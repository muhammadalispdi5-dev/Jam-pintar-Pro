import re,sys
s=open('app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt').read()
ok=True
def cek(n,c):
    global ok
    print(("LULUS " if c else "GAGAL ")+n); ok&=c
cek("batas akurasi 25 m",'if (akurat) 25f else 2_000f' in s)
cek("berhenti cepat 10 m",'location.accuracy <= 10f' in s)
cek("hasil lunak 9 detik",'postDelayed(lunak, 9_000L)' in s)
cek("batas keras 25 detik",'if (akurat) 25_000L' in s)
cek("lunak dibatalkan saat selesai",s.count('removeCallbacks(lunak)')>=1)
cek("tidak ada batas 3 m lama",'if (akurat) 3f' not in s)
sys.exit(0 if ok else 1)
