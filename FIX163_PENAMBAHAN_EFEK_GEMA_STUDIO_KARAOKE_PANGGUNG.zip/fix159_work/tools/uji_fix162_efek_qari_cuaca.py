from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
base = ROOT / 'app/src/main/java/com/novan/bateraibicara'
prefs = (base / 'Prefs.kt').read_text(encoding='utf-8')
page = (base / 'Halaman.kt').read_text(encoding='utf-8')
speaker = (base / 'Pembicara.kt').read_text(encoding='utf-8')
khatam = (base / 'KhatamActivity.kt').read_text(encoding='utf-8')
qari_voice = (base / 'QariSuara.kt').read_text(encoding='utf-8')
weather = (base / 'PerintahSuaraActivity.kt').read_text(encoding='utf-8')
assert 'efekRuang' in prefs and 'efekRuang + "|"' in prefs
assert all(x in page for x in ['Ruang kecil', 'Ruang sedang', 'Ruang besar', 'Aula sedang', 'Aula besar', 'Studio / Plate'])
assert 'PresetReverb' in speaker and 'mesin.audioSessionId' in speaker
assert 'ToneGenerator.TONE_PROP_BEEP' not in speaker
assert 'tr("Qari perempuan"' not in khatam and 'Female reciters' not in khatam
assert 'qariNoreenCadangan' not in khatam and 'daftarQariPerempuanTerurut' not in khatam
assert 'Female reciters' not in khatam and '!label.startsWith("Perempuan · ")' in qari_voice
assert 'cobaCuacaCadanganWttr' in weather and 'https://wttr.in/' in weather
assert 'api.open-meteo.com/v1/forecast' in weather
print('UJI FIX162: LULUS (efek vokal Jam/Baterai, qari perempuan tak terverifikasi dihapus, cuaca dengan sumber cadangan)')
