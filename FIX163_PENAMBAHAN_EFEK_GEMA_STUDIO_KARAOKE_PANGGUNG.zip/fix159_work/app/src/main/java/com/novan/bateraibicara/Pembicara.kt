package com.novan.bateraibicara

import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Pembungkus TextToSpeech untuk satu kategori (baterai / jam / pemanggil).
 * Memakai mesin suara pilihan pengguna, menahan CPU saat bicara (layar mati),
 * dan meminta fokus audio agar suara lain mengecil sebentar.
 */
class Pembicara(
    context: Context,
    private val suara: Prefs.Suara,
    private val peringatan: ((Int) -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private class Item(val teks: String, val flush: Boolean, val selesai: (() -> Unit)?)

    private val app = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    val tanda: String = suara.tanda()
    /** FIX74: true untuk pengumuman otomatis (notifikasi); suara dapat dihentikan dengan menelungkupkan HP. */
    var bisaDibungkam = false
    /**
     * FIX154: true untuk pengumuman otomatis di latar belakang (jam bicara, baterai, pemberitahuan masuk). Pengumuman seperti ini hanya
     * meminta fokus audio "boleh diturunkan" (ducking): audio aplikasi lain, mis. voice note, mengecil sebentar lalu kembali normal.
     * Dengan fokus sementara penuh (perilaku sejak FIX146), aplikasi seperti WhatsApp menjeda voice note dan tidak melanjutkannya sendiri.
     * Ucapan asisten yang diminta pengguna tetap memakai fokus sementara penuh.
     */
    var hanyaKecilkanAudioLain = false
    /** Paksa bahasa TTS mengikuti bahasa tampilan aplikasi untuk dialog asisten suara. */
    var paksaBahasaTampilan = false
    private val kunciBungkam = "tts:" + System.identityHashCode(this)
    private var tts: TextToSpeech? = null
    private var siap = false
    private var sudahCobaBawaan = false
    private var gagalInit = false
    private var terakhirCoba = 0L
    private val tunda = ArrayList<Item>()
    private val callbacks = HashMap<String, () -> Unit>()
    private var aktif = 0
    private var fokus: AudioFocusRequest? = null
    private var reverb: android.media.audiofx.PresetReverb? = null
    private var sesiReverb = -1
    private val wakeLock: PowerManager.WakeLock =
        (app.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bateraibicara:bicara")
            .apply { setReferenceCounted(false) }
    private val bersihkan = Runnable {
        aktif = 0
        rangkaianBerjalan = false
        selesaiBicara()
    }

    init {
        val engine = suara.engine
        tts = if (engine.isEmpty()) TextToSpeech(app, this) else TextToSpeech(app, this, engine)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            if (suara.engine.isNotEmpty() && !sudahCobaBawaan) {
                sudahCobaBawaan = true
                handler.post {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = TextToSpeech(app, this)
                }
            } else {
                gagalInit = true
                peringatan?.invoke(R.string.tts_gagal)
            }
            return
        }
        // Bahasa pengucapan adalah pilihan global, bukan hanya untuk jam dan kalender.
        // Fitur lokasi dan pemandu jalan mengikuti bahasa tampilan aplikasi agar petunjuknya
        // tidak bercampur bahasa. Profil lain tetap mengikuti pilihan bahasa ucapan global.
        val bahasaUcapan = if (paksaBahasaTampilan || suara.profil == "pemandu" || suara.profil == "lokasi") {
            BahasaAplikasi.tampilan(app)
        } else Prefs(app).bahasaAktif
        val locale = when (bahasaUcapan) {
            1 -> Locale.forLanguageTag("en-US")
            2 -> Locale.forLanguageTag("ar")
            3 -> Locale.forLanguageTag("jv-ID")
            4 -> Locale.forLanguageTag("su-ID")
            else -> Locale.forLanguageTag("id-ID")
        }
        val r = t.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            peringatan?.invoke(R.string.bahasa_tidak_ada)
            val bahasaCadangan = Locale.forLanguageTag("id-ID")
            val r2 = t.setLanguage(bahasaCadangan)
            // FIX68: bila suara Indonesia pun belum terpasang, pakai bahasa bawaan HP agar pengumuman tidak senyap.
            if (r2 == TextToSpeech.LANG_MISSING_DATA || r2 == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.getDefault())
            }
        }
        t.setSpeechRate(suara.rate)
        t.setPitch(suara.pitch)
        t.setAudioAttributes(suara.audioAttributes())
        terapkanEfekRuangTts(t)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { selesaiSatu(utteranceId, true) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { selesaiSatu(utteranceId, true) }
            override fun onError(utteranceId: String?, errorCode: Int) { selesaiSatu(utteranceId, true) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { selesaiSatu(utteranceId, false) }
        })
        siap = true
        val antrean = ArrayList(tunda)
        tunda.clear()
        for (i in antrean) ucapkan(i.teks, i.flush, i.selesai)
    }

    /** Terapkan efek ruang nyata pada sesi audio TTS (Android 8+); perangkat yang tidak mendukung tetap memakai suara normal. */
    private fun terapkanEfekRuangTts(mesin: TextToSpeech) {
        if (suara.profil != "jam" && suara.profil != "bat") return
        if (Build.VERSION.SDK_INT < 26) return
        val pilihan = suara.efekRuang
        if (pilihan <= 0) { lepasEfekRuang(); return }
        try {
            val sesi = mesin.audioSessionId
            if (sesi <= 0) return
            if (reverb != null && sesiReverb != sesi) lepasEfekRuang()
            if (reverb == null) {
                reverb = android.media.audiofx.PresetReverb(0, sesi)
                sesiReverb = sesi
            }
            val preset = when (pilihan) {
                1 -> android.media.audiofx.PresetReverb.PRESET_SMALLROOM
                2 -> android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM
                3 -> android.media.audiofx.PresetReverb.PRESET_LARGEROOM
                4 -> android.media.audiofx.PresetReverb.PRESET_MEDIUMHALL
                5 -> android.media.audiofx.PresetReverb.PRESET_LARGEHALL
                6 -> android.media.audiofx.PresetReverb.PRESET_PLATE
                // Android tidak menyediakan efek echo/delay universal untuk sesi TTS.
                // Pilihan berikut memakai preset reverb terdekat dan dijelaskan di UI.
                7 -> android.media.audiofx.PresetReverb.PRESET_PLATE       // Echo-like
                8 -> android.media.audiofx.PresetReverb.PRESET_PLATE       // Vocal studio
                9 -> android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM  // Karaoke
                else -> android.media.audiofx.PresetReverb.PRESET_LARGEHALL // Concert stage
            }
            reverb?.let { if (it.hasControl()) { it.preset = preset; it.enabled = true } }
        } catch (_: Exception) {
            lepasEfekRuang()
        }
    }

    private fun lepasEfekRuang() {
        try { reverb?.enabled = false } catch (_: Exception) { }
        try { reverb?.release() } catch (_: Exception) { }
        reverb = null
        sesiReverb = -1
    }

    /** [selesai] dipanggil setelah kalimat selesai diucapkan (tidak dipanggil bila dihentikan paksa). */
    fun ucapkan(teks: String, flush: Boolean = false, selesai: (() -> Unit)? = null) {
        if (ModeAcara.aktif(app)) { selesai?.invoke(); return }
        val t = tts
        if (t == null || !siap) {
            // FIX68: mesin suara gagal aktif (mis. layanan suara baru dipasang atau sempat dimatikan sistem);
            // coba nyalakan ulang paling cepat tiap 5 detik, dan batasi antrean agar tidak menumpuk.
            if (gagalInit && System.currentTimeMillis() - terakhirCoba > 5000L) {
                gagalInit = false
                terakhirCoba = System.currentTimeMillis()
                handler.post {
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = TextToSpeech(app, this)
                }
            }
            if (tunda.size >= 5) tunda.removeAt(0)
            tunda.add(Item(teks, flush, selesai))
            return
        }
        ucapkanLangsung(teks, flush, selesai)
    }

    private fun ucapkanLangsung(teks: String, flush: Boolean, selesai: (() -> Unit)?) {
        val t = tts
        if (t == null || !siap) {
            if (tunda.size >= 5) tunda.removeAt(0)
            tunda.add(Item(teks, flush, selesai))
            return
        }
        aktif++
        wakeLock.acquire(60_000L)
        if (bisaDibungkam) PembungkamTelungkup.mulai(app, kunciBungkam, 90_000L) { berhenti() }
        mintaFokus()
        handler.removeCallbacks(bersihkan)
        handler.postDelayed(bersihkan, 45_000L)
        val id = "bb" + System.nanoTime()
        if (selesai != null) callbacks[id] = selesai
        // Parameter stream lama juga dipasang karena sebagian mesin suara mengabaikan AudioAttributes.
        val parameter = android.os.Bundle()
        parameter.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, suara.streamType())
        // Pastikan level keluaran TTS tidak tereduksi oleh parameter volume per-utterance.
        // Nilai 1.0 adalah level digital penuh; volume fisik tetap mengikuti kontrol Android.
        parameter.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, suara.volumePersen / 100f)
        val hasil = t.speak(
            teks,
            if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            parameter,
            id
        )
        if (hasil != TextToSpeech.SUCCESS) {
            selesaiSatu(id, true)
        }
    }

    /** Membacakan segmen satu per satu dengan jeda standar acuan main.lua (300 ms). */
    fun ucapkanRangkaian(segmen: List<String>, jedaMs: Long = 300L, selesai: (() -> Unit)? = null) {
        if (ModeAcara.aktif(app)) { selesai?.invoke(); return }
        val bersih = segmen.map { it.trim() }.filter { it.isNotEmpty() }
        if (bersih.isEmpty()) { selesai?.invoke(); return }
        var indeks = 0
        // FIX134: selama rangkaian berjalan, pendaftaran ke pembungkam (tombol volume dan telungkup) dipertahankan di sela kalimat.
        // Dahulu pendaftaran dilepas tiap kalimat selesai dan dipasang lagi di kalimat berikut, sehingga tombol volume tidak dikenali
        // pada jeda antarkalimat dan pada 1,2 detik pertama tiap kalimat (masa tenang pemantau volume).
        val id = ++idRangkaian
        rangkaianBerjalan = true
        fun akhiri() {
            if (id == idRangkaian) {
                rangkaianBerjalan = false
                if (bisaDibungkam) PembungkamTelungkup.selesai(kunciBungkam)
            }
            selesai?.invoke()
        }
        fun lanjut() {
            if (id != idRangkaian) return // dihentikan (tombol volume, telungkup, atau rangkaian baru)
            if (indeks >= bersih.size) { akhiri(); return }
            val teks = bersih[indeks++]
            ucapkan(teks, indeks == 1) {
                if (id != idRangkaian) return@ucapkan
                if (indeks >= bersih.size) akhiri()
                else handler.postDelayed({ lanjut() }, jedaMs.coerceAtLeast(0L))
            }
        }
        lanjut()
    }

    private var rangkaianBerjalan = false
    private var idRangkaian = 0

    fun berhenti() {
        tunda.clear()
        callbacks.clear()
        aktif = 0
        idRangkaian++ // membatalkan kalimat rangkaian yang tertunda di sela jeda
        rangkaianBerjalan = false
        try { tts?.stop() } catch (e: Exception) { }
        selesaiBicara()
    }

    fun matikan() {
        berhenti()
        lepasEfekRuang()
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        siap = false
    }

    private fun selesaiSatu(id: String?, panggil: Boolean) {
        handler.post {
            val cb = if (id != null) callbacks.remove(id) else null
            if (aktif > 0) aktif--
            if (aktif == 0) selesaiBicara()
            if (panggil) cb?.invoke()
        }
    }

    private fun selesaiBicara() {
        handler.removeCallbacks(bersihkan)
        lepasFokus()
        if (wakeLock.isHeld) wakeLock.release()
        if (bisaDibungkam && !rangkaianBerjalan) PembungkamTelungkup.selesai(kunciBungkam)
    }

    private fun mintaFokus() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val jenisFokus = if (hanyaKecilkanAudioLain) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(jenisFokus)
                .setAudioAttributes(suara.audioAttributes())
                // Pemutar lain boleh menurunkan volumenya sendiri, bukan menjeda, saat pengumuman berbunyi.
                .setWillPauseWhenDucked(false)
                .build()
            fokus = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, suara.streamType(), jenisFokus)
        }
    }

    private fun lepasFokus() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            fokus?.let { am.abandonAudioFocusRequest(it) }
            fokus = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }
}
