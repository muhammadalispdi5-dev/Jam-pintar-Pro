package com.novan.bateraibicara

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

/**
 * FIX142: menerapkan pengaturan equalizer dan efek audio Khatam (preset, kustom, bass, suara ruang, penguat volume)
 * pada pemutar latar belakang, sehingga audio yang dimulai lewat perintah suara terdengar sama seperti di layar Khatam
 * tanpa membuka layar apa pun. Pengaturan dibaca dari SharedPreferences "khatam_quran" yang sama.
 * Semua kegagalan efek diabaikan secara diam-diam: audio tetap diputar tanpa efek.
 */
class EfekAudioLatar(private val context: Context) {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virtual: Virtualizer? = null
    private var penguat: LoudnessEnhancer? = null
    private var sesi = 0

    private val titikHz = floatArrayOf(60f, 150f, 400f, 1000f, 2500f, 6000f, 12000f)
    private val kurva: Map<String, FloatArray> = mapOf(
        "vocal" to floatArrayOf(-3f, -1f, 1f, 3f, 5f, 3f, 1f),
        "bass" to floatArrayOf(6f, 5f, 2f, 0f, -1f, -2f, -2f),
        "treble" to floatArrayOf(-3f, -2f, -1f, 0f, 3f, 5f, 6f),
        "jernih" to floatArrayOf(-4f, -3f, -1f, 1f, 4f, 4f, 2f),
        "hangat" to floatArrayOf(2f, 3f, 2f, 0f, -2f, -3f, -4f),
        "malam" to floatArrayOf(-3f, -1f, 0f, 0f, -1f, -3f, -5f),
        "speaker" to floatArrayOf(-5f, -2f, 1f, 3f, 3f, 2f, 0f)
    )

    private fun gainDb(preset: String, hz: Float): Float {
        val k = kurva[preset] ?: return 0f
        val x = hz.coerceAtLeast(1f)
        if (x <= titikHz.first()) return k.first()
        if (x >= titikHz.last()) return k.last()
        for (i in 0 until titikHz.size - 1) {
            if (x <= titikHz[i + 1]) {
                val a = Math.log10(titikHz[i].toDouble())
                val b = Math.log10(titikHz[i + 1].toDouble())
                val t = (Math.log10(x.toDouble()) - a) / (b - a)
                return (k[i] + (k[i + 1] - k[i]) * t).toFloat()
            }
        }
        return k.last()
    }

    private fun kunciKustom(slot: String) = when (slot) {
        "kustom2" -> "equalizer_kustom2_mb"
        "kustom3" -> "equalizer_kustom3_mb"
        else -> "equalizer_kustom_mb"
    }

    /** Pasang efek pada sesi audio pemutar yang baru disiapkan. Aman dipanggil berulang untuk sesi berbeda. */
    fun pasang(audioSessionId: Int) {
        if (audioSessionId <= 0) return
        if (audioSessionId != sesi) lepas()
        sesi = audioSessionId
        val kh = context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE)
        val preset = kh.getString("preset_equalizer_audio", "normal") ?: "normal"
        val bassP = (if (preset == "bass") maxOf(kh.getInt("efek_bass_persen", 0), 60) else kh.getInt("efek_bass_persen", 0)).coerceIn(0, 100)
        val ruangP = kh.getInt("efek_spasial_persen", 0).coerceIn(0, 100)
        val dbP = kh.getInt("efek_penguat_db", 0).coerceIn(0, 10)

        if (preset != "normal") {
            try {
                val e = eq ?: Equalizer(0, audioSessionId).also { eq = it }
                if (e.hasControl()) {
                    val jumlah = e.numberOfBands.toInt()
                    if (jumlah > 0) {
                        val min = e.bandLevelRange[0].toInt()
                        val maks = e.bandLevelRange[1].toInt()
                        e.enabled = true
                        if (preset.startsWith("dev_")) {
                            val n = preset.removePrefix("dev_").toIntOrNull() ?: -1
                            if (n in 0 until e.numberOfPresets.toInt()) e.usePreset(n.toShort())
                        } else {
                            val simpan = if (preset.startsWith("kustom"))
                                (kh.getString(kunciKustom(preset), "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() } else null
                            for (i in 0 until jumlah) {
                                val hz = e.getCenterFreq(i.toShort()).toFloat() / 1000f
                                val mB = if (simpan != null) simpan.getOrElse(i) { 0 } else Math.round(gainDb(preset, hz) * 100f)
                                e.setBandLevel(i.toShort(), mB.coerceIn(min, maks).toShort())
                            }
                        }
                    }
                }
            } catch (_: Exception) { try { eq?.release() } catch (_: Exception) { }; eq = null }
        }
        try {
            if (bassP > 0) {
                val b = bass ?: BassBoost(0, audioSessionId).also { bass = it }
                if (b.strengthSupported) { b.setStrength((bassP * 10).coerceIn(0, 1000).toShort()); b.enabled = true }
            }
        } catch (_: Exception) { try { bass?.release() } catch (_: Exception) { }; bass = null }
        try {
            if (ruangP > 0) {
                val v = virtual ?: Virtualizer(0, audioSessionId).also { virtual = it }
                if (v.strengthSupported) { v.setStrength((ruangP * 10).coerceIn(0, 1000).toShort()); v.enabled = true }
            }
        } catch (_: Exception) { try { virtual?.release() } catch (_: Exception) { }; virtual = null }
        try {
            if (dbP > 0) {
                val l = penguat ?: LoudnessEnhancer(audioSessionId).also { penguat = it }
                l.setTargetGain(dbP * 100); l.enabled = true
            }
        } catch (_: Exception) { try { penguat?.release() } catch (_: Exception) { }; penguat = null }
    }

    fun lepas() {
        try { eq?.release() } catch (_: Exception) { }
        try { bass?.release() } catch (_: Exception) { }
        try { virtual?.release() } catch (_: Exception) { }
        try { penguat?.release() } catch (_: Exception) { }
        eq = null; bass = null; virtual = null; penguat = null; sesi = 0
    }
}
