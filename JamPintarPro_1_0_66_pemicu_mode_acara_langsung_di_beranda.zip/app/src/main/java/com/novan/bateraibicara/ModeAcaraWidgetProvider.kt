package com.novan.bateraibicara

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

/** Widget terpisah untuk mengaktifkan/menonaktifkan Mode Acara dengan satu ketukan. */
class ModeAcaraWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val pesan = ModeAcara.toggleCepat(context.applicationContext)
            Toast.makeText(context, pesan, Toast.LENGTH_LONG).show()
            perbaruiSemua(context)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        perbarui(context, manager, ids)
    }

    companion object {
        private const val ACTION_TOGGLE = "com.novan.jambicarapro.MODE_ACARA_WIDGET_TOGGLE"

        fun perbaruiSemua(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, ModeAcaraWidgetProvider::class.java)
            perbarui(context, manager, manager.getAppWidgetIds(component))
        }

        private fun perbarui(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val aktif = ModeAcara.aktif(context)
            val label = if (aktif) "Akhiri Mode Acara" else "Aktifkan Mode Acara"
            val deskripsi = if (aktif) {
                "Mode Acara dan Pertemuan sedang aktif. Ketuk dua kali untuk menonaktifkan dan memulihkan pengaturan sebelumnya."
            } else {
                "Mode Acara dan Pertemuan sedang nonaktif. Ketuk dua kali untuk mengaktifkan menggunakan cakupan dan durasi yang tersimpan."
            }
            val intent = Intent(context, ModeAcaraWidgetProvider::class.java).setAction(ACTION_TOGGLE)
            val pending = PendingIntent.getBroadcast(
                context,
                8172,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            for (id in ids) {
                val views = RemoteViews(context.packageName, R.layout.widget_mode_acara)
                views.setTextViewText(R.id.widget_mode_acara_button, label)
                views.setContentDescription(R.id.widget_mode_acara_button, deskripsi)
                views.setContentDescription(R.id.widget_mode_acara_root, deskripsi)
                views.setOnClickPendingIntent(R.id.widget_mode_acara_root, pending)
                views.setOnClickPendingIntent(R.id.widget_mode_acara_button, pending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
