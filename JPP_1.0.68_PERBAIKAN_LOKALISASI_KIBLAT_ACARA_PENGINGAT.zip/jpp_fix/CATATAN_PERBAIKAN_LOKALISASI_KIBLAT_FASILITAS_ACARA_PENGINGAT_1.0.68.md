# Catatan Perbaikan Lokalisasi — Jam Pintar Pro 1.0.68

Perbaikan ini mempertahankan versionCode 68 dan versionName 1.0.68.

## Cakupan
- Find Nearby Public Facilities: label fasilitas dan kueri pencarian mengikuti bahasa tampilan Inggris atau Indonesia.
- Events and Meetings Mode: petunjuk, pilihan cakupan, pengecualian, durasi, status, izin Jangan Ganggu, dan sisa waktu ditampilkan secara konsisten.
- Qibla Direction and Compass: status arah, arah mata angin, perbedaan derajat, arahan putar, dan pesan sensor/kalibrasi mengikuti bahasa tampilan.
- Prayer Time Reminder, Adhan Sound and Sound Test, serta Suhoor and Iftar Reminders: menambahkan terjemahan untuk petunjuk dan label dinamis yang sebelumnya masih berbahasa Indonesia.
- BahasaAplikasi: menambahkan pemetaan awalan untuk label dinamis, termasuk nama salat yang disisipkan ke label.

## Validasi
- Berkas XML sumber daya diparsing untuk memastikan struktur valid.
- Arsip ZIP diuji setelah dibuat.
- Build Android penuh tidak dapat diklaim berhasil: proyek ini tidak menyertakan Gradle wrapper yang dapat dijalankan di lingkungan ini. Jalankan GitHub Actions untuk verifikasi kompilasi APK.
