package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri

/** Pencarian fasilitas terdekat lewat aplikasi peta yang dipilih pengguna. */
class FasilitasTerdekatActivity : Halaman() {
    override val judulHalaman = R.string.kategori_fasilitas_terdekat

    override fun bangun() {
        info("Pilih jenis fasilitas yang ingin dicari. Pencarian dibuka di Google Maps atau aplikasi peta yang tersedia. Internet dan izin lokasi pada aplikasi peta mungkin diperlukan agar hasil dan jarak terdekat akurat. Jam Pintar Pro tidak menyimpan lokasi Anda.")
        val bahasaInggris = BahasaAplikasi.tampilan(this) == 1
        val pilihan = listOf(
            Triple("Masjid dan musala", "Mosques and Prayer Rooms", "mosque prayer room nearby"),
            Triple("Rumah sakit", "Hospitals", "hospital nearby"),
            Triple("Puskesmas dan klinik", "Community Health Centers and Clinics", "community health center clinic nearby"),
            Triple("Apotek", "Pharmacies", "pharmacy nearby"),
            Triple("ATM", "ATM", "ATM nearby"),
            Triple("Bank", "Banks", "bank nearby"),
            Triple("Toilet umum", "Public Restrooms", "public restroom nearby"),
            Triple("Kantor polisi", "Police Stations", "police station nearby"),
            Triple("Pemadam kebakaran", "Fire Stations", "fire station nearby"),
            Triple("SPBU", "Gas Stations", "gas station nearby"),
            Triple("Halte dan stasiun", "Bus Stops and Train Stations", "bus stop train station nearby"),
            Triple("Pasar dan minimarket", "Markets and Convenience Stores", "market convenience store nearby")
        )
        for ((labelId, labelEn, queryEn) in pilihan) {
            tombol(if (bahasaInggris) labelEn else labelId) {
                val query = if (bahasaInggris) queryEn else when (labelId) {
                    "Masjid dan musala" -> "masjid dan musala terdekat"
                    "Rumah sakit" -> "rumah sakit terdekat"
                    "Puskesmas dan klinik" -> "puskesmas klinik terdekat"
                    "Apotek" -> "apotek terdekat"
                    "ATM" -> "ATM terdekat"
                    "Bank" -> "bank terdekat"
                    "Toilet umum" -> "toilet umum terdekat"
                    "Kantor polisi" -> "kantor polisi terdekat"
                    "Pemadam kebakaran" -> "pemadam kebakaran terdekat"
                    "SPBU" -> "SPBU terdekat"
                    "Halte dan stasiun" -> "halte stasiun terdekat"
                    else -> "pasar minimarket terdekat"
                }
                cari(query)
            }
        }
    }

    private fun cari(query: String) {
        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { toast("Aplikasi peta tidak dapat dibuka.") }
    }
}
