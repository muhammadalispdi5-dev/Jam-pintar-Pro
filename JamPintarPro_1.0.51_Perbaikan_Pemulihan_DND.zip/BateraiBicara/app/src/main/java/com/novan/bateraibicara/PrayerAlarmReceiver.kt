package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action.orEmpty()
        val pp = PrayerPrefs(context)
        if (action == "com.novan.jambicarapro.RESTORE_PRAYER_DND") {
            val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
            val until = state.getLong("prayer_dnd_active_until", 0L)
            if (until > System.currentTimeMillis()) {
                // Alarm lama mungkin terpanggil setelah durasi diperpanjang oleh salat berikutnya.
                PrayerAlarm.scheduleDndRestore(context, until)
            } else {
                PrayerAlarm.restoreExpiredDnd(context)
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        val key = intent.getStringExtra("prayer_key") ?: return
        if (action == "com.novan.jambicarapro.START_PRAYER_DND") {
            if (pp.dndEnabled && pp.locationSet && pp.dndPrayer(key) && android.os.Build.VERSION.SDK_INT >= 23) {
                val nm = context.getSystemService(android.app.NotificationManager::class.java)
                if (nm.isNotificationPolicyAccessGranted) {
                    val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
                    val now = System.currentTimeMillis()
                    val oldUntil = state.getLong("prayer_dnd_active_until", 0L)
                    val savedPrevious = state.getInt("prayer_dnd_previous_filter", android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
                    val current = nm.currentInterruptionFilter
                    // Hindari menyimpan ALARMS sebagai keadaan awal jika pemulihan sebelumnya terlewat.
                    val previous = when {
                        oldUntil > now -> savedPrevious
                        current == android.app.NotificationManager.INTERRUPTION_FILTER_ALARMS && state.contains("prayer_dnd_previous_filter") ->
                            if (savedPrevious == android.app.NotificationManager.INTERRUPTION_FILTER_ALARMS) android.app.NotificationManager.INTERRUPTION_FILTER_ALL else savedPrevious
                        else -> current
                    }
                    val until = now + pp.dndDuration * 60_000L
                    // Simpan filter asal dan batas waktu secara atomik sebelum mengubah DND.
                    state.edit().putInt("prayer_dnd_previous_filter", previous)
                        .putLong("prayer_dnd_active_until", until).commit()
                    try { nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_ALARMS) } catch (_: Exception) { }
                    // Jadwalkan pemulihan langsung dari receiver agar tidak bergantung pada
                    // penjadwalan ulang alarm salat/pengingat yang lain.
                    PrayerAlarm.scheduleDndRestore(context, until)
                }
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        val advance = intent.getBooleanExtra("advance_reminder", false)
        val allowed = if (advance) pp.advanceReminder(key) else pp.reminder(key)
        if (pp.enabled && allowed) {
            val service = Intent(context, PrayerAlarmService::class.java)
                .putExtra("prayer_key", key)
                .putExtra("advance_reminder", advance)
            try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
        }
        PrayerAlarm.scheduleAll(context)
    }
}
