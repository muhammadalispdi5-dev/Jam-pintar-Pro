B="app/src/main/java/com/novan/bateraibicara/"
a=open(B+"TafsirActivity.kt").read(); m=open(B+"Melodi.kt").read(); b=open(B+"BatteryTalkService.kt").read(); g=open("app/build.gradle.kts").read()
def cek(n,k): print(("ok " if k else "GAGAL ")+n)
cek("urutan tafsir",a.index("1. Cari berdasarkan")<a.index("2. Cari berdasarkan tema")<a.index("Hasil tafsir")<a.index("3. Unduhan kitab"))
cek("melodi DND",b.count("DndSistem.senyap")>=5)
cek("versi",'versionCode = 92' in g and '1.0.92' in g)
t=open(B+"TafsirActivity.kt").read(); j=open(B+"TajwidActivity.kt").read()
cek("tafsir blokSuara di bawah",t.index("3. Unduhan kitab")<t.index('blokSuara("tafsir")') and "MesinSuaraPembaca" not in t)
cek("tajwid blokSuara",'blokSuara("tajwid")' in j and "MesinSuaraPembaca" not in j)
for f in ("Hadits","KhutbahJumat","PanduanIbadah","ManasikHaji","DoaHarian","AsmaulHusna"):
    x=open(B+f+"Activity.kt").read(); cek("mesin di bawah "+f,"tombolMesinBawah()" in x and x.count('tombol(tr("Pilih mesin suara pembaca"')==1)
