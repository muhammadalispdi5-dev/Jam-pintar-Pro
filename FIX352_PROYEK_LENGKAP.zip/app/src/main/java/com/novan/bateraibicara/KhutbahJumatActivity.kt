package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale

/**
 * FIX202: Himpunan Khutbah Jum'at. Daftar naskah -> halaman naskah (khutbah pertama dan kedua) dengan ukuran huruf
 * yang dapat diatur, salin, bagikan, dan dengarkan (teks-ke-ucapan, mengikuti bahasa aktif).
 */
class KhutbahJumatActivity : Halaman() {
    override val judulHalaman = R.string.judul_khutbah

    private val simpan by lazy { getSharedPreferences("khutbah_jumat", MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private var tertunda: (() -> Unit)? = null

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun judul(k: KhutbahData.Khutbah) = if (english) k.judulEn else k.judulId
    private fun isi(b: KhutbahData.Blok) = if (english) b.en else b.id

    override fun onPause() {
        BacaanBisaDibungkam.lepas("baca_khutbah")
        try { tts?.stop() } catch (_: Exception) { }
        super.onPause()
    }

    override fun onDestroy() {
        BacaanBisaDibungkam.lepas("baca_khutbah")
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("khutbah", -1)
        val k = KhutbahData.daftar.getOrNull(nomor)
        if (k == null) daftar() else { naskah(nomor, k); tombolMesinBawah() }
    }

    // ---------- Daftar ----------

    private fun daftar() {
        info(tr(
            "Himpunan lebih dari delapan puluh naskah khutbah Jum'at yang dapat dibaca dari ponsel, lengkap dengan khutbah pertama dan kedua, kutipan Arab, dan terjemahan. Naskah ini draf yang disusun untuk aplikasi ini; sebaiknya ditinjau ustadz atau takmir sebelum disampaikan di mimbar.",
            "A collection of Friday sermon texts (over eighty topics) you can read on your phone, with the first and second sermons, Arabic quotations, and translations. These texts are drafts prepared for this app; please have a scholar or mosque committee review them before delivering them from the pulpit."
        ))
        var render: (String) -> Unit = { }
        val kolom = isian(tr("Cari tema khutbah", "Search sermon topic"), "", android.text.InputType.TYPE_CLASS_TEXT) { render(it) }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        val mulai = root.childCount
        render = { teksCari ->
            while (root.childCount > mulai) root.removeViewAt(root.childCount - 1)
            val q = teksCari.trim().lowercase(Locale.ROOT)
            var ada = 0
            KhutbahData.daftar.forEachIndexed { i, k ->
                if (q.isEmpty() || k.judulId.lowercase(Locale.ROOT).contains(q) || k.judulEn.lowercase(Locale.ROOT).contains(q) || (i + 1).toString() == q) {
                    ada++
                    tombol((i + 1).toString() + ". " + judul(k)) {
                        startActivity(Intent(this, KhutbahJumatActivity::class.java).putExtra("khutbah", i))
                    }
                }
            }
            if (ada == 0) info(tr("Tidak ada tema yang cocok.", "No matching topic."))
            tombolMesinBawah()
        }
        render("")
    }

    // ---------- Naskah ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 18f)

    private fun naskah(nomor: Int, k: KhutbahData.Khutbah) {
        bagian(judul(k), 22f)
        tombol(tr("Dengarkan khutbah ini", "Listen to this sermon")) { ucapkanSemua(k) }
        tombol(tr("Hentikan suara", "Stop audio")) { try { tts?.stop() } catch (_: Exception) { }; BacaanBisaDibungkam.lepas("baca_khutbah") }
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(34f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }

        subjudul(tr("Khutbah pertama", "First sermon"))
        k.pertama.forEach { blok(it) }
        subjudul(tr("Khutbah kedua", "Second sermon"))
        k.kedua.forEach { blok(it) }

        val semua = teksLengkap(k)
        tombol(tr("Salin naskah", "Copy text")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("khutbah", semua))
                toast(tr("Naskah disalin.", "Text copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan naskah", "Share text")) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua)
                startActivity(Intent.createChooser(i, tr("Bagikan naskah khutbah", "Share sermon text")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan naskah.", "No app is available to share this text."))
            }
        }
    }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 20f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(24), 0, dp(6))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun blok(b: KhutbahData.Blok) {
        if (b.arab != null) {
            val ar = TextView(this)
            ar.text = b.arab
            ar.textSize = ukuran() + 6f
            ar.setTextColor(warnaTeks())
            ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
            ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            ar.setLineSpacing(0f, 1.3f)
            ar.setPadding(0, dp(12), 0, dp(6))
            root.addView(ar)
        }
        val tv = TextView(this)
        tv.text = isi(b)
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(4), 0, dp(8))
        root.addView(tv)
        if (b.sumber != null) {
            val s = TextView(this)
            s.text = b.sumber
            s.textSize = 14f
            s.setTextColor(warnaPetunjuk())
            root.addView(s)
        }
    }

    private fun teksLengkap(k: KhutbahData.Khutbah): String = buildString {
        append(judul(k)).append("\n\n")
        append(tr("Khutbah pertama", "First sermon")).append("\n\n")
        k.pertama.forEach { b -> if (b.arab != null) append(b.arab).append("\n"); append(isi(b)).append("\n\n") }
        append(tr("Khutbah kedua", "Second sermon")).append("\n\n")
        k.kedua.forEach { b -> if (b.arab != null) append(b.arab).append("\n"); append(isi(b)).append("\n\n") }
    }.trim()

    // ---------- Audio: membaca terjemahan/isi dalam bahasa aktif (kutipan Arab tidak dibacakan) ----------

    private fun pecah(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        var sisa = teks.trim()
        while (sisa.length > maks) {
            var potong = sisa.lastIndexOfAny(charArrayOf('.', '\n', ';', ':'), maks)
            if (potong < maks / 2) potong = sisa.lastIndexOf(' ', maks)
            if (potong <= 0) potong = maks - 1
            hasil.add(sisa.substring(0, potong + 1).trim())
            sisa = sisa.substring(potong + 1).trim()
        }
        if (sisa.isNotEmpty()) hasil.add(sisa)
        return hasil
    }

    /** FIX352: pemilih mesin suara diletakkan di bagian paling bawah halaman. */
    private fun tombolMesinBawah() {
        bagian(tr("Mesin suara pembaca", "Reading speech engine"))
        tombol(tr("Pilih mesin suara pembaca", "Choose reading speech engine")) { pilihMesinSuara() }
    }

    private fun pilihMesinSuara() {
        MesinSuaraPembaca.tampilkan(this, simpan) {
            try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
            tts = null; ttsSiap = false; tertunda = null
        }
    }

    private fun ucapkanSemua(k: KhutbahData.Khutbah) {
        val aksi: () -> Unit = {
            val m = tts
            if (m != null) {
                val bahasa = if (english) Locale.US else Locale("id", "ID")
                val r = m.setLanguage(bahasa)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    toast(tr("Suara bahasa Indonesia belum terpasang di perangkat. Pasang data suara pada pengaturan teks-ke-ucapan Android.",
                        "The English voice is not installed on this device. Install voice data in Android text-to-speech settings."))
                } else {
                    m.stop()
                    val maks = minOf(3500, TextToSpeech.getMaxSpeechInputLength() - 100)
                    var pertama = true
                    val bacaan = (listOf(judul(k)) + (k.pertama + k.kedua).map { isi(it) }).joinToString("\n")
                    for (potongan in pecah(bacaan, maks)) {
                        m.speak(potongan, if (pertama) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "khutbah_" + System.nanoTime())
                        pertama = false
                    }
                    BacaanBisaDibungkam.mulai(this, m, "baca_khutbah", bacaan.length) { try { m.stop() } catch (_: Exception) { } }
                }
            }
        }
        if (ttsSiap) { aksi(); return }
        tertunda = aksi
        if (tts == null) {
            val mesin = MesinSuaraPembaca.paket(simpan).ifBlank { null }
            tts = TextToSpeech(applicationContext, { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsSiap = true
                    val a = tertunda
                    tertunda = null
                    a?.invoke()
                } else {
                    toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = null
                    tertunda = null
                }
            }, mesin)
        }
    }
}
