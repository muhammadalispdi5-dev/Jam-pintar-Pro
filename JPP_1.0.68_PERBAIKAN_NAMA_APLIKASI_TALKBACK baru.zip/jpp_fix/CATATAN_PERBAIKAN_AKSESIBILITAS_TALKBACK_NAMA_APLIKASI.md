# Perbaikan aksesibilitas daftar aplikasi terpilih — 1.0.68

- Menghapus contentDescription yang sebelumnya membacakan pola teknis seperti “App 1 of 3: ...” dan dapat mengganggu pembacaan label yang terlihat.
- CheckBox kini memakai label teks nama aplikasi sebagai nama aksesibilitas bawaan Android. TalkBack seharusnya membaca nama aplikasi beserta status dicentang/tidak dicentang.
- Nama aplikasi tetap diambil dari label aplikasi yang terpasang; aplikasi yang tidak terpasang tetap ditandai dengan keterangan yang dilokalkan.
- Versi aplikasi tidak diubah: 1.0.68 / versionCode 68.

Pemeriksaan ini adalah perubahan kode sumber. Uji TalkBack di perangkat Android nyata dan kompilasi GitHub Actions tetap diperlukan untuk mengonfirmasi hasil akhir.
