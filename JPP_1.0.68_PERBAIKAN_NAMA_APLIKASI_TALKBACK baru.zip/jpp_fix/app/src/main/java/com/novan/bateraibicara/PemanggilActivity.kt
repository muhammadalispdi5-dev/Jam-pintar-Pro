package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.media.ToneGenerator
import android.media.AudioManager
import android.widget.TextView
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView

/** Pengaturan kategori Nama Pemanggil. */
class PemanggilActivity : Halaman() {

    override val judulHalaman = R.string.kategori_pemanggil

    private lateinit var teksAkses: TextView
    private lateinit var teksTelepon: TextView
    private var teksAksesPesan: TextView? = null

    override fun bangun() {
        when (kodeKelompok()) {
            "izin" -> grupIzin()
            "jenis" -> grupJenis()
            "melodi" -> grupMelodi()
            "suara" -> grupSuara()
            "pesan" -> grupPembacaanPesan()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        saklar(getString(R.string.sw_pem_on), prefs.pemOn) { prefs.pemOn = it }
        info(getString(R.string.info_pemanggil))

        tombolKelompok("Izin dan akses notifikasi", "izin")
        tombolKelompok("Jenis panggilan dan pengulangan", "jenis")
        tombolKelompok("Pembacaan pesan dan notifikasi masuk", "pesan")
        tombolKelompok("Melodi sebelum dan sesudah pengumuman", "melodi")
        tombolKelompok("Suara pengumuman", "suara")
    }

    private fun grupIzin() {
        judulGrup("Izin dan akses notifikasi")
        // ----- Izin -----
        bagian(getString(R.string.bagian_izin))
        teksAkses = info("")
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
        info(getString(R.string.info_setelan_terbatas))
        teksTelepon = info("")
        tombol(getString(R.string.tombol_izin_telepon)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 2)
        }
        tombol(getString(R.string.tombol_izin_kontak)) {
            // Hanya izin kontak yang dipakai (mencocokkan nomor dengan nama). Izin daftar panggilan tidak
            // pernah dipakai dan tidak dideklarasikan di manifest, jadi tidak diminta.
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 3)
        }
        saklar(getString(R.string.sw_nama_panggilan), prefs.pemNamaPanggilan) { prefs.pemNamaPanggilan = it }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

    }

    private fun grupJenis() {
        judulGrup("Jenis panggilan dan pengulangan")
        bagian("Status akses notifikasi", 18f)
        statusAksesNotifikasi()
        info("Pengaturan panggilan disusun menurut sumbernya: telepon seluler, WhatsApp Business, lalu WhatsApp Messenger. Setiap kelompok memuat sakelar pengaktifan dan pola pengumuman yang terkait. Gunakan judul bagian untuk menelusuri pengaturan dengan pembaca layar.")

        // 1. Telepon seluler: sakelar dan pola pengumuman berada dalam satu kelompok.
        bagian("Telepon seluler", 17f)
        saklar(getString(R.string.sw_pem_telp), prefs.pemTelp) { prefs.pemTelp = it }
        info("Atur kalimat yang diucapkan sebelum dan sesudah nama pemanggil untuk panggilan telepon seluler.")
        pasanganPesan("Panggilan telepon seluler", prefs.pesanSebelumTelp, prefs.pesanSesudahTelp,
            { prefs.pesanSebelumTelp = it }, { prefs.pesanSesudahTelp = it })

        // 2. WhatsApp Business: pengaktifan, panggilan suara, dan panggilan video.
        bagian("WhatsApp Business", 17f)
        saklar(getString(R.string.sw_pem_wb), prefs.pemWb) { prefs.pemWb = it }
        info("Atur pengumuman panggilan suara dan panggilan video WhatsApp Business secara terpisah.")
        pasanganPesan("Panggilan suara WhatsApp Business", prefs.pesanSebelumWbSuara, prefs.pesanSesudahWbSuara,
            { prefs.pesanSebelumWbSuara = it }, { prefs.pesanSesudahWbSuara = it })
        pasanganPesan("Panggilan video WhatsApp Business", prefs.pesanSebelumWbVideo, prefs.pesanSesudahWbVideo,
            { prefs.pesanSebelumWbVideo = it }, { prefs.pesanSesudahWbVideo = it })

        // 3. WhatsApp Messenger: pengaktifan, panggilan suara, dan panggilan video.
        bagian("WhatsApp Messenger", 17f)
        saklar(getString(R.string.sw_pem_wa), prefs.pemWa) { prefs.pemWa = it }
        info("Atur pengumuman panggilan suara dan panggilan video WhatsApp Messenger secara terpisah.")
        pasanganPesan("Panggilan suara WhatsApp Messenger", prefs.pesanSebelumWaSuara, prefs.pesanSesudahWaSuara,
            { prefs.pesanSebelumWaSuara = it }, { prefs.pesanSesudahWaSuara = it })
        pasanganPesan("Panggilan video WhatsApp Messenger", prefs.pesanSebelumWaVideo, prefs.pesanSesudahWaVideo,
            { prefs.pesanSebelumWaVideo = it }, { prefs.pesanSesudahWaVideo = it })

        // Pengulangan panggilan tetap menjadi bagian tersendiri setelah semua jenis panggilan.
        bagian(getString(R.string.bagian_ulang))
        isian(
            getString(R.string.pem_jeda), formatDetik(prefs.pemJeda),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        ) { s ->
            val v = s.replace(',', '.').toFloatOrNull()
            if (v != null && v >= 0.3f) prefs.pemJeda = v.coerceAtMost(60f)
        }
        pilihan(getString(R.string.pem_batas), larik(R.array.pem_batas), prefs.pemBatasIdx) {
            prefs.pemBatasIdx = it
        }
    }

    private fun grupPembacaanPesan() {
        judulGrup("Pembacaan pesan dan notifikasi masuk")
        bagian("Status akses notifikasi", 18f)
        teksAksesPesan = statusAksesNotifikasi()
        info("Pengaturan pesan disusun menurut sumbernya: pesan seluler atau SMS, WhatsApp Business, WhatsApp Messenger, lalu aplikasi lain. Pengulangan notifikasi ditempatkan di bagian akhir. Setiap kelompok memuat pengaturan yang berkaitan dengan sumber tersebut.")
        info("Aktifkan sumber notifikasi yang ingin dibacakan. Untuk pesan yang didukung, Anda dapat memilih apakah isi pesan ikut dibacakan dan mengatur kalimat sebelum atau sesudah nama pengirim. Notifikasi pesan suara WhatsApp hanya mengumumkan pemberitahuan dan nama pengirim jika tersedia; audio pesan suara tidak diubah menjadi teks.")

        // 1. Pesan seluler / SMS.
        bagian("Pesan seluler atau SMS", 17f)
        info("Atur apakah notifikasi SMS dibacakan bersama isi pesannya atau hanya pemberitahuannya, lalu sesuaikan kalimat pengumuman pengirim.")
        pilihan("Cara membaca SMS", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanSeluler) { prefs.modePesanSeluler = it }
        saklar("Bacakan notifikasi pesan seluler atau SMS", prefs.bacaPesanSeluler) { prefs.bacaPesanSeluler = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim SMS", prefs.pesanSebelumNamaSms, prefs.pesanSesudahNamaSms,
            { prefs.pesanSebelumNamaSms = it }, { prefs.pesanSesudahNamaSms = it }, "Contoh isi pesan")

        // 2. WhatsApp Business: semua dukungan pesan teks dan pesan suara berurutan di sini.
        bagian("WhatsApp Business", 17f)
        info("Atur pembacaan chat pribadi, chat grup, dan pemberitahuan pesan suara WhatsApp Business.")
        pilihan("Cara membaca WhatsApp Business", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanWb) { prefs.modePesanWb = it }
        saklar("Bacakan chat teks pribadi WhatsApp Business", prefs.bacaChatWbPribadi) { prefs.bacaChatWbPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat pribadi WhatsApp Business", prefs.pesanSebelumChatWbPribadi, prefs.pesanSesudahChatWbPribadi,
            { prefs.pesanSebelumChatWbPribadi = it }, { prefs.pesanSesudahChatWbPribadi = it }, "Contoh isi pesan")
        saklar("Bacakan chat teks grup WhatsApp Business", prefs.bacaChatWbGrup) { prefs.bacaChatWbGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat grup WhatsApp Business", prefs.pesanSebelumChatWbGrup, prefs.pesanSesudahChatWbGrup,
            { prefs.pesanSebelumChatWbGrup = it }, { prefs.pesanSesudahChatWbGrup = it }, "Contoh isi pesan dari grup Keluarga")
        saklar("Bacakan pemberitahuan pesan suara pribadi WhatsApp Business", prefs.bacaSuaraWbPribadi) { prefs.bacaSuaraWbPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara pribadi WhatsApp Business", prefs.pesanSebelumSuaraWbPribadi, prefs.pesanSesudahSuaraWbPribadi,
            { prefs.pesanSebelumSuaraWbPribadi = it }, { prefs.pesanSesudahSuaraWbPribadi = it })
        saklar("Bacakan pemberitahuan pesan suara grup WhatsApp Business", prefs.bacaSuaraWbGrup) { prefs.bacaSuaraWbGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara grup WhatsApp Business", prefs.pesanSebelumSuaraWbGrup, prefs.pesanSesudahSuaraWbGrup,
            { prefs.pesanSebelumSuaraWbGrup = it }, { prefs.pesanSesudahSuaraWbGrup = it })

        // 3. WhatsApp Messenger: semua dukungan pesan teks dan pesan suara berurutan di sini.
        bagian("WhatsApp Messenger", 17f)
        info("Atur pembacaan chat pribadi, chat grup, dan pemberitahuan pesan suara WhatsApp Messenger.")
        pilihan("Cara membaca WhatsApp Messenger", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanWa) { prefs.modePesanWa = it }
        saklar("Bacakan chat teks pribadi WhatsApp Messenger", prefs.bacaChatWaPribadi) { prefs.bacaChatWaPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat pribadi WhatsApp Messenger", prefs.pesanSebelumChatWaPribadi, prefs.pesanSesudahChatWaPribadi,
            { prefs.pesanSebelumChatWaPribadi = it }, { prefs.pesanSesudahChatWaPribadi = it }, "Contoh isi pesan")
        saklar("Bacakan chat teks grup WhatsApp Messenger", prefs.bacaChatWaGrup) { prefs.bacaChatWaGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat grup WhatsApp Messenger", prefs.pesanSebelumChatWaGrup, prefs.pesanSesudahChatWaGrup,
            { prefs.pesanSebelumChatWaGrup = it }, { prefs.pesanSesudahChatWaGrup = it }, "Contoh isi pesan dari grup Keluarga")
        saklar("Bacakan pemberitahuan pesan suara pribadi WhatsApp Messenger", prefs.bacaSuaraWaPribadi) { prefs.bacaSuaraWaPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara pribadi WhatsApp Messenger", prefs.pesanSebelumSuaraWaPribadi, prefs.pesanSesudahSuaraWaPribadi,
            { prefs.pesanSebelumSuaraWaPribadi = it }, { prefs.pesanSesudahSuaraWaPribadi = it })
        saklar("Bacakan pemberitahuan pesan suara grup WhatsApp Messenger", prefs.bacaSuaraWaGrup) { prefs.bacaSuaraWaGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara grup WhatsApp Messenger", prefs.pesanSebelumSuaraWaGrup, prefs.pesanSesudahSuaraWaGrup,
            { prefs.pesanSebelumSuaraWaGrup = it }, { prefs.pesanSesudahSuaraWaGrup = it })

        // 4. Aplikasi lain: daftar notifikasi pihak ketiga yang didukung.
        bagian("Notifikasi aplikasi lain", 17f)
        info("Aktifkan aplikasi yang notifikasinya ingin dibacakan. Isi yang dibacakan bergantung pada informasi yang ditampilkan oleh aplikasi tersebut. Pastikan akses notifikasi Jam Pintar Pro diizinkan di pengaturan Android.")
        saklar("Bacakan notifikasi email", prefs.bacaNotifEmail) { prefs.bacaNotifEmail = it }
        saklar("Bacakan notifikasi Gojek", prefs.bacaNotifGojek) { prefs.bacaNotifGojek = it }
        saklar("Bacakan notifikasi Grab", prefs.bacaNotifGrab) { prefs.bacaNotifGrab = it }
        saklar("Bacakan notifikasi inDrive", prefs.bacaNotifInDrive) { prefs.bacaNotifInDrive = it }
        saklar("Bacakan notifikasi Maxim", prefs.bacaNotifMaxim) { prefs.bacaNotifMaxim = it }

        bagian("Pilih aplikasi tambahan", 17f)
        info("Pilih sendiri aplikasi terpasang yang notifikasinya ingin dibacakan. Pilihan ini berlaku untuk aplikasi lain di luar SMS, WhatsApp, email, dan aplikasi transportasi yang memiliki pengaturan khusus di atas.")
        val ringkasanAplikasi = info(ringkasanAplikasiKhusus())
        tombol("Pilih aplikasi yang akan dibacakan") { pilihAplikasiNotifikasi(ringkasanAplikasi) }
        tombol("Lihat dan kelola aplikasi terpilih") { kelolaAplikasiTerpilih(ringkasanAplikasi) }

        // Pengulangan pesan terpisah dari pengulangan panggilan.
        bagian("Pengaturan pengulangan notifikasi pesan", 17f)
        info("Atur berapa kali notifikasi pesan dibacakan dan jeda antar pembacaan. Pilih Tidak aktif untuk mematikan pengulangan notifikasi pesan. Pengulangan panggilan masuk diatur terpisah. Pembaruan sistem pada notifikasi yang sama tidak dianggap sebagai pesan baru hanya karena teks notifikasinya berubah.")
        pilihan("Jumlah pembacaan setiap notifikasi", listOf("Tidak aktif", "1 kali", "2 kali", "3 kali", "5 kali", "10 kali"), prefs.notifUlangIdx) { prefs.notifUlangIdx = it }
        isian("Jeda antar pembacaan notifikasi dalam detik", formatDetik(prefs.notifJeda), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL) { v ->
            v.replace(',', '.').toFloatOrNull()?.let { if (it >= 1f) prefs.notifJeda = it.coerceAtMost(60f) }
        }
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
    }

    private data class AplikasiPilihan(val paket: String, val nama: String)

    private fun aplikasiYangDapatDipilih(): List<AplikasiPilihan> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hasil = try { packageManager.queryIntentActivities(intent, 0) } catch (_: Exception) { emptyList<ResolveInfo>() }
        val daftar = hasil.mapNotNull { ri ->
            val ai = ri.activityInfo ?: return@mapNotNull null
            val paket = ai.packageName ?: return@mapNotNull null
            if (paket == packageName || paket == "com.whatsapp" || paket == "com.whatsapp.w4b") return@mapNotNull null
            val p = paket.lowercase()
            // Aplikasi ini sudah memiliki sakelar tersendiri; hindari dua pengaturan yang saling membingungkan.
            if (p.contains("gojek") || p.contains("grab") || p.contains("indrive") || p.contains("taxsee") ||
                p.contains("maxim") || p.contains("email") || p.contains("mail") || p.contains("messaging") ||
                p.contains("mms") || p.contains("sms") || p == "com.google.android.gm" ||
                p == "com.microsoft.office.outlook" || p == "com.samsung.android.email.provider" ||
                p == "com.yahoo.mobile.client.android.mail") return@mapNotNull null
            val nama = try { ri.loadLabel(packageManager).toString().trim() } catch (_: Exception) { paket }
            if (nama.isBlank()) null else AplikasiPilihan(paket, nama)
        }.distinctBy { it.paket }.sortedBy { it.nama.lowercase() }
        return daftar
    }

    private fun ringkasanAplikasiKhusus(): String {
        val jumlah = prefs.aplikasiNotifKhusus.size
        return if (BahasaAplikasi.tampilan(this) == 1) {
            if (jumlah == 0) "No additional apps selected." else "$jumlah additional app(s) selected."
        } else {
            if (jumlah == 0) "Belum ada aplikasi tambahan yang dipilih." else "$jumlah aplikasi tambahan dipilih."
        }
    }

    private fun pilihAplikasiNotifikasi(ringkasan: TextView) {
        val aplikasi = aplikasiYangDapatDipilih()
        if (aplikasi.isEmpty()) {
            android.widget.Toast.makeText(this, ui("Tidak ditemukan aplikasi tambahan yang dapat dipilih."), android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val terpilih = prefs.aplikasiNotifKhusus.toMutableSet()
        val checked = BooleanArray(aplikasi.size) { aplikasi[it].paket in terpilih }
        val labels = aplikasi.map { it.nama }.toTypedArray()
        val dialog = AlertDialog.Builder(this)
            .setTitle(ui("Pilih aplikasi yang notifikasinya dibacakan"))
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(ui("Simpan pilihan")) { _, _ ->
                val paketTerpilih = aplikasi.indices.filter { checked[it] }.map { aplikasi[it].paket }.toSet()
                prefs.aplikasiNotifKhusus = paketTerpilih
                ringkasan.text = ui(ringkasanAplikasiKhusus())
                val pesan = if (BahasaAplikasi.tampilan(this) == 1) {
                    "Saved. ${paketTerpilih.size} additional app(s) selected."
                } else {
                    "Pilihan disimpan. ${paketTerpilih.size} aplikasi tambahan dipilih."
                }
                android.widget.Toast.makeText(this, pesan, android.widget.Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(ui("Batal"), null)
            .setNeutralButton(ui("Hapus semua")) { _, _ ->
                prefs.aplikasiNotifKhusus = emptySet()
                ringkasan.text = ui(ringkasanAplikasiKhusus())
            }
            .create()
        dialog.show()
    }

    /** Daftar aplikasi terpilih memakai kotak centang tersendiri agar nama dan statusnya lebih jelas bagi TalkBack. */
    private fun kelolaAplikasiTerpilih(ringkasan: TextView) {
        val paketTersimpan = prefs.aplikasiNotifKhusus.toMutableSet()
        if (paketTersimpan.isEmpty()) {
            android.widget.Toast.makeText(this, ui("Belum ada aplikasi pilihan untuk dikelola."), android.widget.Toast.LENGTH_LONG).show()
            return
        }

        val daftarTerpasang = aplikasiYangDapatDipilih().associateBy { it.paket }
        val daftar = paketTersimpan.sortedBy { daftarTerpasang[it]?.nama?.lowercase() ?: it.lowercase() }
        val label = daftar.map { paket ->
            daftarTerpasang[paket]?.nama ?: try {
                val ai = packageManager.getApplicationInfo(paket, 0)
                packageManager.getApplicationLabel(ai).toString() + " (" + ui("tidak terpasang") + ")"
            } catch (_: Exception) {
                paket + " (" + ui("tidak terpasang") + ")"
            }
        }

        val skala = resources.displayMetrics.density
        fun dp(nilai: Int) = (nilai * skala + 0.5f).toInt()
        val isi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        val petunjuk = TextView(this).apply {
            text = ui("Daftar aplikasi yang dipilih. Setiap nama memiliki kotak centang. TalkBack akan membacakan nama aplikasi dan apakah kotaknya dicentang.")
            textSize = 16f
            setPadding(0, dp(4), 0, dp(12))
        }
        isi.addView(petunjuk, LinearLayout.LayoutParams(-1, -2))
        val hitung = TextView(this).apply {
            textSize = 15f
            setPadding(0, 0, 0, dp(8))
        }
        isi.addView(hitung, LinearLayout.LayoutParams(-1, -2))

        val centang = daftar.mapIndexed { indeks, paket ->
            CheckBox(this).apply {
                text = label[indeks]
                isChecked = true
                textSize = 16f
                minHeight = dp(52)
                // Jangan menimpa label bawaan CheckBox dengan deskripsi gabungan.
                // TalkBack akan membaca nama aplikasi yang tampil, lalu status dicentang/tidak dicentang.
                contentDescription = null
                setPadding(0, dp(6), 0, dp(6))
                setOnCheckedChangeListener { _, _ ->
                    val jumlahDipilih = centangDipilih(isi)
                    hitung.text = if (BahasaAplikasi.tampilan(this@PemanggilActivity) == 1) {
                        "$jumlahDipilih of ${daftar.size} apps selected."
                    } else {
                        "$jumlahDipilih dari ${daftar.size} aplikasi dipilih."
                    }
                    hitung.announceForAccessibility(hitung.text)
                }
            }.also { kotak -> isi.addView(kotak, LinearLayout.LayoutParams(-1, -2)) }
        }
        hitung.text = if (BahasaAplikasi.tampilan(this) == 1) {
            "${centang.count { it.isChecked }} of ${daftar.size} apps selected."
        } else {
            "${centang.count { it.isChecked }} dari ${daftar.size} aplikasi dipilih."
        }
        val gulir = ScrollView(this).apply {
            isFillViewport = true
            addView(isi, ScrollView.LayoutParams(-1, -2))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(ui("Aplikasi yang dipilih untuk dibacakan"))
            .setView(gulir)
            .setPositiveButton(ui("Simpan perubahan"), null)
            .setNegativeButton(ui("Batal"), null)
            .setNeutralButton(ui("Hapus semua"), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val dipertahankan = daftar.indices.filter { centang[it].isChecked }.map { daftar[it] }.toSet()
                prefs.aplikasiNotifKhusus = dipertahankan
                ringkasan.text = ui(ringkasanAplikasiKhusus())
                val pesan = if (BahasaAplikasi.tampilan(this) == 1) {
                    "Changes saved. ${dipertahankan.size} app(s) remain selected."
                } else {
                    "Perubahan disimpan. ${dipertahankan.size} aplikasi tetap dipilih."
                }
                android.widget.Toast.makeText(this, pesan, android.widget.Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                prefs.aplikasiNotifKhusus = emptySet()
                ringkasan.text = ui(ringkasanAplikasiKhusus())
                android.widget.Toast.makeText(this, ui("Semua aplikasi pilihan telah dihapus."), android.widget.Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun centangDipilih(isi: LinearLayout): Int {
        var jumlah = 0
        for (i in 0 until isi.childCount) {
            val anak = isi.getChildAt(i)
            if (anak is CheckBox && anak.isChecked) jumlah++
        }
        return jumlah
    }

    private fun pasanganPesan(
        judul: String,
        sebelum: String,
        sesudah: String,
        simpanSebelum: (String) -> Unit,
        simpanSesudah: (String) -> Unit,
        contohTambahan: String = ""
    ) {
        bagian(judul, 14f)
        info("Tuliskan kalimat yang ingin diucapkan sebelum atau sesudah nama pengirim atau pemanggil. Kedua kolom boleh dikosongkan. Jika kedua kolom kosong, aplikasi akan menggunakan kalimat pemberitahuan standar.")
        val awal = isian("Kalimat sebelum nama", sebelum, InputType.TYPE_CLASS_TEXT) { simpanSebelum(it) }
        val akhir = isian("Kalimat sesudah nama", sesudah, InputType.TYPE_CLASS_TEXT) { simpanSesudah(it) }
        tombol("Uji susunan pesan untuk " + judul) {
            simpanSebelum(awal.text?.toString().orEmpty())
            simpanSesudah(akhir.text?.toString().orEmpty())
            val sebelumUji = awal.text?.toString().orEmpty().trim()
            val sesudahUji = akhir.text?.toString().orEmpty().trim()
            val templateStandar = templateStandarPesan(judul)
            val contoh = if (templateStandar != null && sebelumUji.isBlank() && sesudahUji.isBlank()) {
                // Kolom kosong berarti gunakan kalimat standar sesuai jenis pesan dan bahasa pengucapan.
                templateStandar
                    .replace("{nama}", "Ali Bima")
                    .replace("{grup}", namaContohGrup())
                    .replace("{pesan}", pesanContoh())
                    .replace("{jenis}", jenisContohPesan(judul))
                    .replace(Regex("\\s{2,}"), " ")
                    .trim()
            } else {
                val isGrup = judul.contains("grup", ignoreCase = true)
                val isPesanSuara = judul.contains("pesan suara", ignoreCase = true)
                listOf(
                    sebelumUji,
                    "Ali Bima",
                    sesudahUji,
                    if (isGrup) keteranganGrupContoh() else "",
                    if (isPesanSuara) "" else if (contohTambahan.isNotBlank()) pesanContoh() else ""
                ).filter { it.isNotBlank() }.joinToString(" ")
            }
            tesSuara("pem", contoh)
        }
    }

    /** Template uji pesan memakai kalimat standar yang sama dengan layanan notifikasi. */
    private fun templateStandarPesan(judul: String): String? = when {
        judul.contains("SMS", true) -> prefs.kalPesanSeluler
        judul.contains("pesan suara", true) && judul.contains("WhatsApp Messenger", true) && judul.contains("grup", true) -> prefs.kalSuaraWaGrup
        judul.contains("pesan suara", true) && judul.contains("WhatsApp Messenger", true) -> prefs.kalSuaraWaPribadi
        judul.contains("pesan suara", true) && judul.contains("WhatsApp Business", true) && judul.contains("grup", true) -> prefs.kalSuaraWbGrup
        judul.contains("pesan suara", true) && judul.contains("WhatsApp Business", true) -> prefs.kalSuaraWbPribadi
        judul.contains("WhatsApp Business", true) && judul.contains("grup", true) -> prefs.kalChatWbGrup
        judul.contains("WhatsApp Business", true) -> prefs.kalChatWbPribadi
        judul.contains("WhatsApp Messenger", true) && judul.contains("grup", true) -> prefs.kalChatWaGrup
        judul.contains("WhatsApp Messenger", true) -> prefs.kalChatWaPribadi
        else -> null
    }

    private fun namaContohGrup(): String = when (prefs.jamBahasaIdx) {
        1 -> "Family"
        2 -> "العائلة"
        3 -> "Kulawarga"
        4 -> "Kulawarga"
        else -> "Keluarga"
    }

    private fun pesanContoh(): String = when (prefs.jamBahasaIdx) {
        1 -> "This is a sample message."
        2 -> "هذه رسالة تجريبية"
        3 -> "Iki conto pesen."
        4 -> "Ieu conto pesen."
        else -> "Ini contoh isi pesan."
    }

    private fun jenisContohPesan(judul: String): String = when {
        judul.contains("SMS", true) -> when (prefs.jamBahasaIdx) { 1 -> "text message"; 2 -> "رسالة نصية"; 3 -> "pesen teks"; 4 -> "pesen téks"; else -> "pesan teks" }
        judul.contains("pesan suara", true) -> when (prefs.jamBahasaIdx) { 1 -> "voice message"; 2 -> "رسالة صوتية"; 3 -> "pesen swara"; 4 -> "pesen sora"; else -> "pesan suara" }
        else -> when (prefs.jamBahasaIdx) { 1 -> "message"; 2 -> "رسالة"; 3 -> "pesen"; 4 -> "pesen"; else -> "pesan" }
    }

    private fun keteranganGrupContoh(): String = when (prefs.jamBahasaIdx) {
        1 -> "in the group ${namaContohGrup()}"
        2 -> "في مجموعة ${namaContohGrup()}"
        3 -> "ing grup ${namaContohGrup()}"
        4 -> "dina grup ${namaContohGrup()}"
        else -> "di grup ${namaContohGrup()}"
    }

    private fun grupMelodi() {
        judulGrup("Melodi sebelum dan sesudah pengumuman")
        // ----- Melodi sebelum/sesudah pengumuman -----
        bagian(getString(R.string.bagian_melodi))
        info(getString(R.string.info_melodi))
        saklar(getString(R.string.sw_melodi_awal), prefs.melodiAwalOn) { prefs.melodiAwalOn = it }
        isian(getString(R.string.jeda_melodi_awal), prefs.jedaMelodiAwal.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAwal = v }
        }
        saklar(getString(R.string.sw_melodi_akhir), prefs.melodiAkhirOn) { prefs.melodiAkhirOn = it }
        isian(getString(R.string.jeda_melodi_akhir), prefs.jedaMelodiAkhir.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAkhir = v }
        }
        pilihan(getString(R.string.melodi_awal_pilih), larik(R.array.jam_melodi), prefs.melodiAwalIdx) {
            prefs.melodiAwalIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_awal)) { Melodi.putar(this, prefs.melodiAwalIdx, prefs.suara("pem").audioAttributes()) }
        pilihan(getString(R.string.melodi_akhir_pilih), larik(R.array.jam_melodi), prefs.melodiAkhirIdx) {
            prefs.melodiAkhirIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_akhir)) { Melodi.putar(this, prefs.melodiAkhirIdx, prefs.suara("pem").audioAttributes()) }
        tombol("Tes nada singkat") { Melodi.bunyikan(this, 180) }

    }

    private fun grupSuara() {
        judulGrup("Suara pengumuman")
        // ----- Suara -----
        // Tombol tes tiap kalimat diletakkan langsung di bawah kolom kalimat terkait.
        blokSuara("pem") {
            CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::teksAkses.isInitialized) teksAkses.text = getString(
            if (aksesNotifikasiAktif()) R.string.akses_notif_aktif else R.string.akses_notif_mati
        )
        if (::teksTelepon.isInitialized) teksTelepon.text = getString(
            if (izinTelepon()) R.string.izin_telepon_aktif else R.string.izin_telepon_mati
        )
        teksAksesPesan?.let { perbaruiStatusAkses(it) }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, hasil: IntArray) {
        super.onRequestPermissionsResult(code, perms, hasil)
        if (code == 2 && izinTelepon()) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, CallerListener::class.java))
            } catch (e: Exception) { }
        }
        onResume()
    }

    private fun izinTelepon() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    /** Status akses notifikasi ditampilkan sebagai teks visual berkontras tinggi dan tetap dibaca pembaca layar. */
    private fun statusAksesNotifikasi(): TextView {
        val tv = info("")
        tv.textSize = 16f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(dp(14), dp(12), dp(14), dp(12))
        tv.contentDescription = ""
        perbaruiStatusAkses(tv)
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), if (aksesNotifikasiAktif()) Color.rgb(30, 120, 60) else Color.rgb(170, 40, 40))
            setColor(if (aksesNotifikasiAktif()) Color.rgb(225, 245, 230) else Color.rgb(255, 232, 232))
        }
        tv.setTextColor(if (aksesNotifikasiAktif()) Color.rgb(20, 90, 45) else Color.rgb(130, 25, 25))
        return tv
    }

    private fun perbaruiStatusAkses(tv: TextView) {
        val aktif = aksesNotifikasiAktif()
        tv.text = getString(if (aktif) R.string.akses_notif_aktif else R.string.akses_notif_mati)
        tv.contentDescription = tv.text
        tv.setTextColor(if (aktif) Color.rgb(20, 90, 45) else Color.rgb(130, 25, 25))
        tv.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), if (aktif) Color.rgb(30, 120, 60) else Color.rgb(170, 40, 40))
            setColor(if (aktif) Color.rgb(225, 245, 230) else Color.rgb(255, 232, 232))
        }
    }

    private fun aksesNotifikasiAktif(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun bukaAksesNotifikasi() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            bukaInfoApp()
        }
    }

    private fun formatDetik(v: Float) = if (v % 1f == 0f) v.toInt().toString() else v.toString()
}
