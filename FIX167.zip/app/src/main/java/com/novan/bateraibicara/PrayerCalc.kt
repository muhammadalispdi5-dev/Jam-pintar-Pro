package com.novan.bateraibicara

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.*

/** Perhitungan astronomi lokal; tidak memerlukan koneksi internet. */
object PrayerCalc {
    data class Times(val imsak: Double, val fajr: Double, val sunrise: Double, val dhuha: Double,
                     val dhuhr: Double, val asr: Double, val maghrib: Double, val isha: Double)

    // urutan: Subuh, Terbit, Dzuhur, Ashar, Maghrib, Isya
    private data class Method(val fajr: Double, val isha: Double, val ishaMinutes: Double = 0.0)
    private val methods = listOf(
        Method(20.0, 18.0),                 // Kemenag RI
        Method(18.0, 17.0),                 // Muslim World League
        Method(15.0, 15.0),                 // ISNA
        Method(19.5, 17.5),                 // Egypt
        Method(18.0, 18.0),                 // Karachi
        Method(20.0, 18.0),                 // Singapore
        Method(18.5, 0.0, 90.0)             // Umm Al-Qura
    )
    val methodNames = listOf("Kemenag RI (Subuh 20°, Isya 18°)", "Muslim World League (18°/17°)",
        "ISNA (15°/15°)", "Mesir (19,5°/17,5°)", "Karachi (18°/18°)",
        "Singapura (20°/18°)", "Umm Al-Qura (Isya 90 menit setelah Maghrib)")

    fun calculate(date: LocalDate, lat: Double, lon: Double, zone: ZoneId, methodIndex: Int,
                  asrFactor: Int, adjustments: IntArray = IntArray(6)): Times {
        val method = methods[methodIndex.coerceIn(methods.indices)]
        val day = date.dayOfYear.toDouble()
        val gamma = 2.0 * Math.PI / 365.0 * (day - 1.0)
        val eq = 229.18 * (0.000075 + 0.001868*cos(gamma) - 0.032077*sin(gamma) -
            0.014615*cos(2*gamma) - 0.040849*sin(2*gamma))
        val dec = 0.006918 - 0.399912*cos(gamma) + 0.070257*sin(gamma) -
            0.006758*cos(2*gamma) + 0.000907*sin(2*gamma) -
            0.002697*cos(3*gamma) + 0.00148*sin(3*gamma)
        val offset = date.atStartOfDay(zone).offset.totalSeconds / 3600.0
        val noon = 12.0 + offset - lon / 15.0 - eq / 60.0
        fun hourAngle(altitudeDeg: Double): Double {
            val a = Math.toRadians(altitudeDeg)
            val phi = Math.toRadians(lat)
            val cosH = ((sin(a) - sin(phi)*sin(dec)) / (cos(phi)*cos(dec))).coerceIn(-1.0, 1.0)
            return Math.toDegrees(acos(cosH)) / 15.0
        }
        val sunrise = noon - hourAngle(-0.833)
        val sunset = noon + hourAngle(-0.833)
        val fajr = noon - hourAngle(-method.fajr)
        val asrAltitude = Math.toDegrees(atan(1.0 / (asrFactor.coerceIn(1, 2) + tan(abs(Math.toRadians(lat) - dec)))))
        val asr = noon + hourAngle(asrAltitude)
        val isha = if (method.ishaMinutes > 0) sunset + method.ishaMinutes / 60.0 else noon + hourAngle(-method.isha)
        val adj = DoubleArray(8) { adjustments.getOrElse(it) { 0 } / 60.0 }
        val fajrAdj = fajr + adj[1]
        val sunriseAdj = sunrise + adj[2]
        return Times(fajrAdj - 10.0/60.0 + adj[0], fajrAdj, sunriseAdj,
            sunrise + 20.0/60.0 + adj[3], noon + adj[4], asr + adj[5], sunset + adj[6], isha + adj[7])
    }

    /** Perkiraan Tahajud pada dua pertiga malam, dihitung dari Isya hari sebelumnya hingga Subuh hari ini. */
    fun tahajud(date: LocalDate, lat: Double, lon: Double, zone: ZoneId, methodIndex: Int,
                asrFactor: Int, adjustments: IntArray = IntArray(8), offsetMinutes: Int = 0): Double {
        val prev = calculate(date.minusDays(1), lat, lon, zone, methodIndex, asrFactor, adjustments).isha
        val fajr = calculate(date, lat, lon, zone, methodIndex, asrFactor, adjustments).fajr
        val fajrAfterMidnight = if (fajr <= prev) fajr + 24.0 else fajr
        val estimated = prev + (fajrAfterMidnight - prev) * (2.0 / 3.0)
        return (estimated + offsetMinutes.coerceIn(-180, 180) / 60.0 + 24.0) % 24.0
    }

    fun format(hours: Double, use24: Boolean = true): String {
        var total = ((hours * 60.0).roundToInt() % (24 * 60) + 24 * 60) % (24 * 60)
        var h = total / 60; val m = total % 60
        val suffix = if (total / 60 >= 12) " PM" else " AM"
        if (!use24) h = (h % 12).let { if (it == 0) 12 else it }
        return "%02d:%02d".format(h, m) + if (use24) "" else suffix
    }

    fun minutes(hours: Double): Int = ((hours * 60.0).roundToInt() % (24 * 60) + 24 * 60) % (24 * 60)
    fun qiblaBearing(lat: Double, lon: Double): Double {
        val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225)
        val dl = Math.toRadians(39.8262 - lon)
        val y = sin(dl); val x = cos(p1)*tan(p2) - sin(p1)*cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

}
