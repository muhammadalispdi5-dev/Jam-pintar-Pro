package com.novan.bateraibicara

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.graphics.Path
import android.graphics.Rect
import android.accessibilityservice.GestureDescription

/**
 * Mengoperasikan kontrol panggilan WhatsApp hanya untuk permintaan yang baru saja
 * dikonfirmasi pengguna dengan ucapan "telepon suara" atau "telepon video".
 * Tidak membaca isi chat dan tidak mengirim pesan.
 *
 * FIX138: layanan yang sama juga menekan sakelar Wi-Fi, Bluetooth, lokasi, hotspot, data seluler,
 * mode pesawat, atau NFC di layar Pengaturan Android, hanya untuk
 * permintaan yang baru saja diucapkan pengguna ("hidupkan/matikan ..."). Android tidak mengizinkan aplikasi biasa mengubahnya
 * secara langsung, sehingga sakelar di layar pengaturan resmi yang ditekan. Satu layanan, satu izin aksesibilitas.
 */
class PanggilanWhatsAppAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var perangkatTerjadwal = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (tanganiKontrolPerangkat(event)) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_PENDING, false)) return
        val dibuat = prefs.getLong(KEY_CREATED, 0L)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > 45_000L) {
            prefs.edit().clear().apply(); return
        }
        val paket = prefs.getString(KEY_PACKAGE, "") ?: ""
        if (event.packageName?.toString() != paket) return
        val root = rootInActiveWindow ?: return
        val jenis = prefs.getString(KEY_TYPE, "voice") ?: "voice"
        val target = if (jenis == "video") VIDEO_LABELS else VOICE_LABELS
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        kumpulkan(root, nodes, 0)

        // Utamakan kontrol yang menyebut jenis panggilan secara spesifik. Bila WhatsApp
        // menampilkan menu konfirmasi, item spesifik akan ditemukan pada event berikutnya.
        val stage = prefs.getInt(KEY_STAGE, 0)
        if (stage == 2) {
            // Hanya tekan tombol konfirmasi bila dialog benar-benar menyebut jenis panggilan
            // yang baru saja dipilih pengguna. Jangan menekan tombol umum di layar chat.
            val teksLayar = nodes.joinToString(" ") { label(it) }
            val judulKonfirmasi = if (jenis == "video")
                listOf("start video call", "mulai panggilan video", "mulai panggilan vidio", "memulai panggilan video").any { teksLayar.contains(it) }
            else listOf("start voice call", "mulai panggilan suara", "memulai panggilan suara").any { teksLayar.contains(it) }
            if (judulKonfirmasi) {
                val tombol = nodes.firstOrNull { node ->
                    val l = label(node)
                    node.isEnabled && (l == "call" || l == "panggil" || l == "start" || l == "mulai") && punyaIndukKlik(node)
                }
                if (tombol != null && klik(tombol)) prefs.edit().putBoolean(KEY_PENDING, false).apply()
            }
            return
        }

        val spesifik = nodes.firstOrNull { node ->
            val l = label(node)
            target.any { l.contains(it) } && node.isEnabled && punyaIndukKlik(node)
        }
        if (spesifik != null && klik(spesifik)) {
            prefs.edit().putInt(KEY_STAGE, 2).apply()
            return
        }

        // Beberapa versi WhatsApp hanya menampilkan tombol umum "Call" yang membuka
        // pilihan suara/video. Klik tombol umum satu kali, lalu tunggu item spesifik.
        if (stage == 0) {
            val umum = nodes.firstOrNull { node ->
                val label = label(node)
                node.isEnabled && (label == "call" || label == "panggilan" || label == "telepon" || label == "voice/video call")
            }
            if (umum != null && klik(umum)) {
                prefs.edit().putInt(KEY_STAGE, 1).apply()
                return
            }
        }
    }

    // ===== FIX138: kontrol sakelar perangkat melalui antarmuka sistem =====

    private fun paketPengaturan(paket: String): Boolean {
        val p = paket.lowercase()
        // Android AOSP, Samsung, Xiaomi, OPPO/realme, vivo, dan panel System UI.
        return p == "com.android.settings" || p == "com.android.systemui" ||
            p.contains("settings") || p.endsWith(".setting") || p.contains("wireless") ||
            p.contains("systemui") || p.contains("connectivity")
    }

    /** true bila ada permintaan kontrol perangkat yang masih berlaku (logika WhatsApp tidak dijalankan pada event ini). */
    private fun tanganiKontrolPerangkat(event: AccessibilityEvent): Boolean {
        val p = getSharedPreferences(PREFS_PERANGKAT, MODE_PRIVATE)
        if (!p.getBoolean(KEY_PERANGKAT_PENDING, false)) return false
        val dibuat = p.getLong(KEY_PERANGKAT_DIBUAT, 0L)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > BATAS_PERANGKAT_MS) { p.edit().clear().apply(); return false }
        if (paketPengaturan(event.packageName?.toString().orEmpty())) jadwalkanPerangkat(350L)
        return true
    }

    private fun jadwalkanPerangkat(tunda: Long) {
        if (perangkatTerjadwal) return
        perangkatTerjadwal = true
        handler.postDelayed({ perangkatTerjadwal = false; cobaKontrolPerangkat() }, tunda)
    }

    private fun cobaKontrolPerangkat() {
        val p = getSharedPreferences(PREFS_PERANGKAT, MODE_PRIVATE)
        if (!p.getBoolean(KEY_PERANGKAT_PENDING, false)) return
        val dibuat = p.getLong(KEY_PERANGKAT_DIBUAT, 0L)
        val jenis = p.getString(KEY_PERANGKAT_JENIS, "") ?: ""
        val mau = p.getBoolean(KEY_PERANGKAT_AKTIF, true)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > BATAS_PERANGKAT_MS) {
            p.edit().clear().apply()
            umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
            return
        }
        val root = rootInActiveWindow
        if (root == null || !paketPengaturan(root.packageName?.toString().orEmpty())) { jadwalkanPerangkat(700L); return }
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        kumpulkan(root, nodes, 0)
        val sakelar = PemilihSakelar.pilih(nodes.map { node -> infoSakelar(node) }, jenis)
        val tahap = p.getInt(KEY_PERANGKAT_TAHAP, 0)
        if (sakelar == null) {
            // FIX137: hotspot di banyak ponsel dua langkah: halaman tethering hanya berisi baris "Wi-Fi hotspot" yang membuka sakelarnya.
            if (jenis == "hotspot" && tahap == 0) {
                val daftarBaris = nodes.map { node -> infoBaris(node) }
                val baris = PemilihSakelar.pilihBarisHotspot(daftarBaris)
                if (baris != null && klik(nodes[baris])) {
                    p.edit().putInt(KEY_PERANGKAT_TAHAP, 1).apply()
                    jadwalkanPerangkat(1000L)
                    return
                }
            }
            jadwalkanPerangkat(700L); return
        }
        val node = nodes[sakelar]
        val sekarang = statusSakelar(node)
        val percobaan = p.getInt(KEY_PERANGKAT_PERCOBAAN, 0)
        if (sekarang != null && sekarang == mau) {
            p.edit().clear().apply()
            umumkan(if (percobaan == 0) R.string.perintah_perangkat_sudah else R.string.perintah_perangkat_berhasil, namaPerangkat(jenis), statusPerangkat(mau, percobaan == 0))
            // Tutup layar Pengaturan; hotspot dua langkah perlu dua kali kembali.
            val kali = if (tahap >= 1) 2 else 1
            for (k in 0 until kali) handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 900L + k * 700L)
            return
        }

        val menungguVerifikasi = p.getBoolean(KEY_PERANGKAT_MENUNGGU_VERIFIKASI, false)
        val gesturSudahDicoba = p.getBoolean(KEY_PERANGKAT_GESTUR_DICOBA, false)

        // Tahap pertama memakai aksi aksesibilitas native. Jika OEM menerima aksi
        // tersebut tetapi tampilan sakelar tidak berubah, coba ketukan layar pada
        // koordinat sakelar yang sama satu kali. Jangan mengulang toggle tanpa batas.
        if (menungguVerifikasi) {
            if (!gesturSudahDicoba) {
                if (ketukDenganGestur(node)) {
                    p.edit()
                        .putBoolean(KEY_PERANGKAT_GESTUR_DICOBA, true)
                        .putInt(KEY_PERANGKAT_PERCOBAAN, percobaan + 1)
                        .putInt(KEY_PERANGKAT_PEMERIKSAAN, 0)
                        .apply()
                    jadwalkanPerangkat(1400L)
                } else {
                    p.edit().clear().apply()
                    umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
                }
            } else {
                p.edit().clear().apply()
                umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
            }
            return
        }

        if (sekarang == null) {
            // Status tidak diketahui tidak boleh dianggap OFF. Namun, bila node
            // yang cocok benar-benar merupakan sakelar perangkat, lakukan satu
            // aksi native dan verifikasi ulang sebelum memutuskan berhasil.
            if (klik(node)) {
                p.edit()
                    .putInt(KEY_PERANGKAT_PERCOBAAN, percobaan + 1)
                    .putBoolean(KEY_PERANGKAT_MENUNGGU_VERIFIKASI, true)
                    .putInt(KEY_PERANGKAT_PEMERIKSAAN, 0)
                    .apply()
                jadwalkanPerangkat(1200L)
            } else if (ketukDenganGestur(node)) {
                p.edit()
                    .putInt(KEY_PERANGKAT_PERCOBAAN, percobaan + 1)
                    .putBoolean(KEY_PERANGKAT_GESTUR_DICOBA, true)
                    .putBoolean(KEY_PERANGKAT_MENUNGGU_VERIFIKASI, true)
                    .putInt(KEY_PERANGKAT_PEMERIKSAAN, 0)
                    .apply()
                jadwalkanPerangkat(1400L)
            } else {
                p.edit().clear().apply()
                umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
            }
            return
        }

        if (percobaan >= 2) {
            p.edit().clear().apply()
            umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
            return
        }
        if (klik(node)) {
            p.edit()
                .putInt(KEY_PERANGKAT_PERCOBAAN, percobaan + 1)
                .putBoolean(KEY_PERANGKAT_MENUNGGU_VERIFIKASI, true)
                .putInt(KEY_PERANGKAT_PEMERIKSAAN, 0)
                .apply()
            jadwalkanPerangkat(1200L)
        } else if (ketukDenganGestur(node)) {
            p.edit()
                .putInt(KEY_PERANGKAT_PERCOBAAN, percobaan + 1)
                .putBoolean(KEY_PERANGKAT_GESTUR_DICOBA, true)
                .putBoolean(KEY_PERANGKAT_MENUNGGU_VERIFIKASI, true)
                .putInt(KEY_PERANGKAT_PEMERIKSAAN, 0)
                .apply()
            jadwalkanPerangkat(1400L)
        } else {
            p.edit().clear().apply()
            umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
        }
    }

    /**
     * null berarti status benar-benar tidak diekspos oleh Android/OEM.
     * Jangan menyamakan status tak terbaca dengan OFF karena itu bisa memberi laporan palsu.
     */
    private fun nodeAdalahSakelar(node: AccessibilityNodeInfo): Boolean {
        val nama = node.className?.toString().orEmpty()
        val id = node.viewIdResourceName.orEmpty().lowercase()
        return node.isCheckable || nama.contains("Switch", true) || nama.contains("ToggleButton", true) ||
            nama.contains("CompoundButton", true) || id.contains("switch_widget") || id.contains("switchbar") || id.contains("toggle")
    }

    /** Hindari mengambil label dari baris tetangga yang berisi sakelar perangkat lain. */
    private fun subpohonMemuatSakelar(node: AccessibilityNodeInfo, depth: Int = 0): Boolean {
        if (nodeAdalahSakelar(node)) return true
        if (depth >= 4) return false
        for (i in 0 until node.childCount) {
            val anak = node.getChild(i) ?: continue
            if (subpohonMemuatSakelar(anak, depth + 1)) return true
        }
        return false
    }

    /** Gabungkan label switch dan label teks satu baris, tanpa menggabungkan baris kontrol tetangga. */
    private fun konteksSakelar(node: AccessibilityNodeInfo): String {
        val hasil = StringBuilder()
        fun tambah(teks: String) { if (teks.isNotBlank()) hasil.append(' ').append(teks) }
        tambah(label(node))
        if (Build.VERSION.SDK_INT >= 30) {
            try { tambah(node.stateDescription?.toString().orEmpty()) } catch (_: Exception) { }
        }
        tambah(node.viewIdResourceName.orEmpty())
        var cabang: AccessibilityNodeInfo? = node
        var tingkat = 0
        while (tingkat < 3) {
            val saatIni = cabang ?: break
            val induk = saatIni.parent ?: break
            val namaInduk = induk.className?.toString().orEmpty()
            // Jangan membaca teks agregat dari daftar/scroll container karena dapat memuat semua sakelar.
            if (!namaInduk.contains("RecyclerView") && !namaInduk.contains("ListView") && !namaInduk.contains("ScrollView")) {
                tambah(label(induk))
            }
            for (i in 0 until induk.childCount) {
                val saudara = induk.getChild(i) ?: continue
                if (saudara == saatIni || subpohonMemuatSakelar(saudara)) continue
                tambah(label(saudara))
                for (j in 0 until saudara.childCount) {
                    val teks = saudara.getChild(j) ?: continue
                    if (!subpohonMemuatSakelar(teks)) tambah(label(teks))
                }
            }
            cabang = induk
            tingkat++
        }
        return hasil.toString().lowercase().replace(Regex("\\s+"), " ").trim()
    }

    /** null berarti status benar-benar tidak diekspos oleh Android/OEM. */
    private fun statusSakelar(node: AccessibilityNodeInfo): Boolean? {
        if (node.isCheckable) return node.isChecked
        val teks = konteksSakelar(node)
        if (Regex("\\b(on|enabled|aktif|nyala|urip|hurung|turned on)\\b").containsMatchIn(teks) ||
            teks.contains("dihidupkan") || teks.contains("قيد التشغيل") || teks.contains("مفعّل") || teks.contains("مفعل")) return true
        if (Regex("\\b(off|disabled|nonaktif|mati|pareum|turned off)\\b").containsMatchIn(teks) ||
            teks.contains("dimatikan") || teks.contains("متوقف") || teks.contains("معطل") || teks.contains("غير مفعل")) return false
        return null
    }

    private fun infoSakelar(node: AccessibilityNodeInfo): PemilihSakelar.Info {
        val id = node.viewIdResourceName.orEmpty().lowercase()
        val state = if (Build.VERSION.SDK_INT >= 30) try { node.stateDescription?.toString().orEmpty() } catch (_: Exception) { "" } else ""
        val kelasSakelar = nodeAdalahSakelar(node)
        // Panel System UI/OEM kadang menyajikan sakelar sebagai tombol biasa dengan status eksplisit.
        val statusPadaTombol = state.isNotBlank() && punyaIndukKlik(node)
        val bisaDicentang = kelasSakelar || statusPadaTombol
        if (!bisaDicentang) return PemilihSakelar.Info(false, false, false, "", "")
        return PemilihSakelar.Info(bisaDicentang, node.isVisibleToUser, node.isEnabled, konteksSakelar(node), id)
    }

    private fun infoBaris(node: AccessibilityNodeInfo): PemilihSakelar.InfoBaris {
        val nama = node.className?.toString().orEmpty()
        val id = node.viewIdResourceName.orEmpty().lowercase()
        val bisaDicentang = node.isCheckable || nama.contains("Switch", true) || nama.contains("ToggleButton", true) ||
            nama.contains("CompoundButton", true) || id.contains("switch_widget") || id.contains("switchbar") || id.contains("toggle")
        val teks = label(node)
        if (teks.isBlank() || bisaDicentang) return PemilihSakelar.InfoBaris(teks, false, false, bisaDicentang)
        // Baris harus berada di dalam daftar; judul halaman (di luar daftar) tidak boleh diketuk.
        var dalamDaftar = false
        var induk = node.parent
        var tingkat = 0
        while (induk != null && tingkat++ < 10) {
            val n = induk.className?.toString().orEmpty()
            if (n.contains("RecyclerView") || n.contains("ListView") || n.contains("ScrollView")) { dalamDaftar = true; break }
            induk = induk.parent
        }
        return PemilihSakelar.InfoBaris(teks, punyaIndukKlik(node), dalamDaftar, false)
    }

    private fun namaPerangkat(jenis: String): String =
        BahasaAplikasi.bungkus(this).getString(
            when (jenis) {
                "bluetooth" -> R.string.perintah_perangkat_bluetooth
                "lokasi" -> R.string.perintah_perangkat_lokasi
                "hotspot" -> R.string.perintah_perangkat_hotspot
                "data_seluler" -> R.string.perintah_perangkat_data
                "pesawat" -> R.string.perintah_perangkat_pesawat
                "nfc" -> R.string.perintah_perangkat_nfc
                else -> R.string.perintah_perangkat_wifi
            }
        )

    private fun statusPerangkat(aktif: Boolean, sudahDariAwal: Boolean): String {
        val c = BahasaAplikasi.bungkus(this)
        return c.getString(
            if (sudahDariAwal) (if (aktif) R.string.perintah_perangkat_status_aktif else R.string.perintah_perangkat_status_mati)
            else (if (aktif) R.string.perintah_perangkat_status_diaktifkan else R.string.perintah_perangkat_status_dimatikan)
        )
    }

    private fun umumkan(res: Int, vararg arg: Any) {
        val teks = try { BahasaAplikasi.bungkus(this).getString(res, *arg) } catch (_: Exception) { return }
        try { Toast.makeText(applicationContext, teks, Toast.LENGTH_LONG).show() } catch (_: Exception) { }
        try {
            val suara = Pembicara(applicationContext, Prefs(applicationContext).suara("jam"))
            suara.bisaDibungkam = true
            suara.ucapkan(teks, true) { try { suara.matikan() } catch (_: Exception) { } }
        } catch (_: Exception) { }
    }

    private fun label(node: AccessibilityNodeInfo): String =
        ((node.text?.toString().orEmpty()) + " " + (node.contentDescription?.toString().orEmpty()))
            .lowercase().replace(Regex("\\s+"), " ").trim()

    private fun kumpulkan(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 24 || out.size > 1500) return
        out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { kumpulkan(it, out, depth + 1) }
    }

    private fun punyaIndukKlik(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 6) {
            if (current.isClickable && current.isEnabled) return true
            current = current.parent
        }
        return false
    }

    private fun klik(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 6) {
            if (current.isEnabled) {
                val punyaAksiKlik = try { current.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK } } catch (_: Exception) { false }
                if ((current.isClickable || punyaAksiKlik) && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            current = current.parent
        }
        return false
    }

    /** Ketukan layar sebagai jalur cadangan untuk Switch OEM yang ACTION_CLICK-nya tidak bereaksi. */
    private fun ketukDenganGestur(node: AccessibilityNodeInfo): Boolean {
        val kandidat = mutableListOf<AccessibilityNodeInfo>()
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 5) {
            if (current.isVisibleToUser && current.isEnabled) kandidat.add(current)
            current = current.parent
        }
        for (target in kandidat) {
            val bounds = Rect()
            try { target.getBoundsInScreen(bounds) } catch (_: Exception) { continue }
            if (bounds.width() < 8 || bounds.height() < 8) continue
            val x = bounds.centerX().toFloat()
            val y = bounds.centerY().toFloat()
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 90L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            try {
                if (dispatchGesture(gesture, null, null)) return true
            } catch (_: Exception) { }
        }
        return false
    }

    override fun onInterrupt() = Unit

    companion object {
        const val PREFS = "wa_auto_call"
        const val KEY_PENDING = "pending"
        const val KEY_PACKAGE = "package"
        const val KEY_TYPE = "type"
        const val KEY_CREATED = "created"
        const val KEY_STAGE = "stage"
        // FIX138: permintaan kontrol perangkat (ditulis PerintahSuaraActivity, dibaca layanan ini)
        const val PREFS_PERANGKAT = "kontrol_perangkat_auto"
        const val KEY_PERANGKAT_PENDING = "pending"
        const val KEY_PERANGKAT_JENIS = "jenis"
        const val KEY_PERANGKAT_AKTIF = "aktif"
        const val KEY_PERANGKAT_DIBUAT = "dibuat"
        const val KEY_PERANGKAT_PERCOBAAN = "percobaan"
        const val KEY_PERANGKAT_MENUNGGU_VERIFIKASI = "menunggu_verifikasi"
        const val KEY_PERANGKAT_PEMERIKSAAN = "pemeriksaan_status"
        const val KEY_PERANGKAT_GESTUR_DICOBA = "gestur_sudah_dicoba"
        /** 0 = belum membuka halaman hotspot terpisah, 1 = baris hotspot sudah diketuk. */
        const val KEY_PERANGKAT_TAHAP = "tahap"
        const val BATAS_PERANGKAT_MS = 25_000L
        private val VOICE_LABELS = listOf("voice call", "panggilan suara", "telepon suara", "panggilan audio", "audio call", "call by voice")
        private val VIDEO_LABELS = listOf("video call", "panggilan video", "telepon video", "panggilan vidio")
    }
}
