package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/** Pemutar 15 melodi yang dipulihkan dari APK sumber. Indeks 0 berarti mati. */
object Melodi {
    private val handler = Handler(Looper.getMainLooper())
    private val aktif = HashSet<MediaPlayer>()
    private val audio = intArrayOf(
        0, R.raw.melodi_01, R.raw.melodi_02, R.raw.melodi_03, R.raw.melodi_04,
        R.raw.melodi_05, R.raw.melodi_06, R.raw.melodi_07, R.raw.melodi_08,
        R.raw.melodi_09, R.raw.melodi_10, R.raw.melodi_11, R.raw.melodi_12,
        R.raw.melodi_13, R.raw.melodi_14, R.raw.melodi_15, R.raw.melodi_16
    )

    /**
     * Memutar melodi lewat saluran volume pilihan pengguna ([atribut]; null = volume media).
     * Atribut dipasang sebelum sumber data/prepare agar benar-benar dipakai sistem
     * (MediaPlayer.create() langsung prepare sehingga atribut sesudahnya diabaikan).
     */
    fun putar(context: Context, pilihan: Int, atribut: AudioAttributes? = null, volume: Float = 1.0f, selesai: (() -> Unit)? = null) {
        if (pilihan <= 0 || pilihan >= audio.size) {
            selesai?.invoke()
            return
        }
        try {
            val app = context.applicationContext
            val attrs = AudioAttributes.Builder()
                .setUsage(atribut?.usage ?: AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            val player = MediaPlayer()
            synchronized(aktif) { aktif.add(player) }
            try {
                player.setAudioAttributes(attrs)
                val afd = app.resources.openRawResourceFd(audio[pilihan])
                try { player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                player.setOnCompletionListener {
                    synchronized(aktif) { aktif.remove(it) }
                    try { it.release() } catch (_: Exception) { }
                    selesai?.invoke()
                }
                player.setOnErrorListener { mp, _, _ ->
                    synchronized(aktif) { aktif.remove(mp) }
                    try { mp.release() } catch (_: Exception) { }
                    selesai?.invoke()
                    true
                }
                player.setVolume(volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f))
                player.prepare()
                player.start()
            } catch (e: Exception) {
                synchronized(aktif) { aktif.remove(player) }
                try { player.release() } catch (_: Exception) { }
                selesai?.invoke()
            }
        } catch (_: Exception) { selesai?.invoke() }
    }

    /** FIX74: hentikan semua melodi yang sedang berbunyi tanpa memanggil kelanjutan rangkaian pengumumannya. */
    fun hentikanSemua() {
        val salinan = synchronized(aktif) { val x = ArrayList(aktif); aktif.clear(); x }
        for (p in salinan) {
            try { p.setOnCompletionListener(null) } catch (_: Exception) { }
            try { p.setOnErrorListener(null) } catch (_: Exception) { }
            try { p.stop() } catch (_: Exception) { }
            try { p.release() } catch (_: Exception) { }
        }
    }

    /** Nada singkat untuk fitur nama pemanggil. */
    fun bunyikan(context: Context, durasiMs: Int = 180) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
            val d = durasiMs.coerceIn(80, 800)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, d)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) { } }, d.toLong() + 100)
        } catch (_: Exception) { }
    }
}
