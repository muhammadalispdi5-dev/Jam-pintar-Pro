# Perbaikan konsistensi bahasa — Prayer Schedule 1.0.68

Fokus perubahan:
- Memperluas pemetaan terjemahan pada `BahasaAplikasi.kt` untuk label, bantuan, tombol, status, pilihan, pesan toast/dialog, jadwal hari ini, jadwal 30 hari, pembaruan daring/luring, lokasi, pengingat salat, pengingat puasa, suara azan, dan mode Jangan Ganggu.
- Menambahkan padanan nama waktu salat pada teks dinamis agar nama yang digabungkan ke label juga mengikuti bahasa Inggris.
- Menjaga versi aplikasi tetap 1.0.68 dan tidak mengubah ID preferensi atau nilai indeks pilihan yang tersimpan.

Validasi yang dilakukan:
- Semua berkas `strings.xml` di direktori `res/values*` berhasil diparsing sebagai XML.
- Pemeriksaan statis sumber terjemahan dan arsip ZIP dilakukan.

Batasan:
- APK belum dikompilasi oleh Gradle pada lingkungan ini dan belum diuji pada perangkat. Pemeriksaan statis tidak dapat menjamin seluruh teks runtime bebas campuran bahasa; uji GitHub Actions dan pemeriksaan perangkat tetap diperlukan.
