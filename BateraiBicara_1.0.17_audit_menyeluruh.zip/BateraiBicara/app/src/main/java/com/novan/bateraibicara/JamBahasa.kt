package com.novan.bateraibicara

/** Kata bilangan untuk pengumuman jam. */
object JamBahasa {
    private val id = arrayOf("nol", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas")
    private val en = arrayOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven")
    private val ar = arrayOf("صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر")
    fun kata(n: Int, bahasa: Int): String {
        if (bahasa == 0) return JamWaktu.kata(n)
        if (bahasa == 2) return when {
            n in 0..12 -> ar[n]
            n in 13..19 -> ar[n - 10] + " عشر"
            n in 20..59 -> {
                val puluh = arrayOf("", "", "عشرون", "ثلاثون", "أربعون", "خمسون")
                if (n % 10 == 0) puluh[n / 10] else ar[n % 10] + " و" + puluh[n / 10]
            }
            else -> n.toString()
        }
        val a = en
        return when (n) {
            in 0..11 -> a[n]
            12 -> "twelve"; 13 -> "thirteen"; 14 -> "fourteen"; 15 -> "fifteen"; 16 -> "sixteen"
            17 -> "seventeen"; 18 -> "eighteen"; 19 -> "nineteen"
            else -> {
                val tens = arrayOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
                if (n in 20..99) tens[n / 10] + if (n % 10 == 0) "" else "-" + a[n % 10] else n.toString()
            }
        }
    }
}
