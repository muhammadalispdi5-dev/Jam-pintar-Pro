package com.novan.bateraibicara

import android.content.Context
import java.io.File
import java.util.Locale

/**
 * FIX329: pembacaan terjemahan Al-Qur'an dengan suara TTS sesudah tiap ayat (ayat, terjemahan, ayat berikutnya, terjemahan, dan seterusnya).
 * Teks terjemahan diambil dari cache teks Khatam (quran_id.json / quran_en.json) sehingga tidak butuh internet. Saklar disimpan di
 * pengaturan Khatam; suara (mesin, kecepatan, keluaran) memakai profil suara "trj".
 */
object TerjemahTts {
    const val KUNCI = "terjemah_tts_aktif"
    const val PROFIL = "trj"

    fun aktif(c: Context): Boolean = c.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).getBoolean(KUNCI, false)
    fun setAktif(c: Context, v: Boolean) { c.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).edit().putBoolean(KUNCI, v).apply() }

    private var namaBerkas = ""
    private var waktuBerkas = 0L
    private var data: Array<List<String>?> = arrayOfNulls(115)

    private fun muat(c: Context) {
        val nama = if (BahasaAplikasi.tampilan(c) == 1) "quran_en.json" else "quran_id.json"
        val f = File(c.filesDir, nama)
        if (!f.exists()) { data = arrayOfNulls(115); namaBerkas = ""; return }
        if (nama == namaBerkas && f.lastModified() == waktuBerkas) return
        val baru: Array<List<String>?> = arrayOfNulls(115)
        try {
            val surahs = org.json.JSONObject(f.readText(Charsets.UTF_8)).optJSONObject("data")?.optJSONArray("surahs")
            if (surahs != null) for (i in 0 until minOf(114, surahs.length())) {
                val ayahs = surahs.optJSONObject(i)?.optJSONArray("ayahs") ?: continue
                val daftar = ArrayList<String>(ayahs.length())
                for (j in 0 until ayahs.length()) daftar.add(ayahs.optJSONObject(j)?.optString("text").orEmpty())
                baru[i + 1] = daftar
            }
        } catch (_: Exception) { }
        data = baru; namaBerkas = nama; waktuBerkas = f.lastModified()
    }

    /** Dipanggil di thread latar agar pembacaan pertama tidak menunggu penguraian berkas. */
    @Synchronized fun panaskan(c: Context) { muat(c.applicationContext) }

    @Synchronized fun teks(c: Context, surah: Int, ayat: Int): String? {
        if (surah !in 1..114 || ayat < 1) return null
        muat(c.applicationContext)
        return data[surah]?.getOrNull(ayat - 1)?.trim()?.takeIf { it.isNotBlank() }
    }

    fun bahasa(c: Context): Locale = if (BahasaAplikasi.tampilan(c) == 1) Locale.ENGLISH else Locale("id", "ID")
}
