package com.novan.bateraibicara

import java.io.File

/**
 * FIX310: efek gema nyata pada data suara (DSP), meniru cara kerja aplikasi Gema TTS: ucapan dirender ke berkas WAV,
 * gema (pengulangan tertunda) dan ruang (reverb Schroeder/Freeverb: filter sisir paralel + all-pass) dihitung langsung pada sampel PCM,
 * lalu hasilnya diputar biasa. Tidak bergantung pada AudioEffect/EnvironmentalReverb milik HP sehingga terdengar sama di semua HP.
 * Ekor gema ditambahkan ke akhir berkas agar tidak terpotong.
 */
object GemaDsp {
    private class Param(
        val echoMs: Int, val echoFb: Float, val echoMix: Float, val echoRep: Int,
        val rvFb: Float, val rvWet: Float, val preMs: Int, val damp: Float, val tailMs: Int
    )

    private fun param(k: String): Param? = when (k) {
        "kamar" -> Param(0, 0f, 0f, 0, 0.72f, 0.22f, 0, 0.40f, 700)
        "aula" -> Param(0, 0f, 0f, 0, 0.82f, 0.30f, 15, 0.35f, 1600)
        "aula_besar" -> Param(0, 0f, 0f, 0, 0.88f, 0.34f, 25, 0.30f, 2400)
        "echo_lembut" -> Param(180, 0.35f, 0.40f, 4, 0f, 0f, 0, 0f, 1100)
        "echo" -> Param(320, 0.50f, 0.55f, 5, 0f, 0f, 0, 0f, 2200)
        "lembah" -> Param(700, 0.55f, 0.60f, 4, 0.70f, 0.12f, 0, 0.40f, 3200)
        "studio" -> Param(0, 0f, 0f, 0, 0.70f, 0.16f, 8, 0.50f, 900)
        "karaoke" -> Param(120, 0.42f, 0.40f, 4, 0.75f, 0.22f, 0, 0.40f, 1500)
        "panggung" -> Param(90, 0.40f, 0.30f, 3, 0.86f, 0.34f, 20, 0.35f, 2200)
        "gua" -> Param(420, 0.50f, 0.45f, 4, 0.93f, 0.35f, 30, 0.25f, 4000)
        else -> null
    }

    /** Panjang ekor (ms) yang ditambahkan; 0 untuk mode normal. */
    fun ekorMs(k: String): Int = param(k)?.tailMs ?: 0

    private fun le16(d: ByteArray, o: Int) = (d[o].toInt() and 255) or ((d[o + 1].toInt() and 255) shl 8)
    private fun le32(d: ByteArray, o: Int) = le16(d, o) or (le16(d, o + 2) shl 16)

    private val sisir = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491)
    private val semua = intArrayOf(556, 441, 341, 225)

    /**
     * Pemroses gema berurutan (streaming): dapat dipanggil blok demi blok pada audio yang sedang diputar maupun pada berkas utuh.
     * [kanal] = jumlah kanal sampel PCM 16-bit berselang-seling. Status gema (pantulan dan reverb) dipertahankan antar blok.
     */
    class Pemroses(kunci: String, kekuatan: Int, private val laju: Int, private val kanal: Int) {
        private val p: Param = param(kunci) ?: throw IllegalArgumentException("unknown echo mode")
        private val skala = (kekuatan / 60f).coerceIn(0f, 1.67f)
        private val mix = (p.echoMix * skala).coerceAtMost(0.95f)
        private val wet = (p.rvWet * skala).coerceAtMost(0.9f)
        private val d = laju * p.echoMs / 1000
        private val pre = laju * p.preMs / 1000
        private val gainEcho = FloatArray(p.echoRep + 1).also { g -> var v = mix; for (k in 1..p.echoRep) { g[k] = v; v *= p.echoFb } }

        private inner class Saluran {
            val ringEcho = FloatArray(if (p.echoRep > 0 && d > 0) p.echoRep * d + 1 else 1)
            var posEcho = 0
            val ringPre = FloatArray(pre + 1)
            var posPre = 0
            val skl = laju / 44100f
            val bufS = Array(sisir.size) { FloatArray(maxOf(1, (sisir[it] * skl).toInt())) }
            val posS = IntArray(sisir.size)
            val simpanS = FloatArray(sisir.size)
            val bufA = Array(semua.size) { FloatArray(maxOf(1, (semua[it] * skl).toInt())) }
            val posA = IntArray(semua.size)

            fun langkah(x: Float): Float {
                var y = x
                if (p.echoRep > 0 && d > 0) {
                    val n = ringEcho.size
                    for (k in 1..p.echoRep) {
                        var i = posEcho - k * d
                        while (i < 0) i += n
                        y += ringEcho[i] * gainEcho[k]
                    }
                    ringEcho[posEcho] = x
                    if (++posEcho >= n) posEcho = 0
                }
                var keluar = y
                if (p.rvFb > 0f) {
                    val xi: Float
                    if (pre > 0) {
                        ringPre[posPre] = y
                        if (++posPre >= ringPre.size) posPre = 0
                        xi = ringPre[posPre]
                    } else xi = y
                    val masuk = xi * 0.12f
                    var jumlah = 0f
                    for (c in sisir.indices) {
                        val b = bufS[c]; val o = b[posS[c]]
                        simpanS[c] = o * (1f - p.damp) + simpanS[c] * p.damp
                        b[posS[c]] = masuk + simpanS[c] * p.rvFb
                        if (++posS[c] >= b.size) posS[c] = 0
                        jumlah += o
                    }
                    for (a in semua.indices) {
                        val b = bufA[a]; val o = b[posA[a]]
                        val z = jumlah
                        b[posA[a]] = z + o * 0.5f
                        jumlah = o - z
                        if (++posA[a] >= b.size) posA[a] = 0
                    }
                    keluar += jumlah * wet * 1.2f
                }
                // Pembatas lembut agar tidak pecah tanpa mengecilkan seluruh suara.
                val a = Math.abs(keluar)
                if (a > 0.8f) keluar = Math.signum(keluar) * (0.8f + 0.2f * Math.tanh(((a - 0.8f) / 0.2f).toDouble()).toFloat())
                return keluar
            }
        }

        private val saluran = Array(kanal) { Saluran() }

        /** Panjang ekor (jumlah frame) yang perlu diumpankan sebagai senyap setelah audio habis. */
        val ekorFrame: Int get() = (laju.toLong() * p.tailMs / 1000L).toInt()

        /** Proses [panjang] sampel berselang-seling mulai [awal], hasil menimpa [data]. */
        fun proses(data: ShortArray, awal: Int, panjang: Int) {
            var i = awal
            val akhir = awal + panjang
            var c = 0
            while (i < akhir) {
                val x = data[i] / 32768f
                val y = saluran[c].langkah(x)
                data[i] = (y * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
                i++; if (++c >= kanal) c = 0
            }
        }
    }

    /**
     * Terapkan gema [kunci] dengan [kekuatan] (0..100; 60 = bawaan) pada berkas WAV 16-bit hasil render TTS (ditimpa).
     * Mengembalikan false bila format tidak dikenal atau terjadi kesalahan; berkas asli tidak rusak dalam kasus itu.
     */
    fun proses(f: File, kunci: String, kekuatan: Int): Boolean {
        if (kunci == "normal" || kekuatan <= 0) return true
        if (param(kunci) == null) return false
        return try {
            val dt = f.readBytes()
            if (dt.size < 44 || String(dt, 0, 4) != "RIFF" || String(dt, 8, 4) != "WAVE") return false
            var q = 12; var kanal = 0; var laju = 0; var bit = 0; var fmt = 0; var awal = -1; var panjang = 0
            while (q + 8 <= dt.size) {
                val id = String(dt, q, 4); val n = le32(dt, q + 4)
                if (id == "fmt ") { fmt = le16(dt, q + 8); kanal = le16(dt, q + 10); laju = le32(dt, q + 12); bit = le16(dt, q + 22) }
                if (id == "data") { awal = q + 8; panjang = if (n <= 0 || awal + n > dt.size) dt.size - awal else n; break }
                if (n < 0) return false
                q += 8 + n + (n and 1)
            }
            if (awal < 0 || kanal !in 1..2 || laju < 8000 || bit != 16 || (fmt != 1 && fmt != 0xFFFE)) return false
            val jumlah = panjang / 2 / kanal * kanal
            if (jumlah <= 0) return false
            val pm = Pemroses(kunci, kekuatan, laju, kanal)
            val total = jumlah + pm.ekorFrame * kanal
            val s = ShortArray(total)
            for (i in 0 until jumlah) s[i] = le16(dt, awal + i * 2).toShort()
            pm.proses(s, 0, total)
            val ukuran = total * 2
            val b = ByteArray(44 + ukuran)
            fun t32(o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte(); b[o + 2] = (v shr 16).toByte(); b[o + 3] = (v shr 24).toByte() }
            fun t16(o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() }
            "RIFF".toByteArray().copyInto(b, 0); t32(4, 36 + ukuran); "WAVE".toByteArray().copyInto(b, 8)
            "fmt ".toByteArray().copyInto(b, 12); t32(16, 16); t16(20, 1); t16(22, kanal); t32(24, laju)
            t32(28, laju * kanal * 2); t16(32, kanal * 2); t16(34, 16)
            "data".toByteArray().copyInto(b, 36); t32(40, ukuran)
            for (i in 0 until total) { val v = s[i].toInt(); b[44 + i * 2] = v.toByte(); b[45 + i * 2] = (v shr 8).toByte() }
            f.writeBytes(b)
            true
        } catch (_: Throwable) { false }
    }
}
