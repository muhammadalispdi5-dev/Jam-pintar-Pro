package com.novan.bateraibicara

import android.content.Context
import android.icu.util.IslamicCalendar
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.YearMonth
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * FIX216: tanggal Hijriah tidak lagi bergantung pada hitungan lokal perangkat saja.
 *
 * Satu bulan Masehi penuh diambil dari internet (AlAdhan gToHCalendar), divalidasi (jumlah hari, urutan hari Hijriah berkesinambungan),
 * lalu disimpan di perangkat. Pembacaan tanggal Hijriah, jadwal puasa Ramadan/Syawal, dan ucapan tanggal memakai data ini lebih dulu;
 * hitungan ICU perangkat hanya cadangan bila bulan itu belum pernah diunduh. Data diperbarui otomatis:
 *  - bulan berjalan dan bulan depan disegarkan paling lambat tiap 2 hari (menangkap penyesuaian tanggal Hijriah),
 *  - 13 bulan ke depan diunduh sekali dan disegarkan tiap 30 hari (menangkap pergantian tahun Hijriah/Masehi),
 *  - bila internet mati, data terakhir tetap dipakai dan percobaan diulang otomatis di kesempatan berikutnya.
 * Sumber daring adalah AlAdhan, bukan server resmi Kemenag. FIX293: penetapan resmi Kemenag (HijriahResmi) selalu didahulukan bila ada.
 */
object HijriahDaring {
    private const val PREF = "hijriah_daring"
    private const val JEDA_PERCOBAAN_MS = 3L * 60L * 60L * 1000L
    private const val USIA_BULAN_DEKAT_MS = 2L * 24L * 60L * 60L * 1000L
    private const val USIA_BULAN_JAUH_MS = 30L * 24L * 60L * 60L * 1000L
    private const val BULAN_KE_DEPAN = 13

    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var berjalan = false

    /** "yyyy-MM" -> array hari ke-1..n berisi (tahun, bulan 0-based, tanggal) Hijriah. */
    private val memori = ConcurrentHashMap<String, Array<IntArray>>()

    private fun kunci(ym: YearMonth) = String.format(Locale.US, "%04d-%02d", ym.year, ym.monthValue)

    private fun sp(context: Context) = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun bacaBulan(context: Context, ym: YearMonth): Array<IntArray>? {
        val k = kunci(ym)
        memori[k]?.let { return it }
        val teks = sp(context).getString("b_$k", null) ?: return null
        return try {
            val baris = teks.split(';').map { e -> e.split(',').map { it.toInt() }.toIntArray() }.toTypedArray()
            if (baris.size != ym.lengthOfMonth() || baris.any { it.size != 3 }) null else { memori[k] = baris; baris }
        } catch (_: Exception) { null }
    }

    /** Tanggal Hijriah (tahun, bulan 0-based, tanggal) dari data daring tersimpan; null bila bulan itu belum diunduh. */
    fun cari(context: Context, date: LocalDate): Triple<Int, Int, Int>? {
        HijriahResmi.cari(context, date)?.let { return it }
        val bulan = bacaBulan(context, YearMonth.from(date)) ?: return null
        val e = bulan.getOrNull(date.dayOfMonth - 1) ?: return null
        return Triple(e[0], e[1], e[2])
    }

    /** Data daring bila ada, bila tidak hitungan ICU perangkat. */
    fun hijri(context: Context, date: LocalDate): Triple<Int, Int, Int> = cari(context, date) ?: hitungIcu(date)

    fun hitungIcu(date: LocalDate): Triple<Int, Int, Int> {
        val g = Calendar.getInstance(TimeZone.getDefault()).apply {
            clear(); set(date.year, date.monthValue - 1, date.dayOfMonth, 12, 0, 0)
        }
        val islamic = IslamicCalendar(g.time)
        return Triple(islamic.get(Calendar.YEAR), islamic.get(Calendar.MONTH), islamic.get(Calendar.DAY_OF_MONTH))
    }

    /** Waktu (ms) unduhan terakhir yang berhasil untuk bulan berjalan; 0 bila belum pernah. */
    fun terakhirDiperbarui(context: Context): Long = sp(context).getLong("sukses_terakhir", 0L)

    private fun perluDiunduh(context: Context, ym: YearMonth, sekarang: YearMonth, nowMs: Long): Boolean {
        val selisih = (ym.year - sekarang.year) * 12 + (ym.monthValue - sekarang.monthValue)
        val usia = nowMs - sp(context).getLong("t_" + kunci(ym), 0L)
        val punya = bacaBulan(context, ym) != null
        if (!punya) return true
        return usia > (if (selisih in 0..1) USIA_BULAN_DEKAT_MS else USIA_BULAN_JAUH_MS)
    }

    /**
     * Unduh bulan yang belum ada atau sudah kedaluwarsa. Aman dipanggil sering-sering: jeda minimal antar percobaan 3 jam
     * kecuali paksa = true. selesai(true) bila semua bulan yang dibutuhkan kini tersedia.
     */
    fun segarkan(context: Context, paksa: Boolean = false, selesai: ((Boolean) -> Unit)? = null) {
        val app = context.applicationContext
        HijriahResmi.segarkan(app, paksa)
        val prefs = sp(app)
        val nowMs = System.currentTimeMillis()
        val sekarang = YearMonth.now()
        // Bulan sebelumnya ikut karena pukul 18.00 ke atas dihitung sebagai hari berikutnya dan tanggal dapat menyeberangi batas bulan.
        val daftar = (-1..BULAN_KE_DEPAN).map { sekarang.plusMonths(it.toLong()) }
        val perlu = daftar.filter { paksa || perluDiunduh(app, it, sekarang, nowMs) }
        if (perlu.isEmpty()) { selesai?.let { cb -> Handler(Looper.getMainLooper()).post { cb(true) } }; return }
        if (!paksa && nowMs - prefs.getLong("percobaan_terakhir", 0L) < JEDA_PERCOBAAN_MS) {
            selesai?.let { cb -> Handler(Looper.getMainLooper()).post { cb(false) } }; return
        }
        synchronized(this) {
            if (berjalan) { selesai?.let { cb -> Handler(Looper.getMainLooper()).post { cb(false) } }; return }
            berjalan = true
        }
        prefs.edit().putLong("percobaan_terakhir", nowMs).apply()
        executor.execute {
            var semua = true
            try {
                // Bulan berjalan dan sekitarnya lebih dulu agar data yang paling dibutuhkan cepat tersedia.
                for (ym in perlu.sortedBy { Math.abs((it.year - sekarang.year) * 12 + (it.monthValue - sekarang.monthValue)) }) {
                    val hasil = unduhBulan(ym)
                    if (hasil == null) { semua = false; break }
                    memori[kunci(ym)] = hasil
                    prefs.edit()
                        .putString("b_" + kunci(ym), hasil.joinToString(";") { it.joinToString(",") })
                        .putLong("t_" + kunci(ym), System.currentTimeMillis()).apply()
                    if (ym == sekarang) prefs.edit().putLong("sukses_terakhir", System.currentTimeMillis()).apply()
                }
            } catch (_: Exception) {
                semua = false
            } finally {
                synchronized(this) { berjalan = false }
                val hasilAkhir = semua
                selesai?.let { cb -> Handler(Looper.getMainLooper()).post { cb(hasilAkhir) } }
            }
        }
    }

    /** Satu bulan Masehi dari AlAdhan; null bila gagal atau datanya tidak masuk akal (tidak disimpan). */
    private fun unduhBulan(ym: YearMonth): Array<IntArray>? {
        var koneksi: HttpURLConnection? = null
        try {
            koneksi = (URL("https://api.aladhan.com/v1/gToHCalendar/" + ym.monthValue + "/" + ym.year).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000; readTimeout = 12000; requestMethod = "GET"
            }
            if (koneksi.responseCode !in 200..299) return null
            val json = JSONObject(koneksi.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val data = json.getJSONArray("data")
            val panjang = ym.lengthOfMonth()
            if (data.length() != panjang) return null
            val hasil = Array(panjang) { IntArray(3) }
            for (i in 0 until data.length()) {
                val item = data.getJSONObject(i)
                val g = item.getJSONObject("gregorian")
                val h = item.getJSONObject("hijri")
                if (g.getString("day").trim().toInt() != i + 1) return null
                val tahun = h.getString("year").trim().toInt()
                val bulan = h.getJSONObject("month").getInt("number") - 1
                val hari = h.getString("day").trim().toInt()
                hasil[i] = intArrayOf(tahun, bulan, hari)
            }
            if (!masukAkal(hasil)) return null
            return hasil
        } catch (_: Exception) {
            return null
        } finally {
            try { koneksi?.disconnect() } catch (_: Exception) { }
        }
    }

    /** Tiap hari harus maju satu tanggal Hijriah, atau berganti bulan/tahun dengan tanggal 1 setelah tanggal 29/30. */
    private fun masukAkal(d: Array<IntArray>): Boolean {
        for (i in d.indices) {
            val (t, b, h) = d[i].let { Triple(it[0], it[1], it[2]) }
            if (t !in 1300..1700 || b !in 0..11 || h !in 1..30) return false
            if (i == 0) continue
            val (pt, pb, ph) = d[i - 1].let { Triple(it[0], it[1], it[2]) }
            val lanjutBulan = t == pt && b == pb && h == ph + 1
            val bulanBaru = h == 1 && ph >= 29 && ((t == pt && b == pb + 1) || (t == pt + 1 && pb == 11 && b == 0))
            if (!lanjutBulan && !bulanBaru) return false
        }
        return true
    }
}
