package com.novan.bateraibicara

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText

/** Ruang ta'aruf yang berbagi hanya atas pilihan pengguna, serta doa yang disimpan lokal dan dapat dibagikan. */
class TaarufDoaActivity : Halaman() {
    override val judulHalaman = R.string.judul_taaruf_doa
    private val data by lazy { getSharedPreferences("taaruf_dan_doa", MODE_PRIVATE) }
    private lateinit var nama: EditText
    private lateinit var usia: EditText
    private lateinit var kota: EditText
    private lateinit var minat: EditText
    private lateinit var tujuan: EditText
    private lateinit var namaPenerima: EditText
    private lateinit var isiDoa: EditText

    override fun bangun() {
        bagian("Ta'aruf / Berkenalan", 22f)
        info("Kenalkan diri dengan sopan untuk membangun silaturahmi sesama muslim. Data tersimpan di perangkat ini dan tidak diunggah otomatis. Anda menentukan sendiri kapan membagikannya.")
        nama = isian("Nama atau nama panggilan", data.getString("nama", "").orEmpty(), InputType.TYPE_CLASS_TEXT) {}
        usia = isian("Usia (opsional)", data.getString("usia", "").orEmpty(), InputType.TYPE_CLASS_NUMBER) {}
        kota = isian("Kota atau daerah (opsional)", data.getString("kota", "").orEmpty(), InputType.TYPE_CLASS_TEXT) {}
        minat = isian("Minat atau hal yang ingin dikenalkan (opsional)", data.getString("minat", "").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) {}
        tujuan = isian("Tujuan berkenalan (misalnya silaturahmi atau mencari pasangan secara serius)", data.getString("tujuan", "").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) {}
        tombol("Simpan profil ta'aruf di perangkat") { simpanProfil() }
        tombol("Bagikan perkenalan") { simpanProfil(); bagikanProfil() }

        bagian("Saling Mendoakan", 22f)
        info("Tuliskan doa baik untuk keluarga, sahabat, atau sesama muslim. Doa dapat disimpan di perangkat atau dibagikan melalui aplikasi pilihan Anda.")
        namaPenerima = isian("Nama penerima doa (opsional)", "", InputType.TYPE_CLASS_TEXT) {}
        isiDoa = isian("Tuliskan doa", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) {}
        tombol("Isi contoh doa") {
            isiDoa.setText(if (BahasaAplikasi.tampilan(this) == 1)
                "May Allah grant you health, peace, ease in your affairs, abundant blessings, and goodness in this life and the Hereafter. Ameen."
            else "Semoga Allah menganugerahkan kesehatan, ketenangan, kemudahan dalam urusan, keberkahan yang luas, serta kebaikan di dunia dan akhirat. Aamiin.")
        }
        tombol("Simpan doa di perangkat") { simpanDoa() }
        tombol("Bagikan doa") { bagikanDoa() }
        tombol("Bagikan doa umum untuk sesama muslim") { bagikanDoaUmum() }
        val doaTersimpan = data.getString("doa_terakhir", "").orEmpty()
        if (doaTersimpan.isNotBlank()) {
            bagian("Doa terakhir yang disimpan")
            info(doaTersimpan)
        }
    }

    private fun simpanProfil() {
        data.edit().putString("nama", nama.text.toString().trim())
            .putString("usia", usia.text.toString().trim())
            .putString("kota", kota.text.toString().trim())
            .putString("minat", minat.text.toString().trim())
            .putString("tujuan", tujuan.text.toString().trim()).apply()
        toast("Profil ta'aruf disimpan di perangkat ini.")
    }

    private fun teksProfil(): String {
        val english = BahasaAplikasi.tampilan(this) == 1
        val n = nama.text.toString().trim()
        val u = usia.text.toString().trim()
        val k = kota.text.toString().trim()
        val m = minat.text.toString().trim()
        val t = tujuan.text.toString().trim()
        val labelNama = if (english) "Name" else "Nama"
        val labelUsia = if (english) "Age" else "Usia"
        val labelKota = if (english) "City/area" else "Kota/daerah"
        val labelMinat = if (english) "Interests" else "Minat"
        val labelTujuan = if (english) "Purpose of introduction" else "Tujuan berkenalan"
        val judul = if (english) "Ta'aruf introduction" else "Perkenalan ta'aruf"
        val penutup = if (english) {
            "I hope we can get to know each other respectfully and maintain good Muslim fellowship."
        } else {
            "Semoga kita dapat saling mengenal dengan sopan dan menjaga silaturahmi sesama muslim."
        }
        return buildString {
            append(judul)
            if (n.isNotBlank()) append("\n$labelNama: $n")
            if (u.isNotBlank()) append("\n$labelUsia: $u")
            if (k.isNotBlank()) append("\n$labelKota: $k")
            if (m.isNotBlank()) append("\n$labelMinat: $m")
            if (t.isNotBlank()) append("\n$labelTujuan: $t")
            append("\n\n")
            append(penutup)
        }
    }

    private fun bagikanProfil() {
        if (nama.text.toString().isBlank()) { toast("Isi nama atau nama panggilan terlebih dahulu."); return }
        bagikan(teksProfil(), if (BahasaAplikasi.tampilan(this) == 1) "Share introduction" else "Bagikan perkenalan")
    }

    private fun simpanDoa() {
        val isi = isiDoa.text.toString().trim()
        if (isi.isBlank()) { toast("Tuliskan doa terlebih dahulu."); return }
        val penerima = namaPenerima.text.toString().trim()
        val english = BahasaAplikasi.tampilan(this) == 1
        val hasil = buildString {
            if (penerima.isNotBlank()) append((if (english) "A prayer for " else "Doa untuk ") + penerima + ":\n")
            append(isi)
        }
        data.edit().putString("doa_terakhir", hasil).apply()
        toast("Doa disimpan di perangkat ini.")
    }

    private fun bagikanDoa() {
        val isi = isiDoa.text.toString().trim()
        if (isi.isBlank()) { toast("Tuliskan doa terlebih dahulu."); return }
        val english = BahasaAplikasi.tampilan(this) == 1
        val penerima = namaPenerima.text.toString().trim()
        val teks = buildString {
            if (penerima.isNotBlank()) append((if (english) "A prayer for " else "Doa untuk ") + penerima + ":\n")
            append(isi)
            append("\n\n")
            append(if (english) "May Allah accept our prayers. Ameen." else "Semoga Allah menerima doa-doa kita. Aamiin.")
        }
        data.edit().putString("doa_terakhir", teks).apply()
        bagikan(teks, if (english) "Share a prayer" else "Bagikan doa")
    }

    private fun bagikanDoaUmum() {
        val english = BahasaAplikasi.tampilan(this) == 1
        val teks = if (english) {
            "May Allah forgive us, guide our hearts, protect our families, heal those who are ill, ease the burdens of those in hardship, provide lawful sustenance, and grant goodness in this life and the Hereafter. Ameen."
        } else {
            "Semoga Allah mengampuni kita, membimbing hati kita, menjaga keluarga kita, menyembuhkan saudara-saudara yang sakit, meringankan kesulitan mereka yang sedang diuji, melapangkan rezeki yang halal, serta menganugerahkan kebaikan di dunia dan akhirat. Aamiin."
        }
        bagikan(teks, if (english) "Share a prayer for Muslims" else "Bagikan doa untuk sesama muslim")
    }

    private fun bagikan(teks: String, judul: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, teks)
            startActivity(Intent.createChooser(intent, ui(judul)))
        } catch (_: Exception) {
            toast("Tidak ditemukan aplikasi untuk membagikan pesan.")
        }
    }
}
