# Baterai Jam Nama Pemanggil

Aplikasi Android berbahasa Indonesia, **tanpa internet** (tidak ada izin INTERNET). Semua suara memakai mesin
Text-to-Speech yang terpasang di HP; tiap kategori bisa memilih mesin suaranya sendiri.

## Kategori di halaman utama
- **Baterai** – tampilan baterai (persen, bar, suhu, tegangan); persen disebut setiap 5/10/20/25%,
  dapat dipilih *hanya saat mengisi daya* atau *selalu*; peringatan lemah/kritis/penuh; ucapan charger & USB.
- **Jam** – jam bicara tepat waktu: setiap jam atau setiap 5–30 menit, jam mulai–selesai, hari aktif,
  format 24 jam atau 12 jam (pagi/siang/sore/malam), pilihan bahasa Indonesia/English, sebut menit, kata pembuka, mesin suara sendiri.
- **Nama pemanggil** – mengumumkan panggilan WhatsApp (suara & video) dan telepon seluler beserta nama
  penelepon, diulang selama berdering (jeda bawaan 1,5 detik, bisa diubah; batas ulang opsional), berhenti
  otomatis saat dijawab/ditolak. Mesin suara, kecepatan, nada, dan keluaran volume sendiri; nada penanda singkat sebelum/sesudah pengumuman dapat diaktifkan.

## Berjalan terus di latar belakang
Layanan foreground + alarm tepat waktu + wake lock, aktif otomatis setelah HP dihidupkan ulang.
Nama pemanggil memakai *Akses notifikasi* (dijalankan sistem sendiri setelah restart).

## Versi proyek
Versi proyek diselaraskan menjadi **1.0.18** mengikuti APK referensi. Perubahan ini mempertahankan package ID `com.novan.bateraibicara`.

## Cara membangun lewat GitHub Actions
1. Buat repositori GitHub, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Tab **Actions** → **Bangun APK** → **Run workflow** (atau push ke `main`).
3. Unduh artefak **BateraiBicara-APK** (`app-release.apk`).

APK ditandatangani otomatis dengan kunci yang dibuat saat build. Untuk kunci tetap isi secret repo:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Izin yang perlu diberikan di HP
1. Notifikasi (Android 13+), 2. Akses notifikasi (untuk nama pemanggil), 3. Status telepon (opsional),
4. Izinkan berjalan di latar belakang + Mulai otomatis (OPPO/ColorOS). Semua ada tombolnya di aplikasi.


## Pelengkapan jam bicara dan baterai (versi 1.0.18)

- Jam bicara kini memiliki pilihan Bahasa Indonesia, English, dan Arab (hasil pengucapan Arab bergantung pada ketersediaan suara Arab di mesin TTS HP).
- Ditambahkan 16 berkas audio melodi yang diekstrak dari APK sumber ke `app/src/main/res/raw/`, pilihan melodi awal/akhir, jeda sebelum/sesudah pengucapan, tombol dengarkan melodi, tes jam lengkap, dan pintasan izin alarm tepat waktu.
- Baterai kini memiliki pilihan batas penuh 80–100%, pengulangan ucapan penuh dengan jumlah dan jeda yang dapat diatur, serta pembaruan pengaturan yang diterapkan ke layanan berjalan.
- Pengumuman baterai tetap membutuhkan layanan latar belakang aktif. Pada beberapa merek HP, pengguna perlu mengizinkan aktivitas latar belakang/mulai otomatis.

## Verifikasi sebelum rilis

Jalankan workflow GitHub Actions untuk membangun APK. Setelah terpasang, uji jam dengan layar mati dan layar menyala, jam melewati tengah malam, setiap interval, semua pilihan bahasa yang didukung TTS, melodi awal/akhir, serta baterai lemah/penuh dan pencabutan kabel pengisi daya. Audio melodi dipertahankan dari APK sumber, tetapi urutan nama melodi di proyek hasil disusun sebagai pilihan 1–15 dan perlu dicocokkan pendengaran di perangkat.

- Ditambahkan pilihan cara penyebutan baterai berdasarkan persentase atau interval waktu (1, 2, 5, 10, 15, 30, atau 60 menit).
- Ditambahkan kolom kalimat baterai yang dapat disesuaikan untuk persentase, peringatan lemah/kritis/penuh, dan status charger/USB. Token `{persen}` diisi dengan nilai aktual.


## Fitur penyebutan panggilan

Halaman **Penyebutan Nama Pemanggil** menyediakan pengaktifan utama, pilihan panggilan WhatsApp, WhatsApp Bisnis, dan telepon seluler, kalimat terpisah untuk WhatsApp suara/video, WhatsApp Bisnis suara/video, dan telepon biasa (placeholder `{nama}`), jeda dan batas pengulangan, melodi awal/akhir beserta jeda, pengaturan mesin TTS/kecepatan/nada/keluaran, serta tombol tes untuk masing-masing pola kalimat.

Agar deteksi berfungsi, pengguna harus memberi **Akses notifikasi** kepada aplikasi. Izin **Status telepon** disarankan untuk menghentikan pengumuman telepon seluler saat panggilan dijawab/berakhir; izin Kontak membantu mengubah nomor menjadi nama. Deteksi panggilan WhatsApp bergantung pada format notifikasi yang disediakan versi WhatsApp dan Android pada perangkat. Perilaku latar belakang tetap perlu diuji pada perangkat sasaran dan tidak dapat dijamin hanya dengan pemeriksaan berkas.


## Kelengkapan pengujian dan kalimat

- Halaman baterai menyediakan tombol tes untuk setiap kalimat: persentase, lemah, kritis, baterai penuh di bawah 100%, baterai 100%, pengisi daya dipasang/dicabut, dan USB dipasang/dicabut. Kalimat persentase mendukung token `{persen}` dan dapat dipulihkan ke bawaan.
- Halaman jam menyediakan tes ucapan saja dan tes lengkap bersama melodi.
- Halaman nama pemanggil menyediakan pengaturan dan tes kalimat WhatsApp suara/video, WhatsApp Bisnis suara/video, dan telepon biasa; token `{nama}` bisa disisipkan melalui tombol. Melodi awal/akhir dapat dipilih dari audio yang tersedia dan diuji masing-masing.
- Pencocokan kontak dapat menggunakan nama panggilan (nickname) bila tersedia.
- Pilihan keluaran suara mencakup media, alarm, notifikasi, dering, aksesibilitas, dan panggilan suara.

Catatan audit: perubahan ini diperiksa secara statis dan berkas XML divalidasi. Lingkungan ini tidak memiliki Android SDK/Gradle untuk menghasilkan APK atau menjalankan pengujian panggilan di perangkat; hasil build GitHub Actions tetap harus diperiksa.


## Audit tambahan fitur baterai dan bahasa
- Batas baterai kritis sekarang dapat dipilih: 1%, 2%, 3%, 5%, 7%, 10%, 15%, atau 20%.
- Tombol uji kalimat baterai diletakkan tepat setelah kolom kalimat terkait, termasuk level, lemah, kritis, penuh, charger, dan USB.
- Contoh nama pemanggil untuk pengujian adalah Ali Bima. Tombol uji kalimat tetap berada di bagian masing-masing jenis panggilan.
- Pengucapan waktu memiliki pilihan Jawa Krama Inggil dengan susunan kalimat Jawa dan permintaan locale TTS `jv-ID`. Dukungan bahasa Jawa bergantung pada mesin TTS dan data suara yang terpasang di perangkat; jika mesin tidak mendukungnya, Android dapat memakai bahasa cadangan.
