package com.novan.bateraibicara

/**
 * FIX321: pencocok nama aplikasi untuk perintah suara "buka brimo", "buka WhatsApp bisnis", "buka inDrive" dan sejenisnya.
 * Memakai kunci tanpa spasi/tanda baca, alias ucapan umum (nama bank dan aplikasi transportasi daring), kecocokan sebagian,
 * dan kemiripan huruf agar salah dengar kecil pada pengenal suara tetap menemukan aplikasi yang benar.
 */
object PencocokAplikasi {
    class Aplikasi(val label: String, val paket: String)
    class Hasil(val aplikasi: Aplikasi, val skor: Int)

    private val kataBuang = setOf("buka", "bukakan", "bukain", "bukalah", "jalankan", "jalanin", "open", "launch", "start", "run", "aplikasi", "app", "apps",
        "tolong", "please", "dong", "ya", "saya", "aku", "yang", "ke", "the", "my", "mobile")

    /** Kunci ucapan (tanpa spasi) -> potongan label (kunci) atau nama paket yang dituju. Awalan "pkg:" = nama paket persis. */
    private val alias: Map<String, List<String>> = mapOf(
        "brimo" to listOf("brimo", "pkg:id.co.bri.brimo"), "bribimo" to listOf("brimo"), "brimobri" to listOf("brimo"), "bri" to listOf("brimo", "bri"),
        "bion" to listOf("byond", "bsi"), "bionbsi" to listOf("byond", "bsi"), "bayon" to listOf("byond"), "byond" to listOf("byond"), "byondbsi" to listOf("byond", "bsi"),
        "bsi" to listOf("byond", "bsi"), "bsimobile" to listOf("byond", "bsi"), "bayonbsi" to listOf("byond", "bsi"),
        "mandiri" to listOf("livin", "mandiri"), "livin" to listOf("livin"), "livinmandiri" to listOf("livin"), "livinbymandiri" to listOf("livin"),
        "bca" to listOf("bca"), "bcamobile" to listOf("bca"), "bni" to listOf("bni"), "bnimobile" to listOf("bni"), "wondr" to listOf("wondr"),
        "wa" to listOf("pkg:com.whatsapp"), "whatsapp" to listOf("pkg:com.whatsapp"), "watsap" to listOf("pkg:com.whatsapp"), "wasap" to listOf("pkg:com.whatsapp"),
        "wabisnis" to listOf("pkg:com.whatsapp.w4b"), "wabusiness" to listOf("pkg:com.whatsapp.w4b"), "wabis" to listOf("pkg:com.whatsapp.w4b"),
        "wab" to listOf("pkg:com.whatsapp.w4b"), "wab2b" to listOf("pkg:com.whatsapp.w4b"), "whatsappbisnis" to listOf("pkg:com.whatsapp.w4b"),
        "whatsappbusiness" to listOf("pkg:com.whatsapp.w4b"), "watsapbisnis" to listOf("pkg:com.whatsapp.w4b"), "wasapbisnis" to listOf("pkg:com.whatsapp.w4b"),
        "gojek" to listOf("pkg:com.gojek.app", "gojek"), "gojeg" to listOf("pkg:com.gojek.app", "gojek"), "gojec" to listOf("pkg:com.gojek.app", "gojek"),
        "grab" to listOf("pkg:com.grabtaxi.passenger", "grab"), "grap" to listOf("pkg:com.grabtaxi.passenger", "grab"),
        "maxim" to listOf("maxim"), "maksim" to listOf("maxim"), "maxime" to listOf("maxim"),
        "indriver" to listOf("indrive", "indriver"), "indrive" to listOf("indrive", "indriver"), "inderiver" to listOf("indrive", "indriver"),
        "indraiver" to listOf("indrive", "indriver"), "indraver" to listOf("indrive", "indriver"), "inderaiver" to listOf("indrive", "indriver"),
        "tele" to listOf("pkg:org.telegram.messenger", "telegram"), "telegram" to listOf("pkg:org.telegram.messenger", "telegram"),
        "tokped" to listOf("tokopedia"), "shopee" to listOf("shopee"), "spay" to listOf("shopee"), "ovo" to listOf("ovo"), "dana" to listOf("pkg:id.dana", "dana"),
        "gopay" to listOf("gojek"), "traveloka" to listOf("traveloka"), "kai" to listOf("kai access", "kaiaccess"), "kaiaccess" to listOf("kaiaccess"),
        "yt" to listOf("pkg:com.google.android.youtube"), "youtube" to listOf("pkg:com.google.android.youtube"),
        "gmail" to listOf("pkg:com.google.android.gm"), "maps" to listOf("pkg:com.google.android.apps.maps"), "peta" to listOf("pkg:com.google.android.apps.maps"),
        "playstore" to listOf("pkg:com.android.vending"), "chrome" to listOf("pkg:com.android.chrome"), "fb" to listOf("pkg:com.facebook.katana"),
        "ig" to listOf("pkg:com.instagram.android"), "instagram" to listOf("pkg:com.instagram.android"), "tiktok" to listOf("tiktok")
    )

    fun kunci(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

    /** Buang kata perintah dari ucapan; sisanya nama aplikasi. */
    fun namaDariUcapan(ucapan: String): String =
        ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() && it !in kataBuang }.joinToString(" ")

    private fun jarak(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var p = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val c = IntArray(b.length + 1); c[0] = i
            for (j in 1..b.length) c[j] = minOf(c[j - 1] + 1, p[j] + 1, p[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            p = c
        }
        return p[b.length]
    }

    /** Daftar hasil, skor tertinggi dulu (skor >= 20). */
    fun cari(daftar: List<Aplikasi>, ucapan: String): List<Hasil> {
        val nama = namaDariUcapan(ucapan)
        val q = kunci(nama)
        if (q.length < 2) return emptyList()
        val tokenQ = nama.split(" ").filter { it.length >= 2 }
        val tujuan = alias[q]
        val hasil = ArrayList<Hasil>()
        for (a in daftar) {
            val lk = kunci(a.label)
            if (lk.isEmpty()) continue
            var skor = 0
            if (tujuan != null) {
                for (t in tujuan) {
                    if (t.startsWith("pkg:")) { if (a.paket == t.substring(4)) skor = maxOf(skor, 98) }
                    else if (lk == kunci(t)) skor = maxOf(skor, 95)
                    else if (lk.contains(kunci(t))) skor = maxOf(skor, 88)
                }
            }
            if (lk == q) skor = maxOf(skor, 100)
            else if (lk.startsWith(q)) skor = maxOf(skor, 80)
            else if (q.length >= 3 && lk.contains(q)) skor = maxOf(skor, 65)
            else if (lk.length >= 3 && q.contains(lk)) skor = maxOf(skor, 55)
            if (skor == 0 && tokenQ.size >= 2 && tokenQ.all { lk.contains(kunci(it)) }) skor = 45
            if (skor == 0 && q.length >= 4) {
                val d = jarak(q, lk)
                val batas = if (q.length >= 8) 2 else 1
                if (d <= batas) skor = 30 - d
                else if (lk.length > q.length && jarak(q, lk.substring(0, minOf(lk.length, q.length))) <= batas) skor = 22
            }
            if (skor >= 20) hasil.add(Hasil(a, skor))
        }
        return hasil.sortedWith(compareByDescending<Hasil> { it.skor }.thenBy { it.aplikasi.label.length })
    }
}
