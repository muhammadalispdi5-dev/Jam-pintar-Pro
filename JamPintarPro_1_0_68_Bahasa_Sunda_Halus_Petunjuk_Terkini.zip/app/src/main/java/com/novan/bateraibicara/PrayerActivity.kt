package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.GnssStatus
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.app.AlertDialog
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Jadwal hari ini, pembaruan lokasi, pengaturan, jadwal 30 hari dan arah kiblat. */
class PrayerActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private lateinit var status: android.widget.TextView
    private lateinit var list: android.widget.TextView
    private val dateFmt = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID"))
    private val locationHandler = Handler(Looper.getMainLooper())
    private var activeLocationManager: LocationManager? = null
    private var activeLocationListener: LocationListener? = null
    private var activeGnssCallback: GnssStatus.Callback? = null
    private var locationTone: ToneGenerator? = null
    private var searchingPrayerLocation = false
    private var bestLiveLocation: Location? = null
    private var freshCachedLocation: Location? = null
    private var accurateFixCount = 0
    private var firstAccurateFixAt = 0L
    private var lastFixTimestamp = 0L
    private var satelliteStatusAvailable = false
    private var visibleSatellites = 0
    private var usedSatellites = 0
    private var lastSpokenSearchStatus = 0L
    private val prayerLocationBeep = object : Runnable {
        override fun run() {
            if (!searchingPrayerLocation) return
            try { locationTone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }
            locationHandler.postDelayed(this, 650L)
        }
    }
    private val prayerLocationProgress = object : Runnable {
        override fun run() {
            if (!searchingPrayerLocation) return
            val now = System.currentTimeMillis()
            if (now - lastSpokenSearchStatus >= 12_000L) {
                lastSpokenSearchStatus = now
                val loc = bestLiveLocation
                val accuracy = if (loc != null) " Akurasi terbaik sementara sekitar ${loc.accuracy.toInt()} meter." else " Posisi langsung belum diterima."
                val sat = if (satelliteStatusAvailable) " Satelit GPS terdeteksi $visibleSatellites, digunakan untuk menentukan posisi $usedSatellites." else " Status satelit belum tersedia dari perangkat."
                val message = "Pencarian lokasi jadwal sholat masih berlangsung. Nada pendek berulang menandakan pencarian aktif.$accuracy$sat"
                if (::status.isInitialized) status.text = message
                tesSuara("jam", message)
            }
            locationHandler.postDelayed(this, 2_000L)
        }
    }

    override fun bangun() {
        status = info("")
        list = info("")
        bagian("Lokasi")
        info("Jadwal dihitung di HP sebagai cadangan. Jika opsi pembaruan otomatis melalui internet diaktifkan di Pengaturan Jadwal Sholat, aplikasi mengunduh jadwal berdasarkan koordinat untuk memperbarui waktu. Koordinat lokasi akan dikirim ke layanan jadwal tersebut hanya untuk meminta waktu salat.")
        tombol("Perbarui lokasi (GPS)") { perbaruiLokasiGps() }
        tombol("Atur lokasi manual") { dialogLokasiManual() }
        tombol("Pengaturan Jadwal Sholat dan Pengingat") { startActivity(Intent(this, PrayerSettingsActivity::class.java)) }
        tombol("Bacakan jadwal sholat hari ini") {
            if (!pp.locationSet) toast("Atur lokasi terlebih dahulu.") else {
                val d = LocalDate.now()
                val t = PrayerCalc.calculate(d, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
                val bahasa = prefs.jamBahasaIdx
                val daftar = listOf(
                    "subuh" to onlineOrLocal(d, "subuh", t.fajr), "terbit" to onlineOrLocal(d, "terbit", t.sunrise),
                    "dhuha" to onlineOrLocal(d, "dhuha", t.dhuha), "tahajud" to waktuTahajud(d),
                    "dzuhur" to onlineOrLocal(d, "dzuhur", t.dhuhr), "ashar" to onlineOrLocal(d, "ashar", t.asr),
                    "maghrib" to onlineOrLocal(d, "maghrib", t.maghrib), "isya" to onlineOrLocal(d, "isya", t.isha)
                )
                tesSuara("jam", UcapanSholat.jadwalHariIni(daftar, bahasa, pp.use24))
            }
        }
        tombol("Pilih hari dan jadwal 30 hari") { startActivity(Intent(this, PrayerThirtyActivity::class.java)) }
        tombol("Arah Kiblat") { startActivity(Intent(this, QiblaActivity::class.java)) }
        tombol("Info Jadwal Sholat") {
            AlertDialog.Builder(this).setTitle("Info Jadwal Sholat")
                .setMessage("Jadwal dihitung secara lokal tanpa internet. Untuk Indonesia, metode yang disarankan adalah Kemenag RI. Hasil dapat berbeda beberapa menit dari jadwal masjid setempat karena koordinat, metode, dan penyesuaian menit. Pengingat dan suara azan dalam keadaan nonaktif sampai Anda mengaktifkannya di Pengaturan Jadwal Sholat.")
                .setPositiveButton("Mengerti", null).show()
        }
        segarkan()
        if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, msg ->
            runOnUiThread { if (::status.isInitialized) { segarkan(); toast(msg) }; PrayerAlarm.scheduleAll(this) }
        }
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) { segarkan(); if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, _ -> runOnUiThread { segarkan(); PrayerAlarm.scheduleAll(this) } } } }

    private fun segarkan() {
        if (!pp.locationSet) {
            status.text = "Lokasi belum diatur. Ketuk Perbarui lokasi (GPS) atau Atur lokasi manual."
            list.text = "Jadwal belum dapat dihitung sampai lokasi ditentukan."
            return
        }
        val date = LocalDate.now()
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        status.text = ("" + (date.format(dateFmt)) + "\n" + (pp.place) + "\nKoordinat: " + ("%.5f".format(pp.lat)) + ", " + ("%.5f".format(pp.lon)) + "\nMetode: " + (PrayerCalc.methodNames[pp.method]) + "\nPengingat: " + (if (pp.enabled) "aktif" else "nonaktif"))
        list.text = listOf(
            ("Imsak: " + (PrayerCalc.format(onlineOrLocal(date, "imsak", t.imsak), pp.use24))),
            ("Subuh: " + (PrayerCalc.format(onlineOrLocal(date, "subuh", t.fajr), pp.use24))),
            ("Terbit: " + (PrayerCalc.format(onlineOrLocal(date, "terbit", t.sunrise), pp.use24))),
            ("Dhuha: " + (PrayerCalc.format(onlineOrLocal(date, "dhuha", t.dhuha), pp.use24))),
            ("Tahajud (perkiraan): " + (PrayerCalc.format(waktuTahajud(date), pp.use24))),
            ("Dzuhur: " + (PrayerCalc.format(onlineOrLocal(date, "dzuhur", t.dhuhr), pp.use24))),
            ("Ashar: " + (PrayerCalc.format(onlineOrLocal(date, "ashar", t.asr), pp.use24))),
            ("Maghrib: " + (PrayerCalc.format(onlineOrLocal(date, "maghrib", t.maghrib), pp.use24))),
            ("Isya: " + (PrayerCalc.format(onlineOrLocal(date, "isya", t.isha), pp.use24)))
        ).joinToString("\n")
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 401 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) perbaruiLokasiGps()
    }

    private fun perbaruiLokasiGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 401)
            return
        }
        berhentiMencariLokasiJadwal()
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        activeLocationManager = lm
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        if (providers.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Layanan lokasi mati. Nyalakan lokasi di setelan perangkat, atau atur lokasi manual.")
                .setPositiveButton("Setelan lokasi") { _, _ -> startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
                .setNegativeButton("Batal", null).show()
            return
        }

        searchingPrayerLocation = true
        bestLiveLocation = null
        freshCachedLocation = null
        accurateFixCount = 0
        firstAccurateFixAt = 0L
        lastFixTimestamp = 0L
        satelliteStatusAvailable = false
        visibleSatellites = 0
        usedSatellites = 0
        lastSpokenSearchStatus = System.currentTimeMillis()
        val pesanMulai = "Sedang mencari lokasi untuk jadwal sholat melalui GPS dan jaringan. Mohon tunggu hingga 45 detik. Untuk hasil lebih teliti, usahakan berada di tempat terbuka. Nada pendek berulang menandakan pencarian aktif."
        if (::status.isInitialized) status.text = pesanMulai
        tesSuara("jam", pesanMulai)
        locationTone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        locationHandler.post(prayerLocationBeep)
        locationHandler.postDelayed(prayerLocationProgress, 12_000L)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val callback = object : GnssStatus.Callback() {
                    override fun onSatelliteStatusChanged(gnssStatus: GnssStatus) {
                        if (!searchingPrayerLocation) return
                        var visible = 0
                        var used = 0
                        for (i in 0 until gnssStatus.satelliteCount) {
                            visible++
                            if (gnssStatus.usedInFix(i)) used++
                        }
                        visibleSatellites = visible
                        usedSatellites = used
                        satelliteStatusAvailable = true
                    }
                }
                activeGnssCallback = callback
                lm.registerGnssStatusCallback(callback, locationHandler)
            } catch (_: Exception) {
                activeGnssCallback = null
                satelliteStatusAvailable = false
            }
        }

        try {
            // Simpan lokasi cache sebagai cadangan sahaja; jangan jadikan hasil lama sebagai hasil utama.
            val now = System.currentTimeMillis()
            for (provider in providers) {
                try {
                    @Suppress("MissingPermission")
                    val cached = lm.getLastKnownLocation(provider)
                    if (cached != null && now - cached.time in 0L..120_000L && cached.accuracy > 0f && cached.accuracy <= 10_000f &&
                        (freshCachedLocation == null || cached.accuracy < freshCachedLocation!!.accuracy)) freshCachedLocation = cached
                } catch (_: Exception) { }
            }

            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (!searchingPrayerLocation || !location.hasAccuracy() || location.accuracy <= 0f || location.accuracy > 10_000f) return
                    if (System.currentTimeMillis() - location.time !in 0L..120_000L) return
                    val old = bestLiveLocation
                    if (old == null || location.accuracy < old.accuracy ||
                        (location.accuracy <= old.accuracy + 2f && location.time > old.time)) bestLiveLocation = location
                    if (location.time > lastFixTimestamp) {
                        lastFixTimestamp = location.time
                        if (location.accuracy <= 8f) {
                            if (accurateFixCount == 0) firstAccurateFixAt = System.currentTimeMillis()
                            accurateFixCount++
                        } else {
                            accurateFixCount = 0
                            firstAccurateFixAt = 0L
                        }
                    }
                    // Hindari berhenti pada fix pertama; minta beberapa sampel yang teliti dan stabil.
                    if (accurateFixCount >= 3 && firstAccurateFixAt > 0L &&
                        System.currentTimeMillis() - firstAccurateFixAt >= 4_000L) {
                        bestLiveLocation?.let { akhiriPencarianLokasiJadwal(it) }
                    }
                }
                @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            activeLocationListener = listener
            var requested = 0
            for (provider in providers) {
                try {
                    @Suppress("MissingPermission")
                    lm.requestLocationUpdates(provider, 1_000L, 0f, listener, Looper.getMainLooper())
                    requested++
                } catch (_: Exception) { }
            }
            if (requested == 0) {
                akhiriPencarianLokasiJadwal(null, "Perangkat tidak mengizinkan pembaruan lokasi. Periksa izin lokasi dan coba lagi.")
                return
            }
            locationHandler.postDelayed({
                if (searchingPrayerLocation) {
                    // Utamakan lokasi langsung; gunakan cache baru hanya jika tak ada fix langsung.
                    val selected = bestLiveLocation ?: freshCachedLocation
                    akhiriPencarianLokasiJadwal(selected, "Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka atau atur lokasi manual.")
                }
            }, 45_000L)
        } catch (_: SecurityException) {
            akhiriPencarianLokasiJadwal(null, "Izin lokasi belum diberikan. Izinkan akses lokasi untuk memperbarui jadwal sholat.")
        } catch (_: Exception) {
            akhiriPencarianLokasiJadwal(null, "Lokasi belum ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi atau atur lokasi manual.")
        }
    }

    private fun berhentiMencariLokasiJadwal() {
        searchingPrayerLocation = false
        locationHandler.removeCallbacksAndMessages(null)
        try { activeLocationListener?.let { activeLocationManager?.removeUpdates(it) } } catch (_: Exception) { }
        activeLocationListener = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try { activeGnssCallback?.let { activeLocationManager?.unregisterGnssStatusCallback(it) } } catch (_: Exception) { }
        }
        activeGnssCallback = null
        try { locationTone?.release() } catch (_: Exception) { }
        locationTone = null
        activeLocationManager = null
    }

    private fun akhiriPencarianLokasiJadwal(lokasi: Location?, pesanGagal: String? = null) {
        if (!searchingPrayerLocation) return
        berhentiMencariLokasiJadwal()
        if (lokasi != null && lokasi.hasAccuracy() && lokasi.accuracy > 0f && lokasi.accuracy <= 10_000f) {
            val sumber = when (lokasi.provider) {
                LocationManager.GPS_PROVIDER -> "GPS/satelit"
                LocationManager.NETWORK_PROVIDER -> "jaringan"
                else -> "perangkat"
            }
            simpanLokasi(lokasi.latitude, lokasi.longitude, "Lokasi $sumber (akurasi ±${lokasi.accuracy.toInt()} m)")
            val pesan = when {
                lokasi.accuracy > 2_000f -> "Lokasi disimpan dari $sumber, tetapi perkiraan akurasinya masih rendah, sekitar ${lokasi.accuracy.toInt()} meter. Untuk jadwal lebih tepat, coba lagi di tempat terbuka atau atur lokasi manual."
                lokasi.provider == LocationManager.GPS_PROVIDER -> "Lokasi jadwal sholat diperbarui menggunakan GPS. Perkiraan akurasi ${lokasi.accuracy.toInt()} meter."
                else -> "Lokasi jadwal sholat diperbarui. Sumber posisi: $sumber. Perkiraan akurasi ${lokasi.accuracy.toInt()} meter."
            }
            if (::status.isInitialized) status.text = pesan
            tesSuara("jam", pesan)
        } else {
            val pesan = pesanGagal ?: "Lokasi yang layak belum ditemukan. Coba lagi di tempat terbuka atau atur lokasi manual."
            if (::status.isInitialized) status.text = pesan
            AlertDialog.Builder(this).setMessage(pesan).setPositiveButton("Mengerti", null).show()
        }
    }

    override fun onDestroy() {
        berhentiMencariLokasiJadwal()
        super.onDestroy()
    }

    private fun dialogLokasiManual() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val lat = EditText(this).apply { hint = "Lintang / latitude, contoh -7.797"; inputType = 8194; setText(if (pp.locationSet) pp.lat.toString() else "") }
        val lon = EditText(this).apply { hint = "Bujur / longitude, contoh 110.370"; inputType = 8194; setText(if (pp.locationSet) pp.lon.toString() else "") }
        val place = EditText(this).apply { hint = "Nama kota/lokasi (opsional)"; setText(if (pp.locationSet) pp.place else "") }
        box.addView(lat); box.addView(lon); box.addView(place)
        AlertDialog.Builder(this).setTitle("Atur lokasi manual").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val a = lat.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val b = lon.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (a == null || b == null || a !in -90.0..90.0 || b !in -180.0..180.0) {
                    infoDialog("Koordinat tidak valid. Lintang harus −90 sampai 90 dan bujur −180 sampai 180.")
                } else simpanLokasi(a, b, place.text.toString().trim().ifEmpty { "Lokasi manual" })
            }.setNegativeButton("Batal", null).show()
    }

    private fun simpanLokasi(lat: Double, lon: Double, nama: String) {
        pp.lat = lat; pp.lon = lon; pp.place = nama; pp.locationSet = true
        PrayerAlarm.scheduleAll(this)
        toast("Lokasi disimpan")
        segarkan()
        // Cari nama tempat yang spesifik (kelurahan/desa, kota, provinsi) bila nama belum diisi pengguna.
        if (NamaLokasi.belumSpesifik(nama)) NamaLokasi.perbaruiAsinkron(this, pp) { hasil ->
            runOnUiThread {
                if (::status.isInitialized) segarkan()
                if (hasil != null) toast("Nama lokasi: " + hasil)
            }
        }
    }
    private fun onlineOrLocal(date: LocalDate, key: String, fallback: Double): Double {
        if (key == "dhuha" && pp.dhuhaCustomEnabled) return pp.dhuhaCustomMinute / 60.0
        val minutes = if (pp.autoOnline) PrayerOnlineTimes.minutes(this, date, key) else null
        return (minutes?.toDouble() ?: PrayerCalc.minutes(fallback).toDouble()) / 60.0
    }

    private fun waktuTahajud(date: LocalDate): Double {
        if (pp.tahajudCustomEnabled) return pp.tahajudCustomMinute / 60.0
        return PrayerCalc.tahajud(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments(), 0)
    }

    private fun infoDialog(msg: String) { runOnUiThread { AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Mengerti", null).show() } }
}
