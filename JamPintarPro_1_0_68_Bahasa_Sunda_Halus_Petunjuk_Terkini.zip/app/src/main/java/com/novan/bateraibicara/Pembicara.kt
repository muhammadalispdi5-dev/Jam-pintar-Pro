package com.novan.bateraibicara

import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Pembungkus TextToSpeech untuk satu kategori (baterai / jam / pemanggil).
 * Memakai mesin suara pilihan pengguna, menahan CPU saat bicara (layar mati),
 * dan meminta fokus audio agar suara lain mengecil sebentar.
 */
class Pembicara(
    context: Context,
    private val suara: Prefs.Suara,
    private val peringatan: ((Int) -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private class Item(val teks: String, val flush: Boolean, val selesai: (() -> Unit)?)

    private val app = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    val tanda: String = suara.tanda()
    private var tts: TextToSpeech? = null
    private var siap = false
    private var sudahCobaBawaan = false
    private val tunda = ArrayList<Item>()
    private val callbacks = HashMap<String, () -> Unit>()
    private var aktif = 0
    private var fokus: AudioFocusRequest? = null
    private val wakeLock: PowerManager.WakeLock =
        (app.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bateraibicara:bicara")
            .apply { setReferenceCounted(false) }
    private val bersihkan = Runnable {
        aktif = 0
        selesaiBicara()
    }

    init {
        val engine = suara.engine
        tts = if (engine.isEmpty()) TextToSpeech(app, this) else TextToSpeech(app, this, engine)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            if (suara.engine.isNotEmpty() && !sudahCobaBawaan) {
                sudahCobaBawaan = true
                handler.post {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = TextToSpeech(app, this)
                }
            } else {
                peringatan?.invoke(R.string.tts_gagal)
            }
            return
        }
        val locale = if (suara.profil == "jam" || suara.profil == "tgl") {
            when (Prefs(app).jamBahasaIdx) {
                1 -> Locale.forLanguageTag("en-US")
                2 -> Locale.forLanguageTag("ar")
                3 -> Locale.forLanguageTag("jv-ID")
                4 -> Locale.forLanguageTag("su-ID")
                else -> Locale.forLanguageTag("id-ID")
            }
        } else Locale.forLanguageTag("id-ID")
        val r = t.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            peringatan?.invoke(R.string.bahasa_tidak_ada)
            val bahasaCadangan = if ((suara.profil == "jam" || suara.profil == "tgl") && Prefs(app).jamBahasaIdx in 3..4) {
                Locale.forLanguageTag("id-ID")
            } else Locale.getDefault()
            t.setLanguage(bahasaCadangan)
        }
        t.setSpeechRate(suara.rate)
        t.setPitch(suara.pitch)
        t.setAudioAttributes(suara.audioAttributes())
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { selesaiSatu(utteranceId, true) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { selesaiSatu(utteranceId, true) }
            override fun onError(utteranceId: String?, errorCode: Int) { selesaiSatu(utteranceId, true) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { selesaiSatu(utteranceId, false) }
        })
        siap = true
        val antrean = ArrayList(tunda)
        tunda.clear()
        for (i in antrean) ucapkan(i.teks, i.flush, i.selesai)
    }

    /** [selesai] dipanggil setelah kalimat selesai diucapkan (tidak dipanggil bila dihentikan paksa). */
    fun ucapkan(teks: String, flush: Boolean = false, selesai: (() -> Unit)? = null) {
        if (ModeAcara.aktif(app)) { selesai?.invoke(); return }
        val t = tts
        if (t == null || !siap) {
            tunda.add(Item(teks, flush, selesai))
            return
        }
        aktif++
        wakeLock.acquire(60_000L)
        mintaFokus()
        handler.removeCallbacks(bersihkan)
        handler.postDelayed(bersihkan, 45_000L)
        val id = "bb" + System.nanoTime()
        if (selesai != null) callbacks[id] = selesai
        // Parameter stream lama juga dipasang karena sebagian mesin suara mengabaikan AudioAttributes.
        val parameter = android.os.Bundle()
        parameter.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, suara.streamType())
        val hasil = t.speak(
            teks,
            if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            parameter,
            id
        )
        if (hasil != TextToSpeech.SUCCESS) {
            selesaiSatu(id, true)
        }
    }

    /** Membacakan segmen satu per satu dengan jeda standar acuan main.lua (300 ms). */
    fun ucapkanRangkaian(segmen: List<String>, jedaMs: Long = 300L, selesai: (() -> Unit)? = null) {
        if (ModeAcara.aktif(app)) { selesai?.invoke(); return }
        val bersih = segmen.map { it.trim() }.filter { it.isNotEmpty() }
        if (bersih.isEmpty()) { selesai?.invoke(); return }
        var indeks = 0
        fun lanjut() {
            if (indeks >= bersih.size) { selesai?.invoke(); return }
            val teks = bersih[indeks++]
            ucapkan(teks, indeks == 1) {
                if (indeks >= bersih.size) selesai?.invoke()
                else handler.postDelayed({ lanjut() }, jedaMs.coerceAtLeast(0L))
            }
        }
        lanjut()
    }

    fun berhenti() {
        tunda.clear()
        callbacks.clear()
        aktif = 0
        try { tts?.stop() } catch (e: Exception) { }
        selesaiBicara()
    }

    fun matikan() {
        berhenti()
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        siap = false
    }

    private fun selesaiSatu(id: String?, panggil: Boolean) {
        handler.post {
            val cb = if (id != null) callbacks.remove(id) else null
            if (aktif > 0) aktif--
            if (aktif == 0) selesaiBicara()
            if (panggil) cb?.invoke()
        }
    }

    private fun selesaiBicara() {
        handler.removeCallbacks(bersihkan)
        lepasFokus()
        if (wakeLock.isHeld) wakeLock.release()
    }

    private fun mintaFokus() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(suara.audioAttributes())
                .build()
            fokus = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, suara.streamType(), AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun lepasFokus() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            fokus?.let { am.abandonAudioFocusRequest(it) }
            fokus = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }
}
