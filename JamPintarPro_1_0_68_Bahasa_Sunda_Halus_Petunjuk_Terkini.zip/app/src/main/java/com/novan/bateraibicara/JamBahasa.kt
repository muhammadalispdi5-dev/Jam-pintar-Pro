package com.novan.bateraibicara

/** Kata bilangan untuk pengumuman jam. */
object JamBahasa {
    private val id = arrayOf("nol", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas")
    private val en = arrayOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven")
    private val ar = arrayOf("صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر")
    fun kata(n: Int, bahasa: Int): String {
        if (bahasa == 0) return JamWaktu.kata(n)
        if (bahasa == 3) return jawaKata(n)
        if (bahasa == 4) return sundaKata(n)
        if (bahasa == 2) return when {
            n in 0..12 -> ar[n]
            n in 13..19 -> ar[n - 10] + " عشر"
            n in 20..59 -> {
                val puluh = arrayOf("", "", "عشرون", "ثلاثون", "أربعون", "خمسون")
                if (n % 10 == 0) puluh[n / 10] else ar[n % 10] + " و" + puluh[n / 10]
            }
            else -> n.toString()
        }
        val a = en
        return when (n) {
            in 0..11 -> a[n]
            12 -> "twelve"; 13 -> "thirteen"; 14 -> "fourteen"; 15 -> "fifteen"; 16 -> "sixteen"
            17 -> "seventeen"; 18 -> "eighteen"; 19 -> "nineteen"
            else -> {
                val tens = arrayOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
                if (n in 20..99) tens[n / 10] + if (n % 10 == 0) "" else "-" + a[n % 10] else n.toString()
            }
        }
    }

    /** Bilangan Sunda pikeun pengucapan waktos dina ragam lemes/sopan. */
    fun sundaKata(n: Int): String {
        val dasar = arrayOf("nol", "hiji", "dua", "tilu", "opat", "lima", "genep", "tujuh", "dalapan", "salapan")
        return when (n) {
            in 0..9 -> dasar[n]
            10 -> "sapuluh"
            11 -> "sawelas"
            in 12..19 -> dasar[n - 10] + " belas"
            in 20..99 -> {
                val puluh = n / 10
                val sisa = n % 10
                (when (puluh) { 2 -> "dua puluh"; 3 -> "tilu puluh"; 4 -> "opat puluh"; 5 -> "lima puluh"; 6 -> "genep puluh"; 7 -> "tujuh puluh"; 8 -> "dalapan puluh"; 9 -> "salapan puluh"; else -> n.toString() }) +
                    if (sisa == 0) "" else " " + dasar[sisa]
            }
            else -> n.toString()
        }
    }

    /** Bilangan Jawa krama kanggo wektu; ora nggunakake tembung panyambung basa Indonesia. */
    fun jawaKata(n: Int): String {
        val siji = arrayOf("nol", "setunggal", "kalih", "tiga", "sekawan", "gangsal", "enem", "pitu", "wolu", "sanga")
        return when (n) {
            in 0..9 -> siji[n]
            10 -> "sedasa"
            11 -> "sewelas"
            12 -> "kalih welas"
            13 -> "tiga welas"
            14 -> "sekawan welas"
            15 -> "gangsal welas"
            16 -> "enem welas"
            17 -> "pitulas"
            18 -> "wolulas"
            19 -> "sangalas"
            20 -> "kalih dasa"
            21 -> "selikur"
            22 -> "kalih likur"
            23 -> "tiga likur"
            24 -> "sekawan likur"
            25 -> "selangkung"
            in 26..29 -> ("" + (siji[n % 10]) + " likur")
            in 30..39 -> if (n % 10 == 0) "tigang dasa" else ("tigang dasa " + (siji[n % 10]))
            in 40..49 -> if (n % 10 == 0) "sekawan dasa" else ("sekawan dasa " + (siji[n % 10]))
            in 50..59 -> if (n % 10 == 0) "seket" else ("seket " + (siji[n % 10]))
            in 60..69 -> if (n % 10 == 0) "sewidak" else ("sewidak " + (siji[n % 10]))
            in 70..79 -> if (n % 10 == 0) "pitung dasa" else ("pitung dasa " + (siji[n % 10]))
            in 80..89 -> if (n % 10 == 0) "wolung dasa" else ("wolung dasa " + (siji[n % 10]))
            in 90..99 -> if (n % 10 == 0) "sangang dasa" else ("sangang dasa " + (siji[n % 10]))
            else -> n.toString()
        }
    }

    /** Angka tanggal/tahun supaya rangkaian Jawa ora tiba-tiba bali menyang angka Indonesia. */
    fun jawaAngka(n: Int): String {
        if (n in 0..99) return jawaKata(n)
        if (n in 100..999) {
            val atus = n / 100
            val sisa = n % 100
            val wiwitan = if (atus == 1) "setunggal atus" else ("" + (jawaKata(atus)) + " atus")
            return if (sisa == 0) wiwitan else ("" + (wiwitan) + " " + (jawaKata(sisa)))
        }
        if (n in 1000..9999) {
            val ewu = n / 1000
            val sisa = n % 1000
            val wiwitan = if (ewu == 1) "setunggal ewu" else ("" + (jawaKata(ewu)) + " ewu")
            return if (sisa == 0) wiwitan else ("" + (wiwitan) + " " + (jawaAngka(sisa)))
        }
        return n.toString()
    }

    /**
     * Ganti deretan angka di dalam teks (mis. "Imlek 2577", "Saka 1948") dengan kata Jawa
     * agar mesin suara tidak membacakannya dengan angka bahasa Indonesia/Inggris.
     */
    fun jawaAngkaDalamTeks(teks: String): String =
        Regex("\\d+").replace(teks) { m ->
            val n = m.value.toIntOrNull()
            when {
                n == null -> m.value
                m.value.length >= 3 -> jawaTaun(n)
                else -> jawaKata(n)
            }
        }

    /** Taun diwaca kanthi puluhan biasa, ora nganggo wangun khusus 21–29. */
    fun jawaTaun(n: Int): String {
        if (n in 0..20 || n in 30..99) return jawaKata(n)
        if (n in 21..29) return ("kalih dasa " + (jawaKata(n % 10)))
        if (n in 100..999) {
            val atus = n / 100
            val sisa = n % 100
            val wiwitan = if (atus == 1) "setunggal atus" else ("" + (jawaKata(atus)) + " atus")
            return if (sisa == 0) wiwitan else ("" + (wiwitan) + " " + (jawaTaun(sisa)))
        }
        if (n in 1000..9999) {
            val ewu = n / 1000
            val sisa = n % 1000
            val wiwitan = if (ewu == 1) "setunggal ewu" else ("" + (jawaKata(ewu)) + " ewu")
            return if (sisa == 0) wiwitan else ("" + (wiwitan) + " " + (jawaTaun(sisa)))
        }
        return n.toString()
    }
}
