package com.novan.bateraibicara

import android.net.Uri
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView

/** FIX392: memutar satu saluran TV daring (HLS atau lainnya yang didukung Android) dengan VideoView. */
class TvPemutarActivity : Halaman() {
    override val judulHalaman = R.string.judul_radio_tv
    private var video: VideoView? = null
    private var status: TextView? = null

    override fun bangun() {
        val nama = intent.getStringExtra("nama").orEmpty()
        val url = intent.getStringExtra("url").orEmpty()
        PemutarSaluran.berhenti()
        bagian(nama)
        status = info(tr("Memuat siaran…", "Loading the broadcast…"))
        val v = VideoView(this)
        video = v
        root.addView(v, LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 600))
        v.setMediaController(MediaController(this).also { it.setAnchorView(v) })
        v.setOnPreparedListener { it.start(); setStatus(tr("Memutar: ", "Playing: ") + nama) }
        v.setOnErrorListener { _, _, _ -> setStatus(tr("Siaran tidak dapat diputar. Saluran mungkin sedang tidak tersedia.", "The broadcast could not be played. The channel may be unavailable.")); true }
        tombol(tr("Jeda atau lanjutkan", "Pause or resume")) { if (v.isPlaying) { v.pause(); setStatus(tr("Dijeda.", "Paused.")) } else { v.start(); setStatus(tr("Dilanjutkan.", "Resumed.")) } }
        tombol(tr("Berhenti dan kembali", "Stop and go back")) { v.stopPlayback(); finish() }
        try { v.setVideoURI(Uri.parse(url)); v.requestFocus() } catch (_: Exception) { setStatus(tr("Alamat siaran tidak valid.", "The stream address is invalid.")) }
    }

    private fun setStatus(t: String) { runOnUiThread { status?.text = t; status?.announceForAccessibility(t) } }

    override fun onDestroy() { try { video?.stopPlayback() } catch (_: Exception) { }; super.onDestroy() }
}
