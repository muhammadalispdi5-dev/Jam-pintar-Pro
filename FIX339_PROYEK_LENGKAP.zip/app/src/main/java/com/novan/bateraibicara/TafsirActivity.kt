package com.novan.bateraibicara

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Build
import android.text.InputType
import android.view.View
import android.widget.TextView

/**
 * FIX338: Kitab Tafsir. Pilih kitab, surah, dan ayat; tafsir ayat ditampilkan beserta terjemahan (bila sudah tersimpan) dan dapat dibacakan.
 * Dapat dibuka asisten suara dengan extra surah, ayat, kitab, dan baca.
 */
class TafsirActivity : Halaman() {
    override val judulHalaman = R.string.judul_tafsir

    private val simpan by lazy { getSharedPreferences("tafsir", MODE_PRIVATE) }
    private var kitab = 0
    private var surah = 1
    private var ayat = 1
    private var pembicara: Pembicara? = null
    private var berurutan = false
    private var tetap = 0
    private var generasi = 0
    private var hasilTeks = ""
    private var hasilStatus = ""
    private var muatSedang = false

    private fun ukuran(): Float = simpan.getFloat("ukuran", 20f)

    override fun onPause() { hentikanSuara(); super.onPause() }
    override fun onDestroy() { hentikanSuara(); try { pembicara?.matikan() } catch (_: Exception) { }; pembicara = null; super.onDestroy() }

    override fun bangun() {
        kitab = simpan.getInt("kitab", 0).coerceIn(0, TafsirData.daftar.size - 1)
        surah = simpan.getInt("surah", 1).coerceIn(1, 114)
        ayat = simpan.getInt("ayat", 1).coerceAtLeast(1)
        val s = intent.getIntExtra("surah", -1)
        if (s in 1..114) {
            surah = s
            ayat = intent.getIntExtra("ayat", 1).coerceAtLeast(1)
        }
        val k = intent.getIntExtra("kitab", -1)
        if (k in TafsirData.daftar.indices) kitab = k
        tetap = root.childCount
        render()
        if (s in 1..114) tampilkan(intent.getBooleanExtra("baca", false))
    }

    private fun nama(k: TafsirData.Kitab) = if (BahasaAplikasi.tampilan(this) == 1) k.nama.en else k.nama.id

    private fun render() {
        while (root.childCount > tetap) root.removeViewAt(tetap)
        info(tr("Baca tafsir ayat demi ayat dari beberapa kitab. Teks diunduh per surah dari internet sekali saja, lalu tersimpan di HP sehingga surah itu dapat dibuka tanpa internet. Anda juga dapat berkata kepada asisten: tafsir surah Al Baqarah ayat 255, atau tafsir surah Al Kahfi ayat 10 bacakan.",
            "Read tafsir verse by verse from several books. The text is downloaded once per surah, then stored on the phone so that surah opens without internet. You can also tell the assistant: tafsir surah Al Baqarah verse 255, or tafsir surah Al Kahf verse 10 read it."))
        tombol(tr("Kitab tafsir: ", "Tafsir book: ") + nama(TafsirData.daftar[kitab])) { pilihKitab() }
        tombol(tr("Surah: ", "Surah: ") + surah + ". " + PenafsirQuran.namaTampil(surah)) { pilihSurah() }
        val jumlah = PenafsirQuran.jumlahAyat(surah)
        val kolom = isian(tr("Nomor ayat (1 sampai " + jumlah + ")", "Verse number (1 to " + jumlah + ")"), ayat.toString(), InputType.TYPE_CLASS_NUMBER) { t ->
            t.toIntOrNull()?.let { if (it in 1..jumlah) ayat = it }
        }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        tombol(tr("Tampilkan tafsir ayat ini", "Show tafsir of this verse")) { tampilkan(false) }
        tombol(tr("Tampilkan dan bacakan", "Show and read aloud")) { tampilkan(true) }
        tombol(tr("Ayat sebelumnya", "Previous verse")) { pindah(-1) }
        tombol(tr("Ayat berikutnya", "Next verse")) { pindah(1) }
        tombol(tr("Bacakan berurutan dari ayat ini", "Read in order from this verse")) { berurutan = true; tampilkan(true) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara(); toast(tr("Suara dihentikan.", "Audio stopped.")) }
        tombol(tr("Pilih mesin suara pembaca", "Choose reading speech engine")) { MesinSuaraPembaca.tampilkan(this, simpan) { try { pembicara?.matikan() } catch (_: Exception) { }; pembicara = null } }
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(36f)).apply(); render(); isiHasil() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); render(); isiHasil() }
        isiHasil()
    }

    private fun isiHasil() {
        if (hasilStatus.isNotBlank()) {
            val st = TextView(this)
            st.text = hasilStatus
            st.textSize = 18f
            st.setTypeface(st.typeface, Typeface.BOLD)
            st.setTextColor(warnaAksen())
            st.setPadding(0, dp(16), 0, dp(4))
            if (Build.VERSION.SDK_INT >= 28) st.isAccessibilityHeading = true
            root.addView(st)
        }
        if (hasilTeks.isNotBlank()) {
            val tv = TextView(this)
            tv.text = hasilTeks
            tv.textSize = ukuran()
            tv.setTextColor(warnaTeks())
            tv.setLineSpacing(0f, 1.2f)
            tv.setPadding(0, dp(4), 0, dp(8))
            tv.setTextIsSelectable(true)
            root.addView(tv)
        }
    }

    private fun pilihKitab() {
        AlertDialog.Builder(this).setTitle(tr("Pilih kitab tafsir", "Choose tafsir book"))
            .setItems(TafsirData.daftar.map { nama(it) }.toTypedArray()) { _, i ->
                kitab = i; simpan.edit().putInt("kitab", i).apply(); render()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihSurah() {
        val item = (1..114).map { it.toString() + ". " + PenafsirQuran.namaTampil(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih surah", "Choose surah"))
            .setItems(item) { _, i ->
                surah = i + 1; ayat = 1; simpan.edit().putInt("surah", surah).putInt("ayat", ayat).apply(); render()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pindah(arah: Int) {
        var s = surah; var a = ayat + arah
        if (a < 1) { s = if (s > 1) s - 1 else 114; a = PenafsirQuran.jumlahAyat(s) }
        else if (a > PenafsirQuran.jumlahAyat(s)) { s = if (s < 114) s + 1 else 1; a = 1 }
        surah = s; ayat = a
        simpan.edit().putInt("surah", surah).putInt("ayat", ayat).apply()
        render()
        tampilkan(false)
    }

    private fun tampilkan(baca: Boolean) {
        if (muatSedang) return
        val jumlah = PenafsirQuran.jumlahAyat(surah)
        if (ayat !in 1..jumlah) { toast(tr("Nomor ayat tidak sesuai (surah ini punya " + jumlah + " ayat).", "Verse number is not valid (this surah has " + jumlah + " verses).")); return }
        simpan.edit().putInt("surah", surah).putInt("ayat", ayat).apply()
        val k = TafsirData.daftar[kitab]
        val s = surah; val a = ayat
        muatSedang = true
        toast(tr("Memuat tafsir...", "Loading tafsir..."))
        Thread {
            val peta = TafsirData.muat(this, k.slug, s)
            val terjemah = try { TerjemahTts.pastikanTersedia(applicationContext); TerjemahTts.teks(this, s, a) } catch (_: Exception) { null }
            runOnUiThread {
                muatSedang = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (peta == null) {
                    hasilStatus = tr("Tafsir belum dapat dimuat", "Tafsir could not be loaded")
                    hasilTeks = tr("Tafsir surah ini belum tersimpan dan tidak dapat diunduh sekarang. Hubungkan internet lalu coba lagi, atau pilih kitab lain.", "This surah's tafsir is not saved and could not be downloaded now. Connect to the internet and try again, or choose another book.")
                    render(); return@runOnUiThread
                }
                val hasil = TafsirData.untukAyat(peta, a)
                hasilStatus = nama(k) + " · " + PenafsirQuran.namaTampil(s) + " " + a
                hasilTeks = if (hasil == null) tr("Tidak ada tafsir untuk ayat ini pada kitab ini.", "There is no tafsir for this verse in this book.")
                else {
                    val sb = StringBuilder()
                    if (!terjemah.isNullOrBlank()) sb.append(tr("Terjemahan: ", "Translation: ")).append(terjemah).append("\n\n")
                    if (hasil.first != a) sb.append(tr("(Tafsir ini membahas ayat " + hasil.first + " dan seterusnya.)", "(This tafsir covers verse " + hasil.first + " onward.)")).append("\n")
                    sb.append(hasil.second)
                    sb.toString()
                }
                render()
                if (baca && hasil != null) bacakan(hasilTeks)
                else if (!baca) berurutan = false
            }
        }.start()
    }

    private fun bacakan(teks: String) {
        val urut = berurutan
        hentikanSuara()
        berurutan = urut
        val gen = generasi
        try {
            val p = pembicara ?: Pembicara(applicationContext, Prefs(this).suara("tafsir")).also { pembicara = it }
            val potongan = teks.split(Regex("(?<=[.!?؟۔])\\s+|\\n+")).map { it.trim() }.filter { it.isNotBlank() }
            p.ucapkanRangkaian(potongan, 250L) {
                runOnUiThread {
                    if (gen == generasi && berurutan && !isFinishing && !isDestroyed) {
                        var s = surah; var a = ayat + 1
                        if (a > PenafsirQuran.jumlahAyat(s)) { s = if (s < 114) s + 1 else 0; a = 1 }
                        if (s == 0) { berurutan = false; return@runOnUiThread }
                        surah = s; ayat = a
                        tampilkan(true)
                    }
                }
            }
        } catch (_: Exception) { toast(tr("Suara tidak dapat dimulai.", "Speech could not be started.")) }
    }

    private fun hentikanSuara() {
        generasi++
        berurutan = false
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
    }
}
