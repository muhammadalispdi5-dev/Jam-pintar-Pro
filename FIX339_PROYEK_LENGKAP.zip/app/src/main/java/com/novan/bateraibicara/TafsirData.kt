package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX338: kitab tafsir. Teks diunduh per surah dari proyek terbuka spa5k/tafsir_api (lewat jsDelivr atau GitHub mentah) lalu disimpan
 * di penyimpanan aplikasi sehingga surah yang pernah dibuka dapat dibaca tanpa internet. Penguraian JSON dibuat longgar
 * (beberapa bentuk kunci) karena bentuk berkas tiap edisi belum diuji di perangkat.
 */
object TafsirData {
    class Dua(val id: String, val en: String)
    private fun tr(id: String, en: String) = Dua(id, en)

    class Kitab(val slug: String, val nama: Dua, val bahasa: String, val kunci: List<String>)

    val daftar: List<Kitab> = listOf(
        Kitab("in-tafsir-jalalayn", tr("Tafsir Jalalayn (Indonesia)", "Tafsir Jalalayn (Indonesian)"), "id", listOf("jalalayn", "jalalain", "jalalen", "jalalan")),
        Kitab("id-tafsir-as-saadi", tr("Tafsir As-Sa'di (Indonesia)", "Tafsir As-Sa'di (Indonesian)"), "id", listOf("saadi", "sa'di", "sadi", "as sa di")),
        Kitab("indonesian-mokhtasar", tr("Tafsir Al-Mukhtashar (Indonesia)", "Tafsir Al-Mukhtasar (Indonesian)"), "id", listOf("mukhtashar", "mukhtasar", "mokhtasar", "muhtasar")),
        Kitab("ar-tafsir-muyassar", tr("Tafsir Al-Muyassar (Arab)", "Tafsir Al-Muyassar (Arabic)"), "ar", listOf("muyassar", "muyasar", "muaisar")),
        Kitab("ar-tafsir-ibn-kathir", tr("Tafsir Ibnu Katsir (Arab)", "Tafsir Ibn Kathir (Arabic)"), "ar", listOf("katsir", "kathir", "katir", "kasir", "ibnu katsir", "ibn kathir")),
        Kitab("ar-tafsir-al-jalalayn", tr("Tafsir Jalalayn (Arab)", "Tafsir Jalalayn (Arabic)"), "ar", listOf("jalalayn arab")),
        Kitab("en-tafisr-ibn-kathir", tr("Tafsir Ibn Kathir (Inggris)", "Tafsir Ibn Kathir (English)"), "en", listOf("kathir inggris", "ibn kathir english")),
        Kitab("en-al-jalalayn", tr("Tafsir Jalalayn (Inggris)", "Tafsir Jalalayn (English)"), "en", listOf("jalalayn inggris", "jalalayn english"))
    )

    private val kunciAyat = listOf("ayah", "verse", "aya", "ayat", "number", "id", "ayah_number", "verse_number")
    private val kunciTeks = listOf("text", "content", "tafsir", "body", "tafseer")
    private val kunciDaftar = listOf("ayahs", "verses", "tafsir", "data", "result", "results", "ayat")

    private fun berkas(c: Context, slug: String, surah: Int): File {
        val dir = File(c.applicationContext.filesDir, "tafsir/" + slug)
        dir.mkdirs()
        return File(dir, "$surah.json")
    }

    fun tersimpan(c: Context, slug: String, surah: Int): Boolean = berkas(c, slug, surah).let { it.exists() && it.length() > 2 }

    private fun ambil(alamat: String): String? {
        return try {
            val k = URL(alamat).openConnection() as HttpURLConnection
            k.connectTimeout = 12000; k.readTimeout = 25000
            k.setRequestProperty("User-Agent", "JamPintarPro-Tafsir")
            try {
                if (k.responseCode != 200) null else k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally { k.disconnect() }
        } catch (_: Exception) { null }
    }

    /** Memuat tafsir satu surah: nomor ayat ke teks. Panggil di thread latar. Null bila tidak tersimpan dan tidak dapat diunduh. */
    @Synchronized
    fun muat(c: Context, slug: String, surah: Int): Map<Int, String>? {
        val f = berkas(c, slug, surah)
        if (f.exists() && f.length() > 2) {
            val lokal = try { urai(f.readText(Charsets.UTF_8)) } catch (_: Exception) { null }
            if (lokal != null && lokal.isNotEmpty()) return lokal
            try { f.delete() } catch (_: Exception) { }
        }
        val alamat = listOf(
            "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/$slug/$surah.json",
            "https://raw.githubusercontent.com/spa5k/tafsir_api/main/tafsir/$slug/$surah.json"
        )
        for (a in alamat) {
            val teks = ambil(a) ?: continue
            val hasil = try { urai(teks) } catch (_: Exception) { null }
            if (hasil != null && hasil.isNotEmpty()) {
                try { f.writeText(teks, Charsets.UTF_8) } catch (_: Exception) { }
                return hasil
            }
        }
        return null
    }

    private fun cariDaftar(o: Any?, kedalaman: Int): JSONArray? {
        if (o is JSONArray) return o
        if (o !is JSONObject || kedalaman > 2) return null
        for (k in kunciDaftar) { val v = o.opt(k); if (v is JSONArray) return v }
        for (k in kunciDaftar) { val v = o.opt(k); if (v is JSONObject) cariDaftar(v, kedalaman + 1)?.let { return it } }
        return null
    }

    private fun urai(teks: String): Map<Int, String>? {
        val akar: Any = try { JSONObject(teks) } catch (_: Exception) { try { JSONArray(teks) } catch (_: Exception) { return null } }
        val arr = cariDaftar(akar, 0) ?: return null
        val hasil = LinkedHashMap<Int, String>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            var nomor = 0
            for (k in kunciAyat) { val n = e.optInt(k, 0); if (n > 0) { nomor = n; break } }
            if (nomor == 0) nomor = i + 1
            var isi = ""
            for (k in kunciTeks) { val s = e.optString(k, ""); if (s.isNotBlank()) { isi = s; break } }
            hasil[nomor] = isi.replace(Regex("<[^>]+>"), " ").replace(Regex("[ \\t]+"), " ").trim()
        }
        return hasil
    }

    /** Teks tafsir ayat [ayat]; bila kosong (tafsir menggabung beberapa ayat) dikembalikan teks ayat sebelumnya yang tidak kosong beserta nomornya. */
    fun untukAyat(peta: Map<Int, String>, ayat: Int): Pair<Int, String>? {
        val langsung = peta[ayat]
        if (!langsung.isNullOrBlank()) return ayat to langsung
        var k = ayat - 1
        while (k >= 1) { val t = peta[k]; if (!t.isNullOrBlank()) return k to t; k-- }
        return null
    }

    /** Kitab yang disebut dalam ucapan (dicocokkan dari kata kunci); null bila tidak disebut. */
    fun cariKitab(kandidat: List<String>): Int? {
        for (u in kandidat) {
            val s = u.lowercase().replace(Regex("[^a-z' ]"), " ").replace(Regex("\\s+"), " ")
            val arab = s.contains("arab")
            val inggris = s.contains("inggris") || s.contains("english")
            var terbaik: Int? = null
            for ((i, k) in daftar.withIndex()) {
                if (k.kunci.any { s.contains(it) }) {
                    if (arab && k.bahasa == "ar") return i
                    if (inggris && k.bahasa == "en") return i
                    if (terbaik == null) terbaik = i
                }
            }
            // "jalalayn" tanpa bahasa: Indonesia; Katsir tanpa bahasa: Arab sudah dipilih urutan daftar.
            if (terbaik != null) return terbaik
        }
        return null
    }
}
