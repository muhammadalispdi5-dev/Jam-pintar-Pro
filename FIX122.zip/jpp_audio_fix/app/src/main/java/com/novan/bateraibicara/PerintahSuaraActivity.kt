package com.novan.bateraibicara

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Calendar

/**
 * FIX84: perintah suara Beritahu Saya.
 * Dibuka dengan ketuk tahan pada ikon Beritahu Saya (pintasan aplikasi) atau ketuk tahan pada saklar
 * pemicu Beritahu Saya di layar utama aplikasi. Layar pengenalan suara sistem dibuka (tanpa izin
 * mikrofon aplikasi), lalu perintah dijalankan: waktu, tanggal, atau memutar Al-Qur'an.
 * Bahasa pengenalan, teks, dan pesan mengikuti bahasa tampilan utama yang aktif.
 */
class PerintahSuaraActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutupDanLanjutAudio() }
    private var permintaanFokusMik: AudioFocusRequest? = null
    private var fokusMikDiminta = false
    // FIX121: status menunggu pengenalan, supaya pemicu baru dapat memulai ulang pengenalan yang macet.
    private var menungguPengenalan = false
    private var waktuMulai = 0L
    private var waktuBukaSistem = 0L
    private var percobaanUlangMic = 0
    private var generasiPengenalan = 0
    // FIX122: tombol volume dan telungkup menghentikan jawaban suara; layar ditutup bila itu terjadi.
    private var volumeDikonsumsi = false
    private var generasiBungkamAwal = 0
    private val pantauBungkam = object : Runnable {
        override fun run() {
            if (selesai || isFinishing) return
            if (PembungkamTelungkup.generasi != generasiBungkamAwal) { tutupDanLanjutAudio(); return }
            handler.postDelayed(this, 400L)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) volumeDikonsumsi = false
                if (volumeDikonsumsi) return true
                if (PembungkamTelungkup.bungkamDariTombolVolume(this)) {
                    volumeDikonsumsi = true
                    tutupDanLanjutAudio()
                    return true
                }
            } else if (event.action == KeyEvent.ACTION_UP && volumeDikonsumsi) {
                volumeDikonsumsi = false
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }
    private var pengenal: SpeechRecognizer? = null
    private var sudahFallback = false
    private var percobaanSibuk = 0
    private var dipicuGoncanganSaatIni = false

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)
        val dipicuGoncangan = intent.getBooleanExtra(EXTRA_PEMICU_GONCANGAN, false)
        dipicuGoncanganSaatIni = dipicuGoncangan
        if (dipicuGoncangan) {
            // FIX95: notifikasi "Perintah suara siap" sudah tidak diperlukan setelah layar ini terbuka.
            try { getSystemService(NotificationManager::class.java).cancel(GoncanganSuaraService.NOTIFIKASI_SIAP_ID) } catch (_: Exception) { }
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
            }
        }
        if (!dipicuGoncangan && !prefs.beritahuSayaOn) {
            Toast.makeText(this, getString(R.string.beritahu_saya_nonaktif_petunjuk), Toast.LENGTH_LONG).show()
            selesai = true
            finish()
            return
        }
        // FIX120: hanya satu layar perintah suara yang boleh memegang mikrofon. Instance lama yang macet (hasil pengenalan tidak
        // pernah kembali) dahulu menumpuk dan menahan layanan pengenal suara sehingga mikrofon sulit dibuka setelah beberapa kali.
        val lama = aktif
        if (lama != null && lama !== this && !lama.isFinishing) lama.tutupPaksa()
        aktif = this
        if (savedInstanceState == null) mulai()
    }

    private fun terkunci(): Boolean =
        try { (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked } catch (_: Exception) { false }

    /**
     * FIX95: layar pengenal suara milik aplikasi lain tidak tampil di atas layar kunci, sehingga perintah suara
     * gagal saat terkunci. Untuk pemicu goncangan atau saat terkunci, pengenalan dijalankan langsung di layar ini
     * (SpeechRecognizer) bila izin mikrofon sudah diberikan; selain itu memakai layar pengenal sistem seperti biasa.
     */
    private fun bisaPengenalanDalam(): Boolean {
        if (!(dipicuGoncanganSaatIni || terkunci())) return false
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
    }

    /** Bila "Suara TalkBack saat mikrofon dipakai" dimatikan (Khatam), senyapkan TalkBack, beri getar, lalu buka mikrofon. */
    private fun mulai() {
        // FIX120: audio Khatam tidak menangani fokus audio sendiri, jadi dijeda secara eksplisit selama mikrofon dibuka
        // (dilanjutkan setelah jawaban selesai bila perintahnya tidak mengatur audio). Fokus sementara membuat pemutar latar
        // belakang ikut berhenti sebentar. Batas waktu mencegah layar ini tertahan selamanya bila pengenal tidak menjawab.
        KhatamActivity.jedakanUntukMikrofon()
        menungguPengenalan = true
        waktuMulai = SystemClock.elapsedRealtime()
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 45_000L)
        val senyap = getSharedPreferences("khatam_quran", MODE_PRIVATE).getBoolean("senyap_talkback_pergantian_audio", false)
        val dalam = bisaPengenalanDalam()
        if (senyap || dalam) {
            try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
            getar(150L)
            handler.postDelayed({
                if (isFinishing) return@postDelayed
                if (dalam && bukaPengenalanDalam()) return@postDelayed
                bukaPengenalan(false)
            }, if (dalam) 700L else 800L)
        } else {
            bukaPengenalan(true)
        }
    }

    private fun tagBahasaPengenalan(): String = when (BahasaAplikasi.tampilan(this)) {
        1 -> "en-US"
        2 -> "ar-SA"
        3 -> "jv-ID"
        4 -> "su-ID"
        else -> "id-ID"
    }

    private fun nadaSiap() {
        getar(90L)
        try {
            val nada = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            nada.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            handler.postDelayed({ try { nada.release() } catch (_: Exception) { } }, 400L)
        } catch (_: Exception) { }
    }

    private fun lepasPengenal() {
        try { pengenal?.cancel() } catch (_: Exception) { }
        try { pengenal?.destroy() } catch (_: Exception) { }
        pengenal = null
    }

    private fun keCadangan() {
        lepasPengenal()
        if (sudahFallback || isFinishing) { tutup(); return }
        sudahFallback = true
        // FIX121: beri layanan pengenal suara waktu melepas sesi lama sebelum layar sistem dibuka.
        handler.postDelayed({ if (!isFinishing && !selesai) bukaPengenalan(false) }, 500L)
    }

    /** Pengenalan suara di dalam layar ini; mengembalikan false bila tidak dapat dimulai (pemanggil beralih ke layar pengenal sistem). */
    private fun bukaPengenalanDalam(): Boolean {
        return try {
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            pengenal = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { nadaSiap() }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
                override fun onResults(results: Bundle?) {
                    val kandidat = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    lepasPengenal()
                    if (kandidat.isEmpty()) { tutupDanLanjutAudio(); return }
                    jalankan(kandidat)
                }
                override fun onError(error: Int) {
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                            lepasPengenal()
                            getar(300L)
                            Toast.makeText(this@PerintahSuaraActivity, getString(R.string.perintah_suara_tidak_terdengar), Toast.LENGTH_LONG).show()
                            tutupDanLanjutAudio()
                        }
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            if (percobaanSibuk++ < 1) {
                                lepasPengenal()
                                handler.postDelayed({ if (!isFinishing && !bukaPengenalanDalam()) keCadangan() }, 600L)
                            } else keCadangan()
                        }
                        else -> keCadangan()
                    }
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            }
            ambilFokusMikrofon() // layar pengenal sistem meminta fokus audio sendiri; hanya pengenal dalam yang perlu kita minta
            sr.startListening(i)
            true
        } catch (_: Exception) {
            lepasPengenal()
            false
        }
    }

    /** FIX95: perintah yang membuka aplikasi lain, memanggil, atau membacakan pesan pribadi meminta pengguna membuka kunci layar lebih dulu. */
    private fun denganBukaKunci(aksi: () -> Unit) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (km == null || !km.isKeyguardLocked || Build.VERSION.SDK_INT < 26) { aksi(); return }
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { handler.removeCallbacks(batasWaktu); aksi() }
            override fun onDismissCancelled() { tutup() }
            override fun onDismissError() { tutup() }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Pemicu ganda (peluncuran langsung dan notifikasi layar penuh) datang dalam hitungan detik dan tidak memulai pengenalan kedua.
        // FIX121: tetapi pemicu baru setelah >6 detik berarti pengenalan sebelumnya macet (layar sistem tampil tanpa mikrofon aktif):
        // mulai ulang dari awal, bukan mengabaikannya.
        if (!selesai && menungguPengenalan && SystemClock.elapsedRealtime() - waktuMulai > 6_000L) mulaiUlangPengenalan()
    }

    private fun mulaiUlangPengenalan() {
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        generasiPengenalan++ // hasil layar pengenal lama (dibatalkan) diabaikan
        lepasPengenal()
        lepasFokusMikrofon()
        handler.removeCallbacks(batasWaktu)
        sudahFallback = false
        percobaanSibuk = 0
        percobaanUlangMic = 0
        mulai()
    }

    private fun kodePengenalan(): Int = KODE_PENGENALAN + generasiPengenalan

    private fun pengenalDalamTersedia(): Boolean {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
    }

    /**
     * FIX121: layar pengenal sistem yang gagal memakai mikrofon (kode galat audio/klien/server/jaringan, atau dibatalkan dalam
     * kurang dari 1,5 detik tanpa sempat berbicara) diulang satu kali; bila tetap gagal, pengguna diberi tahu, bukan ditutup tanpa suara.
     */
    private fun ulangiPengenalanMikrofon() {
        if (isFinishing || selesai) return
        if (percobaanUlangMic++ < 1) {
            getar(120L)
            handler.postDelayed({
                if (isFinishing || selesai) return@postDelayed
                if (pengenalDalamTersedia() && bukaPengenalanDalam()) return@postDelayed
                bukaPengenalan(false)
            }, 900L)
        } else {
            getar(300L)
            Toast.makeText(this, getString(R.string.perintah_suara_mikrofon_gagal), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
        }
    }

    private fun bukaPengenalan(denganPetunjuk: Boolean) {
        val tagBahasa = tagBahasaPengenalan()
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasa)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasa)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                if (denganPetunjuk) putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.perintah_suara_petunjuk))
            }
            @Suppress("DEPRECATION")
            waktuBukaSistem = SystemClock.elapsedRealtime()
            startActivityForResult(intent, kodePengenalan())
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            tutup()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != kodePengenalan()) return
        val kandidat = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty() else emptyList<String>()
        if (kandidat.isEmpty()) {
            val galatMikrofon = resultCode == RecognizerIntent.RESULT_AUDIO_ERROR || resultCode == RecognizerIntent.RESULT_CLIENT_ERROR ||
                resultCode == RecognizerIntent.RESULT_SERVER_ERROR || resultCode == RecognizerIntent.RESULT_NETWORK_ERROR ||
                (resultCode == RESULT_CANCELED && SystemClock.elapsedRealtime() - waktuBukaSistem < 1_500L)
            if (galatMikrofon) { ulangiPengenalanMikrofon(); return }
            tutupDanLanjutAudio(); return
        }
        jalankan(kandidat)
    }

    private fun jalankan(kandidat: List<String>) {
        // FIX120: pengenalan selesai; lepas fokus mikrofon agar pemutar latar belakang lanjut sebelum perintah diproses,
        // dan beri batas waktu longgar untuk perintah apa pun.
        menungguPengenalan = false
        lepasFokusMikrofon()
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 120_000L)
        generasiBungkamAwal = PembungkamTelungkup.generasi
        handler.removeCallbacks(pantauBungkam)
        handler.postDelayed(pantauBungkam, 400L)
        when (PerintahSuara.tafsir(kandidat)) {
            PerintahSuara.Jenis.WAKTU -> bacakan(waktu = true, tanggal = false)
            PerintahSuara.Jenis.TANGGAL -> bacakan(waktu = false, tanggal = true)
            PerintahSuara.Jenis.WAKTU_TANGGAL -> bacakan(waktu = true, tanggal = true)
            PerintahSuara.Jenis.SEMUA -> bacakan(waktu = true, tanggal = true, lengkap = true)
            PerintahSuara.Jenis.PASARAN -> bacakanKhusus { p, c -> KalenderTanggal.pasaran(c, p.kalenderPasaranKoreksi, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_MASEHI -> bacakanKhusus { p, c -> KalenderTanggal.masehi(c, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_HIJRIAH -> bacakanKhusus { p, c ->
                KalenderTanggal.hijriah(c,
                    if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null,
                    p.bahasaAktif)
            }
            PerintahSuara.Jenis.LIBUR -> bacakanKhusus { p, _ ->
                val nasional = HariLibur.ringkasan(applicationContext, p, "national").drop(1)
                val cuti = HariLibur.ringkasan(applicationContext, p, "joint").drop(1)
                (nasional + cuti).joinToString(" ").ifBlank { pesanKosong(p, "holiday") }
            }
            PerintahSuara.Jenis.SHOLAT_BERIKUTNYA -> bacakanKhusus { p, c ->
                InfoSholat.segmen(p, c, abaikanSakelar = true).firstOrNull() ?: pesanKosong(p, "prayer")
            }
            PerintahSuara.Jenis.QURAN -> {
                // FIX96: saat terkunci, putar langsung lewat layanan latar belakang tanpa meminta buka kunci.
                // Memilih qari tetap lewat Khatam (butuh buka kunci); audio selalu memakai qari yang tersimpan.
                // FIX98: perintah dengan isyarat tambahan (pengulangan, sampai akhir, ayat berikutnya, ulangi, kecepatan, jeda)
                // selalu dijalankan pemutar latar belakang, juga saat layar tidak terkunci, karena hanya pemutar itu yang memahaminya.
                if (!PerintahSuara.adaKlausaQari(kandidat) && (terkunci() || PenafsirQuran.adaDirektif(kandidat))) putarQuranLatarBelakang(kandidat)
                else denganBukaKunci { bukaKhatam(kandidat) }
            }
            PerintahSuara.Jenis.BERHENTI_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_BERHENTI)
            PerintahSuara.Jenis.JEDA_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_JEDA)
            PerintahSuara.Jenis.LANJUT_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_LANJUT)
            PerintahSuara.Jenis.BUKA_FITUR -> denganBukaKunci { bukaFitur(PerintahSuara.fitur(kandidat)) }
            PerintahSuara.Jenis.PANGGIL -> denganBukaKunci { panggilKontak(kandidat) }
            PerintahSuara.Jenis.PESAN -> denganBukaKunci { bukaPesan(kandidat, baca = false) }
            PerintahSuara.Jenis.BACA_PESAN -> denganBukaKunci { bacaPesanTersimpan(kandidat) }
            PerintahSuara.Jenis.CARI_PESAN -> denganBukaKunci { cariPesanKontak(kandidat) }
            PerintahSuara.Jenis.BUKA_APLIKASI -> denganBukaKunci { bukaAplikasiDisebut(kandidat) }
            PerintahSuara.Jenis.LIBUR_SPESIFIK -> bacakanKhusus { p, c -> HariLibur.jawabanKhusus(applicationContext, p, PerintahSuara.kategoriLibur(kandidat), PerintahSuara.periodeLibur(kandidat), c) }
            PerintahSuara.Jenis.TIDAK_DIKENAL -> {
                val didengar = kandidat.firstOrNull().orEmpty()
                getar(300L)
                Toast.makeText(
                    this,
                    getString(R.string.perintah_suara_tidak_dikenal) + (if (didengar.isNotBlank()) " (\"" + didengar + "\")" else ""),
                    Toast.LENGTH_LONG
                ).show()
                tutupDanLanjutAudio()
            }
        }
    }

    private fun pesanKosong(p: Prefs, jenis: String): String = when (p.bahasaAktif) {
        1 -> if (jenis == "holiday") "No holiday information is available." else "Prayer time information is unavailable. Check your prayer location and schedule."
        2 -> if (jenis == "holiday") "لا تتوفر معلومات عن العطلات." else "معلومات أوقات الصلاة غير متاحة. تحقق من الموقع والجدول."
        3 -> if (jenis == "holiday") "Informasi preinan dereng cumawis." else "Informasi wekdal salat dereng cumawis. Priksa lokasi lan jadwal salat."
        4 -> if (jenis == "holiday") "Inpormasi libur teu sayogi." else "Inpormasi waktos salat teu sayogi. Pariksa lokasi sareng jadwal salat."
        else -> if (jenis == "holiday") "Informasi hari libur belum tersedia." else "Informasi waktu salat belum tersedia. Periksa lokasi dan jadwal salat."
    }

    /** Satu perintah spesifik menghasilkan satu jawaban saja; tidak menambahkan rangkaian tanggal/libur/sholat lain. */
    private fun bacakanKhusus(penyusun: (Prefs, Calendar) -> String) {
        try {
            val prefs = Prefs(applicationContext)
            val teks = penyusun(prefs, Calendar.getInstance()).trim()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    /** Waktu dibacakan suara jam; tanggal umum mengikuti pengaturan rangkaian pengguna. */
    /** [lengkap] false: hanya waktu dan/atau tanggal kalender yang diminta; true: seluruh rangkaian (termasuk libur dan salat). */
    private fun bacakan(waktu: Boolean, tanggal: Boolean, lengkap: Boolean = false) {
        try {
            val prefs = Prefs(applicationContext)
            val c = Calendar.getInstance()
            val teksWaktu = if (waktu) JamWaktu.ucapan(prefs, c) else ""
            val segmenTanggal = if (!tanggal) emptyList() else if (lengkap) JamWaktu.segmenTanggal(prefs, c) else JamWaktu.segmenKalender(prefs, c)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            fun bacaTanggal() {
                if (segmenTanggal.isEmpty()) { tutupDanLanjutAudio(); return }
                val pt = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
                pembicaraTanggal = pt
                pt.ucapkanRangkaian(segmenTanggal, 300L) { tutupDanLanjutAudio() }
            }
            if (teksWaktu.isBlank()) {
                bacaTanggal()
            } else {
                val p = Pembicara(applicationContext, prefs.suara("jam")).also { it.bisaDibungkam = true }
                pembicara = p
                p.ucapkan(teksWaktu, true) { bacaTanggal() }
            }
        } catch (_: Exception) {
            tutup()
        }
    }

    /** Membuka halaman fitur yang diminta secara langsung, tanpa menebak fitur lain. */
    private fun bukaFitur(fitur: PerintahSuara.Fitur?) {
        val tujuan = when (fitur) {
            PerintahSuara.Fitur.BATERAI -> BateraiActivity::class.java
            PerintahSuara.Fitur.JAM -> JamActivity::class.java
            PerintahSuara.Fitur.KALENDER -> KalenderActivity::class.java
            PerintahSuara.Fitur.PEMANGGIL -> PemanggilActivity::class.java
            PerintahSuara.Fitur.SHOLAT -> PrayerActivity::class.java
            PerintahSuara.Fitur.LOKASI -> LokasiTerkiniActivity::class.java
            PerintahSuara.Fitur.PEMANDU_JALAN -> PemanduJalanActivity::class.java
            PerintahSuara.Fitur.KIBLAT -> QiblaActivity::class.java
            PerintahSuara.Fitur.FASILITAS -> FasilitasTerdekatActivity::class.java
            PerintahSuara.Fitur.DOA -> TaarufDoaActivity::class.java
            PerintahSuara.Fitur.KHATAM -> KhatamActivity::class.java
            PerintahSuara.Fitur.MODE_ACARA -> ModeAcaraActivity::class.java
            PerintahSuara.Fitur.BAHASA -> BahasaActivity::class.java
            null -> null
        }
        if (tujuan == null) {
            val bahasa = Prefs(applicationContext).bahasaAktif
            val pesan = when (bahasa) {
                1 -> "I couldn't identify which app feature you meant. Please say the feature name."
                2 -> "لم أتمكن من تحديد الميزة المطلوبة. يرجى ذكر اسم الميزة."
                3 -> "Fitur ingkang dipun kersakaken dereng saged dipun mangertosi. Sebutaken nami fituripun."
                4 -> "Fitur anu dimaksud teu kahartos. Sebutkeun nami fiturna."
                else -> "Saya belum mengenali fitur yang dimaksud. Silakan sebutkan nama fiturnya."
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            tutup()
            return
        }
        try { startActivity(Intent(this, tujuan)) } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }


    /** Membuka dialer; panggilan hanya dilakukan setelah pengguna menekan tombol panggil. */
    private fun panggilKontak(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty()
        val angka = ucapan.filter { it.isDigit() || it == '+' }
        if (angka.count { it.isDigit() } < 3 && ucapan.lowercase().split(Regex("\\s+")).any { it in setOf("buka", "bukakan", "open") }) {
            try { startActivity(Intent(Intent.ACTION_DIAL)) } catch (_: Exception) { }
            tutup(); return
        }
        val nomor = if (angka.count { it.isDigit() } >= 3) angka else cariNomorKontak(ucapan)
        if (nomor.isNullOrBlank()) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "I couldn't find that contact. Check contact permission or say the phone number."
                2 -> "تعذر العثور على جهة الاتصال. تحقق من إذن جهات الاتصال أو قل رقم الهاتف."
                3 -> "Kontakipun dereng kapanggih. Priksa idin kontak utawi sebataken nomer telpon."
                4 -> "Kontak teu kapanggih. Pariksa idin kontak atanapi sebutkeun nomer telepon."
                else -> "Kontak tidak ditemukan. Periksa izin kontak atau sebutkan nomor telepon."
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show(); tutup(); return
        }
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) }
        catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun cariNomorKontak(ucapan: String): String? {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val nama = ucapan.lowercase().replace(Regex("(?i)\\b(tolong|silakan|please|call|telepon|telpon|panggil|hubungi|kontak|nomor|nomer|saya|aku)\\b"), " ").trim()
        if (nama.isBlank()) return null
        return try {
            val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
                var hasil: String? = null
                while (c.moveToNext()) {
                    val label = c.getString(1).orEmpty()
                    if (label.equals(nama, true) || label.contains(nama, true)) { hasil = c.getString(0); break }
                }
                hasil
            }
        } catch (_: Exception) { null }
    }


    /** Membacakan pesan masuk terakhir yang tersimpan dari notifikasi, bukan mengakses chat privat secara diam-diam. */
    private fun bacaPesanTersimpan(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        val isi = if (nama.isNotBlank()) RiwayatPesanSuara.cari(this, nama) else RiwayatPesanSuara.terbaru(this)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> "No recent incoming message is available in the notification history."
            2 -> "لا توجد رسالة واردة حديثة في سجل الإشعارات."
            3 -> "Pesen mlebet enggal dereng wonten ing riwayat notifikasi."
            4 -> "Teu aya talatah asup panganyarna dina riwayat béwara."
            else -> "Belum ada pesan masuk terbaru di riwayat notifikasi."
        }
        bacakanTeksLokal(teks)
    }

    private fun cariPesanKontak(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        if (nama.isBlank()) { bukaPesan(kandidat, baca = false); return }
        val isi = RiwayatPesanSuara.cari(this, nama)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> ("No recent incoming message from " + (nama) + " was found in notification history.")
            2 -> ("لم يتم العثور على رسالة واردة حديثة من " + (nama) + " في سجل الإشعارات.")
            3 -> ("Pesen mlebet enggal saking " + (nama) + " boten kapanggih ing riwayat notifikasi.")
            4 -> ("Teu kapanggih talatah asup panganyarna ti " + (nama) + " dina riwayat béwara.")
            else -> ("Tidak ditemukan pesan masuk terbaru dari " + (nama) + " di riwayat notifikasi.")
        }
        bacakanTeksLokal(teks)
    }

    private fun bacakanTeksLokal(teks: String) {
        try {
            val prefs = Prefs(applicationContext)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    /** Membuka aplikasi pesan. Pembacaan otomatis tetap mengikuti izin Notification Listener. */
    private fun bukaPesan(kandidat: List<String>, baca: Boolean) {
        val ucapan = kandidat.joinToString(" ").lowercase()
        try {
            val paket = when {
                ucapan.contains("whatsapp business") -> "com.whatsapp.w4b"
                ucapan.contains("whatsapp") || ucapan.contains("wa ") -> "com.whatsapp"
                else -> null
            }
            val intent = if (paket != null) packageManager.getLaunchIntentForPackage(paket)
                else Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            if (intent != null) startActivity(intent) else startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        if (baca) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Opened your messaging app. Incoming messages can be read aloud when notification access and message announcements are enabled."
                2 -> "تم فتح تطبيق الرسائل. يمكن قراءة الرسائل الواردة عند تفعيل الوصول إلى الإشعارات وإعلان الرسائل."
                3 -> "Aplikasi pesen sampun kabikak. Pesen mlebet saged dipunwaos nalika akses notifikasi lan pawartos pesen sampun aktif."
                4 -> "Aplikasi pesen parantos dibuka. Talatah asup tiasa dibacakeun upami aksés béwara sareng fitur maca talatah diaktipkeun."
                else -> "Aplikasi pesan dibuka. Pesan masuk dapat dibacakan jika akses notifikasi dan fitur pembacaan pesan sudah diaktifkan."
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    /** Mencocokkan nama aplikasi dengan label launcher yang terpasang. */
    private fun bukaAplikasiDisebut(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty().lowercase()
            .replace(Regex("(?i)\\b(buka|bukakan|jalankan|open|launch|aplikasi|app|tolong|please)\\b"), " ").trim()
        if (ucapan.isBlank()) { tutup(); return }
        try {
            val daftar = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val cocok = daftar.firstOrNull { it.loadLabel(packageManager).toString().equals(ucapan, true) }
                ?: daftar.firstOrNull { it.loadLabel(packageManager).toString().contains(ucapan, true) }
            val launch = cocok?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) startActivity(launch) else {
                val pesan = when (Prefs(applicationContext).bahasaAktif) {
                    1 -> "App not found. Say its name as shown on the home screen."
                    2 -> "لم يتم العثور على التطبيق. قل اسمه كما يظهر على الشاشة الرئيسية."
                    3 -> "Aplikasi boten kapanggih. Sebataken nami kados ingkang katingal ing layar utama."
                    4 -> "Aplikasi teu kapanggih. Sebutkeun nami sapertos dina layar utama."
                    else -> "Aplikasi tidak ditemukan. Sebutkan nama aplikasi seperti yang tampil di layar utama."
                }
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun putarQuranLatarBelakang(kandidat: List<String>) {
        try { PemutarQuranService.kirim(this, PemutarQuranService.ACTION_PUTAR, kandidat) }
        catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun kendaliQuran(aksi: String) {
        // FIX119: audio dari perintah putar bisa berada di pemutar Khatam ATAU di layanan latar belakang. Sebelumnya perintah
        // berhenti/jeda/lanjut hanya dikirim ke layanan, sehingga audio Khatam tetap berbunyi walau ada jawaban "dihentikan".
        val kendaliKhatam = when (aksi) {
            PemutarQuranService.ACTION_BERHENTI -> KhatamActivity.KENDALI_BERHENTI
            PemutarQuranService.ACTION_JEDA -> KhatamActivity.KENDALI_JEDA
            PemutarQuranService.ACTION_LANJUT -> KhatamActivity.KENDALI_LANJUT
            else -> null
        }
        val ditanganiKhatam = kendaliKhatam != null && KhatamActivity.kendaliLatar(kendaliKhatam)
        // Berhenti selalu juga dikirim ke layanan agar pemutar mana pun yang aktif berhenti.
        // Jeda/lanjut hanya diteruskan ke layanan bila Khatam tidak memegang audionya.
        if (aksi == PemutarQuranService.ACTION_BERHENTI || !ditanganiKhatam) {
            try { PemutarQuranService.kirim(this, aksi) }
            catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        }
        tutup()
    }

    /** Perintah putar Al-Qur'an diteruskan ke Khatam; Khatam menafsirkan surah/ayat/juz dan memutar audionya. */
    private fun bukaKhatam(kandidat: List<String>) {
        try {
            // FIX87: dari layar depan/pintasan/widget, Khatam hanya memutar audio lalu mengembalikan pengguna ke layar depan.
            // Bila perintah suara dibuka dari dalam aplikasi sendiri, pengguna tetap berada di Khatam seperti sebelumnya.
            val dariAplikasi = getIntent()?.getBooleanExtra(EXTRA_DARI_APLIKASI, false) ?: false
            // FIX98: Khatam tidak memahami isyarat pengulangan; ucapan dibersihkan agar angka "5 kali" tidak dibaca sebagai nomor ayat.
            val kandidatKhatam = if (PenafsirQuran.adaDirektif(kandidat)) PenafsirQuran.bersihkanDirektif(kandidat) else kandidat
            val intent = Intent(this, KhatamActivity::class.java).apply {
                putStringArrayListExtra(KhatamActivity.EXTRA_PERINTAH_SUARA, ArrayList(kandidatKhatam))
                putExtra(KhatamActivity.EXTRA_KEMBALI_KE_LAYAR_DEPAN, !dariAplikasi)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        menungguPengenalan = false
        // Tutup layar pengenal sistem bila masih terbuka di atas layar ini.
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        finish()
    }

    /** Perintah hanya memberi informasi atau tidak dipahami: audio Khatam yang kita jeda untuk mikrofon dilanjutkan. */
    private fun tutupDanLanjutAudio() {
        KhatamActivity.lanjutkanSetelahMikrofon()
        tutup()
    }

    /** Dipanggil instance baru: lepaskan mikrofon, pengenal, dan fokus milik instance lama tanpa memicu pelanjutan audio. */
    private fun tutupPaksa() {
        selesai = true
        menungguPengenalan = false
        handler.removeCallbacksAndMessages(null)
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        finish()
    }

    private fun ambilFokusMikrofon() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .build()
                permintaanFokusMik = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            }
            fokusMikDiminta = true
        } catch (_: Exception) { }
    }

    private fun lepasFokusMikrofon() {
        if (!fokusMikDiminta) return
        fokusMikDiminta = false
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) permintaanFokusMik?.let { am.abandonAudioFocusRequest(it) }
            else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) { }
        permintaanFokusMik = null
    }

    override fun onDestroy() {
        if (aktif === this) aktif = null
        handler.removeCallbacksAndMessages(null)
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PEMICU_GONCANGAN = "pemicu_dari_goncangan"
        private const val KODE_PENGENALAN = 6911
        @Volatile
        private var aktif: PerintahSuaraActivity? = null
        /** FIX87: diisi true oleh pemanggil di dalam aplikasi agar pengguna tidak dikirim ke layar depan. */
        const val EXTRA_DARI_APLIKASI = "perintah_suara_dari_aplikasi"
    }
}

/** Penafsir perintah suara: menilai SEMUA alternatif pengenalan, lalu memilih maksud paling spesifik. */
object PerintahSuara {
    enum class Jenis { WAKTU, TANGGAL, WAKTU_TANGGAL, SEMUA, PASARAN, TANGGAL_MASEHI, TANGGAL_HIJRIAH, LIBUR, LIBUR_SPESIFIK, SHOLAT_BERIKUTNYA, CARI_PESAN, QURAN, BERHENTI_AUDIO, JEDA_AUDIO, LANJUT_AUDIO, BUKA_FITUR, PANGGIL, PESAN, BACA_PESAN, BUKA_APLIKASI, TIDAK_DIKENAL }
    enum class Fitur { BATERAI, JAM, KALENDER, PEMANGGIL, SHOLAT, LOKASI, PEMANDU_JALAN, KIBLAT, FASILITAS, DOA, KHATAM, MODE_ACARA, BAHASA }

    private val kataWaktu = setOf("waktu", "jam", "pukul", "time", "clock", "jamnya")
    private val kataTanggal = setOf("tanggal", "hari", "tgl", "date", "today", "day", "kalender", "calendar", "pasaran")
    private val kataSemua = setOf("semua", "lengkap", "semuanya", "everything", "all", "both")
    private val kataKerjaInfo = setOf("informasikan", "informasi", "info", "beritahu", "beritahukan", "sebutkan", "katakan", "bacakan", "baca", "tolong", "tell", "say", "give", "what", "whats", "read", "announce", "saya", "me")
    private val kataQuran = setOf("surah", "surat", "sura", "ayat", "ayah", "aya", "verse", "juz", "jus", "juzz", "murattal", "mushaf", "alquran", "quran", "quranul")
    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori")
    private val kataKerjaQari = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set", "choose", "select", "switch", "change", "use")
    private val kataKerjaBuka = setOf("buka", "bukakan", "tampilkan", "tunjukkan", "lihat", "masuk", "jalankan", "open", "launch", "show", "display", "go", "navigate", "akses")

    fun tafsir(kandidat: List<String>): Jenis {
        // Alternatif pertama dari mesin ASR sering terlalu umum. Prioritas numerik memastikan
        // tanggal Hijriah/shalat/libur dan aksi fitur selalu menang dari kata "tanggal" atau "waktu" umum.
        return kandidat.mapNotNull { tafsirSatu(it) }
            .maxByOrNull { prioritas(it) } ?: Jenis.TIDAK_DIKENAL
    }

    private fun prioritas(j: Jenis): Int = when (j) {
        Jenis.TANGGAL_HIJRIAH, Jenis.TANGGAL_MASEHI, Jenis.PASARAN, Jenis.SHOLAT_BERIKUTNYA, Jenis.LIBUR, Jenis.LIBUR_SPESIFIK, Jenis.PANGGIL, Jenis.PESAN, Jenis.BACA_PESAN, Jenis.CARI_PESAN -> 110
        Jenis.BERHENTI_AUDIO, Jenis.JEDA_AUDIO, Jenis.LANJUT_AUDIO -> 120
        Jenis.QURAN -> 95
        Jenis.BUKA_FITUR -> 90
        Jenis.WAKTU_TANGGAL, Jenis.SEMUA -> 40
        Jenis.WAKTU, Jenis.TANGGAL -> 30
        else -> 0
    }

    private fun token(ucapan: String): List<String> = ucapan.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun tafsirSatu(ucapan: String): Jenis? {
        val t = token(ucapan)
        if (t.isEmpty()) return null
        val frasa = t.joinToString(" ")
        val gabung = t.joinToString("")
        val kerjaBuka = t.any { it in kataKerjaBuka }
        val panggil = t.any { it in setOf("telepon", "telpon", "panggil", "hubungi", "call", "phone", "dial") }
        val pesan = t.any { it in setOf("pesan", "sms", "message", "messages", "whatsapp", "wa", "chat", "inbox", "kotak") }
        val baca = t.any { it in setOf("baca", "bacakan", "read", "listen", "dengarkan") }
        // FIX96: kendali audio Al-Qur'an yang sedang diputar perintah suara (hanya ucapan pendek agar tidak salah tafsir).
        if (t.size <= 4) {
            if (t.any { it in setOf("berhenti", "hentikan", "stop", "henti", "matikan") }) return Jenis.BERHENTI_AUDIO
            if (t.any { it in setOf("jeda", "pause", "jedakan") }) return Jenis.JEDA_AUDIO
            if (t.any { it in setOf("lanjut", "lanjutkan", "resume", "teruskan", "continue") }) return Jenis.LANJUT_AUDIO
        }
        if (panggil) return Jenis.PANGGIL
        val cari = t.any { it in setOf("cari", "temukan", "search", "find", "from", "dari") }
        if (pesan && cari && t.any { it in setOf("ali", "bima") }) return Jenis.CARI_PESAN
        if (pesan && baca) return Jenis.BACA_PESAN
        if (pesan && (t.any { it in setOf("buka", "open", "lihat", "tampilkan", "cek", "periksa") } || t.size <= 3)) return Jenis.PESAN
        if (kerjaBuka && fiturDariToken(t) == null && t.any { it !in kataKerjaBuka && it !in setOf("aplikasi", "app", "tolong", "please") }) return Jenis.BUKA_APLIKASI
        // Aksi membuka fitur harus dibedakan dari pertanyaan informasi ("jam berapa", "tanggal apa").
        if (kerjaBuka && (t.any { it in kataQuran } || gabung.contains("quran"))) return Jenis.BUKA_FITUR
        if (kerjaBuka && fiturDariToken(t) != null) return Jenis.BUKA_FITUR
        val quran = t.any { it in kataQuran } || gabung.contains("quran")
        if (quran) return Jenis.QURAN
        // FIX98: "ulangi 3 kali", "putar lagi", dan "putar Yasin 5 kali" (nama surah tanpa kata "surah").
        val kataUlangPendek = t.any { it in setOf("ulangi", "ulang", "diulang", "mengulang", "repeat") } ||
            (t.size <= 4 && t.any { it in setOf("lagi", "again") } && t.any { it in setOf("putar", "play", "mainkan", "baca") })
        if (kataUlangPendek && t.size <= 7 && "tahun" !in t && !pesan && !panggil) return Jenis.QURAN
        if (t.any { it in setOf("putar", "putarkan", "mainkan", "play") } &&
            PenafsirQuran.tafsir(listOf(ucapan))?.let { it.surah != null || it.juz != null || it.relatif != 0 } == true) return Jenis.QURAN
        val qari = t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
        if (qari) return Jenis.QURAN
        // Pasaran Jawa diminta sendiri: jawab pasarannya saja, bukan rangkaian tanggal, libur, dan salat.
        if (t.any { it in setOf("pasaran", "pasarannya", "weton") }) return Jenis.PASARAN
        if (t.any { it in setOf("masehi", "gregorian") } || frasa.contains("tanggal masehi") || frasa.contains("gregorian date")) return Jenis.TANGGAL_MASEHI
        val kataLibur = t.any { it in setOf("libur", "liburan", "holiday", "holidays", "cuti", "vacation") } || frasa.contains("day off")
        if (kataLibur && (t.any { it in setOf("nasional", "national", "bersama", "joint", "today", "hari", "ini", "kemarin", "yesterday", "besok", "berikutnya", "mendatang", "upcoming", "next", "past", "terakhir", "lalu", "akan", "datang") })) return Jenis.LIBUR_SPESIFIK
        if (kataLibur) return Jenis.LIBUR
        if (t.any { it in setOf("hijriah", "hijriyah", "hijri", "islamic") } || frasa.contains("islamic date")) return Jenis.TANGGAL_HIJRIAH
        if (t.any { it in setOf("salat", "shalat", "sholat", "solat", "prayer", "prayers", "fajr", "subuh", "dzuhur", "zuhur", "ashar", "asar", "maghrib", "isya") } || frasa.contains("prayer time")) return Jenis.SHOLAT_BERIKUTNYA
        val waktu = t.any { it in kataWaktu }
        val tanggal = t.any { it in kataTanggal }
        val semua = t.any { it in kataSemua }
        return when {
            waktu && tanggal -> Jenis.WAKTU_TANGGAL
            waktu && semua -> Jenis.SEMUA
            tanggal && semua -> Jenis.SEMUA
            waktu -> Jenis.WAKTU
            tanggal -> Jenis.TANGGAL
            semua -> Jenis.SEMUA
            t.any { it in kataKerjaInfo } && t.size <= 3 -> Jenis.SEMUA
            else -> null
        }
    }

    /** True bila ucapan memuat klausa memilih qari ("pilih qari ..."); itu hanya dapat ditangani Khatam. */
    fun adaKlausaQari(kandidat: List<String>): Boolean = kandidat.any { u ->
        val t = token(u)
        t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
    }

    fun namaKontakPesan(kandidat: List<String>): String {
        val gabung = kandidat.joinToString(" ").lowercase()
        return if (gabung.contains("ali") && gabung.contains("bima")) "Ali Bima" else ""
    }

    fun kategoriLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return if (t.any { it in setOf("cuti", "bersama", "joint") }) "joint" else "national"
    }
    fun periodeLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return when {
            t.any { it in setOf("kemarin", "kemarinnya", "yesterday", "lampau", "lalu", "past", "terakhir") } -> "past"
            t.any { it in setOf("besok", "mendatang", "berikutnya", "selanjutnya", "upcoming", "next") } || (t.contains("akan") && t.contains("datang")) -> "next"
            else -> "today"
        }
    }

    fun fitur(kandidat: List<String>): Fitur? = kandidat.asSequence().mapNotNull { fiturDariToken(token(it)) }.firstOrNull()

    private fun fiturDariToken(t: List<String>): Fitur? {
        val f = t.joinToString(" ")
        fun ada(vararg kata: String) = kata.any { k -> f.contains(k) || t.contains(k) }
        return when {
            ada("baterai", "battery") -> Fitur.BATERAI
            ada("kalender", "calendar") -> Fitur.KALENDER
            ada("pemanggil", "penelepon", "caller", "penelpon") -> Fitur.PEMANGGIL
            ada("jadwal sholat", "jadwal salat", "pengaturan sholat", "pengaturan salat", "prayer schedule", "waktu salat", "waktu sholat") -> Fitur.SHOLAT
            ada("pemandu jalan", "navigasi", "petunjuk jalan", "route guide", "road guide") -> Fitur.PEMANDU_JALAN
            ada("lokasi terkini", "lokasi saya", "current location", "my location") -> Fitur.LOKASI
            ada("kiblat", "qibla", "arah kiblat") -> Fitur.KIBLAT
            ada("fasilitas terdekat", "nearby facilities", "tempat terdekat") -> Fitur.FASILITAS
            ada("taaruf doa", "doa", "doa harian", "daily prayer", "supplication") -> Fitur.DOA
            ada("khatam", "hafalan", "quran", "alquran", "surah", "surat", "ayat", "juz") -> Fitur.KHATAM
            ada("mode acara", "event mode") -> Fitur.MODE_ACARA
            ada("bahasa", "language settings", "pengaturan bahasa") -> Fitur.BAHASA
            ada("jam", "clock") -> Fitur.JAM
            else -> null
        }
    }
}
