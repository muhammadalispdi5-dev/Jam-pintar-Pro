package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Beranda: saklar utama, tiga kategori (Baterai, Jam, Nama Pemanggil), dan bantuan latar belakang. */
class MainActivity : Halaman() {

    override val judulHalaman = R.string.judul

    private lateinit var saklarAktif: Switch
    private lateinit var teksStatus: TextView
    private lateinit var saklarBeritahuSaya: Switch
    private var sinkron = false
    private var sinkronPemicu = false
    private val kartu = ArrayList<Pair<Button, () -> String>>()

    // Rekaman pengantar awal: diputar utuh lebih dulu pada penggunaan pertama, baru petunjuk tampil.
    private var pemutarPengantar: MediaPlayer? = null
    private var ulangPengantar = false
    private var dialogPanduanTampil = false

    // Pembaruan aplikasi (unduh dan pasang tanpa Play Store).
    private val handlerUpdate = android.os.Handler(android.os.Looper.getMainLooper())
    private var dialogUnduh: AlertDialog? = null
    private var tawaranPasangTampil = false

    private val kodeCadangkan = 4101
    private val kodePulihkan = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val panduanPrefs = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (!panduanPrefs.getBoolean("panduan_awal_ditampilkan", false)) {
            if (panduanPrefs.getBoolean("pengantar_awal_selesai", false)) {
                // Rekaman sudah pernah diputar utuh (mis. layar diputar sebelum petunjuk ditutup).
                tampilkanPanduan(panduanPertama = true)
            } else {
                mulaiPengantarAwal()
            }
        } else {
            mintaIzinNotifikasiJikaPerlu()
            tampilkanPengingatIzinMerek()
            UpdateManager.bersihkan(this)
            if (UpdateManager.terkonfigurasi() && UpdateManager.otomatisAktif(this) && UpdateManager.sudahWaktunyaCek(this)) {
                periksaPembaruan(manual = false)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Rekaman dihentikan saat aplikasi ke latar belakang; ulangi dari awal agar didengar utuh.
        if (ulangPengantar) {
            ulangPengantar = false
            mulaiPengantarAwal()
        }
    }

    override fun onStop() {
        super.onStop()
        if (pemutarPengantar != null) {
            bersihkanPemutarPengantar()
            ulangPengantar = true
        }
    }

    override fun onDestroy() {
        bersihkanPemutarPengantar()
        handlerUpdate.removeCallbacksAndMessages(null)
        try { dialogUnduh?.dismiss() } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun bersihkanPemutarPengantar() {
        val p = pemutarPengantar ?: return
        pemutarPengantar = null
        try { p.setOnCompletionListener(null) } catch (_: Exception) { }
        try { p.setOnErrorListener(null) } catch (_: Exception) { }
        try { if (p.isPlaying) p.stop() } catch (_: Exception) { }
        try { p.release() } catch (_: Exception) { }
    }

    /** Memutar rekaman pengantar awal; setelah selesai utuh barulah informasi pengembang dan petunjuk tampil. */
    private fun mulaiPengantarAwal() {
        if (pemutarPengantar != null || dialogPanduanTampil) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            val player = MediaPlayer()
            pemutarPengantar = player
            try {
                // Atribut dipasang sebelum sumber data dan prepare agar benar-benar dipakai sistem.
                player.setAudioAttributes(attrs)
                val afd = resources.openRawResourceFd(R.raw.pengantar_awal_aplikasi_jam_pintar_pro)
                try { player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                player.setOnCompletionListener { selesaiPengantarAwal() }
                player.setOnErrorListener { _, _, _ -> selesaiPengantarAwal(); true }
                player.prepare()
                player.start()
            } catch (e: Exception) {
                selesaiPengantarAwal()
            }
        } catch (e: Exception) {
            selesaiPengantarAwal()
        }
    }

    private fun selesaiPengantarAwal() {
        bersihkanPemutarPengantar()
        getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
            .putBoolean("pengantar_awal_selesai", true).apply()
        if (isFinishing || isDestroyed) return
        tampilkanPanduan(panduanPertama = true)
    }

    override fun bangun() {
        info(getString(R.string.slogan_aksesibilitas))

        saklarAktif = saklar(getString(R.string.aktifkan), prefs.enabled) { on ->
            if (!sinkron) {
                prefs.enabled = on
                if (on) BatteryTalkService.start(this) else BatteryTalkService.stop(this)
            }
        }

        teksStatus = info("")
        teksStatus.textSize = 16f

        bagian(getString(R.string.bagian_pemicu_beritahu_saya))
        saklarBeritahuSaya = saklar(getString(R.string.sw_beritahu_saya), prefs.beritahuSayaOn) { aktif ->
            if (!sinkronPemicu) {
                prefs.beritahuSayaOn = aktif
                BeritahuSayaWidgetProvider.perbaruiSemua(this)
                toast(if (aktif) R.string.beritahu_saya_diaktifkan else R.string.beritahu_saya_dimatikan)
            }
        }
        info(getString(R.string.info_beritahu_saya))

        bagian(getString(R.string.bagian_kategori))
        kartuKategori(R.string.kategori_baterai, BateraiActivity::class.java) { prefs.bateraiOn }
        kartuKategori(R.string.kategori_jam, JamActivity::class.java) { prefs.jamOn }
        kartuKategori(R.string.kategori_kalender, KalenderActivity::class.java) {
            prefs.kalenderMasehiOn || prefs.kalenderHijriOn || prefs.kalenderPasaranOn ||
                prefs.liburNasionalLampau || prefs.liburNasionalTerkini || prefs.liburNasionalMendatang ||
                prefs.cutiBersamaLampau || prefs.cutiBersamaTerkini || prefs.cutiBersamaMendatang
        }
        kartuKategori(R.string.kategori_pemanggil, PemanggilActivity::class.java) { prefs.pemOn }
        kartuKategori(R.string.kategori_sholat, PrayerActivity::class.java) { PrayerPrefs(this).enabled }
        tombol(getString(R.string.judul_mode_acara)) { startActivity(Intent(this, ModeAcaraActivity::class.java)) }
        val pemicuCepatAcara = tombol("Pemicu cepat Mode Acara dan Pertemuan. Ketuk tahan untuk mengaktifkan atau menonaktifkan; ketuk biasa untuk membuka pengaturan.") {
            startActivity(Intent(this, ModeAcaraActivity::class.java))
        }
        pemicuCepatAcara.contentDescription = "Pemicu cepat Mode Acara dan Pertemuan. Ketuk tahan untuk mengaktifkan atau menonaktifkan menggunakan cakupan dan durasi terakhir. Ketuk biasa untuk membuka pengaturan."
        pemicuCepatAcara.setOnLongClickListener {
            toast(ModeAcara.toggleCepat(this))
            perbaruiStatus()
            true
        }
        // Sediakan tindakan bernama jelas di menu tindakan TalkBack, selain gestur ketuk-tahan.
        if (Build.VERSION.SDK_INT >= 21) {
            val actionId = View.generateViewId()
            pemicuCepatAcara.setAccessibilityDelegate(object : View.AccessibilityDelegate() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfo) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info.addAction(AccessibilityNodeInfo.AccessibilityAction(actionId, "Aktifkan atau nonaktifkan Mode Acara sekarang"))
                }
                override fun performAccessibilityAction(host: View, action: Int, args: android.os.Bundle?): Boolean {
                    if (action == actionId) {
                        toast(ModeAcara.toggleCepat(this@MainActivity))
                        perbaruiStatus()
                        return true
                    }
                    return super.performAccessibilityAction(host, action, args)
                }
            })
        }
        tombol(getString(R.string.tombol_petunjuk_penggunaan)) { tampilkanPanduan(panduanPertama = false) }

        bagian(getString(R.string.bagian_cadangan))
        info(getString(R.string.info_cadangan))
        tombol(getString(R.string.tombol_cadangkan)) { mulaiCadangkan() }
        tombol(getString(R.string.tombol_pulihkan)) { mulaiPulihkan() }
        tombol(getString(R.string.tombol_reset)) { konfirmasiReset() }

        saklar(getString(R.string.sw_boot), prefs.bootOn) { prefs.bootOn = it }

        bagian(getString(R.string.bagian_latar))
        info(getString(R.string.teks_latar))
        tombol(getString(R.string.tombol_izin_perangkat)) {
            startActivity(Intent(this, IzinPerangkatActivity::class.java))
        }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

        bagian(getString(R.string.bagian_bantuan))
        info(getString(R.string.info_versi_app, UpdateManager.namaVersi(this)))
        saklar(getString(R.string.sw_update_otomatis), UpdateManager.otomatisAktif(this)) { UpdateManager.setOtomatis(this, it) }
        tombol(getString(R.string.tombol_periksa_update)) { periksaPembaruan(manual = true) }
        tombol(getString(R.string.tombol_hubungi_pengembang)) { startActivity(Intent(this, KeluhanActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        if (saklarAktif.isChecked != prefs.enabled) {
            sinkron = true
            saklarAktif.isChecked = prefs.enabled
            sinkron = false
        }
        // Pastikan layanan tetap berjalan bila saklar utama aktif.
        if (prefs.enabled) {
            try { BatteryTalkService.start(this) } catch (e: Exception) { }
        }
        perbaruiStatus()
        tawarkanPasangJikaSiap()
        if (saklarBeritahuSaya.isChecked != prefs.beritahuSayaOn) {
            sinkronPemicu = true
            saklarBeritahuSaya.isChecked = prefs.beritahuSayaOn
            sinkronPemicu = false
        }
        for ((b, teks) in kartu) b.text = teks()
    }

    private fun kartuKategori(judul: Int, tujuan: Class<*>, aktif: () -> Boolean) {
        val nama = getString(judul)
        val b = tombol(nama) { startActivity(Intent(this, tujuan)) }
        b.minimumHeight = dp(72)
        kartu.add(b to {
            nama + "\n" + getString(if (aktif()) R.string.status_aktif else R.string.status_mati)
        })
    }

    private fun tampilkanPanduan(panduanPertama: Boolean) {
        if (panduanPertama) {
            if (dialogPanduanTampil) return
            dialogPanduanTampil = true
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.judul_petunjuk_penggunaan))
            .setMessage(getString(R.string.isi_petunjuk_penggunaan))
            .setPositiveButton(getString(R.string.tombol_mengerti)) { d, _ ->
                d.dismiss()
                if (panduanPertama) {
                    getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
                        .putBoolean("panduan_awal_ditampilkan", true).apply()
                    mintaIzinNotifikasiJikaPerlu()
                }
            }
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    // ---------- Cadangkan dan pulihkan pengaturan (pemilih berkas bawaan Android; tanpa izin penyimpanan) ----------

    private fun mulaiCadangkan() {
        val nama = "JamPintarPro_cadangan_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".json"
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, nama)
        }
        try { startActivityForResult(i, kodeCadangkan) } catch (e: Exception) { toast(R.string.cadangan_tidak_didukung) }
    }

    private fun mulaiPulihkan() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(i, kodePulihkan) } catch (e: Exception) { toast(R.string.cadangan_tidak_didukung) }
    }

    @Deprecated("Memakai pemilih berkas bawaan sistem")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            kodeCadangkan -> simpanCadangan(uri)
            kodePulihkan -> konfirmasiPulihkan(uri)
        }
    }

    private fun simpanCadangan(uri: Uri) {
        try {
            val teks = CadanganPengaturan.buatJson(this)
            val keluar = contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("tidak bisa menulis")
            keluar.use { it.write(teks.toByteArray(Charsets.UTF_8)) }
            toast(R.string.cadangan_berhasil)
        } catch (e: Exception) {
            toast(R.string.cadangan_gagal)
        }
    }

    private fun konfirmasiPulihkan(uri: Uri) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pulihkan_konfirmasi_judul))
            .setMessage(getString(R.string.pulihkan_konfirmasi_isi))
            .setPositiveButton(getString(R.string.pulihkan_ya)) { d, _ ->
                d.dismiss()
                terapkanPulihan(uri)
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun konfirmasiReset() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.reset_konfirmasi_judul))
            .setMessage(getString(R.string.reset_konfirmasi_isi))
            .setPositiveButton(getString(R.string.reset_ya)) { d, _ ->
                d.dismiss()
                CadanganPengaturan.aturUlangSemua(this)
                toast(R.string.reset_berhasil)
                // Bangun ulang beranda agar semua sakelar dan status kembali ke tampilan awal.
                recreate()
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun terapkanPulihan(uri: Uri) {
        val teks = CadanganPengaturan.bacaTeks(this, uri)
        if (teks == null) {
            toast(R.string.pulihkan_gagal_baca)
            return
        }
        val jumlah = CadanganPengaturan.pulihkan(this, teks)
        if (jumlah < 0) {
            toast(R.string.pulihkan_gagal_format)
            return
        }
        CadanganPengaturan.segarkan(this)
        toast(R.string.pulihkan_berhasil)
        // Bangun ulang beranda agar semua sakelar dan status menampilkan pengaturan hasil pemulihan.
        recreate()
    }

    private fun mintaIzinNotifikasiJikaPerlu() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun perbaruiStatus() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        val persen = if (level < 0) 0 else level * 100 / skala
        val mengisi = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        teksStatus.text = getString(R.string.status_format, persen, status)
    }

    /** Pengingat sekali saja untuk HP selain Samsung agar pengguna membuka layar izin khusus merek. */
    private fun tampilkanPengingatIzinMerek() {
        val pref = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (pref.getBoolean("pengingat_izin_perangkat_tampil", false) || PerangkatIzin.samsung()) return
        // Tunggu dialog izin notifikasi sistem selesai (Android 13 ke atas) agar dua dialog tidak bertumpuk.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        pref.edit().putBoolean("pengingat_izin_perangkat_tampil", true).apply()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pengingat_izin_judul))
            .setMessage(getString(R.string.pengingat_izin_isi, PerangkatIzin.namaPerangkat()))
            .setPositiveButton(getString(R.string.pengingat_buka)) { d, _ ->
                d.dismiss()
                startActivity(Intent(this, IzinPerangkatActivity::class.java))
            }
            .setNegativeButton(getString(R.string.pengingat_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    // ---------- Pembaruan aplikasi ----------

    private fun periksaPembaruan(manual: Boolean) {
        if (!UpdateManager.terkonfigurasi()) {
            if (manual) toast(R.string.update_belum_diatur)
            return
        }
        if (manual) toast(R.string.update_memeriksa)
        UpdateManager.periksa(this) { status, info ->
            if (isFinishing || isDestroyed) return@periksa
            UpdateManager.catatCek(this)
            when (status) {
                UpdateManager.STATUS_ADA -> if (info != null) tampilkanPembaruan(info)
                UpdateManager.STATUS_TERBARU -> if (manual) toast(R.string.update_terbaru)
                else -> if (manual) toast(R.string.update_gagal_cek)
            }
        }
    }

    private fun tampilkanPembaruan(info: UpdateManager.Info) {
        val catatan = if (info.catatan.isBlank()) "" else info.catatan
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_tersedia_judul))
            .setMessage(getString(R.string.update_tersedia_isi, info.versionName, UpdateManager.namaVersi(this), catatan).trim())
            .setPositiveButton(getString(R.string.update_tombol_unduh)) { d, _ ->
                d.dismiss()
                mulaiUnduh(info)
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun mulaiUnduh(info: UpdateManager.Info) {
        val id = try { UpdateManager.unduh(this, info) } catch (e: Exception) { -1L }
        if (id < 0) {
            toast(R.string.update_gagal_unduh)
            return
        }
        dialogUnduh = AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_mengunduh_judul))
            .setMessage(getString(R.string.update_mengunduh, 0))
            .setCancelable(false)
            .setNegativeButton(getString(R.string.update_batal)) { d, _ ->
                handlerUpdate.removeCallbacksAndMessages(null)
                UpdateManager.batalkan(this, id)
                d.dismiss()
            }
            .create()
        dialogUnduh?.show()
        pantauUnduh(id)
    }

    private fun pantauUnduh(id: Long) {
        if (isFinishing || isDestroyed) return
        val h = UpdateManager.progres(this, id)
        when (h[0]) {
            android.app.DownloadManager.STATUS_SUCCESSFUL -> {
                dialogUnduh?.dismiss()
                pasangPembaruan()
            }
            android.app.DownloadManager.STATUS_FAILED, -1 -> {
                dialogUnduh?.dismiss()
                toast(R.string.update_gagal_unduh)
            }
            else -> {
                dialogUnduh?.setMessage(getString(R.string.update_mengunduh, h[1]))
                handlerUpdate.postDelayed({ pantauUnduh(id) }, 800)
            }
        }
    }

    private fun pasangPembaruan() {
        when (UpdateManager.pasang(this)) {
            UpdateManager.PASANG_MULAI -> toast(R.string.update_memulai_pasang)
            UpdateManager.PASANG_BUTUH_IZIN -> {
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.update_izin_judul))
                    .setMessage(getString(R.string.update_izin_isi))
                    .setPositiveButton(getString(R.string.update_izin_buka)) { d, _ ->
                        d.dismiss()
                        try {
                            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + packageName)))
                        } catch (e: Exception) { bukaInfoApp() }
                    }
                    .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
                    .show()
            }
            else -> toast(R.string.update_gagal_pasang)
        }
    }

    /** Bila unduhan pembaruan sudah selesai tetapi belum dipasang (mis. setelah memberi izin), tawarkan memasang. */
    private fun tawarkanPasangJikaSiap() {
        if (tawaranPasangTampil || dialogPanduanTampil || pemutarPengantar != null) return
        if (dialogUnduh?.isShowing == true) return
        if (!UpdateManager.siapDipasang(this)) return
        tawaranPasangTampil = true
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_siap_judul))
            .setMessage(getString(R.string.update_siap_isi))
            .setPositiveButton(getString(R.string.update_siap_pasang)) { d, _ ->
                d.dismiss()
                pasangPembaruan()
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }
}
