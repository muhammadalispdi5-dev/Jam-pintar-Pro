#!/usr/bin/env python3
"""Uji FIX204: kalimat yang diucapkan tidak boleh memakai templat dolar Kotlin.
Gejala: asisten membacakan "baterai tersisa persen persen status" (nama peubah terbaca sebagai kata) karena kalimat disusun dengan templat dolar.
Bagian 1: port Python penyusun kalimat baterai dan durasi timer. Bagian 2: kontrak sumber dan jumlah templat dolar per berkas (tidak boleh bertambah).
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import re, sys

def status(bahasa, mengisi):
    if bahasa == 1: return ", and charging" if mengisi else ", not charging"
    if bahasa == 3: return ", lagi diisi" if mengisi else ", ora lagi diisi"
    if bahasa == 4: return ", keur dieusi" if mengisi else ", henteu keur dieusi"
    return ", dan sedang diisi daya" if mengisi else ", tidak sedang diisi daya"

def kalimat_baterai(persen, bahasa, mengisi):
    angka = str(persen); st = status(bahasa, mengisi)
    return {1: "Battery is " + angka + " percent" + st + ".", 3: "Baterei " + angka + " persen" + st + ".",
            4: "Batré " + angka + " persén" + st + "."}.get(bahasa, "Baterai tersisa " + angka + " persen" + st + ".")

def teks_durasi(total, inggris):
    j, m, d = total // 3600, total % 3600 // 60, total % 60
    b = []
    if j > 0: b.append(str(j) + ((" hour" if j == 1 else " hours") if inggris else " jam"))
    if m > 0: b.append(str(m) + ((" minute" if m == 1 else " minutes") if inggris else " menit"))
    if d > 0 or not b: b.append(str(d) + ((" second" if d == 1 else " seconds") if inggris else " detik"))
    return " ".join(b)

gagal = []
def cek(n, k):
    if not k: gagal.append(n)

cek("baterai Indonesia, mengisi", kalimat_baterai(85, 0, True) == "Baterai tersisa 85 persen, dan sedang diisi daya.")
cek("baterai Indonesia, tidak mengisi", kalimat_baterai(5, 0, False) == "Baterai tersisa 5 persen, tidak sedang diisi daya.")
cek("baterai English", kalimat_baterai(100, 1, True) == "Battery is 100 percent, and charging.")
for b in range(5):
    for ch in (True, False):
        t = kalimat_baterai(42, b, ch)
        cek("tanpa nama peubah dan simbol dolar (bahasa %d)" % b, "$" not in t and "statusBaterai" not in t and "persen persen" not in t and "{" not in t and "42" in t)
cek("durasi campuran", teks_durasi(3930, False) == "1 jam 5 menit 30 detik")
cek("durasi English tunggal/jamak", teks_durasi(3661, True) == "1 hour 1 minute 1 second" and teks_durasi(7320, True) == "2 hours 2 minutes")
cek("durasi nol", teks_durasi(0, False) == "0 detik")
cek("durasi menit saja tanpa spasi berlebih", teks_durasi(300, False) == "5 menit")

B = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
ps = (B / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
fn = ps[ps.index("private fun bacakanBaterai()"):ps.index("private fun bacakanBateraiDenganSuara")]
cek("bacakanBaterai tanpa templat dolar", re.search(r'\$[A-Za-z_{]', fn) is None)
cek("bacakanBaterai memakai penyambungan", '"Baterai tersisa " + angka + " persen" + statusBaterai + "."' in fn)
cek("timer memakai teksDurasi", ps.count("teksDurasi(") >= 3 and '"Timer dimulai selama " + lama + "."' in ps and '"Sisa waktu timer: " + durasi + "."' in ps)
# Jumlah templat dolar per berkas tidak boleh bertambah (sisa: kunci preferensi, pola SQL, tag, dan normalisasi yang tidak diucapkan).
BATAS = {"KhatamActivity.kt": 5, "PemilihSakelar.kt": 2, "PemutarQuranService.kt": 3, "SuaraPengingat.kt": 3, "TimerJamService.kt": 1}
pola = re.compile(r'\$[A-Za-z_{]')
for f in sorted(B.glob("*.kt")):
    teks = f.read_text(encoding="utf-8")
    n = sum(1 for baris in teks.splitlines() if not baris.lstrip().startswith("//") and pola.search(baris) and '"' in baris)
    cek(f.name + ": templat dolar " + str(n) + " > batas " + str(BATAS.get(f.name, 0)), n <= BATAS.get(f.name, 0))
if gagal:
    print("UJI UCAPAN TANPA TEMPLAT DOLAR: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI UCAPAN TANPA TEMPLAT DOLAR: LULUS (port penyusun kalimat + kontrak sumber)")
