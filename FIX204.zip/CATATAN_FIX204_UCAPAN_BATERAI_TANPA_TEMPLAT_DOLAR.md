# FIX204 - Pembacaan indikator baterai: "baterai tersisa persen persen status"

Versi aplikasi tidak diubah (1.0.82, versionCode 82). Basis: FIX203. Berkas diubah: `PerintahSuaraActivity.kt`. Berkas baru: `tools/uji_ucapan_tanpa_templat_dolar.py`.

## Gejala
Perintah suara untuk membacakan indikator baterai diucapkan sebagai "baterai tersisa persen persen status", bukan "baterai tersisa 85 persen, dan sedang diisi daya".

## Penyebab (dari pembacaan kode; belum diuji di perangkat)
Kalimat disusun dengan templat dolar Kotlin ("Baterai tersisa $persen persen$statusBaterai."). Ucapan yang terdengar memuat nama peubah (persen, statusBaterai), bukan nilainya: itu pola yang sama dengan
masalah cuaca di FIX166 (kata "dolar" berulang), yang diselesaikan dengan penyambungan teks biasa. Lapisan pengaman di `Pembicara.kt` membuang simbol dolar sebelum diucapkan, sehingga nama peubah yang tersisa
terbaca sebagai kata. Penyebab pasti di jalur build tidak dapat dipastikan dari kode; yang jelas, kalimat tanpa templat dolar tidak terpengaruh.

## Perbaikan
- Kalimat baterai (lima bahasa) kini disusun dengan penyambungan teks biasa: mis. "Baterai tersisa " + angka + " persen" + status + ".".
- Tempat lain dengan pola yang sama ditemukan lewat audit seluruh kode: jawaban timer yang diucapkan ("Sisa waktu timer: ..." dan "Timer dimulai selama ..."). Keduanya kini memakai penyusun durasi `teksDurasi`
  (juga memperbaiki spasi berlebih sebelum titik dan bentuk jamak English: "1 hour", "2 hours").
- Templat pada URL cuaca dan pesan status HTTP di `PerintahSuaraActivity.kt` ikut diubah menjadi penyambungan, sehingga file itu tidak lagi memuat templat dolar.
- Templat dolar yang tersisa di berkas lain (kunci preferensi, pola pencarian berkas, tag, dan normalisasi teks internal) bukan teks yang diucapkan dan tidak diubah; jumlahnya dikunci oleh uji agar tidak bertambah.

## Bahasa aktif
Tidak ada string baru yang terlihat pengguna; kalimat tetap lima bahasa mengikuti bahasa tampilan; pemeriksa bahasa aktif dan resource string lulus.

## Pemeriksaan
- `uji_ucapan_tanpa_templat_dolar.py` lulus: port penyusun kalimat baterai dan durasi (semua bahasa, mengisi/tidak mengisi), kontrak sumber, dan batas jumlah templat dolar per berkas. Kurung Kotlin seimbang.
- Kegagalan yang sudah ada pada FIX203 asli dan tidak terkait: `verify_project.py` (arsip tidak menyertakan `.github`), `uji_mikrofon_perintah_suara.py`, dan `verify_final.py` (petunjuk penggunaan). Tidak diubah.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: ucapkan "berapa persen baterai" dalam bahasa Indonesia dan English, saat mengisi dan tidak mengisi; "sisa waktu timer" dan "pasang timer lima menit".
