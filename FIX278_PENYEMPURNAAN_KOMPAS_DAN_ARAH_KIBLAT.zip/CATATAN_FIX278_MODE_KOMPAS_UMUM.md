# FIX278 — Penyempurnaan Mode Kompas Umum dan Arah Kiblat

## Dasar perbaikan
Berkas sumber yang digunakan: `FIX277_PROYEK_LENGKAP.zip` (versi aplikasi 1.0.89, versionCode 89).

## Perubahan
1. Menambahkan pilihan pergantian antara Mode Arah Kiblat dan Mode Kompas Umum pada halaman kompas.
2. Mode Kompas Umum tidak memerlukan koordinat GPS/lokasi. Sensor orientasi tetap menjadi prasyarat.
3. Mode Kompas Umum mengenali delapan sektor mata angin: Utara, Timur Laut, Timur, Tenggara, Selatan, Barat Daya, Barat, dan Barat Laut.
4. Saat perangkat memasuki sektor arah yang berbeda, aplikasi mengumumkan nama arah melalui Text-to-Speech dan membunyikan nada panjang sekitar 1,1 detik. Nada menggunakan nada DTMF berbeda untuk tiap sektor; getaran mengikuti pengaturan getar yang sudah tersedia.
5. Pengumuman arah mengikuti bahasa tampilan aplikasi (Indonesia atau Inggris) dan tidak mengulang pengumuman terus-menerus selama perangkat tetap berada pada sektor yang sama.
6. Mode Arah Kiblat tetap menggunakan perhitungan bearing kiblat, panduan putar kiri/kanan, serta nada konfirmasi kiblat yang sudah ada.
7. Memperbaiki pesan awal agar tidak menampilkan bearing kiblat 0 derajat ketika lokasi belum diatur.

## Cara menggunakan
1. Buka menu Arah Kiblat dan Kompas.
2. Tekan tombol “Ganti Mode Kompas dan Arah Kiblat” untuk mengaktifkan Mode Kompas Umum.
3. Pegang HP mendatar dengan layar menghadap ke atas.
4. Putar HP perlahan. Aplikasi akan menyebutkan arah yang sedang dituju dan membunyikan nada panjang saat memasuki arah mata angin yang berbeda.
5. Tekan tombol pergantian mode kembali untuk memakai Mode Arah Kiblat.

## Batasan dan pengujian
- Mode kompas umum memerlukan sensor `TYPE_ROTATION_VECTOR` yang didukung perangkat. Tanpa sensor tersebut, aplikasi tidak dapat membaca arah secara langsung.
- Kompas digital dapat terpengaruh benda logam, magnet, casing magnetik, atau gangguan medan magnet. Kalibrasikan perangkat bila akurasi rendah.
- Mode kompas umum bekerja ketika halaman kompas terbuka di layar. Layanan layar mati yang sudah ada tetap merupakan panduan khusus kiblat, bukan navigasi arah umum.
- Pemeriksaan XML dan pemeriksaan statis sumber dilakukan. Lingkungan kerja ini tidak menyediakan Gradle maupun Android SDK, sehingga APK belum dapat dibangun atau diuji langsung pada perangkat. Nada dan pembacaan arah perlu diuji di HP setelah APK dibangun.
- Versi aplikasi tidak dinaikkan: `versionCode 89`, `versionName 1.0.89`.
