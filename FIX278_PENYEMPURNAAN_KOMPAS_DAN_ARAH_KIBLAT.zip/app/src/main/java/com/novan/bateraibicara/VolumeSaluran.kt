package com.novan.bateraibicara

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

/**
 * FIX273: volume pengumuman Nama Panggilan dan Pembacaan Notifikasi mengatur volume SALURAN suara yang dipilih pengguna
 * (media, alarm, notifikasi, dering, aksesibilitas, panggilan suara, atau sistem). Volume saluran dipasang saat pengumuman
 * (melodi dan ucapan) mulai dan dikembalikan ke nilai semula sesudah selesai. Pemakaian dihitung (pinjam/lepas) agar
 * melodi dan ucapan yang berurutan tidak saling mengembalikan volume. Bila pengguna sendiri mengubah volume saluran selama
 * pengumuman, nilai pilihan pengguna itu tidak ditimpa saat pengembalian.
 */
object VolumeSaluran {
    private val handler = Handler(Looper.getMainLooper())
    private var pinjaman = 0
    private var saluran = -1
    private var asal = -1
    private var diterapkan = -1
    private var pemulih: Runnable? = null
    private const val TUNDA_PULIH_MS = 2500L

    fun pinjam(ctx: Context, streamType: Int, persen: Int) {
        try {
            val am = ctx.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            pemulih?.let { handler.removeCallbacks(it) }
            pemulih = null
            if (saluran != -1 && saluran != streamType) pulihkan(am)
            if (saluran == -1) {
                saluran = streamType
                asal = am.getStreamVolume(streamType)
            }
            val maks = am.getStreamMaxVolume(streamType)
            val p = persen.coerceIn(0, 100)
            var target = if (p == 0) 0 else Math.round(maks * p / 100f).coerceIn(1, maks)
            // FIX277: pada volume maksimum, tombol volume atas tidak mengubah nilai sehingga pemantau tidak dapat mengenalinya untuk
            // menghentikan pengumuman. Bila fitur stop dengan tombol volume aktif, satu tingkat di bawah maksimum dipakai.
            if (target >= maks && maks >= 3 && PembungkamTelungkup.volumeAktif(ctx)) target = maks - 1
            try {
                PembungkamTelungkup.volumeDiubahAplikasi()
                am.setStreamVolume(streamType, target, 0)
                PembungkamTelungkup.volumeDiubahAplikasi()
                diterapkan = am.getStreamVolume(streamType)
            } catch (_: SecurityException) {
                // Saluran dering/notifikasi dapat ditolak sistem saat mode jangan ganggu aktif tanpa akses kebijakan.
                diterapkan = -1
            }
        } catch (_: Exception) { }
        pinjaman++
    }

    fun lepas(ctx: Context) {
        if (pinjaman > 0) pinjaman--
        if (pinjaman > 0 || saluran == -1) return
        val app = ctx.applicationContext
        val r = Runnable {
            pemulih = null
            if (pinjaman == 0) {
                try { pulihkan(app.getSystemService(Context.AUDIO_SERVICE) as AudioManager) } catch (_: Exception) { }
            }
        }
        pemulih = r
        handler.postDelayed(r, TUNDA_PULIH_MS)
    }

    private fun pulihkan(am: AudioManager) {
        val s = saluran
        if (s != -1 && asal >= 0) {
            try {
                // Hanya dikembalikan bila nilainya masih yang kita pasang; bila pengguna mengubahnya, biarkan.
                if (diterapkan >= 0 && am.getStreamVolume(s) == diterapkan) {
                    PembungkamTelungkup.volumeDiubahAplikasi()
                    am.setStreamVolume(s, asal, 0)
                    PembungkamTelungkup.volumeDiubahAplikasi()
                }
            } catch (_: Exception) { }
        }
        saluran = -1; asal = -1; diterapkan = -1
    }
}
