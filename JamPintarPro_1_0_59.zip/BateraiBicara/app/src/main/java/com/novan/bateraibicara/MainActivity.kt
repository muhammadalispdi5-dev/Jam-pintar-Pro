package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView

/** Beranda: saklar utama, tiga kategori (Baterai, Jam, Nama Pemanggil), dan bantuan latar belakang. */
class MainActivity : Halaman() {

    override val judulHalaman = R.string.judul

    private lateinit var saklarAktif: Switch
    private lateinit var teksStatus: TextView
    private lateinit var saklarBeritahuSaya: Switch
    private var sinkron = false
    private var sinkronPemicu = false
    private val kartu = ArrayList<Pair<Button, () -> String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val panduanPrefs = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (!panduanPrefs.getBoolean("panduan_awal_ditampilkan", false)) {
            tampilkanPanduan(panduanPertama = true)
        } else {
            mintaIzinNotifikasiJikaPerlu()
        }
    }

    override fun bangun() {
        info(getString(R.string.slogan_aksesibilitas))

        saklarAktif = saklar(getString(R.string.aktifkan), prefs.enabled) { on ->
            if (!sinkron) {
                prefs.enabled = on
                if (on) BatteryTalkService.start(this) else BatteryTalkService.stop(this)
            }
        }

        teksStatus = info("")
        teksStatus.textSize = 16f

        bagian(getString(R.string.bagian_pemicu_beritahu_saya))
        saklarBeritahuSaya = saklar(getString(R.string.sw_beritahu_saya), prefs.beritahuSayaOn) { aktif ->
            if (!sinkronPemicu) {
                prefs.beritahuSayaOn = aktif
                BeritahuSayaWidgetProvider.perbaruiSemua(this)
                toast(if (aktif) R.string.beritahu_saya_diaktifkan else R.string.beritahu_saya_dimatikan)
            }
        }
        info(getString(R.string.info_beritahu_saya))

        bagian(getString(R.string.bagian_kategori))
        kartuKategori(R.string.kategori_baterai, BateraiActivity::class.java) { prefs.bateraiOn }
        kartuKategori(R.string.kategori_jam, JamActivity::class.java) { prefs.jamOn }
        kartuKategori(R.string.kategori_kalender, KalenderActivity::class.java) {
            prefs.kalenderMasehiOn || prefs.kalenderHijriOn || prefs.kalenderPasaranOn ||
                prefs.liburNasionalLampau || prefs.liburNasionalTerkini || prefs.liburNasionalMendatang ||
                prefs.cutiBersamaLampau || prefs.cutiBersamaTerkini || prefs.cutiBersamaMendatang
        }
        kartuKategori(R.string.kategori_pemanggil, PemanggilActivity::class.java) { prefs.pemOn }
        kartuKategori(R.string.kategori_sholat, PrayerActivity::class.java) { PrayerPrefs(this).enabled }
        tombol(getString(R.string.tombol_petunjuk_penggunaan)) { tampilkanPanduan(panduanPertama = false) }

        saklar(getString(R.string.sw_boot), prefs.bootOn) { prefs.bootOn = it }

        bagian(getString(R.string.bagian_latar))
        info(getString(R.string.teks_latar))
        tombol(getString(R.string.tombol_abaikan)) { abaikanOptimasi() }
        tombol(getString(R.string.tombol_autostart)) { bukaAutostart() }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }
    }

    override fun onResume() {
        super.onResume()
        if (saklarAktif.isChecked != prefs.enabled) {
            sinkron = true
            saklarAktif.isChecked = prefs.enabled
            sinkron = false
        }
        // Pastikan layanan tetap berjalan bila saklar utama aktif.
        if (prefs.enabled) {
            try { BatteryTalkService.start(this) } catch (e: Exception) { }
        }
        perbaruiStatus()
        if (saklarBeritahuSaya.isChecked != prefs.beritahuSayaOn) {
            sinkronPemicu = true
            saklarBeritahuSaya.isChecked = prefs.beritahuSayaOn
            sinkronPemicu = false
        }
        for ((b, teks) in kartu) b.text = teks()
    }

    private fun kartuKategori(judul: Int, tujuan: Class<*>, aktif: () -> Boolean) {
        val nama = getString(judul)
        val b = tombol(nama) { startActivity(Intent(this, tujuan)) }
        b.minimumHeight = dp(72)
        kartu.add(b to {
            nama + "\n" + getString(if (aktif()) R.string.status_aktif else R.string.status_mati)
        })
    }

    private fun tampilkanPanduan(panduanPertama: Boolean) {
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.judul_petunjuk_penggunaan))
            .setMessage(getString(R.string.isi_petunjuk_penggunaan))
            .setPositiveButton(getString(R.string.tombol_mengerti)) { d, _ ->
                d.dismiss()
                if (panduanPertama) {
                    getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
                        .putBoolean("panduan_awal_ditampilkan", true).apply()
                    mintaIzinNotifikasiJikaPerlu()
                }
            }
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    private fun mintaIzinNotifikasiJikaPerlu() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun perbaruiStatus() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        val persen = if (level < 0) 0 else level * 100 / skala
        val mengisi = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        teksStatus.text = getString(R.string.status_format, persen, status)
    }

    private fun abaikanOptimasi() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast(R.string.sudah_diizinkan)
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse(("package:" + (packageName))))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                bukaInfoApp()
            }
        }
    }

    private fun bukaAutostart() {
        val kandidat = listOf(
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
            "com.oplus.battery" to "com.oplus.startupapp.view.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity"
        )
        for ((paket, kelas) in kandidat) {
            try {
                startActivity(Intent().setComponent(ComponentName(paket, kelas)))
                return
            } catch (e: Exception) { }
        }
        toast(R.string.autostart_tidak_ada)
        bukaInfoApp()
    }
}
