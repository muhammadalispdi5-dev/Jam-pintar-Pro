package com.novan.bateraibicara

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Pengingat lokal harian untuk membaca Al-Qur'an. */
class KhatamReminderReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("pengingat_aktif", false)) return
        val english = BahasaAplikasi.tampilan(context) == 1
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "khatam_quran_reminder"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, if (english) "Qur'an reading reminder" else "Pengingat membaca Al-Qur'an", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(context, 6902, Intent(context, KhatamActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, channelId)
            else android.app.Notification.Builder(context)
        val notification = builder
            .setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(if (english) "A gentle Qur'an reminder" else "Pengingat membaca Al-Qur'an")
            .setContentText(if (english) "Continue at your own pace. Every verse counts." else "Lanjutkan sesuai kemampuan. Setiap ayat berarti.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { manager.notify(6903, notification) } catch (_: SecurityException) { }
    }
}
