package com.novan.bateraibicara

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.AudioAttributes
import android.os.Bundle
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/** Pemutar pengingat azan yang berjalan dari alarm meski layar mati. */
class PrayerAlarmService : Service() {

    override fun attachBaseContext(newBase: Context) {
        // FIX70: teks notifikasi layanan ini mengikuti bahasa tampilan utama aplikasi, bukan bahasa sistem HP.
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    private var player: MediaPlayer? = null
    private var isTestPlayback = false
    private var reminderTts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var serviceAktif = true

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action.orEmpty()
        if (action == "com.novan.jambicarapro.PAUSE_TEST_PLAYBACK" || action == "com.novan.jambicarapro.RESUME_TEST_PLAYBACK" || action == "com.novan.jambicarapro.STOP_TEST_PLAYBACK" || action == "com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK") {
            val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
            if (!state.getBoolean("test_playback_active", false)) { stopSelf(startId); return START_NOT_STICKY }
            val kunciTes = state.getString("test_playback_key", "") ?: ""
            when (action) {
                "com.novan.jambicarapro.PAUSE_TEST_PLAYBACK" -> {
                    try {
                        jedaTes(kunciTes, startId)
                        state.edit().putBoolean("test_playback_paused", true).apply()
                    } catch (_: Exception) { }
                }
                "com.novan.jambicarapro.RESUME_TEST_PLAYBACK" -> {
                    try {
                        lanjutTes(kunciTes, startId)
                        state.edit().putBoolean("test_playback_paused", false).apply()
                    } catch (_: Exception) { }
                }
                "com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK" -> {
                    try {
                        if (state.getBoolean("test_playback_paused", false)) {
                            lanjutTes(kunciTes, startId)
                            state.edit().putBoolean("test_playback_paused", false).apply()
                        } else {
                            jedaTes(kunciTes, startId)
                            state.edit().putBoolean("test_playback_paused", true).apply()
                        }
                    } catch (_: Exception) { }
                }
                else -> { state.edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply(); stopPlayback(); try { reminderTts?.stop() } catch (_: Exception) { }; if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true); stopSelf(startId); return START_NOT_STICKY }
            }
            updateTestNotification(state.getBoolean("test_playback_paused", false))
            return START_NOT_STICKY
        }
        if (action == "com.novan.jambicarapro.STOP_PRAYER_SOUND") {
            stopPlayback()
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (action == "com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK") {
            try { if (player?.isPlaying == true) player?.pause() else player?.start() } catch (_: Exception) { }
            return START_NOT_STICKY
        }
        val key = intent?.getStringExtra("prayer_key") ?: "subuh"
        val test = intent?.getBooleanExtra("test", false) ?: false
        if (ModeAcara.aktif(this)) { stopSelf(startId); return START_NOT_STICKY }
        val pp = PrayerPrefs(this)
        isTestPlayback = test
        val berbukaReminder = intent?.getBooleanExtra("berbuka_reminder", false) ?: false
        if (berbukaReminder) {
            val testBerbuka = intent?.getBooleanExtra("test", false) ?: false
            if (!testBerbuka && (!pp.enabled || !pp.berbukaReminderEnabled || !pp.locationSet)) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val offset = intent?.getIntExtra("berbuka_offset", pp.berbukaOffsetMinutes) ?: pp.berbukaOffsetMinutes
            val waktu = when {
                offset < 0 -> ("" + (-offset) + " menit sebelum Maghrib")
                offset > 0 -> ("" + (offset) + " menit setelah Maghrib")
                else -> "tepat saat Maghrib"
            }
            val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
            val message = FastingSchedule.berbukaMessage(pp.fastingType, offset, bahasaAktif, testBerbuka)
            val notificationMessage = FastingSchedule.berbukaMessage(pp.fastingType, offset, if (BahasaAplikasi.tampilan(this) == 1) 1 else 0, testBerbuka)
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(BahasaAplikasi.teks(this, if (testBerbuka) "Tes suara pengingat berbuka puasa" else "Pengingat waktu berbuka puasa"))
                .setContentText(notificationMessage).setContentIntent(open).setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            pasangBungkam(testBerbuka)
            if (testBerbuka) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false).putString("test_playback_key", "berbuka").apply()
            mulaiDenganMelodiPuasa("berbuka", startId, testBerbuka) {
                when (pp.reminderSoundMode("berbuka")) {
                    1, 3 -> playEmbeddedBerbukaSound(startId, testBerbuka)
                    2 -> {
                        val custom = pp.sound("berbuka")
                        if (custom.isNotBlank()) playSound(custom, pp.volumeMode, startId, "berbuka", testBerbuka)
                        else playEmbeddedBerbukaSound(startId, testBerbuka)
                    }
                    else -> playSound(pp.globalSound, pp.volumeMode, startId, "berbuka", testBerbuka)
                }
            }
            return START_NOT_STICKY
        }
        val sahurReminder = intent?.getBooleanExtra("sahur_reminder", false) ?: false
        if (sahurReminder) {
            val testSahur = intent?.getBooleanExtra("test", false) ?: false
            if (!testSahur && (!pp.enabled || !pp.sahurReminderEnabled || !pp.locationSet)) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val lead = intent?.getIntExtra("sahur_minutes", pp.sahurReminderMinutes) ?: pp.sahurReminderMinutes
            val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
            val message = FastingSchedule.sahurMessage(pp.fastingType, lead, bahasaAktif, testSahur)
            val notificationMessage = FastingSchedule.sahurMessage(pp.fastingType, lead, if (BahasaAplikasi.tampilan(this) == 1) 1 else 0, testSahur)
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(BahasaAplikasi.teks(this, if (testSahur) "Tes suara pemberitahuan sahur" else "Pengingat waktu sahur")).setContentText(notificationMessage)
                .setContentIntent(open).setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            pasangBungkam(testSahur)
            if (testSahur) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false).putString("test_playback_key", "sahur").apply()
            mulaiDenganMelodiPuasa("sahur", startId, testSahur) {
                when (pp.reminderSoundMode("sahur")) {
                    1 -> ucapkanPengingatAwal(message, startId, testSahur, UcapanSholat.locale(bahasaAktif))
                    2 -> {
                        val custom = pp.sound("sahur")
                        if (custom.isNotBlank()) playSound(custom, pp.volumeMode, startId, "sahur", testSahur)
                        else playEmbeddedSahurSound(startId, testSahur)
                    }
                    3 -> playEmbeddedSahurSound(startId, testSahur)
                    else -> playSound(pp.globalSound, pp.volumeMode, startId, "sahur", testSahur)
                }
            }
            return START_NOT_STICKY
        }
        val advanceReminder = intent?.getBooleanExtra("advance_reminder", false) ?: false
        if (advanceReminder) {
            if (!test && (!pp.enabled || !pp.advanceReminder(key))) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val lead = pp.advanceMinutes(key)
            // Notifikasi dan TTS pengingat mengikuti bahasa tampilan utama aplikasi.
            val bahasaTampilanInggris = BahasaAplikasi.tampilan(this) == 1
            val labelNotifikasi = if (bahasaTampilanInggris) UcapanSholat.nama(key, 1) else PrayerAlarm.label(key)
            val title = if (bahasaTampilanInggris) {
                if (test) ("Tes pengingat sebelum salat: " + (labelNotifikasi)) else ("Pengingat sebelum salat: " + (labelNotifikasi))
            } else {
                if (test) ("Tes suara pengingat sebelum salat " + (labelNotifikasi)) else ("Pengingat sebelum salat " + (labelNotifikasi))
            }
            val message = if (bahasaTampilanInggris) {
                ("Waktu salat " + (labelNotifikasi) + " tinggal " + (lead) + " menit lagi.")
            } else {
                ("Waktu salat " + (labelNotifikasi) + " tinggal " + (lead) + " menit lagi.")
            }
            val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
            val pesanSuara = UcapanSholat.pengingatAwal(key, lead, bahasaAktif)
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title).setContentText(message).setContentIntent(open)
                .setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            pasangBungkam(test)
            if (test) {
                // Tes baru: bersihkan sisa ucapan/penutup tes sebelumnya agar jeda dan lanjut selalu menyasar tes ini saja.
                batalkanPenutupTts()
                try { reminderTts?.stop() } catch (_: Exception) { }
                getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                    .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false)
                    .putString("test_playback_key", ("advance_" + (key))).apply()
                updateTestNotification(false)
            }
            mulaiDenganMelodiPuasa("advance_" + key, startId, test) {
                when (pp.advanceSoundMode(key)) {
                    1 -> playEmbeddedAdvanceSound(key, startId, test)
                    2 -> {
                        val customSound = pp.advanceSound(key)
                        if (customSound.isNotBlank()) playSound(customSound, pp.volumeMode, startId, "advance_custom", test)
                        else ucapkanPengingatAwal(pesanSuara, startId, test, UcapanSholat.locale(bahasaAktif))
                    }
                    else -> ucapkanPengingatAwal(pesanSuara, startId, test, UcapanSholat.locale(bahasaAktif))
                }
            }
            return START_NOT_STICKY
        }
        if (test) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
            .putBoolean("test_playback_active", true)
            .putBoolean("test_playback_paused", false)
            .putString("test_playback_key", key)
            .apply()
        if (!test && (!pp.enabled || !pp.reminder(key))) { stopSelf(startId); return START_NOT_STICKY }
        createChannel()
        val title = BahasaAplikasi.teks(this, if (test) ("Tes suara azan " + PrayerAlarm.label(key)) else ("Saatnya menunaikan sholat " + PrayerAlarm.label(key)))
        val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND")
        val stopPi = PendingIntent.getService(this, 810, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = n.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(BahasaAplikasi.teks(this, if (pp.notifyOnly && !test) "Pengingat waktu sholat" else "Pengingat waktu sholat dan suara azan"))
            .setContentIntent(open).setAutoCancel(false).setOngoing(true)
        val toggleIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK")
        val togglePi = PendingIntent.getService(this, 811, toggleIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        if (test) {
            val pauseIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.PAUSE_TEST_PLAYBACK")
            val resumeIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.RESUME_TEST_PLAYBACK")
            val pausePi = PendingIntent.getService(this, 812, pauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val resumePi = PendingIntent.getService(this, 813, resumeIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(android.R.drawable.ic_media_pause, BahasaAplikasi.teks(this, "Jeda tes suara azan"), pausePi)
            builder.addAction(android.R.drawable.ic_media_play, BahasaAplikasi.teks(this, "Lanjutkan tes suara azan"), resumePi)
            val stopTestIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_TEST_PLAYBACK")
            val stopTestPi = PendingIntent.getService(this, 814, stopTestIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan tes suara azan"), stopTestPi)
        } else {
            builder.addAction(android.R.drawable.ic_media_play, BahasaAplikasi.teks(this, "Jeda atau lanjutkan suara azan"), togglePi)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan suara azan"), stopPi)
        }
        val notification = builder.build()
        startForeground(809, notification)
        if (pp.notifyOnly && !test) { handler.postDelayed({ stopSelf(startId) }, 2500); return START_NOT_STICKY }
        val putarSuaraPengingat = {
            if (key == "imsak" || key == "terbit" || key == "dhuha") {
                when (pp.reminderSoundMode(key)) {
                    1 -> playEmbeddedReminderSound(key, startId, test)
                    3 -> playEmbeddedReminderSound(key, startId, test)
                    2 -> {
                        val ownSound = pp.sound(key)
                        if (ownSound.isNotBlank()) playSound(ownSound, pp.volumeMode, startId, key, test)
                        else playSound(pp.globalSound, pp.volumeMode, startId, key, test)
                    }
                    else -> playSound(pp.globalSound, pp.volumeMode, startId, key, test)
                }
            } else {
                playSound(pp.sound(key).ifBlank { pp.globalSound }, pp.volumeMode, startId, key, test)
            }
        }
        if (key in setOf("imsak", "terbit", "dhuha", "tahajud")) {
            mulaiDenganMelodiPuasa(key, startId, test, putarSuaraPengingat)
        } else putarSuaraPengingat()
        pasangBungkam(test)
        return START_NOT_STICKY
    }

    /**
     * Memutar audio bawaan (res/raw) lewat saluran volume pilihan pengguna.
     * Atribut audio HARUS dipasang pada MediaPlayer() sebelum sumber data/prepare; MediaPlayer.create()
     * sudah memanggil prepare sehingga setAudioAttributes sesudahnya ditolak sistem dan suara jatuh
     * ke volume media.
     */
    private fun playRawSound(resource: Int, startId: Int, test: Boolean, afterCompletion: (() -> Unit)? = null) {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(usageUntukVolume(PrayerPrefs(this).volumeMode))
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                val afd = this@PrayerAlarmService.resources.openRawResourceFd(resource)
                try { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                setOnCompletionListener {
                    if (afterCompletion != null) afterCompletion()
                    else if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test)
                    else { if (test) clearTestState(); stopSelf(startId) }
                }
                setOnErrorListener { _, _, _ ->
                    if (afterCompletion != null) afterCompletion()
                    else if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test)
                    else { if (test) clearTestState(); stopSelf(startId) }
                    true
                }
                prepare(); start()
            }
            handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, 180_000L)
        } catch (_: Exception) {
            if (test) clearTestState()
            stopSelf(startId)
        }
    }

    private fun playEmbeddedReminderSound(key: String, startId: Int, test: Boolean) {
        stopPlayback()
        val resource = when (key) {
            "imsak" -> R.raw.pemberitahuan_imsak
            "terbit" -> R.raw.pemberitahuan_matahari_terbit
            "dhuha" -> R.raw.pemberitahuan_dhuha
            else -> return
        }
        playRawSound(resource, startId, test)
    }

    private fun playEmbeddedBerbukaSound(startId: Int, test: Boolean) {
        stopPlayback()
        val pp = PrayerPrefs(this)
        val bahasa = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
        val message = FastingSchedule.berbukaMessage(pp.fastingType, pp.berbukaOffsetMinutes, bahasa, test)
        // Audio bawaan tetap diputar, kemudian TTS menyebutkan jenis puasa yang dipilih.
        playRawSound(R.raw.pemberitahuan_berbuka_puasa, startId, test) {
            ucapkanPengingatAwal(message, startId, test, UcapanSholat.locale(bahasa))
        }
    }

    private fun playEmbeddedSahurSound(startId: Int, test: Boolean) {
        stopPlayback()
        val pp = PrayerPrefs(this)
        val bahasa = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
        val message = FastingSchedule.sahurMessage(pp.fastingType, pp.sahurReminderMinutes, bahasa, test)
        // Audio bawaan tetap diputar, kemudian TTS menyebutkan jenis puasa yang dipilih.
        playRawSound(R.raw.pemberitahuan_sahur, startId, test) {
            ucapkanPengingatAwal(message, startId, test, UcapanSholat.locale(bahasa))
        }
    }

    private fun playEmbeddedAdvanceSound(key: String, startId: Int, test: Boolean) {
        stopPlayback()
        val resource = when (key) {
            "subuh" -> R.raw.pengingat_sebelum_subuh
            "dzuhur" -> R.raw.pengingat_sebelum_dzuhur
            "ashar" -> R.raw.pengingat_sebelum_ashar
            "maghrib" -> R.raw.pengingat_sebelum_maghrib
            "isya" -> R.raw.pengingat_sebelum_isya
            else -> R.raw.pengingat_sebelum_subuh
        }
        playRawSound(resource, startId, test)
    }

    /** Padanan jenis stream lama; beberapa mesin suara (TTS) hanya menaati parameter stream ini. */
    private fun streamUntukVolume(mode: Int): Int = when (mode) {
        0 -> AudioManager.STREAM_MUSIC
        1 -> AudioManager.STREAM_ALARM
        2 -> AudioManager.STREAM_NOTIFICATION
        3 -> AudioManager.STREAM_RING
        4 -> if (Build.VERSION.SDK_INT >= 26) 10 else AudioManager.STREAM_MUSIC // STREAM_ACCESSIBILITY
        5 -> AudioManager.STREAM_VOICE_CALL
        6 -> AudioManager.STREAM_SYSTEM
        else -> AudioManager.STREAM_ALARM
    }

    private fun usageUntukVolume(mode: Int): Int = when (mode) {
        0 -> AudioAttributes.USAGE_MEDIA
        1 -> AudioAttributes.USAGE_ALARM
        2 -> AudioAttributes.USAGE_NOTIFICATION
        3 -> AudioAttributes.USAGE_NOTIFICATION_RINGTONE
        4 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
        5 -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        6 -> AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
        else -> AudioAttributes.USAGE_ALARM
    }

    private fun playSound(uriString: String, volumeMode: Int, startId: Int, key: String, test: Boolean) {
        stopPlayback()
        try {
            val usage = usageUntukVolume(volumeMode)
            val attrs = AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            if (uriString.isNotBlank()) {
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    setDataSource(this@PrayerAlarmService, Uri.parse(uriString))
                    setOnCompletionListener { if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) } }
                    setOnErrorListener { _, _, _ -> if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) }; true }
                    prepare(); start()
                }
                handler.postDelayed({ stopSelf(startId) }, 180_000L)
            } else {
                // Audio azan bawaan dibawa dari APK referensi: azan Subuh dan azan umum.
                val resource = if (key == "subuh") R.raw.azan_subuh else R.raw.azan_biasa
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    val afd = this@PrayerAlarmService.resources.openRawResourceFd(resource)
                    try { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                    setOnCompletionListener { if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) } }
                    setOnErrorListener { _, _, _ -> if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) }; true }
                    prepare(); start()
                }
                handler.postDelayed({ stopSelf(startId) }, 240_000L)
            }
        } catch (_: Exception) {
            // Berkas suara kustom bisa hilang atau izin aksesnya dicabut; azan bawaan tetap diputar
            // agar pengguna tunanetra tidak kehilangan pengingat waktu sholat.
            if (uriString.isNotBlank() && key != "advance_custom") playSound("", volumeMode, startId, key, test) else stopSelf(startId)
        }
    }

    /**
     * FIX74: menelungkupkan HP menghentikan azan, semua pengingat (awal, sahur, berbuka, Imsak, Terbit, Dhuha, dll.)
     * dan ucapan pengingat. Tes suara dikecualikan. Pendeteksian gerakan dikelola PembungkamTelungkup.
     */
    private fun pasangBungkam(test: Boolean) {
        if (test) return
        PembungkamTelungkup.mulai(this, "alarm_sholat", 240_000L) {
            stopPlayback()
            try { reminderTts?.stop() } catch (_: Exception) { }
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf()
        }
    }

    private fun ucapkanPengingatAwal(teks: String, startId: Int, test: Boolean = false, bahasa: Locale? = null) {
        try {
            reminderTts?.shutdown()
            reminderTts = TextToSpeech(applicationContext) { status ->
                val engine = reminderTts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    // Ikuti pilihan "volume keluaran" pengguna agar pengingat terdengar sama keras dengan azan.
                    try {
                        engine.setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(usageUntukVolume(PrayerPrefs(this@PrayerAlarmService).volumeMode))
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    } catch (_: Exception) { }
                    val bahasaAktif = bahasa ?: if (BahasaAplikasi.tampilan(this@PrayerAlarmService) == 1) Locale.ENGLISH else Locale("id", "ID")
                    val languageResult = engine.setLanguage(bahasaAktif)
                    if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        // Keep the selected app language as the fallback rather than forcing Indonesian.
                        engine.language = bahasaAktif
                    }
                    if (Build.VERSION.SDK_INT >= 21) {
                        // Pengingat (sebelum azan, imsak, matahari terbit) memakai stream pilihan pengguna
                        // (bawaan: alarm) sehingga tidak ikut berubah saat tombol volume media ditekan.
                        val parameter = Bundle()
                        parameter.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, streamUntukVolume(PrayerPrefs(this@PrayerAlarmService).volumeMode))
                        engine.speak(teks, TextToSpeech.QUEUE_FLUSH, parameter, ("pengingat_awal_" + (startId)))
                    } else {
                        @Suppress("DEPRECATION")
                        engine.speak(teks, TextToSpeech.QUEUE_FLUSH, null)
                    }
                    jadwalkanPenutupTts(test, startId, 15000L)
                } else {
                    jadwalkanPenutupTts(test, startId, 5000L)
                }
            }
        } catch (_: Exception) {
            jadwalkanPenutupTts(test, startId, 5000L)
        }
    }

    private var penutupTts: Runnable? = null
    @Volatile private var kunciMelodiPengingatPuasa: String? = null

    private fun mulaiDenganMelodiPuasa(key: String, startId: Int, test: Boolean, aksi: () -> Unit) {
        kunciMelodiPengingatPuasa = key
        val pp = PrayerPrefs(this)
        val melodi = when {
            key == "sahur" -> pp.sahurMelodiAwal
            key == "berbuka" -> pp.berbukaMelodiAwal
            key.startsWith("advance_") -> pp.advanceMelodyBefore(key.removePrefix("advance_"))
            key in setOf("imsak", "terbit", "dhuha", "tahajud") -> pp.reminderMelodyBefore(key)
            else -> 0
        }
        if (melodi > 0) Melodi.putar(this, melodi, volume = 1f) { if (serviceAktif) aksi() }
        else aksi()
    }

    private fun akhiriPengingatPuasa(startId: Int, test: Boolean) {
        val key = kunciMelodiPengingatPuasa
        if (key == null) { if (test) clearTestState(); stopSelf(startId); return }
        kunciMelodiPengingatPuasa = null
        val pp = PrayerPrefs(this)
        val melodi = when {
            key == "sahur" -> pp.sahurMelodiAkhir
            key == "berbuka" -> pp.berbukaMelodiAkhir
            key.startsWith("advance_") -> pp.advanceMelodyAfter(key.removePrefix("advance_"))
            key in setOf("imsak", "terbit", "dhuha", "tahajud") -> pp.reminderMelodyAfter(key)
            else -> 0
        }
        val selesai = { if (test) clearTestState(); stopSelf(startId) }
        if (melodi > 0) Melodi.putar(this, melodi, volume = 1f, selesai = selesai) else selesai()
    }

    private fun batalkanPenutupTts() {
        penutupTts?.let { handler.removeCallbacks(it) }
        penutupTts = null
    }

    /** Penutup otomatis tes/pengingat berbasis TTS; satu penutup aktif pada satu waktu agar jeda tidak dipotong oleh penutup lama. */
    private fun jadwalkanPenutupTts(test: Boolean, startId: Int, tundaMs: Long) {
        batalkanPenutupTts()
        val r = Runnable { if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) } }
        penutupTts = r
        handler.postDelayed(r, tundaMs)
    }

    /** Tes yang sedang aktif berbunyi lewat mesin TTS (bukan MediaPlayer)? */
    private fun tesPakaiTts(kunci: String): Boolean {
        val pp = PrayerPrefs(this)
        if (kunci == "sahur") return pp.reminderSoundMode("sahur") == 1
        if (kunci.startsWith("advance_")) {
            val k = kunci.removePrefix("advance_")
            return when (pp.advanceSoundMode(k)) {
                1 -> false
                2 -> pp.advanceSound(k).isBlank()
                else -> true
            }
        }
        return false
    }

    /** Jeda tes: pemutar berkas dijeda di tempat; TTS tidak bisa dijeda di tengah kalimat sehingga dihentikan (dan diucapkan ulang saat dilanjutkan). */
    private fun jedaTes(kunci: String, startId: Int) {
        if (tesPakaiTts(kunci)) {
            reminderTts?.stop()
            // Tanpa penutup lama; beri batas aman agar layanan tidak menggantung bila lupa dilanjutkan.
            jadwalkanPenutupTts(true, startId, 600_000L)
        } else {
            player?.pause()
        }
    }

    private fun lanjutTes(kunci: String, startId: Int) {
        if (tesPakaiTts(kunci)) mulaiUlangTesTts(kunci, startId) else player?.start()
    }

    /** Ucapan tes yang sama seperti saat tes dimulai. */
    private fun mulaiUlangTesTts(kunci: String, startId: Int) {
        val pp = PrayerPrefs(this)
        val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
        if (kunci == "sahur") {
            ucapkanPengingatAwal(BahasaAplikasi.teks(this, ("Tes suara pemberitahuan sahur. Waktu sahur tinggal " + (pp.sahurReminderMinutes) + " menit sebelum Imsak.")), startId, true, if (BahasaAplikasi.tampilan(this@PrayerAlarmService) == 1) Locale.ENGLISH else Locale("id", "ID"))
        } else if (kunci.startsWith("advance_")) {
            val k = kunci.removePrefix("advance_")
            ucapkanPengingatAwal(UcapanSholat.pengingatAwal(k, pp.advanceMinutes(k), bahasaAktif), startId, true, UcapanSholat.locale(bahasaAktif))
        }
    }

    private fun updateTestNotification(paused: Boolean) {
        val pp = PrayerPrefs(this)
        val key = getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getString("test_playback_key", "subuh") ?: "subuh"
        val judulTes = BahasaAplikasi.teks(this, when {
            key == "sahur" -> "Tes suara pemberitahuan sahur"
            key.startsWith("advance_") -> "Tes suara pengingat sebelum salat " + PrayerAlarm.label(key.removePrefix("advance_"))
            else -> "Tes suara azan — " + (PrayerAlarm.label(key))
        })
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val toggleIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_TEST_PLAYBACK")
        fun pi(req: Int, i: Intent) = PendingIntent.getService(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(BahasaAplikasi.teks(this, judulTes + " — " + (if (paused) "dijeda" else "sedang diputar")))
            .setContentText(getString(R.string.notif_kontrol_pemutar_audio))
            .setOngoing(true).setAutoCancel(false)
            .addAction(if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause, BahasaAplikasi.teks(this, if (paused) "Lanjutkan tes suara" else "Jeda tes suara"), pi(812, toggleIntent))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan tes suara"), pi(814, stopIntent))
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(809, builder.build())
    }

    private fun clearTestState() {
        getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            val namaKanal = if (BahasaAplikasi.tampilan(this) == 1) "Prayer Schedule Reminders" else "Pengingat Jadwal Sholat"
            if (manager.getNotificationChannel("jadwal_sholat") == null) {
                val channel = NotificationChannel("jadwal_sholat", namaKanal, NotificationManager.IMPORTANCE_HIGH)
                channel.setSound(null, null)
                manager.createNotificationChannel(channel)
            } else {
                // Nama kanal diperbarui mengikuti bahasa aktif; pengaturan suara/prioritas kanal tidak berubah.
                manager.createNotificationChannel(NotificationChannel("jadwal_sholat", namaKanal, manager.getNotificationChannel("jadwal_sholat").importance))
            }
        }
    }
    private fun stopPlayback() {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }
    override fun onDestroy() {
        serviceAktif = false
        handler.removeCallbacksAndMessages(null)
        if (isTestPlayback) clearTestState()
        stopPlayback()
        PembungkamTelungkup.selesai("alarm_sholat")
        try { reminderTts?.stop(); reminderTts?.shutdown() } catch (_: Exception) { }
        reminderTts = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
}
