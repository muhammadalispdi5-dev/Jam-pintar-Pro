package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.time.ZoneId
import java.util.Calendar

object PrayerAlarm {
    private val names = listOf("imsak", "subuh", "dhuha", "tahajud", "dzuhur", "ashar", "maghrib", "isya", "terbit")
    private val labels = mapOf("imsak" to "Imsak", "subuh" to "Subuh", "terbit" to "Matahari terbit", "dhuha" to "Dhuha", "tahajud" to "Tahajud", "dzuhur" to "Dzuhur", "ashar" to "Ashar", "maghrib" to "Maghrib", "isya" to "Isya")
    fun scheduleAll(context: Context) {
        val pp = PrayerPrefs(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for ((index, key) in names.withIndex()) {
            val pi = pending(context, key, index)
            try { am.cancel(pi) } catch (_: Exception) { }
            if (!pp.enabled || !pp.locationSet || !pp.reminder(key)) continue
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            // Cari kemunculan berikutnya, sambil melewati Dzuhur Jumat bila opsi itu aktif.
            for (dayOffset in 0..8) {
                if (key == "dzuhur" && pp.fridayDhuhrOff && date.dayOfWeek.value == 5) {
                    date = date.plusDays(1)
                    continue
                }
                val time = prayerMinutes(context, pp, date, key)
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1)
                    set(Calendar.DAY_OF_MONTH, date.dayOfMonth); set(Calendar.HOUR_OF_DAY, time / 60)
                    set(Calendar.MINUTE, time % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger <= nowMillis) continue
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                } else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi)
            } catch (_: SecurityException) {
                try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi) } catch (_: Exception) { }
            } catch (_: Exception) { }
        }
        // Alarm pendahuluan: request ID terpisah agar tidak bertabrakan dengan alarm azan utama.
        val advanceKeys = listOf("subuh", "dzuhur", "ashar", "maghrib", "isya")
        for ((index, key) in advanceKeys.withIndex()) {
            val pi = pending(context, key, 100 + index)
            try { am.cancel(pi) } catch (_: Exception) { }
            if (!pp.enabled || !pp.locationSet || !pp.advanceReminder(key)) continue
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            for (dayOffset in 0..8) {
                if (key == "dzuhur" && pp.fridayDhuhrOff && date.dayOfWeek.value == 5) {
                    date = date.plusDays(1)
                    continue
                }
                val time = prayerMinutes(context, pp, date, key)
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1)
                    set(Calendar.DAY_OF_MONTH, date.dayOfMonth); set(Calendar.HOUR_OF_DAY, time / 60)
                    set(Calendar.MINUTE, time % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    add(Calendar.MINUTE, -pp.advanceMinutes(key))
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger <= nowMillis) continue
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi)
            } catch (_: SecurityException) {
                try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi) } catch (_: Exception) { }
            } catch (_: Exception) { }
        }
    }
    private fun prayerMinutes(context: Context, pp: PrayerPrefs, date: LocalDate, key: String): Int {
        // Waktu khusus adalah jam harian yang dipilih pengguna; jika nonaktif, pakai perhitungan standar.
        if (key == "dhuha" && pp.dhuhaCustomEnabled) return pp.dhuhaCustomMinute
        if (key == "tahajud" && pp.tahajudCustomEnabled) return pp.tahajudCustomMinute
        val zone = ZoneId.systemDefault()
        if (pp.autoOnline) {
            PrayerOnlineTimes.minutes(context = context, date = date, key = key)?.let { onlineMinute ->
                return onlineMinute
            }
        }
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, zone, pp.method, pp.asrFactor, pp.adjustments())
        return PrayerCalc.minutes(when (key) {
            "imsak" -> t.imsak
            "subuh" -> t.fajr
            "terbit" -> t.sunrise
            "dhuha" -> t.dhuha
            "tahajud" -> PrayerCalc.tahajud(date, pp.lat, pp.lon, zone, pp.method, pp.asrFactor, pp.adjustments(), 0)
            "dzuhur" -> t.dhuhr
            "ashar" -> t.asr
            "maghrib" -> t.maghrib
            else -> t.isha
        })
    }
    private fun pending(context: Context, key: String, request: Int): PendingIntent {
        val i = Intent(context, PrayerAlarmReceiver::class.java).putExtra("prayer_key", key)
        if (request >= 100) i.putExtra("advance_reminder", true)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        return PendingIntent.getBroadcast(context, 700 + request, i, flags)
    }
    fun label(key: String) = labels[key] ?: key
}
