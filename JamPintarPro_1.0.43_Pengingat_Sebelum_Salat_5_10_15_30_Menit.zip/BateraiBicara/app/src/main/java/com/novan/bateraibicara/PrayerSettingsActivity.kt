package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast

/** Semua pilihan jadwal, pengingat, metode, penyesuaian menit, dan sumber suara azan. */
class PrayerSettingsActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private val prayerNames = listOf(
        "Imsak" to "imsak", "Subuh" to "subuh", "Matahari terbit" to "terbit", "Dhuha" to "dhuha", "Tahajud" to "tahajud",
        "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya"
    )
    private val requestGlobal = 50
    private fun requestPrayer(key: String) = 51 + prayerNames.indexOfFirst { it.second == key }

    override fun onResume() { super.onResume(); PrayerAlarm.scheduleAll(this) }

    override fun bangun() {
        bagian("Pengaturan Jadwal Sholat")
        info("Semua fitur jadwal sholat dan pengingat dinonaktifkan pada pengaturan awal. Aktifkan hanya yang Anda perlukan. Penghitungan waktu tetap dapat dilihat pada halaman Jadwal Sholat tanpa mengaktifkan pengingat.")
        saklar("Aktifkan pengingat waktu sholat", pp.enabled) { pp.enabled = it; PrayerAlarm.scheduleAll(this); if (it) mintaIzinNotifikasi() }
        bagian("Pembaruan otomatis jadwal melalui internet")
        info("Jika diaktifkan, aplikasi mengambil jadwal bulan ini dan bulan berikutnya dari layanan jadwal online saat halaman Jadwal Sholat dibuka. Jika internet tidak tersedia, aplikasi tetap menghitung jadwal di HP. Periksa kembali metode dan jadwal masjid setempat.")
        saklar("Perbarui jadwal sholat otomatis melalui internet", pp.autoOnline) {
            pp.autoOnline = it
            if (it) PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); if (pp.enabled) PrayerAlarm.scheduleAll(this) } }
            recreate()
        }
        info(PrayerOnlineTimes.lastSyncLabel(this))
        tombol("Perbarui jadwal sekarang melalui internet") { PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); recreate(); PrayerAlarm.scheduleAll(this) } } }

        bagian("Lokasi dan perhitungan")
        info(if (pp.locationSet) "Lokasi: ${pp.place} (${"%.5f".format(pp.lat)}, ${"%.5f".format(pp.lon)})" else "Lokasi belum diatur. Atur GPS atau koordinat manual pada halaman Jadwal Sholat.")
        tombol("Buka halaman lokasi") { startActivity(Intent(this, PrayerActivity::class.java)) }
        pilihan("Metode perhitungan", PrayerCalc.methodNames, pp.method) { pp.method = it; PrayerAlarm.scheduleAll(this) }
        pilihan("Perhitungan Ashar", listOf("Mazhab Syafi'i, Maliki, Hanbali (bayangan 1x)", "Mazhab Hanafi (bayangan 2x)"), pp.asrFactor - 1) { pp.asrFactor = it + 1; PrayerAlarm.scheduleAll(this) }
        pilihan("Format waktu", listOf("24 jam", "12 jam"), if (pp.use24) 0 else 1) { pp.use24 = it == 0 }

        bagian("Waktu khusus Dhuha dan Tahajud")
        info("Secara bawaan, Dhuha dan Tahajud tetap mengikuti waktu standar hasil perhitungan jadwal. Jika ingin azan/pengingat berbunyi pada jam pilihan sendiri, aktifkan waktu khusus, lalu pilih jamnya. Pengaturan ini memengaruhi jadwal dan alarm pengingat.")
        saklar("Gunakan waktu khusus Dhuha", pp.dhuhaCustomEnabled) { enabled ->
            pp.dhuhaCustomEnabled = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) "Pengingat Dhuha menggunakan waktu pilihan: ${formatJam(pp.dhuhaCustomMinute)}" else "Waktu Dhuha kembali mengikuti perhitungan standar")
        }
        tombol("Pilih waktu khusus Dhuha, saat ini ${formatJam(pp.dhuhaCustomMinute)}") {
            TimePickerDialog(this, { _, hour, minute ->
                pp.dhuhaCustomMinute = hour * 60 + minute
                PrayerAlarm.scheduleAll(this); recreate()
                toast("Waktu khusus Dhuha disimpan: ${formatJam(pp.dhuhaCustomMinute)}")
            }, pp.dhuhaCustomMinute / 60, pp.dhuhaCustomMinute % 60, pp.use24).show()
        }
        saklar("Gunakan waktu khusus Tahajud", pp.tahajudCustomEnabled) { enabled ->
            pp.tahajudCustomEnabled = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) "Pengingat Tahajud menggunakan waktu pilihan: ${formatJam(pp.tahajudCustomMinute)}" else "Waktu Tahajud kembali mengikuti perhitungan standar")
        }
        tombol("Pilih waktu khusus Tahajud, saat ini ${formatJam(pp.tahajudCustomMinute)}") {
            TimePickerDialog(this, { _, hour, minute ->
                pp.tahajudCustomMinute = hour * 60 + minute
                PrayerAlarm.scheduleAll(this); recreate()
                toast("Waktu khusus Tahajud disimpan: ${formatJam(pp.tahajudCustomMinute)}")
            }, pp.tahajudCustomMinute / 60, pp.tahajudCustomMinute % 60, pp.use24).show()
        }

        bagian("Pengingat sebelum salat lima waktu")
        info("Aktifkan pengingat pendahuluan untuk Subuh, Dzuhur, Ashar, Maghrib, dan Isya. Pilih apakah pengingat berbunyi 5, 10, 15, atau 30 menit sebelum waktu salat. Pengingat ini terpisah dari pengingat/azan pada waktu salat.")
        val sholatWajib = listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        val pilihanMenit = listOf("5 menit", "10 menit", "15 menit", "30 menit")
        val nilaiMenit = listOf(5, 10, 15, 30)
        for ((name, key) in sholatWajib) {
            bagian("Pengingat sebelum $name", 17f)
            saklar("Aktifkan pengingat sebelum $name", pp.advanceReminder(key)) {
                pp.setAdvanceReminder(key, it)
                PrayerAlarm.scheduleAll(this)
                toast(if (it) "Pengingat sebelum $name aktif, ${pp.advanceMinutes(key)} menit sebelumnya" else "Pengingat sebelum $name dinonaktifkan")
            }
            pilihan("Waktu pengingat sebelum $name", pilihanMenit, nilaiMenit.indexOf(pp.advanceMinutes(key)).coerceAtLeast(0)) { selected ->
                pp.setAdvanceMinutes(key, nilaiMenit[selected])
                PrayerAlarm.scheduleAll(this)
                toast("Pengingat $name akan berbunyi ${nilaiMenit[selected]} menit sebelum waktu salat")
            }
        }

        bagian("Pengingat setiap waktu sholat")
        info("Aktifkan pengingat matahari terbit secara terpisah melalui sakelar Ingatkan waktu Matahari terbit.")
        for ((name, key) in prayerNames) {
            saklar("Ingatkan waktu $name", pp.reminder(key)) { pp.setReminder(key, it); PrayerAlarm.scheduleAll(this) }
        }
        saklar("Matikan pengingat Dzuhur pada hari Jumat", pp.fridayDhuhrOff) { pp.fridayDhuhrOff = it; PrayerAlarm.scheduleAll(this) }
        saklar("Notifikasi saja, tanpa suara azan", pp.notifyOnly) { pp.notifyOnly = it }
        tombol("Izinkan alarm tepat waktu") { bukaIzinAlarm() }
        tombol("Buka pengaturan notifikasi aplikasi") { bukaNotifikasi() }

        bagian("Tambah atau kurangi menit")
        info("Sesuaikan setiap waktu bila jadwal setempat berbeda. Nilai boleh negatif atau positif dari −30 sampai +30 menit.")
        val adjust = listOf("Imsak" to "imsak", "Subuh" to "subuh", "Terbit" to "terbit", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        for ((label, key) in adjust) {
            val field = isian("Penyesuaian $label (menit)", pp.adjustment(key).toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED) { raw ->
                raw.toIntOrNull()?.let { pp.setAdjustment(key, it) }
            }
            field.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) PrayerAlarm.scheduleAll(this) }
        }

        bagian("Sumber suara pengingat dan azan")
        info("Pilih berkas audio dari penyimpanan internal untuk semua waktu atau atur suara berbeda bagi Imsak, Subuh, Terbit, Dhuha, Tahajud, Dzuhur, Ashar, Maghrib, dan Isya. Saat tes sedang diputar, gunakan tombol Jeda tes suara azan, Lanjutkan tes suara azan, atau Hentikan tes suara azan di bawah. Tombol-tombol ini hanya untuk tes di pengaturan, bukan azan normal.")
        bagian("Kontrol tes suara azan", 17f)
        info("Gunakan satu tombol ini saja. Ketuk pertama untuk memutar tes; ketika suara berjalan, ketuk lagi untuk menjeda; ketuk sekali lagi untuk melanjutkan dari posisi terakhir. Ketuk lama tidak diperlukan. Untuk menghentikan tes, gunakan tombol Hentikan tes di bagian bawah atau tindakan pada notifikasi.")
        val tombolTes = tombol(labelTombolTes()) { toggleTesAzan() }
        tombolTes.contentDescription = labelTombolTes()
        tombolTes.setOnClickListener {
            toggleTesAzan()
            tombolTes.text = labelTombolTes()
            tombolTes.contentDescription = tombolTes.text
        }
        tombol("Pilih berkas azan cadangan untuk semua waktu") { pilihBerkas(requestGlobal) }
        info("Berkas semua waktu: ${if (pp.globalSound.isBlank()) "azan bawaan" else pp.globalSound}")
        tombol("Hapus berkas azan semua waktu") { pp.globalSound = ""; ulangiTesAktifJikaAda(); toast("Berkas semua waktu dihapus"); recreate() }
        tombol("Hapus semua berkas azan pilihan") {
            pp.globalSound = ""
            for ((_, key) in prayerNames) pp.setSound(key, "")
            ulangiTesAktifJikaAda()
            toast("Semua berkas azan pilihan dihapus"); recreate()
        }
        pilihan("Jenis volume azan", listOf("Alarm", "Notifikasi", "Media"), pp.volumeMode) { pp.volumeMode = it }
        for ((name, key) in prayerNames) {
            bagian("Suara pengingat $name", 17f)
            info("Sumber suara: ${if (pp.sound(key).isBlank()) if (pp.globalSound.isBlank()) if (key == "subuh") "azan Subuh bawaan" else "azan umum bawaan" else "berkas semua waktu" else pp.sound(key)}")
            tombol("Pilih berkas suara $name") { pilihBerkas(requestPrayer(key)) }
            tombol("Putar atau jeda tes suara azan $name") { tesAzan(key) }
            tombol("Gunakan suara umum atau bawaan untuk $name") { pp.setSound(key, ""); if ((getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getString("test_playback_key", "subuh") ?: "subuh") == key) ulangiTesAktifJikaAda(); recreate() }
        }
        tombol("Tes suara azan Subuh") { tesAzan("subuh") }
        tombol("Hentikan tes suara azan") { kontrolTes("STOP_TEST_PLAYBACK"); recreate() }

        bagian("Arah kiblat")
        saklar("Ucapan arah otomatis setiap 1,5 detik", pp.voiceQibla) { pp.voiceQibla = it }
        saklar("Getar panjang saat menghadap kiblat (selisih kurang dari 5 derajat)", pp.qiblaHaptic) { pp.qiblaHaptic = it }
        bagian("Panduan kompas saat layar mati")
        info("Sakelar ini hanya mengatur apakah panduan suara/nada boleh diteruskan saat layar mati. Sakelar tidak membuka atau menjalankan kompas. Untuk memulai panduan, buka halaman arah kiblat dan jarum kompas; jika opsi ini aktif, layanan latar belakang akan mulai saat halaman kompas dibuka.")
        val qiblaBgState = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        saklar("Izinkan panduan kompas tetap berjalan saat layar mati", qiblaBgState.getBoolean("qibla_screen_off_enabled", false)) { enabled ->
            qiblaBgState.edit().putBoolean("qibla_screen_off_enabled", enabled).apply()
            if (!enabled) {
                stopService(Intent(this, QiblaGuidanceService::class.java))
                qiblaBgState.edit().putBoolean("qibla_background_active", false).apply()
                toast("Panduan kompas tidak akan diteruskan saat layar mati.")
            } else {
                toast("Pengaturan disimpan. Buka halaman arah kiblat dan jarum kompas untuk memulai panduan.")
            }
        }
        tombol("Buka halaman arah kiblat dan jarum kompas") { startActivity(Intent(this, QiblaActivity::class.java)) }
    }

    private fun formatJam(total: Int): String {
        val h = (total.coerceIn(0, 1439) / 60).toString().padStart(2, '0')
        val m = (total.coerceIn(0, 1439) % 60).toString().padStart(2, '0')
        return if (pp.use24) "$h:$m" else { val hour = total / 60; "%02d:%02d %s".format(if (hour % 12 == 0) 12 else hour % 12, total % 60, if (hour < 12) "AM" else "PM") }
    }

    private fun pilihBerkas(request: Int) {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i, request)
        } catch (e: Exception) { toast("Pemilih berkas tidak dapat dibuka pada perangkat ini.") }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        when (requestCode) {
            requestGlobal -> pp.globalSound = uri.toString()
            else -> {
                val idx = requestCode - 51
                if (idx in prayerNames.indices) pp.setSound(prayerNames[idx].second, uri.toString())
            }
        }
        toast("Sumber suara disimpan")
        ulangiTesAktifJikaAda()
        recreate()
    }

    private fun labelTombolTes(): String {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        return when {
            !state.getBoolean("test_playback_active", false) -> "Putar tes suara azan"
            state.getBoolean("test_playback_paused", false) -> "Lanjutkan tes suara azan"
            else -> "Jeda tes suara azan"
        }
    }
    private fun toggleTesAzan() {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!state.getBoolean("test_playback_active", false)) tesAzan("subuh")
        else kontrolTes("TOGGLE_TEST_PLAYBACK")
    }

    private fun tesAzan(key: String) {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        val active = state.getBoolean("test_playback_active", false)
        val currentKey = state.getString("test_playback_key", "subuh") ?: "subuh"
        // Ketuk tes pada waktu sholat lain berarti pilih dan putar berkasnya yang baru,
        // bukan menjeda pemutar lama. Jika kuncinya sama, tombol tetap berfungsi sebagai jeda/lanjut.
        val i = if (active && currentKey == key) {
            Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        } else {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true)
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Tidak dapat memutar atau menjeda suara. Periksa izin dan berkas audio.") }
    }

    private fun ulangiTesAktifJikaAda() {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!state.getBoolean("test_playback_active", false)) return
        val key = state.getString("test_playback_key", "subuh") ?: "subuh"
        val i = Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true)
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Berkas tersimpan, tetapi tes audio aktif tidak dapat dimulai ulang.") }
    }
    private fun kontrolTes(action: String) {
        val i = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.$action")
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Kontrol tes suara tidak dapat dijalankan. Mulai tes suara terlebih dahulu.") }
    }

    private fun mintaIzinNotifikasi() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 405)
    }
    private fun bukaIzinAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        } else toast("Pada versi Android ini, izin alarm tepat waktu dikelola otomatis.")
    }
    private fun bukaNotifikasi() {
        try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
    }
}
