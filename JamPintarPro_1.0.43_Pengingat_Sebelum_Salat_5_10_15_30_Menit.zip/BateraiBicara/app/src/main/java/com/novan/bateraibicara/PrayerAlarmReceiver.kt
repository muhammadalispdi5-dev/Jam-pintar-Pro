package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("prayer_key") ?: return
        val pp = PrayerPrefs(context)
        val advance = intent.getBooleanExtra("advance_reminder", false)
        val allowed = if (advance) pp.advanceReminder(key) else pp.reminder(key)
        if (pp.enabled && allowed) {
            val service = Intent(context, PrayerAlarmService::class.java)
                .putExtra("prayer_key", key)
                .putExtra("advance_reminder", advance)
            try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
        }
        PrayerAlarm.scheduleAll(context)
    }
}
