package com.novan.bateraibicara

import android.app.AlertDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.ContentValues
import android.os.Environment
import android.media.MediaScannerConnection
import android.provider.Settings
import android.provider.MediaStore
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.UUID
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pembaca Al-Qur'an dan pendamping khatam. Teks/terjemahan disimpan di perangkat setelah diunduh. */
class KhatamActivity : Halaman() {
    override val judulHalaman = R.string.khatam_judul
    private val handler = Handler(Looper.getMainLooper())
    private val dataPrefs by lazy { getSharedPreferences("khatam_quran", MODE_PRIVATE) }
    private var quran: JSONObject? = null
    private var terjemahan: JSONObject? = null
    private var nomorSurah = 1
    private var nomorAyat = 1
    private var tampilkanArti = true
    private var ukuranArab = 28f
    private var pemutar: PemutarAudio? = null
    private var keluaranMono = false
    private var equalizerAudio: Equalizer? = null
    private var statusEqualizer = "belum aktif"
    private var speechRecognizerHafalan: SpeechRecognizer? = null
    private var dialogKoreksiHafalan: AlertDialog? = null
    private var statusKoreksiHafalan: TextView? = null
    private var ttsTerjemahan: TextToSpeech? = null
    private var ttsSiap = false
    private var modePemutaranAudio = "arab" // arab, terjemahan, arab_terjemahan
    private var presetEqualizer = "normal" // normal, vocal, bass, treble, kustom
    private var latihanHafalanAktif = false
    private var audioSiap = false
    private var audioGenerasi = 0
    private var tombolStatusAudio: TextView? = null
    private var tombolJedaAudio: android.widget.Button? = null
    private var teksKecepatanAudio: TextView? = null
    private var infoQari: TextView? = null
    private var infoModeAudio: TextView? = null
    private var sedangDiPembaca = false
    private var qariId: String = "ar.alafasy"
    // Katalog dipisah berdasarkan kemampuan audio agar qari audio per surah
    // tidak memenuhi daftar qari yang memang mendukung pemutaran per ayat.
    private val daftarQari = mutableListOf(
        "ar.alafasy" to "Mishary Rashid Alafasy · merdu dan jelas",
        "ar.husary" to "Mahmoud Khalil Al-Husary · tartil dan tajwid",
        "ar.minshawi" to "Mohamed Siddiq Al-Minshawi · tartil",
        "ar.abdurrahmaansudais" to "Abdurrahman As-Sudais",
        "ar.saoodshuraym" to "Saud Al-Shuraim",
        "ar.abdulbasitmurattal" to "Abdul Basit Abdus Samad · murattal",
        "ar.ahmedajamy" to "Ahmed ibn Ali Al-Ajamy",
        "ar.muhammadayyoub" to "Muhammad Ayyoub",
        "ar.hudhaify" to "Ali Al-Hudhaify",
        "ar.shaatree" to "Abu Bakr Ash-Shaatree",
        "ar.mahermuaiqly" to "Maher Al-Muaiqly",
        "ar.yasseraldosari" to "Yasser Al-Dosari",
        "ar.nasserqatami" to "Nasser Al-Qatami",
        "ar.haniarrifai" to "Hani Ar-Rifai"
    )
    private val daftarQariPerSurah = mutableListOf<Pair<String, String>>()
    private var katalogQariSedangDimuat = false
    private var audioSedangJuz = false
    private var audioGlobalSaatIni = 1
    private var audioGlobalAkhir = 1
    private var juzAktif = 1
    private var halamanAktif = 1
    private var audioRentangLabel = ""
    private var dialogUnduh: AlertDialog? = null
    private var status: TextView? = null
    private var ayatArab: TextView? = null
    private var ayatArti: TextView? = null
    private var teksReferensi: TextView? = null
    private var tombolAudio: android.widget.Button? = null
    private var tombolAudioAyat: android.widget.Button? = null
    private var tombolAudioAktif: android.widget.Button? = null
    private var tombolTandaiAyat: android.widget.Button? = null
    // Pengulangan murattal ayat: 1–10 kali, atau 0 untuk terus mengulang.
    private var pengulanganAyat = 1
    private var sisaPengulanganAyat = 1
    private var audioSedangAyat = false
    private var urlAudioAyatAktif = ""
    private var pesanAudioAyatAktif = ""
    private var kecepatanAudio = 1.0f
    // Mode hafalan: biasa, ayat (ulang ayat aktif), berurutan (ulang lalu lanjut ayat berikutnya).
    private var modeHafalan = "biasa"
    private var targetPemutaran = "ayat"
    private var jedaAntarAyatDetik = 2

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1, 114)
        nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        tampilkanArti = dataPrefs.getBoolean("tampilkan_terjemahan", true)
        ukuranArab = dataPrefs.getFloat("ukuran_arab", 28f).coerceIn(22f, 42f)
        qariId = dataPrefs.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        // Pengenal lama yang tidak ada di CDN dipetakan ke pengenal yang benar agar pilihan pengguna tetap terjaga.
        qariId = when (qariId) {
            "ar.sudais" -> "ar.abdurrahmaansudais"
            "ar.shuraim" -> "ar.saoodshuraym"
            "ar.abdulbasit" -> "ar.abdulbasitmurattal"
            "ar.ajamy" -> "ar.ahmedajamy"
            "ar.muhammadayoub" -> "ar.muhammadayyoub"
            else -> qariId
        }
        if (daftarQari.none { it.first == qariId } && !qariId.startsWith("mp3quran|") && !qariId.startsWith("ar.")) qariId = "ar.alafasy"
        dataPrefs.edit().putString("qari_audio_id", qariId).apply()
        keluaranMono = dataPrefs.getString("keluaran_suara_audio", "stereo") == "mono"
        pengulanganAyat = dataPrefs.getInt("pengulangan_audio_ayat", 1).let { if (it in 0..10) it else 1 }
        kecepatanAudio = dataPrefs.getFloat("kecepatan_audio", 1.0f).let { if (it in listOf(0.75f, 1.0f, 1.25f, 1.5f)) it else 1.0f }
        modeHafalan = dataPrefs.getString("mode_hafalan_audio", "biasa")?.takeIf { it in listOf("biasa", "ayat", "berurutan") } ?: "biasa"
        targetPemutaran = dataPrefs.getString("target_pemutaran_audio", "ayat")?.takeIf { it in listOf("ayat", "surah", "juz", "halaman") } ?: "ayat"
        jedaAntarAyatDetik = dataPrefs.getInt("jeda_antar_ayat_detik", 2).let { if (it in listOf(0, 2, 5, 10)) it else 2 }
        senyapTalkBackPergantian = dataPrefs.getBoolean("senyap_talkback_pergantian_audio", false)
        modePemutaranAudio = dataPrefs.getString("mode_pemutaran_audio", "arab")?.takeIf { it in listOf("arab", "terjemahan", "arab_terjemahan") } ?: "arab"
        presetEqualizer = dataPrefs.getString("preset_equalizer_audio", "normal")?.takeIf { it in listOf("normal", "vocal", "bass", "treble", "kustom") } ?: "normal"
        ttsTerjemahan = TextToSpeech(this) { status ->
            ttsSiap = status == TextToSpeech.SUCCESS
            if (ttsSiap) {
                val locale = if (BahasaAplikasi.tampilan(this) == 1) Locale.US else Locale("id", "ID")
                val hasilBahasa = ttsTerjemahan?.setLanguage(locale)
                if (hasilBahasa == TextToSpeech.LANG_MISSING_DATA || hasilBahasa == TextToSpeech.LANG_NOT_SUPPORTED) {
                    ttsSiap = false
                }
                ttsTerjemahan?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { }
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            perbaruiStatusAudio(tr("Audio terjemahan selesai dibacakan.", "Translation audio finished."), true)
                            perbaruiTombolJedaAudio(true)
                        }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        runOnUiThread { perbaruiStatusAudio(tr("Mesin suara gagal membacakan terjemahan.", "Speech engine failed to read the translation.")); perbaruiTombolJedaAudio(true) }
                    }
                })
            }
        }
        muatCache()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { pemutar?.stop() } catch (_: Exception) { }
        try { pemutar?.release() } catch (_: Exception) { }
        pemutar = null
        lepasEfekAudio()
        try { speechRecognizerHafalan?.destroy() } catch (_: Exception) { }
        speechRecognizerHafalan = null
        try { dialogKoreksiHafalan?.dismiss() } catch (_: Exception) { }
        try { ttsTerjemahan?.stop(); ttsTerjemahan?.shutdown() } catch (_: Exception) { }
        ttsTerjemahan = null
        try { dialogUnduh?.dismiss() } catch (_: Exception) { }
        super.onDestroy()
    }


    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (sedangDiPembaca) {
            hentikanAudio()
            bangunMenuLagi()
        } else {
            super.onBackPressed()
        }
    }

    override fun bangun() {
        sedangDiPembaca = false
        bagian(tr("Khatam Al-Qur'an", "Qur'an Completion"), 24f)
        info(tr(
            "Pembaca Al-Qur'an yang ramah pembaca layar. Teks Arab dan terjemahan dapat disimpan di perangkat agar bisa dibaca tanpa internet setelah diunduh. Kemajuan bacaan tersimpan di perangkat ini.",
            "A screen-reader-friendly Qur'an reader. Arabic text and translation can be saved on this device for offline reading after download. Reading progress is stored on this device."
        ))
        status = info(tr("Memeriksa teks Al-Qur'an yang tersimpan…", "Checking saved Qur'an text…"))
        info(ringkasanKemajuan())
        bagian(tr("BACAAN DAN NAVIGASI", "READING AND NAVIGATION"))
        tombol(tr("Lanjutkan bacaan terakhir", "Resume last reading")) { bukaAyatTersimpan() }
        tombol(tr("Baca Al-Qur'an / pilih surah", "Read Qur'an / choose surah")) { pilihSurah() }
        tombol(tr("Pilih juz untuk membaca", "Choose juz to read")) { pilihJuz() }
        bagian(tr("LATIHAN HAFALAN", "MEMORIZATION PRACTICE"))
        info(tr(
            "Latihan memakai ayat bacaan terakhir Anda. Ayat akan disembunyikan, lalu Anda membaca dari hafalan.",
            "Practice uses your last reading position. The verse is hidden and you recite from memory."
        ))
        tombol(tr("Koreksi otomatis dengan pengenalan suara", "Automatic speech-recognition check")) { mulaiKoreksiOtomatisHafalan() }
        tombol(tr("Latihan hafalan tanpa mikrofon", "Memorization practice without microphone")) { latihanKoreksiHafalan() }
        bagian(tr("PENGATURAN", "SETTINGS"))
        infoQari = info(tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari())
        infoModeAudio = info(tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat())
        tombol(tr("Pengaturan Khatam Al-Qur'an", "Qur'an completion settings")) { dialogPengaturanKhatam() }
        bagian(tr("PEMUTARAN AUDIO", "AUDIO PLAYBACK"))
        tombolStatusAudio = info(tr("Audio siap. Pilih Putar untuk memulai murattal.", "Audio is ready. Choose Play to start recitation."))
        bangunKontrolPemutarAudio()
        tombol(tr("Cari juz, surah, atau ayat untuk diputar", "Search a juz, surah, or verse to play")) { dialogCariAudio() }
        tombol(tr("Unduh audio Al-Qur'an", "Download Qur'an audio")) { dialogUnduhAudio() }
        bagian(tr("KELENGKAPAN BACAAN", "READING TOOLS"))
        tombol(tr("Unduh teks lengkap untuk penggunaan offline", "Download complete text for offline use")) { unduhSemuaTeks() }
        tombol(tr("Tandai ayat terakhir yang dibaca", "Mark last reading position")) { tandaiPosisi() }
        bagian(tr("Sumber teks dan audio", "Text and audio sources"))
        info(tr(
            "Teks Arab dan terjemahan diambil melalui Al Quran Cloud API dan disimpan setelah diunduh. Sumber: alquran.cloud; teks Uthmani merujuk pada sumber Al-Qur'an yang dicantumkan penyedia. Audio murattal dapat diputar secara streaming atau diunduh. Hasil unduhan audio dan teks disimpan otomatis di folder Jam Pintar Pro pada memori internal HP, subfolder Audio dan Teks.",
            "Arabic text and translation are retrieved through the Al Quran Cloud API and saved after download. Source: alquran.cloud; the Uthmani text refers to the Qur'an source credited by the provider. Murattal audio can be streamed and downloaded for personal use. Downloaded audio and text are saved automatically in the Jam Pintar Pro folder in the phone's internal storage, in the Audio and Text subfolders. Juz audio is saved as individual verse MP3 files."
        ))
    }

    private fun cacheFile(name: String) = File(filesDir, name)

    /** Tulis cache lewat berkas sementara agar unduhan yang terputus tidak merusak cache lama. */
    private fun tulisCacheAtomik(name: String, content: String) {
        val target = cacheFile(name)
        val temporary = File(filesDir, ("" + (name) + ".tmp"))
        val backup = File(filesDir, ("" + (name) + ".bak"))
        temporary.writeText(content, Charsets.UTF_8)
        if (backup.exists()) backup.delete()
        val hadOld = target.exists()
        if (hadOld && !target.renameTo(backup)) {
            temporary.delete()
            throw IllegalStateException(("Tidak dapat mencadangkan cache " + (name)))
        }
        if (!temporary.renameTo(target)) {
            if (hadOld) backup.renameTo(target)
            temporary.delete()
            throw IllegalStateException(("Tidak dapat menyimpan cache " + (name)))
        }
        backup.delete()
    }

    private fun muatCache() {
        try {
            if (cacheFile("quran_ar.json").exists()) quran = JSONObject(cacheFile("quran_ar.json").readText(Charsets.UTF_8))
            val activeCache = if (BahasaAplikasi.tampilan(this) == 1) cacheFile("quran_en.json") else cacheFile("quran_id.json")
            if (activeCache.exists()) terjemahan = JSONObject(activeCache.readText(Charsets.UTF_8)) else terjemahan = null
            status?.text = if (quran != null) tr("Teks Arab tersedia di perangkat.", "Arabic text is available on this device.") else tr("Teks belum diunduh. Hubungkan internet lalu pilih unduh teks lengkap.", "Text is not downloaded yet. Connect to the internet and choose download complete text.")
        } catch (_: Exception) {
            quran = null; terjemahan = null
            status?.text = tr("Cache teks perlu diunduh ulang.", "Text cache needs to be downloaded again.")
        }
    }

    private fun fetch(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection)
        connection.connectTimeout = 20000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException(("HTTP " + (code)))
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { connection.disconnect() }
    }

    private fun unduhSemuaTeks(setelah: (() -> Unit)? = null) = pastikanIzinFolder(setelah) { unduhSemuaTeksSekarang(setelah) }

    private fun unduhSemuaTeksSekarang(setelah: (() -> Unit)? = null) {
        val progress = android.app.ProgressDialog(this)
        progress.setTitle(tr("Mengunduh teks Al-Qur'an", "Downloading Qur'an text"))
        progress.setMessage(tr("Mengunduh teks Arab serta terjemahan Indonesia dan Inggris agar pilihan bahasa tetap bisa dibaca offline. Mohon tunggu.", "Downloading Arabic text and both Indonesian and English translations so either app language works offline. Please wait."))
        progress.setCancelable(false)
        progress.show()
        dialogUnduh = progress
        Thread {
            try {
                val ar = fetch("https://api.alquran.cloud/v1/quran/quran-uthmani")
                val id = fetch("https://api.alquran.cloud/v1/quran/id.indonesian")
                val en = fetch("https://api.alquran.cloud/v1/quran/en.sahih")
                val arObj = JSONObject(ar); val idObj = JSONObject(id); val enObj = JSONObject(en)
                fun validasi(obj: JSONObject, label: String) {
                    val surahs = obj.optJSONObject("data")?.optJSONArray("surahs")
                    if (surahs?.length() != 114) throw IllegalStateException(("Jumlah surah " + (label) + " tidak lengkap"))
                    var count = 0
                    for (i in 0 until 114) count += surahs!!.optJSONObject(i)?.optJSONArray("ayahs")?.length() ?: 0
                    if (count != 6236) throw IllegalStateException(("Jumlah ayat " + (label) + " tidak sesuai 6236"))
                }
                validasi(arObj, "Arab"); validasi(idObj, "terjemahan Indonesia"); validasi(enObj, "terjemahan Inggris")
                tulisCacheAtomik("quran_ar.json", ar)
                tulisCacheAtomik("quran_id.json", id)
                tulisCacheAtomik("quran_en.json", en)
                val active = if (BahasaAplikasi.tampilan(this) == 1) enObj else idObj
                tulisCacheAtomik("quran_active_translation.json", active.toString())
                // Salinan berkas di folder "Jam Pintar Pro" pada memori internal. Kegagalan di sini tidak membatalkan unduhan.
                val lokasiSalinan: String? = try {
                    simpanKePenyimpananPublik("Teks", "Al-Quran-Arab-Uthmani.json", "application/json") { it.write(ar.toByteArray(Charsets.UTF_8)) }
                    simpanKePenyimpananPublik("Teks", "Al-Quran-Terjemahan-Indonesia.json", "application/json") { it.write(id.toByteArray(Charsets.UTF_8)) }
                    simpanKePenyimpananPublik("Teks", "Al-Quran-Terjemahan-Inggris.json", "application/json") { it.write(en.toByteArray(Charsets.UTF_8)) }
                } catch (_: Exception) { null }
                runOnUiThread {
                    quran = arObj; terjemahan = active
                    status?.text = tr("Teks Arab serta terjemahan Indonesia dan Inggris tersimpan di perangkat dan siap dibaca offline.", "Arabic text and Indonesian and English translations are saved on this device and ready for offline reading.")
                    progress.dismiss(); dialogUnduh = null
                    toast(if (lokasiSalinan != null)
                        tr("Unduhan selesai. Teks tersimpan di folder: ", "Download complete. Text saved in folder: ") + lokasiSalinan
                    else
                        tr("Unduhan selesai dan teks siap dibaca offline, tetapi salinan ke folder Jam Pintar Pro gagal dibuat.", "Download complete and text is ready offline, but the copy in the Jam Pintar Pro folder could not be created."))
                    setelah?.invoke()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss(); dialogUnduh = null
                    toast(tr("Unduhan gagal. Periksa koneksi internet lalu coba lagi. Detail: ", "Download failed. Check your internet connection and try again. Details: ") + (e.message ?: ""))
                    setelah?.invoke()
                }
            }
        }.start()
    }

    private fun daftarSurah(): org.json.JSONArray? = quran?.optJSONObject("data")?.optJSONArray("surahs")

    private fun pilihSurah() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val surahs = daftarSurah() ?: return
        val labels = (0 until surahs.length()).map { i ->
            val s = surahs.getJSONObject(i)
            val namaTampil = if (BahasaAplikasi.tampilan(this) == 1) s.optString("englishName") else s.optString("name")
            ("" + (s.optInt("number")) + ". " + namaTampil + " (" + (s.optInt("numberOfAyahs")) + " " + (tr("ayat", "verses")) + ")")
        }
        AlertDialog.Builder(this).setTitle(tr("Pilih surah", "Choose a surah"))
            .setItems(labels.toTypedArray()) { _, index -> nomorSurah = index + 1; nomorAyat = 1; tampilkanPembaca() }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihJuz() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val juz = (1..30).map { ("" + (tr("Juz", "Juz")) + " " + (it)) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz", "Choose a juz")).setItems(juz) { _, which ->
            val target = which + 1
            val surahs = daftarSurah() ?: return@setItems
            var foundS = 1; var foundA = 1
            loop@ for (i in 0 until surahs.length()) {
                val verses = surahs.getJSONObject(i).optJSONArray("ayahs") ?: continue
                for (j in 0 until verses.length()) {
                    val a = verses.getJSONObject(j)
                    if (a.optInt("juz") == target) { foundS = i + 1; foundA = a.optInt("numberInSurah", 1); break@loop }
                }
            }
            nomorSurah = foundS; nomorAyat = foundA; tampilkanPembaca()
        }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihAyat() {
        val maxAyat = getSurah(nomorSurah)?.optJSONArray("ayahs")?.length() ?: 0
        if (maxAyat <= 0) { toast(tr("Data ayat surah ini belum tersedia.", "Verse data for this surah is not available.")); return }
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        input.hint = tr("Nomor ayat 1 sampai ", "Verse number from 1 to ") + maxAyat
        input.contentDescription = input.hint
        input.setText(nomorAyat.toString())
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih ayat dalam surah ini", "Choose a verse in this surah"))
            .setMessage(tr("Masukkan nomor ayat antara 1 dan ", "Enter a verse number between 1 and ") + maxAyat)
            .setView(input)
            .setPositiveButton(tr("Buka ayat", "Open verse")) { _, _ ->
                val selected = input.text.toString().trim().toIntOrNull()
                if (selected != null && selected in 1..maxAyat) {
                    nomorAyat = selected
                    tampilkanPembaca()
                } else {
                    toast(tr("Nomor ayat tidak valid. Silakan masukkan angka 1 sampai ", "Invalid verse number. Enter a number from 1 to ") + maxAyat)
                }
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    private fun bukaAyatTersimpan() {
        nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1,114)
        nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return }
        tampilkanPembaca()
    }

    private fun dialogBelumAdaTeks() {
        AlertDialog.Builder(this).setTitle(tr("Teks belum tersedia", "Text not available"))
            .setMessage(tr("Untuk membaca offline, unduh dulu teks lengkap ketika tersambung ke internet.", "To read offline, first download the complete text while connected to the internet."))
            .setPositiveButton(tr("Unduh sekarang", "Download now")) { _, _ -> unduhSemuaTeks() }
            .setNegativeButton(tr("Nanti", "Later"), null).show()
    }

    private fun getSurah(n: Int): JSONObject? = daftarSurah()?.optJSONObject(n - 1)
    private fun getAyat(surah: Int, ayah: Int): JSONObject? = getSurah(surah)?.optJSONArray("ayahs")?.let { arr -> if (ayah in 1..arr.length()) arr.optJSONObject(ayah - 1) else null }

    private fun tampilkanPembaca() {
        val surah = getSurah(nomorSurah)
        if (surah == null) { dialogBelumAdaTeks(); return }
        val verses = surah.optJSONArray("ayahs") ?: return
        nomorAyat = nomorAyat.coerceIn(1, verses.length())
        // Simpan penanda terakhir tanpa menganggap ayat sudah selesai dibaca.
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        root.removeAllViews()
        sedangDiPembaca = true
        tombol(tr("Kembali ke menu khatam", "Back to Khatam menu")) { hentikanAudio(); bangunMenuLagi() }
        bagian(tr("Pembaca Al-Qur'an", "Qur'an reader"), 24f)
        val namaSurahTampil = if (BahasaAplikasi.tampilan(this) == 1) surah.optString("englishName") else surah.optString("name")
        info(namaSurahTampil)
        info(tr("Surah", "Surah") + (" " + (nomorSurah) + ", ") + tr("ayat", "verse") + (" " + (nomorAyat) + " / " + (verses.length())))
        val a = getAyat(nomorSurah, nomorAyat) ?: return
        val ar = TextView(this)
        ar.text = teksArabTampil(a.optString("text"))
        ar.textSize = ukuranArab
        ar.gravity = Gravity.CENTER
        ar.textDirection = android.view.View.TEXT_DIRECTION_RTL
        ar.setTextColor(warnaTeks())
        ar.setPadding(dp(12), dp(24), dp(12), dp(24))
        ar.contentDescription = tr("Teks Arab ayat", "Arabic verse text") + (" " + (nomorSurah) + ":" + (nomorAyat) + ". ") + teksArabTampil(a.optString("text"))
        ar.setBackgroundColor(if (modeGelap()) Color.rgb(28, 44, 40) else Color.rgb(239, 236, 221))
        root.addView(ar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })
        ayatArab = ar
        val translatedSurah = terjemahan?.optJSONObject("data")?.optJSONArray("surahs")?.optJSONObject(nomorSurah - 1)
        val translatedAyat = translatedSurah?.optJSONArray("ayahs")?.optJSONObject(nomorAyat - 1)?.optString("text", "") ?: ""
        val arti = TextView(this)
        arti.text = if (translatedAyat.isBlank()) tr("Terjemahan belum tersedia. Unduh teks sesuai bahasa aplikasi.", "Translation is not available. Download text in the app's selected language.") else translatedAyat
        arti.textSize = 17f; arti.setTextColor(warnaTeks()); arti.setPadding(dp(8), dp(8), dp(8), dp(8))
        arti.visibility = if (tampilkanArti) android.view.View.VISIBLE else android.view.View.GONE
        root.addView(arti); ayatArti = arti
        val ref = info(tr("Surah", "Surah") + (" " + (nomorSurah) + ", ") + tr("ayat", "verse") + (" " + (nomorAyat)))
        teksReferensi = ref
        tombol(tr("Ayat sebelumnya", "Previous verse")) { hentikanAudio(); if (nomorAyat > 1) nomorAyat-- else if (nomorSurah > 1) { nomorSurah--; nomorAyat = getSurah(nomorSurah)?.optJSONArray("ayahs")?.length() ?: 1 }; tampilkanPembaca() }
        tombol(tr("Ayat berikutnya", "Next verse")) { hentikanAudio(); if (nomorAyat < verses.length()) nomorAyat++ else if (nomorSurah < 114) { nomorSurah++; nomorAyat = 1 }; tampilkanPembaca() }
        tombol(tr("Pilih nomor ayat", "Choose verse number")) { hentikanAudio(); pilihAyat() }
        tombolTandaiAyat = tombol(if (ayatSudahSelesai()) tr("Batalkan tanda selesai untuk ayat ini", "Unmark this verse as completed") else tr("Tandai ayat selesai dibaca", "Mark verse as read")) {
            if (ayatSudahSelesai()) batalkanTandaAyatSelesai() else tandaiAyatSelesai()
        }
        tombol(tr("Tandai posisi terakhir", "Save reading position")) { tandaiPosisi() }
        tombol(if (tampilkanArti) tr("Sembunyikan terjemahan", "Hide translation") else tr("Tampilkan terjemahan", "Show translation")) { hentikanAudio(); tampilkanArti = !tampilkanArti; dataPrefs.edit().putBoolean("tampilkan_terjemahan", tampilkanArti).apply(); tampilkanPembaca() }
        tombol(tr("Perbesar teks Arab", "Increase Arabic text size")) { hentikanAudio(); ukuranArab = (ukuranArab + 2f).coerceAtMost(42f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); tampilkanPembaca() }
        tombol(tr("Perkecil teks Arab", "Decrease Arabic text size")) { hentikanAudio(); ukuranArab = (ukuranArab - 2f).coerceAtLeast(22f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); tampilkanPembaca() }
        bagian(tr("AUDIO DAN HAFALAN", "AUDIO AND MEMORIZATION"))
        infoQari = info(tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari())
        tombol(tr("Pengaturan utama Khatam Al-Qur'an", "Main Qur'an completion settings")) { dialogPengaturanKhatam() }
        infoModeAudio = info(tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat())
        tombolStatusAudio = info(tr("Audio belum diputar. Internet diperlukan untuk murattal.", "Audio has not started. Internet is required for murattal."))
        tombolAudioAyat = null
        bangunKontrolPemutarAudio()
        info(tr("Cara pemutaran: ", "Playback range: ") + namaTargetPemutaran())
        tombol(tr("Hentikan audio", "Stop audio")) { hentikanAudio(); perbaruiStatusAudio(tr("Audio dihentikan. Posisi bacaan disimpan.", "Audio stopped. Reading position saved.")) }
        tombol(tr("Cari juz, surah, atau ayat", "Search juz, surah, or verse")) { dialogCariAudio() }
        tombol(tr("Putar satu halaman mushaf", "Play one mushaf page")) { pilihHalamanUntukDiputar() }
        bagian(tr("NAVIGASI AYAT", "VERSE NAVIGATION"))
    }

    /** Tata letak pemutar bergaya profesional: navigasi trek, kontrol utama, lalu kecepatan. */
    private fun bangunKontrolPemutarAudio() {
        val barisNavigasi = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            contentDescription = tr("Kontrol trek audio", "Audio track controls")
        }
        fun buatKontrol(label: String, deskripsi: String, aksi: () -> Unit, utama: Boolean = false): android.widget.Button {
            return android.widget.Button(this).apply {
                text = label
                contentDescription = deskripsi
                isAllCaps = false
                textSize = if (utama) 15f else 13f
                minHeight = dp(if (utama) 64 else 56)
                minimumHeight = dp(if (utama) 64 else 56)
                setOnClickListener { aksi() }
                importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
                layoutParams = LinearLayout.LayoutParams(0, -2, if (utama) 1.35f else 1f).apply {
                    setMargins(dp(3), dp(4), dp(3), dp(4))
                }
            }
        }
        barisNavigasi.addView(buatKontrol("⏮ Sebelumnya", tr("Audio sebelumnya", "Previous audio track"), { pindahTrekAudio(-1) }))
        val tombolUtama = buatKontrol("▶ Putar", tr("Putar audio atau lanjutkan audio yang dijeda", "Play audio or resume paused audio"), { jedaLanjutAudio() }, true)
        tombolJedaAudio = tombolUtama
        barisNavigasi.addView(tombolUtama)
        barisNavigasi.addView(buatKontrol("Berikutnya ⏭", tr("Audio berikutnya", "Next audio track"), { pindahTrekAudio(1) }))
        root.addView(barisNavigasi, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val barisKecepatan = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        barisKecepatan.addView(buatKontrol("− Lambat", tr("Perlambat kecepatan audio", "Decrease audio playback speed"), { ubahKecepatanAudio(-1) }))
        val labelKecepatan = TextView(this).apply {
            text = labelKecepatanAudio()
            textSize = 16f
            gravity = Gravity.CENTER
            contentDescription = tr("Kecepatan pemutaran saat ini ", "Current playback speed ") + labelKecepatanAudio()
            setPadding(dp(4), dp(12), dp(4), dp(12))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        teksKecepatanAudio = labelKecepatan
        barisKecepatan.addView(labelKecepatan, LinearLayout.LayoutParams(0, -2, 1f))
        barisKecepatan.addView(buatKontrol("+ Cepat", tr("Percepat kecepatan audio", "Increase audio playback speed"), { ubahKecepatanAudio(1) }))
        root.addView(barisKecepatan, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        perbaruiTombolJedaAudio()
    }

    private fun labelKecepatanAudio(): String = String.format(Locale.ROOT, "%.2fx", kecepatanAudio)

    private fun ubahKecepatanAudio(arah: Int) {
        val values = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)
        val index = values.indices.firstOrNull { kotlin.math.abs(values[it] - kecepatanAudio) < 0.001f } ?: 1
        kecepatanAudio = values[(index + arah + values.size) % values.size]
        dataPrefs.edit().putFloat("kecepatan_audio", kecepatanAudio).apply()
        if (Build.VERSION.SDK_INT >= 23) try { pemutar?.let { it.playbackParams = it.playbackParams.setSpeed(kecepatanAudio) } } catch (_: Exception) { }
        val label = labelKecepatanAudio()
        teksKecepatanAudio?.text = label
        teksKecepatanAudio?.contentDescription = tr("Kecepatan pemutaran saat ini ", "Current playback speed ") + label
        teksKecepatanAudio?.announceForAccessibility(teksKecepatanAudio?.contentDescription)
        perbaruiStatusAudio(tr("Kecepatan audio diatur ke ", "Audio speed set to ") + label)
    }

    /** Pindah ke trek ayat/surah sebelumnya atau berikutnya sesuai rentang yang sedang diputar. */
    private fun pindahTrekAudio(arah: Int) {
        if (quran == null) { muatCache() }
        if (quran == null) { toast(tr("Unduh teks Al-Qur'an terlebih dahulu untuk navigasi audio.", "Download Qur'an text first to navigate audio.")); return }
        if (targetPemutaran == "surah" || qariId.startsWith("mp3quran|") || (!audioSedangAyat && !audioSedangJuz && targetPemutaran == "surah")) {
            val tujuan = (nomorSurah + arah).coerceIn(1, 114)
            if (tujuan == nomorSurah) { toast(tr("Tidak ada surah lain pada arah tersebut.", "There is no other surah in that direction.")); return }
            hentikanAudio(); nomorSurah = tujuan; nomorAyat = 1
            dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
            tampilkanPembaca(); putarAudioSurah()
            return
        }
        val tujuanGlobal = if (audioSedangJuz) audioGlobalSaatIni + arah else nomorAyatGlobal() + arah
        val batas = if (audioSedangJuz) audioGlobalAkhir else 6236
        val awal = if (audioSedangJuz) (if (audioRentangLabel.startsWith(tr("Halaman", "Page"))) rentangGlobalHalaman(halamanAktif)?.first else rentangGlobalJuz(juzAktif)?.first) ?: 1 else 1
        if (tujuanGlobal !in awal..batas) { toast(tr("Tidak ada audio sebelumnya/berikutnya dalam rentang ini.", "No previous/next audio in this range.")); return }
        val posisi = posisiSurahAyatDariGlobal(tujuanGlobal) ?: return
        val tetapJuz = audioSedangJuz
        if (tetapJuz) audioGlobalSaatIni = tujuanGlobal
        nomorSurah = posisi.first; nomorAyat = posisi.second
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val url = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + tujuanGlobal + ".mp3"
        hentikanAudio()
        audioSedangJuz = tetapJuz
        if (tetapJuz) { audioGlobalSaatIni = tujuanGlobal; audioGlobalAkhir = batas }
        audioSedangAyat = !tetapJuz
        urlAudioAyatAktif = url
        pesanAudioAyatAktif = tr("Memutar ayat ", "Playing verse ") + nomorSurah + ":" + nomorAyat
        sisaPengulanganAyat = pengulanganAyat
        tampilkanPembaca()
        tombolAudioAktif = tombolAudioAyat
        mulaiAudio(url, pesanAudioAyatAktif)
    }

    private fun bangunMenuLagi() {
        root.removeAllViews()
        tombol(tr("Kembali ke halaman sebelumnya", "Back to previous page")) { finish() }
        bangun()
    }

    private fun namaQari(): String {
        if (qariId.startsWith("mp3quran|")) return dataPrefs.getString("qari_audio_nama", "Qari MP3Quran") ?: "Qari MP3Quran"
        return daftarQari.firstOrNull { it.first == qariId }?.second
            ?: dataPrefs.getString("qari_audio_nama", null)
            ?: "Mishary Rashid Alafasy"
    }

    private fun pilihQari(induk: () -> Unit = { dialogPengaturanAudio() }) {
        if (!katalogQariSedangDimuat) {
            katalogQariSedangDimuat = true
            Thread {
                val tambahanEdisi = mutableListOf<Pair<String, String>>()
                try {
                    // Ambil hanya edisi audio ayat yang diumumkan API resmi, agar pengenal qari tambahan valid.
                    try {
                        val edisiResponse = JSONObject(fetch("https://api.alquran.cloud/v1/edition?format=audio&language=ar&type=versebyverse"))
                        val edisi = edisiResponse.optJSONArray("data")
                        if (edisi != null) for (j in 0 until edisi.length()) {
                            val e = edisi.optJSONObject(j) ?: continue
                            val idEdisi = e.optString("identifier").trim()
                            val namaEdisi = e.optString("englishName").ifBlank { e.optString("name") }.trim()
                            if (idEdisi.startsWith("ar.") && namaEdisi.isNotBlank() && daftarQari.none { it.first == idEdisi } && tambahanEdisi.none { it.first == idEdisi }) {
                                tambahanEdisi.add(idEdisi to (namaEdisi + " · audio per ayat"))
                            }
                        }
                    } catch (_: Exception) { }
                    // API diminta dalam bahasa Inggris agar nama qari tampil dengan huruf Latin
                    // dan dapat dibaca mesin TTS yang tidak memiliki suara bahasa Arab.
                    val obj = JSONObject(fetch("https://mp3quran.net/api/v3/reciters?language=eng"))
                    val reciters = obj.optJSONArray("reciters")
                    if (reciters != null) {
                        val tambahan = mutableListOf<Pair<String, String>>()
                        for (i in 0 until reciters.length()) {
                            val r = reciters.optJSONObject(i) ?: continue
                            val name = r.optString("name").trim()
                            val moshaf = r.optJSONArray("moshaf") ?: continue
                            if (name.isBlank() || moshaf.length() == 0) continue
                            val m = moshaf.optJSONObject(0) ?: continue
                            val server = m.optString("server").trim().trimEnd('/') + "/"
                            val surahList = m.optString("surah_list").trim()
                            if (!server.startsWith("https://") || surahList.isBlank()) continue
                            val id = "mp3quran|" + server + "|" + surahList
                            val child = name.lowercase(Locale.ROOT).let { it.contains("ahmad saud") || it.contains("junaid adam") || it.contains("muhammad taha") || it.contains("taha al junayd") }
                            val namaLatin = namaQariLatin(name)
                            tambahan.add(id to (if (child) "Anak · " else "MP3Quran · ") + namaLatin)
                        }
                        runOnUiThread {
                            tambahanEdisi.forEach { item -> if (daftarQari.none { q -> q.first == item.first }) daftarQari.add(item) }
                            tambahan.forEach { item -> if (daftarQariPerSurah.none { q -> q.first == item.first }) daftarQariPerSurah.add(item) }
                            tampilkanDialogPilihQari(induk)
                        }
                    } else runOnUiThread { tambahanEdisi.forEach { item -> if (daftarQari.none { q -> q.first == item.first }) daftarQari.add(item) }; tampilkanDialogPilihQari(induk) }
                } catch (_: Exception) {
                    runOnUiThread { tambahanEdisi.forEach { item -> if (daftarQari.none { q -> q.first == item.first }) daftarQari.add(item) }; tampilkanDialogPilihQari(induk) }
                }
            }.start()
        } else tampilkanDialogPilihQari(induk)
    }

    private fun namaQariLatin(nama: String): String {
        // Jika API tetap mengembalikan aksara Arab, gunakan nama Latin yang
        // tersedia pada katalog lokal atau transliterasi sederhana sebagai fallback.
        if (nama.none { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.ARABIC }) return nama
        val peta = mapOf(
            "مشاري العفاسي" to "Mishary Rashid Alafasy",
            "محمود خليل الحصري" to "Mahmoud Khalil Al-Husary",
            "محمد صديق المنشاوي" to "Mohamed Siddiq Al-Minshawi",
            "عبدالرحمن السديس" to "Abdurrahman As-Sudais",
            "سعود الشريم" to "Saud Al-Shuraim",
            "عبدالباسط عبدالصمد" to "Abdul Basit Abdus Samad",
            "ماهر المعيقلي" to "Maher Al-Muaiqly",
            "ياسر الدوسري" to "Yasser Al-Dosari"
        )
        return peta[nama.trim()] ?: nama.filter { Character.UnicodeBlock.of(it) != Character.UnicodeBlock.ARABIC }
            .replace(Regex("\\s+"), " ").trim().ifBlank { "Qari (nama Latin tidak tersedia)" }
    }

    private fun tampilkanDialogPilihQari(induk: () -> Unit = { dialogPengaturanAudio() }) {
        val pilihan = arrayOf(
            tr("Qari audio per ayat / juz", "Verse-by-verse / juz reciters"),
            tr("Qari audio per surah", "Full-surah reciters")
        )
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih jenis katalog qari", "Choose reciter catalogue"))
            .setItems(pilihan) { _, jenis ->
                val sumber = if (jenis == 0) daftarQari else daftarQariPerSurah
                if (sumber.isEmpty()) {
                    toast(if (jenis == 0) tr("Daftar qari per ayat belum tersedia.", "Verse-by-verse reciter list is not available.") else tr("Daftar qari per surah belum tersedia. Periksa koneksi internet.", "Full-surah reciter list is unavailable. Check your internet connection."))
                    handler.post { tampilkanDialogPilihQari(induk) }
                    return@setItems
                }
                val daftarTampil = sumber.toList()
                val labels = daftarTampil.map { it.second + if (it.first == qariId) tr(" (dipilih)", " (selected)") else "" }
                AlertDialog.Builder(this)
                    .setTitle(if (jenis == 0) pilihan[0] else pilihan[1])
                    .setItems(labels.toTypedArray()) { _, which ->
                        if (which in daftarTampil.indices) {
                            hentikanAudio()
                            qariId = daftarTampil[which].first
                            dataPrefs.edit().putString("qari_audio_id", qariId).putString("qari_audio_nama", daftarTampil[which].second).apply()
                            val nama = tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari()
                            infoQari?.text = nama
                            tombolStatusAudio?.text = tr("Qari dipilih: ", "Reciter selected: ") + namaQari() + tr(". Silakan pilih juz, surah, atau ayat untuk diputar.", ". Choose a juz, surah, or verse to play.")
                            tombolStatusAudio?.announceForAccessibility(tombolStatusAudio?.text)
                            toast(tr("Qari audio diubah menjadi ", "Audio reciter changed to ") + namaQari())
                            handler.post { induk() }
                        }
                    }
                    .kembaliKe(tr("Kembali ke pilihan katalog qari", "Back to reciter catalogue")) { tampilkanDialogPilihQari(induk) }
                    .show()
            }
            .kembaliKe(tr("Kembali ke pengaturan audio", "Back to audio settings")) { induk() }
            .show()
    }

    /**
     * Navigasi pengaturan (FIX55): setiap sub menu punya tombol Kembali bernama induknya, dan menutup dialog
     * dengan tombol Kembali Android atau sentuhan di luar dialog juga kembali ke induk, bukan ke menu utama Khatam.
     * Susunan: Pengaturan Khatam > (Hafalan | Pemutaran audio > ... | Pengingat | Target | Aksesibilitas | Riwayat | Statistik).
     */
    private fun AlertDialog.Builder.kembaliKe(label: String, induk: () -> Unit): AlertDialog.Builder =
        setNegativeButton(label) { _, _ -> handler.post { induk() } }
            .setOnCancelListener { handler.post { induk() } }

    private fun namaModeHafalan(): String = when (modeHafalan) {
        "ayat" -> tr("Hafalan · ulang ayat pilihan", "Memorization · repeat selected verse")
        "berurutan" -> tr("Hafalan · ulang lalu lanjut ayat", "Memorization · repeat then next verse")
        else -> tr("Putar biasa · satu kali", "Normal playback · once")
    }

    /** Pusat pengaturan Khatam: fitur yang jarang dipakai tidak memenuhi menu utama. */
    private fun dialogPengaturanKhatam() {
        val opsi = arrayOf(
            tr("Pengaturan hafalan", "Memorization settings"),
            tr("Pengaturan pemutaran audio", "Audio playback settings"),
            tr("Pengingat membaca dan hafalan", "Reading and memorization reminder"),
            tr("Target khatam", "Khatam goal"),
            tr("Pengaturan aksesibilitas", "Accessibility settings"),
            tr("Riwayat khatam", "Khatam history"),
            tr("Kemajuan dan statistik", "Progress and statistics")
        )
        AlertDialog.Builder(this)
            .setTitle(tr("Pengaturan Khatam Al-Qur'an", "Qur'an completion settings"))
            .setItems(opsi) { _, which ->
                when (which) {
                    0 -> dialogPengaturanHafalan()
                    1 -> dialogPengaturanAudio()
                    2 -> pengaturanPengingat()
                    3 -> pengaturanTarget()
                    4 -> pengaturanAksesibilitas()
                    5 -> tampilkanRiwayat()
                    6 -> tampilkanStatistik()
                }
            }
            .setNegativeButton(tr("Kembali ke menu Khatam", "Back to Khatam menu"), null)
            .show()
    }

    /** Pengaturan hafalan terpisah dari pengaturan pemutaran audio. */
    private fun dialogPengaturanHafalan() {
        val opsi = arrayOf(
            tr("Mode hafalan audio", "Audio memorization mode"),
            tr("Jumlah pengulangan ayat", "Verse repetition count"),
            tr("Jeda antar ayat", "Pause between verses")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan Hafalan", "Memorization Settings"))
            .setItems(opsi) { _, which -> when (which) {
                0 -> pengaturanModeHafalan()
                1 -> pengaturanPengulanganAyat()
                2 -> pengaturanJedaAntarAyat()
            } }.kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }.show()
    }

    /** Seluruh pilihan keluaran dan rentang audio berada pada satu kelompok. */
    private fun dialogPengaturanAudio() {
        val opsi = arrayOf(
            tr("Pilih suara qari", "Choose reciter voice"),
            tr("Pilihan pemutaran: Arab / terjemahan", "Playback: Arabic / translation"),
            tr("Cara pemutaran: ayat / surah / juz / halaman", "Playback range: verse / surah / juz / page"),
            tr("Keluaran suara: Stereo / Mono", "Audio output: Stereo / Mono"),
            tr("Equalizer audio", "Audio equalizer"),
            tr("Kecepatan audio", "Audio speed")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan Pemutaran Audio", "Audio Playback Settings"))
            .setItems(opsi) { _, which -> when (which) {
                0 -> pilihQari()
                1 -> pilihanPemutaranAudio()
                2 -> pengaturanTargetPemutaran()
                3 -> pengaturanStereoMono()
                4 -> pengaturanEqualizer()
                5 -> pengaturanKecepatanAudio()
            } }.kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }.show()
    }

    private fun pilihanPemutaranAudio() {
        val labels = arrayOf(
            tr("Murattal Arab saja", "Arabic recitation only"),
            tr("Audio terjemahan saja (suara mesin TTS)", "Translation audio only (device TTS voice)"),
            tr("Murattal Arab lalu terjemahan (satu ayat)", "Arabic recitation then translation (one verse)")
        )
        val values = arrayOf("arab", "terjemahan", "arab_terjemahan")
        val selected = values.indexOf(modePemutaranAudio).coerceAtLeast(0)
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Pilihan pemutaran audio", "Audio playback options"), tr("Audio terjemahan dibacakan oleh mesin suara Android dan menggunakan teks terjemahan yang sudah diunduh. Mode gabungan bekerja untuk ayat yang dipilih; audio surah penuh/juz tetap menggunakan murattal Arab.", "Translation is spoken by Android text-to-speech using the downloaded translation. Combined mode works for the selected verse; full-surah/juz playback remains Arabic recitation.")))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in values.indices) {
                    modePemutaranAudio = values[which]
                    dataPrefs.edit().putString("mode_pemutaran_audio", modePemutaranAudio).apply()
                    dialog.dismiss()
                    toast(labels[which])
                    handler.post { dialogPengaturanAudio() }
                }
            }.setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    /**
     * Judul + pesan penjelasan untuk dialog berdaftar. AlertDialog bawaan Android TIDAK menampilkan daftar
     * pilihan bila setMessage dipakai bersamaan, jadi pesan ditaruh di judul kustom.
     */
    private fun judulDenganPesan(judul: String, pesan: String): android.view.View {
        val kotak = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(20), dp(24), dp(8)) }
        kotak.addView(TextView(this).apply {
            text = judul
            setTextAppearance(android.R.style.TextAppearance_DeviceDefault_DialogWindowTitle)
        })
        kotak.addView(TextView(this).apply {
            text = pesan
            textSize = 15f
            setPadding(0, dp(8), 0, 0)
        })
        kotak.contentDescription = judul + ". " + pesan
        return kotak
    }

    private fun pengaturanStereoMono() {
        val labels = arrayOf(
            tr("Stereo (kiri dan kanan terpisah)", "Stereo (separate left and right)"),
            tr("Mono (kiri dan kanan digabung)", "Mono (left and right combined)")
        )
        val selected = if (keluaranMono) 1 else 0
        AlertDialog.Builder(this).setTitle(tr("Keluaran Stereo atau Mono", "Stereo or Mono output"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                val mono = which == 1
                val berubah = mono != keluaranMono
                keluaranMono = mono
                dataPrefs.edit().putString("keluaran_suara_audio", if (mono) "mono" else "stereo").apply()
                dialog.dismiss()
                val sedangJalan = pemutar != null && audioSiap
                val pesan = (if (mono) tr("Keluaran mono aktif: suara kiri dan kanan digabung.", "Mono output on: left and right are combined.") else tr("Keluaran stereo aktif.", "Stereo output on.")) +
                    (if (berubah && sedangJalan) tr(" Berlaku mulai audio berikutnya; hentikan lalu putar ulang untuk mendengarnya sekarang.", " Applies from the next audio; stop and play again to hear it now.") else "")
                toast(pesan)
                perbaruiStatusAudio(pesan)
                handler.post { dialogPengaturanAudio() }
            }
            .setNeutralButton(tr("Pengaturan mono sistem", "System mono setting")) { _, _ ->
                try {
                    kembaliSetelahLayarSistem = { pengaturanStereoMono() }
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                    kembaliSetelahLayarSistem = null
                    toast(tr("Pengaturan aksesibilitas tidak dapat dibuka otomatis.", "Could not open accessibility settings."))
                    handler.post { pengaturanStereoMono() }
                }
            }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    // ====================================================================================
    // EQUALIZER AUDIO (FIX47)
    // Satu sesi audio tetap dipakai semua pemutar murattal, sehingga efek dibuat sekali, dapat diatur
    // kapan saja (juga saat audio belum diputar), dan langsung terdengar pada audio yang sedang berjalan.
    // ====================================================================================

    private var sesiAudioEfek = 0
    private var bassBoostAudio: android.media.audiofx.BassBoost? = null
    private val kunciPresetEqualizer = arrayOf("normal", "vocal", "bass", "treble", "kustom")

    /** Buat sesi audio bersama dan Equalizer bila belum ada. */
    private fun pastikanEfekAudio(): Boolean {
        if (equalizerAudio != null) return true
        return try {
            if (sesiAudioEfek <= 0) {
                val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                sesiAudioEfek = am.generateAudioSessionId()
            }
            if (sesiAudioEfek <= 0) {
                statusEqualizer = "gagal membuat sesi audio"
                return false
            }
            equalizerAudio = Equalizer(0, sesiAudioEfek)
            true
        } catch (e: Exception) {
            statusEqualizer = "tidak didukung: " + e.javaClass.simpleName
            equalizerAudio = null
            false
        }
    }

    private fun lepasEfekAudio() {
        try { bassBoostAudio?.release() } catch (_: Exception) { }
        bassBoostAudio = null
        sesiAudioEfek = 0
    }

    /** Penguatan (dB) tiap preset menurut frekuensi pusat pita, tidak mengandaikan jumlah pita tertentu. */
    private fun gainPresetDb(preset: String, hz: Float): Float = when (preset) {
        "vocal" -> when {
            hz < 120f -> -3f
            hz < 400f -> -1f
            hz < 1500f -> 3f
            hz < 6000f -> 5f
            else -> 1f
        }
        "bass" -> when {
            hz < 120f -> 6f
            hz < 400f -> 4f
            hz < 1500f -> 1f
            hz < 6000f -> -1f
            else -> -2f
        }
        "treble" -> when {
            hz < 120f -> -3f
            hz < 400f -> -2f
            hz < 1500f -> 0f
            hz < 6000f -> 4f
            else -> 6f
        }
        else -> 0f
    }

    private fun levelKustomTersimpan(jumlahBand: Int): IntArray {
        val simpan = (dataPrefs.getString("equalizer_kustom_mb", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }
        return IntArray(jumlahBand) { simpan.getOrElse(it) { 0 } }
    }

    private fun labelFrekuensi(eq: Equalizer, band: Int): String {
        val hz = eq.getCenterFreq(band.toShort()) / 1000
        return if (hz >= 1000) String.format(Locale.ROOT, "%.1f kHz", hz / 1000f).replace(".0 kHz", " kHz") else "" + hz + " Hz"
    }

    /** Terapkan preset aktif pada Equalizer (dan BassBoost untuk preset Bass). Mengembalikan true bila efek aktif/sah. */
    private fun terapkanEqualizer(): Boolean {
        if (!pastikanEfekAudio()) return false
        val eq = equalizerAudio ?: return false
        return try {
            if (!eq.hasControl()) {
                statusEqualizer = "efek audio sedang dikendalikan aplikasi lain atau sistem"
                return false
            }
            val jumlahBand = eq.numberOfBands.toInt()
            if (jumlahBand <= 0) {
                statusEqualizer = "perangkat tidak menyediakan pita equalizer"
                return false
            }
            val minimum = eq.bandLevelRange[0].toInt()
            val maksimum = eq.bandLevelRange[1].toInt()
            val aktif = presetEqualizer != "normal"
            // Aktifkan dahulu: sebagian perangkat mengabaikan perubahan pita saat efek masih nonaktif.
            eq.enabled = aktif
            val kustom = if (presetEqualizer == "kustom") levelKustomTersimpan(jumlahBand) else null
            for (i in 0 until jumlahBand) {
                val hz = eq.getCenterFreq(i.toShort()).toFloat() / 1000f
                val mB = if (kustom != null) kustom[i] else (gainPresetDb(presetEqualizer, hz) * 100f).toInt()
                eq.setBandLevel(i.toShort(), mB.coerceIn(minimum, maksimum).toShort())
            }
            terapkanBassBoost(presetEqualizer == "bass")
            statusEqualizer = if (aktif) "aktif: " + presetEqualizer else "normal"
            !aktif || eq.enabled
        } catch (e: Exception) {
            statusEqualizer = "gagal diterapkan: " + e.javaClass.simpleName
            false
        }
    }

    private fun terapkanBassBoost(hidup: Boolean) {
        try {
            if (hidup) {
                if (bassBoostAudio == null && sesiAudioEfek > 0) bassBoostAudio = android.media.audiofx.BassBoost(0, sesiAudioEfek)
                bassBoostAudio?.let { if (it.strengthSupported) it.setStrength(600.toShort()); it.enabled = true }
            } else {
                bassBoostAudio?.enabled = false
            }
        } catch (_: Exception) {
            try { bassBoostAudio?.release() } catch (_: Exception) { }
            bassBoostAudio = null
        }
    }

    private fun pengaturanEqualizer() {
        val labels = arrayOf(tr("Normal (mati)", "Normal (off)"), tr("Vokal / bacaan", "Vocal / recitation"), tr("Bass", "Bass"), tr("Treble", "Treble"), tr("Kustom (atur tiap pita)", "Custom (adjust each band)"))
        val selected = kunciPresetEqualizer.indexOf(presetEqualizer).coerceAtLeast(0)
        val ada = pastikanEfekAudio()
        val info = if (ada) {
            val eq = equalizerAudio
            tr("Perangkat menyediakan ", "This device provides ") + (eq?.numberOfBands?.toInt() ?: 0) + tr(" pita equalizer. Pilihan langsung berlaku, juga pada audio yang sedang diputar.", " equalizer bands. Your choice applies immediately, including audio that is playing.")
        } else tr("Equalizer tidak tersedia di perangkat ini (", "Equalizer is not available on this device (") + statusEqualizer + tr("). Pemutaran tetap berjalan dengan suara normal.", "). Playback continues with normal sound.")
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Equalizer audio", "Audio equalizer"), info))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in kunciPresetEqualizer.indices) {
                    presetEqualizer = kunciPresetEqualizer[which]
                    dataPrefs.edit().putString("preset_equalizer_audio", presetEqualizer).apply()
                    dialog.dismiss()
                    if (presetEqualizer == "kustom") { handler.post { dialogEqualizerKustom() }; return@setSingleChoiceItems }
                    val berhasil = terapkanEqualizer()
                    val pesanEq = if (berhasil) tr("Equalizer: ", "Equalizer: ") + labels[which] else tr("Preset disimpan, tetapi tidak dapat diaktifkan: ", "Preset saved but could not be activated: ") + statusEqualizer
                    toast(pesanEq)
                    perbaruiStatusAudio(pesanEq)
                    handler.post { dialogPengaturanAudio() }
                }
            }.setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    /** Pengaturan kustom: satu penggeser per pita (langkah 1 dB), langsung terdengar saat digeser. */
    private fun dialogEqualizerKustom() {
        if (!pastikanEfekAudio()) {
            toast(tr("Equalizer tidak tersedia di perangkat ini.", "Equalizer is not available on this device."))
            handler.post { dialogPengaturanAudio() }
            return
        }
        val eq = equalizerAudio ?: run { handler.post { dialogPengaturanAudio() }; return }
        val jumlahBand = eq.numberOfBands.toInt()
        if (jumlahBand <= 0) { toast(tr("Perangkat tidak menyediakan pita equalizer.", "This device has no equalizer bands.")); handler.post { dialogPengaturanAudio() }; return }
        val minimum = eq.bandLevelRange[0].toInt()
        val maksimum = eq.bandLevelRange[1].toInt()
        val langkahMax = ((maksimum - minimum) / 100).coerceAtLeast(1)
        val level = levelKustomTersimpan(jumlahBand)
        fun teksDb(mB: Int): String = String.format(Locale.ROOT, "%+d dB", mB / 100)
        val isi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        try { eq.enabled = true } catch (_: Exception) { }
        for (i in 0 until jumlahBand) {
            val nama = labelFrekuensi(eq, i)
            val label = TextView(this).apply { textSize = 16f; setPadding(0, dp(12), 0, 0) }
            val bar = android.widget.SeekBar(this).apply {
                max = langkahMax
                progress = ((level[i].coerceIn(minimum, maksimum) - minimum) / 100).coerceIn(0, langkahMax)
            }
            fun perbarui() {
                val teks = nama + ": " + teksDb(level[i])
                label.text = teks
                bar.contentDescription = teks
            }
            perbarui()
            bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                    level[i] = (minimum + progress * 100).coerceIn(minimum, maksimum)
                    perbarui()
                    if (fromUser) try { equalizerAudio?.setBandLevel(i.toShort(), level[i].toShort()) } catch (_: Exception) { }
                }
                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) { seekBar?.announceForAccessibility(label.text) }
            })
            isi.addView(label)
            isi.addView(bar)
        }
        val gulir = android.widget.ScrollView(this).apply { addView(isi) }
        val dialog = AlertDialog.Builder(this).setTitle(tr("Equalizer kustom", "Custom equalizer"))
            .setView(gulir)
            .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                dataPrefs.edit().putString("equalizer_kustom_mb", level.joinToString(",")).putString("preset_equalizer_audio", "kustom").apply()
                presetEqualizer = "kustom"
                val berhasil = terapkanEqualizer()
                val pesan = if (berhasil) tr("Equalizer kustom disimpan dan aktif.", "Custom equalizer saved and active.") else tr("Disimpan, tetapi tidak dapat diaktifkan: ", "Saved but could not be activated: ") + statusEqualizer
                toast(pesan); perbaruiStatusAudio(pesan)
                handler.post { dialogPengaturanAudio() }
            }
            .setNeutralButton(tr("Setel ulang", "Reset"), null)
            .setNegativeButton(tr("Batal", "Cancel")) { _, _ -> terapkanEqualizer(); handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { terapkanEqualizer(); handler.post { dialogPengaturanAudio() } }
            .create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            for (i in 0 until jumlahBand) {
                level[i] = 0.coerceIn(minimum, maksimum)
                try { eq.setBandLevel(i.toShort(), level[i].toShort()) } catch (_: Exception) { }
                (isi.getChildAt(i * 2 + 1) as? android.widget.SeekBar)?.progress = ((level[i] - minimum) / 100).coerceIn(0, langkahMax)
            }
            dialog.window?.decorView?.announceForAccessibility(tr("Semua pita dikembalikan ke 0 dB.", "All bands reset to 0 dB."))
        }
    }

    // ====================================================================================
    // KOREKSI HAFALAN (FIX46)
    // Dua jalur: (1) koreksi otomatis dengan pengenalan suara, (2) latihan mandiri tanpa mikrofon.
    // Keduanya selalu dijalankan dari layar pembaca supaya teks ayat benar-benar dapat disembunyikan.
    // ====================================================================================

    private data class KataArab(val tampil: String, val kunci: String)

    private var ayatTerbukaKoreksi = false
    private var hasilKoreksiTampil = false
    private var sedangMendengarkanHafalan = false
    private var sudahCobaJalurSistem = false

    /** Pastikan layar pembaca tampil dengan ayat aktif. Mengembalikan false jika teks belum ada. */
    private fun pastikanDiPembaca(): Boolean {
        // Dibuka dari menu utama: pakai posisi bacaan terakhir yang tersimpan.
        if (!sedangDiPembaca) {
            nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1, 114)
            nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        }
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return false }
        if (getAyat(nomorSurah, nomorAyat) == null) {
            toast(tr("Teks ayat belum tersedia. Unduh teks Al-Qur'an terlebih dahulu.", "Verse text is unavailable. Download Qur'an text first."))
            return false
        }
        if (!sedangDiPembaca || ayatArab == null) tampilkanPembaca()
        return ayatArab != null
    }

    private fun sembunyikanAyatLatihan() {
        latihanHafalanAktif = true
        ayatTerbukaKoreksi = false
        ayatArab?.visibility = android.view.View.INVISIBLE
        ayatArti?.visibility = android.view.View.GONE
    }

    private fun tampilkanAyatLatihan() {
        latihanHafalanAktif = false
        ayatTerbukaKoreksi = true
        ayatArab?.visibility = android.view.View.VISIBLE
        ayatArti?.visibility = if (tampilkanArti) android.view.View.VISIBLE else android.view.View.GONE
    }

    // Mode senyap TalkBack (FIX50): selama mikrofon bersiap/mendengarkan, isi dialog disembunyikan dari TalkBack,
    // pengumuman dimatikan, dan ucapan TalkBack yang sedang berjalan diinterupsi agar tidak tertangkap mikrofon.
    private var modaSenyapKoreksi = false
    private var isiKoreksiHafalan: android.view.View? = null
    private var penundaMulaiKoreksi: Runnable? = null

    private fun talkBackAktif(): Boolean = try {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        am.isEnabled && am.isTouchExplorationEnabled
    } catch (_: Exception) { false }

    private fun senyapkanTalkBack(aktif: Boolean) {
        modaSenyapKoreksi = aktif
        isiKoreksiHafalan?.importantForAccessibility = if (aktif) android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS else android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        if (aktif) {
            try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
        }
    }

    /** Isyarat getar sebagai pengganti pengumuman suara saat mikrofon siap. */
    private fun getarIsyarat(ms: Long) {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun setStatusKoreksi(pesan: String, umumkan: Boolean = true) {
        val tv = statusKoreksiHafalan ?: return
        tv.text = pesan
        if (umumkan && !modaSenyapKoreksi) tv.announceForAccessibility(pesan)
    }

    /** Pemeriksaan urutan kata dengan layanan pengenalan suara Android. Ini bukan penilaian tajwid. */
    private fun mulaiKoreksiOtomatisHafalan() {
        if (!pastikanDiPembaca()) return
        val layananSuaraAda = try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
        val dialogSistemAda = try { packageManager.queryIntentActivities(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).isNotEmpty() } catch (_: Exception) { false }
        if (!layananSuaraAda && !dialogSistemAda) {
            AlertDialog.Builder(this).setTitle(tr("Pengenalan suara tidak tersedia", "Speech recognition unavailable"))
                .setMessage(tr("HP ini belum menyediakan layanan pengenalan suara. Pasang atau aktifkan layanan suara (misalnya aplikasi Google) di Pengaturan Android. Anda tetap dapat memakai Latihan koreksi mandiri tanpa mikrofon.", "This phone has no speech recognition service. Install or enable a speech service (for example the Google app) in Android settings. You can still use the self-check practice without a microphone."))
                .setPositiveButton(tr("Buka latihan mandiri", "Open self-check practice")) { _, _ -> handler.post { latihanKoreksiHafalan() } }
                .setNegativeButton(tr("Tutup", "Close"), null)
                .show()
            return
        }
        val isi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        val petunjuk = TextView(this).apply {
            text = tr("Ayat yang diperiksa: surah ", "Verse to check: surah ") + nomorSurah +
                tr(", ayat ", ", verse ") + nomorAyat + tr(".\n\nTekan Mulai membaca, lalu bacalah ayat dengan jelas dari hafalan. Setelah Anda berhenti, bacaan diubah menjadi teks dan urutan katanya dibandingkan dengan ayat.\n\nPemeriksaan ini hanya perkiraan untuk menemukan kata yang mungkin terlewat, berubah, atau bertambah. Pengenalan suara bisa keliru. Fitur ini TIDAK menilai tajwid, makhraj, panjang-pendek, sifat huruf, atau kualitas bacaan. Suara diproses oleh layanan pengenalan suara di HP dan mungkin memerlukan internet.", ".\n\nPress Start reciting and recite the verse clearly from memory. When you stop, the speech is converted to text and its word order is compared with the verse.\n\nThis is an estimate to find words that may be omitted, changed, or added. Speech recognition can be wrong. It does NOT assess tajwid, articulation, elongation, letter qualities, or recitation quality. Audio is processed by the speech service on your phone and may require internet.")
            textSize = 16f
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        statusKoreksiHafalan = TextView(this).apply {
            text = tr("Status: belum dimulai.", "Status: not started.")
            textSize = 16f
            setPadding(0, dp(16), 0, dp(8))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        isi.addView(petunjuk)
        isi.addView(statusKoreksiHafalan)
        val gulir = android.widget.ScrollView(this).apply { addView(isi) }
        isiKoreksiHafalan = gulir
        modaSenyapKoreksi = false
        hasilKoreksiTampil = false
        sedangMendengarkanHafalan = false
        val dialog = AlertDialog.Builder(this)
            .setTitle(tr("Koreksi hafalan dengan suara", "Voice-assisted memorization check"))
            .setView(gulir)
            .setPositiveButton(tr("Mulai membaca", "Start reciting"), null)
            .setNeutralButton(tr("Hentikan", "Stop"), null)
            .setNegativeButton(tr("Tutup", "Close"), null)
            .create()
        dialogKoreksiHafalan = dialog
        dialog.setOnDismissListener {
            try { speechRecognizerHafalan?.cancel(); speechRecognizerHafalan?.destroy() } catch (_: Exception) { }
            speechRecognizerHafalan = null
            penundaMulaiKoreksi?.let { handler.removeCallbacks(it) }
            penundaMulaiKoreksi = null
            senyapkanTalkBack(false)
            isiKoreksiHafalan = null
            sedangMendengarkanHafalan = false
            hasilKoreksiTampil = false
            tampilkanAyatLatihan()
            latihanHafalanAktif = false
            statusKoreksiHafalan = null
            dialogKoreksiHafalan = null
        }
        sembunyikanAyatLatihan()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 6905)
            } else mulaiPengenalanBacaanAyat()
        }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val tombolLain = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            if (hasilKoreksiTampil) {
                if (ayatTerbukaKoreksi) {
                    sembunyikanAyatLatihan()
                    tombolLain.text = tr("Tampilkan ayat", "Reveal verse")
                    ayatArab?.announceForAccessibility(tr("Ayat disembunyikan.", "Verse hidden."))
                } else {
                    tampilkanAyatLatihan()
                    tombolLain.text = tr("Sembunyikan ayat", "Hide verse")
                    ayatArab?.announceForAccessibility(tr("Teks ayat ditampilkan.", "Verse text revealed."))
                }
            } else {
                try { speechRecognizerHafalan?.cancel() } catch (_: Exception) { }
                penundaMulaiKoreksi?.let { handler.removeCallbacks(it) }
                penundaMulaiKoreksi = null
                sedangMendengarkanHafalan = false
                senyapkanTalkBack(false)
                setStatusKoreksi(tr("Status: perekaman dihentikan. Tekan Mulai membaca untuk mencoba lagi.", "Status: listening stopped. Press Start reciting to try again."))
            }
        }
    }

    /** Titik masuk: senyapkan TalkBack lebih dulu, beri jeda ±1 detik, baru mikrofon dibuka. */
    private fun mulaiPengenalanBacaanAyat() {
        if (statusKoreksiHafalan == null) return
        senyapkanTalkBack(true)
        penundaMulaiKoreksi?.let { handler.removeCallbacks(it) }
        val r = Runnable { penundaMulaiKoreksi = null; mulaiPengenalanSekarang() }
        penundaMulaiKoreksi = r
        handler.postDelayed(r, 1000L)
    }

    private fun mulaiPengenalanSekarang() {
        if (statusKoreksiHafalan == null) return
        senyapkanTalkBack(true)
        hentikanAudio()
        sembunyikanAyatLatihan()
        hasilKoreksiTampil = false
        sudahCobaJalurSistem = false
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_POSITIVE)?.text = tr("Mulai membaca", "Start reciting")
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_NEUTRAL)?.text = tr("Hentikan", "Stop")
        try { speechRecognizerHafalan?.cancel(); speechRecognizerHafalan?.destroy() } catch (_: Exception) { }
        speechRecognizerHafalan = null
        val layananAda = try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
        if (!layananAda) { mulaiPengenalanLewatDialogSistem(); return }
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizerHafalan = recognizer
            sedangMendengarkanHafalan = true
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (speechRecognizerHafalan !== recognizer) return
                    senyapkanTalkBack(true)
                    getarIsyarat(150L)
                    setStatusKoreksi(tr("Mikrofon siap. Silakan mulai membaca ayat sekarang.", "Microphone ready. Start reciting the verse now."))
                }
                override fun onBeginningOfSpeech() {
                    if (speechRecognizerHafalan !== recognizer) return
                    setStatusKoreksi(tr("Bacaan terdeteksi. Silakan lanjutkan sampai selesai.", "Speech detected. Continue until you finish."), false)
                }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() {
                    if (speechRecognizerHafalan !== recognizer) return
                    setStatusKoreksi(tr("Bacaan selesai diterima. Sedang memeriksa urutan kata…", "Recitation received. Checking word order…"))
                }
                override fun onError(error: Int) {
                    if (speechRecognizerHafalan !== recognizer) return
                    sedangMendengarkanHafalan = false
                    // 4=SERVER, 5=CLIENT, 8=BUSY, 11=SERVER_DISCONNECTED, 12=LANGUAGE_NOT_SUPPORTED, 13=LANGUAGE_UNAVAILABLE
                    if (error in listOf(4, 5, 8, 11, 12, 13) && !sudahCobaJalurSistem) {
                        try { recognizer.cancel(); recognizer.destroy() } catch (_: Exception) { }
                        speechRecognizerHafalan = null
                        mulaiPengenalanLewatDialogSistem()
                        return
                    }
                    val pesan = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> tr("Bacaan belum dapat dikenali. Coba di tempat lebih tenang dan baca dengan jelas, lalu tekan Mulai membaca.", "Speech was not recognized. Try a quieter place and speak clearly, then press Start reciting.")
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> tr("Tidak terdengar bacaan. Tekan Mulai membaca untuk mencoba lagi.", "No speech was heard. Press Start reciting to try again.")
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> tr("Izin mikrofon belum diberikan. Aktifkan izin mikrofon untuk aplikasi ini di Pengaturan Android.", "Microphone permission was not granted. Enable the microphone permission for this app in Android settings.")
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> tr("Layanan suara memerlukan internet yang stabil. Periksa koneksi lalu coba lagi.", "The speech service needs a stable internet connection. Check your connection and try again.")
                        SpeechRecognizer.ERROR_AUDIO -> tr("Mikrofon tidak dapat dipakai. Tutup aplikasi lain yang memakai mikrofon lalu coba lagi.", "The microphone could not be used. Close other apps using the microphone and try again.")
                        else -> tr("Layanan pengenalan suara mengalami kendala (kode " + error + "). Coba lagi beberapa saat.", "Speech recognition encountered a problem (code " + error + "). Try again shortly.")
                    }
                    senyapkanTalkBack(false)
                    setStatusKoreksi(pesan)
                    if (!talkBackAktif()) bicaraUmpanBalikKoreksi(pesan)
                }
                override fun onResults(results: Bundle?) {
                    if (speechRecognizerHafalan !== recognizer) return
                    sedangMendengarkanHafalan = false
                    prosesHasilSuara(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty())
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    if (speechRecognizerHafalan !== recognizer) return
                    val sementara = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (sementara.isNotBlank()) setStatusKoreksi(tr("Terdengar sementara:\n", "Heard so far:\n") + teksArabTampil(sementara), false)
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            setStatusKoreksi(tr("Menyiapkan pengenalan suara…", "Preparing speech recognition…"), false)
            recognizer.startListening(buatIntentPengenalan(true))
        } catch (e: Exception) {
            sedangMendengarkanHafalan = false
            mulaiPengenalanLewatDialogSistem()
        }
    }

    private fun buatIntentPengenalan(sebagian: Boolean): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, sebagian)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        putExtra(RecognizerIntent.EXTRA_PROMPT, tr("Bacalah ayat Al-Qur'an", "Recite the Qur'an verse"))
    }

    /** Jalur cadangan: dialog pengenalan suara bawaan sistem (Google/Samsung) bila layanan langsung gagal. */
    @Suppress("DEPRECATION")
    private fun mulaiPengenalanLewatDialogSistem() {
        sudahCobaJalurSistem = true
        try {
            setStatusKoreksi(tr("Membuka layar pengenalan suara sistem. Bacalah ayat setelah layar muncul.", "Opening the system speech screen. Recite the verse once it appears."))
            sedangMendengarkanHafalan = true
            startActivityForResult(buatIntentPengenalan(false), 6906)
        } catch (e: Exception) {
            sedangMendengarkanHafalan = false
            senyapkanTalkBack(false)
            val pesan = tr("Layanan pengenalan suara tidak dapat dibuka di HP ini. Pasang atau perbarui aplikasi Google, atau gunakan Latihan koreksi mandiri tanpa mikrofon.", "Speech recognition could not be opened on this phone. Install or update the Google app, or use the self-check practice without a microphone.")
            setStatusKoreksi(pesan)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 6906) {
            sedangMendengarkanHafalan = false
            if (statusKoreksiHafalan == null) return
            if (resultCode == RESULT_OK) {
                prosesHasilSuara(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty())
            } else {
                senyapkanTalkBack(false)
                setStatusKoreksi(tr("Tidak ada hasil pengenalan suara. Tekan Mulai membaca untuk mencoba lagi.", "No speech result. Press Start reciting to try again."))
            }
        }
    }

    private fun prosesHasilSuara(kandidat: List<String>) {
        if (statusKoreksiHafalan == null) return
        val teksAcuan = teksArabTampil(getAyat(nomorSurah, nomorAyat)?.optString("text", "").orEmpty())
        val kandidatArab = kandidat.filter { Regex("[\\u0600-\\u06FF]").containsMatchIn(it) }
        val hasil: Triple<Int, String, String> = when {
            kandidat.isEmpty() -> Triple(-1, tr("Tidak ada hasil yang diterima. Silakan ulangi.", "No result was received. Please try again."), tr("Tidak ada hasil. Silakan ulangi.", "No result. Please try again."))
            kandidatArab.isEmpty() -> Triple(-1, tr("Layanan suara mengembalikan teks non-Arab (\"", "The speech service returned non-Arabic text (\"") + kandidat.first() + tr("\"). Tidak ada penilaian yang dibuat. Atur bahasa pengenalan suara HP ke Arab, lalu coba lagi.", "\"). No assessment was made. Set the phone's speech recognition language to Arabic and try again."), tr("Teks Arab tidak diterima. Periksa bahasa pengenalan suara.", "Arabic text was not returned. Check speech recognition language."))
            else -> kandidatArab.map { bandingkanBacaanAyat(teksAcuan, it) }.filter { it.first >= 0 }.minByOrNull { it.first }
                ?: Triple(-1, tr("Hasil suara belum dapat dibandingkan. Silakan ulangi.", "Speech result could not be compared. Please try again."), tr("Hasil belum dapat diperiksa.", "Result could not be checked."))
        }
        val dikenali = kandidatArab.firstOrNull().orEmpty()
        val pesan = tr("Teks ayat asli:\n", "Original verse text:\n") + teksAcuan + "\n\n" +
            (if (dikenali.isNotBlank()) tr("Teks yang dikenali:\n", "Recognized text:\n") + teksArabTampil(dikenali) + "\n\n" else "") + hasil.second
        // Ayat ditampilkan setelah ada hasil agar pengguna dapat membandingkan langsung.
        tampilkanAyatLatihan()
        hasilKoreksiTampil = true
        senyapkanTalkBack(false)
        setStatusKoreksi(pesan)
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_POSITIVE)?.text = tr("Ulangi membaca", "Recite again")
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_NEUTRAL)?.text = tr("Sembunyikan ayat", "Hide verse")
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(180, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(180)
                }
            }
        } catch (_: Exception) { }
        if (!talkBackAktif()) bicaraUmpanBalikKoreksi(hasil.third)
    }

    private fun bicaraUmpanBalikKoreksi(pesan: String) {
        if (!ttsSiap || pesan.isBlank()) return
        try { ttsTerjemahan?.speak(pesan, TextToSpeech.QUEUE_FLUSH, null, "koreksi_" + UUID.randomUUID()) } catch (_: Exception) { }
    }

    /** Pastikan teks mushaf yang ditampilkan adalah karakter Arab, bukan literal escape/HTML entity. */
    private fun teksArabTampil(teks: String): String {
        var hasil = teks.trim()
        try { hasil = android.text.Html.fromHtml(hasil, android.text.Html.FROM_HTML_MODE_LEGACY).toString() } catch (_: Exception) { }
        hasil = Regex("\\\\u([0-9a-fA-F]{4})").replace(hasil) { m -> m.groupValues[1].toInt(16).toChar().toString() }
        return hasil.trim()
    }

    /**
     * Kunci perbandingan kata: tanpa harakat/tanda baca mushaf, bentuk hamzah/alif disamakan, dan alif di tengah kata
     * dibuang agar ejaan mushaf (العٰلمين) dan ejaan hasil pengenalan suara (العالمين) dianggap sama.
     * Hanya untuk perbandingan kasar; bukan penilaian harakat atau tajwid.
     */
    private fun kunciKataArab(kata: String): String {
        var k = java.text.Normalizer.normalize(kata, java.text.Normalizer.Form.NFKC)
            .replace(Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]"), "")
            .replace("ـ", "")
            .replace(Regex("[أإآٱ]"), "ا")
            .replace("ؤ", "و").replace("ئ", "ي").replace("ى", "ي").replace("ة", "ه")
            .replace(Regex("[^\\u0621-\\u064A]"), "")
            .replace("ء", "")
        if (k.length > 1) k = k.substring(0, 1) + k.substring(1).replace("ا", "")
        return k
    }

    private fun pecahKataArab(teks: String): List<KataArab> =
        teks.trim().split(Regex("\\s+")).map { KataArab(it, kunciKataArab(it)) }.filter { it.kunci.isNotEmpty() }

    private fun jarakHuruf(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun kataCocok(a: String, b: String): Boolean {
        if (a == b) return true
        val pendek = minOf(a.length, b.length)
        if (pendek < 4) return false
        return jarakHuruf(a, b) <= (if (pendek >= 8) 2 else 1)
    }

    private fun selaraskanKata(expected: List<KataArab>, heard: List<KataArab>): Pair<Int, List<String>> {
        val dp = Array(expected.size + 1) { IntArray(heard.size + 1) }
        for (i in 0..expected.size) dp[i][0] = i
        for (j in 0..heard.size) dp[0][j] = j
        for (i in 1..expected.size) for (j in 1..heard.size) {
            val cost = if (kataCocok(expected[i - 1].kunci, heard[j - 1].kunci)) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
        }
        var i = expected.size
        var j = heard.size
        var jumlah = 0
        val masalah = mutableListOf<String>()
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && kataCocok(expected[i - 1].kunci, heard[j - 1].kunci) && dp[i][j] == dp[i - 1][j - 1]) { i--; j--; continue }
            if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
                jumlah++
                masalah.add(tr("Kata ke-" + i + " (" + expected[i - 1].tampil + ") mungkin berbeda; terdengar: " + heard[j - 1].tampil + ".", "Word " + i + " (" + expected[i - 1].tampil + ") may differ; heard: " + heard[j - 1].tampil + "."))
                i--; j--; continue
            }
            if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
                jumlah++
                masalah.add(tr("Kata ke-" + i + " (" + expected[i - 1].tampil + ") mungkin terlewat.", "Word " + i + " (" + expected[i - 1].tampil + ") may have been omitted."))
                i--; continue
            }
            if (j > 0) {
                jumlah++
                masalah.add(tr("Mungkin ada kata tambahan: " + heard[j - 1].tampil + ".", "There may be an extra word: " + heard[j - 1].tampil + "."))
                j--; continue
            }
        }
        masalah.reverse()
        return Pair(jumlah, masalah)
    }

    /** Perbandingan tingkat kata. Hasil selalu disajikan sebagai perkiraan, bukan penilaian tajwid. */
    private fun bandingkanBacaanAyat(teksAsli: String, hasilSuara: String): Triple<Int, String, String> {
        val penuh = pecahKataArab(teksAsli)
        val heard = pecahKataArab(hasilSuara)
        if (penuh.isEmpty() || heard.isEmpty()) return Triple(-1, tr("Hasil suara kosong atau tidak terbaca. Silakan ulangi.", "Speech result was empty or unreadable. Please try again."), tr("Bacaan belum dapat diperiksa. Silakan ulangi.", "The recitation could not be checked. Please try again."))
        // Ayat pertama kebanyakan surah diawali basmalah pada data sumber; bacaan tanpa basmalah tetap dianggap benar.
        val basmalah = listOf("بسم", "الله", "الرحمن", "الرحيم")
        val varian = mutableListOf(penuh)
        if (penuh.size > 4 && penuh.take(4).map { it.kunci } == basmalah) varian.add(penuh.drop(4))
        val terbaik = varian.map { Pair(it, selaraskanKata(it, heard)) }.minByOrNull { it.second.first }!!
        val expected = terbaik.first
        val jumlah = terbaik.second.first
        val masalah = terbaik.second.second.take(6)
        val cocok = (expected.size - jumlah).coerceIn(0, expected.size)
        val ringkas = if (jumlah == 0) tr("Hasil pengenalan cocok dengan urutan kata ayat. Alhamdulillah. Ini bukan penilaian tajwid.", "Recognized words match the verse order. This is not a tajwid assessment.")
            else tr("Ada sekitar " + jumlah + " bagian kata yang perlu diperiksa. Kata yang cocok terdeteksi sekitar " + cocok + " dari " + expected.size + ".", "About " + jumlah + " word-level differences need review. Approximately " + cocok + " of " + expected.size + " expected words were recognized.")
        val detail = if (masalah.isEmpty()) ringkas else ringkas + "\n" + masalah.joinToString("\n")
        val suara = if (jumlah == 0) tr("Bacaan yang dikenali cocok dengan urutan kata ayat. Namun, tetap cocokkan dengan mushaf atau guru karena pengenalan suara bukan penilaian tajwid.", "Recognized words match the verse order. Still compare with a mushaf or teacher because speech recognition does not assess tajwid.")
            else tr("Ada " + jumlah + " bagian yang perlu diperiksa. Ini mungkin kesalahan bacaan atau kesalahan pengenalan suara. Dengarkan murattal dan cocokkan dengan mushaf atau guru.", "There are " + jumlah + " parts to review. This may be a recitation difference or a speech recognition error. Listen to the recitation and compare with a mushaf or teacher.")
        return Triple(jumlah, detail, suara)
    }

    /** Latihan koreksi mandiri tanpa mikrofon: sembunyikan ayat, baca dari hafalan, lalu tampilkan untuk mencocokkan. */
    private fun latihanKoreksiHafalan() {
        if (!pastikanDiPembaca()) return
        val pesan = tr("Ayat akan disembunyikan. Bacakan dari hafalan, lalu pilih Tampilkan jawaban untuk mencocokkan bacaan. Fitur ini adalah latihan mandiri tanpa mikrofon, bukan penilaian otomatis tajwid atau makhraj.", "The verse will be hidden. Recite from memory, then reveal the answer to compare. This is a self-guided exercise without a microphone, not automatic tajwid or articulation assessment.")
        AlertDialog.Builder(this).setTitle(tr("Latihan koreksi hafalan", "Memorization self-check"))
            .setMessage(pesan)
            .setPositiveButton(tr("Mulai latihan", "Start practice")) { _, _ -> mulaiSesiLatihanMandiri() }
            .setNegativeButton(tr("Kembali", "Back"), null).show()
    }

    private fun mulaiSesiLatihanMandiri() {
        if (!pastikanDiPembaca()) return
        hentikanAudio()
        sembunyikanAyatLatihan()
        ayatArab?.announceForAccessibility(tr("Ayat disembunyikan. Silakan membaca dari hafalan.", "Verse hidden. Recite from memory."))
        val kataPertama = pecahKataArab(teksArabTampil(getAyat(nomorSurah, nomorAyat)?.optString("text", "").orEmpty())).firstOrNull()?.tampil.orEmpty()
        val dialog = AlertDialog.Builder(this).setTitle(tr("Silakan membaca dari hafalan", "Recite from memory"))
            .setMessage(tr("Surah " + nomorSurah + ", ayat " + nomorAyat + ". Setelah selesai, tampilkan jawaban dan cocokkan setiap kata serta harakat pada mushaf.", "Surah " + nomorSurah + ", verse " + nomorAyat + ". When finished, reveal the answer and compare every word and diacritic with the text."))
            .setPositiveButton(tr("Tampilkan jawaban", "Reveal answer"), null)
            .setNeutralButton(tr("Petunjuk kata pertama", "First-word hint"), null)
            .setNegativeButton(tr("Batalkan", "Cancel")) { _, _ -> tampilkanAyatLatihan(); latihanHafalanAktif = false }
            .setOnCancelListener { tampilkanAyatLatihan(); latihanHafalanAktif = false }
            .create()
        dialog.show()
        // Tombol dipasang ulang agar dialog tidak tertutup otomatis saat petunjuk diminta.
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val petunjuk = if (kataPertama.isNotBlank()) tr("Kata pertama: ", "First word: ") + kataPertama else tr("Petunjuk tidak tersedia.", "Hint unavailable.")
            dialog.setMessage(tr("Surah " + nomorSurah + ", ayat " + nomorAyat + ".\n", "Surah " + nomorSurah + ", verse " + nomorAyat + ".\n") + petunjuk)
            dialog.window?.decorView?.announceForAccessibility(petunjuk)
        }
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            tampilkanAyatLatihan()
            ayatArab?.announceForAccessibility(tr("Jawaban ayat ditampilkan kembali.", "Verse answer revealed."))
            dialog.dismiss()
            AlertDialog.Builder(this).setTitle(tr("Cocokkan bacaan", "Compare your recitation"))
                .setMessage(tr("Apakah bacaan hafalan Anda sudah sesuai dengan teks?", "Did your memorized recitation match the text?"))
                .setPositiveButton(tr("Sudah sesuai", "Matched")) { _, _ -> toast(tr("Alhamdulillah. Lanjutkan ke ayat berikutnya.", "Well done. Continue to the next verse.")) }
                .setNeutralButton(tr("Ulangi latihan", "Practice again")) { _, _ -> handler.post { mulaiSesiLatihanMandiri() } }
                .setNegativeButton(tr("Perlu diulang", "Needs more practice")) { _, _ -> toast(tr("Silakan dengarkan murattal dan ulangi hafalan ayat ini.", "Listen to the recitation and practice this verse again.")) }
                .show()
        }
    }

    private fun teksTerjemahanAyatAktif(): String {
        val translatedSurah = terjemahan?.optJSONObject("data")?.optJSONArray("surahs")?.optJSONObject(nomorSurah - 1)
        return translatedSurah?.optJSONArray("ayahs")?.optJSONObject(nomorAyat - 1)?.optString("text", "")?.trim().orEmpty()
    }

    private fun putarTerjemahanAyat(pergantian: Boolean = false) {
        val teks = teksTerjemahanAyatAktif()
        if (teks.isBlank()) { toast(tr("Terjemahan belum tersedia. Unduh teks Al-Qur'an terlebih dahulu.", "Translation is unavailable. Download Qur'an text first.")); return }
        if (!ttsSiap || ttsTerjemahan == null) {
            toast(tr("Mesin suara belum siap atau bahasa terjemahan belum didukung. Periksa pengaturan Text-to-Speech Android.", "Speech engine is not ready or does not support this language. Check Android Text-to-Speech settings."))
            return
        }
        val id = "terjemahan_" + UUID.randomUUID().toString()
        try {
            ttsTerjemahan?.speak(teks, TextToSpeech.QUEUE_FLUSH, null, id)
            perbaruiStatusAudio(tr("Membacakan terjemahan ayat ", "Speaking translation of verse ") + nomorSurah + ":" + nomorAyat, pergantian)
            tombolJedaAudio?.text = tr("⏹ Hentikan", "⏹ Stop")
            tombolJedaAudio?.contentDescription = tr("Hentikan audio terjemahan yang sedang dibacakan", "Stop the translation currently being spoken")
        } catch (_: Exception) { toast(tr("Terjemahan tidak dapat dibacakan oleh mesin suara perangkat.", "Device speech engine could not read the translation.")) }
    }

    private fun pengaturanModeHafalan() {
        val nilai = arrayOf("biasa", "ayat", "berurutan")
        val label = arrayOf(
            tr("Putar biasa: ayat diputar satu kali", "Normal: play verse once"),
            tr("Hafalan ayat: ulang ayat yang dipilih", "Memorize verse: repeat selected verse"),
            tr("Hafalan berurutan: ulang ayat lalu lanjut otomatis", "Sequential memorization: repeat verse then continue automatically")
        )
        val selected = nilai.indexOf(modeHafalan).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(tr("Pilih mode hafalan", "Choose memorization mode"))
            .setSingleChoiceItems(label, selected) { dialog, which ->
                if (which in nilai.indices) {
                    modeHafalan = nilai[which]
                    if (modeHafalan == "biasa") pengulanganAyat = 1
                    else if (pengulanganAyat == 1) pengulanganAyat = 3
                    dataPrefs.edit().putString("mode_hafalan_audio", modeHafalan).putInt("pengulangan_audio_ayat", pengulanganAyat).apply()
                    val ringkasMode = tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat()
                    infoModeAudio?.text = ringkasMode
                    infoModeAudio?.announceForAccessibility(ringkasMode)
                    toast(tr("Mode diubah: ", "Mode changed: ") + namaModeHafalan())
                    dialog.dismiss()
                    handler.post { dialogPengaturanHafalan() }
                }
            }.setNegativeButton(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { _, _ -> handler.post { dialogPengaturanHafalan() } }.setOnCancelListener { handler.post { dialogPengaturanHafalan() } }.show()
    }

    private fun pengaturanJedaAntarAyat() {
        val nilai = intArrayOf(0, 2, 5, 10)
        val label = arrayOf(tr("Tanpa jeda", "No pause"), tr("2 detik", "2 seconds"), tr("5 detik", "5 seconds"), tr("10 detik", "10 seconds"))
        val selected = nilai.indexOf(jedaAntarAyatDetik).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(tr("Jeda sebelum ayat berikutnya", "Pause before next verse"))
            .setSingleChoiceItems(label, selected) { dialog, which ->
                if (which in nilai.indices) {
                    jedaAntarAyatDetik = nilai[which]
                    dataPrefs.edit().putInt("jeda_antar_ayat_detik", jedaAntarAyatDetik).apply()
                    toast(tr("Jeda antar ayat: ", "Pause between verses: ") + label[which])
                    dialog.dismiss()
                    handler.post { dialogPengaturanHafalan() }
                }
            }.setNegativeButton(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { _, _ -> handler.post { dialogPengaturanHafalan() } }.setOnCancelListener { handler.post { dialogPengaturanHafalan() } }.show()
    }

    private fun namaTargetPemutaran(): String = when (targetPemutaran) {
        "surah" -> tr("Seluruh surah", "Whole surah")
        "juz" -> tr("Satu juz", "One juz")
        "halaman" -> tr("Satu halaman mushaf", "One mushaf page")
        else -> tr("Ayat pilihan", "Selected verse")
    }

    private fun pengaturanTargetPemutaran() {
        val values = arrayOf("ayat", "surah", "juz", "halaman")
        val labels = arrayOf(
            tr("Per ayat", "By verse"),
            tr("Per surah", "By surah"),
            tr("Per juz", "By juz"),
            tr("Per halaman mushaf", "By mushaf page")
        )
        AlertDialog.Builder(this).setTitle(tr("Cara pemutaran audio", "Audio playback range"))
            .setSingleChoiceItems(labels, values.indexOf(targetPemutaran).coerceAtLeast(0)) { dialog, which ->
                if (which in values.indices) {
                    targetPemutaran = values[which]
                    dataPrefs.edit().putString("target_pemutaran_audio", targetPemutaran).apply()
                    val info = tr("Cara pemutaran diatur: ", "Playback range set to: ") + namaTargetPemutaran()
                    infoModeAudio?.text = info
                    infoModeAudio?.announceForAccessibility(info)
                    toast(info)
                    dialog.dismiss()
                    handler.post { dialogPengaturanAudio() }
                }
            }.setNegativeButton(tr("Kembali ke pengaturan audio", "Back to audio settings")) { _, _ -> handler.post { dialogPengaturanAudio() } }.setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    /** Tombol Putar menjalankan rentang yang sudah dipilih di Pengaturan Audio. */
    private fun mulaiSesuaiPengaturan() {
        if (modePemutaranAudio == "terjemahan") {
            if (targetPemutaran != "ayat") { toast(tr("Audio terjemahan saat ini tersedia untuk ayat yang dipilih. Ubah cara pemutaran ke ayat.", "Translation audio is currently available for the selected verse. Change playback range to verse.")); return }
            putarTerjemahanAyat()
            return
        }
        if (modePemutaranAudio == "arab_terjemahan" && targetPemutaran != "ayat") {
            toast(tr("Mode gabungan Arab dan terjemahan saat ini tersedia untuk satu ayat. Pilih cara pemutaran ayat.", "Combined Arabic and translation mode currently supports one verse. Select verse playback.")); return
        }
        val player = pemutar
        if (player != null && audioSiap && !player.isPlaying) {
            try {
                player.start()
                perbaruiTombolJedaAudio(false)
                tombolJedaAudio?.announceForAccessibility(tombolJedaAudio?.contentDescription)
                perbaruiStatusAudio(tr("Murattal dilanjutkan.", "Recitation resumed."))
                return
            } catch (_: Exception) { }
        }
        when (targetPemutaran) {
            "juz" -> pilihJuzUntukDiputar()
            "halaman" -> pilihHalamanUntukDiputar()
            "surah" -> {
                if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
                putarAudioSurah()
            }
            else -> putarAudioAyat()
        }
    }

    private fun pilihSurahUntukAudio() {
        val surahs = daftarSurah() ?: return
        val bahasaInggris = BahasaAplikasi.tampilan(this) == 1
        val labels = (0 until surahs.length()).map { i ->
            val item = surahs.optJSONObject(i) ?: JSONObject()
            val nomor = item.optInt("number")
            val nama = if (bahasaInggris) item.optString("englishName") else item.optString("name")
            "" + nomor + ". " + nama
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih surah untuk diputar", "Choose surah to play"))
            .setItems(labels) { _, which ->
                nomorSurah = which + 1
                nomorAyat = 1
                dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
                tampilkanPembaca()
                putarAudioSurah()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun dialogCariAudio() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val wadah = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun kolom(label: String): EditText = EditText(this).apply {
            hint = label
            contentDescription = label
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
            wadah.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val inputJuz = kolom(tr("Tulis nomor juz (opsional)", "Enter juz number (optional)"))
        val inputSurah = kolom(tr("Tulis nomor surah (opsional)", "Enter surah number (optional)"))
        val inputAyat = kolom(tr("Tulis nomor ayat (opsional)", "Enter verse number (optional)"))
        AlertDialog.Builder(this)
            .setTitle(tr("Cari juz, surah, atau ayat", "Find juz, surah, or verse"))
            .setMessage(tr("Isi salah satu kolom saja sudah cukup. Jika mengisi nomor ayat tanpa nomor surah, ayat dicari pada surah yang sedang dipilih (surah ", "Fill in just one field. If you enter a verse without a surah, it is searched in the currently selected surah (surah ") + nomorSurah + ").")
            .setView(wadah)
            .setPositiveButton(tr("Cari dan putar", "Find and play")) { _, _ ->
                prosesPencarianAudioTerstruktur(
                    inputJuz.text.toString().trim(),
                    inputSurah.text.toString().trim(),
                    inputAyat.text.toString().trim()
                )
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    private fun prosesPencarianAudioTerstruktur(juzText: String, surahText: String, ayatText: String) {
        val juz = juzText.toIntOrNull()
        val surah = surahText.toIntOrNull()
        val ayat = ayatText.toIntOrNull()
        if (juzText.isNotBlank() && (juz == null || juz !in 1..30)) {
            toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); return
        }
        if (surahText.isNotBlank() && (surah == null || surah !in 1..114)) {
            toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); return
        }
        if (ayatText.isNotBlank() && (ayat == null || ayat < 1)) {
            toast(tr("Nomor ayat harus berupa angka positif.", "Verse number must be a positive number.")); return
        }
        if (juz == null && surah == null && ayat == null) {
            toast(tr("Isi minimal satu kolom pencarian.", "Fill in at least one search field.")); return
        }
        // Bila juz diisi, juz menjadi tujuan utama; kolom lain tidak digunakan.
        if (juz != null) {
            if (qariId.startsWith("mp3quran|")) {
                toast(tr("Qari yang dipilih hanya menyediakan audio per surah. Pilih qari per ayat untuk memutar juz.", "The selected reciter only provides surah audio. Choose a verse-by-verse reciter to play a juz.")); return
            }
            putarJuz(juz); return
        }
        val surahTujuan = surah ?: nomorSurah
        if (ayat != null) {
            mulaiDariReferensi(surahTujuan, ayat)
        } else {
            nomorSurah = surahTujuan
            nomorAyat = 1
            dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", 1).apply()
            tampilkanPembaca()
            putarAudioSurah()
        }
    }

    private fun mulaiDariReferensi(surah: Int, ayat: Int) {
        if (surah !in 1..114) { toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); return }
        val total = getSurah(surah)?.optJSONArray("ayahs")?.length() ?: 0
        if (ayat !in 1..total) { toast(tr("Nomor ayat tidak sesuai dengan surah yang dipilih.", "Verse number is not valid for the selected surah.")); return }
        nomorSurah = surah; nomorAyat = ayat
        dataPrefs.edit().putInt("terakhir_surah", surah).putInt("terakhir_ayat", ayat).apply()
        tampilkanPembaca(); putarAudioAyat()
    }

    private fun nomorAyatGlobal(): Int {
        var global = nomorAyat
        for (i in 1 until nomorSurah) global += getSurah(i)?.optJSONArray("ayahs")?.length() ?: 0
        return global.coerceIn(1, 6236)
    }

    private fun putarAudioAyat() {
        tombolAudioAktif = tombolAudioAyat
        audioSedangAyat = true
        sisaPengulanganAyat = pengulanganAyat
        if (qariId.startsWith("mp3quran|")) {
            audioSedangAyat = false
            AlertDialog.Builder(this)
                .setTitle(tr("Audio ayat tidak tersedia untuk qari ini", "Verse audio is unavailable for this reciter"))
                .setMessage(tr("Qari MP3Quran yang dipilih hanya menyediakan rekaman per surah. Anda dapat memutar surah penuh atau memilih qari yang menyediakan audio per ayat.", "The selected MP3Quran reciter provides full-surah recordings only. You can play the whole surah or choose a reciter with verse-by-verse audio."))
                .setPositiveButton(tr("Putar surah penuh", "Play whole surah")) { _, _ -> putarAudioSurah() }
                .setNeutralButton(tr("Pilih qari audio per ayat", "Choose verse-by-verse reciter")) { _, _ -> pilihQari { } }
                .setNegativeButton(tr("Batal", "Cancel"), null)
                .show()
            return
        }
        audioSedangJuz = false
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + nomorAyatGlobal() + ".mp3"
        pesanAudioAyatAktif = tr("Memuat murattal ayat ", "Loading verse recitation ") + nomorSurah + ":" + nomorAyat
        mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif)
    }

    private fun putarAudioSurah() {
        tombolAudioAktif = tombolAudio
        audioSedangAyat = false
        audioSedangJuz = false
        val url = if (qariId.startsWith("mp3quran|")) {
            val parts = qariId.split("|")
            val server = parts.getOrNull(1) ?: ""
            val available = parts.getOrNull(2)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            if (nomorSurah !in available) {
                toast(tr("Surah ini tidak tersedia untuk qari yang dipilih.", "This surah is unavailable for the selected reciter.")); return
            }
            server + String.format(Locale.ROOT, "%03d", nomorSurah) + ".mp3"
        } else "https://cdn.islamic.network/quran/audio-surah/128/" + qariId + "/" + nomorSurah + ".mp3"
        mulaiAudio(url, tr("Memuat murattal surah ", "Loading surah recitation ") + nomorSurah + ", " + namaQari())
    }

    private fun posisiSurahAyatDariGlobal(global: Int): Pair<Int, Int>? {
        if (global !in 1..6236) return null
        var tersisa = global
        val surahs = daftarSurah() ?: return null
        for (i in 0 until surahs.length()) {
            val n = surahs.optJSONObject(i)?.optJSONArray("ayahs")?.length() ?: 0
            if (tersisa <= n) return (i + 1) to tersisa
            tersisa -= n
        }
        return null
    }

    private fun rentangGlobalJuz(juz: Int): IntRange? {
        val surahs = daftarSurah() ?: return null
        var global = 0
        var awal = -1
        var akhir = -1
        for (i in 0 until surahs.length()) {
            val ayahs = surahs.optJSONObject(i)?.optJSONArray("ayahs") ?: continue
            for (j in 0 until ayahs.length()) {
                global++
                val ayah = ayahs.optJSONObject(j) ?: continue
                if (ayah.optInt("juz") == juz) {
                    if (awal < 0) awal = global
                    akhir = global
                } else if (awal >= 0 && akhir >= 0) {
                    // Ayat juz tersebar berurutan dalam urutan mushaf; jangan hentikan bila metadata berpindah kembali.
                }
            }
        }
        return if (awal > 0 && akhir >= awal) awal..akhir else null
    }

    /** Mengambil rentang global ayat berdasarkan nomor halaman pada metadata mushaf. */
    private fun rentangGlobalHalaman(halaman: Int): IntRange? {
        if (halaman !in 1..604) return null
        val surahs = daftarSurah() ?: return null
        var global = 0
        var awal = -1
        var akhir = -1
        for (i in 0 until surahs.length()) {
            val ayahs = surahs.optJSONObject(i)?.optJSONArray("ayahs") ?: continue
            for (j in 0 until ayahs.length()) {
                global++
                val page = ayahs.optJSONObject(j)?.optInt("page", -1) ?: -1
                if (page == halaman) { if (awal < 0) awal = global; akhir = global }
            }
        }
        return if (awal > 0 && akhir >= awal) awal..akhir else null
    }

    private fun pilihHalamanUntukDiputar() {
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return }
        val page = getAyat(nomorSurah, nomorAyat)?.optInt("page", -1) ?: -1
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = tr("Nomor halaman 1 sampai 604", "Page number 1 to 604")
            contentDescription = hint
            setText((if (page in 1..604) page else 1).toString())
        }
        AlertDialog.Builder(this).setTitle(tr("Putar satu halaman mushaf", "Play one mushaf page"))
            .setMessage(tr("Masukkan nomor halaman. Jika dibiarkan sesuai posisi sekarang, halaman ayat aktif yang dipilih.", "Enter a page number. The current verse's page is preselected."))
            .setView(input).setPositiveButton(tr("Putar halaman", "Play page")) { _, _ ->
                val selected = input.text.toString().toIntOrNull()
                if (selected == null || selected !in 1..604) toast(tr("Nomor halaman harus 1 sampai 604.", "Page number must be from 1 to 604."))
                else putarHalaman(selected)
            }
            .setNeutralButton(tr("Pilih Qari untuk halaman", "Choose reciter for page")) { _, _ ->
                pilihQariKhususUntukHalaman()
            }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    /** Pilihan khusus qari per ayat; hanya jenis ini yang dapat diputar berurutan untuk satu halaman. */
    private fun pilihQariKhususUntukHalaman() {
        val sumber = daftarQari.toList()
        if (sumber.isEmpty()) {
            toast(tr("Daftar qari audio per ayat belum tersedia.", "Verse-by-verse reciter list is unavailable."))
            return
        }
        val labels = sumber.map { it.second + if (it.first == qariId) tr(" (dipilih)", " (selected)") else "" }
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih Qari untuk pemutaran halaman", "Choose reciter for page playback"))
            .setItems(labels.toTypedArray()) { _, which ->
                if (which in sumber.indices) {
                    hentikanAudio()
                    qariId = sumber[which].first
                    dataPrefs.edit()
                        .putString("qari_audio_id", qariId)
                        .putString("qari_audio_nama", sumber[which].second)
                        .apply()
                    val info = tr("Qari halaman dipilih: ", "Page reciter selected: ") + namaQari()
                    infoQari?.text = tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari()
                    infoQari?.announceForAccessibility(info)
                    toast(info)
                    handler.post { pilihHalamanUntukDiputar() }
                }
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    private fun putarHalaman(halaman: Int) {
        if (qariId.startsWith("mp3quran|")) { toast(tr("Qari ini hanya menyediakan audio surah penuh. Pilih qari yang mendukung audio per ayat untuk memutar halaman.", "This reciter only provides full-surah audio. Choose a verse-by-verse reciter to play a page.")); return }
        val range = rentangGlobalHalaman(halaman)
        if (range == null) { toast(tr("Data halaman tidak tersedia. Unduh ulang teks Al-Qur'an yang memuat metadata halaman.", "Page metadata is unavailable. Download Qur'an text containing page metadata.")); return }
        hentikanAudio()
        halamanAktif = halaman; audioRentangLabel = tr("Halaman ", "Page ") + halaman
        audioSedangJuz = true; audioSedangAyat = false
        audioGlobalSaatIni = range.first; audioGlobalAkhir = range.last
        val posisi = posisiSurahAyatDariGlobal(audioGlobalSaatIni) ?: return
        nomorSurah = posisi.first; nomorAyat = posisi.second
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
        tampilkanPembaca(); tombolAudioAktif = tombolAudioAyat
        mulaiAudio(urlAudioAyatAktif, tr("Memutar halaman ", "Playing page ") + halaman + " · " + nomorSurah + ":" + nomorAyat)
    }

    private fun pilihJuzUntukDiputar() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        if (qariId.startsWith("mp3quran|")) {
            toast(tr("Pemutaran juz berurutan per ayat tersedia untuk qari CDN; qari MP3Quran hanya menyediakan audio per surah.", "Juz-by-verse playback is available for CDN reciters; MP3Quran reciters provide surah audio only.")); return
        }
        val labels = (1..30).map { tr("Juz ", "Juz ") + it }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz untuk diputar", "Choose juz to play"))
            .setItems(labels) { _, which ->
                putarJuz(which + 1)
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun putarJuz(juz: Int) {
        if (juz !in 1..30) { toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); return }
        if (qariId.startsWith("mp3quran|")) { toast(tr("Qari ini menyediakan audio per surah, bukan audio juz atau ayat terpisah. Pilih qari audio per ayat untuk pemutaran juz.", "This reciter provides surah audio, not separate juz or verse audio. Choose a verse-by-verse reciter to play a juz.")); return }
        val range = rentangGlobalJuz(juz)
        if (range == null) { toast(tr("Rentang ayat juz tidak tersedia. Unduh teks lengkap terlebih dahulu.", "Juz verse range is unavailable. Download the complete text first.")); return }
        hentikanAudio()
        juzAktif = juz; audioRentangLabel = tr("Juz ", "Juz ") + juz; audioSedangJuz = true; audioSedangAyat = false
        audioGlobalSaatIni = range.first; audioGlobalAkhir = range.last
        val posisi = posisiSurahAyatDariGlobal(audioGlobalSaatIni) ?: return
        nomorSurah = posisi.first; nomorAyat = posisi.second
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
        tombolAudioAktif = tombolAudioAyat
        mulaiAudio(urlAudioAyatAktif, tr("Memutar juz ", "Playing juz ") + juz + " · " + nomorSurah + ":" + nomorAyat)
    }

    private fun dialogUnduhAudio() {
        val pilihan = arrayOf(
            tr("Unduh seluruh Al-Qur'an untuk qari ini (114 surah)", "Download the full Qur'an for this reciter (114 surahs)"),
            tr("Unduh surah penuh (1 berkas MP3)", "Download full surah (one MP3 file)"),
            tr("Unduh semua ayat pada surah ini (berkas terpisah)", "Download all verses in this surah (separate files)"),
            tr("Unduh semua ayat dalam satu juz (berkas terpisah)", "Download all verses in one juz (separate files)")
        )
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Unduh audio · ", "Download audio · ") + namaQari(), tr("Unduhan seluruh Al-Qur'an cukup besar dan memerlukan ruang penyimpanan. Pastikan Wi-Fi dan ruang kosong mencukupi.", "The full Qur'an download is large and needs storage space. Make sure Wi-Fi and free space are sufficient.")))
            .setItems(pilihan) { _, which ->
                if (which == 0) mulaiUnduhSemuaSurahQari()
                else if (which == 1) mulaiUnduhAudioSurah()
                else if (which == 2) mulaiUnduhRentangAyat("surah", nomorSurah)
                else pilihJuzUntukUnduh()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihJuzUntukUnduh() {
        val labels = (1..30).map { tr("Juz ", "Juz ") + it }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz untuk diunduh", "Choose juz to download"))
            .setItems(labels) { _, which -> mulaiUnduhRentangAyat("juz", which + 1) }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun mulaiUnduhSemuaSurahQari() {
        val available: Set<Int>? = if (qariId.startsWith("mp3quran|")) {
            qariId.split("|").getOrNull(2)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet()
        } else null
        val server = if (qariId.startsWith("mp3quran|")) qariId.split("|").getOrNull(1) else null
        val items = (1..114).filter { available == null || it in available }.map { surah ->
            val url = if (server != null) server + String.format(Locale.ROOT, "%03d", surah) + ".mp3"
                else "https://cdn.islamic.network/quran/audio-surah/128/" + qariId + "/" + surah + ".mp3"
            url to ("Qari_" + namaQari().replace(Regex("[^A-Za-z0-9_-]"), "_") + "_Surah_" + String.format(Locale.ROOT, "%03d", surah) + ".mp3")
        }
        unduhDaftarAudio(items)
    }

    private fun mulaiUnduhAudioSurah() {
        val url = if (qariId.startsWith("mp3quran|")) {
            val parts = qariId.split("|")
            val available = parts.getOrNull(2)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            if (nomorSurah !in available) { toast(tr("Surah ini tidak tersedia untuk qari pilihan.", "This surah is unavailable for the selected reciter.")); return }
            (parts.getOrNull(1) ?: return) + String.format(Locale.ROOT, "%03d", nomorSurah) + ".mp3"
        } else "https://cdn.islamic.network/quran/audio-surah/128/" + qariId + "/" + nomorSurah + ".mp3"
        val surahName = getSurah(nomorSurah)?.optString("englishName", "Surah") ?: "Surah"
        unduhDaftarAudio(listOf(url to ("Qari_" + namaQari().replace(Regex("[^A-Za-z0-9_-]"), "_") + "_Surah_" + nomorSurah + "_" + surahName.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".mp3")))
    }

    private fun mulaiUnduhRentangAyat(mode: String, nilai: Int) {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        if (qariId.startsWith("mp3quran|")) {
            toast(tr("Qari dari katalog tambahan menyediakan audio per surah, bukan per ayat. Pilih qari CDN untuk unduh per juz/ayat.", "Additional catalog reciters provide surah audio, not individual verses. Choose a CDN reciter to download by juz/verse.")); return
        }
        val items = mutableListOf<Pair<String, String>>()
        var global = 0
        val surahs = daftarSurah() ?: return
        for (i in 0 until surahs.length()) {
            val surah = surahs.optJSONObject(i) ?: continue
            val ayahs = surah.optJSONArray("ayahs") ?: continue
            for (j in 0 until ayahs.length()) {
                global++
                val a = ayahs.optJSONObject(j) ?: continue
                val selected = if (mode == "surah") i + 1 == nilai else a.optInt("juz") == nilai
                if (selected) {
                    val file = "Qari_" + namaQari().replace(Regex("[^A-Za-z0-9_-]"), "_") + "_S" + String.format(Locale.ROOT, "%03d", i + 1) + "_A" + String.format(Locale.ROOT, "%03d", j + 1) + ".mp3"
                    items.add(("https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + global + ".mp3") to file)
                }
            }
        }
        if (items.isEmpty()) { toast(tr("Tidak ada ayat yang ditemukan untuk unduhan ini.", "No verses found for this download.")); return }
        unduhDaftarAudio(items)
    }

    private fun unduhDaftarAudio(items: List<Pair<String, String>>) = pastikanIzinFolder { unduhDaftarAudioSekarang(items) }

    private fun unduhDaftarAudioSekarang(items: List<Pair<String, String>>) {
        lokasiUnduhTerakhir = ""
        val progress = android.app.ProgressDialog(this)
        progress.setTitle(tr("Mengunduh audio Al-Qur'an", "Downloading Qur'an audio"))
        progress.setMessage(tr("Menyiapkan unduhan…", "Preparing download…"))
        progress.setCancelable(false); progress.show(); dialogUnduh = progress
        Thread {
            var sukses = 0
            var gagal = 0
            try {
                for ((index, item) in items.withIndex()) {
                    runOnUiThread { progress.setMessage(tr("Mengunduh berkas ", "Downloading file ") + (index + 1) + "/" + items.size + "\n" + item.second) }
                    try { simpanAudioKePenyimpanan(item.first, item.second); sukses++ } catch (_: Exception) { gagal++ }
                }
            } finally {
                runOnUiThread {
                    try { progress.dismiss() } catch (_: Exception) { }
                    dialogUnduh = null
                    toast(tr("Unduhan selesai: ", "Download finished: ") + sukses + tr(" berhasil, ", " succeeded, ") + gagal + tr(" gagal. Folder: ", " failed. Folder: ") + lokasiUnduhTerakhir.ifBlank { "Jam Pintar Pro/Audio" })
                }
            }
        }.start()
    }

    private fun simpanAudioKePenyimpanan(url: String, namaFile: String) {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000; connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP " + code)
            lokasiUnduhTerakhir = simpanKePenyimpananPublik("Audio", namaFile, "audio/mpeg") { out -> connection.inputStream.use { input -> input.copyTo(out) } }
        } finally { connection.disconnect() }
    }

    // ====================================================================================
    // FOLDER "Jam Pintar Pro" (FIX54)
    // Unduhan audio dan teks disimpan otomatis ke folder "Jam Pintar Pro" di memori internal HP:
    //   Jam Pintar Pro/Audio  dan  Jam Pintar Pro/Teks
    // Akses langsung ke folder tingkat atas memori internal hanya diizinkan Android bila:
    //   - Android 11+ : izin "Akses semua berkas" (MANAGE_EXTERNAL_STORAGE) diberikan pengguna sekali.
    //   - Android 7-9 : izin penyimpanan (WRITE_EXTERNAL_STORAGE) diberikan.
    // Tanpa itu (atau Android 10), berkas tetap tersimpan di Download/Jam Pintar Pro agar unduhan tidak gagal.
    // ====================================================================================

    private val namaFolderAplikasi = "Jam Pintar Pro"
    private var lokasiUnduhTerakhir = ""
    private var aksiTertundaIzinFolder: (() -> Unit)? = null
    private var lewatiIzinFolder = false

    private fun aksesFolderLangsung(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> try { Environment.isExternalStorageManager() } catch (_: Exception) { false }
        Build.VERSION.SDK_INT >= 29 -> false
        else -> checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /** Pastikan izin folder sudah ditangani (diminta satu kali per sesi), lalu jalankan unduhan. */
    private fun pastikanIzinFolder(batal: (() -> Unit)? = null, lanjut: () -> Unit) {
        if (aksesFolderLangsung() || lewatiIzinFolder || Build.VERSION.SDK_INT == 29) { lanjut(); return }
        if (Build.VERSION.SDK_INT >= 30) {
            AlertDialog.Builder(this)
                .setTitle(tr("Izinkan penyimpanan di folder Jam Pintar Pro", "Allow saving to the Jam Pintar Pro folder"))
                .setMessage(tr(
                    "Agar unduhan audio dan teks tersimpan otomatis di folder Jam Pintar Pro pada memori internal HP, aplikasi memerlukan izin Akses semua berkas. Tekan Buka pengaturan, aktifkan izin untuk Jam Pintar Pro, lalu kembali ke aplikasi; unduhan akan berlanjut otomatis.\n\nJika Anda memilih Lanjut tanpa izin, berkas disimpan di folder Download/Jam Pintar Pro.",
                    "To save downloaded audio and text automatically in the Jam Pintar Pro folder in internal storage, the app needs All files access permission. Press Open settings, turn the permission on for Jam Pintar Pro, then return to the app; the download continues automatically.\n\nIf you choose Continue without permission, files are saved in Download/Jam Pintar Pro."))
                .setPositiveButton(tr("Buka pengaturan", "Open settings")) { _, _ ->
                    aksiTertundaIzinFolder = lanjut
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + packageName)))
                    } catch (_: Exception) {
                        try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                        catch (_: Exception) { aksiTertundaIzinFolder = null; lewatiIzinFolder = true; lanjut() }
                    }
                }
                .setNeutralButton(tr("Lanjut tanpa izin", "Continue without permission")) { _, _ -> lewatiIzinFolder = true; lanjut() }
                .setNegativeButton(tr("Batal", "Cancel")) { _, _ -> if (batal != null) handler.post { batal() } }
                .setOnCancelListener { if (batal != null) handler.post { batal() } }
                .show()
        } else {
            aksiTertundaIzinFolder = lanjut
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 6906)
        }
    }

    private var kembaliSetelahLayarSistem: (() -> Unit)? = null

    override fun onResume() {
        super.onResume()
        // Kembali dari layar pengaturan sistem: buka lagi dialog asal agar tidak terlempar ke menu utama.
        val kembali = kembaliSetelahLayarSistem
        if (kembali != null) { kembaliSetelahLayarSistem = null; handler.post { kembali() } }
        // Kembali dari layar izin "Akses semua berkas": lanjutkan unduhan yang tertunda (izin diberikan atau tidak).
        val aksi = aksiTertundaIzinFolder
        if (aksi != null && Build.VERSION.SDK_INT >= 30) {
            aksiTertundaIzinFolder = null
            if (!aksesFolderLangsung()) lewatiIzinFolder = true
            handler.post { aksi() }
        }
    }

    /**
     * Tulis satu berkas ke folder "Jam Pintar Pro/<subfolder>". Mengembalikan nama folder tempat berkas tersimpan.
     * Dipanggil dari thread latar belakang.
     */
    private fun simpanKePenyimpananPublik(subfolder: String, namaFile: String, mime: String, tulis: (java.io.OutputStream) -> Unit): String {
        val relatif = namaFolderAplikasi + "/" + subfolder
        if (aksesFolderLangsung()) {
            val folder = File(Environment.getExternalStorageDirectory(), relatif)
            if (!folder.exists() && !folder.mkdirs() && !folder.exists()) throw IllegalStateException("Tidak dapat membuat folder " + relatif)
            val tujuan = File(folder, namaFile)
            val sementara = File(folder, namaFile + ".tmp")
            try {
                sementara.outputStream().use { tulis(it) }
                if (tujuan.exists()) tujuan.delete()
                if (!sementara.renameTo(tujuan)) throw IllegalStateException("Tidak dapat menyimpan " + namaFile)
            } catch (e: Exception) { sementara.delete(); throw e }
            try { MediaScannerConnection.scanFile(this, arrayOf(tujuan.absolutePath), null, null) } catch (_: Exception) { }
            return relatif
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val relatifDownload = "Download/" + relatif
            try {
                contentResolver.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                    arrayOf(namaFile, relatifDownload + "/"))
            } catch (_: Exception) { }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, namaFile)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relatifDownload)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Tidak dapat membuat berkas tujuan")
            try {
                contentResolver.openOutputStream(uri)?.use { tulis(it) } ?: throw IllegalStateException("Tidak dapat membuka berkas tujuan")
                contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
            return relatifDownload
        }
        // Android 7-9 tanpa izin penyimpanan: folder khusus aplikasi.
        val dasar = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
        val folder = File(dasar, relatif)
        if (!folder.exists() && !folder.mkdirs() && !folder.exists()) throw IllegalStateException("Tidak dapat membuat folder")
        File(folder, namaFile).outputStream().use { tulis(it) }
        return folder.absolutePath
    }

    private fun teksPengulanganAyat(): String = when (pengulanganAyat) {
        0 -> tr("Ayat diulang terus sampai audio dihentikan.", "Repeat verse continuously until audio is stopped.")
        1 -> tr("Setiap ayat diputar satu kali.", "Each verse plays once.")
        else -> tr("Setiap ayat diputar ", "Each verse plays ") + pengulanganAyat + tr(" kali.", " times.")
    }

    private fun pengaturanPengulanganAyat() {
        // Beri pilihan jumlah yang berurutan agar pengguna dapat mengatur 1, 2, 3, ... 10 kali.
        // Nilai 0 berarti pengulangan terus-menerus sampai dihentikan pengguna.
        val values = (1..10).toList() + 0
        val labels = (1..10).map { n ->
            if (BahasaAplikasi.tampilan(this) == 1) {
                when (n) { 1 -> "1 time"; else -> ("" + (n) + " times") }
            } else {
                ("" + (n) + " kali")
            }
        }.toMutableList().apply { add(tr("Terus-menerus", "Continuous")) }.toTypedArray()
        val selected = values.indexOf(pengulanganAyat).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(tr("Pengulangan murattal ayat", "Verse recitation repeat"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in values.indices) {
                    pengulanganAyat = values[which]
                    dataPrefs.edit().putInt("pengulangan_audio_ayat", pengulanganAyat).apply()
                    toast(teksPengulanganAyat())
                    dialog.dismiss()
                    perbaruiStatusAudio(tr("Pengulangan audio diatur: ", "Audio repeat set: ") + labels[which])
                    handler.post { dialogPengaturanHafalan() }
                }
            }.kembaliKe(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { dialogPengaturanHafalan() }.show()
    }

    private fun pengaturanKecepatanAudio() {
        val values = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)
        val labels = if (BahasaAplikasi.tampilan(this) == 1) arrayOf("0.75x", "1.0x", "1.25x", "1.5x") else arrayOf("0,75x", "1,0x", "1,25x", "1,5x")
        val selected = values.indices.firstOrNull { kotlin.math.abs(values[it] - kecepatanAudio) < 0.001f } ?: 1
        AlertDialog.Builder(this).setTitle(tr("Kecepatan murattal", "Recitation speed"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in values.indices) {
                    kecepatanAudio = values[which]
                    dataPrefs.edit().putFloat("kecepatan_audio", kecepatanAudio).apply()
                    if (Build.VERSION.SDK_INT >= 23) {
                        try { pemutar?.let { player -> player.playbackParams = player.playbackParams.setSpeed(kecepatanAudio) } } catch (_: Exception) { }
                    }
                    toast(tr("Kecepatan murattal diubah menjadi ", "Recitation speed changed to ") + labels[which])
                    dialog.dismiss()
                    perbaruiStatusAudio(tr("Kecepatan audio diatur ke ", "Audio speed set to ") + labels[which])
                    handler.post { dialogPengaturanAudio() }
                }
            }.kembaliKe(tr("Kembali ke pengaturan audio", "Back to audio settings")) { dialogPengaturanAudio() }.show()
    }

    /**
     * Coba bitrate pada host CDN yang sama. Jangan mengganti host ke domain
     * alternatif yang belum terverifikasi memiliki struktur endpoint yang sama.
     */
    private fun urlAudioPercobaan(url: String, percobaan: Int): String {
        if (qariId.startsWith("mp3quran|")) return url
        val bitrate = listOf("128", "64", "48", "40", "32", "192").getOrElse(percobaan) { "128" }
        return url.replace(Regex("/audio/\\d+/"), "/audio/" + bitrate + "/")
            .replace(Regex("/audio-surah/\\d+/"), "/audio-surah/" + bitrate + "/")
    }

    private fun mulaiAudio(url: String, pesanMemuat: String, percobaan: Int = 0, generasi: Int = ++audioGenerasi, otomatis: Boolean = false) {
        val urlPercobaan = urlAudioPercobaan(url, percobaan)
        try {
            val lama = pemutar
            pemutar = null
            audioSiap = false
            try { lama?.setOnPreparedListener(null) } catch (_: Exception) { }
            try { lama?.setOnCompletionListener(null) } catch (_: Exception) { }
            try { lama?.setOnErrorListener(null) } catch (_: Exception) { }
            try { lama?.release() } catch (_: Exception) { }

            val p: PemutarAudio = if (keluaranMono) PemutarMono() else PemutarStereo()
            pemutar = p
            // Sesi audio bersama harus dipasang sebelum prepare agar Equalizer menjangkau audio ini.
            if (pastikanEfekAudio()) {
                try { p.setAudioSessionId(sesiAudioEfek) } catch (_: Exception) { }
                terapkanEqualizer()
            }
            // Hindari status "Menghubungkan audio…" yang menggantung bila jaringan tidak
            // pernah mengembalikan callback prepared/error.
            val timeoutAudio = Runnable {
                if (generasi == audioGenerasi && pemutar === p && !audioSiap) {
                    pemutar = null
                    try { p.setOnPreparedListener(null) } catch (_: Exception) { }
                    try { p.setOnCompletionListener(null) } catch (_: Exception) { }
                    try { p.setOnErrorListener(null) } catch (_: Exception) { }
                    try { p.release() } catch (_: Exception) { }
                    if (percobaan < (if (qariId.startsWith("mp3quran|")) 0 else 5)) {
                        tombolStatusAudio?.text = tr("Sumber audio belum merespons. Mencoba sumber/bitrate alternatif…", "Audio source did not respond. Trying an alternate source/bitrate…")
                        mulaiAudio(url, pesanMemuat, percobaan + 1, generasi, otomatis)
                    } else {
                        tombolStatusAudio?.text = tr("Audio tidak berhasil dimuat dari beberapa sumber. Periksa apakah jaringan mengizinkan akses ke server audio, lalu coba lagi.", "Audio could not load from multiple sources. Check whether your network allows access to the audio servers, then try again.")
                        tombolAudioAktif?.text = tr("Coba putar murattal lagi", "Try playing the murattal again")
                        diagnosaAudio(urlPercobaan, generasi)
                    }
                }
            }
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setOnPreparedListener { siap ->
                handler.removeCallbacks(timeoutAudio)
                if (generasi != audioGenerasi || pemutar !== siap) { try { siap.release() } catch (_: Exception) { }; return@setOnPreparedListener }
                audioSiap = true
                if (Build.VERSION.SDK_INT >= 23) {
                    try { siap.playbackParams = siap.playbackParams.setSpeed(kecepatanAudio) } catch (_: Exception) { }
                }
                // Cadangan: bila perangkat tidak menerima sesi audio bersama, pakai sesi milik pemutar ini.
                if (equalizerAudio != null && siap.audioSessionId != sesiAudioEfek && siap.audioSessionId > 0) {
                    lepasEfekAudio()
                    sesiAudioEfek = siap.audioSessionId
                }
                val eqAktif = terapkanEqualizer()
                if (!eqAktif && presetEqualizer != "normal") {
                    umumkanAudio(tombolStatusAudio, tr("Equalizer belum aktif. ", "Equalizer is not active. ") + statusEqualizer, otomatis)
                }
                siap.start()
                perbaruiTombolJedaAudio(false)
                tombolAudioAktif?.text = tr("Murattal sedang diputar", "Murattal is playing")
                tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
                tombolStatusAudio?.text = tr("Sedang memutar audio. Qari: ", "Playing audio. Reciter: ") + namaQari() + ". " + namaModeHafalan()
                umumkanAudio(tombolStatusAudio, tombolStatusAudio?.text, otomatis)
            }
            p.setOnCompletionListener { selesai ->
                if (generasi != audioGenerasi || pemutar !== selesai) return@setOnCompletionListener
                audioSiap = false
                if (audioSedangJuz) {
                    if (audioGlobalSaatIni < audioGlobalAkhir) {
                        audioGlobalSaatIni++
                        val posisi = posisiSurahAyatDariGlobal(audioGlobalSaatIni) ?: run { audioSedangJuz = false; return@setOnCompletionListener }
                        nomorSurah = posisi.first; nomorAyat = posisi.second
                        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
                        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
                        tombolStatusAudio?.text = (if (audioRentangLabel.isNotBlank()) tr("Melanjutkan ", "Continuing ") + audioRentangLabel else tr("Memutar juz ", "Playing juz ") + juzAktif) + " · " + nomorSurah + ":" + nomorAyat
                        redamTalkBackSaatPergantian()
                        mulaiAudio(urlAudioAyatAktif, tombolStatusAudio?.text?.toString() ?: "", otomatis = true)
                    } else {
                        audioSedangJuz = false
                        tombolStatusAudio?.text = (if (audioRentangLabel.isNotBlank()) audioRentangLabel else tr("Juz", "Juz")) + tr(" selesai diputar.", " playback completed.")
                        audioRentangLabel = ""
                        tombolAudioAktif?.text = tr("Juz selesai", "Juz completed")
                    }
                    return@setOnCompletionListener
                }
                if (audioSedangAyat && modeHafalan != "biasa" && (pengulanganAyat == 0 || sisaPengulanganAyat > 1)) {
                    if (sisaPengulanganAyat > 1) sisaPengulanganAyat--
                    tombolStatusAudio?.text = tr("Mengulang ayat ", "Repeating verse ") + nomorSurah + ":" + nomorAyat + tr(" · sisa pengulangan ", " · repeats remaining ") + if (sisaPengulanganAyat == 0) tr("tanpa batas", "unlimited") else sisaPengulanganAyat
                    redamTalkBackSaatPergantian()
                    handler.postDelayed({
                        if (generasi == audioGenerasi && audioSedangAyat) mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif, otomatis = true)
                    }, 250L)
                    return@setOnCompletionListener
                }
                if (audioSedangAyat && modeHafalan == "berurutan") {
                    val globalBerikut = nomorAyatGlobal() + 1
                    val posisiBerikut = posisiSurahAyatDariGlobal(globalBerikut)
                    if (posisiBerikut != null) {
                        nomorSurah = posisiBerikut.first
                        nomorAyat = posisiBerikut.second
                        sisaPengulanganAyat = pengulanganAyat
                        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + globalBerikut + ".mp3"
                        pesanAudioAyatAktif = tr("Mode hafalan · ayat ", "Memorization mode · verse ") + nomorSurah + ":" + nomorAyat
                        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
                        tombolStatusAudio?.text = tr("Jeda hafalan, ayat berikutnya ", "Memorization pause, next verse ") + nomorSurah + ":" + nomorAyat
                        redamTalkBackSaatPergantian()
                        umumkanAudio(tombolStatusAudio, tombolStatusAudio?.text, true)
                        handler.postDelayed({
                            if (generasi == audioGenerasi && audioSedangAyat && modeHafalan == "berurutan") mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif, otomatis = true)
                        }, jedaAntarAyatDetik * 1000L)
                        return@setOnCompletionListener
                    }
                    audioSedangAyat = false
                    tombolStatusAudio?.text = tr("Hafalan berurutan selesai sampai akhir Al-Qur'an.", "Sequential memorization reached the end of the Qur'an.")
                }
                if (modePemutaranAudio == "arab_terjemahan") {
                    redamTalkBackSaatPergantian()
                    putarTerjemahanAyat(true)
                    return@setOnCompletionListener
                }
                tombolAudioAktif?.text = tr("Murattal selesai; tekan untuk memutar lagi", "Recitation finished; press to replay")
                tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
                tombolStatusAudio?.text = tr("Pemutaran audio selesai.", "Audio playback completed.")
            }
            p.setOnErrorListener { gagal, _, _ ->
                handler.removeCallbacks(timeoutAudio)
                if (generasi != audioGenerasi || pemutar !== gagal) return@setOnErrorListener true
                try { gagal.reset() } catch (_: Exception) { }
                try { gagal.release() } catch (_: Exception) { }
                pemutar = null
                audioSiap = false
                if (percobaan < (if (qariId.startsWith("mp3quran|")) 0 else 5)) {
                    tombolStatusAudio?.text = tr("Sumber audio gagal. Mencoba sumber/bitrate alternatif…", "Audio source failed. Trying an alternate source/bitrate…")
                    mulaiAudio(url, pesanMemuat, percobaan + 1, generasi, otomatis)
                } else {
                    tombolStatusAudio?.text = tr("Audio gagal diputar setelah mencoba beberapa sumber. Masalah dapat berasal dari server, qari, atau akses jaringan ke CDN; Wi-Fi tersambung saja belum memastikan server audio dapat dijangkau.", "Audio failed after trying multiple sources. The issue may be the server, reciter, or network access to the CDN; a connected Wi-Fi does not guarantee the audio server is reachable.")
                    toast(tr("Audio gagal dari beberapa sumber. Coba qari lain atau coba lagi nanti.", "Audio failed from multiple sources. Try another reciter or try again later."))
                    tombolAudioAktif?.text = tr("Coba putar murattal lagi", "Try playing the murattal again")
                    diagnosaAudio(urlPercobaan, generasi)
                }
                true
            }
            // Berikan header HTTP yang lazim untuk pemutar media Android. Beberapa CDN
            // dapat merespons berbeda terhadap permintaan tanpa User-Agent eksplisit.
            val headerAudio = mapOf(
                "User-Agent" to ("Mozilla/5.0 (Linux; Android " + (Build.VERSION.RELEASE) + ") AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"),
                "Accept" to "audio/mpeg,audio/*;q=0.9,*/*;q=0.8"
            )
            p.setDataSource(this, Uri.parse(urlPercobaan), headerAudio)
            tombolAudioAktif?.text = tr("Menghubungkan audio…", "Connecting to audio…")
            tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
            tombolStatusAudio?.text = pesanMemuat
            p.prepareAsync()
            handler.postDelayed(timeoutAudio, 30000L)
        } catch (_: Exception) {
            val gagal = pemutar
            pemutar = null
            audioSiap = false
            try { gagal?.setOnPreparedListener(null) } catch (_: Exception) { }
            try { gagal?.setOnCompletionListener(null) } catch (_: Exception) { }
            try { gagal?.setOnErrorListener(null) } catch (_: Exception) { }
            try { gagal?.release() } catch (_: Exception) { }
            if (percobaan < (if (qariId.startsWith("mp3quran|")) 0 else 5)) {
                mulaiAudio(url, pesanMemuat, percobaan + 1, generasi, otomatis)
            } else {
                tombolStatusAudio?.text = tr("Audio tidak dapat dimuat setelah mencoba beberapa sumber. Coba qari lain atau coba lagi nanti.", "Audio could not load after trying multiple sources. Try another reciter or try again later.")
                toast(tr("Audio tidak dapat dimuat dari beberapa sumber.", "Audio could not load from multiple sources."))
                tombolAudioAktif?.text = tr("Coba putar murattal lagi", "Try playing the murattal again")
                diagnosaAudio(urlPercobaan, generasi)
            }
        }
    }

    /**
     * Saat semua percobaan gagal, periksa server di latar belakang dan tambahkan penyebab yang jelas
     * pada status audio (berkas tidak ada, server tidak terjangkau, DNS, sambungan aman, atau batas waktu).
     */
    private fun diagnosaAudio(url: String, generasiAsal: Int) {
        Thread {
            val hasil: String = try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "GET"
                c.setRequestProperty("Range", "bytes=0-0")
                c.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val kode = c.responseCode
                c.disconnect()
                when {
                    kode in 200..299 -> tr("Diagnosis: server audio dapat dijangkau (HTTP " + kode + "), tetapi pemutar perangkat tidak dapat membuka berkas ini. Coba qari lain.", "Diagnosis: the audio server is reachable (HTTP " + kode + "), but the device player cannot open this file. Try another reciter.")
                    kode == 404 -> tr("Diagnosis: berkas audio tidak ada di server (HTTP 404) untuk qari atau surah ini. Pilih qari lain.", "Diagnosis: the audio file does not exist on the server (HTTP 404) for this reciter or surah. Choose another reciter.")
                    else -> tr("Diagnosis: server menjawab HTTP " + kode + ".", "Diagnosis: the server answered HTTP " + kode + ".")
                }
            } catch (e: java.net.UnknownHostException) {
                tr("Diagnosis: nama server audio tidak dapat ditemukan. Periksa internet, DNS pribadi, atau VPN.", "Diagnosis: the audio server name could not be resolved. Check the internet connection, private DNS, or VPN.")
            } catch (e: java.net.SocketTimeoutException) {
                tr("Diagnosis: koneksi ke server audio melewati batas waktu. Jaringan mungkin lambat atau memblokir server ini.", "Diagnosis: the connection to the audio server timed out. The network may be slow or blocking this server.")
            } catch (e: javax.net.ssl.SSLException) {
                tr("Diagnosis: sambungan aman (HTTPS) gagal. Periksa tanggal dan jam perangkat.", "Diagnosis: the secure (HTTPS) connection failed. Check the device date and time.")
            } catch (e: Exception) {
                tr("Diagnosis: server audio tidak dapat dijangkau (", "Diagnosis: the audio server could not be reached (") + (e.javaClass.simpleName) + ")."
            }
            runOnUiThread {
                if (generasiAsal == audioGenerasi) {
                    val lama = tombolStatusAudio?.text?.toString().orEmpty()
                    tombolStatusAudio?.text = lama + " " + hasil
                    tombolStatusAudio?.contentDescription = tombolStatusAudio?.text
                }
            }
        }.start()
    }

    // Suara TalkBack saat pergantian audio otomatis (FIX52). Bawaan: tetap aktif (false).
    private var senyapTalkBackPergantian = false

    /** Umumkan lewat TalkBack; pengumuman pergantian audio otomatis dilewati bila pengguna memilih mematikannya. */
    private fun umumkanAudio(tampilan: android.view.View?, pesan: CharSequence?, pergantian: Boolean = false) {
        if (pesan.isNullOrBlank()) return
        if (pergantian && senyapTalkBackPergantian) return
        tampilan?.announceForAccessibility(pesan)
    }

    /** Dipanggil saat audio berpindah otomatis: hentikan ucapan TalkBack yang sedang berjalan agar tidak menimpa audio berikutnya. */
    private fun redamTalkBackSaatPergantian() {
        if (!senyapTalkBackPergantian) return
        try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
    }

    private fun perbaruiStatusAudio(pesan: String, pergantian: Boolean = false) {
        tombolStatusAudio?.text = pesan
        tombolStatusAudio?.contentDescription = pesan
        umumkanAudio(tombolStatusAudio, pesan, pergantian)
    }


    private fun perbaruiTombolJedaAudio(dijeda: Boolean? = null) {
        if (modePemutaranAudio == "terjemahan" && ttsTerjemahan?.isSpeaking == true) {
            tombolJedaAudio?.text = tr("⏹ Hentikan", "⏹ Stop")
            tombolJedaAudio?.contentDescription = tr("Hentikan audio terjemahan yang sedang dibacakan", "Stop the translation currently being spoken")
            return
        }
        val p = pemutar
        val siap = audioSiap && p != null
        val sedangJalan = dijeda?.let { !it } ?: (p?.isPlaying == true)
        val label = when {
            !siap -> tr("⏸ JEDA / LANJUTKAN AUDIO", "⏸ PAUSE / RESUME AUDIO")
            sedangJalan -> tr("⏸ JEDA AUDIO SEKARANG", "⏸ PAUSE AUDIO NOW")
            else -> tr("▶ LANJUTKAN AUDIO", "▶ RESUME AUDIO")
        }
        tombolJedaAudio?.text = if (!siap) tr("▶ Putar", "▶ Play") else if (sedangJalan) tr("⏸ Jeda", "⏸ Pause") else tr("▶ Lanjutkan", "▶ Resume")
        tombolJedaAudio?.contentDescription = when {
            !siap -> tr("Tombol jeda audio. Mulai pemutaran terlebih dahulu, kemudian gunakan tombol ini untuk menjeda atau melanjutkan.", "Audio pause button. Start playback first, then use this button to pause or resume.")
            sedangJalan -> tr("Jeda audio yang sedang diputar", "Pause the audio currently playing")
            else -> tr("Lanjutkan audio yang dijeda", "Resume paused audio")
        }
    }

    private fun jedaLanjutAudio() {
        if (modePemutaranAudio == "terjemahan" && ttsTerjemahan?.isSpeaking == true) {
            try { ttsTerjemahan?.stop() } catch (_: Exception) { }
            perbaruiStatusAudio(tr("Audio terjemahan dihentikan.", "Translation audio stopped."))
            perbaruiTombolJedaAudio(true)
            return
        }
        val p = pemutar
        if (p == null || !audioSiap) {
            mulaiSesuaiPengaturan()
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
                perbaruiTombolJedaAudio(true)
                tombolJedaAudio?.announceForAccessibility(tombolJedaAudio?.contentDescription)
                perbaruiStatusAudio(tr("Murattal dijeda. Fokuskan tombol Lanjutkan Audio untuk meneruskan.", "Recitation paused. Focus the Resume Audio button to continue."))
                toast(tr("Murattal dijeda.", "Murattal paused."))
            } else {
                p.start()
                perbaruiTombolJedaAudio(false)
                tombolJedaAudio?.announceForAccessibility(tombolJedaAudio?.contentDescription)
                perbaruiStatusAudio(tr("Murattal dilanjutkan.", "Recitation resumed."))
                toast(tr("Murattal dilanjutkan.", "Murattal resumed."))
            }
        } catch (_: Exception) {
            toast(tr("Audio tidak dapat dilanjutkan. Tekan tombol murattal untuk memutar ulang.", "Audio could not resume. Press the murattal button to replay."))
        }
    }

    private fun hentikanAudio() {
        audioGenerasi++
        audioSedangAyat = false
        audioSedangJuz = false
        sisaPengulanganAyat = 1
        handler.removeCallbacksAndMessages(null)
        val p = pemutar
        pemutar = null
        audioSiap = false
        try { p?.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p?.setOnCompletionListener(null) } catch (_: Exception) { }
        try { if (p?.isPlaying == true) p.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
        try { ttsTerjemahan?.stop() } catch (_: Exception) { }
        tombolAudio?.text = tr("Putar murattal seluruh surah", "Play the whole surah recitation")
        tombolAudio?.contentDescription = tombolAudio?.text
        tombolAudioAyat?.text = tr("Putar murattal ayat ini", "Play this verse's recitation")
        tombolAudioAyat?.contentDescription = tombolAudioAyat?.text
        tombolAudioAktif = null
        perbaruiTombolJedaAudio(true)
        tombolStatusAudio?.text = tr("Audio dihentikan.", "Audio stopped.")
    }

    private fun keyAyat() = ("" + (nomorSurah) + ":" + (nomorAyat))
    private fun tandaiPosisi() {
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val today = tanggalHariIni()
        dataPrefs.edit().putString("posisi_terakhir", ("" + (nomorSurah) + ":" + (nomorAyat) + "|" + (today))).apply()
        toast(tr("Posisi bacaan disimpan.", "Reading position saved."))
    }

    private fun ayatSudahSelesai(): Boolean =
        dataPrefs.getStringSet("ayat_selesai", emptySet())?.contains(keyAyat()) == true

    private fun perbaruiLabelTandaAyat() {
        tombolTandaiAyat?.text = if (ayatSudahSelesai())
            tr("Batalkan tanda selesai untuk ayat ini", "Unmark this verse as completed")
        else tr("Tandai ayat selesai dibaca", "Mark verse as read")
        tombolTandaiAyat?.contentDescription = tombolTandaiAyat?.text
    }

    private fun tandaiAyatSelesai() {
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.toMutableSet() ?: mutableSetOf()
        val key = keyAyat()
        val added = completed.add(key)
        dataPrefs.edit().putStringSet("ayat_selesai", completed).putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val dayKey = ("selesai_" + tanggalHariIni())
        val daily = dataPrefs.getStringSet(dayKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        daily.add(key)
        dataPrefs.edit().putStringSet(dayKey, daily).apply()
        perbaruiLabelTandaAyat()
        toast(if (added) tr("Ayat ditandai selesai. Kemajuan diperbarui.", "Verse marked as read. Progress updated.") else tr("Ayat ini sudah tercatat sebagai selesai.", "This verse is already marked as read."))
    }

    private fun batalkanTandaAyatSelesai() {
        val key = keyAyat()
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.toMutableSet() ?: mutableSetOf()
        completed.remove(key)
        val editor = dataPrefs.edit().putStringSet("ayat_selesai", completed)
        // Hapus ayat ini dari catatan harian juga agar statistik dan riwayat tetap konsisten.
        dataPrefs.all.keys.filter { it.startsWith("selesai_") }.forEach { dayKey ->
            val daily = dataPrefs.getStringSet(dayKey, emptySet())?.toMutableSet() ?: mutableSetOf()
            if (daily.remove(key)) editor.putStringSet(dayKey, daily)
        }
        editor.apply()
        perbaruiLabelTandaAyat()
        toast(tr("Tanda selesai dibatalkan. Statistik diperbarui.", "Completion mark removed. Statistics updated."))
    }

    private fun ringkasanKemajuan(): String {
        val completed = (dataPrefs.getStringSet("ayat_selesai", emptySet())?.size ?: 0).coerceIn(0, jumlahAyatTotal())
        val today = dataPrefs.getStringSet("selesai_" + tanggalHariIni(), emptySet())?.size ?: 0
        val percent = completed * 100.0 / jumlahAyatTotal()
        val goal = dataPrefs.getInt("target_hari", 0)
        return buildString {
            append(tr("Kemajuan saat ini: ", "Current progress: "))
            append(completed).append(" / ").append(jumlahAyatTotal()).append(" ").append(tr("ayat", "verses"))
            append(" ( ").append(String.format(Locale.ROOT, "%.2f", percent)).append("% ).\n")
            append(tr("Ayat ditandai hari ini: ", "Verses marked today: ")).append(today).append(".\n")
            append(tr("Sisa ayat yang belum ditandai: ", "Verses remaining to mark: ")).append(jumlahAyatTotal() - completed).append(".\n")
            append(tr("Target: ", "Goal: ")).append(if (goal == 0) tr("belum ditentukan", "not set") else ("" + (goal) + " ") + tr("hari", "days"))
        }
    }

    private fun pengaturanTarget() {
        val options = arrayOf(tr("30 hari", "30 days"), tr("60 hari", "60 days"), tr("90 hari", "90 days"), tr("Tentukan jumlah hari sendiri", "Choose a custom number of days"), tr("Tanpa target", "No target"))
        AlertDialog.Builder(this).setTitle(tr("Pilih target khatam", "Choose a Khatam goal")).setItems(options) { _, which ->
            when (which) {
                0,1,2 -> { simpanTarget(listOf(30,60,90)[which]); handler.post { dialogPengaturanKhatam() } }
                3 -> {
                    val input = android.widget.EditText(this); input.inputType = android.text.InputType.TYPE_CLASS_NUMBER; input.hint = tr("Jumlah hari (1–3650)", "Number of days (1–3650)")
                    AlertDialog.Builder(this).setTitle(tr("Target khusus", "Custom goal")).setView(input)
                        .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                            val days = input.text.toString().toIntOrNull()
                            if (days != null && days in 1..3650) { simpanTarget(days); handler.post { dialogPengaturanKhatam() } }
                            else { toast(tr("Masukkan angka 1 sampai 3650.", "Enter a number from 1 to 3650.")); handler.post { pengaturanTarget() } }
                        }
                        .kembaliKe(tr("Kembali ke pilihan target", "Back to goal options")) { pengaturanTarget() }
                        .show()
                }
                else -> { dataPrefs.edit().putInt("target_hari", 0).remove("target_mulai").apply(); toast(tr("Target khatam dinonaktifkan. Kemajuan tetap disimpan.", "Khatam goal disabled. Progress will still be saved.")); handler.post { dialogPengaturanKhatam() } }
            }
        }.kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }.show()
    }

    private fun simpanTarget(days: Int) {
        dataPrefs.edit().putInt("target_hari", days).putLong("target_mulai", System.currentTimeMillis()).apply()
        toast(tr("Target disimpan: ", "Goal saved: ") + ("" + (days) + " ") + tr("hari. Baca sesuai kemampuan; target dapat diubah kapan saja.", "days. Read at your own pace; you can change the goal anytime."))
    }

    private fun jumlahAyatTotal(): Int = 6236
    private fun urutanGlobal(s: Int, a: Int): Int {
        val surahs = daftarSurah() ?: return 0
        var count = 0
        for (i in 0 until (s - 1).coerceIn(0, surahs.length())) count += surahs.optJSONObject(i)?.optInt("numberOfAyahs", 0) ?: 0
        return count + a
    }

    private fun tampilkanStatistik() {
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.size ?: 0
        val goal = dataPrefs.getInt("target_hari", 0)
        val remaining = (jumlahAyatTotal() - completed).coerceAtLeast(0)
        val start = dataPrefs.getLong("target_mulai", 0L)
        val elapsed = if (start > 0L) (((System.currentTimeMillis() - start).coerceAtLeast(0L)) / 86400000L).toInt() else 0
        val daysLeft = if (goal > 0) (goal - elapsed).coerceAtLeast(1) else 0
        val perDay = if (goal > 0) kotlin.math.ceil(remaining.toDouble() / daysLeft).toInt() else 0
        val today = dataPrefs.getStringSet(("selesai_" + tanggalHariIni()), emptySet())?.size ?: 0
        val pct = completed.coerceIn(0, jumlahAyatTotal()) * 100.0 / jumlahAyatTotal()
        val msg = buildString {
            append(tr("Ayat yang ditandai selesai: ", "Verses marked as read: ")).append(completed).append(" / 6236\n")
            append(tr("Kemajuan: ", "Progress: ")).append(String.format(Locale.ROOT, "%.2f", pct)).append("%\n")
            append(tr("Sisa ayat yang belum ditandai: ", "Verses remaining to mark: ")).append(remaining).append("\n")
            append(tr("Ayat ditandai hari ini: ", "Verses marked today: ")).append(today).append("\n")
            append(tr("Target: ", "Goal: ")).append(if (goal == 0) tr("tanpa target", "no goal") else ("" + (goal) + " ") + tr("hari", "days"))
            if (goal > 0) {
                append("\n").append(tr("Hari target yang telah berlalu: ", "Goal days elapsed: ")).append(elapsed.coerceAtMost(goal)).append(" / ").append(goal)
                append("\n").append(tr("Perkiraan ayat tersisa per hari agar sesuai target: ", "Approximate remaining verses per day to meet the goal: ")).append(perDay)
            }
            if (remaining == 0) append("\n\n").append(tr("Alhamdulillah, semua 6.236 ayat sudah ditandai selesai. Semoga Allah menerima amal ibadah kita.", "Praise be to Allah, all 6,236 verses have been marked complete. May Allah accept our worship."))
            append("\n\n").append(tr("Kemajuan dihitung dari ayat yang Anda tandai selesai, bukan dari audio yang hanya diputar. Tidak ada teguran jika target harian terlewat.", "Progress counts verses you mark as read, not audio that was merely played. There is no penalty for missing a daily target."))
        }
        AlertDialog.Builder(this).setTitle(tr("Kemajuan dan statistik", "Progress and statistics"))
            .setMessage(msg)
            .setPositiveButton(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { _, _ -> handler.post { dialogPengaturanKhatam() } }
            .setOnCancelListener { handler.post { dialogPengaturanKhatam() } }
            .show()
    }

    private fun tampilkanRiwayat() {
        val all = dataPrefs.all
        val rows = all.keys.filter { it.startsWith("selesai_") }.sortedDescending().take(30).map { key ->
            val day = key.removePrefix("selesai_")
            val count = (all[key] as? Set<*>)?.size ?: 0
            ("" + (day) + " — " + (count) + " ") + tr("ayat", "verses")
        }
        val posisi = dataPrefs.getString("posisi_terakhir", "") ?: ""
        val posisiText = if (posisi.isNotBlank()) {
            val bagianPosisi = posisi.split("|")
            val ref = bagianPosisi.firstOrNull().orEmpty()
            val tanggal = bagianPosisi.getOrNull(1).orEmpty()
            tr("Posisi terakhir: ", "Last position: ") + ref + if (tanggal.isNotBlank()) (" (" + (tanggal) + ")") else ""
        } else tr("Posisi terakhir belum disimpan secara terpisah.", "The last position has not been saved separately.")
        val aktivitas = if (rows.isEmpty()) tr("Belum ada riwayat ayat yang ditandai selesai.", "There is no history of verses marked as read yet.") else rows.joinToString("\n")
        val message = posisiText + "\n\n" + tr("Aktivitas harian (hingga 30 hari dengan data):", "Daily activity (up to 30 days with data):") + "\n" + aktivitas
        AlertDialog.Builder(this).setTitle(tr("Riwayat bacaan", "Reading history"))
            .setMessage(message)
            .setPositiveButton(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { _, _ -> handler.post { dialogPengaturanKhatam() } }
            .setOnCancelListener { handler.post { dialogPengaturanKhatam() } }
            .show()
    }

    private fun pengaturanPengingat() {
        val enabled = dataPrefs.getBoolean("pengingat_aktif", false)
        val hour = dataPrefs.getInt("pengingat_jam", 20)
        val minute = dataPrefs.getInt("pengingat_menit", 0)
        val dialog = AlertDialog.Builder(this)
            .setTitle(tr("Pengingat membaca dan hafalan", "Reading and memorization reminder"))
            .setMessage(tr("Status saat ini: ", "Current status: ") + if (enabled) String.format(Locale.ROOT, "%02d:%02d", hour, minute) else tr("nonaktif", "off"))
            .setPositiveButton(tr("Atur waktu", "Set time"), null)
            .setNegativeButton(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { _, _ ->
                handler.post { dialogPengaturanKhatam() }
            }
            .setNeutralButton(if (enabled) tr("Matikan pengingat", "Turn off reminder") else tr("Biarkan nonaktif", "Keep disabled"), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                dialog.dismiss()
                TimePickerDialog(this, { _, h, m ->
                    dataPrefs.edit().putBoolean("pengingat_aktif", true).putInt("pengingat_jam", h).putInt("pengingat_menit", m).apply()
                    jadwalkanPengingat(h, m)
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 6904)
                    } else {
                        toast(tr("Pengingat harian disetel.", "Daily reminder has been set."))
                    }
                    handler.post { dialogPengaturanKhatam() }
                }, hour, minute, true).apply {
                    setOnCancelListener { handler.post { pengaturanPengingat() } }
                }.show()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                if (enabled) {
                    dataPrefs.edit().putBoolean("pengingat_aktif", false).apply()
                    batalkanPengingat()
                    toast(tr("Pengingat dimatikan.", "Reminder turned off."))
                }
                dialog.dismiss()
                handler.post { dialogPengaturanKhatam() }
            }
        }
        dialog.setOnCancelListener { handler.post { dialogPengaturanKhatam() } }
        dialog.show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 6905) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                mulaiPengenalanBacaanAyat()
            } else {
                val pesan = tr("Izin mikrofon ditolak. Koreksi otomatis tidak dapat berjalan tanpa izin mikrofon. Latihan mandiri tetap dapat digunakan.", "Microphone permission denied. Automatic checking cannot run without microphone permission. Self-check practice remains available.")
                statusKoreksiHafalan?.text = pesan
                statusKoreksiHafalan?.announceForAccessibility(pesan)
            }
        }
        if (requestCode == 6906) {
            val aksi = aksiTertundaIzinFolder
            aksiTertundaIzinFolder = null
            if (grantResults.isEmpty() || grantResults[0] != android.content.pm.PackageManager.PERMISSION_GRANTED) lewatiIzinFolder = true
            if (aksi != null) handler.post { aksi() }
        }
        if (requestCode == 6904) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast(tr("Pengingat harian disetel dan notifikasi diizinkan.", "Daily reminder is set and notifications are allowed."))
            } else {
                toast(tr("Jadwal pengingat tersimpan, tetapi notifikasi diblokir. Izinkan notifikasi Jam Pintar Pro di Pengaturan Android.", "The reminder is scheduled, but notifications are blocked. Allow Jam Pintar Pro notifications in Android Settings."))
            }
        }
    }

    private fun jadwalkanPengingat(hour: Int, minute: Int) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, KhatamReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 6901, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        } else {
            @Suppress("DEPRECATION")
            alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }

    private fun batalkanPengingat() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(this, 6901, Intent(this, KhatamReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.cancel(pi); pi.cancel()
    }

    private fun pengaturanAksesibilitas() {
        val options = arrayOf(
            tr("Tampilkan terjemahan: ", "Show translation: ") + if (tampilkanArti) tr("aktif", "on") else tr("nonaktif", "off"),
            tr("Perbesar teks Arab", "Increase Arabic text size"),
            tr("Perkecil teks Arab", "Decrease Arabic text size"),
            tr("Unduh ulang teks untuk bahasa aktif", "Download text for the active language"),
            tr("Suara TalkBack saat pergantian audio: ", "TalkBack speech when audio changes: ") + if (senyapTalkBackPergantian) tr("dimatikan", "muted") else tr("tetap aktif", "kept on")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan aksesibilitas", "Accessibility settings"))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { tampilkanArti = !tampilkanArti; dataPrefs.edit().putBoolean("tampilkan_terjemahan", tampilkanArti).apply(); toast(if (tampilkanArti) tr("Terjemahan diaktifkan.", "Translation enabled.") else tr("Terjemahan disembunyikan.", "Translation hidden.")) }
                    1 -> { ukuranArab = (ukuranArab + 2).coerceAtMost(42f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); toast(tr("Ukuran teks Arab: ", "Arabic text size: ") + ukuranArab.toInt()) }
                    2 -> { ukuranArab = (ukuranArab - 2).coerceAtLeast(22f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); toast(tr("Ukuran teks Arab: ", "Arabic text size: ") + ukuranArab.toInt()) }
                    3 -> { unduhSemuaTeks { pengaturanAksesibilitas() }; return@setItems }
                    4 -> {
                        senyapTalkBackPergantian = !senyapTalkBackPergantian
                        dataPrefs.edit().putBoolean("senyap_talkback_pergantian_audio", senyapTalkBackPergantian).apply()
                        toast(if (senyapTalkBackPergantian)
                            tr("Suara TalkBack dimatikan saat audio berpindah otomatis ke audio berikutnya.", "TalkBack speech is muted when audio moves automatically to the next audio.")
                        else
                            tr("Suara TalkBack tetap aktif saat audio berpindah ke audio berikutnya.", "TalkBack speech stays on when audio moves to the next audio."))
                    }
                }
                // Tetap di grup aksesibilitas agar pilihan dapat diatur berulang; Kembali menuju Pengaturan Khatam.
                handler.post { pengaturanAksesibilitas() }
            }
            .kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }
            .show()
    }

    private fun tanggalHariIni(): String = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())
}
