package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

class Prefs(context: Context) {

    internal val appContext: Context = context.applicationContext
    private val sp = context.applicationContext
        .getSharedPreferences("pengaturan", Context.MODE_PRIVATE)

    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun idx(k: String, d: Int, max: Int) = sp.getInt(k, d).coerceIn(0, max - 1)
    private fun putInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    // ---------- Umum ----------
    var enabled: Boolean
        get() = bool("enabled", false)
        set(v) = putBool("enabled", v)

    var bootOn: Boolean
        get() = bool("boot", false)
        set(v) = putBool("boot", v)

    // ---------- Profil suara: "bat" (baterai), "jam", "tgl" (pembaca tanggal), "pem" (pemanggil) ----------
    fun suara(profil: String) = Suara(profil)

    /**
     * FIX264: volume mandiri pengumuman Nama Panggilan per sumber: "panggilan_seluler", "panggilan_wb", "panggilan_wa" (Jenis panggilan),
     * "pesan_seluler", "pesan_wb", "pesan_wa" (Pembacaan pesan dan notifikasi), dan "lain" (satu volume untuk semua aplikasi tambahan). Selama belum diatur, mengikuti volume profil pemanggil.
     */
    fun volumeSumberPem(kelompok: String): Int =
        if (sp.contains("pem_vol_" + kelompok)) sp.getInt("pem_vol_" + kelompok, 100).coerceIn(0, 100) else suara("pem").volumePersen
    /** FIX264: berkas audio pengguna per slot (baterai: level, lemah, kritis, penuh, penuh100, charger_on, charger_off, usb_on, usb_off; jam: jam_awal, jam_akhir). Kosong = ucapan/melodi bawaan. */
    fun berkasSendiri(slot: String): String = sp.getString("berkas_sendiri_" + slot, "") ?: ""
    fun setBerkasSendiri(slot: String, uri: String) { sp.edit().putString("berkas_sendiri_" + slot, uri).apply() }

    fun setVolumeSumberPem(kelompok: String, v: Int) { sp.edit().putInt("pem_vol_" + kelompok, v.coerceIn(0, 100)).apply() }

    inner class Suara(private val p: String) {
        val profil: String get() = p
        // Profil baterai memakai kunci lama agar pengaturan lama tetap terbaca.
        private fun k(n: String) = if (p == "bat") n else ("" + (p) + "_" + (n))

        /**
         * Profil "tgl" (pembaca tanggal) memakai pengaturan profil "jam" selama belum pernah diubah sendiri,
         * sehingga suara tanggal tidak tiba-tiba berganti setelah pembaruan.
         */
        private fun kb(n: String) = if (p == "tgl" && !sp.contains(k(n))) ("jam_" + n) else k(n)

        /** Nama paket mesin suara; kosong = mesin bawaan sistem. */
        var engine: String
            get() = sp.getString(kb("engine"), "") ?: ""
            set(v) = sp.edit().putString(k("engine"), v).apply()

        var rateIdx: Int
            get() = idx(kb("rate"), 2, RATES.size)
            set(v) = putInt(k("rate"), v)

        var pitchIdx: Int
            get() = idx(kb("pitch"), 2, PITCHES.size)
            set(v) = putInt(k("pitch"), v)

        /** 0 = Media, 1 = Alarm, 2 = Notifikasi, 3 = Dering, 4 = Aksesibilitas, 5 = Panggilan suara, 6 = Sistem */
        var streamIdx: Int
            get() = idx(kb("stream"), if (p == "pem") 1 else 0, 7)
            set(v) = putInt(k("stream"), v)

        /** Volume digital mandiri per kategori, tidak mengubah volume sistem atau kategori lain. */
        var volumePersen: Int
            get() = sp.getInt(kb("volume_persen"), 100).coerceIn(0, 100)
            set(v) { sp.edit().putInt(k("volume_persen"), v.coerceIn(0, 100)).apply() }

        /** Efek ruang TTS: 0 normal, 1-6 preset lama, 7-10 karakter gema/studio/karaoke/panggung. */
        var efekRuang: Int
            get() = idx(kb("efek_ruang"), 0, 11)
            set(v) = putInt(k("efek_ruang"), v)

        /** Kunci lama tetap dibaca agar preferensi versi sebelumnya tidak mengganggu migrasi. */
        var efekPengumuman: Int
            get() = idx(kb("efek_pengumuman"), 0, 3)
            set(v) = putInt(k("efek_pengumuman"), v)

        val rate: Float get() = RATES[rateIdx]
        val pitch: Float get() = PITCHES[pitchIdx]

        fun tanda() = (("" + (p) + "|" + (engine) + "|" + (rateIdx) + "|" + (pitchIdx) + "|" + (streamIdx) + "|" + volumePersen + "|" + efekRuang + "|") + jamBahasaIdx + "|" + bahasaPemanggil)

        fun audioAttributes(): AudioAttributes {
            val usage = when (streamIdx) {
                1 -> AudioAttributes.USAGE_ALARM
                2 -> AudioAttributes.USAGE_NOTIFICATION
                3 -> AudioAttributes.USAGE_NOTIFICATION_RINGTONE
                4 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
                5 -> AudioAttributes.USAGE_VOICE_COMMUNICATION
                6 -> AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
                else -> AudioAttributes.USAGE_MEDIA
            }
            return AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        }

        fun streamType(): Int = when (streamIdx) {
            1 -> AudioManager.STREAM_ALARM
            2 -> AudioManager.STREAM_NOTIFICATION
            3 -> AudioManager.STREAM_RING
            4 -> if (android.os.Build.VERSION.SDK_INT >= 26) AudioManager.STREAM_ACCESSIBILITY else AudioManager.STREAM_MUSIC
            5 -> AudioManager.STREAM_VOICE_CALL
            6 -> AudioManager.STREAM_SYSTEM
            else -> AudioManager.STREAM_MUSIC
        }
    }

    // ---------- Baterai ----------
    var bateraiOn: Boolean
        get() = bool("baterai_on", false)
        set(v) = putBool("baterai_on", v)

    var stepIdx: Int
        get() = idx("step", 1, STEPS.size)
        set(v) = putInt("step", v)

    /** 0 = berdasarkan persen baterai, 1 = berdasarkan interval waktu. */
    var batCara: Int
        get() = idx("bat_cara", 0, 2)
        set(v) = putInt("bat_cara", v)

    var batIntervalIdx: Int
        get() = idx("bat_interval", 3, BAT_INTERVALS.size)
        set(v) = putInt("bat_interval", v)

    val batInterval: Int get() = BAT_INTERVALS[batIntervalIdx]

    /** 0 = persen disebut hanya saat mengisi daya, 1 = selalu */
    var levelMode: Int
        get() = idx("level_mode", 1, 2)
        set(v) = putInt("level_mode", v)

    var lowIdx: Int
        get() = idx("low", 1, LOWS.size)
        set(v) = putInt("low", v)

    var lemahOn: Boolean
        get() = bool("lemah", false)
        set(v) = putBool("lemah", v)

    var kritisOn: Boolean
        get() = bool("kritis", false)
        set(v) = putBool("kritis", v)

    /** Batas kritis yang dapat dipilih pengguna, dalam persen. */
    var batasKritis: Int
        get() = sp.getInt("batas_kritis", 5).coerceIn(1, 20)
        set(v) = putInt("batas_kritis", v.coerceIn(1, 20))

    var penuhOn: Boolean
        get() = bool("penuh", false)
        set(v) = putBool("penuh", v)

    var chargerOn: Boolean
        get() = bool("charger", false)
        set(v) = putBool("charger", v)

    var usbOn: Boolean
        get() = bool("usb", false)
        set(v) = putBool("usb", v)

    val lowThreshold: Int get() = LOWS[lowIdx]
    val step: Int get() = STEPS[stepIdx]

    // Kalimat baterai bawaan mengikuti bahasa pengucapan aktif. Jika pengguna benar-benar
    // mengubah kalimatnya sendiri, teks khusus itu dipertahankan saat bahasa diganti.
    private fun kalimat(kunci: String, bawaan: String, bahasa: Int = bahasaAktif): String {
        val tersimpan = sp.getString(kunci, null)?.takeIf { it.isNotBlank() }
        val semuaBahasa = (0..4).map { kalimatBawaanUntukBahasa(kunci, bawaan, it) }.toSet()
        if (tersimpan != null && tersimpan !in semuaBahasa) return tersimpan
        return kalimatBawaanUntukBahasa(kunci, bawaan, bahasa)
    }

    private fun kalimatBawaanUntukBahasa(kunci: String, bawaan: String, bahasa: Int): String {
        if (bahasa == 0) return bawaan
        return when (bahasa) {
            1 -> when (kunci) {
                "kal_pesan_seluler" -> "New text message from {nama}. {pesan}"
                "kal_chat_wa_pribadi" -> "New WhatsApp message from {nama}. {pesan}"
                "kal_chat_wa_grup" -> "New WhatsApp message from {nama} in the group {grup}. {pesan}"
                "kal_suara_wa_pribadi" -> "WhatsApp voice message from {nama}"
                "kal_suara_wa_grup" -> "WhatsApp voice message from {nama} in the group {grup}"
                "kal_chat_wb_pribadi" -> "New WhatsApp Business message from {nama}. {pesan}"
                "kal_chat_wb_grup" -> "New WhatsApp Business message from {nama} in the group {grup}. {pesan}"
                "kal_suara_wb_pribadi" -> "WhatsApp Business voice message from {nama}"
                "kal_suara_wb_grup" -> "WhatsApp Business voice message from {nama} in the group {grup}"

                "kal_level" -> "Battery {persen} percent."
                "kal_lemah" -> "Low battery, {persen} percent remaining. Please charge the device."
                "kal_kritis" -> "Warning! Critical battery, {persen} percent remaining. Charge the device now."
                "kal_penuh" -> "Battery is {persen} percent. You may unplug the charger."
                "kal_penuh_100" -> "Battery is fully charged. Please unplug the charger."
                "kal_charger_on" -> "Charger connected."
                "kal_charger_off" -> "Charger disconnected."
                "kal_usb_on" -> "USB cable connected."
                "kal_usb_off" -> "USB cable disconnected."
                else -> bawaan
            }
            2 -> when (kunci) {
                "kal_pesan_seluler" -> "رسالة نصية جديدة من {nama}. {pesan}"
                "kal_chat_wa_pribadi" -> "رسالة واتساب جديدة من {nama}. {pesan}"
                "kal_chat_wa_grup" -> "رسالة واتساب جديدة من {nama} في مجموعة {grup}. {pesan}"
                "kal_suara_wa_pribadi" -> "رسالة صوتية من واتساب من {nama}"
                "kal_suara_wa_grup" -> "رسالة صوتية من واتساب من {nama} في مجموعة {grup}"
                "kal_chat_wb_pribadi" -> "رسالة جديدة من واتساب للأعمال من {nama}. {pesan}"
                "kal_chat_wb_grup" -> "رسالة جديدة من واتساب للأعمال من {nama} في مجموعة {grup}. {pesan}"
                "kal_suara_wb_pribadi" -> "رسالة صوتية من واتساب للأعمال من {nama}"
                "kal_suara_wb_grup" -> "رسالة صوتية من واتساب للأعمال من {nama} في مجموعة {grup}"

                "kal_level" -> "مستوى البطارية {persen} بالمئة."
                "kal_lemah" -> "البطارية منخفضة، المتبقي {persen} بالمئة. يرجى شحن الجهاز."
                "kal_kritis" -> "تحذير، مستوى البطارية حرج، المتبقي {persen} بالمئة. يرجى شحن الجهاز فوراً."
                "kal_penuh", "kal_penuh_100" -> "اكتمل شحن البطارية. يرجى فصل الشاحن."
                "kal_charger_on" -> "تم توصيل الشاحن."
                "kal_charger_off" -> "تم فصل الشاحن."
                "kal_usb_on" -> "تم توصيل كابل يو إس بي."
                "kal_usb_off" -> "تم فصل كابل يو إس بي."
                else -> bawaan
            }
            3 -> when (kunci) {
                "kal_pesan_seluler" -> "Pesen teks enggal saking {nama}. {pesan}"
                "kal_chat_wa_pribadi" -> "Pesen WhatsApp enggal saking {nama}. {pesan}"
                "kal_chat_wa_grup" -> "Pesen WhatsApp enggal saking {nama} ing grup {grup}. {pesan}"
                "kal_suara_wa_pribadi" -> "Pesen swara WhatsApp saking {nama}"
                "kal_suara_wa_grup" -> "Pesen swara WhatsApp saking {nama} ing grup {grup}"
                "kal_chat_wb_pribadi" -> "Pesen WhatsApp Business enggal saking {nama}. {pesan}"
                "kal_chat_wb_grup" -> "Pesen WhatsApp Business enggal saking {nama} ing grup {grup}. {pesan}"
                "kal_suara_wb_pribadi" -> "Pesen swara WhatsApp Business saking {nama}"
                "kal_suara_wb_grup" -> "Pesen swara WhatsApp Business saking {nama} ing grup {grup}"

                "kal_level" -> "Baterei {persen} persen."
                "kal_lemah" -> "Baterei kirang, kantun {persen} persen. Mangga enggal dipunisi."
                "kal_kritis" -> "Pènget, baterei kritis, kantun {persen} persen. Mangga enggal dipunisi."
                "kal_penuh", "kal_penuh_100" -> "Baterei sampun kebak. Mangga copot pangisi daya."
                "kal_charger_on" -> "Pangisi daya sampun kasambung."
                "kal_charger_off" -> "Pangisi daya sampun kacopot."
                "kal_usb_on" -> "Kabel USB sampun kasambung."
                "kal_usb_off" -> "Kabel USB sampun kacopot."
                else -> bawaan
            }
            4 -> when (kunci) {
                "kal_pesan_seluler" -> "Aya pesen téks anyar ti {nama}. {pesan}"
                "kal_chat_wa_pribadi" -> "Aya pesen WhatsApp anyar ti {nama}. {pesan}"
                "kal_chat_wa_grup" -> "Aya pesen WhatsApp anyar ti {nama} dina grup {grup}. {pesan}"
                "kal_suara_wa_pribadi" -> "Pesen sora WhatsApp ti {nama}"
                "kal_suara_wa_grup" -> "Pesen sora WhatsApp ti {nama} dina grup {grup}"
                "kal_chat_wb_pribadi" -> "Aya pesen WhatsApp Business anyar ti {nama}. {pesan}"
                "kal_chat_wb_grup" -> "Aya pesen WhatsApp Business anyar ti {nama} dina grup {grup}. {pesan}"
                "kal_suara_wb_pribadi" -> "Pesen sora WhatsApp Business ti {nama}"
                "kal_suara_wb_grup" -> "Pesen sora WhatsApp Business ti {nama} dina grup {grup}"

                "kal_level" -> "Batéri {persen} persén."
                "kal_lemah" -> "Batéri lemah, kari {persen} persén. Mangga geura dieusi."
                "kal_kritis" -> "Pangéling, batéri kritis, kari {persen} persén. Mangga geura dieusi."
                "kal_penuh", "kal_penuh_100" -> "Batéri parantos pinuh. Mangga cabut carjer."
                "kal_charger_on" -> "Carjer parantos nyambung."
                "kal_charger_off" -> "Carjer parantos dicabut."
                "kal_usb_on" -> "Kabel USB parantos nyambung."
                "kal_usb_off" -> "Kabel USB parantos dicabut."
                else -> bawaan
            }
            else -> bawaan
        }
    }
    private fun simpanKalimat(kunci: String, nilai: String, properti: String) {
        val bawaan = when (properti) {
            "kalLevel" -> "Baterai {persen} persen."
            "kalLemah" -> "Baterai lemah, tinggal {persen} persen. Segera isi daya."
            "kalKritis" -> "Peringatan! Baterai kritis, tinggal {persen} persen. Segera isi daya."
            "kalPenuh" -> "Baterai sudah {persen} persen. Silakan cabut pengisi daya."
            "kalPenuh100" -> "Baterai sudah 100 persen. Silakan cabut pengisi daya."
            "kalChargerOn" -> "Pengisi daya terhubung."
            "kalChargerOff" -> "Pengisi daya dicabut."
            "kalUsbOn" -> "Kabel USB terhubung."
            else -> "Kabel USB dicabut."
        }
        val defaultSet = (0..4).map { kalimatBawaanUntukBahasa(kunci, bawaan, it) }.toSet()
        val editor = sp.edit()
        if (nilai in defaultSet) editor.remove(kunci) else editor.putString(kunci, nilai)
        editor.apply()
    }

    var kalLevel: String
        get() = kalimat("kal_level", "Baterai {persen} persen.")
        set(v) = simpanKalimat("kal_level", v, "kalLevel")
    var kalLemah: String
        get() = kalimat("kal_lemah", "Baterai lemah, tinggal {persen} persen. Segera isi daya.")
        set(v) = simpanKalimat("kal_lemah", v, "kalLemah")
    var kalKritis: String
        get() = kalimat("kal_kritis", "Peringatan! Baterai kritis, tinggal {persen} persen. Segera isi daya.")
        set(v) = simpanKalimat("kal_kritis", v, "kalKritis")
    var kalPenuh: String
        get() = kalimat("kal_penuh", "Baterai sudah {persen} persen. Silakan cabut pengisi daya.")
        set(v) = simpanKalimat("kal_penuh", v, "kalPenuh")
    var kalPenuh100: String
        get() = kalimat("kal_penuh_100", "Baterai sudah 100 persen. Silakan cabut pengisi daya.")
        set(v) = simpanKalimat("kal_penuh_100", v, "kalPenuh100")
    var kalChargerOn: String
        get() = kalimat("kal_charger_on", "Pengisi daya terhubung.")
        set(v) = simpanKalimat("kal_charger_on", v, "kalChargerOn")
    var kalChargerOff: String
        get() = kalimat("kal_charger_off", "Pengisi daya dicabut.")
        set(v) = simpanKalimat("kal_charger_off", v, "kalChargerOff")
    var kalUsbOn: String
        get() = kalimat("kal_usb_on", "Kabel USB terhubung.")
        set(v) = simpanKalimat("kal_usb_on", v, "kalUsbOn")
    var kalUsbOff: String
        get() = kalimat("kal_usb_off", "Kabel USB dicabut.")
        set(v) = simpanKalimat("kal_usb_off", v, "kalUsbOff")

    // ---------- Pemicu Beritahu Saya ----------
    /** Mengizinkan widget layar utama membacakan waktu. Aktif secara bawaan untuk menjaga perilaku lama. */
    var beritahuSayaOn: Boolean
        get() = bool("beritahu_saya_on", false)
        set(v) = putBool("beritahu_saya_on", v)

    /** FIX86: ketukan pada Beritahu Saya (widget dan ikon) langsung membuka perintah suara, bukan membacakan waktu. */
    var beritahuSayaLangsungSuara: Boolean
        get() = bool("beritahu_saya_langsung_suara", false)
        set(v) = putBool("beritahu_saya_langsung_suara", v)

    // ---------- Info hari libur nasional dan cuti bersama ----------
    var liburNasionalAutoSync: Boolean
        get() = bool("enable_national_auto_sync", false)
        set(v) = putBool("enable_national_auto_sync", v)
    var liburNasionalLampau: Boolean
        get() = bool("enable_national_past", false)
        set(v) = putBool("enable_national_past", v)
    var liburNasionalTerkini: Boolean
        get() = bool("enable_national_current", false)
        set(v) = putBool("enable_national_current", v)
    var liburNasionalMendatang: Boolean
        get() = bool("enable_national_upcoming", false)
        set(v) = putBool("enable_national_upcoming", v)
    var cutiBersamaAutoSync: Boolean
        get() = bool("enable_joint_auto_sync", false)
        set(v) = putBool("enable_joint_auto_sync", v)
    var cutiBersamaLampau: Boolean
        get() = bool("enable_joint_past", false)
        set(v) = putBool("enable_joint_past", v)
    var cutiBersamaTerkini: Boolean
        get() = bool("enable_joint_current", false)
        set(v) = putBool("enable_joint_current", v)
    var cutiBersamaMendatang: Boolean
        get() = bool("enable_joint_upcoming", false)
        set(v) = putBool("enable_joint_upcoming", v)

    // ---------- Jam ----------
    var jamOn: Boolean
        get() = bool("jam_on", false)
        set(v) = putBool("jam_on", v)

    /** 0 = setiap jam tepat, 1 = setiap beberapa menit */
    var jamMode: Int
        get() = idx("jam_mode", 0, 2)
        set(v) = putInt("jam_mode", v)

    var jamIntervalIdx: Int
        get() = idx("jam_interval", 4, JAM_INTERVALS.size)
        set(v) = putInt("jam_interval", v)

    val jamInterval: Int get() = JAM_INTERVALS[jamIntervalIdx]

    /** Menit sejak pukul 00.00 */
    var jamMulai: Int
        get() = sp.getInt("jam_mulai", 6 * 60).coerceIn(0, 1439)
        set(v) = putInt("jam_mulai", v)

    var jamSelesai: Int
        get() = sp.getInt("jam_selesai", 22 * 60).coerceIn(0, 1439)
        set(v) = putInt("jam_selesai", v)

    /** Bit 0 = Minggu, bit 1 = Senin, ... bit 6 = Sabtu */
    var jamHari: Int
        get() = sp.getInt("jam_hari", 127) and 127
        set(v) = putInt("jam_hari", v and 127)

    /** 0 = 24 jam, 1 = 12 jam (pagi/siang/sore/malam) */
    var jamFormat: Int
        get() = idx("jam_format", 1, 2)
        set(v) = putInt("jam_format", v)

    /** Bahasa pengucapan: 0 Indonesia, 1 English, 2 Arab, 3 Jawa Krama Inggil, 4 Sunda Halus. */
    var jamBahasaIdx: Int
        get() = idx("jam_bahasa", 0, 5)
        set(v) = putInt("jam_bahasa", v)

    /**
     * FIX70: bahasa pengumuman nama pemanggil dan notifikasi. Mengikuti bahasa tampilan utama (Indonesia atau English);
     * pilihan bahasa pengucapan Arab, Jawa, atau Sunda tetap dihormati karena tidak bertentangan dengan bahasa tampilan.
     */
    val bahasaPemanggil: Int
        get() = bahasaAktif

    /**
     * FIX71: bahasa aktif untuk semua pengucapan (jam, baterai, kalender, info salat, pemanggil, notifikasi).
     * Mengikuti bahasa tampilan utama (Indonesia atau English); pilihan bahasa pengucapan Arab, Jawa Krama Inggil,
     * atau Sunda Halus tetap dihormati. Nilai tersimpan `jamBahasaIdx` hanya dipakai di layar pengaturan bahasa.
     */
    val bahasaAktif: Int
        get() { val u = jamBahasaIdx; return if (u in 2..4) u else BahasaAplikasi.tampilan(appContext).coerceIn(0, 1) }

    /** Melodi jam: 0 = mati, 1..16 = audio yang dipulihkan dari APK sumber. */
    var jamMelodiAwal: Int
        get() = idx("jam_melodi_awal", 0, 18)
        set(v) = putInt("jam_melodi_awal", v)

    var jamMelodiAkhir: Int
        get() = idx("jam_melodi_akhir", 0, 18)
        set(v) = putInt("jam_melodi_akhir", v)

    var jamJedaAwal: Float
        get() = sp.getFloat("jam_jeda_awal", 0.0f).coerceIn(0f, 30f)
        set(v) = sp.edit().putFloat("jam_jeda_awal", v.coerceIn(0f, 30f)).apply()

    var jamJedaAkhir: Float
        get() = sp.getFloat("jam_jeda_akhir", 0.0f).coerceIn(0f, 30f)
        set(v) = sp.edit().putFloat("jam_jeda_akhir", v.coerceIn(0f, 30f)).apply()

    var jamJedaJamMenit: Int
        get() {
            // Versi 1.0.29 mengembalikan jeda antarucapan jam-menit ke standar 300 ms.
            // Migrasi hanya dilakukan sekali agar nilai 650 ms dari versi sebelumnya tidak tertinggal.
            if (!sp.getBoolean("jam_jeda_standard_v1029", false)) {
                sp.edit().putInt("jam_jeda_jam_menit", 300)
                    .putBoolean("jam_jeda_standard_v1029", true).apply()
            }
            return sp.getInt("jam_jeda_jam_menit", 300).coerceIn(0, 3000)
        }
        set(v) = putInt("jam_jeda_jam_menit", v.coerceIn(0, 3000))

    // ---------- Pengulangan baterai penuh ----------
    var penuhUlangOn: Boolean
        get() = bool("penuh_ulang", false)
        set(v) = putBool("penuh_ulang", v)

    var penuhUlangJumlah: Int
        get() = sp.getInt("penuh_ulang_jumlah", 3).coerceIn(1, 20)
        set(v) = putInt("penuh_ulang_jumlah", v.coerceIn(1, 20))

    var penuhUlangJeda: Int
        get() = sp.getInt("penuh_ulang_jeda", 60).coerceIn(1, 3600)
        set(v) = putInt("penuh_ulang_jeda", v.coerceIn(1, 3600))

    var batasPenuh: Int
        get() = sp.getInt("batas_penuh", 100).coerceIn(80, 100)
        set(v) = putInt("batas_penuh", v.coerceIn(80, 100))

    var jamSebutJam: Boolean
        get() = bool("jam_sebut_jam", false)
        set(v) = putBool("jam_sebut_jam", v)

    var jamSebutMenit: Boolean
        get() = bool("jam_menit", false)
        set(v) = putBool("jam_menit", v)

    var jamSebutDetik: Boolean
        get() = bool("jam_detik", false)
        set(v) = putBool("jam_detik", v)

    /** Kata "tepat" sebelum jam, saat jam pas (mis. "Tepat pukul lima pagi"). */
    var jamTepatAwal: Boolean
        get() = bool("jam_tepat_awal", false)
        set(v) = putBool("jam_tepat_awal", v)

    /** Kata "tepat" sesudah jam, saat jam pas (mis. "pukul enam tepat"). Bawaan aktif seperti perilaku sebelumnya. */
    var jamTepatAkhir: Boolean
        get() = bool("jam_tepat_akhir", true)
        set(v) = putBool("jam_tepat_akhir", v)

    /** Info waktu sholat berikutnya ikut dibacakan dalam rangkaian ucapan jam (bawaan mati). */
    var jamInfoSholat: Boolean
        get() = bool("jam_info_sholat", false)
        set(v) = putBool("jam_info_sholat", v)

    /** Sebut nama lokasi pada info sholat berikutnya (bawaan aktif). */
    var jamInfoSholatLokasi: Boolean
        get() = bool("jam_info_sholat_lokasi", true)
        set(v) = putBool("jam_info_sholat_lokasi", v)

    var jamSebutPeriode: Boolean
        get() = bool("jam_sebut_periode", false)
        set(v) = putBool("jam_sebut_periode", v)

    /** Kata pembuka ucapan bawaan tiap bahasa ucapan: 0 Indonesia, 1 English, 2 Arab, 3 Jawa. */
    fun awalanBawaan(bahasa: Int): String = when (bahasa) {
        1 -> "It is"
        2 -> "الوقت الحالي"
        3 -> "Sapunika wekdalipun"
        4 -> "Ayeuna tabuh"
        else -> "Saat ini pukul"
    }

    // Tiap bahasa menyimpan kata pembuka sendiri (Indonesia tetap memakai kunci lama "jam_awalan").
    private fun kunciAwalan(bahasa: Int): String = when (bahasa) {
        1 -> "jam_awalan_en"
        2 -> "jam_awalan_ar"
        3 -> "jam_awalan_jv"
        4 -> "jam_awalan_su"
        else -> "jam_awalan"
    }

    /** Kata pembuka untuk bahasa ucapan yang sedang dipilih; kosong/spasi = kata pembuka bawaan bahasa itu. */
    var jamAwalan: String
        get() = sp.getString(kunciAwalan(bahasaAktif), null)?.takeIf { it.isNotBlank() } ?: awalanBawaan(bahasaAktif)
        set(v) = sp.edit().putString(kunciAwalan(bahasaAktif), v).apply()

    // ---------- Kalender yang dibacakan bersama waktu ----------
    var kalenderMasehiOn: Boolean
        get() = bool("kal_masehi_on", false)
        set(v) = putBool("kal_masehi_on", v)

    var kalenderHijriOn: Boolean
        get() = bool("kal_hijri_on", false)
        set(v) = putBool("kal_hijri_on", v)

    /** Mode otomatis memakai perhitungan Hijriah perangkat; koreksi manual dikunci saat aktif. */
    var kalenderHijriAuto: Boolean
        get() = bool("kal_hijri_auto", true) // FIX216: default aktif agar Hijriah mengikuti data daring
        set(v) = putBool("kal_hijri_auto", v)

    /** Koreksi hari Hijriah manual, rentang -30 sampai +30. */
    var kalenderHijriKoreksi: Int
        get() = sp.getInt("kal_hijri_koreksi", 0).coerceIn(-30, 30)
        set(v) = putInt("kal_hijri_koreksi", v.coerceIn(-30, 30))

    /** Selisih hasil sinkronisasi daring terhadap kalender Hijriah Android. */
    var kalenderHijriOnlineOffset: Int
        get() = sp.getInt("kal_hijri_online_offset", 0).coerceIn(-3, 3)
        set(v) = putInt("kal_hijri_online_offset", v.coerceIn(-3, 3))
    val kalenderHijriOnlineTanggal: String
        get() = sp.getString("kal_hijri_online_sync_date", "") ?: ""
    val kalenderHijriOnlineHari: Int
        get() = sp.getInt("kal_hijri_online_day", 0)
    val kalenderHijriOnlineBulan: Int
        get() = sp.getInt("kal_hijri_online_month", 0)
    val kalenderHijriOnlineTahun: Int
        get() = sp.getInt("kal_hijri_online_year", 0)

    var kalenderPasaranOn: Boolean
        get() = bool("kal_pasaran_on", false)
        set(v) = putBool("kal_pasaran_on", v)

    /** Koreksi putaran pasaran manual, rentang -30 sampai +30 hari. */
    var kalenderPasaranKoreksi: Int
        get() = sp.getInt("kal_pasaran_koreksi", 0).coerceIn(-30, 30)
        set(v) = putInt("kal_pasaran_koreksi", v.coerceIn(-30, 30))

    // ---------- Nama pemanggil ----------
    var pemOn: Boolean
        get() = bool("pem_on", false)
        set(v) = putBool("pem_on", v)

    var pemWa: Boolean
        get() = bool("pem_wa", false)
        set(v) = putBool("pem_wa", v)

    var pemTelp: Boolean
        get() = bool("pem_telp", false)
        set(v) = putBool("pem_telp", v)

    var pemWb: Boolean
        get() = bool("pem_wb", false)
        set(v) = putBool("pem_wb", v)

    var pemJenis: Boolean
        get() = bool("pem_jenis", false)
        set(v) = putBool("pem_jenis", v)

    var pemNamaPanggilan: Boolean
        get() = bool("pem_nama_panggilan", false)
        set(v) = putBool("pem_nama_panggilan", v)

    // Pesan opsional sebelum dan sesudah nama pemanggil.
    var pesanSebelumNamaPemanggil: String get() = sp.getString("pesan_sebelum_nama_pemanggil", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_nama_pemanggil", v).apply()
    var pesanSesudahNamaPemanggil: String get() = sp.getString("pesan_sesudah_nama_pemanggil", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_nama_pemanggil", v).apply()

    // Pola pesan khusus setiap jenis panggilan agar pengguna dapat membedakan sumber dan jenis panggilan.
    var pesanSebelumTelp: String get() = sp.getString("pesan_sebelum_telp", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_telp", v).apply()
    var pesanSesudahTelp: String get() = sp.getString("pesan_sesudah_telp", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_telp", v).apply()
    var pesanSebelumWaSuara: String get() = sp.getString("pesan_sebelum_wa_suara", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_wa_suara", v).apply()
    var pesanSesudahWaSuara: String get() = sp.getString("pesan_sesudah_wa_suara", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_wa_suara", v).apply()
    var pesanSebelumWaVideo: String get() = sp.getString("pesan_sebelum_wa_video", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_wa_video", v).apply()
    var pesanSesudahWaVideo: String get() = sp.getString("pesan_sesudah_wa_video", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_wa_video", v).apply()
    var pesanSebelumWbSuara: String get() = sp.getString("pesan_sebelum_wb_suara", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_wb_suara", v).apply()
    var pesanSesudahWbSuara: String get() = sp.getString("pesan_sesudah_wb_suara", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_wb_suara", v).apply()
    var pesanSebelumWbVideo: String get() = sp.getString("pesan_sebelum_wb_video", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_wb_video", v).apply()
    var pesanSesudahWbVideo: String get() = sp.getString("pesan_sesudah_wb_video", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_wb_video", v).apply()

    // Cara membaca isi pesan diatur terpisah untuk SMS, WhatsApp Messenger, dan WhatsApp Business.
    // Jika pengaturan baru belum pernah disimpan, pertahankan pilihan lama sebagai nilai awal.
    private fun modePesan(kunci: String): Int = idx(kunci, modePembacaanIsiPesan, 2).coerceIn(0, 1)
    var modePembacaanIsiPesan: Int
        get() = idx("mode_pembacaan_isi_pesan", 0, 2)
        set(v) = putInt("mode_pembacaan_isi_pesan", v.coerceIn(0, 1))
    var modePesanSeluler: Int get() = modePesan("mode_pesan_seluler"); set(v) = putInt("mode_pesan_seluler", v.coerceIn(0, 1))
    var modePesanWa: Int get() = modePesan("mode_pesan_wa"); set(v) = putInt("mode_pesan_wa", v.coerceIn(0, 1))
    var modePesanWb: Int get() = modePesan("mode_pesan_wb"); set(v) = putInt("mode_pesan_wb", v.coerceIn(0, 1))

    // Pesan sebelum/sesudah nama pengirim untuk setiap jenis notifikasi.
    // Kunci SMS lama dipertahankan agar pengaturan yang sudah disimpan pengguna tetap terbaca.
    var pesanSebelumNamaSms: String get() = sp.getString("pesan_sebelum_nama_sms", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_nama_sms", v).apply()
    var pesanSesudahNamaSms: String get() = sp.getString("pesan_sesudah_nama_sms", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_nama_sms", v).apply()
    var pesanSebelumChatWaPribadi: String get() = sp.getString("pesan_sebelum_chat_wa_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_chat_wa_pribadi", v).apply()
    var pesanSesudahChatWaPribadi: String get() = sp.getString("pesan_sesudah_chat_wa_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_chat_wa_pribadi", v).apply()
    var pesanSebelumChatWaGrup: String get() = sp.getString("pesan_sebelum_chat_wa_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_chat_wa_grup", v).apply()
    var pesanSesudahChatWaGrup: String get() = sp.getString("pesan_sesudah_chat_wa_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_chat_wa_grup", v).apply()
    var pesanSebelumSuaraWaPribadi: String get() = sp.getString("pesan_sebelum_suara_wa_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_suara_wa_pribadi", v).apply()
    var pesanSesudahSuaraWaPribadi: String get() = sp.getString("pesan_sesudah_suara_wa_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_suara_wa_pribadi", v).apply()
    var pesanSebelumSuaraWaGrup: String get() = sp.getString("pesan_sebelum_suara_wa_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_suara_wa_grup", v).apply()
    var pesanSesudahSuaraWaGrup: String get() = sp.getString("pesan_sesudah_suara_wa_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_suara_wa_grup", v).apply()
    var pesanSebelumChatWbPribadi: String get() = sp.getString("pesan_sebelum_chat_wb_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_chat_wb_pribadi", v).apply()
    var pesanSesudahChatWbPribadi: String get() = sp.getString("pesan_sesudah_chat_wb_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_chat_wb_pribadi", v).apply()
    var pesanSebelumChatWbGrup: String get() = sp.getString("pesan_sebelum_chat_wb_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_chat_wb_grup", v).apply()
    var pesanSesudahChatWbGrup: String get() = sp.getString("pesan_sesudah_chat_wb_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_chat_wb_grup", v).apply()
    var pesanSebelumSuaraWbPribadi: String get() = sp.getString("pesan_sebelum_suara_wb_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_suara_wb_pribadi", v).apply()
    var pesanSesudahSuaraWbPribadi: String get() = sp.getString("pesan_sesudah_suara_wb_pribadi", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_suara_wb_pribadi", v).apply()
    var pesanSebelumSuaraWbGrup: String get() = sp.getString("pesan_sebelum_suara_wb_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sebelum_suara_wb_grup", v).apply()
    var pesanSesudahSuaraWbGrup: String get() = sp.getString("pesan_sesudah_suara_wb_grup", "").orEmpty(); set(v) = sp.edit().putString("pesan_sesudah_suara_wb_grup", v).apply()

    // Jumlah pembacaan notifikasi terpisah dari pengulangan panggilan masuk.
    // Kunci baru menjaga kompatibilitas: pilihan lama 1/2/3/5 kali tetap dipertahankan
    // saat aplikasi diperbarui, sementara pilihan 0 kali dapat dipakai untuk menonaktifkan.
    var notifUlangIdx: Int
        get() = if (sp.contains("notif_ulang_pilihan_idx")) {
            idx("notif_ulang_pilihan_idx", 1, 6)
        } else {
            (idx("notif_ulang_idx", 0, 4) + 1).coerceIn(1, 4)
        }
        set(v) = putInt("notif_ulang_pilihan_idx", v.coerceIn(0, 5))
    val notifUlangJumlah: Int get() = intArrayOf(0, 1, 2, 3, 5, 10)[notifUlangIdx]
    var notifJeda: Float get() = sp.getFloat("notif_jeda", 3f).coerceIn(1f, 60f); set(v) = sp.edit().putFloat("notif_jeda", v.coerceIn(1f, 60f)).apply()

    // Pembacaan notifikasi pesan; semua sakelar baru nonaktif secara bawaan.
    var bacaPesanSeluler: Boolean
        get() = bool("baca_pesan_seluler", false)
        set(v) = putBool("baca_pesan_seluler", v)
    // Pembacaan notifikasi dari aplikasi selain SMS/WhatsApp; nonaktif secara bawaan.
    var bacaNotifEmail: Boolean get() = bool("baca_notif_email", false); set(v) = putBool("baca_notif_email", v)
    var bacaNotifGojek: Boolean get() = bool("baca_notif_gojek", false); set(v) = putBool("baca_notif_gojek", v)
    var bacaNotifGrab: Boolean get() = bool("baca_notif_grab", false); set(v) = putBool("baca_notif_grab", v)
    var bacaNotifInDrive: Boolean get() = bool("baca_notif_indrive", false); set(v) = putBool("baca_notif_indrive", v)
    var bacaNotifMaxim: Boolean get() = bool("baca_notif_maxim", false); set(v) = putBool("baca_notif_maxim", v)
    /** Paket aplikasi tambahan yang dipilih pengguna untuk dibacakan; kosong secara bawaan. */
    var aplikasiNotifKhusus: Set<String>
        get() = sp.getStringSet("aplikasi_notif_khusus", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("aplikasi_notif_khusus", v.toSet()).apply() }
    // Sakelar pesan dibedakan menurut aplikasi, jenis pesan, dan percakapan pribadi/grup.
    var bacaChatWaPribadi: Boolean get() = if (sp.contains("baca_chat_wa_pribadi")) bool("baca_chat_wa_pribadi", false) else bool("baca_chat_wa", false); set(v) = putBool("baca_chat_wa_pribadi", v)
    var bacaChatWaGrup: Boolean get() = bool("baca_chat_wa_grup", false); set(v) = putBool("baca_chat_wa_grup", v)
    var bacaSuaraWaPribadi: Boolean get() = if (sp.contains("baca_suara_wa_pribadi")) bool("baca_suara_wa_pribadi", false) else bool("baca_suara_wa", false); set(v) = putBool("baca_suara_wa_pribadi", v)
    var bacaSuaraWaGrup: Boolean get() = bool("baca_suara_wa_grup", false); set(v) = putBool("baca_suara_wa_grup", v)
    var bacaChatWbPribadi: Boolean get() = if (sp.contains("baca_chat_wb_pribadi")) bool("baca_chat_wb_pribadi", false) else bool("baca_chat_wb", false); set(v) = putBool("baca_chat_wb_pribadi", v)
    var bacaChatWbGrup: Boolean get() = bool("baca_chat_wb_grup", false); set(v) = putBool("baca_chat_wb_grup", v)
    var bacaSuaraWbPribadi: Boolean get() = if (sp.contains("baca_suara_wb_pribadi")) bool("baca_suara_wb_pribadi", false) else bool("baca_suara_wb", false); set(v) = putBool("baca_suara_wb_pribadi", v)
    var bacaSuaraWbGrup: Boolean get() = bool("baca_suara_wb_grup", false); set(v) = putBool("baca_suara_wb_grup", v)

    // Kalimat pengumuman pesan masuk; token {nama}, {grup}, {pesan}, dan {jenis} didukung.
    var kalPesanSeluler: String get() = kalimat("kal_pesan_seluler", "Pesan masuk dari {nama}. {pesan}", bahasaPemanggil); set(v) = sp.edit().putString("kal_pesan_seluler", v).apply()
    var kalChatWaPribadi: String get() = kalimat("kal_chat_wa_pribadi", "Chat masuk dari {nama}. {pesan}", bahasaPemanggil); set(v) = sp.edit().putString("kal_chat_wa_pribadi", v).apply()
    var kalChatWaGrup: String get() = kalimat("kal_chat_wa_grup", "Chat masuk dari {nama} di grup {grup}. {pesan}", bahasaPemanggil); set(v) = sp.edit().putString("kal_chat_wa_grup", v).apply()
    var kalSuaraWaPribadi: String get() = kalimat("kal_suara_wa_pribadi", "Pesan suara dari {nama}", bahasaPemanggil); set(v) = sp.edit().putString("kal_suara_wa_pribadi", v).apply()
    var kalSuaraWaGrup: String get() = kalimat("kal_suara_wa_grup", "Pesan suara dari {nama} di grup {grup}", bahasaPemanggil); set(v) = sp.edit().putString("kal_suara_wa_grup", v).apply()
    var kalChatWbPribadi: String get() = kalimat("kal_chat_wb_pribadi", "Chat masuk dari {nama}. {pesan}", bahasaPemanggil); set(v) = sp.edit().putString("kal_chat_wb_pribadi", v).apply()
    var kalChatWbGrup: String get() = kalimat("kal_chat_wb_grup", "Chat masuk dari {nama} di grup {grup}. {pesan}", bahasaPemanggil); set(v) = sp.edit().putString("kal_chat_wb_grup", v).apply()
    var kalSuaraWbPribadi: String get() = kalimat("kal_suara_wb_pribadi", "Pesan suara dari {nama}", bahasaPemanggil); set(v) = sp.edit().putString("kal_suara_wb_pribadi", v).apply()
    var kalSuaraWbGrup: String get() = kalimat("kal_suara_wb_grup", "Pesan suara dari {nama} di grup {grup}", bahasaPemanggil); set(v) = sp.edit().putString("kal_suara_wb_grup", v).apply()

    /** Kalimat yang diucapkan; {nama} diganti nama pemanggil. */
    var pemKalimatWaSuara: String
        get() = sp.getString("pem_k_wa_suara", null)?.takeIf { it.isNotBlank() } ?: DEF_WA_SUARA
        set(v) = sp.edit().putString("pem_k_wa_suara", v).apply()

    var pemKalimatWaVideo: String
        get() = sp.getString("pem_k_wa_video", null)?.takeIf { it.isNotBlank() } ?: DEF_WA_VIDEO
        set(v) = sp.edit().putString("pem_k_wa_video", v).apply()

    var pemKalimatTelp: String
        get() = sp.getString("pem_k_telp", null)?.takeIf { it.isNotBlank() } ?: DEF_TELP
        set(v) = sp.edit().putString("pem_k_telp", v).apply()

    var pemKalimatWbSuara: String
        get() = sp.getString("pem_k_wb_suara", null)?.takeIf { it.isNotBlank() } ?: DEF_WB_SUARA
        set(v) = sp.edit().putString("pem_k_wb_suara", v).apply()

    var pemKalimatWbVideo: String
        get() = sp.getString("pem_k_wb_video", null)?.takeIf { it.isNotBlank() } ?: DEF_WB_VIDEO
        set(v) = sp.edit().putString("pem_k_wb_video", v).apply()

    // Melodi pendek sebelum dan sesudah pengumuman nama pemanggil.
    var melodiAwalOn: Boolean
        get() = bool("melodi_awal_on", false)
        set(v) = putBool("melodi_awal_on", v)

    var melodiAkhirOn: Boolean
        get() = bool("melodi_akhir_on", false)
        set(v) = putBool("melodi_akhir_on", v)

    var melodiAwalIdx: Int
        get() = idx("pem_melodi_awal", 0, 18)
        set(v) = putInt("pem_melodi_awal", v)

    var melodiAkhirIdx: Int
        get() = idx("pem_melodi_akhir", 0, 18)
        set(v) = putInt("pem_melodi_akhir", v)

    var jedaMelodiAwal: Int
        get() = sp.getInt("jeda_melodi_awal", 350).coerceIn(0, 3000)
        set(v) = putInt("jeda_melodi_awal", v.coerceIn(0, 3000))

    var jedaMelodiAkhir: Int
        get() = sp.getInt("jeda_melodi_akhir", 250).coerceIn(0, 3000)
        set(v) = putInt("jeda_melodi_akhir", v.coerceIn(0, 3000))

    /** Jeda antar pengulangan, dalam detik. */
    var pemJeda: Float
        get() = sp.getFloat("pem_jeda", 1.5f).coerceIn(0.3f, 60f)
        set(v) = sp.edit().putFloat("pem_jeda", v).apply()

    var pemBatasIdx: Int
        get() = idx("pem_batas", 0, PEM_BATAS.size)
        set(v) = putInt("pem_batas", v)

    val pemBatas: Int get() = PEM_BATAS[pemBatasIdx]

    companion object {
        val DEF_WA_SUARA = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_WA_VIDEO = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_TELP = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_WB_SUARA = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_WB_VIDEO = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val RATES = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val PITCHES = floatArrayOf(0.6f, 0.8f, 1.0f, 1.2f, 1.4f)
        val STEPS = intArrayOf(0, 5, 10, 20, 25)
        val BAT_INTERVALS = intArrayOf(1, 2, 5, 10, 15, 30, 60)
        val LOWS = intArrayOf(10, 15, 20, 30)
        val JAM_INTERVALS = intArrayOf(5, 10, 15, 20, 30, 60)
        val PEM_BATAS = intArrayOf(0, 3, 5, 10, 20)
    }
}
