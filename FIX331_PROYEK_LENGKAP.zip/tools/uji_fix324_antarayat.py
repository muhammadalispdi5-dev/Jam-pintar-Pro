from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
k=(R/"KhatamActivity.kt").read_text(encoding="utf-8"); v=(R/"PemutarQuranService.kt").read_text(encoding="utf-8")
g=[]
for x in ["siapkanAyatBerikutnya()","lepasPramuatKh()","urlAyatBerikutnya","saatSiapKh(p)","adopsi"]:
    if x not in k: g.append("GAGAL khatam "+x)
if "if (i + 1 < totalItem()) 0 else" not in v: g.append("GAGAL ekor service 0")
print("\n".join(g) if g else "UJI FIX324: LULUS")
