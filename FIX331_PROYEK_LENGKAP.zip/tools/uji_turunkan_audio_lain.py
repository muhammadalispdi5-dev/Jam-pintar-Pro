from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
if "var turunkanAudioLain" not in t("Prefs.kt") or "turunkanAudioLain + " not in t("Prefs.kt"): g.append("GAGAL Prefs")
if "if (!suara.turunkanAudioLain) return" not in t("Pembicara.kt"): g.append("GAGAL Pembicara")
h=t("Halaman.kt")
if "turunkanDraf" in h or "Turunkan audio lain saat berbicara" in h: g.append("GAGAL dialog masih memuat saklar ganda")
if "turunkan_lain_global" not in t("Prefs.kt"): g.append("GAGAL kunci global")
m=t("MainActivity.kt")
if m.count("else \"Turunkan audio lain saat berbicara\"")!=1 or "turunkanAudioLain = it" not in m: g.append("GAGAL saklar tunggal di MainActivity")
print("\n".join(g) if g else "UJI TURUNKAN AUDIO LAIN: LULUS")
