from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
if "var ekorMaksMs" not in t("PemutarAudio.kt") or "ekorMaksMs / 1000L" not in t("PemutarAudio.kt"): g.append("GAGAL batas ekor gema")
if "aturEkorGema(awal, i)" not in t("PemutarQuranService.kt") or "aturEkorGema(p, i)" not in t("PemutarQuranService.kt"): g.append("GAGAL service ekor")
if "ekorMaksMs" not in t("KhatamActivity.kt"): g.append("GAGAL khatam ekor")
a=t("PerintahSuaraActivity.kt")
for k in ["TEKS_TEMA -> tampilkanTeksTema","private fun tampilkanTeksTema","setPrimaryClip","Salin semua","setOnDismissListener"]:
    if k not in a: g.append("GAGAL "+k)
print("\n".join(g) if g else "UJI FIX320: LULUS")
