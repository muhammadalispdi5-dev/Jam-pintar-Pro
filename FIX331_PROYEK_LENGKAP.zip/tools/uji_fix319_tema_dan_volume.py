#!/usr/bin/env python3
import sys
B='app/src/main/java/com/novan/bateraibicara/'
r=lambda f:open(B+f,encoding='utf-8').read()
pb,pq,ps,tq=r('Pembicara.kt'),r('PemutarQuranService.kt'),r('PerintahSuaraActivity.kt'),r('TemaQuran.kt')
g=[]
def c(n,x):
    if not x: g.append(n)
c("volume perangkat tidak diubah Pembicara","setStreamVolume" not in pb and "turunkanDeringNotifikasi" not in pb)
c("pendengar fokus tetap ada","pendengarFokus" in pb)
c("tema quran","object TemaQuran" in tq and "fun deteksi" in tq and len(tq)>3000)
c("parser tema","TemaQuran.deteksi(tokens)" in pq and "val tema: String?" in pq)
c("pemutaran tema","p.tema != null" in pq and "cariAyatTema" in pq)
c("hadis tema","HADITS_TEMA" in ps and "private fun bacakanHaditsTema" in ps and "cariNomorDariTeks" in ps)
if g: print("UJI FIX319: GAGAL"); [print("-",x) for x in g]; sys.exit(1)
print("UJI FIX319: ok")
