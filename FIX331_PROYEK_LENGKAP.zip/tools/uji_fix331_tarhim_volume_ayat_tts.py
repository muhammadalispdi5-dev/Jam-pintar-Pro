import sys
b='app/src/main/java/com/novan/bateraibicara/'
def r(n): return open(b+n).read()
g=0
def cek(n,c):
    global g
    print(("OK   " if c else "GAGAL ")+n); g+=(not c)
cek("tarhim otomatis",'durasiTarhimMs' in r('PrayerAlarm.kt') and 'tarhimMenit(name: String): Int = sp.getInt("tarhim_menit_" + name, 0)' in r('PrayerPrefs.kt'))
cek("tarhim tidak dipotong pengingat",'tarhim_hingga' in r('PrayerAlarmReceiver.kt') and 'tarhim_hingga' in r('PrayerAlarmService.kt'))
t=r('TombolSuaraAccessibilityService.kt')
cek("volume bungkam sebelum gerbang saklar",t.index('bungkamDariTombolVolume')<t.index('"enabled", false'))
cek("perintah ayat tts",'pisahPerintah' in r('PemutarQuranService.kt') and 'terjemahTtsPaksa' in r('PemutarQuranService.kt') and 'pastikanTersedia' in r('TerjemahTts.kt'))
sys.exit(0)
