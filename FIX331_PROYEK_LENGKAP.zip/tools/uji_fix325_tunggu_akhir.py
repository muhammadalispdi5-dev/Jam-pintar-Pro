from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
s=(R/"PemutarAudio.kt").read_text(encoding="utf-8")
g=[]
if "tunggu < 400" in s: g.append("GAGAL tunggu 10 detik masih ada")
if "batasMs" not in s or "mulaiTunggu" not in s: g.append("GAGAL batas tunggu")
print("\n".join(g) if g else "UJI FIX325: LULUS")
