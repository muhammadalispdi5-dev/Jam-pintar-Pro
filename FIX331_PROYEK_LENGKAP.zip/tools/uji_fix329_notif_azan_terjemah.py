import sys,os
b='app/src/main/java/com/novan/bateraibicara/'
def r(n): return open(b+n).read()
g=0
def cek(n,c):
    global g
    print(("OK   " if c else "GAGAL ")+n); g+=(not c)
cek("notif hitung mundur hanya bila pengingat aktif",'pp.advanceReminder(k)' in r('JadwalNotifikasi.kt'))
cek("azan tepat waktu",'tepat - kini > 90_000L' in r('PrayerAlarmReceiver.kt'))
d=r('DndAzan.kt')
cek("dnd hanya alarm",'val kat = NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS' in d and 'priorityCategories or' not in d)
cek("azan lama",os.path.exists('app/src/main/res/raw/azan_biasa_lama.mp3') and os.path.exists('app/src/main/res/raw/azan_subuh_lama.mp3') and 'azan_subuh_lama' in r('PrayerAlarmService.kt') and 'azanBawaan' in r('PrayerSettingsActivity.kt'))
cek("terjemah tts layanan",'terjemahAyatSaatIni' in r('PemutarQuranService.kt') and 'bacaTerjemah' in r('PemutarQuranService.kt'))
cek("terjemah tts khatam",'terjemahKhUntukAyat' in r('KhatamActivity.kt') and 'penyelesai@' in r('KhatamActivity.kt'))
cek("halaman terjemah",'TerjemahSuaraActivity' in open('app/src/main/AndroidManifest.xml').read())
sys.exit(0)
