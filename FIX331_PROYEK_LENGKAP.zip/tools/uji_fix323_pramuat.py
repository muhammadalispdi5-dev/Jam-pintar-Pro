from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
s=(R/"PemutarQuranService.kt").read_text(encoding="utf-8")
g=[]
a=s.index("private fun pramuatBerikut"); b=s.index("private fun aturEkorGema")
f=s[a:b]
if 'startsWith("http://")' in f: g.append("GAGAL pramuat masih hanya internet")
if "keluaran_suara_audio" not in f or "mono2" not in f: g.append("GAGAL pramuat mono")
print("\n".join(g) if g else "UJI FIX323: LULUS")
