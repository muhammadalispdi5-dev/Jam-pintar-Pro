package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** FIX103: notifikasi harian "ayat hafalan perlu diulang"; tidak muncul bila tidak ada ayat jatuh tempo. */
class HafalanSrsReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent?) {
        // FIX328: saklar utama mati = semua fitur latar tidak berfungsi.
        if (!Prefs(context).enabled) return
        val prefs = HafalanSrs.prefs(context)
        if (!prefs.getBoolean(HafalanSrs.KEY_PENGINGAT, false)) return
        val hari = HafalanSrs.hariIni()
        val due = HafalanSrs.jatuhTempo(prefs, hari)
        if (due.isEmpty()) return
        val english = BahasaAplikasi.tampilan(context) == 1
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val suara = SuaraPengingat.siapkan(
            context, "khatam_hafalan_srs",
            if (english) "Memorization review reminder" else "Pengingat ulasan hafalan",
            prefs, "hafalan_srs_suara"
        )
        val buka = Intent(context, KhatamActivity::class.java).putExtra(HafalanSrs.EXTRA_BUKA_ULASAN, true)
        val open = PendingIntent.getActivity(context, 6912, buka, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val daftar = due.take(3).joinToString(", ") { HafalanSrs.namaSurah(it.surah) + (if (english) " verse " else " ayat ") + it.ayat }
        val sisa = due.size - 3
        val terlambatMaks = due.maxOf { it.terlambat(hari) }
        val judul = if (english) "Time to review your memorization" else "Saatnya mengulas hafalan"
        var isi = if (english) ("" + (due.size) + " verse(s) to review: " + (daftar)) + (if (sisa > 0) (" and " + (sisa) + " more") else "")
            else ("" + (due.size) + " ayat perlu diulang: " + (daftar)) + (if (sisa > 0) (" dan " + (sisa) + " lainnya") else "")
        if (terlambatMaks >= 3) isi += if (english) (". Some are " + (terlambatMaks) + " days overdue.") else (". Ada yang tertunda " + (terlambatMaks) + " hari.")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, suara.channelId) else Notification.Builder(context)
        builder
            .setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(judul)
            .setContentText(isi)
            .setStyle(Notification.BigTextStyle().bigText(isi))
            .setContentIntent(open)
            .setAutoCancel(true)
        SuaraPengingat.aturSuara(builder, suara)
        val notification = builder.build()
        try { manager.notify(6913, notification) } catch (_: SecurityException) { }
        if (suara.gunakanTts && manager.areNotificationsEnabled() &&
            (Build.VERSION.SDK_INT < 26 || manager.getNotificationChannel(suara.channelId)?.importance != NotificationManager.IMPORTANCE_NONE)) {
            val pending = goAsync()
            SuaraPengingat.ucapkan(context,
                if (english) "It is time to review your Qur'an memorization. Some verses are ready to be reviewed."
                else "Saatnya mengulang hafalan Al-Qur'an. Ada ayat yang perlu ditinjau kembali.", english
            ) { pending.finish() }
        }
        // FIX124: bunyi notifikasi ini dapat dihentikan dengan tombol volume atau telungkup, seperti notifikasi aplikasi lainnya.
        PembungkamTelungkup.mulai(context, "hafalan_srs_notif", 20_000L) { try { manager.cancel(6913) } catch (_: Exception) { } }
    }
}
