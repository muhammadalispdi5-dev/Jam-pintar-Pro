package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {

    /**
     * FIX327: satu pengingat/azan hanya dibunyikan sekali dalam 20 menit. Sebagian perangkat mengirim alarm yang sama beberapa detik lebih
     * awal lalu penjadwalan ulang menembakkan waktu yang sama sekali lagi, sehingga azan terdengar dua kali.
     */
    private fun sudahDipicu(context: Context, jenis: String): Boolean {
        val sp = context.getSharedPreferences("pengingat_sekali", Context.MODE_PRIVATE)
        val kini = System.currentTimeMillis()
        if (kini - sp.getLong("terpicu_" + jenis, 0L) in 0 until 20 * 60_000L) return true
        sp.edit().putLong("terpicu_" + jenis, kini).commit()
        return false
    }
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action.orEmpty()
        val pp = PrayerPrefs(context)
        if (action == "com.novan.jambicarapro.RESTORE_PRAYER_DND") {
            val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
            val until = state.getLong("prayer_dnd_active_until", 0L)
            if (until > System.currentTimeMillis()) {
                // Alarm lama mungkin terpanggil setelah durasi diperpanjang oleh salat berikutnya.
                PrayerAlarm.scheduleDndRestore(context, until)
            } else {
                PrayerAlarm.restoreExpiredDnd(context)
            }
            // scheduleAll harus mempertahankan alarm retry pemulihan yang masih diperlukan.
            PrayerAlarm.scheduleAll(context)
            return
        }
        // FIX328: saklar utama mati = semua fitur latar tidak berfungsi.
        if (!Prefs(context).enabled) return
        if (action == JadwalNotifikasi.AKSI_PERBARUI) { PrayerAlarm.scheduleAll(context); return }
        val key = intent.getStringExtra("prayer_key") ?: return
        if (intent.getBooleanExtra("berbuka_reminder", false)) {
            if (pp.enabled && pp.locationSet && pp.berbukaReminderEnabled && FastingSchedule.isFastingDay(context, java.time.LocalDate.now(), pp) && !sudahDipicu(context, "berbuka")) {
                val service = Intent(context, PrayerAlarmService::class.java)
                    .putExtra("prayer_key", "berbuka")
                    .putExtra("berbuka_reminder", true)
                    .putExtra("berbuka_offset", pp.berbukaOffsetMinutes)
                try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        if (intent.getBooleanExtra("sahur_reminder", false)) {
            if (pp.enabled && pp.locationSet && pp.sahurReminderEnabled && FastingSchedule.isFastingDay(context, java.time.LocalDate.now(), pp) && !sudahDipicu(context, "sahur")) {
                val service = Intent(context, PrayerAlarmService::class.java)
                    .putExtra("prayer_key", "sahur")
                    .putExtra("sahur_reminder", true)
                    .putExtra("sahur_minutes", pp.sahurReminderMinutes)
                try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        if (action == "com.novan.jambicarapro.START_PRAYER_DND") {
            if (pp.dndEnabled && pp.locationSet && pp.dndPrayer(key) && android.os.Build.VERSION.SDK_INT >= 23) {
                val nm = context.getSystemService(android.app.NotificationManager::class.java)
                if (nm.isNotificationPolicyAccessGranted) {
                    val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
                    val now = System.currentTimeMillis()
                    val oldUntil = state.getLong("prayer_dnd_active_until", 0L)
                    val savedPrevious = state.getInt("prayer_dnd_previous_filter", android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
                    val current = nm.currentInterruptionFilter
                    // Hindari menyimpan ALARMS sebagai keadaan awal jika pemulihan sebelumnya terlewat.
                    val previous = when {
                        oldUntil > now -> savedPrevious
                        current == android.app.NotificationManager.INTERRUPTION_FILTER_ALARMS && state.contains("prayer_dnd_previous_filter") ->
                            if (savedPrevious == android.app.NotificationManager.INTERRUPTION_FILTER_ALARMS) android.app.NotificationManager.INTERRUPTION_FILTER_ALL else savedPrevious
                        else -> current
                    }
                    val until = now + pp.dndDuration * 60_000L
                    // Simpan filter asal dan batas waktu secara atomik sebelum mengubah DND.
                    state.edit().putInt("prayer_dnd_previous_filter", previous)
                        .putLong("prayer_dnd_active_until", until).commit()
                    DndAzan.pasangFilterRamahAzan(context, nm)
                    // Jadwalkan pemulihan langsung dari receiver agar tidak bergantung pada
                    // penjadwalan ulang alarm salat/pengingat yang lain.
                    PrayerAlarm.scheduleDndRestore(context, until)
                }
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        val advance = intent.getBooleanExtra("advance_reminder", false)
        val tarhim = intent.getBooleanExtra("tarhim_reminder", false)
        val iqomah = intent.getBooleanExtra("iqomah_reminder", false)
        val allowed = if (iqomah) pp.iqomahAktif(key) else if (tarhim) pp.tarhimAktif(key) else if (advance) pp.advanceReminder(key) else pp.reminder(key)
        val fastingDayAllowed = key != "imsak" || FastingSchedule.isFastingDay(context, java.time.LocalDate.now(), pp)
        // FIX329: azan harus tepat waktunya. Bila sistem mengirim alarm azan lebih dari 90 detik sebelum waktu salat hari ini, abaikan
        // dan jadwalkan ulang; alarm yang tepat waktu tetap berbunyi sekali.
        if (!advance && !tarhim && !iqomah && key in setOf("subuh", "dzuhur", "ashar", "maghrib", "isya")) {
            try {
                val menitHariIni = PrayerAlarm.prayerMinutes(context, pp, java.time.LocalDate.now(), key)
                val tepat = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, menitHariIni / 60); set(java.util.Calendar.MINUTE, menitHariIni % 60)
                    set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
                }.timeInMillis
                val kini = System.currentTimeMillis()
                if (tepat - kini > 90_000L && tepat - kini < 6 * 3_600_000L) { PrayerAlarm.scheduleAll(context); return }
            } catch (_: Exception) { }
        }
        // FIX330: pengingat sebelum salat tidak boleh memotong Tarhim yang sedang diputar (sebelumnya terpotong bila menitnya sama).
        if (advance && context.getSharedPreferences("pengingat_sekali", Context.MODE_PRIVATE).getLong("tarhim_hingga", 0L) > System.currentTimeMillis()) return
        val jenisPicu = if (tarhim) "tarhim_" + key else if (advance) "advance_" + key else "azan_" + key
        if (pp.enabled && allowed && fastingDayAllowed && (iqomah || !sudahDipicu(context, jenisPicu))) {
            val service = Intent(context, PrayerAlarmService::class.java)
                .putExtra("prayer_key", key)
                .putExtra("advance_reminder", advance)
                .putExtra("tarhim_reminder", tarhim)
                .putExtra("iqomah_reminder", iqomah)
            try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
        }
        PrayerAlarm.scheduleAll(context)
    }
}
