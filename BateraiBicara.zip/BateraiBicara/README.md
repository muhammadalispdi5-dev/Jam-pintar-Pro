# Baterai Jam Nama Pemanggil

Aplikasi Android berbahasa Indonesia, **tanpa internet** (tidak ada izin INTERNET). Semua suara memakai mesin
Text-to-Speech yang terpasang di HP; tiap kategori bisa memilih mesin suaranya sendiri.

## Kategori di halaman utama
- **Baterai** – tampilan baterai (persen, bar, suhu, tegangan); persen disebut setiap 5/10/20/25%,
  dapat dipilih *hanya saat mengisi daya* atau *selalu*; peringatan lemah/kritis/penuh; ucapan charger & USB.
- **Jam** – jam bicara tepat waktu: setiap jam atau setiap 5–30 menit, jam mulai–selesai, hari aktif,
  format 24 jam atau 12 jam (pagi/siang/sore/malam), sebut menit, kata pembuka, mesin suara sendiri.
- **Nama pemanggil** – mengumumkan panggilan WhatsApp (suara & video) dan telepon seluler beserta nama
  penelepon, diulang selama berdering (jeda bawaan 1,5 detik, bisa diubah; batas ulang opsional), berhenti
  otomatis saat dijawab/ditolak. Mesin suara, kecepatan, nada, dan keluaran volume sendiri.

## Berjalan terus di latar belakang
Layanan foreground + alarm tepat waktu + wake lock, aktif otomatis setelah HP dihidupkan ulang.
Nama pemanggil memakai *Akses notifikasi* (dijalankan sistem sendiri setelah restart).

## Cara membangun lewat GitHub Actions
1. Buat repositori GitHub, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Tab **Actions** → **Bangun APK** → **Run workflow** (atau push ke `main`).
3. Unduh artefak **BateraiBicara-APK** (`app-release.apk`).

APK ditandatangani otomatis dengan kunci yang dibuat saat build. Untuk kunci tetap isi secret repo:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Izin yang perlu diberikan di HP
1. Notifikasi (Android 13+), 2. Akses notifikasi (untuk nama pemanggil), 3. Status telepon (opsional),
4. Izinkan berjalan di latar belakang + Mulai otomatis (OPPO/ColorOS). Semua ada tombolnya di aplikasi.
