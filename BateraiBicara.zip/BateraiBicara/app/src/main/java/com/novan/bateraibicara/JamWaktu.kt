package com.novan.bateraibicara

import java.util.Calendar

/** Penyusun kalimat jam (bahasa Indonesia) dan penghitung jadwal berikutnya. */
object JamWaktu {

    private val SATUAN = arrayOf(
        "nol", "satu", "dua", "tiga", "empat", "lima",
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"
    )

    fun kata(n: Int): String = when {
        n < 12 -> SATUAN[n]
        n < 20 -> SATUAN[n - 10] + " belas"
        n < 100 -> {
            val s = n % 10
            SATUAN[n / 10] + " puluh" + if (s > 0) " " + SATUAN[s] else ""
        }
        else -> n.toString()
    }

    private fun bagianHari(h: Int) = when (h) {
        in 4..10 -> "pagi"
        in 11..14 -> "siang"
        in 15..17 -> "sore"
        else -> "malam"
    }

    fun ucapan(p: Prefs, c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val duabelas = p.jamFormat == 1
        val jam = if (duabelas) (if (h % 12 == 0) 12 else h % 12) else h
        val sb = StringBuilder(p.jamAwalan.trim())
        sb.append(' ').append(kata(jam))
        if (m == 0) {
            sb.append(" tepat")
        } else if (p.jamSebutMenit) {
            sb.append(" lewat ").append(kata(m)).append(" menit")
        }
        if (duabelas) sb.append(' ').append(bagianHari(h))
        return sb.toString()
    }

    /** "06.30" */
    fun format(menit: Int): String = "%02d.%02d".format(menit / 60, menit % 60)

    private val NAMA_HARI = arrayOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")

    fun ringkasHari(mask: Int): String {
        if ((mask and 127) == 127) return "Setiap hari"
        if ((mask and 127) == 0) return "Tidak ada"
        // Urutan tampil Senin..Minggu
        return listOf(1, 2, 3, 4, 5, 6, 0).filter { (mask and (1 shl it)) != 0 }
            .joinToString(", ") { NAMA_HARI[it] }
    }

    /** Waktu (ms) jadwal pertama yang lebih besar dari [setelah], atau null bila tidak ada hari aktif. */
    fun berikut(p: Prefs, setelah: Long): Long? {
        val mulai = p.jamMulai
        val selesai = p.jamSelesai
        val panjang = when {
            selesai > mulai -> selesai - mulai
            selesai < mulai -> selesai + 1440 - mulai
            else -> 0
        }
        val langkah = if (p.jamMode == 0) 60 else p.jamInterval
        val awal = if (p.jamMode == 0) (60 - mulai % 60) % 60 else 0
        if (p.jamHari == 0) return null

        for (d in -1..8) {
            val dasar = Calendar.getInstance()
            dasar.timeInMillis = setelah
            dasar.set(Calendar.HOUR_OF_DAY, 0)
            dasar.set(Calendar.MINUTE, 0)
            dasar.set(Calendar.SECOND, 0)
            dasar.set(Calendar.MILLISECOND, 0)
            dasar.add(Calendar.DAY_OF_YEAR, d)
            val hari = dasar.get(Calendar.DAY_OF_WEEK) - 1
            if ((p.jamHari and (1 shl hari)) == 0) continue
            var off = awal
            while (off <= panjang) {
                val t = dasar.clone() as Calendar
                t.add(Calendar.MINUTE, mulai + off)
                if (t.timeInMillis > setelah) return t.timeInMillis
                off += langkah
            }
        }
        return null
    }
}
