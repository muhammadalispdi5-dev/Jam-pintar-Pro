package com.novan.bateraibicara

import android.Manifest
import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Membaca notifikasi panggilan masuk (WhatsApp & aplikasi telepon) lalu mengucapkan nama
 * pemanggil berulang-ulang sampai panggilan dijawab, ditolak, atau berhenti berdering.
 * Dijalankan sistem secara otomatis (termasuk setelah HP dihidupkan ulang) selama
 * "Akses notifikasi" diizinkan.
 */
class CallerListener : NotificationListenerService() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var pembicara: Pembicara? = null

    private var berdering = false
    private var sumber = SUMBER_WA
    private var teks = ""
    private var ulang = 0
    private val kunciAktif = HashSet<String>()
    private var namaAktif = ""

    private var telCallback: Any? = null
    private var telListener: PhoneStateListener? = null

    private val ulangRunnable = Runnable { ucapUlang() }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (prefs.enabled && prefs.pemOn) siapkanPembicara()
        daftarTelepon()
    }

    override fun onListenerDisconnected() {
        hentikan()
        lepasTelepon()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        hentikan()
        lepasTelepon()
        pembicara?.matikan()
        pembicara = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try { proses(sbn) } catch (e: Exception) { }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null || !berdering) return
        if (kunciAktif.remove(sbn.key) && kunciAktif.isEmpty()) hentikan()
    }

    // ---------- Deteksi panggilan ----------

    private fun proses(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val wa = pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
        if (!wa && !PAKET_TELEPON.containsMatchIn(pkg)) return

        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val tipe = if (extras.containsKey("android.callType")) extras.getInt("android.callType") else -1
        if (n.category != Notification.CATEGORY_CALL && tipe <= 0) return

        val aktifSaja = prefs.enabled && prefs.pemOn && (if (wa) prefs.pemWa else prefs.pemTelp)
        val masuk = aktifSaja && apakahMasuk(n, extras, tipe)

        if (!masuk) {
            // Panggilan yang sedang diumumkan berubah menjadi berlangsung / selesai: berhenti.
            if (berdering && kunciAktif.contains(sbn.key)) hentikan()
            return
        }

        val nama = namaPemanggil(extras)
        if (berdering) {
            if (sumber == (if (wa) SUMBER_WA else SUMBER_TELP) && nama == namaAktif) {
                kunciAktif.add(sbn.key) // notifikasi tambahan untuk panggilan yang sama
                return
            }
            hentikan()
        }

        val gabung = gabungTeks(n, extras)
        val video = wa && gabung.contains("video")
        mulai(sbn.key, if (wa) SUMBER_WA else SUMBER_TELP, video, nama)
    }

    private fun apakahMasuk(n: Notification, e: Bundle, tipe: Int): Boolean {
        if (tipe > 0) return tipe == 1 // 1 = masuk, 2 = berlangsung, 3 = disaring
        if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) return false
        val t = gabungTeks(n, e)
        if (KATA_SELESAI.containsMatchIn(t)) return false
        if (KATA_MASUK.containsMatchIn(t)) return true
        return n.fullScreenIntent != null
    }

    private fun gabungTeks(n: Notification, e: Bundle): String {
        val daftar = listOf(
            Notification.EXTRA_TEXT, Notification.EXTRA_SUB_TEXT,
            Notification.EXTRA_BIG_TEXT, Notification.EXTRA_INFO_TEXT
        ).mapNotNull { e.getCharSequence(it)?.toString() }
        return (daftar + listOfNotNull(n.tickerText?.toString())).joinToString(" ").lowercase()
    }

    @Suppress("DEPRECATION")
    private fun namaPemanggil(e: Bundle): String {
        var nama = ""
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val p = if (Build.VERSION.SDK_INT >= 33) {
                    e.getParcelable("android.callPerson", android.app.Person::class.java)
                } else {
                    e.getParcelable<android.app.Person>("android.callPerson")
                }
                nama = p?.name?.toString().orEmpty()
            } catch (ex: Exception) { }
        }
        if (nama.isBlank()) nama = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        return nama.trim()
    }

    // ---------- Pengumuman berulang ----------

    private fun siapkanPembicara(): Pembicara {
        val s = prefs.suara("pem")
        val ada = pembicara
        if (ada != null && ada.tanda == s.tanda()) return ada
        ada?.matikan()
        val baru = Pembicara(this, s)
        pembicara = baru
        return baru
    }

    private fun mulai(kunci: String, jenisSumber: Int, video: Boolean, nama: String) {
        berdering = true
        sumber = jenisSumber
        namaAktif = nama
        kunciAktif.clear()
        kunciAktif.add(kunci)
        ulang = 0
        teks = susun(this, prefs, jenisSumber == SUMBER_WA, video, nama)
        ucapUlang()
    }

    private fun ucapUlang() {
        if (!berdering) return
        val batas = prefs.pemBatas
        if (batas > 0 && ulang >= batas) {
            hentikan()
            return
        }
        ulang++
        siapkanPembicara().ucapkan(teks, ulang == 1) {
            if (berdering) {
                handler.postDelayed(ulangRunnable, (prefs.pemJeda * 1000).toLong())
            }
        }
    }

    private fun hentikan() {
        berdering = false
        handler.removeCallbacks(ulangRunnable)
        kunciAktif.clear()
        pembicara?.berhenti()
    }

    // ---------- Status telepon seluler (untuk berhenti saat diangkat/ditolak) ----------

    private fun statusTelepon(state: Int) {
        if (berdering && sumber == SUMBER_TELP && state != TelephonyManager.CALL_STATE_RINGING) {
            hentikan()
        }
    }

    private fun daftarTelepon() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        lepasTelepon()
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handler.post { statusTelepon(state) }
                    }
                }
                tm.registerTelephonyCallback(mainExecutor, cb)
                telCallback = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        statusTelepon(state)
                    }
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                telListener = l
            }
        } catch (e: Exception) { }
    }

    private fun lepasTelepon() {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val cb = telCallback
            if (Build.VERSION.SDK_INT >= 31 && cb is TelephonyCallback) {
                tm.unregisterTelephonyCallback(cb)
            }
            telListener?.let {
                @Suppress("DEPRECATION")
                tm.listen(it, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) { }
        telCallback = null
        telListener = null
    }

    companion object {
        private const val SUMBER_WA = 1
        private const val SUMBER_TELP = 2

        private val PAKET_TELEPON =
            Regex("dialer|incall|telecom|phone|oplus|coloros|oppo|miui|contacts")
        private val KATA_MASUK = Regex("incoming|masuk|ringing|berdering")
        private val KATA_SELESAI = Regex(
            "ongoing|berlangsung|connected|tersambung|in call|dalam panggilan|missed|" +
                "tak terjawab|tidak terjawab|terlewat|ended|berakhir|declin|ditolak"
        )

        /** Nomor tanpa nama dibaca angka per angka. */
        private fun bacaNama(nama: String): String {
            if (nama.isBlank()) return ""
            if (nama.none { it.isLetter() } && nama.count { it.isDigit() } >= 5) {
                return nama.filter { it.isDigit() }.toCharArray().joinToString(" ")
            }
            return nama
        }

        /** Kalimat yang diucapkan untuk satu panggilan. Dipakai juga oleh tombol tes. */
        fun susun(ctx: Context, p: Prefs, wa: Boolean, video: Boolean, nama: String): String {
            val n = bacaNama(nama).ifEmpty { ctx.getString(R.string.nama_tidak_dikenal) }
            val kalimat = when {
                wa && video -> p.pemKalimatWaVideo
                wa -> p.pemKalimatWaSuara
                else -> p.pemKalimatTelp
            }
            return kalimat.replace("{nama}", n)
        }
    }
}
