package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("pengaturan", Context.MODE_PRIVATE)

    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun idx(k: String, d: Int, max: Int) = sp.getInt(k, d).coerceIn(0, max - 1)
    private fun putInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    // ---------- Umum ----------
    var enabled: Boolean
        get() = bool("enabled", true)
        set(v) = putBool("enabled", v)

    var bootOn: Boolean
        get() = bool("boot", true)
        set(v) = putBool("boot", v)

    // ---------- Profil suara: "bat" (baterai), "jam", "pem" (pemanggil) ----------
    fun suara(profil: String) = Suara(profil)

    inner class Suara(private val p: String) {
        // Profil baterai memakai kunci lama agar pengaturan lama tetap terbaca.
        private fun k(n: String) = if (p == "bat") n else "${p}_$n"

        /** Nama paket mesin suara; kosong = mesin bawaan sistem. */
        var engine: String
            get() = sp.getString(k("engine"), "") ?: ""
            set(v) = sp.edit().putString(k("engine"), v).apply()

        var rateIdx: Int
            get() = idx(k("rate"), 2, RATES.size)
            set(v) = putInt(k("rate"), v)

        var pitchIdx: Int
            get() = idx(k("pitch"), 2, PITCHES.size)
            set(v) = putInt(k("pitch"), v)

        /** 0 = Media, 1 = Alarm, 2 = Notifikasi, 3 = Dering */
        var streamIdx: Int
            get() = idx(k("stream"), if (p == "pem") 1 else 0, 4)
            set(v) = putInt(k("stream"), v)

        val rate: Float get() = RATES[rateIdx]
        val pitch: Float get() = PITCHES[pitchIdx]

        fun tanda() = "$p|$engine|$rateIdx|$pitchIdx|$streamIdx"

        fun audioAttributes(): AudioAttributes {
            val usage = when (streamIdx) {
                1 -> AudioAttributes.USAGE_ALARM
                2 -> AudioAttributes.USAGE_NOTIFICATION
                3 -> AudioAttributes.USAGE_NOTIFICATION_RINGTONE
                else -> AudioAttributes.USAGE_MEDIA
            }
            return AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        }

        fun streamType(): Int = when (streamIdx) {
            1 -> AudioManager.STREAM_ALARM
            2 -> AudioManager.STREAM_NOTIFICATION
            3 -> AudioManager.STREAM_RING
            else -> AudioManager.STREAM_MUSIC
        }
    }

    // ---------- Baterai ----------
    var bateraiOn: Boolean
        get() = bool("baterai_on", true)
        set(v) = putBool("baterai_on", v)

    var stepIdx: Int
        get() = idx("step", 1, STEPS.size)
        set(v) = putInt("step", v)

    /** 0 = persen disebut hanya saat mengisi daya, 1 = selalu */
    var levelMode: Int
        get() = idx("level_mode", 1, 2)
        set(v) = putInt("level_mode", v)

    var lowIdx: Int
        get() = idx("low", 1, LOWS.size)
        set(v) = putInt("low", v)

    var lemahOn: Boolean
        get() = bool("lemah", true)
        set(v) = putBool("lemah", v)

    var kritisOn: Boolean
        get() = bool("kritis", true)
        set(v) = putBool("kritis", v)

    var penuhOn: Boolean
        get() = bool("penuh", true)
        set(v) = putBool("penuh", v)

    var chargerOn: Boolean
        get() = bool("charger", true)
        set(v) = putBool("charger", v)

    var usbOn: Boolean
        get() = bool("usb", true)
        set(v) = putBool("usb", v)

    val lowThreshold: Int get() = LOWS[lowIdx]
    val step: Int get() = STEPS[stepIdx]

    // ---------- Jam ----------
    var jamOn: Boolean
        get() = bool("jam_on", false)
        set(v) = putBool("jam_on", v)

    /** 0 = setiap jam tepat, 1 = setiap beberapa menit */
    var jamMode: Int
        get() = idx("jam_mode", 0, 2)
        set(v) = putInt("jam_mode", v)

    var jamIntervalIdx: Int
        get() = idx("jam_interval", 4, JAM_INTERVALS.size)
        set(v) = putInt("jam_interval", v)

    val jamInterval: Int get() = JAM_INTERVALS[jamIntervalIdx]

    /** Menit sejak pukul 00.00 */
    var jamMulai: Int
        get() = sp.getInt("jam_mulai", 6 * 60).coerceIn(0, 1439)
        set(v) = putInt("jam_mulai", v)

    var jamSelesai: Int
        get() = sp.getInt("jam_selesai", 22 * 60).coerceIn(0, 1439)
        set(v) = putInt("jam_selesai", v)

    /** Bit 0 = Minggu, bit 1 = Senin, ... bit 6 = Sabtu */
    var jamHari: Int
        get() = sp.getInt("jam_hari", 127) and 127
        set(v) = putInt("jam_hari", v and 127)

    /** 0 = 24 jam, 1 = 12 jam (pagi/siang/sore/malam) */
    var jamFormat: Int
        get() = idx("jam_format", 1, 2)
        set(v) = putInt("jam_format", v)

    var jamSebutMenit: Boolean
        get() = bool("jam_menit", true)
        set(v) = putBool("jam_menit", v)

    var jamAwalan: String
        get() = sp.getString("jam_awalan", null)?.takeIf { it.isNotBlank() } ?: "Sekarang pukul"
        set(v) = sp.edit().putString("jam_awalan", v).apply()

    // ---------- Nama pemanggil ----------
    var pemOn: Boolean
        get() = bool("pem_on", true)
        set(v) = putBool("pem_on", v)

    var pemWa: Boolean
        get() = bool("pem_wa", true)
        set(v) = putBool("pem_wa", v)

    var pemTelp: Boolean
        get() = bool("pem_telp", true)
        set(v) = putBool("pem_telp", v)

    /** Kalimat yang diucapkan; {nama} diganti nama pemanggil. */
    var pemKalimatWaSuara: String
        get() = sp.getString("pem_k_wa_suara", null)?.takeIf { it.isNotBlank() } ?: DEF_WA_SUARA
        set(v) = sp.edit().putString("pem_k_wa_suara", v).apply()

    var pemKalimatWaVideo: String
        get() = sp.getString("pem_k_wa_video", null)?.takeIf { it.isNotBlank() } ?: DEF_WA_VIDEO
        set(v) = sp.edit().putString("pem_k_wa_video", v).apply()

    var pemKalimatTelp: String
        get() = sp.getString("pem_k_telp", null)?.takeIf { it.isNotBlank() } ?: DEF_TELP
        set(v) = sp.edit().putString("pem_k_telp", v).apply()

    /** Jeda antar pengulangan, dalam detik. */
    var pemJeda: Float
        get() = sp.getFloat("pem_jeda", 1.5f).coerceIn(0.3f, 60f)
        set(v) = sp.edit().putFloat("pem_jeda", v).apply()

    var pemBatasIdx: Int
        get() = idx("pem_batas", 0, PEM_BATAS.size)
        set(v) = putInt("pem_batas", v)

    val pemBatas: Int get() = PEM_BATAS[pemBatasIdx]

    companion object {
        const val DEF_WA_SUARA = "Panggilan suara WhatsApp dari {nama}"
        const val DEF_WA_VIDEO = "Panggilan video WhatsApp dari {nama}"
        const val DEF_TELP = "Panggilan telepon dari {nama}"
        val RATES = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val PITCHES = floatArrayOf(0.6f, 0.8f, 1.0f, 1.2f, 1.4f)
        val STEPS = intArrayOf(0, 5, 10, 20, 25)
        val LOWS = intArrayOf(10, 15, 20, 30)
        val JAM_INTERVALS = intArrayOf(5, 10, 15, 20, 30)
        val PEM_BATAS = intArrayOf(0, 3, 5, 10, 20)
    }
}
