#!/usr/bin/env python3
"""Pemeriksaan statis awal proyek Jam Pintar Pro sebelum build Android."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
GRADLE = ROOT / "app/build.gradle.kts"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
ANDROID = "{http://schemas.android.com/apk/res/android}"
errors = []
notes = []

def fail(message: str) -> None:
    errors.append(message)

if not GRADLE.is_file():
    fail("app/build.gradle.kts tidak ditemukan")
if not MANIFEST.is_file():
    fail("AndroidManifest.xml tidak ditemukan")

if not errors:
    gradle_text = GRADLE.read_text(encoding="utf-8")
    for key, pattern in {
        "versionCode": r"versionCode\s*=\s*(\d+)",
        "versionName": r'versionName\s*=\s*"([^\"]+)"',
        "applicationId": r'applicationId\s*=\s*"([^\"]+)"',
        "compileSdk": r"compileSdk\s*=\s*(\d+)",
        "minSdk": r"minSdk\s*=\s*(\d+)",
        "targetSdk": r"targetSdk\s*=\s*(\d+)",
    }.items():
        if not re.search(pattern, gradle_text):
            fail(f"Konfigurasi {key} tidak ditemukan")

    values = {}
    for key, pattern in {
        "versionCode": r"versionCode\s*=\s*(\d+)",
        "versionName": r'versionName\s*=\s*"([^\"]+)"',
        "applicationId": r'applicationId\s*=\s*"([^\"]+)"',
        "compileSdk": r"compileSdk\s*=\s*(\d+)",
        "minSdk": r"minSdk\s*=\s*(\d+)",
        "targetSdk": r"targetSdk\s*=\s*(\d+)",
    }.items():
        match = re.search(pattern, gradle_text)
        if match:
            values[key] = match.group(1)

    version_name = values.get("versionName", "")
    version_code = values.get("versionCode", "")
    if not version_name or not version_code or not version_code.isdigit():
        fail("VersionName atau versionCode tidak valid")
    elif not re.fullmatch(r"\d+\.\d+\.\d+", version_name):
        fail(f"Format versionName tidak valid: {version_name}")
    if values.get("minSdk") and int(values["minSdk"]) < 1:
        fail("minSdk tidak valid")
    if values.get("targetSdk") and values.get("compileSdk") and int(values["targetSdk"]) > int(values["compileSdk"]):
        fail("targetSdk lebih tinggi daripada compileSdk")

    try:
        root = ET.parse(MANIFEST).getroot()
        app = root.find("application")
        if app is None:
            fail("Elemen application tidak ditemukan di manifest")
        else:
            components = ("activity", "service", "receiver", "provider")
            source_root = ROOT / "app/src/main/java"
            for tag in components:
                for component in app.findall(tag):
                    name = component.get(ANDROID + "name", "")
                    exported = component.get(ANDROID + "exported")
                    if not name:
                        fail(f"Komponen {tag} tidak memiliki android:name")
                        continue
                    if exported is None:
                        fail(f"Komponen {tag} {name} tidak menyatakan android:exported secara eksplisit")
                    if name.startswith("."):
                        class_name = name[1:]
                    elif "." not in name:
                        class_name = name
                    else:
                        class_name = name.rsplit(".", 1)[-1]
                    matches = list(source_root.rglob(class_name + ".kt")) + list(source_root.rglob(class_name + ".java"))
                    if not matches:
                        fail(f"Sumber kelas untuk komponen manifest {name} tidak ditemukan")
            permissions = {node.get(ANDROID + "name") for node in root.findall("uses-permission")}
            for required in ("android.permission.RECEIVE_BOOT_COMPLETED", "android.permission.SCHEDULE_EXACT_ALARM"):
                if required not in permissions:
                    fail(f"Izin penting tidak ditemukan: {required}")
    except ET.ParseError as exc:
        fail(f"AndroidManifest.xml tidak valid: {exc}")

    # Pastikan setiap kunci teks utama tersedia dalam kedua bahasa tampilan.
    id_strings = ROOT / "app/src/main/res/values/strings.xml"
    en_strings = ROOT / "app/src/main/res/values-en/strings.xml"
    try:
        id_keys = {node.get("name") for node in ET.parse(id_strings).getroot().findall("string")}
        en_keys = {node.get("name") for node in ET.parse(en_strings).getroot().findall("string")}
        for key in sorted(id_keys - en_keys):
            fail(f"Teks bahasa Inggris belum memiliki kunci string: {key}")
        for key in sorted(en_keys - id_keys):
            fail(f"Teks bahasa Indonesia belum memiliki kunci string: {key}")
    except (ET.ParseError, OSError) as exc:
        fail(f"Berkas sumber daya bahasa tidak dapat diperiksa: {exc}")

    home = ROOT / "app/src/main/java/com/novan/bateraibicara/MainActivity.kt"
    base_ui = ROOT / "app/src/main/java/com/novan/bateraibicara/Halaman.kt"
    if home.is_file() and "QiblaActivity::class.java" not in home.read_text(encoding="utf-8"):
        fail("Pintasan Arah Kiblat langsung dari beranda tidak ditemukan")
    if base_ui.is_file() and "s.setTextColor(warnaTeks())" not in base_ui.read_text(encoding="utf-8"):
        fail("Warna teks sakelar belum mengikuti tema terang/gelap")

    if not (ROOT / ".github/workflows/build.yml").is_file():
        fail("Workflow build.yml tidak ditemukan")
    if not (ROOT / ".github/workflows/rilis.yml").is_file():
        notes.append("Workflow rilis.yml tidak ditemukan; alur rilis manual tidak bisa diverifikasi")

if errors:
    print("PEMERIKSAAN PROYEK: GAGAL")
    for item in errors:
        print(f"- {item}")
    for item in notes:
        print(f"CATATAN: {item}")
    sys.exit(1)

print("PEMERIKSAAN PROYEK: LULUS")
gradle_text = GRADLE.read_text(encoding="utf-8")
version_name = re.search(r'versionName\s*=\s*"([^\"]+)"', gradle_text).group(1)
version_code = re.search(r"versionCode\s*=\s*(\d+)", gradle_text).group(1)
print(f"- Versi aplikasi {version_name} (versionCode {version_code})")
print("- Konfigurasi Gradle dan XML manifest dapat dibaca")
print("- Komponen manifest memiliki deklarasi exported dan sumber kelas ditemukan")
print("- Izin boot dan alarm tepat waktu terdeklarasi")
for item in notes:
    print(f"CATATAN: {item}")
print("Catatan: pemeriksaan ini bersifat statis, bukan pengganti kompilasi atau uji perangkat.")
