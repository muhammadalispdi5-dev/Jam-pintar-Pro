#!/usr/bin/env python3
"""Uji FIX136: sakelar Wi-Fi/Bluetooth dipilih dengan benar dan permintaan otomatis tersambung.
Bagian 1: port Python PemilihSakelar.kt diuji pada tata letak layar Pengaturan yang umum. Bagian 2: kontrak sumber Kotlin/XML.
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys, re
import xml.etree.ElementTree as ET

KATA = {"wifi": ["wi-fi", "wifi", "wi fi", "wlan"], "bluetooth": ["bluetooth"], "lokasi": ["location", "lokasi", "gps"], "hotspot": ["hotspot", "hot spot"]}
LAIN_DASAR = ["airplane", "pesawat", "mobile data", "data seluler", "hotspot", "nfc", "location", "lokasi"]
LAIN = {"lokasi": ["airplane", "pesawat", "mobile data", "data seluler", "hotspot", "nfc", "wi-fi", "wifi", "bluetooth", "scanning", "pemindaian"],
        "hotspot": ["airplane", "pesawat", "mobile data", "data seluler", "nfc", "location", "lokasi", "bluetooth", "usb", "ethernet"]}
def pilih(daftar, jenis):
    kata = KATA.get(jenis, KATA["wifi"]); lain = LAIN.get(jenis, LAIN_DASAR)
    calon = [i for i, d in enumerate(daftar) if d["cek"] and d["terlihat"] and d["aktif"]]
    if not calon: return None
    cocok = [i for i in calon if any(k in daftar[i]["konteks"] or k.replace("-", "").replace(" ", "") in daftar[i].get("id", "") for k in kata)]
    if cocok:
        for i in cocok:
            if not any(l in daftar[i]["konteks"] for l in lain): return i
        return cocok[0]
    return calon[0] if (len(calon) == 1 and jenis != "hotspot") else None

def pilih_baris(daftar):
    tolak = ["bluetooth", "usb", "ethernet"]
    calon = [i for i, d in enumerate(daftar) if not d["cek"] and d["klik"] and d["daftar"] and any(k in d["label"] for k in KATA["hotspot"]) and not any(t in d["label"] for t in tolak)]
    if not calon: return None
    for i in calon:
        if "wi-fi" in daftar[i]["label"] or "wifi" in daftar[i]["label"]: return i
    return calon[0]

def baris(label, klik=True, daftar=True, cek=False): return dict(label=label, klik=klik, daftar=daftar, cek=cek)

def sw(konteks, terlihat=True, aktif=True, id=""): return dict(cek=True, terlihat=terlihat, aktif=aktif, konteks=konteks, id=id)
def teks(): return dict(cek=False, terlihat=True, aktif=True, konteks="", id="")

gagal = []
def cek(n, k):
    if not k: gagal.append(n)

# Halaman Wi-Fi Pixel/AOSP: sakelar utama "Use Wi-Fi"
cek("Pixel Wi-Fi: sakelar utama", pilih([teks(), sw("use wi-fi use wi-fi")], "wifi") == 1)
# Halaman Wi-Fi Samsung: sakelar dengan contentDescription Wi-Fi
cek("Samsung Wi-Fi", pilih([teks(), sw("wi-fi wi-fi on")], "wifi") == 1)
# Halaman Bluetooth: sakelar utama
cek("Bluetooth: sakelar utama", pilih([teks(), sw("use bluetooth use bluetooth")], "bluetooth") == 1)
cek("Bluetooth bahasa Indonesia", pilih([sw("gunakan bluetooth gunakan bluetooth")], "bluetooth") == 0)
# Panel gabungan dengan beberapa sakelar: pilih yang menyebut Wi-Fi, bukan data seluler/pesawat
panel = [sw("mobile data data seluler"), sw("wi-fi wi-fi"), sw("airplane mode mode pesawat")]
cek("panel gabungan: Wi-Fi", pilih(panel, "wifi") == 1)
cek("panel gabungan: Bluetooth tidak ada -> tidak menekan sembarang sakelar", pilih(panel, "bluetooth") is None)
# Sakelar tersembunyi atau nonaktif tidak dipilih
cek("abaikan sakelar tersembunyi", pilih([sw("wi-fi", terlihat=False)], "wifi") is None)
cek("abaikan sakelar nonaktif", pilih([sw("wi-fi", aktif=False)], "wifi") is None)
# Satu sakelar tanpa label dipakai; beberapa tanpa label tidak ditebak
cek("sakelar tunggal tanpa label dipakai", pilih([sw("")], "wifi") == 0)
cek("beberapa sakelar tanpa label tidak ditebak", pilih([sw(""), sw("")], "wifi") is None)
# Id sumber daya membantu bila label kosong
cek("id wifi_toggle cocok", pilih([sw("", id="com.android.settings:id/wifi_toggle"), sw("")], "wifi") == 0)
# Sakelar Wi-Fi yang konteksnya juga menyebut hotspot: utamakan yang bersih
cek("utamakan sakelar tanpa perangkat lain", pilih([sw("wi-fi hotspot"), sw("wi-fi")], "wifi") == 1)

# ---- FIX137: lokasi
cek("Lokasi: sakelar utama Pixel", pilih([teks(), sw("use location use location")], "lokasi") == 1)
cek("Lokasi: bahasa Indonesia", pilih([sw("gunakan lokasi gunakan lokasi")], "lokasi") == 0)
sub = [sw("wi-fi scanning pemindaian wi-fi"), sw("bluetooth scanning"), sw("location services use location")]
cek("Lokasi: abaikan pemindaian Wi-Fi/Bluetooth", pilih(sub, "lokasi") == 2)
cek("Lokasi: hanya pemindaian -> tidak menebak", pilih([sw("wi-fi scanning"), sw("bluetooth scanning")], "lokasi") is None)
cek("Wi-Fi tetap tidak menekan sakelar lokasi", pilih([sw("location use location"), sw("wi-fi")], "wifi") == 1)
# ---- FIX137: hotspot satu langkah (Samsung) dan dua langkah (AOSP/Pixel)
cek("Hotspot satu langkah: Mobile Hotspot", pilih([sw("mobile hotspot mobile hotspot"), sw("bluetooth tethering"), sw("usb tethering")], "hotspot") == 0)
cek("Hotspot: tidak menekan Bluetooth/USB tethering", pilih([sw("bluetooth tethering"), sw("usb tethering")], "hotspot") is None)
cek("Hotspot: sakelar tunggal tanpa label tidak ditebak", pilih([sw("")], "hotspot") is None)
cek("Hotspot halaman kedua: Use Wi-Fi hotspot", pilih([teks(), sw("use wi-fi hotspot use wi-fi hotspot")], "hotspot") == 1)
cek("Hotspot Indonesia", pilih([sw("hotspot seluler hotspot seluler")], "hotspot") == 0)
rows = [baris("hotspot & tethering", klik=False, daftar=False), baris("wi-fi hotspot"), baris("bluetooth tethering"), baris("usb tethering"), baris("ethernet tethering")]
cek("Baris hotspot: pilih Wi-Fi hotspot, bukan judul/tethering lain", pilih_baris(rows) == 1)
cek("Baris hotspot Indonesia", pilih_baris([baris("penambatan bluetooth"), baris("hotspot wi-fi")]) == 1)
cek("Baris hotspot: judul di luar daftar tidak diketuk", pilih_baris([baris("hotspot & tethering", daftar=False)]) is None)
cek("Baris hotspot: sakelar tidak dianggap baris", pilih_baris([baris("mobile hotspot", cek=True)]) is None)
cek("Baris hotspot: tidak dapat diketuk", pilih_baris([baris("wi-fi hotspot", klik=False)]) is None)

# Kontrak sumber
R = Path(__file__).resolve().parents[1]
B = R / "app/src/main/java/com/novan/bateraibicara"
svc = (B / "PanggilanWhatsAppAccessibilityService.kt").read_text(encoding="utf-8")
act = (B / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
pem = (B / "PemilihSakelar.kt").read_text(encoding="utf-8")
cek("layanan menangani kontrol perangkat lebih dulu", "if (tanganiKontrolPerangkat(event)) return" in svc)
cek("layanan menekan sakelar lalu memverifikasi", "klik(node)\n        jadwalkanPerangkat(900L)" in svc and "if (sekarang == mau)" in svc)
cek("batas percobaan dan waktu", "percobaan >= 3" in svc and "BATAS_PERANGKAT_MS = 25_000L" in svc)
cek("layar pengaturan ditutup setelah berhasil", "performGlobalAction(GLOBAL_ACTION_BACK)" in svc)
cek("pengumuman mengikuti bahasa aktif", svc.count("BahasaAplikasi.bungkus(this)") >= 3)
cek("hanya bertindak pada paket Pengaturan", "paketPengaturan(" in svc)
cek("Activity menulis permintaan sebelum membuka layar", "if (dapatOtomatis) siapkanKontrolOtomatis(kontrol)\n            startActivity(intent)" in act)
cek("Activity membersihkan permintaan bila gagal membuka", "PREFS_PERANGKAT, MODE_PRIVATE).edit().clear().apply()\n            try {" in act)
cek("otomatis hanya untuk Wi-Fi, Bluetooth, lokasi, hotspot; data seluler/pesawat/NFC tetap manual",
    "val dapatOtomatis = (kontrol.jenis == PerintahSuara.JenisPerangkat.WIFI || kontrol.jenis == PerintahSuara.JenisPerangkat.BLUETOOTH ||" in act
    and "DATA_SELULER" not in act[act.index("val dapatOtomatis"):act.index("val dapatOtomatis") + 500])
cek("pemilih tidak memakai Android API", "import android" not in pem)
cek("hotspot dua langkah di layanan", "PemilihSakelar.pilihBarisHotspot(daftarBaris)" in svc and "KEY_PERANGKAT_TAHAP, 1" in svc)
cek("hotspot dua langkah menutup dua kali", "val kali = if (tahap >= 1) 2 else 1" in svc)
cek("baris hotspot hanya di dalam daftar", 'n.contains("RecyclerView")' in svc)
cek("nama perangkat lokasi/hotspot", "R.string.perintah_perangkat_lokasi" in svc and "R.string.perintah_perangkat_hotspot" in svc)
cek("Activity: lokasi dan hotspot otomatis", "JenisPerangkat.LOKASI || kontrol.jenis == PerintahSuara.JenisPerangkat.HOTSPOT) &&" in act)
cek("Activity: jenis lokasi/hotspot dan tahap dicatat", '"lokasi"' in act and '"hotspot"' in act and "KEY_PERANGKAT_TAHAP, 0" in act)
x = (R / "app/src/main/res/xml/panggilan_whatsapp_accessibility.xml").read_text(encoding="utf-8")
cek("konfigurasi: paket Pengaturan dan id tampilan", "com.android.settings" in x and "flagReportViewIds" in x and "com.whatsapp" in x)
for f in ["values", "values-en"]:
    t = (R / f"app/src/main/res/{f}/strings.xml").read_text(encoding="utf-8")
    for k in ["perintah_perangkat_otomatis", "perintah_perangkat_aksesibilitas", "perintah_perangkat_berhasil", "perintah_perangkat_sudah",
              "perintah_perangkat_status_diaktifkan", "perintah_perangkat_status_dimatikan", "perintah_perangkat_status_aktif",
              "perintah_perangkat_status_mati", "perintah_perangkat_gagal_otomatis"]:
        cek(f"{f}: {k}", f'name="{k}"' in t)
if gagal:
    print("UJI KONTROL WI-FI/BLUETOOTH/LOKASI/HOTSPOT: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI KONTROL WI-FI/BLUETOOTH/LOKASI/HOTSPOT: LULUS (port logika pemilih + kontrak sumber)")
