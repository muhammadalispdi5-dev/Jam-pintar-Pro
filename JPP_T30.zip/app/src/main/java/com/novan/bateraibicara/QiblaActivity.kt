package com.novan.bateraibicara

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.abs

/** Kompas kiblat dengan petunjuk teks, opsional pengucapan otomatis dan getar. */
class QiblaActivity : Halaman(), SensorEventListener, TextToSpeech.OnInitListener {
    override val judulHalaman = R.string.kategori_kiblat
    private val pp by lazy { PrayerPrefs(this) }
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private lateinit var status: android.widget.TextView
    private lateinit var needleView: QiblaNeedleView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var heading = 0f
    private var bearing = 0.0
    private var inZone = false
    private var lastVoice = 0L
    private var teksTerakhirMs = 0L
    private var akurasiTerakhir = -1
    private var tone: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    // Nada pendek berulang saat pengguna masih mencari arah kiblat.
    private val searchingToneLoop = object : Runnable {
        override fun run() {
            if (!getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getBoolean("qibla_background_active", false) && !inZone && pp.locationSet && rotationSensor != null) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }
                handler.postDelayed(this, 650L)
            }
        }
    }
    // Setelah arah kiblat ditemukan dan diumumkan, nada panjang berulang sebagai konfirmasi.
    private val alignmentToneLoop = object : Runnable {
        override fun run() {
            if (!getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getBoolean("qibla_background_active", false) && inZone) {
                try { tone?.startTone(ToneGenerator.TONE_DTMF_5, 2200) } catch (_: Exception) { }
                handler.postDelayed(this, 2450L)
            }
        }
    }
    private val voiceLoop = object : Runnable {
        override fun run() {
            if (!getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getBoolean("qibla_background_active", false) && pp.voiceQibla && ttsReady && pp.locationSet && rotationSensor != null) {
                val diff = selisih(bearing, heading.toDouble())
                // Jangan menimpa pengumuman konfirmasi ketika arah kiblat sudah ditemukan.
                if (abs(diff) >= 5.0) {
                    val text = ("Arah perangkat " + (arahMataAngin(heading.toDouble())) + ". Putar ke " + (if (diff > 0) "kanan" else "kiri") + " " + (abs(diff).toInt()) + " derajat menuju kiblat")
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "qibla-direction")
                    lastVoice = System.currentTimeMillis()
                }
            }
            handler.postDelayed(this, 1500L)
        }
    }

    override fun bangun() {
        bagian("Arah Kiblat")
        status = info("")
        info("Arah kiblat dihitung dari koordinat lokasi ke Ka'bah. Jarum menunjukkan arah relatif menuju kiblat. Pengaturan terpisah di Pengaturan Jadwal Sholat menentukan apakah panduan tetap berjalan ketika layar mati. Pegang HP mendatar, layar menghadap ke atas, saat memakai kompas.")
        needleView = QiblaNeedleView(this)
        needleView.contentDescription = deskripsiJarumAwal()
        needleView.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        root.addView(needleView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(230)))
        tombol("Atur lokasi pada Jadwal Sholat") { startActivity(android.content.Intent(this, PrayerActivity::class.java)) }
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        tts = TextToSpeech(this, this)
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        if (!pp.locationSet) status.text = "Lokasi belum diatur. Buka Jadwal Sholat lalu atur lokasi GPS atau manual."
        else bearing = PrayerCalc.qiblaBearing(pp.lat, pp.lon)
        if (rotationSensor == null) status.text = "Perangkat ini tidak punya sensor kompas. Gunakan arah kiblat di atas bersama kompas lain."
        else status.text = ("Arah kiblat " + ("%.0f".format(bearing)) + "° (" + (arahMataAngin(bearing)) + ") dari utara. Kompas mendukung 8 arah mata angin. Gerakkan perangkat perlahan.")
        // Sakelar di Pengaturan hanya mengizinkan kelanjutan saat layar mati; layanan baru dimulai
        // ketika pengguna benar-benar membuka halaman kompas ini.
        val bgPrefs = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (pp.locationSet && bgPrefs.getBoolean("qibla_screen_off_enabled", false)) {
            try {
                bgPrefs.edit().putBoolean("qibla_background_active", true).apply()
                val serviceIntent = Intent(this, QiblaGuidanceService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            } catch (_: Exception) {
                bgPrefs.edit().putBoolean("qibla_background_active", false).apply()
                toast("Panduan layar mati tidak dapat dimulai. Periksa izin notifikasi dan baterai.")
            }
        }
    }

    // Deskripsi jarum adalah label aksesibilitas antarmuka; ikuti bahasa tampilan,
    // terpisah dari bahasa TTS yang digunakan untuk panduan suara.
    private fun deskripsiJarumAwal(): String = if (BahasaAplikasi.tampilan(this) == 1) {
        "Qibla direction pointer. The needle indicates the relative direction to turn toward the Qibla."
    } else {
        "Jarum penunjuk arah kiblat. Jarum mengarah relatif ke arah yang perlu dituju."
    }

    private fun deskripsiJarum(diff: Double, aligned: Boolean): String {
        val derajat = abs(diff).toInt()
        return if (BahasaAplikasi.tampilan(this) == 1) {
            if (aligned) "Pointer: pointing directly toward the Qibla." else
                "Pointer: the Qibla direction is to the ${if (diff > 0) "right" else "left"}, difference $derajat degrees."
        } else {
            if (aligned) "Jarum penunjuk: tepat mengarah ke kiblat." else
                "Jarum penunjuk: arah kiblat berada di ${if (diff > 0) "kanan" else "kiri"}, selisih $derajat derajat."
        }
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        handler.removeCallbacks(voiceLoop); handler.postDelayed(voiceLoop, 1500L)
        handler.removeCallbacks(searchingToneLoop)
        if (pp.locationSet && rotationSensor != null && !inZone && !getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getBoolean("qibla_background_active", false)) handler.post(searchingToneLoop)
    }
    override fun onPause() {
        sensorManager.unregisterListener(this)
        handler.removeCallbacks(voiceLoop)
        handler.removeCallbacks(alignmentToneLoop)
        handler.removeCallbacks(searchingToneLoop)
        try { tone?.stopTone() } catch (_: Exception) { }
        inZone = false
        super.onPause()
    }
    override fun onBackPressed() {
        // Tombol Kembali selalu menghentikan layanan aktif, tetapi tidak mematikan preferensi
        // pengguna. Jika halaman kompas dibuka lagi, layanan dapat dimulai kembali bila sakelar aktif.
        hentikanLayananKompasLatar()
        super.onBackPressed()
    }
    private fun hentikanLayananKompasLatar() {
        try { stopService(Intent(this, QiblaGuidanceService::class.java)) } catch (_: Exception) { }
        getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit().putBoolean("qibla_background_active", false).apply()
    }
    override fun onDestroy() {
        if (isFinishing) hentikanLayananKompasLatar()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; handler.removeCallbacks(alignmentToneLoop); try { tone?.stopTone(); tone?.release() } catch (_: Exception) { }; tone = null; super.onDestroy()
    }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) { tts.language = Locale("id", "ID"); ttsReady = true } }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Kompas yang belum terkalibrasi memberi arah kiblat yang salah; beri tahu pengguna sekali per perubahan.
        if (accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW && accuracy != akurasiTerakhir) {
            toast("Akurasi kompas rendah. Gerakkan HP membentuk angka delapan di udara untuk mengkalibrasi.")
        }
        akurasiTerakhir = accuracy
    }
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR || !pp.locationSet) return
        val matrix = FloatArray(9); SensorManager.getRotationMatrixFromVector(matrix, event.values)
        val orientation = FloatArray(3); SensorManager.getOrientation(matrix, orientation)
        heading = ((Math.toDegrees(orientation[0].toDouble()).toFloat() + 360f) % 360f)
        bearing = PrayerCalc.qiblaBearing(pp.lat, pp.lon)
        val diff = selisih(bearing, heading.toDouble())
        val aligned = abs(diff) < 5.0
        val direction = if (aligned) {
            "Anda menghadap kiblat"
        } else {
            ("Putar ke " + (if (diff > 0) "kanan" else "kiri") + " " + (abs(diff).toInt()) + " derajat")
        }
        needleView.setRelativeDirection(diff.toFloat(), aligned)
        // Teks dan deskripsi diperbarui paling cepat sekali per detik (atau saat status tepat/tidak berubah)
        // agar TalkBack tidak dibanjiri pembaruan puluhan kali per detik.
        val sekarangMs = System.currentTimeMillis()
        val perbaruiTeks = aligned != inZone || sekarangMs - teksTerakhirMs >= 1000L
        if (perbaruiTeks) teksTerakhirMs = sekarangMs
        if (perbaruiTeks) needleView.contentDescription = deskripsiJarum(diff, aligned)
        if (perbaruiTeks) status.text = ("Arah kiblat: " + ("%.0f".format(bearing)) + "° (" + (arahMataAngin(bearing)) + ") dari utara") +
            ("\nArah perangkat: " + ("%.0f".format(heading)) + "° (" + (arahMataAngin(heading.toDouble())) + ")") +
            ("\nSelisih: " + ("%.1f".format(abs(diff))) + ("°\n" + (direction)))
        val backgroundActive = getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getBoolean("qibla_background_active", false)
        if (!backgroundActive && aligned && !inZone) {
            handler.removeCallbacks(searchingToneLoop)
            handler.removeCallbacks(alignmentToneLoop)
            try { tone?.stopTone() } catch (_: Exception) { }
            if (ttsReady) {
                tts.speak("Anda tepat di arah kiblat.", TextToSpeech.QUEUE_FLUSH, null, "qibla-aligned")
                // Beri waktu agar pengumuman selesai sebelum nada panjang dimulai.
                handler.postDelayed(alignmentToneLoop, 1400L)
            } else {
                handler.post(alignmentToneLoop)
            }
        } else if (!backgroundActive && !aligned && inZone) {
            handler.removeCallbacks(alignmentToneLoop)
            try { tone?.stopTone() } catch (_: Exception) { }
            handler.removeCallbacks(searchingToneLoop)
            handler.post(searchingToneLoop)
        }
        if (!backgroundActive && aligned && !inZone && pp.qiblaHaptic) {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE)) else v.vibrate(800)
            } catch (_: Exception) { }
        }
        inZone = aligned
    }
    /** Membagi kompas menjadi 8 arah mata angin, masing-masing 45 derajat. */
    private fun arahMataAngin(derajat: Double): String {
        val arah = arrayOf(
            "Utara", "Timur Laut", "Timur", "Tenggara",
            "Selatan", "Barat Daya", "Barat", "Barat Laut"
        )
        val normal = ((derajat % 360.0) + 360.0) % 360.0
        val indeks = (kotlin.math.floor((normal + 22.5) / 45.0).toInt()) % 8
        return arah[indeks]
    }

    private class QiblaNeedleView(context: Context) : View(context) {
        private val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; style = Paint.Style.STROKE; strokeWidth = 5f }
        private val needle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; strokeWidth = 12f; strokeCap = Paint.Cap.ROUND }
        private val center = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLUE; style = Paint.Style.FILL }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 30f; textAlign = Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        private var relative = 0f
        private var aligned = false
        fun setRelativeDirection(degrees: Float, isAligned: Boolean) { relative = degrees; aligned = isAligned; needle.color = if (isAligned) Color.rgb(0, 130, 0) else Color.RED; invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val r = (minOf(width, height) * 0.36f)
            canvas.drawCircle(cx, cy, r, circle)
            canvas.drawText("KIBLAT", cx, cy - r - 12f, textPaint)
            canvas.drawText("U", cx, cy - r + 36f, textPaint)
            canvas.save(); canvas.rotate(relative, cx, cy)
            canvas.drawLine(cx, cy + r * 0.62f, cx, cy - r * 0.72f, needle)
            val path = android.graphics.Path().apply { moveTo(cx, cy - r * 0.92f); lineTo(cx - r * 0.18f, cy - r * 0.52f); lineTo(cx + r * 0.18f, cy - r * 0.52f); close() }
            val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = needle.color; style = Paint.Style.FILL }
            canvas.drawPath(path, arrow); canvas.restore(); canvas.drawCircle(cx, cy, 11f, center)
            canvas.drawText(if (aligned) "TEPAT" else "PUTAR", cx, cy + r + 38f, textPaint)
        }
    }

    private fun selisih(target: Double, current: Double): Double = ((target - current + 540.0) % 360.0) - 180.0
}
