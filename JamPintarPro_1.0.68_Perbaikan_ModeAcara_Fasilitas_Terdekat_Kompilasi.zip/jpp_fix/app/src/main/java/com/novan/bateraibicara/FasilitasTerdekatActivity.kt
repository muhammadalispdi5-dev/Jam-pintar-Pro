package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri

/** Pencarian fasilitas terdekat lewat aplikasi peta yang dipilih pengguna. */
class FasilitasTerdekatActivity : Halaman() {
    override val judulHalaman = R.string.kategori_fasilitas_terdekat

    override fun bangun() {
        info("Pilih jenis fasilitas yang ingin dicari. Pencarian dibuka di Google Maps atau aplikasi peta yang tersedia. Internet dan izin lokasi pada aplikasi peta mungkin diperlukan agar hasil dan jarak terdekat akurat. Jam Pintar Pro tidak menyimpan lokasi Anda.")
        val pilihan = listOf(
            Triple("Masjid dan musala", "masjid dan musala terdekat", "mosques and prayer rooms near me"),
            Triple("Rumah sakit", "rumah sakit terdekat", "hospitals near me"),
            Triple("Puskesmas dan klinik", "puskesmas klinik terdekat", "health centers and clinics near me"),
            Triple("Apotek", "apotek terdekat", "pharmacies near me"),
            Triple("ATM", "ATM terdekat", "ATMs near me"),
            Triple("Bank", "bank terdekat", "banks near me"),
            Triple("Toilet umum", "toilet umum terdekat", "public toilets near me"),
            Triple("Kantor polisi", "kantor polisi terdekat", "police stations near me"),
            Triple("Pemadam kebakaran", "pemadam kebakaran terdekat", "fire stations near me"),
            Triple("SPBU", "SPBU terdekat", "gas stations near me"),
            Triple("Halte dan stasiun", "halte stasiun terdekat", "bus stops and train stations near me"),
            Triple("Pasar dan minimarket", "pasar minimarket terdekat", "markets and convenience stores near me")
        )
        val english = BahasaAplikasi.tampilan(this) == 1
        for ((label, queryId, queryEn) in pilihan) {
            tombol(label) { cari(if (english) queryEn else queryId) }
        }
    }

    private fun cari(query: String) {
        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { toast("Aplikasi peta tidak dapat dibuka.") }
    }
}
