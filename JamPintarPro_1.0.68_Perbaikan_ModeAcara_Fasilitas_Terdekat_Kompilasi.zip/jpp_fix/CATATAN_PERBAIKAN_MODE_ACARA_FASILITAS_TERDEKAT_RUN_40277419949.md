# Perbaikan Mode Acara dan Fasilitas Terdekat — Jam Pintar Pro 1.0.68

## Perubahan
- Memperbaiki penyusunan teks status pada `ModeAcaraActivity.kt` dengan menggabungkan label terjemahan dan nilai dinamis secara terpisah. Ini menghindari pola string yang rusak pada status waktu tersisa, status izin, dan cakupan Mode Acara yang dilaporkan pada GitHub Actions Run ID 40277419949.
- Menambahkan padanan bahasa Inggris untuk petunjuk, pilihan cakupan, durasi, status, izin Jangan Ganggu, dan pesan cadangan Mode Acara.
- Melengkapi terjemahan label fasilitas terdekat: masjid/musala, rumah sakit, pusat kesehatan/klinik, apotek, ATM, bank, toilet umum, kantor polisi, pemadam kebakaran, SPBU, halte/stasiun, serta pasar/minimarket.
- Ketika bahasa tampilan Inggris dipilih, pencarian Google Maps juga memakai istilah pencarian bahasa Inggris. Ketika bahasa Indonesia dipilih, istilah pencarian tetap bahasa Indonesia.
- Nama menu sumber daya Inggris `Find Nearby Public Facilities` dan `Events and Meetings Mode` tetap dipertahankan; teks isi masing-masing fitur diselaraskan dengan bahasa tampilan.
- Versi aplikasi tetap 1.0.68 / versionCode 68.

## Validasi
- Berkas `values/strings.xml` dan `values-en/strings.xml` berhasil diparsing sebagai XML.
- Pemeriksaan sintaks Kotlin dengan `kotlinc` tidak menemukan pesan kesalahan sintaks pada tiga berkas yang diubah. Kompilasi mandiri berhenti karena dependensi Android/proyek tidak disertakan dalam pemeriksaan tersebut.
- Arsip ZIP diuji setelah dibuat.
- APK penuh belum dibangun di lingkungan ini. Jalankan GitHub Actions untuk mengonfirmasi kompilasi Android lengkap.
