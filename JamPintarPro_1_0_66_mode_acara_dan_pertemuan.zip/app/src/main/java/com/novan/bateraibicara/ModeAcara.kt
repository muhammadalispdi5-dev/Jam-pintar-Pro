package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** Pengelola Mode Acara: menahan pengumuman aplikasi dan memulihkan Jangan Ganggu setelah durasi. */
object ModeAcara {
    private const val PREF = "mode_acara"
    private const val K_AKTIF = "aktif"
    private const val K_BERAKHIR = "berakhir"
    private const val K_FILTER_SEBELUM = "filter_sebelum"
    private const val K_FILTER_DIUBAH = "filter_diubah"

    fun aktif(context: Context): Boolean {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!p.getBoolean(K_AKTIF, false)) return false
        val akhir = p.getLong(K_BERAKHIR, 0L)
        if (akhir > 0L && System.currentTimeMillis() >= akhir) {
            selesai(context)
            return false
        }
        return true
    }

    fun mulai(context: Context, durasiMenit: Int): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val sudahAktif = aktif(context)
        if (!sudahAktif) {
            p.edit().putInt(K_FILTER_SEBELUM, nm.currentInterruptionFilter)
                .putBoolean(K_FILTER_DIUBAH, true).apply()
        }
        val akhir = if (durasiMenit > 0) System.currentTimeMillis() + durasiMenit * 60_000L else 0L
        p.edit().putBoolean(K_AKTIF, true).putLong(K_BERAKHIR, akhir).apply()
        try { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE) } catch (_: Exception) { }
        // Hentikan suara pengingat yang mungkin sedang berlangsung saat mode diaktifkan.
        try {
            context.startService(Intent(context, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND"))
        } catch (_: Exception) { }
        context.sendBroadcast(Intent("com.novan.jambicarapro.MODE_ACARA_DIAKTIFKAN").setPackage(context.packageName))
        jadwalkan(context, akhir)
        return true
    }

    fun selesai(context: Context) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val sebelumnya = p.getInt(K_FILTER_SEBELUM, NotificationManager.INTERRUPTION_FILTER_ALL)
        val pernahDiubah = p.getBoolean(K_FILTER_DIUBAH, false)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        p.edit().putBoolean(K_AKTIF, false).putLong(K_BERAKHIR, 0L).putBoolean(K_FILTER_DIUBAH, false).apply()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        try { am.cancel(pi) } catch (_: Exception) { }
        // Jangan menimpa perubahan yang dibuat pengguna secara manual selama acara.
        if (pernahDiubah && nm.isNotificationPolicyAccessGranted && nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_NONE) {
            try { nm.setInterruptionFilter(sebelumnya) } catch (_: Exception) { }
        }
    }

    private fun jadwalkan(context: Context, akhir: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        try { am.cancel(pi) } catch (_: Exception) { }
        if (akhir <= 0L) return
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, akhir, pi)
            else am.setExact(AlarmManager.RTC_WAKEUP, akhir, pi)
        } catch (_: Exception) {
            try { am.set(AlarmManager.RTC_WAKEUP, akhir, pi) } catch (_: Exception) { }
        }
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, 7711, Intent(context, ModeAcaraReceiver::class.java).setAction("com.novan.jambicarapro.MODE_ACARA_SELESAI"),
        PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    )
}
