package com.novan.bateraibicara

import java.util.Calendar

/** Penyusun kalimat pengumuman waktu dalam bahasa pilihan dan penghitung jadwal berikutnya. */
object JamWaktu {

    private const val PEMISAH_INTERNAL = "\u001F"

    private val SATUAN = arrayOf(
        "nol", "satu", "dua", "tiga", "empat", "lima",
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"
    )

    fun kata(n: Int): String = when {
        n < 12 -> SATUAN[n]
        n < 20 -> SATUAN[n - 10] + " belas"
        n < 100 -> {
            val s = n % 10
            SATUAN[n / 10] + " puluh" + if (s > 0) " " + SATUAN[s] else ""
        }
        else -> n.toString()
    }

    private fun bagianHari(h: Int) = when (h) {
        in 0..3 -> "dini hari"
        in 4..9 -> "pagi"
        in 10..14 -> "siang"
        in 15..17 -> "sore"
        18 -> "petang"
        else -> "malam"
    }

    private fun ucapanDenganPemisah(p: Prefs, c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val duabelas = p.jamFormat == 1
        val jam = if (duabelas) (if (h % 12 == 0) 12 else h % 12) else h
        val sebutJam = p.jamSebutJam
        val sebutMenit = p.jamSebutMenit
        val sebutPeriode = duabelas && p.jamSebutPeriode

        if (p.jamBahasaIdx == 1) {
            val sb = StringBuilder("It is")
            if (sebutJam) sb.append(" ").append(JamBahasa.kata(jam, 1))
            if (sebutMenit) {
                if (sebutJam && m == 0) sb.append(" o'clock")
                else if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" ").append(JamBahasa.kata(m, 1))
                } else sb.append(" ").append(JamBahasa.kata(m, 1)).append(" minutes")
            } else if (sebutJam && m == 0) sb.append(" o'clock")
            if (p.jamSebutDetik) sb.append(" ").append(JamBahasa.kata(c.get(Calendar.SECOND), 1)).append(" seconds")
            if (sebutPeriode) sb.append(if (h < 12) " AM" else " PM")
            return sb.toString()
        }
        if (p.jamBahasaIdx == 2) {
            val sb = StringBuilder("الوقت الحالي")
            if (sebutJam) sb.append("، الساعة ").append(JamBahasa.kata(jam, 2))
            if (sebutMenit) {
                if (sebutJam && m == 0) sb.append(" تمامًا")
                else if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" و").append(JamBahasa.kata(m, 2)).append(" دقيقة")
                } else sb.append(" ").append(JamBahasa.kata(m, 2)).append(" دقيقة")
            } else if (sebutJam && m == 0) sb.append(" تمامًا")
            if (p.jamSebutDetik) sb.append(" ").append(JamBahasa.kata(c.get(Calendar.SECOND), 2)).append(" ثانية")
            return sb.toString()
        }
        if (p.jamBahasaIdx == 3) {
            // Gunakake ukara basa Jawa krama kanthi konsisten; aja nganggo awalan
            // khusus pengguna sing bisa uga isih nganggo basa Indonesia.
            val sb = StringBuilder("Sapunika wekdalipun")
            if (sebutJam) sb.append(" tabuh ").append(jawaKata(jam))
            if (sebutMenit) {
                if (sebutJam && m == 0) sb.append(" pas")
                else if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" langkung ").append(jawaKata(m)).append(" menit")
                } else sb.append(" ").append(jawaKata(m)).append(" menit")
            } else if (sebutJam && m == 0) sb.append(" pas")
            // Menit lan detik langsung dirangkai tanpa tembung panyambung.
            if (p.jamSebutDetik) sb.append(" ").append(jawaKata(c.get(Calendar.SECOND))).append(" detik")
            if (sebutPeriode) sb.append(' ').append(when (h) {
                in 0..3 -> "tengah dalu"
                in 4..10 -> "enjing"
                in 11..14 -> "siyang"
                in 15..18 -> "sonten"
                else -> "dalu"
            })
            return sb.toString()
        }

        val sb = StringBuilder(p.jamAwalan.trim())
        if (sebutJam) sb.append(' ').append(kata(jam))
        if (sebutMenit) {
            if (sebutJam && m == 0) sb.append(" tepat")
            else if (sebutJam) {
                if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                sb.append(" lewat ").append(kata(m)).append(" menit")
            } else sb.append(" menit ").append(kata(m))
        } else if (sebutJam && m == 0) sb.append(" tepat")
        // [DIPERBAIKI] Sebelumnya memakai koma literal (", ") di sini -- satu-
        // satunya dari keempat bahasa yang masih begitu (Inggris pakai "and",
        // Arab pakai "و", Jawa pakai "langkung") -- tidak konsisten dengan
        // perbaikan 1.0.29 yang menghilangkan koma penentu intonasi TTS.
        if (p.jamSebutDetik) sb.append(" ").append(kata(c.get(Calendar.SECOND))).append(" detik")
        if (sebutPeriode) sb.append(' ').append(bagianHari(h))
        return sb.toString()
    }

    /** Teks yang ditampilkan/diucapkan tetap alami; pemisah teknis tidak pernah dibacakan. */
    fun ucapan(p: Prefs, c: Calendar): String = ucapanDenganPemisah(p, c).replace(PEMISAH_INTERNAL, "")

    /** Angka basa Jawa krama kanggo pengumuman wektu. */
    private fun jawaKata(n: Int): String {
        val satuan = arrayOf("nol", "setunggal", "kalih", "tigang", "sekawan", "gangsal", "enem", "pitu", "wolu", "sanga")
        return when (n) {
            in 0..9 -> satuan[n]
            10 -> "sedasa"
            11 -> "setunggal welas"
            12 -> "kalih welas"
            13 -> "tigang welas"
            14 -> "sekawan welas"
            15 -> "gangsal welas"
            16 -> "enem welas"
            17 -> "pitung welas"
            18 -> "wolung welas"
            19 -> "sangang welas"
            20 -> "kalih dasa"
            in 21..29 -> "kalih dasa ${satuan[n % 10]}"
            in 30..39 -> if (n % 10 == 0) "tigang dasa" else "tigang dasa ${satuan[n % 10]}"
            in 40..49 -> if (n % 10 == 0) "sekawan dasa" else "sekawan dasa ${satuan[n % 10]}"
            in 50..59 -> if (n % 10 == 0) "seket" else "seket ${satuan[n % 10]}"
            in 60..69 -> if (n % 10 == 0) "sawidak" else "sawidak ${satuan[n % 10]}"
            in 70..79 -> if (n % 10 == 0) "pitung dasa" else "pitung dasa ${satuan[n % 10]}"
            in 80..89 -> if (n % 10 == 0) "wolung dasa" else "wolung dasa ${satuan[n % 10]}"
            in 90..99 -> if (n % 10 == 0) "sangang dasa" else "sangang dasa ${satuan[n % 10]}"
            else -> n.toString()
        }
    }

    /**
     * Urutan acuan main.lua: waktu terlebih dahulu; lalu satu segmen hari + pasaran Jawa
     * + tanggal Masehi; terakhir tanggal Hijriah. Segmen kalender yang tidak aktif dilewati.
     */
    fun segmenTanggal(p: Prefs, c: Calendar): List<String> {
        val hasil = ArrayList<String>()
        if (p.kalenderPasaranOn || p.kalenderMasehiOn) {
            val bagian = ArrayList<String>()
            if (p.kalenderPasaranOn) bagian.add(KalenderTanggal.pasaran(c, p.kalenderPasaranKoreksi))
            if (p.kalenderMasehiOn) bagian.add(KalenderTanggal.masehi(c))
            hasil.add(bagian.joinToString(", "))
        }
        if (p.kalenderHijriOn) {
            hasil.add(KalenderTanggal.hijriah(
                c,
                if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null
            ))
        }
        hasil.addAll(HariLibur.segmen(p, c))
        return hasil.filter { it.isNotBlank() }
    }

    fun segmenUcapanLengkap(p: Prefs, c: Calendar): List<String> {
        return (listOf(ucapan(p, c)) + segmenTanggal(p, c)).filter { it.isNotBlank() }
    }

    fun ucapanLengkap(p: Prefs, c: Calendar): String = segmenUcapanLengkap(p, c).joinToString(". ")

    /** Waktu saja, mempertahankan pengaturan jeda khusus antara jam dan menit. */
    fun bagianUcapanLengkap(p: Prefs, c: Calendar): Pair<String, String?> = bagianUcapan(p, c)

    /** Pecah melalui pemisah internal agar jeda 300 ms tidak bergantung pada tanda baca. */
    fun bagianUcapan(p: Prefs, c: Calendar): Pair<String, String?> {
        val teks = ucapanDenganPemisah(p, c)
        if (p.jamJedaJamMenit <= 0 || !p.jamSebutJam || !p.jamSebutMenit) {
            return Pair(teks.replace(PEMISAH_INTERNAL, ""), null)
        }
        val posisi = teks.indexOf(PEMISAH_INTERNAL)
        return if (posisi >= 0) Pair(teks.substring(0, posisi).trimEnd(), teks.substring(posisi + PEMISAH_INTERNAL.length).trimStart())
        else Pair(teks.replace(PEMISAH_INTERNAL, ""), null)
    }

    /** "06.30" */
    fun format(menit: Int): String = "%02d.%02d".format(menit / 60, menit % 60)

    private val NAMA_HARI = arrayOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")

    fun ringkasHari(mask: Int): String {
        if ((mask and 127) == 127) return "Setiap hari"
        if ((mask and 127) == 0) return "Tidak ada"
        // Urutan tampil Senin..Minggu
        return listOf(1, 2, 3, 4, 5, 6, 0).filter { (mask and (1 shl it)) != 0 }
            .joinToString(", ") { NAMA_HARI[it] }
    }

    /** Waktu (ms) jadwal pertama yang lebih besar dari [setelah], atau null bila tidak ada hari aktif. */
    fun berikut(p: Prefs, setelah: Long): Long? {
        val mulai = p.jamMulai
        val selesai = p.jamSelesai
        val panjang = when {
            selesai > mulai -> selesai - mulai
            selesai < mulai -> selesai + 1440 - mulai
            else -> 0
        }
        val langkah = if (p.jamMode == 0) 60 else p.jamInterval
        val awal = if (p.jamMode == 0) (60 - mulai % 60) % 60 else 0
        if (p.jamHari == 0) return null

        for (d in -1..8) {
            val dasar = Calendar.getInstance()
            dasar.timeInMillis = setelah
            dasar.set(Calendar.HOUR_OF_DAY, 0)
            dasar.set(Calendar.MINUTE, 0)
            dasar.set(Calendar.SECOND, 0)
            dasar.set(Calendar.MILLISECOND, 0)
            dasar.add(Calendar.DAY_OF_YEAR, d)
            val hari = dasar.get(Calendar.DAY_OF_WEEK) - 1
            if ((p.jamHari and (1 shl hari)) == 0) continue
            var off = awal
            while (off <= panjang) {
                val t = dasar.clone() as Calendar
                t.add(Calendar.MINUTE, mulai + off)
                if (t.timeInMillis > setelah) return t.timeInMillis
                off += langkah
            }
        }
        return null
    }
}
