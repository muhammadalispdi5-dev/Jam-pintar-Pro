# FIX278 — Perbaikan pemutaran audio online Asmaul Husna

## Akar masalah yang ditemukan
FIX277 meminta `https://asmaul-husna-api-coral.vercel.app/api/asmaul-husna?id=...&lang=indonesian` dan hanya membaca properti `audio_url`. Endpoint/format tersebut tidak didukung oleh dokumentasi sumber API yang dapat diverifikasi, sehingga URL audio tidak berhasil diperoleh.

## Perbaikan
- Mengganti endpoint menjadi `GET https://esmaulhusna.org/esmas/{id}?lg=id` sesuai dokumentasi API Esmaul Husna.
- Membaca field `audio` yang didokumentasikan sebagai path berkas MP3 (misalnya `/audio/ar-rahman.mp3`), dan mendukung pembungkus respons `data` serta field `audio_url` untuk kompatibilitas.
- Mengubah path relatif menjadi URL HTTPS terhadap domain API.
- Memvalidasi host audio agar tidak diarahkan ke host yang tidak diharapkan.
- Tetap memakai MediaPlayer streaming (`prepareAsync`), tidak mengunduh MP3 ke penyimpanan.
- Mempertahankan tombol jeda/lanjut, hentikan, dan suara TTS perangkat sebagai alternatif.
- Pesan kesalahan dibuat lebih informatif untuk HTTP error, rekaman yang tidak tersedia, dan masalah koneksi.
- Tidak mengubah daftar 99 nama, fitur lain, maupun versi aplikasi: `versionCode 89`, `versionName 1.0.89`.

## Batas pengujian
Dokumentasi sumber API menyatakan endpoint `/esmas/{id}` dan field `audio` dengan aset di `/audio`. Namun lingkungan build ini tidak memiliki akses DNS/internet untuk melakukan permintaan langsung ke server, dan Android SDK/Gradle build tidak tersedia. Karena itu perbaikan kode telah diperiksa secara statis tetapi belum dapat dinyatakan teruji pada perangkat. Perlu uji APK dengan koneksi internet aktif untuk memastikan server dan semua berkas audionya sedang tersedia.
