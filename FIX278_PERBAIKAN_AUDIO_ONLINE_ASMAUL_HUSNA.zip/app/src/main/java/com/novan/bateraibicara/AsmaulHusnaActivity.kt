package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.media.AudioAttributes
import android.media.MediaPlayer
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale

/**
 * FIX272: Asmaul Husna (99 nama Allah). Beranda: cari, bacakan semua berurutan, daftar 99 nama.
 * Halaman nama: Arab, cara baca Latin, arti, dengarkan, sebelumnya/berikutnya, salin, bagikan.
 */
class AsmaulHusnaActivity : Halaman() {
    override val judulHalaman = R.string.judul_asmaul_husna

    private val simpan by lazy { getSharedPreferences("asmaul_husna", MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private var tertunda: (() -> Unit)? = null
    private var pemutarOnline: MediaPlayer? = null
    @Volatile private var generasiAudioOnline = 0

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun arti(n: AsmaulHusnaData.Nama) = if (english) n.artiEn else n.artiId

    override fun onPause() {
        hentikanSuara()
        super.onPause()
    }

    override fun onDestroy() {
        hentikanSuara()
        try { tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("nomor", -1)
        val n = AsmaulHusnaData.daftar.getOrNull(nomor)
        if (n != null) halamanNama(nomor, n) else beranda()
    }

    // ---------- Beranda ----------

    private fun beranda() {
        info(tr(
            "Asmaul Husna adalah 99 nama Allah yang terbaik. Rasulullah shallallahu 'alaihi wasallam bersabda bahwa Allah memiliki sembilan puluh sembilan nama, siapa yang menghafal dan memahaminya akan masuk surga (HR. Al-Bukhari dan Muslim). Daftar yang dipakai di sini adalah daftar yang lazim digunakan; sebagian ulama menyusun daftar dengan sedikit perbedaan.",
            "Asmaul Husna are the 99 most beautiful names of Allah. The Messenger of Allah, peace be upon him, said that Allah has ninety-nine names, and whoever memorizes and understands them will enter Paradise (Al-Bukhari and Muslim). The list used here is the commonly used one; some scholars compile it with slight differences."
        ))
        tombol(tr("Pilih mesin suara pembaca", "Choose reading speech engine")) { pilihMesinSuara() }
        bagian(tr("Bacakan berurutan", "Read in order"))
        tombol(tr("Bacakan semua: cara baca Latin dan artinya", "Read all: Latin reading and meaning")) { bacaSemua(0, false) }
        tombol(tr("Bacakan semua: bacaan Arab", "Read all: Arabic")) { bacaSemua(0, true) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara(); toast(tr("Suara dihentikan.", "Audio stopped.")) }
        var render: (String) -> Unit = { }
        val kolom = isian(tr("Cari nama atau nomor", "Search by name or number"), "", android.text.InputType.TYPE_CLASS_TEXT) { render(it) }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        val mulai = root.childCount
        render = { teksCari ->
            while (root.childCount > mulai) root.removeViewAt(root.childCount - 1)
            val q = teksCari.trim().lowercase(Locale.ROOT)
            bagian(tr("Daftar 99 nama", "List of 99 names"))
            var ada = 0
            AsmaulHusnaData.daftar.forEachIndexed { i, n ->
                if (q.isEmpty() || cocok(i, n, q)) {
                    ada++
                    tombol((i + 1).toString() + ". " + n.latin + ", " + arti(n)) { buka(i) }
                }
            }
            if (ada == 0) info(tr("Tidak ada nama yang cocok.", "No matching name."))
        }
        render("")
    }

    private fun cocok(i: Int, n: AsmaulHusnaData.Nama, q: String): Boolean {
        val gudang = ((i + 1).toString() + " " + n.latin + " " + n.artiId + " " + n.artiEn).lowercase(Locale.ROOT) + " " +
            AsmaulHusnaData.normal(n.latin)
        return q.split(" ").filter { it.isNotEmpty() }.all { gudang.contains(it) || gudang.contains(AsmaulHusnaData.normal(it)) }
    }

    private fun buka(nomor: Int) {
        startActivity(Intent(this, AsmaulHusnaActivity::class.java).putExtra("nomor", nomor))
    }

    // ---------- Halaman satu nama ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 20f)

    private fun halamanNama(nomor: Int, n: AsmaulHusnaData.Nama) {
        bagian((nomor + 1).toString() + ". " + n.latin, 22f)
        info(tr("Nama ke-" + (nomor + 1) + " dari 99", "Name " + (nomor + 1) + " of 99"))
        subjudul(tr("Teks Arab", "Arabic text"))
        val ar = TextView(this)
        ar.text = n.arab
        ar.textSize = ukuran() + 10f
        ar.setTextColor(warnaTeks())
        ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        ar.setPadding(0, dp(8), 0, dp(8))
        root.addView(ar)
        subjudul(tr("Cara baca (Latin)", "Transliteration"))
        paragraf(n.latin)
        subjudul(tr("Artinya", "Meaning"))
        paragraf(arti(n))

        subjudul(tr("Dengarkan", "Listen"))
        tombol(tr("Putar audio Arab secara online", "Play Arabic audio online")) { putarAudioOnline(nomor) }
        tombol(tr("Jeda atau lanjutkan audio online", "Pause or resume online audio")) { jedaLanjutAudioOnline() }
        tombol(tr("Dengarkan bacaan Arab dengan suara perangkat", "Listen to Arabic using device voice")) { ucapkan(listOf(n.arab), Locale("ar"), true) }
        tombol(tr("Dengarkan cara baca Latin dan artinya", "Listen to the Latin reading and meaning")) {
            ucapkan(listOf(n.latin + ". " + arti(n)), if (english) Locale.US else Locale("id", "ID"), false)
        }
        tombol(tr("Bacakan mulai dari nama ini", "Read starting from this name")) { bacaSemua(nomor, false) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara() }

        subjudul(tr("Pengaturan dan bagikan", "Settings and sharing"))
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(36f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }
        val semua = (nomor + 1).toString() + ". " + n.arab + "\n" + n.latin + "\n" + arti(n)
        tombol(tr("Salin nama", "Copy name")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("asmaul husna", semua))
                toast(tr("Nama disalin.", "Name copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan nama", "Share name")) {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua), tr("Bagikan nama", "Share name")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan teks.", "No app is available to share this text."))
            }
        }
        if (nomor > 0) tombol(tr("Nama sebelumnya", "Previous name")) { pindah(nomor - 1) }
        if (nomor < AsmaulHusnaData.daftar.size - 1) tombol(tr("Nama berikutnya", "Next name")) { pindah(nomor + 1) }
    }

    private fun pindah(nomor: Int) {
        startActivity(Intent(this, AsmaulHusnaActivity::class.java).putExtra("nomor", nomor))
        finish()
    }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 18f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(20), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun paragraf(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(2), 0, dp(6))
        root.addView(tv)
    }

    // ---------- Suara (teks-ke-ucapan) ----------

    private fun hentikanSuara() {
        BacaanBisaDibungkam.lepas("baca_asmaul_husna")
        try { tts?.stop() } catch (_: Exception) { }
        hentikanAudioOnline()
    }

    /**
     * FIX278: Mengambil URL audio dari API esmaulhusna.org.
     * API yang dipakai sebelumnya (Vercel coral) tidak memiliki kontrak endpoint/field
     * audio_url yang dapat diandalkan. Dokumentasi API yang baru menyediakan GET /esmas/{id}
     * dan field audio berupa path /audio/nama.mp3.
     */
    private fun putarAudioOnline(nomor: Int) {
        if (nomor !in AsmaulHusnaData.daftar.indices) return
        hentikanAudioOnline()
        val token = generasiAudioOnline
        toast(tr("Menghubungkan ke sumber audio online…", "Connecting to the online audio source…"))
        Thread {
            var koneksi: HttpURLConnection? = null
            try {
                val endpoint = "https://esmaulhusna.org/esmas/${nomor + 1}?lg=id"
                koneksi = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 20000
                    requestMethod = "GET"
                    instanceFollowRedirects = true
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "JamPintarPro/1.0.89 (Android)")
                }
                val kode = koneksi.responseCode
                if (kode !in 200..299) throw IllegalStateException("HTTP $kode")
                val isi = koneksi.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val json = JSONObject(isi)
                val audioPath = cariFieldAudio(json)
                if (audioPath.isBlank()) throw IllegalStateException("Field audio tidak ditemukan")
                val audioUri = java.net.URI("https://esmaulhusna.org/").resolve(audioPath).toString()
                if (!audioUri.startsWith("https://esmaulhusna.org/")) throw IllegalStateException("Host audio tidak valid")

                runOnUiThread {
                    if (isFinishing || isDestroyed || token != generasiAudioOnline) return@runOnUiThread
                    try {
                        val mp = MediaPlayer()
                        pemutarOnline = mp
                        mp.setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build())
                        mp.setOnPreparedListener { player ->
                            if (token == generasiAudioOnline && pemutarOnline === player) {
                                player.start()
                                toast(tr("Audio Asmaul Husna sedang diputar.", "Asmaul Husna audio is playing."))
                            }
                        }
                        mp.setOnCompletionListener { player ->
                            if (pemutarOnline === player) {
                                pemutarOnline = null
                                try { player.release() } catch (_: Exception) { }
                            }
                        }
                        mp.setOnErrorListener { player, _, _ ->
                            if (pemutarOnline === player) pemutarOnline = null
                            try { player.release() } catch (_: Exception) { }
                            toast(tr("Berkas audio tidak dapat diputar. Silakan coba lagi atau gunakan suara perangkat.",
                                "The audio file could not be played. Please try again or use device speech."))
                            true
                        }
                        mp.setDataSource(audioUri)
                        mp.prepareAsync()
                    } catch (_: Exception) {
                        hentikanAudioOnline()
                        toast(tr("Audio online tidak dapat disiapkan. Periksa koneksi internet.",
                            "Online audio could not be prepared. Check your internet connection."))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed && token == generasiAudioOnline) {
                        val pesan = when {
                            e.message?.contains("HTTP") == true -> tr("Server audio sedang tidak tersedia (" + e.message + ").", "The audio server is unavailable (" + e.message + ").")
                            e.message?.contains("Field audio") == true -> tr("Server belum menyediakan rekaman untuk nama ini.", "The server has no recording for this name yet.")
                            else -> tr("Sumber audio online tidak dapat dihubungi. Periksa koneksi internet.", "The online audio source could not be reached. Check your internet connection.")
                        }
                        toast(pesan)
                    }
                }
            } finally { try { koneksi?.disconnect() } catch (_: Exception) { } }
        }.start()
    }

    /** Mencari field audio di objek utama maupun objek data pembungkus respons API. */
    private fun cariFieldAudio(objek: JSONObject): String {
        val langsung = objek.optString("audio", "").trim()
        if (langsung.isNotEmpty()) return langsung
        val alternatif = objek.optString("audio_url", "").trim()
        if (alternatif.isNotEmpty()) return alternatif
        val data = objek.optJSONObject("data")
        if (data != null) {
            val nested = data.optString("audio", "").trim()
            if (nested.isNotEmpty()) return nested
            val nestedUrl = data.optString("audio_url", "").trim()
            if (nestedUrl.isNotEmpty()) return nestedUrl
        }
        return ""
    }

    private fun jedaLanjutAudioOnline() {
        val mp = pemutarOnline
        if (mp == null) { toast(tr("Belum ada audio online yang diputar.", "No online audio is playing.")); return }
        try {
            if (mp.isPlaying) { mp.pause(); toast(tr("Audio dijeda.", "Audio paused.")) }
            else { mp.start(); toast(tr("Audio dilanjutkan.", "Audio resumed.")) }
        } catch (_: Exception) { hentikanAudioOnline() }
    }

    private fun hentikanAudioOnline() {
        generasiAudioOnline++
        val mp = pemutarOnline
        pemutarOnline = null
        try { mp?.stop() } catch (_: Exception) { }
        try { mp?.release() } catch (_: Exception) { }
    }

    private fun pilihMesinSuara() {
        MesinSuaraPembaca.tampilkan(this, simpan) {
            try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
            tts = null; ttsSiap = false; tertunda = null
        }
    }

    /** Membacakan semua nama mulai dari [awal] secara berurutan; tiap nama menjadi satu ucapan dalam antrean. */
    private fun bacaSemua(awal: Int, arab: Boolean) {
        val bagian = AsmaulHusnaData.daftar.drop(awal)
        val teks = if (arab) bagian.map { it.arab }
        else bagian.mapIndexed { i, n -> (awal + i + 1).toString() + ". " + n.latin + ". " + arti(n) + "." }
        ucapkan(teks, if (arab) Locale("ar") else if (english) Locale.US else Locale("id", "ID"), arab)
    }

    private fun ucapkan(potongan: List<String>, bahasa: Locale, arab: Boolean) {
        denganTts {
            val m = tts
            if (m != null) {
                val r = m.setLanguage(bahasa)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    toast(
                        if (arab) tr("Suara bahasa Arab belum terpasang di perangkat. Pasang data suara Arab pada pengaturan teks-ke-ucapan Android, atau gunakan cara baca Latin.",
                            "The Arabic voice is not installed on this device. Install Arabic voice data in Android text-to-speech settings, or use the Latin reading.")
                        else tr("Data suara untuk bahasa ini belum terpasang. Pasang pada pengaturan teks-ke-ucapan Android.",
                            "Voice data for this language is not installed. Install it in Android text-to-speech settings.")
                    )
                } else {
                    m.stop()
                    var pertama = true
                    var panjang = 0
                    for (p in potongan) {
                        m.speak(p, if (pertama) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "asma_" + System.nanoTime())
                        pertama = false
                        panjang += p.length
                    }
                    BacaanBisaDibungkam.mulai(this, m, "baca_asmaul_husna", panjang) { try { m.stop() } catch (_: Exception) { } }
                }
            }
        }
    }

    private fun denganTts(aksi: () -> Unit) {
        if (ttsSiap) { aksi(); return }
        tertunda = aksi
        if (tts == null) {
            val mesin = MesinSuaraPembaca.paket(simpan).ifBlank { null }
            tts = TextToSpeech(applicationContext, { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsSiap = true
                    val a = tertunda
                    tertunda = null
                    a?.invoke()
                } else {
                    toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = null
                    tertunda = null
                }
            }, mesin)
        }
    }
}
