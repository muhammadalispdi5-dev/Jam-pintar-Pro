#!/usr/bin/env python3
"""FIX273: volume pengumuman harus memasang volume saluran pilihan dan mengembalikannya."""
from pathlib import Path
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
def t(n): return (R / n).read_text(encoding="utf-8")
g = []
for k in ("fun pinjam", "fun lepas", "setStreamVolume", "SecurityException", "pulihkan"):
    if k not in t("VolumeSaluran.kt"): g.append("GAGAL VolumeSaluran: " + k)
for k in ("VolumeSaluran.pinjam", "VolumeSaluran.lepas", "saluranDipinjam"):
    if k not in t("Pembicara.kt"): g.append("GAGAL Pembicara: " + k)
c = t("CallerListener.kt")
if c.count("putarMelodiSaluran(") < 5 or "volume = volPem())" in c.replace("else volPem()", ""): g.append("GAGAL CallerListener belum memakai volume saluran di semua melodi")
if "volumeSaluran = prefs.volumeSaluranPem" not in c: g.append("GAGAL CallerListener volumeSaluran")
if "volumeSaluranPem" not in t("Prefs.kt"): g.append("GAGAL Prefs")
if "p.volumeSaluran = volume" not in t("Halaman.kt"): g.append("GAGAL tes volume")
if "PembungkamTelungkup.volumeDiubahAplikasi" not in t("VolumeSaluran.kt") or "fun volumeDiubahAplikasi" not in t("PembungkamTelungkup.kt"): g.append("GAGAL pemantau volume akan membungkam pengumuman akibat perubahan volume sendiri")
print("\n".join(g) if g else "UJI VOLUME SALURAN: LULUS")
