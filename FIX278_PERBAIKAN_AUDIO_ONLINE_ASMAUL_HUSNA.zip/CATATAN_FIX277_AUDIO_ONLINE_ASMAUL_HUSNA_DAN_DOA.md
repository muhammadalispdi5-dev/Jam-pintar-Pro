# FIX277 — Audio Online Asmaul Husna dan evaluasi sumber Doa Sehari-hari

## Perubahan
- Menambahkan tombol **Putar audio Arab secara online** pada halaman detail setiap Asmaul Husna.
- Menambahkan tombol **Jeda atau lanjutkan audio online**.
- Aplikasi mengambil `audio_url` untuk nomor nama yang dipilih dari API publik Asmaul Husna, lalu memutar URL tersebut langsung dengan `MediaPlayer.prepareAsync()` tanpa mengunduh berkas ke penyimpanan.
- Menambahkan penanganan koneksi gagal, URL audio tidak tersedia, kesalahan pemutar, penghentian saat halaman ditinggalkan, dan pembersihan MediaPlayer.
- TTS/perangkat tetap tersedia sebagai alternatif jika audio online tidak dapat diakses.

## Doa Sehari-hari
- Pemutaran lokal yang sudah ada (raw resource/rekaman pengguna) dan TTS perangkat dipertahankan.
- Streaming online belum diaktifkan untuk daftar doa karena belum ditemukan katalog audio daring yang dapat dipetakan secara andal ke seluruh ID/lafaz pada `DoaHarianData`. Tidak digunakan URL tebakan atau audio doa yang lafaznya tidak cocok.
- Dengan demikian, tidak ada klaim bahwa seluruh doa sudah memiliki rekaman online. Fitur streaming doa dapat ditambahkan setelah sumber rekaman per-doa yang sahih dan stabil tersedia.

## Sumber dan batasan
- Endpoint metadata/audio Asmaul Husna: `https://asmaul-husna-api-coral.vercel.app/api/asmaul-husna?id={nomor}&lang=indonesian`.
- API pihak ketiga dapat berubah, mengalami gangguan, atau menghapus audio; koneksi internet diperlukan.
- Lingkungan kerja tidak memiliki akses DNS internet untuk menguji respons endpoint secara langsung.

## Pemeriksaan
- Tidak ada perubahan versi aplikasi.
- Pemeriksaan parser Kotlin tidak menemukan diagnostik sintaks pada `AsmaulHusnaActivity.kt`.
- Kompilasi Android penuh dan uji perangkat belum dapat dilakukan karena Gradle/Android SDK tidak tersedia di lingkungan kerja ini.
