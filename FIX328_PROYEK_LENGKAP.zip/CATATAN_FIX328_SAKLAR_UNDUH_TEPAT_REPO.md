# FIX328
- Saklar utama (Prefs.enabled) kini menggerbang azan/pengingat salat, notifikasi jadwal, alarm jam, pengingat Khatam/hafalan, goncangan, tombol volume. Pemulihan DND tetap jalan. Menyalakan saklar memasang ulang jadwal.
- Unduhan audio: retry 4x, Retry-After, redirect, penyebab gagal ditampilkan. Penyebab pasti kegagalan lama belum terbukti.
- Jam: pref jam_jeda_tepat (ms) memecah ucapan di sekitar kata "tepat" (5 bahasa).
- Pembaruan: default repo Jam-pintar-Pro, mencoba juga nama Bro; cek apk memakai daftar repo.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
