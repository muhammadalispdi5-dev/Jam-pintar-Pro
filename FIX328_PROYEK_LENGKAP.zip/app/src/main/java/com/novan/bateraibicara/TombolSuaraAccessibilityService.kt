package com.novan.bateraibicara

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.PowerManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * FIX227: layanan aksesibilitas khusus untuk membuka perintah suara dari tombol pilihan pengguna
 * (tahan volume atas/bawah, kedua volume bersamaan, volume dua kali, atau tombol aksesibilitas).
 * Layanan ini tidak membaca isi layar dan tidak merekam suara; ia hanya menerima peristiwa tombol volume,
 * dan hanya bila pengguna mengaktifkannya di Pengaturan > Aksesibilitas.
 */
class TombolSuaraAccessibilityService : AccessibilityService() {
    private val detektor = PemicuTombol()
    private var tombolAksesibilitas: AccessibilityButtonController? = null
    private var callbackTombol: AccessibilityButtonController.AccessibilityButtonCallback? = null
    private val pengendali = Handler(Looper.getMainLooper())
    private var kodeTahan = 0
    private val pemeriksaTahan = Runnable {
        // FIX228: pola tahan dinilai oleh pewaktu, bukan hanya oleh peristiwa pengulangan tombol (HP tertentu tidak mengirimnya).
        if (detektor.cekTahan(SystemClock.uptimeMillis())) {
            kembalikanVolume(kodeTahan)
            picu()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        terapkanPengaturan()
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                val c = accessibilityButtonController
                tombolAksesibilitas = c
                val cb = object : AccessibilityButtonController.AccessibilityButtonCallback() {
                    override fun onClicked(controller: AccessibilityButtonController) {
                        if (modeTersimpan() == PemicuTombol.Mode.AKSESIBILITAS) picu()
                    }
                }
                callbackTombol = cb
                c.registerAccessibilityButtonCallback(cb)
            } catch (_: Throwable) { }
        }
    }

    private fun modeTersimpan(): PemicuTombol.Mode {
        val p = getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        return PemicuTombol.modeDariIndeks(p.getInt(KEY_MODE, 0))
    }

    private fun terapkanPengaturan() {
        val p = getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        detektor.mode = PemicuTombol.modeDariIndeks(p.getInt(KEY_MODE, 0))
        detektor.tahanMs = p.getInt(KEY_TAHAN_MS, 800).coerceIn(400, 3000).toLong()
    }

    private var telanBungkam = false

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode != KeyEvent.KEYCODE_VOLUME_UP && kode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        // FIX328: saklar utama mati = semua fitur latar tidak berfungsi.
        if (!getSharedPreferences("pengaturan", MODE_PRIVATE).getBoolean("enabled", false)) return false
        // FIX262: selama pengumuman panggilan/pesan, pembacaan, atau suara notifikasi aplikasi berbunyi, tombol volume atas/bawah menghentikannya.
        // Jalur ini andal di semua keadaan (layar mati, volume sudah maksimal, HP berdering) karena tidak bergantung pada perubahan nilai volume.
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) telanBungkam = false
            if (telanBungkam) return true
            if (PembungkamTelungkup.bungkamDariTombolVolume(this)) {
                val modeSistem = try { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode } catch (_: Throwable) { AudioManager.MODE_NORMAL }
                // Saat HP berdering atau sedang dalam panggilan, tombol tetap diteruskan agar dering/volume panggilan ikut diredam sistem.
                if (modeSistem == AudioManager.MODE_RINGTONE || modeSistem == AudioManager.MODE_IN_CALL) return false
                telanBungkam = true
                return true
            }
        } else if (event.action == KeyEvent.ACTION_UP && telanBungkam) {
            telanBungkam = false
            return true
        }
        // FIX228: catat peristiwa terakhir yang benar-benar diterima layanan, untuk diagnosa di layar pengaturan.
        try {
            getSharedPreferences("pengaturan", Context.MODE_PRIVATE).edit()
                .putString(KEY_LOG, (if (kode == KeyEvent.KEYCODE_VOLUME_UP) "UP" else "DOWN") + "|" + (if (event.action == KeyEvent.ACTION_DOWN) "D" else "U") + "|" + event.repeatCount + "|" + System.currentTimeMillis())
                .apply()
        } catch (_: Throwable) { }
        // Pengaturan dibaca ulang pada tekanan baru agar perubahan di layar pengaturan langsung berlaku.
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) terapkanPengaturan()
        if (detektor.mode == PemicuTombol.Mode.NONAKTIF || detektor.mode == PemicuTombol.Mode.AKSESIBILITAS) return false
        // Jangan mengganggu pengaturan volume saat panggilan telepon berlangsung.
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION || am.mode == AudioManager.MODE_RINGTONE) return false
        } catch (_: Throwable) { }
        val turun = event.action == KeyEvent.ACTION_DOWN
        val sekarang = SystemClock.uptimeMillis()
        val hasil = detektor.proses(kode, turun, event.repeatCount, sekarang)
        if (turun && event.repeatCount == 0 && detektor.tombolTahan(kode)) {
            kodeTahan = kode
            pengendali.removeCallbacks(pemeriksaTahan)
            pengendali.postDelayed(pemeriksaTahan, detektor.tahanMs + 30L)
        } else if (!turun) {
            pengendali.removeCallbacks(pemeriksaTahan)
        }
        return when (hasil) {
            PemicuTombol.Hasil.LEWAT -> false
            PemicuTombol.Hasil.TELAN -> true
            PemicuTombol.Hasil.PICU -> {
                pengendali.removeCallbacks(pemeriksaTahan)
                if (detektor.mode == PemicuTombol.Mode.TAHAN_ATAS || detektor.mode == PemicuTombol.Mode.TAHAN_BAWAH) kembalikanVolume(kode)
                picu()
                true
            }
        }
    }

    /** Pada mode tahan, tekanan pertama sudah mengubah volume satu langkah; kembalikan ke semula. */
    private fun kembalikanVolume(kode: Int) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustSuggestedStreamVolume(
                if (kode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE,
                AudioManager.USE_DEFAULT_STREAM_TYPE, 0
            )
        } catch (_: Throwable) { }
    }

    private fun picu() {
        if (!PemicuSuara.buka(this)) return
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 26) {
            try { callbackTombol?.let { tombolAksesibilitas?.unregisterAccessibilityButtonCallback(it) } } catch (_: Throwable) { }
        }
        callbackTombol = null
        pengendali.removeCallbacks(pemeriksaTahan)
        super.onDestroy()
    }

    companion object {
        const val KEY_MODE = "pemicu_tombol_mode"
        const val KEY_TAHAN_MS = "pemicu_tombol_tahan_ms"
        const val KEY_LOG = "pemicu_tombol_log"
    }
}

/** Membuka layar perintah suara dari pemicu tombol, termasuk di atas layar kunci (notifikasi layar penuh sebagai jalur andal). */
object PemicuSuara {
    const val NOTIFIKASI_ID = 9411
    private const val KANAL_ID = "pemicu_tombol_suara_siap"
    private val kunci = Any()
    @Volatile private var terakhir = 0L

    fun buka(context: Context): Boolean {
        val sekarang = android.os.SystemClock.elapsedRealtime()
        synchronized(kunci) {
            if (sekarang - terakhir < 2_500L) return false
            terakhir = sekarang
        }
        val english = BahasaAplikasi.tampilan(context) == 1
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, context.packageName + ":TombolSuaraLaunch").apply {
                setReferenceCounted(false)
                acquire(15_000L)
            }
        } catch (_: Exception) { }
        val intent = Intent(context, PerintahSuaraActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(PerintahSuaraActivity.EXTRA_PEMICU_GONCANGAN, true)
        }
        try {
            val manager = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                val kanal = NotificationChannel(
                    KANAL_ID,
                    if (english) "Voice command ready (button trigger)" else "Perintah suara siap (pemicu tombol)",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    setSound(null, null)
                    enableVibration(false)
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                manager.createNotificationChannel(kanal)
            }
            val launch = PendingIntent.getActivity(
                context, 9412, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, KANAL_ID)
                else Notification.Builder(context).setPriority(Notification.PRIORITY_MAX)
            builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(if (english) "Voice command is ready" else "Perintah suara siap")
                .setContentText(if (english) "Tap to speak" else "Ketuk untuk mulai berbicara")
                .setContentIntent(launch)
                .setFullScreenIntent(launch, true)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
            if (Build.VERSION.SDK_INT >= 26) builder.setTimeoutAfter(20_000L)
            manager.notify(NOTIFIKASI_ID, builder.build())
        } catch (_: Exception) { }
        try { context.startActivity(intent) } catch (_: Exception) { }
        return true
    }

    fun layananAktif(context: Context): Boolean {
        val komponen = android.content.ComponentName(context, TombolSuaraAccessibilityService::class.java)
        val aktif = android.provider.Settings.Secure.getString(context.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val dariPengaturan = aktif.split(':').any { entri ->
            entri.isNotBlank() && (android.content.ComponentName.unflattenFromString(entri.trim())?.equals(komponen) == true ||
                entri.trim().equals(komponen.flattenToString(), true) || entri.trim().equals(komponen.flattenToShortString(), true))
        }
        if (dariPengaturan) return true
        return try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
            am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
                it.resolveInfo?.serviceInfo?.let { si -> si.packageName == context.packageName && si.name == komponen.className } == true
            }
        } catch (_: Throwable) { false }
    }
}
