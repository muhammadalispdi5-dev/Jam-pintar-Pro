import re,sys
b='app/src/main/java/com/novan/bateraibicara/'
def r(n): return open(b+n).read()
gagal=0
def cek(n,c):
    global gagal
    print(("OK   " if c else "GAGAL ")+n); gagal+= (not c)
j=r('JadwalNotifikasi.kt'); a=r('PrayerAlarmReceiver.kt'); s=r('PrayerAlarmService.kt')
cek("berlalu didahulukan",'val aktif = berlalu ?: menjelang' in j)
cek("setTimeoutAfter",'setTimeoutAfter' in j)
cek("dedupe receiver",a.count('sudahDipicu')>=4 and '20 * 60_000L' in a)
cek("dedupe service 20 menit",'20 * 60_000L' in s)
sys.exit(0)
