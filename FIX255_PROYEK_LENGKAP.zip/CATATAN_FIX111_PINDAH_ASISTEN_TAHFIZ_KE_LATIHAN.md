# FIX111 — Asisten Tahfiz Cerdas Dipindah ke Bagian Latihan Hafalan

Versi aplikasi: **1.0.75** (versionCode 75). Basis: FIX110. Perubahan hanya di `KhatamActivity.kt` dan `app/build.gradle.kts`.

## Penilaian penempatan
Sebelumnya Asisten Tahfiz Cerdas menjadi butir pertama di dialog **Pengaturan Khatam Al-Qur'an** (di bawah bagian PENGATURAN). Penempatan itu kurang tepat:
- Asisten adalah **pusat pendamping latihan** (Muraja'ah cerdas, Latihan tanpa mikrofon, Koreksi bacaan), bukan pengaturan. Pengaturan hanya salah satu butir di dalamnya.
- Fungsi yang dikelompokkannya sudah berada di bagian **LATIHAN HAFALAN** pada menu utama Khatam. Pengguna harus masuk Pengaturan dulu (dua ketukan lebih dalam) untuk mencapainya, dan pengguna pembaca layar tidak menemukannya di bagian latihan.

## Perubahan
- Menu utama Khatam, bagian **LATIHAN HAFALAN**: tombol baru **Asisten Tahfiz Cerdas** sebagai butir pertama, dengan deskripsi untuk pembaca layar. Tombol latihan langsung yang sudah ada (Ulas hafalan hari ini, Muraja'ah cerdas, Koreksi otomatis, Latihan tanpa mikrofon) tetap di tempatnya.
- Dialog Pengaturan Khatam: butir Asisten Tahfiz Cerdas dihapus. Isinya kini murni pengaturan (Pengaturan hafalan, pemutaran audio, pengingat, target khatam, aksesibilitas, riwayat, statistik). Pengaturan latihan tetap dapat dicapai dari dalam Asisten lewat "Pengaturan latihan dan aksesibilitas".
- Tombol Kembali pada panel Asisten (tombol layar dan tombol sistem) kini menutup ke menu utama Khatam tempat panel dibuka; tombol berlabel "Kembali ke menu Khatam". Di bawah panel itu, perilaku FIX110 tetap berlaku: Kembali naik satu tingkat (sub-dialog ke panel Asisten).

## Pemeriksaan dan batas
- `tools/verify_project.py`, `tools/periksa_bahasa_aktif.py`, dan `tools/uji_murajaah_cerdas.py`: LULUS; kurung seimbang. BELUM dikompilasi dan BELUM diuji di perangkat.
- Menambah satu tombol di bagian Latihan Hafalan menggeser urutan sapuan TalkBack satu butir.
