# FIX251 — Petunjuk penggunaan disempurnakan dan diperbaiki

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.

Temuan: item 29 (Panduan Ibadah Praktis) dan 30 (aplikasi pembaca notifikasi) pada values, serta item 26 dan 27 pada values-en, tertulis di LUAR elemen string (teks lepas di antara elemen) sehingga tidak pernah tampil di petunjuk. Keduanya kini dipindahkan ke dalam isi_petunjuk_penggunaan.

Item baru (Indonesia 31-35, English 28-32): perintah suara mode acara, lokasi, dan sakelar serta daftar layar yang dapat dibuka dengan suara; pemandu izin pertama dan Izin Perangkat; pengaturan bawaan jadwal sholat; stereo di semua saluran, basmalah/hamdalah pada cadangan, dan audio doa; daftar seluruh menu halaman utama.
