# FIX154 — Pengumuman jam dan baterai tidak lagi menjeda voice note

Basis: FIX153. Berkas: `Pembicara.kt`, `BatteryTalkService.kt`, `CallerListener.kt`, uji baru `tools/uji_fokus_pengumuman.py`.

## Masalah
Saat voice note (mis. WhatsApp) sedang diputar lalu pengumuman jam atau baterai berbunyi, voice note terjeda atau terputus dan baru lanjut setelah
pengguna menekan putar. Sebelumnya voice note hanya mengecil sebentar lalu kembali normal.

## Penyebab
FIX146 mengubah permintaan fokus audio TTS dari `AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK` ("boleh diturunkan") menjadi `AUDIOFOCUS_GAIN_TRANSIENT`
(sementara penuh) untuk semua ucapan. Pada fokus sementara penuh, aplikasi lain diminta berhenti; WhatsApp menjeda voice note dan tidak melanjutkannya sendiri.
Pada fokus MAY_DUCK, aplikasi lain cukup mengecilkan volume lalu memulihkannya begitu fokus dilepas.

## Perbaikan
- `Pembicara` mendapat sakelar `hanyaKecilkanAudioLain` (bawaan false). Bila true: fokus `AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK` dan `setWillPauseWhenDucked(false)`;
  jalur Android lama memakai jenis fokus yang sama.
- Sakelar dinyalakan untuk pengumuman otomatis di latar belakang: jam bicara dan baterai (`BatteryTalkService`), serta pembacaan nama pemanggil
  dan pemberitahuan masuk (`CallerListener`).
- Ucapan asisten yang diminta pengguna (Beritahu Saya, perintah suara, layar Jam, Kalender, dan lain-lain) tidak diubah: tetap `AUDIOFOCUS_GAIN_TRANSIENT`.
- Fokus tetap dilepas setelah pengumuman selesai (`selesaiBicara`) dan oleh pengaman 45 detik, sehingga volume aplikasi lain kembali normal.
- Perubahan FIX146 lain (gain digital TTS 1.0, gain pemutar Qur'an) tidak disentuh.

## Bahasa aktif
Tidak ada teks tampilan atau ucapan baru; perubahan hanya pada perilaku fokus audio. Pemeriksaan bahasa aktif dan resource string lulus.

## Cara menguji
1. Putar voice note panjang di WhatsApp. Picu pengumuman jam (jam bicara per interval) atau baterai (mis. lepas/pasang charger). Voice note harus mengecil sebentar
   lalu kembali normal, tanpa terjeda.
2. Ucapkan perintah suara "jam berapa sekarang" saat voice note berjalan: perilaku tetap seperti sebelumnya (voice note dijeda selama asisten bicara).
3. Ulangi dengan aplikasi pemutar musik dan YouTube.

## Batas pemeriksaan
Belum dikompilasi dan belum diuji di perangkat. Perilaku akhir bergantung pada kebijakan fokus audio tiap aplikasi dan versi Android: aplikasi yang tidak menurunkan
volume sendiri saat diminta ducking tetap dapat berhenti. Dua uji lama gagal juga pada FIX153 asli dan bukan akibat perubahan ini:
`uji_kontrol_wifi_bluetooth.py` (pernyataan versi 1.0.81) dan `uji_tombol_volume.py` (menghitung 4 pembuat Pembicara; sekarang lebih banyak).
