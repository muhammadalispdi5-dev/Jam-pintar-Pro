# FIX225 - Cuaca akurat dan real time, dibacakan asisten suara

- OpenMeteo.kt (baru): mengambil kondisi saat ini, prakiraan per jam, dan harian (3 hari) dari Open-Meteo. Jika gagal, jalur lama (Open-Meteo lama, lalu wttr.in) tetap dipakai.
- InfoCuaca.kt (baru, logika murni): menyusun kalimat: kondisi, suhu dan terasa, kelembapan, angin, UV, peluang hujan 6 jam ke depan, rentang suhu hari ini.
- Asisten suara memahami fokus: hujan, angin, suhu, kelembapan, UV; dan hari: hari ini, besok, lusa. Contoh: "apakah besok hujan", "cuaca hari ini", "seberapa kencang angin".
- Peringatan dini BMKG ditambahkan untuk hari ini (InfoBmkg.peringatanSingkat), disebut "Sumber: BMKG".
- Data model Open-Meteo adalah prakiraan model, bukan pengamatan stasiun; ini disebutkan dalam keluaran.
- Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Logika murni sudah diuji dengan kotlinc.
