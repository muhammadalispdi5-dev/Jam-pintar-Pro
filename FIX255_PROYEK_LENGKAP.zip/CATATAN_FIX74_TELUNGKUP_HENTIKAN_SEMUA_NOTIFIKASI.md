# FIX74 — Telungkupkan HP untuk Menghentikan Semua Suara Notifikasi

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX73 (Equalizer diperkaya).

## Sebelumnya
Gerakan telungkup hanya menghentikan azan terjadwal di `PrayerAlarmService` (tidak untuk pengingat awal, tidak untuk ucapan, tidak untuk fitur lain).

## Sekarang
Berkas baru **`PembungkamTelungkup.kt`**: satu pusat pendeteksi. Setiap sumber suara mendaftar selama berbunyi; sensor menyala hanya selama ada yang terdaftar. Sakelar lama (`stop_azan_face_down`, bawaan aktif) tetap dipakai, sehingga pilihan pengguna tidak hilang.

Yang kini dapat dihentikan dengan menelungkupkan HP:
- Azan, semua pengingat sholat (pengingat awal, Imsak, Terbit, Dhuha, sahur, berbuka), termasuk ucapan pengingat. Tes suara tetap dikecualikan.
- Pengumuman baterai (lemah, kritis, penuh beserta pengulangannya, pasang/cabut charger) dan pengumuman jam/tanggal beserta melodi awal/akhirnya.
- Pengumuman pemanggil: panggilan telepon/WhatsApp, pesan, dan notifikasi aplikasi lain yang dibacakan, termasuk ulangannya. Melodi akhir tidak dibunyikan setelah dibungkam.
- Notifikasi pengingat membaca Al-Qur'an (Khatam): dalam 20 detik pertama, bunyi/getar dihentikan dan notifikasi disingkirkan.
- Semua melodi (`Melodi`) dan getar aplikasi yang sedang berjalan ikut dihentikan.

## Aturan gerakan
HP harus lebih dulu terdeteksi **tidak telungkup** minimal 0,3 detik, lalu telungkup datar sekitar 0,65 detik. Akibatnya HP yang memang sudah tergeletak telungkup tidak langsung membungkam suara yang baru mulai; angkat lalu telungkupkan lagi untuk menghentikannya. (Sebelumnya azan akan terpotong dalam sekitar 0,65 detik bila HP sudah telungkup.)

## Tidak termasuk (disengaja)
Audio yang dimulai sendiri oleh pengguna: pemutar murattal Khatam, panduan kiblat, pemandu jalan, lokasi terkini, dan tombol Jam/Kalender/Beritahu Saya.

## Teks pengaturan
Sakelar di Pengaturan Sholat kini berjudul "Hentikan azan dan semua suara notifikasi dengan menelungkupkan HP", dengan penjelasan dan terjemahan Inggris yang diperbarui.

## Pemeriksaan dan batas
- `tools/verify_project.py`: LULUS; kurung `{}` dan `[]` seimbang di semua berkas yang diubah.
- `tools/verify_final.py` GAGAL pada butir "Kontrol streaming murattal" — gagal juga pada FIX72 asli (audit lama), bukan akibat perubahan ini.
- BELUM dikompilasi dan BELUM diuji di perangkat.
- Notifikasi Khatam bersifat usaha terbaik: proses aplikasi bisa dimatikan sistem setelah notifikasi diterbitkan. Notifikasi aplikasi lain (WhatsApp, dll.) tidak dikendalikan aplikasi ini; yang dihentikan hanyalah pembacaannya oleh aplikasi.
