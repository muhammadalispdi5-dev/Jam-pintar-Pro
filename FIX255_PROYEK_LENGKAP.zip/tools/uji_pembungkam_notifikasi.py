#!/usr/bin/env python3
"""Uji penghentian suara notifikasi dengan tombol volume/telungkup (FIX124).

1. Port logika pemantau volume (siaran + polling) dari PembungkamTelungkup.kt dan skenario tekanan tombol.
2. Kontrak sumber: semua jalur suara notifikasi terdaftar pada PembungkamTelungkup.
Jalankan: python3 tools/uji_pembungkam_notifikasi.py
"""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
KT = ROOT / "app/src/main/java/com/novan/bateraibicara"
gagal = []
def cek(nama, ok):
    if not ok: gagal.append(nama)

# ---------- 1. port logika ----------
SALURAN = [0, 1, 2, 3, 4, 5, 10]
GRACE_MS = 1200

def terima_siaran(jenis, nilai, sebelum, sejak_ms):
    """Port penerima siaran FIX124: semua jenis saluran, hanya bila nilai benar-benar berubah, setelah masa tenang."""
    if jenis < 0 or nilai < 0 or sebelum < 0 or nilai == sebelum: return False
    if sejak_ms < GRACE_MS: return False
    return True

def poll(awal, sekarang, sejak_ms):
    """Port satu putaran polling: kembalikan (saluran, nilai_awal) bila ada perubahan setelah masa tenang."""
    if sejak_ms < GRACE_MS: return None
    for s in SALURAN:
        if awal.get(s, -1) < 0: continue
        if sekarang.get(s, -1) >= 0 and sekarang[s] != awal[s]: return (s, awal[s])
    return None

cek("siaran: saluran aksesibilitas (10) kini dikenali", terima_siaran(10, 5, 6, 3000))
cek("siaran: saluran panggilan (0) kini dikenali", terima_siaran(0, 4, 5, 3000))
cek("siaran: tidak berubah diabaikan", not terima_siaran(4, 7, 7, 3000))
cek("siaran: masa tenang awal diabaikan", not terima_siaran(4, 6, 7, 500))
base = {0: 5, 1: 5, 2: 5, 3: 8, 4: 6, 5: 5, 10: 7}
turun = dict(base); turun[10] = 6
cek("polling: perubahan volume aksesibilitas terdeteksi", poll(base, turun, 3000) == (10, 7))
naik = dict(base); naik[4] = 7
cek("polling: perubahan volume alarm terdeteksi dan nilai awal dikembalikan", poll(base, naik, 3000) == (4, 6))
cek("polling: tanpa perubahan tidak memicu", poll(base, dict(base), 3000) is None)
cek("polling: masa tenang awal tidak memicu", poll(base, turun, 400) is None)
tak_valid = dict(base); tak_valid[10] = -1
cek("polling: saluran tak terbaca diabaikan", poll(base, tak_valid, 3000) is None)
# batas yang diketahui: tombol naik saat volume sudah maksimum tidak mengubah nilai sehingga tidak terlihat
maks = dict(base); maks[4] = 6
cek("batas diketahui: tekan naik saat maksimum tidak terlihat (dicatat di CATATAN)", poll(base, maks, 3000) is None)

# ---------- 2. kontrak sumber ----------
def baca(n): return (KT / n).read_text(encoding="utf-8")
pt = baca("PembungkamTelungkup.kt")
cek("penerima siaran menerima semua jenis saluran", "jenis < 0 || nilai < 0" in pt and "jenis !in 1..5" not in pt)
cek("polling volume tersedia", "private fun nyalakanPollVolume" in pt and "saluranPantau = intArrayOf(0, 1, 2, 3, 4, 5, 10)" in pt)
cek("polling dimatikan bersama pemantau", "pemantauPoll?.let { handler.removeCallbacks(it) }" in pt)
cek("polling dinyalakan bersama pemantau volume", "nyalakanPollVolume(ctx)" in pt)
hs = baca("HafalanSrsReceiver.kt")
cek("pengingat hafalan terdaftar di pembungkam", 'PembungkamTelungkup.mulai(context, "hafalan_srs_notif"' in hs)
bs = baca("BeritahuSayaActivity.kt")
cek("pengumuman widget dapat dibungkam", bs.count("bisaDibungkam = true") == 2)
cek("pengumuman widget menangani tombol volume", "bungkamDariTombolVolume(this)" in bs and "override fun dispatchKeyEvent" in bs)
cek("pengumuman widget menutup diri saat dibungkam", "PembungkamTelungkup.generasi != generasiBungkamAwal" in bs)

# audit otomatis: kanal notifikasi yang berbunyi harus terdaftar
audit = []
for f in sorted(KT.glob("*.kt")):
    s = f.read_text(encoding="utf-8")
    # SuaraPengingat hanya pembuat kanal dinamis; pemanggil receiver yang
    # benar-benar menampilkan notifikasi juga memasang PembungkamTelungkup.
    if f.name == "SuaraPengingat.kt":
        continue
    for m in re.finditer(r"NotificationChannel\(", s):
        potong = s[m.start(): m.start() + 700]
        berbunyi = re.search(r"IMPORTANCE_(DEFAULT|HIGH)", potong) is not None
        senyap = "setSound(null" in s[m.start(): m.start() + 900]
        terdaftar = "PembungkamTelungkup.mulai(" in s
        audit.append((f.name, "berbunyi" if berbunyi and not senyap else "senyap/rendah", terdaftar))
        if berbunyi and not senyap and not terdaftar:
            cek("kanal berbunyi tanpa pembungkam: " + f.name, False)
print("Audit kanal notifikasi:")
for nama, jenis, daftar in audit:
    print("  %-34s %-15s pembungkam=%s" % (nama, jenis, "ya" if daftar else "tidak"))

if gagal:
    print("UJI PEMBUNGKAM NOTIFIKASI: GAGAL"); [print(" -", g) for g in gagal]; sys.exit(1)
print("UJI PEMBUNGKAM NOTIFIKASI: LULUS (port logika + kontrak sumber)")
