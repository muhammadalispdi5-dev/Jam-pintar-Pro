import com.novan.bateraibicara.*
import com.novan.bateraibicara.HitungWaris.Ahli
import com.novan.bateraibicara.HitungWaris.Masukan

var gagal = 0
fun cek(nama: String, m: Masukan, vararg harap: Pair<Ahli, String>) {
    val h = HitungWaris.hitung(m)
    val got = h.bagian.associate { it.ahli to it.total.toString() }
    val exp = harap.toMap().mapValues { it.value }
    var total = Pecahan.NOL
    for (b in h.bagian) total = total + b.total
    val ok = got == exp && (total == Pecahan.SATU || h.sisaTakTerbagi.positif())
    if (!ok) { gagal++; println("GAGAL $nama\n  dapat=$got\n  harap=$exp total=$total") } else println("ok  $nama")
}
fun main() {
    cek("istri+2AL+1AP", Masukan(istri = 1, anakL = 2, anakP = 1), Ahli.ISTRI to "1/8", Ahli.ANAK_L to "7/20".let{"7/10"}, Ahli.ANAK_P to "7/40".let{"7/40"})
    cek("suami+ibu+ayah umariyatain", Masukan(suami = 1, ibu = 1, ayah = 1), Ahli.SUAMI to "1/2", Ahli.IBU to "1/6", Ahli.AYAH to "1/3")
    cek("istri+ibu+ayah", Masukan(istri = 1, ibu = 1, ayah = 1), Ahli.ISTRI to "1/4", Ahli.IBU to "1/4", Ahli.AYAH to "1/2")
    cek("suami+2SKP aul", Masukan(suami = 1, skP = 2), Ahli.SUAMI to "3/7", Ahli.SK_P to "4/7")
    cek("akdariyah", Masukan(suami = 1, ibu = 1, kakek = 1, skP = 1), Ahli.SUAMI to "1/3", Ahli.IBU to "2/9", Ahli.KAKEK to "8/27", Ahli.SK_P to "4/27")
    cek("suami+ibu+2seibu", Masukan(suami = 1, ibu = 1, sbL = 1, sbP = 1), Ahli.SUAMI to "1/2", Ahli.IBU to "1/6", Ahli.SB_L to "1/6", Ahli.SB_P to "1/6")
    cek("AP+ibu+ayah", Masukan(anakP = 1, ibu = 1, ayah = 1), Ahli.ANAK_P to "1/2", Ahli.IBU to "1/6", Ahli.AYAH to "1/3")
    cek("radd AP+ibu", Masukan(anakP = 1, ibu = 1), Ahli.ANAK_P to "3/4", Ahli.IBU to "1/4")
    cek("minbariyah", Masukan(istri = 1, anakP = 2, ayah = 1, ibu = 1), Ahli.ISTRI to "1/9", Ahli.ANAK_P to "16/27", Ahli.AYAH to "4/27", Ahli.IBU to "4/27")
    cek("kakek+1SKL", Masukan(kakek = 1, skL = 1), Ahli.KAKEK to "1/2", Ahli.SK_L to "1/2")
    cek("kakek+3SKL", Masukan(kakek = 1, skL = 3), Ahli.KAKEK to "1/3", Ahli.SK_L to "2/3")
    cek("AP+CP+ayah", Masukan(anakP = 1, cucuP = 1, ayah = 1), Ahli.ANAK_P to "1/2", Ahli.CUCU_P to "1/6", Ahli.AYAH to "1/3")
    cek("SKP+SAP radd", Masukan(skP = 1, saP = 1), Ahli.SK_P to "3/4", Ahli.SA_P to "1/4")
    cek("AP+SKP", Masukan(anakP = 1, skP = 1), Ahli.ANAK_P to "1/2", Ahli.SK_P to "1/2")
    cek("ayah blokir kakek+saudara", Masukan(ayah = 1, kakek = 1, skL = 2, ibu = 1), Ahli.AYAH to "5/6", Ahli.IBU to "1/6")
    cek("2AP blokir CP", Masukan(anakP = 2, cucuP = 1, ibu = 1), Ahli.ANAK_P to "8/10".let{"4/5"}.let{"4/5"}, Ahli.IBU to "1/5")
    cek("istri saja radd", Masukan(istri = 1), Ahli.ISTRI to "1")
    cek("4 istri+AL", Masukan(istri = 4, anakL = 1), Ahli.ISTRI to "1/8", Ahli.ANAK_L to "7/8")
    cek("nenek ibu+ nenek ayah", Masukan(nenekIbu = 1, nenekAyah = 1, anakL = 1), Ahli.NENEK_IBU to "1/12", Ahli.NENEK_AYAH to "1/12", Ahli.ANAK_L to "5/6")
    cek("saudara kandung L+P", Masukan(skL = 1, skP = 1), Ahli.SK_L to "2/3", Ahli.SK_P to "1/3")
    cek("2SKP+SAL", Masukan(skP = 2, saL = 1), Ahli.SK_P to "2/3", Ahli.SA_L to "1/3")
    cek("kakek+SKP tunggal", Masukan(kakek = 1, skP = 1), Ahli.KAKEK to "2/3", Ahli.SK_P to "1/3")
    println(if (gagal == 0) "SEMUA LULUS" else "GAGAL: $gagal")
}
