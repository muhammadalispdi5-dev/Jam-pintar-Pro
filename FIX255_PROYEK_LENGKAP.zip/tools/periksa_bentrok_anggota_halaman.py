#!/usr/bin/env python3
"""Mencegah galat kompilasi "'x' hides member of supertype 'Halaman' and needs an 'override' modifier".

Galat itu muncul bila sebuah halaman (turunan Halaman) mendeklarasikan fungsi atau properti dengan nama dan jumlah
parameter yang sama dengan anggota Halaman yang tidak private, tetapi tanpa modifier override. Contoh nyata (FIX160):
Halaman menambahkan tr(indonesia, english) sementara JamActivity, KhatamActivity, dan TaarufDoaActivity masih punya
private fun tr(id, en) sendiri.

Pemeriksaan ini statis dan kasar (berbasis indentasi kelas tingkat atas). Kompilasi sesungguhnya tetap berlaku.
"""
import re, sys, pathlib

JAVA = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/java/com/novan/bateraibicara"
RE_DEKL = re.compile(r'^    ((?:(?:protected|public|internal|open|final|abstract|override|private|lateinit|const|inline)\s+)*)(fun|val|var)\s+(?:<[^>]*>\s*)?([A-Za-z_][A-Za-z0-9_]*)\s*(\(([^)]*)\))?')


def jumlah_param(teks):
    if teks is None:
        return None
    teks = teks.strip()
    if not teks:
        return 0
    # hitung koma tingkat atas (abaikan tipe generik dan lambda sederhana)
    kedalaman = 0
    n = 1
    for c in teks:
        if c in "<([":
            kedalaman += 1
        elif c in ">)]":
            kedalaman -= 1
        elif c == "," and kedalaman == 0:
            n += 1
    return n


def anggota(path):
    hasil = []
    for baris in path.read_text(encoding="utf-8").split("\n"):
        m = RE_DEKL.match(baris)
        if m:
            mod, jenis, nama, _, param = m.groups()
            hasil.append((nama, jenis, set(mod.split()), jumlah_param(param) if jenis == "fun" else None))
    return hasil


def main():
    halaman = [a for a in anggota(JAVA / "Halaman.kt") if "private" not in a[2]]
    kunci = {(nama, jenis, n) for nama, jenis, _, n in halaman}
    salah = []
    for f in sorted(JAVA.glob("*.kt")):
        if f.name == "Halaman.kt":
            continue
        s = f.read_text(encoding="utf-8")
        if not re.search(r'class\s+\w+\s*:\s*Halaman\(\)', s):
            continue
        for nama, jenis, mod, n in anggota(f):
            if "override" in mod:
                continue
            if (nama, jenis, n) in kunci:
                salah.append(f"{f.name}: '{nama}' ({jenis}, parameter={n}) menyembunyikan anggota Halaman tanpa 'override'")
    if salah:
        print("PEMERIKSAAN BENTROK ANGGOTA HALAMAN: GAGAL")
        for x in salah:
            print(" -", x)
        sys.exit(1)
    print("PEMERIKSAAN BENTROK ANGGOTA HALAMAN: LULUS (%d anggota Halaman non-private diperiksa)" % len(kunci))


if __name__ == "__main__":
    main()
