import math, random, sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from simulasi_goncangan_detektor import Detektor
def sinyal(segmen, dur_ms, dt=20, noise=0.3, seed=1, sinus=()):
    random.seed(seed); out=[]
    for t in range(0,dur_ms,dt):
        x=random.gauss(0,noise); y=random.gauss(0,noise); z=9.8+random.gauss(0,noise)
        for (t0,w,amp,ax) in segmen:
            if t0<=t<t0+w:
                f=math.sin(math.pi*(t-t0)/w)*amp
                if ax==0: x+=f
                elif ax==1: y+=f
                else: z+=f
        for (t0,t1,amp,hz) in sinus:
            if t0<=t<t1: x+=amp*math.sin(2*math.pi*hz*(t-t0)/1000.0)
        out.append((x,y,z,t))
    return out
def jalankan(sig,**kw):
    d=Detektor(**kw); h=[]
    for x,y,z,t in sig:
        if d.proses(x,y,z,t)=='POLA': h.append(t)
    return h
def pulsa(mulai,n,jeda,amp=15,w=90): return [(mulai+i*jeda,w,amp*(1 if i%2==0 else -1),0) for i in range(n)]
uji=[]
def cek(nama,sig,harapan,**kw):
    h=jalankan(sig,**kw); ok=len(h)==harapan; uji.append(ok)
    print("OK   " if ok else "GAGAL", nama, "->", h)

cek("tiga hentakan cepat dari diam",sinyal(pulsa(2000,3,260),5000),1)
cek("tiga hentakan (jeda 180ms)",sinyal(pulsa(2000,3,180),5000),1)
cek("tiga hentakan (jeda 400ms)",sinyal(pulsa(2000,3,400),5000),1)
cek("dua hentakan",sinyal(pulsa(2000,2,260),5000),0)
cek("satu hentakan",sinyal(pulsa(2000,1,260),5000),0)
cek("lima hentakan -> sekali",sinyal(pulsa(2000,5,250),6000),1)
cek("tiga hentakan lambat (jeda 700ms)",sinyal(pulsa(2000,3,700),6000),0)
cek("berjalan amp6 550ms",sinyal(pulsa(0,18,550,amp=6,w=150),10000),0)
cek("berjalan cepat amp8 450ms",sinyal(pulsa(0,22,450,amp=8,w=150),10000),0)
angkat=[(1000,400,8,1),(1500,300,-6,1)]
cek("angkat HP lalu langsung goyang (ketat)",sinyal(angkat+pulsa(1900,3,260),5000),0)
cek("angkat HP, diam 1 s, goyang 3x",sinyal(angkat+pulsa(3200,3,260),6000),1)
jalan=pulsa(0,10,550,amp=6,w=150)
cek("berjalan+goyang kuat 3x (ketat)",sinyal(jalan+pulsa(5600,3,250,amp=20),9000),0)
cek("berjalan+goyang kuat 3x (longgar)",sinyal(jalan+pulsa(5600,3,250,amp=20),9000),1,longgar=True)
cek("berjalan saja (longgar)",sinyal(pulsa(0,18,550,amp=6,w=150),10000),0,longgar=True)
cek("berlari amp14 330ms (longgar)",sinyal(pulsa(0,30,330,amp=14,w=120),10000),0,longgar=True)
cek("berlari amp14 330ms (ketat)",sinyal(pulsa(0,30,330,amp=14,w=120),10000),0)
cek("dua urutan terpisah 10 s",sinyal(pulsa(1500,3,260)+pulsa(11500,3,260),14000),2)
cek("dua urutan terpisah 4 s (cooldown)",sinyal(pulsa(1500,3,260)+pulsa(5500,3,260),9000),1)
cek("ringan amp5 sens1",sinyal(pulsa(2000,3,260,amp=5),5000),0,sens=1)
cek("ringan amp5 sens10",sinyal(pulsa(2000,3,260,amp=5),5000),1,sens=10)
cek("meletakkan HP (hentakan tunggal)",sinyal([(2000,60,25,2)],5000),0)
cek("dua ketukan di meja 400ms",sinyal([(2000,40,20,2),(2400,40,20,2)],5000),0)
# goyang sinus realistis: 3 Hz, amp 18 -> puncak magnitudo tiap ~167 ms
cek("goyang sinus 3Hz 0,5 s (3 puncak)",sinyal([],6000,sinus=[(2000,2500,18,3)]),1)
cek("goyang sinus 3Hz 0,17 s (1 puncak)",sinyal([],6000,sinus=[(2000,2170,18,3)]),0)
cek("goyang sinus 3Hz 1,0 s (6 puncak)",sinyal([],6000,sinus=[(2000,3000,18,3)]),1)
cek("goyang sinus 5Hz 1,0 s",sinyal([],6000,sinus=[(2000,3000,18,5)]),1)
cek("ayunan lambat sinus 1,2Hz 3 s",sinyal([],7000,sinus=[(2000,5000,12,1.2)]),0)
cek("tremor/getaran kecil sinus 8Hz amp3",sinyal([],7000,sinus=[(2000,5000,3,8)]),0)
cek("lima hentakan (longgar: tepat tiga)",sinyal(pulsa(2000,5,250,amp=20),6000),0,longgar=True)
cek("tiga hentakan kuat (longgar)",sinyal(pulsa(2000,3,250,amp=20),6000),1,longgar=True)
print("SEMUA LULUS" if all(uji) else "ADA YANG GAGAL", sum(uji),"/",len(uji))
