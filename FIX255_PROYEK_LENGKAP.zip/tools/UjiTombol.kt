import com.novan.bateraibicara.PemicuTombol
import com.novan.bateraibicara.PemicuTombol.Hasil
import com.novan.bateraibicara.PemicuTombol.Mode
fun main() {
    val U = 24; val B = 25
    var gagal = 0
    fun cek(n: String, ok: Boolean) { println((if (ok) "OK   " else "GAGAL") + " " + n); if (!ok) gagal++ }
    fun baru(m: Mode, tahan: Long = 800) = PemicuTombol().also { it.mode = m; it.tahanMs = tahan }

    // Tahan dengan peristiwa pengulangan
    for ((nama, mode, kode) in listOf(Triple("atas", Mode.TAHAN_ATAS, U), Triple("bawah", Mode.TAHAN_BAWAH, B))) {
        val p = baru(mode)
        val h0 = p.proses(kode, true, 0, 0)
        var picu = 0; var tPicu = -1L
        var t = 500L
        while (t <= 1500) { val h = p.proses(kode, true, ((t - 450) / 50).toInt(), t); if (h == Hasil.PICU) { picu++; tPicu = t }; t += 50 }
        cek("tahan $nama: tekan pertama lewat", h0 == Hasil.LEWAT)
        cek("tahan $nama: picu sekali pada >=800ms (t=$tPicu)", picu == 1 && tPicu in 800..850)
        cek("tahan $nama: lepas ditelan", p.proses(kode, false, 0, 1550) == Hasil.TELAN)
        cek("tahan $nama: tekan singkat berikutnya lewat", p.proses(kode, true, 0, 3000) == Hasil.LEWAT && p.proses(kode, false, 0, 3100) == Hasil.LEWAT)
    }
    // FIX228: tahan TANPA peristiwa pengulangan sama sekali (pewaktu)
    for ((nama, mode, kode) in listOf(Triple("atas", Mode.TAHAN_ATAS, U), Triple("bawah", Mode.TAHAN_BAWAH, B))) {
        val p = baru(mode)
        p.proses(kode, true, 0, 1000)
        cek("tahan $nama tanpa pengulangan: sebelum batas belum picu", !p.cekTahan(1500))
        cek("tahan $nama tanpa pengulangan: pewaktu memicu", p.cekTahan(1830))
        cek("tahan $nama tanpa pengulangan: tidak memicu dua kali", !p.cekTahan(1900))
        cek("tahan $nama tanpa pengulangan: lepas ditelan", p.proses(kode, false, 0, 2500) == Hasil.TELAN)
        cek("tahan $nama: tombol tahan dikenali", p.tombolTahan(kode) && !p.tombolTahan(if (kode == U) B else U))
    }
    run {
        val p = baru(Mode.TAHAN_ATAS)
        p.proses(U, true, 0, 0); p.proses(U, false, 0, 300)
        cek("tahan: dilepas sebelum batas, pewaktu tidak memicu", !p.cekTahan(900))
    }
    run {
        val p = baru(Mode.TAHAN_ATAS)
        p.proses(U, true, 0, 0); p.proses(U, true, 5, 900) // picu lewat pengulangan
        cek("tahan: setelah picu lewat pengulangan, pewaktu tidak memicu lagi", !p.cekTahan(1000))
    }
    run {
        // lepas hilang: tekan berikutnya tetap bisa memicu
        val p = baru(Mode.TAHAN_ATAS)
        p.proses(U, true, 0, 0); p.cekTahan(900)
        p.proses(U, true, 0, 5000)
        cek("tahan: setelah UP hilang, tekan baru bisa memicu lagi", p.cekTahan(5900))
    }
    run {
        val p = baru(Mode.TAHAN_ATAS, 1200)
        p.proses(U, true, 0, 0); p.proses(U, false, 0, 1000)
        cek("tahan 1200: dilepas pada 1000ms tidak memicu", !p.cekTahan(1300))
    }
    run {
        val p = baru(Mode.TAHAN_ATAS)
        p.proses(B, true, 0, 0)
        cek("tahan atas: volume bawah tidak memicu", !p.cekTahan(1500))
    }
    // Dua volume bersamaan (waktu kedatangan, tanpa downTime)
    run {
        val p = baru(Mode.DUA_VOLUME)
        val a = p.proses(U, true, 0, 100)
        val b = p.proses(B, true, 0, 300)
        cek("dua volume bersamaan memicu", a == Hasil.LEWAT && b == Hasil.PICU)
        cek("dua volume: lepas ditelan lalu reset", p.proses(U, false, 0, 600) == Hasil.TELAN && p.proses(B, false, 0, 620) == Hasil.TELAN)
        cek("dua volume: satu tombol saja tidak memicu", p.proses(U, true, 0, 2000) == Hasil.LEWAT)
        p.proses(U, false, 0, 2050)
        p.proses(U, true, 0, 3000); val d = p.proses(B, true, 0, 4000)
        cek("dua volume: selisih 1000ms tidak memicu", d == Hasil.LEWAT)
    }
    run {
        val p = baru(Mode.DUA_VOLUME)
        p.proses(B, true, 0, 100); val b = p.proses(U, true, 0, 150)
        cek("dua volume: urutan bawah lalu atas juga memicu", b == Hasil.PICU)
    }
    run {
        // pengulangan tombol pertama tiba sebelum tombol kedua
        val p = baru(Mode.DUA_VOLUME)
        p.proses(U, true, 0, 0); p.proses(U, true, 1, 500)
        cek("dua volume: pengulangan pertama lalu kedua tekan memicu (dalam 800ms)", p.proses(B, true, 0, 700) == Hasil.PICU)
    }
    run {
        // peristiwa lepas hilang untuk satu tombol; tekanan baru pasangan tetap sah
        val p = baru(Mode.DUA_VOLUME)
        p.proses(U, true, 0, 0)               // UP hilang
        p.proses(U, true, 0, 6000); val b = p.proses(B, true, 0, 6100)
        cek("dua volume: UP hilang tidak merusak tekanan berikutnya", b == Hasil.PICU)
    }
    // Dua kali
    run {
        val p = baru(Mode.DUA_KALI_ATAS)
        val a = p.proses(U, true, 0, 0); p.proses(U, false, 0, 80)
        val b = p.proses(U, true, 0, 300)
        cek("dua kali atas memicu pada tekan kedua", a == Hasil.LEWAT && b == Hasil.PICU)
        p.proses(U, false, 0, 380)
        cek("dua kali: tekan tunggal setelah jeda lewat", p.proses(U, true, 0, 5000) == Hasil.LEWAT)
        p.proses(U, false, 0, 5050)
        cek("dua kali: jeda 900ms tidak memicu", p.proses(U, true, 0, 5900) == Hasil.LEWAT)
    }
    run {
        val p = baru(Mode.NONAKTIF)
        cek("nonaktif: semua lewat", p.proses(U, true, 3, 900) == Hasil.LEWAT && !p.cekTahan(5000))
        p.mode = Mode.AKSESIBILITAS
        cek("aksesibilitas: tombol fisik lewat", p.proses(U, true, 3, 900) == Hasil.LEWAT)
        p.mode = Mode.TAHAN_ATAS
        cek("kode lain lewat", p.proses(26, true, 3, 900) == Hasil.LEWAT)
    }
    println(if (gagal == 0) "SEMUA LULUS" else "GAGAL: $gagal")
    if (gagal > 0) kotlin.system.exitProcess(1)
}
