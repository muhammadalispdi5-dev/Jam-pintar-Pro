#!/usr/bin/env python3
"""Uji kontrak sumber FIX118: jendela Khatam yang disembunyikan untuk pemutaran latar harus selalu bisa dipulihkan.
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys
kh = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt").read_text(encoding="utf-8")
gagal = []
def cek(n, k):
    if not k: gagal.append(n)
cek("ada fungsi pemulihan", "private fun pulihkanJendelaKhatam()" in kh)
cek("pemulihan mengembalikan konten terlihat", "root.visibility = View.VISIBLE" in kh)
cek("pemulihan mengembalikan alpha jendela", "atribut.alpha = 1f" in kh)
cek("pemulihan memberi latar jendela opak", "ColorDrawable(warnaLatar())" in kh)
cek("onNewIntent non-latar memulihkan", "pulihkanJendelaKhatam()\n        }\n        jalankanPerintahDariLuar()" in kh)
cek("onResume memulihkan setelah diparkir", "if (jendelaTersembunyi && !latarMenunggu) pulihkanJendelaKhatam()" in kh)
cek("onStop menandai sudah diparkir", "override fun onStop()" in kh and "latarMenunggu = false\n        super.onStop()" in kh)
cek("jaring pengaman 6 detik", "}, 6000L)" in kh and "jendelaTersembunyi && sedangResumed" in kh)
cek("pembuatan ulang sistem tidak mengulang perintah", "if (savedInstanceState != null) {\n            intent?.removeExtra(EXTRA_PERINTAH_SUARA)" in kh)
# setiap tempat yang menyembunyikan harus punya pasangan pemulih
cek("sembunyikan memasang bendera", "jendelaTersembunyi = true" in kh and "latarMenunggu = true" in kh)
if gagal:
    print("UJI PEMULIHAN JENDELA KHATAM: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI PEMULIHAN JENDELA KHATAM: LULUS (kontrak sumber)")
