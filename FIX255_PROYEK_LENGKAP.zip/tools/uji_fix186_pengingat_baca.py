#!/usr/bin/env python3
"""Uji FIX186: pengingat membaca Al-Qur'an (beberapa waktu, hari, suara alarm/notifikasi/ucapan/berkas, tunda, tes) + simulasi jadwal."""
from pathlib import Path
import datetime, re, sys
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
rd = lambda n: (R / n).read_text(encoding="utf-8")
k, pb, rc, bt, sp, ex = rd("KhatamActivity.kt"), rd("PengingatBaca.kt"), rd("KhatamReminderReceiver.kt"), rd("KhatamReminderBootReceiver.kt"), rd("SuaraPengingat.kt"), rd("ExactAlarmPermissionReceiver.kt")
gagal = []
for perlu, nama, teks in [
    ("dialogWaktuPengingat()", "dialog waktu", k), ("NumberPicker", "pemilih jam menit ramah pembaca layar", k), ("ACCESSIBILITY_LIVE_REGION_POLITE", "pengumuman waktu terpilih", k), ("dialogHariPengingat()", "dialog hari", k), ("AKSI_UJI", "tes pengingat", k + rc),
    ('"notif"', "mode nada notifikasi", k + sp), ("AKSI_TUNDA_KLIK", "tombol tunda", rc), ("setExactAndAllowWhileIdle", "alarm tepat", pb),
    ("canScheduleExactAlarms", "cadangan tanpa izin alarm tepat", pb), ("PengingatBaca.jadwalkan", "jadwal ulang saat boot", bt),
    ("PengingatBaca.jadwalkan", "jadwal ulang saat izin alarm berubah", ex), ("PengingatBaca.jadwalkan(context)", "jadwal kejadian berikutnya", rc),
    ("Intent.ACTION_OPEN_DOCUMENT", "berkas suara sendiri", k), ("PengingatBaca.batalkan(this)", "alarm dibatalkan saat reset", k),
    ('"pengingat_waktu"', "kunci waktu ikut reset", k)]:
    if perlu not in teks: gagal.append("hilang: " + nama)
# AlertDialog menyembunyikan daftar pilihan bila setMessage dipakai bersama setItems
_L = k.split("\n"); _mulai = [i for i, l in enumerate(_L) if "AlertDialog.Builder(" in l]
for _i, _b in enumerate(_mulai):
    _e = min([x for x in _mulai if x > _b] + [_b + 45]); _c = "\n".join(_L[_b:min(_e, _b + 45)])
    _m = re.search(r"\.show\(\)|\.create\(\)", _c); _c = _c[:_m.end()] if _m else _c
    if ".setMessage(" in _c and re.search(r"\.set(Items|SingleChoiceItems|MultiChoiceItems)\(", _c): gagal.append("dialog dengan setMessage + daftar pilihan (daftar tidak tampil) pada baris %d" % (_b + 1))
if "TimePickerDialog(this" in k: gagal.append("masih memakai jam analog TimePickerDialog")
if "setInexactRepeating" in pb + rc + bt: gagal.append("masih memakai alarm berulang tidak tepat")
# simulasi berikutnya(): meniru logika Kotlin
def berikutnya(waktu, mask, now):
    if not waktu or mask == 0: return None
    for d in range(8):
        hari = now + datetime.timedelta(days=d)
        bit = (hari.isoweekday() % 7)  # Minggu=0 ... Sabtu=6
        if not mask & (1 << bit): continue
        for m in sorted(waktu):
            t = hari.replace(hour=m // 60, minute=m % 60, second=0, microsecond=0)
            if t > now: return t
    return None
n = datetime.datetime(2026, 11, 5, 15, 0)  # Kamis
cek = [((20 * 60,), 127, n, datetime.datetime(2026, 11, 5, 20, 0)),
       ((5 * 60, 20 * 60), 127, n, datetime.datetime(2026, 11, 5, 20, 0)),
       ((5 * 60, 14 * 60), 127, n, datetime.datetime(2026, 11, 6, 5, 0)),
       ((5 * 60,), 1 << 1, n, datetime.datetime(2026, 11, 9, 5, 0)),  # hanya Senin
       ((15 * 60,), 127, n, datetime.datetime(2026, 11, 6, 15, 0)),
       ((), 127, n, None), ((600,), 0, n, None)]
for w, mask, now, harap in cek:
    h = berikutnya(w, mask, now)
    if h != harap: gagal.append("simulasi jadwal salah: %s %s -> %s (harap %s)" % (w, mask, h, harap))
print("UJI FIX186 PENGINGAT BACA:", "GAGAL" if gagal else "LULUS", *gagal, sep="\n- " if gagal else " ")
sys.exit(1 if gagal else 0)
