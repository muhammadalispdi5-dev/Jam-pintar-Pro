#!/usr/bin/env python3
"""Uji FIX152: pilih surah/ayat dan pindah ayat sebelumnya/berikutnya pada Koreksi hafalan dengan suara.
Bagian 1: port Python dari KhatamActivity.ayatTetangga memakai jumlah ayat 114 surah (jumlah total harus 6236).
Bagian 2: kontrak sumber Kotlin. Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys

AYAT = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6]

def tetangga(s, a, delta):
    jumlah = AYAT[s - 1]
    if delta < 0:
        if a > 1: return (s, a - 1)
        if s > 1: return (s - 1, AYAT[s - 2])
        return None
    if a < jumlah: return (s, a + 1)
    if s < 114: return (s + 1, 1)
    return None

gagal = []
def cek(n, k):
    if not k: gagal.append(n)

cek("114 surah dan total 6236 ayat", len(AYAT) == 114 and sum(AYAT) == 6236)
cek("dalam surah: maju", tetangga(2, 5, 1) == (2, 6))
cek("dalam surah: mundur", tetangga(2, 5, -1) == (2, 4))
cek("batas surah: maju 2:286 -> 3:1", tetangga(2, 286, 1) == (3, 1))
cek("batas surah: mundur 3:1 -> 2:286", tetangga(3, 1, -1) == (2, 286))
cek("batas surah: mundur 2:1 -> 1:7", tetangga(2, 1, -1) == (1, 7))
cek("awal Al-Qur'an tidak ada sebelumnya", tetangga(1, 1, -1) is None)
cek("akhir Al-Qur'an tidak ada berikutnya", tetangga(114, 6, 1) is None)
# Berjalan maju dari 1:1 harus melewati tepat 6236 ayat dan berakhir di 114:6; mundur kembali ke 1:1
n, pos = 1, (1, 1)
while True:
    nx = tetangga(*pos, 1)
    if nx is None: break
    pos = nx; n += 1
cek("maju menyusuri seluruh Al-Qur'an", n == 6236 and pos == (114, 6))
m = 1
while True:
    pv = tetangga(*pos, -1)
    if pv is None: break
    pos = pv; m += 1
cek("mundur menyusuri seluruh Al-Qur'an", m == 6236 and pos == (1, 1))

kh = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt").read_text(encoding="utf-8")
cek("kontrol hanya di luar sesi muraja'ah", "if (!sesiAktif()) isi.addView(bangunKontrolPilihAyatKoreksi())" in kh)
cek("gantiAyatKoreksi menolak saat sesi", "if (dialogKoreksiHafalan == null || sesiAktif()) return" in kh)
cek("pengenalan dan audio dihentikan saat berpindah", "batalkanPengenalanKoreksi()\n        hentikanAudio()" in kh)
cek("ayat baru disembunyikan untuk dibaca dari hafalan", "tampilkanPembaca()\n        sembunyikanAyatLatihan()" in kh)
cek("petunjuk diperbarui saat ayat berganti", "petunjukKoreksi?.text = teksPetunjukKoreksi()" in kh)
cek("tombol Mulai membaca dipulihkan", 'BUTTON_POSITIVE)?.text = tr("Mulai membaca", "Start reciting")' in kh)
cek("pilihSurah/pilihAyat memakai callback (tanpa duplikasi)", "private fun pilihSurah(batal: (() -> Unit)? = null, setelah: ((Int) -> Unit)? = null)" in kh and "private fun pilihAyat(surahTarget: Int = nomorSurah, awal: Int = nomorAyat, batal: (() -> Unit)? = null, setelah: ((Int) -> Unit)? = null)" in kh)
cek("setelah memilih surah, pengguna diminta memilih ayat (FIX165)", "pilihAyat(surahPilihan, 1, batal" in kh and "gantiAyatKoreksi(surahPilihan, ayatPilihan" in kh)
cek("pembaca memakai ayatTetangga", kh.count("ayatTetangga(") >= 3 and "nomorAyat < verses.length()) nomorAyat++" not in kh)
cek("putar audio manual dan otomatis", "putarAudioAyatKoreksiManual()" in kh and '"koreksi_putar_saat_pindah"' in kh)
cek("kunci putar otomatis ikut reset", '"koreksi_putar_saat_pindah", "hafalan_latihan_mandiri_aktif"' in kh)
cek("referensi petunjuk dibersihkan saat dialog ditutup", "petunjukKoreksi = null" in kh)
blok = kh[kh.index("// ===== FIX152"):kh.index("FIX102: memutar audio ayat yang benar")]
import re
cek("blok FIX152 tanpa teks telanjang (semua lewat tr)", not re.findall(r'(?:setTitle|setMessage|toast|setStatusKoreksi)\(\s*"', blok))
cek("blok FIX152 dua bahasa", blok.count("tr(") >= 19)
if gagal:
    print("UJI KOREKSI PILIH AYAT: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI KOREKSI PILIH AYAT: LULUS (port logika + kontrak sumber)")
