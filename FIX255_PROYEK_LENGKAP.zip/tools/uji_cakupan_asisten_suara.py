from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VOICE = ROOT / "app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt"
MAIN = ROOT / "app/src/main/java/com/novan/bateraibicara/MainActivity.kt"
TEXT = VOICE.read_text(encoding="utf-8")
MAIN_TEXT = MAIN.read_text(encoding="utf-8")

# Kategori utama yang tampil di halaman depan harus memiliki identitas fitur suara dan rute pembuka.
required = {
    "BATERAI": "BateraiActivity::class.java",
    "JAM": "JamActivity::class.java",
    "KALENDER": "KalenderActivity::class.java",
    "PEMANGGIL": "PemanggilActivity::class.java",
    "SHOLAT": "PrayerActivity::class.java",
    "LOKASI": "LokasiTerkiniActivity::class.java",
    "PEMANDU_JALAN": "PemanduJalanActivity::class.java",
    "KIBLAT": "QiblaActivity::class.java",
    "FASILITAS": "FasilitasTerdekatActivity::class.java",
    "DOA": "TaarufDoaActivity::class.java",
    "KHATAM": "KhatamActivity::class.java",
    "MODE_ACARA": "ModeAcaraActivity::class.java",
    "BAHASA": "BahasaActivity::class.java",
}
for feature, route in required.items():
    assert f"{feature}" in TEXT, f"Fitur {feature} belum tercantum pada penafsir suara"
    assert route in TEXT, f"Fitur {feature} belum memiliki rute pembuka {route}"

assert "Jenis.BATERAI_INFO -> bacakanBaterai()" in TEXT
assert "BatteryManager.EXTRA_LEVEL" in TEXT
assert "BatteryManager.EXTRA_PLUGGED" in TEXT
assert "bacakanBaterai" in TEXT
assert "PerintahSuara.Jenis.BUKA_FITUR" in TEXT
assert "perintah suara" in MAIN_TEXT.lower() or "beritahu saya" in MAIN_TEXT.lower()
print("UJI CAKUPAN ASISTEN SUARA: LULUS (13 kategori utama + informasi baterai + rute pembuka)")
