#!/usr/bin/env python3
"""Uji statis FIX185: setiap dialog sub menu pengaturan Khatam punya jalur Kembali (tombol dan tombol kembali sistem) ke induknya."""
from pathlib import Path
import re, sys
S = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt").read_text(encoding="utf-8").split("\n")
FUNGSI = ("dialogPengaturanHafalan dialogSaklarLatihanHafalan dialogPengaturanAudio pengaturanSaluranAudio pengaturanVolumeAudio "
          "pilihanPemutaranAudio pengaturanStereoMono pengaturanEqualizer dialogPilihPreset dialogPilihSlotKustom dialogEqualizerKustom "
          "dialogGema dialogEfekTambahan pengaturanModeHafalan dialogHafalanKelompok pilihAyatPerKelompok pilihUlangKelompok dialogAngka "
          "pengaturanJedaAntarAyat pengaturanTargetPemutaran pengaturanPengulanganAyat pengaturanKecepatanAudio pengaturanTarget "
          "tampilkanStatistik tampilkanRiwayat dialogPengingatCerdas dialogPengaturanMurajaah pilihUkuranSesiMurajaah pengaturanPengingat "
          "pilihJenisSuaraPengingat pengaturanAksesibilitas pilihJuzUntukUnduh").split()
mulai = [i for i, l in enumerate(S) if re.match(r"    (private |protected )?fun ", l)]
gagal = []
for n in FUNGSI:
    a = [i for i in mulai if re.match(r"\s*(private )?fun %s\(" % n, S[i])]
    if not a: gagal.append("fungsi tidak ditemukan: " + n); continue
    a = a[0]; b = min([x for x in mulai if x > a], default=len(S))
    badan = "\n".join(S[a:b])
    if not re.search(r"kembaliKe\(|kembaliKeInduk\(|kembaliKeBila\(|setOnCancelListener", badan):
        gagal.append("tanpa jalur kembali ke induk: " + n)
print("UJI FIX185 KEMBALI SUB MENU KHATAM:", "GAGAL" if gagal else "LULUS", *gagal, sep="\n- " if gagal else " ")
sys.exit(1 if gagal else 0)
