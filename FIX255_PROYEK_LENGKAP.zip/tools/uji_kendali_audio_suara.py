#!/usr/bin/env python3
"""Uji kontrak sumber FIX119: perintah suara berhenti/jeda/lanjut harus sampai ke pemutar yang sedang aktif (Khatam atau layanan).
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys
B = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
kh = (B / "KhatamActivity.kt").read_text(encoding="utf-8")
ps = (B / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
gagal = []
def cek(n, k):
    if not k: gagal.append(n)
cek("Khatam punya kendaliLatar", "fun kendaliLatar(aksi: String): Boolean" in kh)
cek("berhenti selalu ditangani bila Khatam ada", "if (aksi != KENDALI_BERHENTI && a.pemutar == null) return false" in kh)
cek("berhenti memanggil hentikanAudio", "KENDALI_BERHENTI -> hentikanAudio()" in kh)
cek("jeda hanya saat berbunyi", "KENDALI_JEDA -> { val p = pemutar; if (p != null && audioSiap && p.isPlaying) jedaLanjutAudio() }" in kh)
cek("lanjut hanya saat dijeda", "KENDALI_LANJUT -> { val p = pemutar; if (p != null && audioSiap && !p.isPlaying) jedaLanjutAudio() }" in kh)
blok = ps[ps.index("private fun kendaliQuran"):ps.index("private fun getar(")]
cek("kendaliQuran menghubungi Khatam", "KhatamActivity.kendaliLatar(kendaliKhatam)" in blok)
cek("berhenti tetap dikirim ke layanan", "aksi == PemutarQuranService.ACTION_BERHENTI || !ditanganiKhatam" in blok)
cek("jeda/lanjut tidak ke layanan bila Khatam memegang audio", "!ditanganiKhatam" in blok)
if gagal:
    print("UJI KENDALI AUDIO SUARA: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI KENDALI AUDIO SUARA: LULUS (kontrak sumber)")
