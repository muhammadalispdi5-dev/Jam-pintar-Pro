#!/usr/bin/env python3
"""Uji statis FIX167: saluran volume audio Khatam (media, alarm, dst.) terhubung ke menu, pemutar layar, pemutar latar, dan reset."""
from pathlib import Path
import sys
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
s = (R / "SaluranAudioKhatam.kt").read_text(encoding="utf-8")
k = (R / "KhatamActivity.kt").read_text(encoding="utf-8")
v = (R / "PemutarQuranService.kt").read_text(encoding="utf-8")
gagal = []
for usage in ("USAGE_ALARM", "USAGE_NOTIFICATION", "USAGE_NOTIFICATION_RINGTONE", "USAGE_ASSISTANCE_ACCESSIBILITY", "USAGE_VOICE_COMMUNICATION", "USAGE_ASSISTANCE_SONIFICATION", "USAGE_MEDIA"):
    if usage not in s: gagal.append("saluran hilang: " + usage)
for st in ("STREAM_ALARM", "STREAM_NOTIFICATION", "STREAM_RING", "STREAM_ACCESSIBILITY", "STREAM_VOICE_CALL", "STREAM_SYSTEM", "STREAM_MUSIC"):
    if st not in s: gagal.append("aliran hilang: " + st)
if "SaluranAudioKhatam.atribut(this)" not in k: gagal.append("pemutar layar Khatam belum memakai saluran")
if "SaluranAudioKhatam.atribut(applicationContext)" not in v: gagal.append("pemutar latar belum memakai saluran")
if "pengaturanSaluranAudio()" not in k or "volumeControlStream" not in k: gagal.append("menu atau tombol volume fisik belum terhubung")
if '"saluran_audio_idx"' not in k: gagal.append("reset pengaturan tidak memuat saluran")
if "Alarm volume" not in s or "Volume alarm" not in s: gagal.append("label dua bahasa hilang")
print("UJI FIX167 SALURAN AUDIO KHATAM:", "GAGAL" if gagal else "LULUS", *gagal, sep="\n- " if gagal else " ")
sys.exit(1 if gagal else 0)
