#!/usr/bin/env python3
"""Gagal bila ada resource string melebihi batas aapt2 (32767 byte UTF-8) yang membuat teks diganti STRING_TOO_LARGE."""
import glob, sys, xml.etree.ElementTree as ET
BATAS = 30000
gagal = []
for p in glob.glob('app/src/main/res/values*/*.xml'):
    for e in ET.parse(p).getroot():
        if e.tag == 'string':
            n = len(''.join(e.itertext()).encode('utf-8'))
            if n > BATAS:
                gagal.append((p, e.get('name'), n))
for g in gagal:
    print('TERLALU BESAR', *g)
print('PEMERIKSAAN UKURAN STRING: ' + ('GAGAL' if gagal else 'LULUS'))
sys.exit(1 if gagal else 0)
