#!/usr/bin/env python3
"""Cerminan Python dari pembersih nama libur (HariLibur.kt: rapikanNama, padanan bahasa, ucapanAkhir).

Memeriksa bahwa nama libur dari sumber daring tidak lagi memuat simbol atau singkatan yang dibaca harfiah oleh mesin suara.
Daftar padanan dibaca langsung dari HariLibur.kt. Jalankan: python3 tools/uji_nama_libur.py
"""
import re, sys, os
SRC = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'java', 'com', 'novan', 'bateraibicara', 'HariLibur.kt')
kt = open(SRC, encoding='utf-8').read()

def ambil_pasangan(awal, akhir):
    blok = kt[kt.index(awal):]
    blok = blok[:blok.index(akhir)]
    return re.findall(r'"([^"]+)"\s+to\s+"([^"]+)"', blok)

EN = ambil_pasangan('val englishNames = listOf(', 'val translatedEnglish')
AR = ambil_pasangan('val arab = listOf(', 'val translatedArabic')

L = r'[^\W\d_]'
def rapikan(sumber, kind):
    t = sumber
    t = re.sub(r'[(\[{]\s*(tentatif|tentative|perkiraan|prakiraan|estimasi|estimated)\s*[)\]}]', ' ', t, flags=re.I)
    t = re.sub(r'["“”„‟\'’‘`´]', '', t)
    t = re.sub(r'\bS\.\s?A\.\s?W\b\.?', 'SAW', t, flags=re.I)
    t = re.sub(r'(\d{3,4})\s?H\b', lambda m: m.group(1) + ' Hijriah', t)
    t = re.sub(r'(\d{4})\s?M\b', lambda m: m.group(1) + ' Masehi', t)
    t = re.sub(r'(\d{4})\s?BE\b', lambda m: m.group(1) + ' Buddhis', t)
    t = re.sub(r'\bR\.\s?I\b\.?', 'RI', t)
    t = re.sub(r'\bRI\b', 'Republik Indonesia', t)
    t = re.sub(r'\bMiraj\b', 'Mikraj', t, flags=re.I)
    t = t.replace('&', ' dan ').replace('+', ' dan ')
    t = re.sub(r'\s*/\s*', ' atau ', t)
    t = re.sub(r'(?<=\d)\s*[-–—]\s*(?=\d)', ' sampai ', t)
    t = re.sub(r'\s+[-–—−]+\s+', ', ', t)
    t = re.sub(r'(?<=' + L + r')[-–—](?=' + L + r')', ' ', t)
    t = re.sub(r'[(\[{]', ', ', t); t = re.sub(r'[)\]}]', ' ', t)
    t = re.sub(r'[:;]', ', ', t)
    t = t.replace('%', ' persen')
    t = re.sub(r'[*#@~^_|<>=\\]', ' ', t)
    t = re.sub(r'\s+', ' ', t); t = re.sub(r'\s+,', ',', t); t = re.sub(r',(\s*,)+', ',', t)
    t = t.strip().strip(',. ').strip()
    awal = re.compile(r'^cuti\s+bersama\s*,?\s+', re.I) if kind == 'joint' else re.compile(r'^(libur\s+nasional|hari\s+libur\s+nasional|libur)\s*,?\s+', re.I)
    tanpa = awal.sub('', t)
    if tanpa.strip(): t = tanpa
    return t

def terjemah(t, daftar):
    for a, b in daftar:
        t = re.sub(re.escape(a), b.replace('\\', '\\\\'), t, flags=re.I)
    return t

def ucapan_akhir(t, bahasa):
    saw = {1: 'peace be upon him', 2: 'صلى الله عليه وسلم'}.get(bahasa, 'Shalallahu Alaihi Wasalam')
    hij = {1: 'Hijri', 2: 'هجرية'}.get(bahasa, 'Hijriah')
    mas = {1: 'CE', 2: 'ميلادية'}.get(bahasa, 'Masehi')
    bud = {1: 'Buddhist Era', 2: 'بوذية'}.get(bahasa, 'Buddhis')
    t = re.sub(r'\bSAW\b', saw, t)
    t = re.sub(r'(\d{3,4})\s?H\b', lambda m: m.group(1) + ' ' + hij, t)
    t = re.sub(r'(\d{4})\s?M\b', lambda m: m.group(1) + ' ' + mas, t)
    t = re.sub(r'(\d{4})\s?BE\b', lambda m: m.group(1) + ' ' + bud, t)
    return re.sub(r'\s+', ' ', t).strip()

KATA_INDONESIA = re.compile(r'\b(hari|tahun|cuti|bersama|libur|raya|suci|lahir|wafat|kenaikan|kebangkitan|kemerdekaan|proklamasi|buruh|baru)\b', re.I)

def nama(sumber, kind, bahasa):
    o = rapikan(sumber, kind)
    umum = {1: ('national holiday', 'joint leave'), 2: ('عطلة وطنية', 'إجازة مشتركة')}
    if bahasa == 1:
        t = terjemah(o, EN)
        if t.lower() != o.lower():
            o = umum[1][kind != 'national'] if KATA_INDONESIA.search(t) else t
        else:
            mirip = any(k.lower() in o.lower() for k in ("Hari ", "Tahun ", "Cuti Bersama", "Libur ", "Wafat Yesus", "Kenaikan Yesus"))
            o = umum[1][kind != 'national'] if mirip else o
    elif bahasa == 2:
        t = terjemah(o, AR)
        o = umum[2][kind != 'national'] if (t.lower() == o.lower() or KATA_INDONESIA.search(t)) else t
    return ucapan_akhir(o, bahasa)

# simbol yang tidak boleh tersisa pada ucapan (kecuali apostrof possessive Inggris "New Year's")
SIMBOL = re.compile(r"[()\[\]{}/&+*#@~^_|<>=:;%\\\"“”`´–—−]|(?<!\w)-|-(?!\w)|\bS\.A\.W|\bSAW\b|\bBE\b|\d\s?[HM]\b|\bRI\b")

def _uji():
    kasus = [
        # (sumber API, jenis, harapan id, harapan en)
        ("Tahun Baru Masehi", "national", "Tahun Baru Masehi", "New Year's Day"),
        ("Isra Mi'raj Nabi Muhammad S.A.W.", "national", "Isra Mikraj Nabi Muhammad Shalallahu Alaihi Wasalam", "Isra and Mi'raj"),
        ("Maulid Nabi Muhammad SAW", "national", "Maulid Nabi Muhammad Shalallahu Alaihi Wasalam", "Prophet Muhammad's Birthday"),
        ("Hari Raya Idul Fitri 1447H", "national", "Hari Raya Idul Fitri 1447 Hijriah", "Eid al-Fitr 1447 Hijri"),
        ("Cuti Bersama Hari Raya Idul Fitri 1447 H", "joint", "Hari Raya Idul Fitri 1447 Hijriah", "Eid al-Fitr 1447 Hijri"),
        ("Cuti Bersama (Tentatif)", "joint", "Cuti Bersama", "joint leave"),
        ("Hari Raya Waisak 2570 BE", "national", "Hari Raya Waisak 2570 Buddhis", "Vesak Day 2570 Buddhist Era"),
        ("Hari Kemerdekaan RI", "national", "Hari Kemerdekaan Republik Indonesia", "Indonesian Independence Day"),
        ("Hari Proklamasi Kemerdekaan R.I.", "national", "Hari Proklamasi Kemerdekaan Republik Indonesia", "Indonesian Independence Day"),
        ("Libur Nasional: Hari Buruh Internasional", "national", "Hari Buruh Internasional", "International Workers' Day"),
        ("Cuti Bersama - Hari Raya Natal", "joint", "Hari Raya Natal", "Christmas Day"),
        ("Idul Adha / Hari Raya Qurban", "national", "Idul Adha atau Hari Raya Qurban", None),
        ("Tahun Baru Islam (1 Muharram 1448 H)", "national", "Tahun Baru Islam, 1 Muharram 1448 Hijriah", None),
        ("Natal & Cuti Bersama", "national", "Natal dan Cuti Bersama", None),
        ("Hari Raya \"Nyepi\" 1948 Saka", "national", "Hari Raya Nyepi 1948 Saka", None),
        ("Tahun Baru 2027 M", "national", "Tahun Baru 2027 Masehi", None),
        ("Libur *Pengganti* Idul Fitri", "national", "Pengganti Idul Fitri", None),
        ("Cuti Bersama 23-24 Maret", "joint", "23 sampai 24 Maret", None),
        ("Hari Raya Idul Fitri — 2 Syawal 1447 H", "national", "Hari Raya Idul Fitri, 2 Syawal 1447 Hijriah", None),
    ]
    gagal = 0
    for sumber, kind, id_h, en_h in kasus:
        hid = nama(sumber, kind, 0)
        hen = nama(sumber, kind, 1)
        ok = (hid == id_h) and (en_h is None or hen == en_h) and not SIMBOL.search(hid)
        if en_h is None:
            ok = ok and True
        if not ok:
            gagal += 1
            print("GAGAL", repr(sumber), "->", repr(hid), "| en:", repr(hen), "| harap", repr(id_h), repr(en_h))
    # nama bawaan tidak boleh memuat simbol pada bahasa mana pun
    bawaan = re.findall(r'"(\d{4}-\d{2}-\d{2})"\s+to\s+"([^"]+)"', kt)
    for tgl, nm in bawaan:
        for b in (0, 1, 2):
            h = nama(nm, "national", b) if b != 1 else nama(nm, "national", 1)
            if b == 0 and SIMBOL.search(h):
                gagal += 1; print("SIMBOL pada bawaan:", tgl, repr(nm), '->', repr(h))
    # tanggal angka tidak boleh dipakai pada kalimat ucapan
    if re.search(r'dd-MM-yyyy', kt):
        gagal += 1; print("GAGAL: format tanggal angka dd-MM-yyyy masih dipakai")
    print("selesai: %d kasus nama, %d gagal" % (len(kasus), gagal))
    return gagal

if __name__ == "__main__":
    sys.exit(1 if _uji() else 0)
