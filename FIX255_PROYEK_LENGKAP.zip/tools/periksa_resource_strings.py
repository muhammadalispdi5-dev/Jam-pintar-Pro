#!/usr/bin/env python3
"""Pemeriksa resource string yang meniru aturan aapt2 agar kesalahan ketahuan sebelum build di GitHub Actions.

Gagal bila sebuah <string> di res/values*/strings.xml memuat:
- apostrof ASCII tanpa backslash (mis. "couldn't"; tulis "could not", ’ (U+2019), atau \\');
- urutan \\u yang tidak diikuti empat digit heksadesimal ("Invalid unicode escape sequence in string");
- backslash diikuti karakter selain n t \\ ' " @ ? u atau spasi baris;
- tanda kutip ganda tanpa backslash yang jumlahnya ganjil, atau berpasangan (aapt2 menelan pasangan itu dari teks);
- awal teks berupa @ atau ? tanpa backslash;
- dua format tanpa nomor posisi (%s %s) pada satu string, atau nama string ganda dalam satu berkas.
Pemakaian: python3 tools/periksa_resource_strings.py
"""
from pathlib import Path
import re, sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res"
masalah = []

for berkas in sorted(RES.glob("values*/*.xml")):
    mentah = berkas.read_text(encoding="utf-8")
    try:
        akar = ET.fromstring(mentah)
    except ET.ParseError as e:
        masalah.append("%s: XML tidak valid (%s)" % (berkas.relative_to(ROOT), e))
        continue
    nama_terlihat = set()
    for el in akar:
        if el.tag not in ("string", "item") or el.get("name") is None and el.tag == "string":
            continue
        nama = el.get("name") or "(item)"
        if el.tag == "string":
            if nama in nama_terlihat:
                masalah.append("%s: nama string ganda '%s'" % (berkas.relative_to(ROOT), nama))
            nama_terlihat.add(nama)
        m = re.search(r'<%s\b[^>]*name="%s"[^>]*>(.*?)</%s>' % (el.tag, re.escape(nama), el.tag), mentah, re.S)
        teks = m.group(1) if m else "".join(el.itertext())
        if "<" in teks:      # berisi markup (b, i, xliff); lewati pemeriksaan teks polos
            continue
        pesan = []
        if re.search(r"(?<!\\)'", teks):
            pesan.append("apostrof tanpa backslash")
        for u in re.finditer(r"\\u", teks):
            if not re.match(r"[0-9a-fA-F]{4}", teks[u.end():u.end() + 4]):
                pesan.append("\\u tidak diikuti empat digit heksadesimal")
                break
        if re.search(r"\\(?![ntu\\'\"@?\n])", teks):
            pesan.append("backslash diikuti karakter yang tidak dikenal")
        kutip = len(re.findall(r'(?<!\\)"', teks))
        if kutip:
            pesan.append("%d tanda kutip ganda tanpa backslash (tulis \\\" atau “ ”)" % kutip)
        if re.match(r"^\s*[@?]", teks):
            pesan.append("diawali @ atau ? tanpa backslash")
        if len(re.findall(r"%(?!\d+\$)(?:[-#+ 0,(]*\d*(?:\.\d+)?)[sdfxXeEgGcb]", teks)) > 1:
            pesan.append("lebih dari satu format tanpa nomor posisi")
        for p in pesan:
            masalah.append("%s: '%s': %s" % (berkas.relative_to(ROOT), nama, p))

if masalah:
    print("PEMERIKSAAN RESOURCE STRING: GAGAL")
    for x in masalah:
        print("- " + x)
    sys.exit(1)
print("PEMERIKSAAN RESOURCE STRING: LULUS")
