#!/usr/bin/env python3
"""Uji statis FIX168: cuaca menyebut nama daerah lokasi aktif, bukan kalimat umum 'lokasi perangkat'."""
from pathlib import Path
import sys
k = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt").read_text(encoding="utf-8")
gagal = []
for perlu in ("private fun namaTempatCuaca(", "NamaLokasi.cari(applicationContext", "reverse-geocode-client", "nearest_area", "namaTempatCuaca(lat, lon, lokasiLangsung != null, pp, bahasa)"):
    if perlu not in k: gagal.append("hilang: " + perlu)
for lama in ("lokasi perangkat saat ini", "your current device location"):
    if lama in k: gagal.append("masih memakai kalimat umum lama: " + lama)
if "$namaLokasi" in k or "$lokasiNama" in k: gagal.append("templat dolar kembali dipakai pada kalimat cuaca")
print("UJI FIX168 NAMA DAERAH CUACA:", "GAGAL" if gagal else "LULUS", *gagal, sep="\n- " if gagal else " ")
sys.exit(1 if gagal else 0)
