#!/usr/bin/env python3
"""Uji logika Muraja'ah cerdas (FIX105).

Ini PORT Python dari HafalanSrs.kt (bukan hasil kompilasi Kotlin): memeriksa aturan jadwal, antrean, dan rangkaian
hari, lalu memeriksa kontrak sumber Kotlin (fungsi, kunci, hook, dan bahasa aktif). Jalankan: python3 tools/uji_murajaah_cerdas.py
"""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
KT = ROOT / "app/src/main/java/com/novan/bateraibicara"
INTERVAL = [1, 2, 4, 7, 14, 30, 60]

class Item:
    def __init__(s, surah, ayat, level=0, due=0, salah=0): s.surah, s.ayat, s.level, s.due, s.salah = surah, ayat, level, due, salah
    def telat(s, h): return max(0, h - s.due)

def catat(i, benar, hari):
    if benar:
        i.due = hari + INTERVAL[i.level]; i.level = min(i.level + 1, len(INTERVAL) - 1)
    else:
        i.level = 0; i.salah += 1; i.due = hari + 1

def catat_nilai(i, nilai, hari):
    if nilai == "LANCAR": catat(i, True, hari)
    elif nilai == "LUPA": catat(i, False, hari)
    else: i.due = hari + max(1, INTERVAL[i.level] // 2)

def skor(i, h): return i.telat(h) * 3 + i.salah * 2 + (len(INTERVAL) - 1 - i.level)

def antrean(daftar, batas, penguatan, h):
    jatuh = sorted([i for i in daftar if i.due <= h], key=lambda i: (-skor(i, h), i.surah, i.ayat))[:max(1, batas)]
    hasil = [(i, False) for i in jatuh]
    if penguatan and len(hasil) < max(1, batas):
        lemah = sorted([i for i in daftar if i.due > h and i.salah > 0 and i.level <= 2], key=lambda i: (-i.salah, i.due))
        hasil += [(i, True) for i in lemah[:max(1, batas) - len(hasil)]]
    return hasil

def rangkaian(terakhir, tersimpan, h):
    if terakhir == h: return max(1, tersimpan)
    if terakhir == h - 1: return tersimpan + 1
    return 1

gagal = []
def cek(nama, kondisi):
    if not kondisi: gagal.append(nama)

H = 20000
# jadwal
a = Item(1, 1, 0, H); catat_nilai(a, "LANCAR", H); cek("lancar level0 -> due+1, level1", a.due == H + 1 and a.level == 1)
b = Item(1, 2, 3, H); catat_nilai(b, "RAGU", H); cek("ragu level3 -> level tetap, due +3", b.level == 3 and b.due == H + 3)
c = Item(1, 3, 0, H); catat_nilai(c, "RAGU", H); cek("ragu level0 -> due minimal +1", c.due == H + 1 and c.level == 0)
d = Item(1, 4, 5, H); catat_nilai(d, "LUPA", H); cek("lupa -> level0, salah+1, besok", d.level == 0 and d.salah == 1 and d.due == H + 1)
e = Item(1, 5, 6, H); catat_nilai(e, "LANCAR", H); cek("level maksimum tidak melewati batas", e.level == 6 and e.due == H + 60)
# antrean
daftar = [Item(2, 1, 0, H - 5, 0), Item(2, 2, 0, H, 3), Item(3, 1, 4, H - 1, 0), Item(4, 1, 1, H + 3, 2), Item(5, 1, 6, H + 9, 4), Item(6, 1, 0, H + 2, 0)]
q = antrean(daftar, 3, True, H)
cek("urutan paling mendesak dulu", [(i.surah, i.ayat) for i, _ in q[:3]] == [(2, 1), (2, 2), (3, 1)])
cek("penguatan tidak ditambah saat sesi penuh", all(not p for _, p in q))
q = antrean(daftar, 5, True, H)
cek("penguatan hanya ayat lemah belum jatuh tempo", [(i.surah, p) for i, p in q[3:]] == [(4, True)])
cek("ayat level tinggi tidak jadi penguatan", all(i.surah != 5 for i, _ in q))
cek("penguatan nonaktif", all(not p for _, p in antrean(daftar, 5, False, H)))
cek("antrean kosong bila tidak ada kandidat", antrean([Item(9, 9, 6, H + 50, 0)], 5, True, H) == [])
cek("batas minimal 1", len(antrean(daftar, 0, True, H)) == 1)
# rangkaian
cek("rangkaian hari yang sama", rangkaian(H, 4, H) == 4)
cek("rangkaian bertambah", rangkaian(H - 1, 4, H) == 5)
cek("rangkaian putus", rangkaian(H - 3, 4, H) == 1)

# kontrak sumber Kotlin
srs = (KT / "HafalanSrs.kt").read_text(encoding="utf-8")
kh = (KT / "KhatamActivity.kt").read_text(encoding="utf-8")
for f in ["fun catatNilai", "fun antreanMurajaah", "fun skorMendesak", "fun catatSesiSelesai", "fun rangkaianAktif", "fun ukuranSesi", "enum class Nilai", "data class ButirSesi"]:
    cek("HafalanSrs memuat " + f, f in srs)
for f in ["fun mulaiMurajaahCerdas", "fun mulaiSesiMurajaah", "fun jalankanAyatSesi", "fun lanjutSesiSetelahAyat", "fun akhiriSesiMurajaah",
          "fun dialogSesiTertunda", "fun dialogNilaiMurajaah", "fun dialogPengaturanMurajaah", "fun setelahDialogKoreksiSesi", "fun catatHasilKoreksiSuara"]:
    cek("KhatamActivity memuat " + f, f in kh)
cek("hook dismiss koreksi suara", "if (sesiAktif()) handler.post { setelahDialogKoreksiSesi() }" in kh)
cek("pembaca digambar ulang saat ayat ulasan berganti", "|| ulas != null) tampilkanPembaca()" in kh)
cek("kunci pengaturan ikut direset", '"murajaah_ukuran_sesi", "murajaah_penguatan_aktif"' in kh)
cek("posisi bacaan dipulihkan", 'putInt("terakhir_surah", sesiAsalSurah)' in kh)
cek("tombol menu utama", "mulaiMurajaahCerdas() }" in kh and "Smart muraja'ah (" in kh)
cek("menu pengaturan hafalan", "6 -> dialogPengaturanMurajaah()" in kh)
# bahasa aktif: setiap dialog/teks pada blok FIX105 memakai tr(
blok = kh[kh.index("// ===== FIX105"):kh.index("private fun pengaturanPengingat()")]
telanjang = [m for m in re.findall(r'(?:setTitle|setMessage|setPositiveButton|setNegativeButton|setNeutralButton|toast)\(\s*"', blok)]
cek("blok FIX105 tanpa teks telanjang (semua lewat tr)", not telanjang)
cek("blok FIX105 memakai tr dua bahasa", len(re.findall(r'tr\(', blok)) > 60)

if gagal:
    print("UJI MURAJA'AH CERDAS: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI MURAJA'AH CERDAS: LULUS (logika portingan Python + kontrak sumber Kotlin)")
print("Catatan: bukan hasil kompilasi Kotlin; jalankan GitHub Actions dan uji di HP.")
