#!/usr/bin/env python3
"""Uji FIX169: "Pilih suara qari" terbuka seketika dan katalog dimuat di latar belakang (kontrak sumber; bukan hasil kompilasi)."""
import re, sys
from pathlib import Path
src = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt").read_text(encoding="utf-8")
gagal = []
def cek(nama, ok):
    if not ok: gagal.append(nama)
def fungsi(nama):
    m = re.search(r"\n    private fun " + re.escape(nama) + r"\(", src)
    if not m: return ""
    awal = m.start(); mulai = src.index("{\n", awal); d = 0
    for i in range(mulai, len(src)):
        if src[i] == "{": d += 1
        elif src[i] == "}":
            d -= 1
            if d == 0: return src[awal:i + 1]
    return ""
pilih = fungsi("pilihQari")
cek("pilihQari ada", bool(pilih))
cek("pilihQari memuat cache lokal lalu langsung membuka dialog", pilih.index("muatKatalogQariDariCache()") < pilih.index("tampilkanDialogPilihQari(induk)"))
cek("pilihQari tidak membuat Thread/fetch (tidak memblokir)", "Thread" not in pilih and "fetch(" not in pilih)
cek("pilihQari tidak menampilkan toast 'Memuat katalog' yang menahan dialog", "Memuat katalog qari" not in pilih)
cek("dialog dibuka sebelum pembaruan jaringan dimulai", pilih.index("tampilkanDialogPilihQari(induk)") < pilih.index("segarkanKatalogQari()"))
seg = fungsi("segarkanKatalogQari")
cek("pembaruan katalog berjalan di Thread latar", "Thread {" in seg and "fetch(" in seg)
cek("hasil dijalankan di thread utama dan pendengar dipanggil", "runOnUiThread" in seg and "katalogQariPendengar" in seg)
cek("katalog lengkap disimpan ke berkas lokal", "berkasKatalogQari().writeText" in seg)
muat = fungsi("muatKatalogQariDariCache")
cek("cache hanya dibaca sekali per sesi", "if (katalogQariCacheDimuat) return" in muat)
cek("cache lengkap dibaca dari berkas lokal", "berkasKatalogQari()" in muat and "katalog_qari_anak_cache" in muat)
daf = fungsi("tampilkanDaftarQari")
cek("dialog 'Memuat daftar qari' otomatis diganti daftar bila katalog selesai", "katalogQariPendengar.add" in daf and "dialogMuat.dismiss()" in daf and "tampilkanDaftarQari(jenis, induk)" in daf)
cek("daftar per ayat (bawaan) tidak pernah menunggu jaringan", "jenis != 1 && katalogQariSedangDimuat" in daf)
cek("tombol kembali tetap ada di dialog memuat dan di daftar", daf.count(".kembaliKe(") >= 2)
cek("pilihan qari tetap menyimpan qari_audio_id", 'putString("qari_audio_id", qariId)' in daf)
tam = fungsi("tampilkanDialogPilihQari")
cek("dialog jenis katalog langsung menampilkan empat pilihan", "daftarJenisKatalogQari()" in tam and ".setItems(pilihan)" in tam)
cek("katalog disiapkan saat Khatam dibuka (tanpa menghalangi layar)", "window.decorView.postDelayed" in src and "2500L" in src and "katalogQariPerluDisegarkan()" in src)
if gagal:
    print("UJI PILIH QARI CEPAT: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI PILIH QARI CEPAT: LULUS (kontrak sumber)")
