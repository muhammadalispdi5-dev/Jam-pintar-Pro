#!/usr/bin/env python3
"""Cerminan Python dari PenafsirQuran (PemutarQuranService.kt) untuk menguji penafsiran perintah suara.

Bukan pengganti uji di perangkat: ini hanya meniru logika (gantiKataAngka, ekstrakDirektif, pencocokan nama surah,
tafsirSatu, tafsirLengkap) agar contoh ucapan dapat diperiksa tanpa kompiler Kotlin. Jalankan: python3 tools/uji_penafsir_quran.py
"""
import re, sys

NAMA_LATIN = ["AlFaatihah","AlBaqarah","AliImran","AnNisaa","AlMaaidah","AlAnaam","AlAaraaf","AlAnfaal","AtTaubah","Yunus","Huud","Yusuf","ArRaad","Ibrahim","AlHijr","AnNahl","AlIsraa","AlKahfi","Maryam","Thaahaa2","AlAnbiyaa","AlHajj","AlMuminuun","AnNuur","AlFurqaan","AsySyuaaraa","AnNaml","AlQashash","AlAnkabuut","ArRuum","Luqman","AsSajdah","AlAhzab","Sabaa","Faathir","Yaasiin","AshShaaffaat","Shaad","AzZumar","AlMuumin","Fushshilat","AsySyuura","AzZukhruf","AdDukhaan","AlJaatsiyah","AlAhqaaf","Muhammad","AlFath","AlHujuraat","Qaaf","AdzDzaariyaat","AthThuur","AnNajm","AlQamar","ArRahmaan","AlWaqiah","AlHadiid","AlMujaadilah","AlHasyr","AlMumtahanah","AshShaff","AlJumuah","AlMunaafiquun","AtTaghaabun","AthThalaaq","AtTahrim","AlMulk","AlQalam","AlHaaqqah","AlMaaarij","Nuh","AlJin","AlMuzzammil","AlMuddatstsir","AlQiyaamah","AlInsaan","AlMursalaat","AnNaba","AnNaaziaat","Abasa","AtTakwiir","AlInfithaar","AlMuthaffifin","AlInsyiqaaq","AlBuruuj","AthThaariq","AlAalaa","AlGhaasyiyah","AlFajr","AlBalad","AsySyams","AlLail","AdhDhuhaa","AlamNasyrah","AtTiin","AlAlaq","AlQadr","AlBayyinah","AlZalzalah","AlAadiyaat","AlQaariah","AtTakaatsur","AlAshr","AlHumazah","AlFiil","Quraisy","AlMaauun","AlKautsar","AlKaafiruun","AnNashr","AlLahab","AlIkhlash","AlFalaq","AnNaas"]
ALIAS = {1:["fatihah","fatiha","fatehah","alfatihah"],2:["baqarah","bakarah","baqoroh","albaqarah"],18:["kahfi","kahf","alkahfi"],36:["yasin","yasiin","yaasiin"],55:["rahman","arrahman","rohman"],56:["waqiah","wakiah"],67:["mulk","almulk"],78:["naba","annaba"],86:["tariq","thariq","tarik","attariq"],87:["ala","aala","alaa","alaala","alala"],88:["ghasyiyah","gasiyah","ghashiyah","ghosyiyah","alghasyiyah"],89:["fajr","fajar","alfajr"],91:["syams","shams","assyams"],92:["lail","layl","laili","allail"],93:["duha","dhuha","dhuhaa","adduha","adhdhuha"],94:["insyirah","insyiroh","alamnasyrah","nasyrah","syarh","sharh","alamnasrah"],95:["tin","tiin","attin","attiin"],96:["alaq","alak","iqra","iqro"],97:["qadr","qodar","kadar","alqadr"],98:["bayyinah","bayinah","bayyina"],99:["zalzalah","zilzal","zalzala","zilzalah"],100:["adiyat","adiyaat","aadiyat"],101:["qariah","qaria","kariah","alqariah"],102:["takatsur","takasur","takatur"],103:["asr","ashr","ashar","alasr"],104:["humazah","humaza"],105:["fil","fiil","alfil"],106:["quraisy","quraish","quraysh","kuraisy","kuraish"],107:["maun","maaun","almaun"],108:["kautsar","kausar","kausor","alkautsar"],109:["kafirun","kafiruun","kafirin","kafiron","alkafirun"],110:["nasr","annasr","nashr","annashr"],111:["lahab","masad","tabbat","allahab"],112:["ikhlas","ikhlash","alikhlas"],113:["falaq","falak","alfalaq"],114:["nas","nass","annas","annaas"]}

def fonetik(s):
    t = ''.join(c for c in s.lower() if 'a' <= c <= 'z')
    for a, b in [("sy","s"),("sh","s"),("kh","k"),("gh","g"),("dh","d"),("dz","d"),("th","t"),("ts","s"),("ph","f"),("ck","k"),("ay","ai"),("ey","ei"),("ou","u")]:
        t = t.replace(a, b)
    t = t.replace('q','k').replace('c','k').replace('v','f').replace('e','i').replace('o','u')
    out = []
    for c in t:
        if not out or out[-1] != c: out.append(c)
    return ''.join(out)

def jarak(a, b):
    if a == b: return 0
    if not a: return len(b)
    if not b: return len(a)
    prev = list(range(len(b)+1))
    for i in range(1, len(a)+1):
        cur = [i] + [0]*len(b)
        for j in range(1, len(b)+1):
            cur[j] = min(cur[j-1]+1, prev[j]+1, prev[j-1] + (0 if a[i-1] == b[j-1] else 1))
        prev = cur
    return prev[-1]

AWALAN = [fonetik(x) for x in ["asy","ash","adh","adz","ath","al","an","ar","as","at","ad","az"]]
def _bentuk(i):
    f = set()
    for nm in [NAMA_LATIN[i]] + ALIAS.get(i+1, []):
        k = fonetik(nm)
        if len(k) >= 2: f.add(k)
        for a in AWALAN:
            if k.startswith(a) and len(k) - len(a) >= 4: f.add(k[len(a):])
    return f
FORMS = [_bentuk(i) for i in range(114)]

def cocokkan_nama(tokens):
    teks = fonetik(''.join(tokens))
    if not teks: return None
    terbaik = None; pj = 0
    for i, fs in enumerate(FORMS):
        for k in fs:
            ok = (teks == k) if len(k) <= 3 else (k in teks)
            if ok and len(k) > pj: terbaik = i+1; pj = len(k)
    if terbaik: return terbaik
    jt = 99; pf = 0
    for a in range(len(tokens)):
        for b in range(a+1, min(len(tokens), a+3)+1):
            w = fonetik(''.join(tokens[a:b]))
            if len(w) < 6: continue
            for i, fs in enumerate(FORMS):
                for k in fs:
                    if len(k) < 6 or k[0] != w[0]: continue
                    batas = 1 if len(k) < 10 else 2
                    d = jarak(w, k)
                    if d <= batas and (d < jt or (d == jt and len(k) > pf)):
                        terbaik = i+1; jt = d; pf = len(k)
    return terbaik

def ganti_kata_angka(tokens):
    dasar = {"nol":0,"satu":1,"dua":2,"tiga":3,"empat":4,"lima":5,"enam":6,"tujuh":7,"delapan":8,"sembilan":9,"sepuluh":10,"sebelas":11,
             "zero":0,"one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,"eight":8,"nine":9,"ten":10,"eleven":11,"twelve":12,
             "thirteen":13,"fourteen":14,"fifteen":15,"sixteen":16,"seventeen":17,"eighteen":18,"nineteen":19,
             "twenty":20,"thirty":30,"forty":40,"fifty":50,"sixty":60,"seventy":70,"eighty":80,"ninety":90}
    hasil = []; st = {'total':0,'seg':0,'ada':False}
    def tutup():
        if st['ada']: hasil.append(str(st['total']+st['seg']))
        st['total']=0; st['seg']=0; st['ada']=False
    for t in tokens:
        v = dasar.get(t)
        if v is not None: st['seg'] += v; st['ada'] = True
        elif t == "belas" and st['ada']: st['seg'] += 10
        elif t == "puluh" and st['ada']: st['seg'] *= 10
        elif t in ("ratus","hundred") and st['ada']: st['total'] += (1 if st['seg']==0 else st['seg'])*100; st['seg']=0
        elif t == "seratus": st['total'] += 100; st['ada'] = True
        elif t in ("dan","and") and st['ada']: pass
        else: tutup(); hasil.append(t)
    tutup()
    return hasil

KATA_KALI = {"kali","times","time","x"}
KUNCI_SURAH = {"surah","surat","sura"}; KUNCI_AYAT = {"ayat","ayah","verse","aya"}; KUNCI_JUZ = {"juz","jus","juzz"}
MAKS_ULANG = 999

class Dir:
    def __init__(self): self.ulang=1; self.per_ayat=False; self.sampai_akhir=False; self.relatif=0; self.satuan=0; self.kata_ulang=False; self.kecepatan=None; self.jeda=0

def ekstrak_direktif(tokens, d):
    keluar = []
    pola_ax = re.compile(r'^(\d{1,3})x$'); pola_xa = re.compile(r'^x(\d{1,3})$')
    pengisi_set = {"sebanyak","selama","sebesar","sebanyaknya","diulang","ulangi","ulang","mengulang","repeat","repeated","for"}
    ulang_semua = {"ulangi","ulang","diulang","mengulang","repeat","repeated","again","lagi","berulang"}
    penghubung = {"sampai","hingga","sd","s","d","to","until","till","through","ke"}
    kata_akhir = {"akhir","selesai","habis","tamat","end","finish"}
    kata_per_ayat = {"setiap","tiap","masing","each","every"}
    kata_berikut = {"berikutnya","selanjutnya","next","sesudahnya","setelahnya"}
    kata_sebelum = {"sebelumnya","previous","prev"}
    kata_jeda = {"jeda","selang","jarak","interval","gap","delay"}
    kata_detik = {"detik","second","seconds","sec","secs"}
    def hapus(): 
        if keluar: keluar.pop()
    i = 0
    while i < len(tokens):
        t = tokens[i]; n = int(t) if t.isdigit() else None
        berikut = tokens[i+1] if i+1 < len(tokens) else None
        if n is not None and berikut is not None and berikut in KATA_KALI:
            d.ulang = max(1, min(MAKS_ULANG, n))
            p = keluar[-1] if keluar else None
            if p is not None and p in pengisi_set:
                if p in ulang_semua: d.kata_ulang = True
                hapus()
            i += 2; continue
        m = pola_ax.match(t) or pola_xa.match(t)
        if m:
            d.ulang = max(1, min(MAKS_ULANG, int(m.group(1))))
            p = keluar[-1] if keluar else None
            if p is not None and p in pengisi_set:
                if p in ulang_semua: d.kata_ulang = True
                hapus()
            i += 1; continue
        if t == "sekali": i += 1; continue
        if t in ("menerus","selamanya","forever","loop"):
            if t == "menerus" and keluar and keluar[-1] == "terus": hapus()
            d.ulang = 0; i += 1; continue
        if t == "batas" and keluar and keluar[-1] == "tanpa": hapus(); d.ulang = 0; i += 1; continue
        if t == "terbatas" and keluar and keluar[-1] in ("tak","tidak"): hapus(); d.ulang = 0; i += 1; continue
        if t in kata_per_ayat: d.per_ayat = True; i += 1; continue
        if t in ("pelan","lambat","slow","slowly","perlahan"): d.kecepatan = 0.75; i += 1; continue
        if t in ("cepat","fast","quick","quickly"):
            d.kecepatan = 1.5 if (d.kecepatan is not None and d.kecepatan > 1.0) else 1.25; i += 1; continue
        if t == "normal": d.kecepatan = 1.0; i += 1; continue
        if t in ulang_semua: d.kata_ulang = True; i += 1; continue
        if t in ("mulai","mulailah","dimulai","start","begin"): i += 1; continue
        if t in kata_akhir and keluar and keluar[-1] in penghubung: hapus(); d.sampai_akhir = True; i += 1; continue
        if t == "terakhir":
            a = keluar[-1] if keluar else None; b = keluar[-2] if len(keluar) >= 2 else None
            if a is not None and a in penghubung: hapus(); d.sampai_akhir = True; i += 1; continue
            if a is not None and a in KUNCI_AYAT and b is not None and b in penghubung: hapus(); hapus(); d.sampai_akhir = True; i += 1; continue
        if t in kata_berikut or t in kata_sebelum:
            d.relatif = 1 if t in kata_berikut else -1
            terakhir = keluar[-1] if keluar else None
            if terakhir is not None and terakhir in KUNCI_SURAH: d.satuan = 1; hapus()
            elif terakhir is not None and terakhir in KUNCI_JUZ: d.satuan = 2; hapus()
            elif terakhir is not None and terakhir in KUNCI_AYAT: d.satuan = 0; hapus()
            elif berikut is not None and berikut in KUNCI_SURAH: d.satuan = 1; i += 1
            elif berikut is not None and berikut in KUNCI_JUZ: d.satuan = 2; i += 1
            elif berikut is not None and berikut in KUNCI_AYAT: d.satuan = 0; i += 1
            i += 1; continue
        if t in kata_jeda:
            angka = tokens[i+1] if i+1 < len(tokens) and tokens[i+1].isdigit() else None
            sat = tokens[i+2] if i+2 < len(tokens) else None
            if angka is not None and sat is not None and sat in kata_detik:
                d.jeda = max(0, min(60, int(angka)))
                sb = keluar[-1] if keluar else None
                if sb is not None and sb in ("dengan","beri","with"): hapus()
                i += 3; continue
        keluar.append(t); i += 1
    return keluar

def token_ucapan(u):
    return ganti_kata_angka([x for x in re.sub(r'[^\w]+', ' ', u.lower()).strip().split(' ') if x])

KATA_ISIAN = {"tolong","dong","yah","deh","saja","aja","nih","itu","ini","lah","kah","sekarang","now","please","lagi","aku","saya","mau","ingin","pengen","untuk","for","pada","dalam","bagian","nomor","number","ayatnya","surahnya","suratnya","alquran","quran","murattal","audio","suara","bacaan","tilawah","sama","oleh","dengan"}
KATA_PERINTAH = {"putar","putarkan","mainkan","bacakan","baca","play","please","tolong","nomor","number","ke","dari","the","of","di","yang","dengan","lalu","alquran","quran"}
PENGHUBUNG_RENTANG = {"sampai","hingga","dengan","sd","s","d","to","through","until","till","ke","and","dan","sampe"}

def tafsir_satu(ucapan):
    d = Dir(); tokens = ekstrak_direktif(token_ucapan(ucapan), d)
    juz = surah = ayat = ayat_akhir = None; sisa = []; angka_lepas = []
    i = 0
    while i < len(tokens):
        t = tokens[i]; berikut = int(tokens[i+1]) if i+1 < len(tokens) and tokens[i+1].isdigit() else None
        if t in KUNCI_JUZ and berikut is not None: juz = berikut; i += 2; continue
        if t in KUNCI_AYAT and berikut is not None:
            if ayat is None:
                ayat = berikut; k = i+2; awal_k = k
                while k < len(tokens) and tokens[k] in PENGHUBUNG_RENTANG: k += 1
                if k > awal_k and k < len(tokens) and tokens[k] in KUNCI_AYAT: k += 1
                aa = int(tokens[k]) if k < len(tokens) and tokens[k].isdigit() else None
                if aa is not None: ayat_akhir = aa; k += 1
                i = k
            else: ayat_akhir = berikut; i += 2
            continue
        if t in KUNCI_SURAH and berikut is not None: surah = berikut; i += 2; continue
        if t in KUNCI_JUZ or t in KUNCI_AYAT or t in KUNCI_SURAH or t in KATA_PERINTAH: pass
        elif t.isdigit(): angka_lepas.append(int(t))
        else: sisa.append(t)
        i += 1
    dari_nama = cocokkan_nama(sisa); surah_dari_nama = False
    if surah is None and dari_nama is not None:
        surah = dari_nama; surah_dari_nama = True
        if ayat is None and juz is None and angka_lepas:
            ayat = angka_lepas[0]
            if len(angka_lepas) >= 2: ayat_akhir = angka_lepas[1]
    elif surah is None and ayat is None and juz is None and len(angka_lepas) >= 2:
        surah = angka_lepas[0]; ayat = angka_lepas[1]
    elif surah is None and ayat is None and juz is None and len(angka_lepas) == 1 and not sisa:
        surah = angka_lepas[0]
    bermakna = [] if surah_dari_nama else [x for x in sisa if len(x) >= 3 and x not in KATA_ISIAN]
    ada_kata_surah = any(x in KUNCI_SURAH for x in tokens)
    if juz is None and surah is None and ayat is not None and bermakna:
        return (None, False, ' '.join(bermakna))
    P = lambda **k: dict(juz=juz, surah=surah, ayat=ayat, ayat_akhir=ayat_akhir, ulang=d.ulang, per_ayat=d.per_ayat, sampai_akhir=d.sampai_akhir, relatif=0, satuan=0, ulangi=False, kecepatan=d.kecepatan, jeda=d.jeda, **k)
    if juz is None and surah is None and ayat is None:
        if d.relatif != 0: return (dict(juz=None,surah=None,ayat=None,ayat_akhir=None,ulang=d.ulang,per_ayat=d.per_ayat,sampai_akhir=False,relatif=d.relatif,satuan=d.satuan,ulangi=False,kecepatan=d.kecepatan,jeda=d.jeda), True, None)
        if d.kata_ulang: return (dict(juz=None,surah=None,ayat=None,ayat_akhir=None,ulang=d.ulang,per_ayat=d.per_ayat,sampai_akhir=False,relatif=0,satuan=0,ulangi=True,kecepatan=d.kecepatan,jeda=d.jeda), True, None)
        if ada_kata_surah and bermakna: return (None, False, ' '.join(bermakna))
        return (None, False, None)
    return (P(), surah is not None or juz is not None, None)

def tafsir_lengkap(kandidat):
    hanya_ayat = None; tak = None
    for u in kandidat:
        p, eks, tk = tafsir_satu(u)
        if p is not None:
            if eks: return (p, None)
            if hanya_ayat is None: hanya_ayat = p
        elif tak is None and tk is not None: tak = tk
    if tak is not None: return (None, tak)
    return (hanya_ayat, None)

def _uji():
    # (ucapan atau daftar kandidat, hasil yang diharapkan): dict kunci penting, 'TAK:nama', atau None
    S = lambda s, a=None, z=None, ul=1, **k: dict(surah=s, ayat=a, ayat_akhir=z, ulang=ul, **k)
    kasus = [
        # --- kasus yang dilaporkan pengguna ---
        ("putar surah al ikhlas ayat 1 sebanyak 3 kali", S(112, 1, None, 3)),
        ("putar surat al-ikhlas ayat 1 sebanyak tiga kali", S(112, 1, None, 3)),
        ("putar surah alikhlas ayat satu 3 kali", S(112, 1, None, 3)),
        ("putar surah al ikhlash ayat 1 3x", S(112, 1, None, 3)),
        ("putar surah iklas ayat 1 sebanyak 3 kali", S(112, 1, None, 3)),
        (["putar surah al ikhlas ayat 1 sebanyak 3 kali", "putar surah ayat 1 sebanyak 3 kali"], S(112, 1, None, 3)),
        (["putar surah ayat 1 sebanyak 3 kali", "putar surah al ikhlas ayat 1 sebanyak 3 kali"], S(112, 1, None, 3)),
        # --- nama tidak dikenal: jangan diam-diam memakai surah terakhir ---
        ("putar surah blablabla ayat 1 sebanyak 3 kali", "TAK:blablabla"),
        ("putar surah xyzxyz ayat 2", "TAK:xyzxyz"),
        (["putar surah foobar ayat 1", "putar surah ayat 1"], "TAK:foobar"),
        ("putar surah foobar", "TAK:foobar"),
        # --- ayat tanpa nama surah tetap memakai surah terakhir (surah=None) ---
        ("putar ayat 10", S(None, 10)),
        ("putar ayat 5 sebanyak 3 kali", S(None, 5, None, 3)),
        ("putar ayat 3 tolong", S(None, 3)),
        # --- perilaku FIX98 yang tidak boleh berubah ---
        ("putar surah Al Fatihah ayat 7 sebanyak 5 kali", S(1, 7, None, 5)),
        ("putar surah 1 ayat 7 5 kali", S(1, 7, None, 5)),
        ("putar surah 1 ayat 7 5x", S(1, 7, None, 5)),
        ("play surah 1 verse 7 five times", S(1, 7, None, 5)),
        ("putar surah 36 ayat 1 sampai 10 tiga kali", S(36, 1, 10, 3)),
        ("putar surah Al Ikhlas setiap ayat 3 kali", S(112, None, None, 3, per_ayat=True)),
        ("putar Yasin 5 kali", S(36, None, None, 5)),
        ("putar surah Al Baqarah ayat 255 terus menerus", S(2, 255, None, 0)),
        ("putar surah Al Kahfi mulai ayat 10 sampai akhir", S(18, 10, None, 1, sampai_akhir=True)),
        ("putar surah 2 ayat 255 sampai 257", S(2, 255, 257, 1)),
        ("putar juz 30 pelan", dict(juz=30, kecepatan=0.75)),
        ("putar surah 1 ayat 7 5 kali jeda 3 detik", S(1, 7, None, 5, jeda=3)),
        ("ayat berikutnya", dict(relatif=1, satuan=0)),
        ("surah sebelumnya", dict(relatif=-1, satuan=1)),
        ("ulangi 3 kali", dict(ulangi=True, ulang=3)),
        ("putar surah 36 ayat 5", S(36, 5)),
        ("putar surah 36", S(36)),
        ("putar juz 30", dict(juz=30)),
        # --- nama-nama surah pendek yang sering diminta ---
        ("putar surah an nas ayat 1", S(114, 1)),
        ("putar surah al falaq", S(113)),
        ("putar surah al kafirun ayat 1 sampai 6", S(109, 1, 6)),
        ("putar surah al kausar", S(108)),
        ("putar surah an nasr", S(110)),
        ("putar surah al lahab ayat 1", S(111, 1)),
        ("putar surah quraisy", S(106)),
        ("putar surah al fatihah", S(1)),
        ("putar surah ar rahman", S(55)),
        ("putar surah al waqiah", S(56)),
        ("putar surah al mulk", S(67)),
        ("putar surah ad duha", S(93)),
        ("putar surah al insyirah", S(94)),
        ("putar surah at tin", S(95)),
        ("putar surah al qadr", S(97)),
        ("putar surah al asr", S(103)),
        ("putar surah al ma un", S(107)),
    ]
    gagal = 0
    for u, h in kasus:
        kand = u if isinstance(u, list) else [u]
        p, tak = tafsir_lengkap(kand)
        if isinstance(h, str):
            ok = p is None and tak == h[4:]
            hasil = ("TAK:" + str(tak)) if p is None else p
        else:
            ok = p is not None and all(p.get(k) == v for k, v in h.items())
            hasil = p if p is not None else "TAK:" + str(tak)
        if not ok:
            gagal += 1
            print("GAGAL", kand, "->", hasil, "| harap", h)
    print("selesai: %d kasus, %d gagal" % (len(kasus), gagal))
    return gagal

if __name__ == "__main__":
    sys.exit(1 if _uji() else 0)
