#!/usr/bin/env python3
"""Uji FIX191: perintah suara memutar audio ONLINE bila qari yang diminta tidak ada di daftar/penyimpanan offline.
Bagian 1: port Python pencocokan berkas lokal dengan qari yang diminta dan pemilihan rekaman katalog online.
Bagian 2: kontrak sumber Kotlin. Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import json, re, sys

def aman(v): return re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|]', "_", v)).strip()

def inti(label):
    for p in ("Anak · ", "Children · ", "MP3Quran · ", "Perempuan · "):
        if label.startswith(p): label = label[len(p):]
    return aman(label.split(" · ")[0].split(" - ")[0])

def sesuai(label, nama, lokasi):
    folder = aman(label)[:80]
    it = inti(label)
    ib = re.sub(r"[^A-Za-z0-9_-]", "_", it)
    return (len(ib) >= 3 and ib.lower() in nama.lower()) or folder.lower() in lokasi.lower() or (len(it) >= 3 and it.lower() in lokasi.lower())

def terima(label, nama, lokasi, ketat):
    return (not ketat) or sesuai(label, nama, lokasi)

gagal = []
def cek(n, k):
    if not k: gagal.append(n)

ALAFASY = "Mishary Rashid Alafasy · merdu dan jelas"
f_alafasy = "Qari_Mishary_Rashid_Alafasy___merdu_dan_jelas_S036_A001.mp3"
l_alafasy = "/sdcard/Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an/Mishary Rashid Alafasy · merdu dan jelas/Audio Per Ayat/036 - Yasin"
GHAMDI = "MP3Quran · Saad Al-Ghamdi"
f_ghamdi = "Qari_MP3Quran___Saad_Al-Ghamdi_Surah_036.mp3"
l_ghamdi = "/sdcard/Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an/MP3Quran · Saad Al-Ghamdi/Audio Per Surah"

cek("berkas Alafasy cocok untuk Alafasy", sesuai(ALAFASY, f_alafasy, l_alafasy))
cek("berkas Alafasy TIDAK cocok untuk qari lain saat ada internet (diputar online)", not terima(GHAMDI, f_alafasy, l_alafasy, True))
cek("berkas qari lain tetap dipakai tanpa internet (offline tidak hilang)", terima(GHAMDI, f_alafasy, l_alafasy, False))
cek("berkas Al-Ghamdi cocok untuk Al-Ghamdi", sesuai(GHAMDI, f_ghamdi, l_ghamdi))
cek("berkas Al-Ghamdi tidak cocok untuk Alafasy", not terima(ALAFASY, f_ghamdi, l_ghamdi, True))
cek("cocok lewat nama folder walau nama berkas berbeda", sesuai(ALAFASY, "Qari_x_S036_A001.mp3", l_alafasy))
cek("qari anak: label Indonesia dan Inggris sama-sama cocok",
    sesuai("Anak · Muhammad Taha Al-Junayd", "Qari_Anak___Muhammad_Taha_Al-Junayd_Surah_001.mp3", "/x") and
    sesuai("Anak · Muhammad Taha Al-Junayd", "Qari_Children___Muhammad_Taha_Al-Junayd_Surah_001.mp3", "/x"))
cek("qari anak lain tidak ikut cocok", not sesuai("Anak · Muhammad Taha Al-Junayd", "Qari_Anak___Ahmad_bin_Saud_Surah_001.mp3", "/x"))
cek("qari bawaan tanpa label dipetakan ke label katalog", inti("Mishary Rashid Alafasy") == "Mishary Rashid Alafasy")
cek("nama terlalu pendek tidak dipakai mencocokkan", not sesuai("MP3Quran · Al", "Qari_MP3Quran___Al_Surah_001.mp3", "/tidak/ada"))

# Pemilihan rekaman katalog online: rekaman paling lengkap, https, minimal 114 surah
def sumber_moshaf(r):
    hasil = []
    for m in r.get("moshaf", []):
        server = m.get("server", "").strip()
        if server.startswith("http://"): server = "https://" + server[len("http://"):]
        daftar = m.get("surah_list", "").strip()
        if not server.startswith("https://") or not daftar: continue
        jumlah = sum(1 for x in daftar.split(",") if x.strip().isdigit())
        if jumlah: hasil.append((server.rstrip("/") + "/", daftar, jumlah))
    return [(a, b) for a, b, _ in sorted(hasil, key=lambda t: -t[2])]

lengkap = ",".join(str(i) for i in range(1, 115)); sebagian = ",".join(str(i) for i in range(1, 51))
r = {"name": "Saad Al-Ghamdi", "moshaf": [{"server": "http://server7.mp3quran.net/s_gmd", "surah_list": sebagian},
                                          {"server": "http://server7.mp3quran.net/s_gmd2", "surah_list": lengkap}]}
sm = sumber_moshaf(r)
cek("rekaman terlengkap dipilih dan http dinaikkan ke https", sm[0][0] == "https://server7.mp3quran.net/s_gmd2/" and sm[0][1] == lengkap)
def masuk_katalog(rec):
    sm_ = sumber_moshaf(rec)
    return bool(sm_) and sum(1 for x in sm_[0][1].split(",") if x.strip().isdigit()) >= 114
cek("qari dengan rekaman lengkap masuk katalog", masuk_katalog(r))
cek("qari yang hanya punya rekaman sebagian tidak masuk katalog",
    not masuk_katalog({"moshaf": [{"server": "https://a.example/q", "surah_list": sebagian}]}))
cek("tanpa rekaman https/daftar surah -> kosong", sumber_moshaf({"moshaf": [{"server": "ftp://x", "surah_list": "1"}, {"server": "https://a", "surah_list": ""}]}) == [])

R = Path(__file__).resolve().parents[1]
B = R / "app/src/main/java/com/novan/bateraibicara"
qs = (B / "QariSuara.kt").read_text(encoding="utf-8")
pq = (B / "PemutarQuranService.kt").read_text(encoding="utf-8")
kh = (B / "KhatamActivity.kt").read_text(encoding="utf-8")
mf = (R / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
cek("QariSuara: pencarian online", "fun cariOnline(context: Context, nama: String, qariSaatIni: String)" in qs and "mp3quran.net/api/v3/reciters?language=eng" in qs)
cek("QariSuara: katalog tambahan dalam pencarian", "tambahan: List<Pair<String, String>> = emptyList()" in qs)
cek("QariSuara: katalog lengkap dari berkas Khatam", "katalog_qari_mp3quran.json" in qs and "katalogDariBerkas(context)" in qs)
cek("QariSuara: tidak menimpa berkas katalog Khatam", "if (!berkas.exists())" in qs)
cek("QariSuara: label dari id", "fun labelDariId(" in qs)
cek("Khatam memakai pembantu bersama (tanpa duplikasi)", "= QariSuara.sumberMoshaf(r)" in kh and "= QariSuara.namaLatin(nama)" in kh)
cek("layanan: cari online di pekerja latar saat ada internet", "pilihan = QariSuara.cariOnline(this, klausaQari.first, aktif)" in pq and "if (pilihan == null && adaInternet())" in pq)
cek("layanan: hasil online dipakai putar()", "QariSuara.cari(this, namaDiminta, qariAktif) ?: qariOnlineHasil" in pq)
cek("layanan: pencocokan qari ketat saat ada internet", "if (ketat && !sesuaiQari(nama, lokasi)) return" in pq and "val ketat = adaInternet()" in pq)
cek("layanan: cache indeks dibedakan menurut mode", 'if (adaInternet()) "S" else "L"' in pq and pq.count("identitasIndeks(kh)") == 2)
cek("layanan: tanpa internet dan tanpa berkas -> beri tahu", "jumlahDaring == daftarUrl.size" in pq)
cek("layanan: cadangan URL Alafasy FIX189 tetap ada", "daftarUrlCadangan" in pq and "pakaiUrlCadangan" in pq)
cek("izin status jaringan", "android.permission.ACCESS_NETWORK_STATE" in mf)
# bahasa aktif: tiap toast baru memakai tr(
for kunci in ["mencari secara online", "memutar secara online", "tidak ada koneksi internet", "baik di daftar offline maupun online"]:
    i = pq.index(kunci)
    cek("toast dua bahasa: " + kunci, "tr(" in pq[max(0, i - 200):i])
if gagal:
    print("UJI PUTAR QARI ONLINE: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI PUTAR QARI ONLINE: LULUS (port logika + kontrak sumber)")
