#!/usr/bin/env python3
"""Penegak aturan ATURAN_BAHASA_AKTIF.md.

1. Kunci strings.xml Indonesia dan Inggris harus sama.
2. Literal Kotlin berbahasa Indonesia yang tidak dibungkus tr(...)/BahasaAplikasi/english/sumber daya
   dihitung per berkas dan dibandingkan dengan baseline (hanya boleh turun; berkas baru = 0).
Pemakaian: python3 tools/periksa_bahasa_aktif.py [--perbarui-baseline] [--rincian]
"""
from pathlib import Path
import json, re, sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java"
BASELINE = ROOT / "tools/baseline_bahasa_aktif.json"
ID_XML = ROOT / "app/src/main/res/values/strings.xml"
EN_XML = ROOT / "app/src/main/res/values-en/strings.xml"

# Kata fungsi bahasa Indonesia yang hampir tidak muncul di Inggris/kode.
KATA_ID = set("""yang dan atau tidak untuk dengan saat dari pada belum sudah silakan ayat akan bila jika ini itu
anda sedang telah dapat harus agar hanya ketuk pilih aktifkan nonaktif kembali berikutnya sebelum sesudah setelah
hari ulangi mulai tampilkan sembunyikan perlu tersedia gagal berhasil lanjut selesai ulasan hafalan bacaan""".split())
# Penanda bahwa literal berada di jalur bahasa-aktif (dibungkus).
PEMBUNGKUS = ("tr", "teks", "ui", "getString", "judulDenganPesan_tr")
PENANDA_BARIS = ("BahasaAplikasi", "english", "Inggris", "R.string", "Log.", "TAG", "putExtra", "getStringExtra",
                 "getSharedPreferences", "getString(", "optString", "Regex(", "Pattern", "contains(", "startsWith(", "endsWith(")

def tokenisasi(teks):
    """Hasilkan (awal, akhir, isi, tumpukan_pemanggil) untuk tiap literal string; abaikan komentar."""
    i, n = 0, len(teks)
    tumpuk = []          # nama fungsi untuk tiap '(' terbuka (None untuk tanda kurung biasa)
    hasil = []
    while i < n:
        c = teks[i]
        if teks.startswith("//", i):
            j = teks.find("\n", i); i = n if j < 0 else j; continue
        if teks.startswith("/*", i):
            j = teks.find("*/", i + 2); i = n if j < 0 else j + 2; continue
        if teks.startswith('"""', i):
            j = teks.find('"""', i + 3); j = n - 3 if j < 0 else j
            hasil.append((i, j + 3, teks[i + 3:j], list(tumpuk))); i = j + 3; continue
        if c == '"':
            j = i + 1
            while j < n and teks[j] != '"':
                j += 2 if teks[j] == "\\" else 1
            hasil.append((i, j + 1, teks[i + 1:j], list(tumpuk))); i = j + 1; continue
        if c == "'":
            j = i + 2 if teks[i + 1] == "\\" else i + 1
            j = teks.find("'", j); i = (i + 1) if j < 0 else j + 1; continue
        if c == "(":
            m = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*$", teks[max(0, i - 40):i])
            tumpuk.append(m.group(1) if m else None)
        elif c == ")" and tumpuk:
            tumpuk.pop()
        i += 1
    return hasil

def berbahasa_indonesia(isi):
    kata = re.findall(r"[A-Za-z']+", isi.lower())
    if len(kata) < 2:
        return False
    return sum(1 for k in kata if k in KATA_ID) >= 1 and " " in isi.strip()

def hitung_berkas(path):
    teks = path.read_text(encoding="utf-8")
    temuan = []
    for awal, akhir, isi, tumpuk in tokenisasi(teks):
        if not berbahasa_indonesia(isi):
            continue
        if any(f in PEMBUNGKUS for f in tumpuk if f):
            continue
        baris_awal = teks.rfind("\n", 0, awal) + 1
        baris_akhir = teks.find("\n", akhir); baris_akhir = len(teks) if baris_akhir < 0 else baris_akhir
        baris = teks[baris_awal:baris_akhir]
        if any(p in baris for p in PENANDA_BARIS):
            continue
        # Pola "if (english) A else B" yang dipecah beberapa baris: periksa 3 baris sebelumnya.
        konteks = teks[max(0, teks.rfind("\n", 0, max(0, baris_awal - 1)) - 160):baris_akhir]
        if "english" in konteks or "tampilan(" in konteks:
            continue
        temuan.append((teks.count("\n", 0, awal) + 1, isi.strip()[:70]))
    return temuan

def periksa_xml():
    galat = []
    try:
        kid = {n.get("name") for n in ET.parse(ID_XML).getroot().findall("string")}
        ken = {n.get("name") for n in ET.parse(EN_XML).getroot().findall("string")}
    except Exception as e:  # noqa
        return [f"strings.xml tidak dapat dibaca: {e}"]
    galat += [f"Kunci hanya di Indonesia (belum ada bahasa Inggris): {k}" for k in sorted(kid - ken)]
    galat += [f"Kunci hanya di Inggris (belum ada bahasa Indonesia): {k}" for k in sorted(ken - kid)]
    return galat

def main():
    perbarui = "--perbarui-baseline" in sys.argv
    rinci = "--rincian" in sys.argv
    galat = periksa_xml()
    hitungan, rincian = {}, {}
    for f in sorted(SRC.rglob("*.kt")):
        if f.name == "BahasaAplikasi.kt":  # kamus terjemahan: kunci Indonesia memang sengaja ada
            continue
        t = hitung_berkas(f)
        rel = str(f.relative_to(ROOT))
        hitungan[rel] = len(t); rincian[rel] = t
    if perbarui:
        BASELINE.write_text(json.dumps(hitungan, indent=1, sort_keys=True), encoding="utf-8")
        print(f"Baseline diperbarui: {sum(hitungan.values())} literal lama tercatat.")
        return 0 if not galat else (print("\n".join(galat)) or 1)
    dasar = json.loads(BASELINE.read_text(encoding="utf-8")) if BASELINE.is_file() else {}
    for rel, jumlah in hitungan.items():
        batas = dasar.get(rel, 0)
        if jumlah > batas:
            galat.append(f"{rel}: {jumlah - batas} teks Indonesia baru belum mengikuti bahasa aktif (batas {batas}, ditemukan {jumlah}). "
                         f"Bungkus dengan tr(id, en) atau sumber daya dua bahasa.")
            for baris, isi in rincian[rel][:8 if not rinci else 99]:
                galat.append(f"    baris {baris}: \"{isi}\"")
    if galat:
        print("PEMERIKSAAN BAHASA AKTIF: GAGAL")
        print("\n".join("- " + g if not g.startswith("    ") else g for g in galat))
        return 1
    turun = sum(max(0, dasar.get(k, 0) - v) for k, v in hitungan.items())
    print(f"PEMERIKSAAN BAHASA AKTIF: LULUS (sisa literal lama: {sum(hitungan.values())}" + (f", turun {turun} dari baseline; jalankan --perbarui-baseline" if turun else "") + ")")
    return 0

if __name__ == "__main__":
    sys.exit(main())
