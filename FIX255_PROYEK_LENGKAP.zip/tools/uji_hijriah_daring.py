#!/usr/bin/env python3
"""Uji FIX216: Hijriah daring (port logika validasi + kontrak sumber). Bukan hasil kompilasi Kotlin."""
from pathlib import Path
import re, sys
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
hd = (R / "HijriahDaring.kt").read_text(encoding="utf-8")
kt = (R / "KalenderTanggal.kt").read_text(encoding="utf-8")
fs = (R / "FastingSchedule.kt").read_text(encoding="utf-8")
gagal = []
def cek(nama, ok):
    print(("LULUS" if ok else "GAGAL") + " - " + nama)
    if not ok: gagal.append(nama)

def masuk_akal(d):  # port HijriahDaring.masukAkal
    for i, (t, b, h) in enumerate(d):
        if not (1300 <= t <= 1700 and 0 <= b <= 11 and 1 <= h <= 30): return False
        if i == 0: continue
        pt, pb, ph = d[i - 1]
        lanjut = t == pt and b == pb and h == ph + 1
        baru = h == 1 and ph >= 29 and ((t == pt and b == pb + 1) or (t == pt + 1 and pb == 11 and b == 0))
        if not lanjut and not baru: return False
    return True

bagus = [(1448, 5, d) for d in range(20, 31)] + [(1448, 6, d) for d in range(1, 20)]
cek("bulan wajar diterima", masuk_akal(bagus))
cek("pergantian tahun Hijriah (Zulhijah 30 -> Muharam 1) diterima", masuk_akal([(1447, 11, 29), (1447, 11, 30), (1448, 0, 1)]))
cek("pergantian bulan pada 29 diterima", masuk_akal([(1448, 8, 28), (1448, 8, 29), (1448, 9, 1)]))
cek("lompatan hari ditolak", not masuk_akal([(1448, 5, 10), (1448, 5, 12)]))
cek("bulan baru terlalu dini ditolak", not masuk_akal([(1448, 5, 10), (1448, 6, 1)]))
cek("data mundur ditolak", not masuk_akal([(1448, 5, 10), (1448, 5, 9)]))
cek("tahun tak masuk akal ditolak", not masuk_akal([(5, 5, 10)]))

cek("memakai endpoint kalender bulanan", "gToHCalendar" in hd)
cek("jumlah hari bulan Masehi diperiksa", "data.length() != panjang" in hd)
cek("data buruk tidak disimpan", "if (!masukAkal(hasil)) return null" in hd)
cek("pembaruan berkala bulan dekat dan jauh", "USIA_BULAN_DEKAT_MS" in hd and "USIA_BULAN_JAUH_MS" in hd and "BULAN_KE_DEPAN = 13" in hd)
cek("bulan sebelumnya ikut diunduh (batas bulan pukul 18.00)", "(-1..BULAN_KE_DEPAN)" in hd)
cek("offline tidak menghapus data", "edit().remove(" not in hd and "edit().clear()" not in hd)
cek("KalenderTanggal memakai tabel daring sebelum ICU", "HijriahDaring.cari(" in kt and kt.index("HijriahDaring.cari(") < kt.index("IslamicCalendar(IcuTimeZone.getDefault(), localeId)\n                hijri.timeInMillis"))
cek("KalenderTanggal memicu unduhan tabel", "HijriahDaring.segarkan(context, paksa)" in kt)
cek("jadwal puasa memakai tabel daring", "HijriahDaring.hijri(context, date)" in fs and "fun shawwalDates(context: Context" in fs)
cek("mode otomatis bawaan aktif", 'bool("kal_hijri_auto", true)' in (R / "Prefs.kt").read_text(encoding="utf-8"))
if gagal: print("UJI HIJRIAH DARING: GAGAL"); sys.exit(1)
print("UJI HIJRIAH DARING: LULUS (port logika + kontrak sumber)")
