#!/usr/bin/env python3
"""Uji kontrak sumber FIX142: perintah putar Quran tidak boleh membuka layar Khatam; layanan latar menangani qari, efek, pengaturan bawaan.
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys
B = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
ps = (B / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
sv = (B / "PemutarQuranService.kt").read_text(encoding="utf-8")
ef = (B / "EfekAudioLatar.kt").read_text(encoding="utf-8")
qs = (B / "QariSuara.kt").read_text(encoding="utf-8")
g = []
def cek(n, k):
    if not k: g.append(n)
i = ps.index("PerintahSuara.Jenis.QURAN ->"); j = ps.index("PerintahSuara.Jenis.BERHENTI_AUDIO")
blok = ps[i:j]
cek("cabang QURAN memanggil layanan", "putarQuranLatarBelakang(kandidat)" in blok)
cek("cabang QURAN tidak membuka Khatam", "bukaKhatam" not in blok and "KhatamActivity" not in blok)
cek("bukaKhatam dihapus", "fun bukaKhatam" not in ps)
cek("layanan memahami klausa qari", "QariSuara.pisah(" in sv and "qari_audio_id" in sv)
cek("layanan memasang efek", "efek.pasang(pemutar.audioSessionId)" in sv and "efek.lepas()" in sv)
cek("pengaturan bawaan ulang/jeda", "pengulangan_audio_ayat" in sv and "jeda_antar_ayat_detik" in sv)
cek("efek membaca preset Khatam", all(k in ef for k in ["preset_equalizer_audio", "equalizer_kustom_mb", "efek_bass_persen", "efek_spasial_persen", "efek_penguat_db"]))
cek("qari memakai katalog cache Khatam", "katalog_qari_anak_cache" in qs)
cek("layanan memakai PemutarMono/PemutarStereo sesuai pengaturan", "keluaran_suara_audio" in sv and "PemutarMono()" in sv and "PemutarStereo()" in sv and "MediaPlayer()" not in sv)
cek("antarmuka punya setVolume", "fun setVolume(kiri: Float, kanan: Float)" in (B / "PemutarAudio.kt").read_text(encoding="utf-8"))
cek("kunci CPU untuk dekode mono", "QuranSuaraCpu" in sv)
if g:
    print("UJI PUTAR TANPA LAYAR: GAGAL"); [print("-", x) for x in g]; sys.exit(1)
print("UJI PUTAR TANPA LAYAR: LULUS (kontrak sumber)")
