#!/usr/bin/env python3
"""FIX205: uji statis pengenalan perintah suara "putar surah X dan terjemahan Indonesia"."""
import re, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
src = root / "app/src/main/java/com/novan/bateraibicara"
svc = (src / "PemutarQuranService.kt").read_text(encoding="utf-8")
kh = (src / "KhatamActivity.kt").read_text(encoding="utf-8")
gagal = []
def cek(nama, ok):
    print(("OK   " if ok else "GAGAL"), nama)
    if not ok: gagal.append(nama)

cek("Perintah punya field terjemah", "val terjemah: Int = 0" in svc)
cek("adaDirektif memuat terjemah", "jedaDetik > 0 || terjemah != 0" in svc)
cek("ekstrakDirektif memanggil ekstrakTerjemah", "ekstrakTerjemah(tokensAsli, d)" in svc)
cek("tafsirSatu meneruskan d.terjemah", "d.kecepatan, d.jeda, d.terjemah)" in svc)
cek("URL terjemahan dipakai pemutar", "PenafsirQuran.urlTerjemahanId(surah)" in svc)
cek("Khatam memakai daftar bersama", "get() = PenafsirQuran.berkasTerjemahanId" in kh)
m = re.search(r"val berkasTerjemahanId: List<String> = listOf\((.*?)\n    \)", svc, re.S)
nama = re.findall(r'"([^"]+)"', m.group(1)) if m else []
cek("114 nama berkas terjemahan", len(nama) == 114)

# Simulasi ekstrakTerjemah (cermin logika Kotlin)
T = {"terjemah","terjemahan","terjemahnya","terjemahannya","translation","translations","translated","artinya","arti"}
H = {"saja","aja","only","hanya","doang"}
G = {"dan","dengan","beserta","serta","and","with","plus","sama","lalu","kemudian","then"}
B = {"indonesia","indonesian","bahasa","indo","in","dalam","language"}
def ekstrak(tok):
    if not any(t in T for t in tok): return tok, 0
    hapus = [False]*len(tok); hanya = False
    for i,t in enumerate(tok):
        if t not in T: continue
        hapus[i] = True
        k = i+1
        while k < len(tok) and tok[k] in B: hapus[k] = True; k += 1
        if k < len(tok) and tok[k] in H: hapus[k] = True; hanya = True
        b = i-1
        while b >= 0 and tok[b] in B: hapus[b] = True; b -= 1
        if b >= 0 and tok[b] in G: hapus[b] = True
        if b >= 0 and tok[b] in H: hapus[b] = True; hanya = True
        if i >= 1 and tok[i-1] in H: hapus[i-1] = True; hanya = True
    return [t for t,h in zip(tok,hapus) if not h], (2 if hanya else 1)
kasus = [
    ("putar surah al fatihah dan terjemahan indonesia", "putar surah al fatihah", 1),
    ("putar surah al ikhlas dan terjemahan indonesia", "putar surah al ikhlas", 1),
    ("putar surah yasin dengan terjemah bahasa indonesia", "putar surah yasin", 1),
    ("putar surah al mulk terjemahan indonesia saja", "putar surah al mulk", 2),
    ("putar hanya terjemahan indonesia surah an nas", "putar surah an nas", 2),
    ("play surah al kahf and indonesian translation", "play surah al kahf", 1),
    ("putar surah al baqarah ayat 255", "putar surah al baqarah ayat 255", 0),
]
for u, harap, mode in kasus:
    sisa, md = ekstrak(u.split())
    cek("simulasi: " + u, " ".join(sisa) == harap and md == mode)
sys.exit(1 if gagal else 0)
