#!/bin/sh
# FIX219: kompilasi dan uji mesin waris (Kotlin murni). Perlu kompiler Kotlin embeddable (ada pada distribusi Gradle).
# Pemakaian: tools/uji_waris.sh /jalur/ke/gradle/lib
L="${1:-/opt/gradle-8.14.3/lib}"
CP="$L/kotlin-compiler-embeddable-2.0.21.jar:$L/kotlin-stdlib-2.0.21.jar:$L/kotlin-reflect-2.0.21.jar:$L/kotlin-script-runtime-2.0.21.jar:$L/trove4j-1.0.20200330.jar:$L/annotations-24.0.1.jar:$L/kotlin-daemon-embeddable-2.0.21.jar:$L/kotlinx-coroutines-core-jvm-1.6.4.jar"
OUT="$(mktemp -d)"
java -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -cp "$L/kotlin-stdlib-2.0.21.jar" -d "$OUT" \
  app/src/main/java/com/novan/bateraibicara/HitungWaris.kt tools/UjiWaris.kt && java -cp "$OUT:$L/kotlin-stdlib-2.0.21.jar" UjiWarisKt
