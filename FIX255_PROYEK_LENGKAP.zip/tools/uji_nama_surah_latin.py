#!/usr/bin/env python3
"""Uji FIX153: nama surah pada daftar pilihan dan pembaca layar memakai huruf Latin (bukan Arab).

1. Daftar nama Latin aplikasi (HafalanSrs.NAMA_SURAH): 114 butir, hanya ASCII.
2. Port pembangun label daftar surah: tidak ada karakter Arab pada label, untuk bahasa Indonesia dan English, termasuk bila data tidak punya englishName.
3. Kontrak sumber: tiga tempat tampilan nama surah memakai namaSurahLatin; nama Arab hanya sebagai teks visual yang disembunyikan dari pembaca layar.
Jalankan: python3 tools/uji_nama_surah_latin.py
"""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
KT = ROOT / "app/src/main/java/com/novan/bateraibicara"
ARAB = re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]")
gagal = []
def cek(nama, ok):
    if not ok: gagal.append(nama)

hs = (KT / "HafalanSrs.kt").read_text(encoding="utf-8")
blok = hs[hs.index("NAMA_SURAH ="): hs.index("fun namaSurah")]
NAMA = re.findall(r'"([^"]+)"', blok)
cek("daftar nama Latin berisi 114 surah", len(NAMA) == 114)
cek("daftar nama Latin hanya ASCII", all(re.fullmatch(r"[\x20-\x7E]+", n) for n in NAMA))
cek("daftar nama Latin tanpa duplikat", len(set(NAMA)) == 114)

def nama_latin(nomor, inggris_aktif, data):
    """Port KhatamActivity.namaSurahLatin."""
    if inggris_aktif:
        e = (data.get(nomor, {}).get("englishName") or "").strip()
        if e: return e
    return NAMA[nomor - 1] if 1 <= nomor <= 114 else "Surah %d" % nomor

def labels(inggris_aktif, data):
    return ["%d. %s (%d %s)" % (n, nama_latin(n, inggris_aktif, data), data.get(n, {}).get("numberOfAyahs", 0), "verses" if inggris_aktif else "ayat") for n in range(1, 115)]

# data contoh seperti cache Al-Qur'an: nama Arab ada, englishName kadang kosong
data = {n: {"name": "سُورَةُ ٱلْفَاتِحَةِ", "englishName": ("Al-Faatiha" if n == 1 else ("" if n == 2 else "Name%d" % n)), "numberOfAyahs": 7} for n in range(1, 115)}
for inggris in (False, True):
    L = labels(inggris, data)
    cek("label tanpa karakter Arab (inggris=%s)" % inggris, not any(ARAB.search(x) for x in L))
    cek("label berurutan dan lengkap (inggris=%s)" % inggris, len(L) == 114 and L[0].startswith("1. ") and L[113].startswith("114. "))
cek("Indonesia memakai transliterasi aplikasi", labels(False, data)[1].startswith("2. Al-Baqarah"))
cek("English memakai englishName bila ada", labels(True, data)[0].startswith("1. Al-Faatiha"))
cek("English jatuh ke daftar aplikasi bila englishName kosong", labels(True, data)[1].startswith("2. Al-Baqarah"))

k = (KT / "KhatamActivity.kt").read_text(encoding="utf-8")
def badan(nama_fun):
    i = k.index("private fun " + nama_fun)
    j = k.index("\n    private fun ", i + 10)
    return k[i:j]
cek("pembantu namaSurahLatin ada", "private fun namaSurahLatin(nomor: Int): String" in k)
cek("pilihSurah memakai nama Latin", "namaSurahLatin(nomorDaftar)" in badan("pilihSurah(") and 'optString("name")' not in badan("pilihSurah("))
cek("pilih surah untuk audio memakai nama Latin", "namaSurahLatin(nomor)" in badan("pilihSurahUntukAudio") and 'optString("name")' not in badan("pilihSurahUntukAudio"))
cek("header pembaca memakai nama Latin", "info(namaSurahLatin(nomorSurah))" in k)
cek("nama Arab disembunyikan dari pembaca layar", "IMPORTANT_FOR_ACCESSIBILITY_NO" in k and "namaSurahArab(nomorSurah)" in k)
cek("petunjuk koreksi memuat nama Latin", "namaSurahLatin(nomorSurah) + \" (\" + nomorSurah" in k)
cek("status berpindah memuat nama Latin", k.count("namaSurahLatin(surah)") >= 2)
# nama Arab dari data hanya boleh dipakai di namaSurahArab (tampilan visual); sisanya milik katalog qari/edisi
sisa = [m.start() for m in re.finditer(r'optString\("name"\)', k)]
konteks = [k[max(0, p - 150): p] for p in sisa]
cek("optString(\"name\") hanya untuk nama Arab visual atau katalog qari/edisi",
    all(("namaSurahArab" in c) or ("namaEdisi" in c) or ("namaArab" in c) or ("val name" in c) or ("englishName" in c) for c in konteks))

if gagal:
    print("UJI NAMA SURAH LATIN: GAGAL"); [print(" -", g) for g in gagal]; sys.exit(1)
print("UJI NAMA SURAH LATIN: LULUS (port logika + kontrak sumber)")
