import math, random, sys
sys.path.insert(0,'/home/claude/sim')

class Detektor:
    TAU=0.1; MIN_JEDA=120; JEDA_MAKS=500; JENDELA=1800; TENANG_SEBELUM=700; AKHIR_BURST=300
    NAIK_MAKS=150; MULAI_MAKS=450; RIWAYAT_MS=2000
    def __init__(s, sens=5, longgar=False, cooldown=7000):
        s.sens=sens; s.longgar=longgar; s.cooldown=cooldown; s.siap=False; s.reset()
    def reset(s):
        s.jumlah=0; s.tPertama=0; s.tTerakhir=0; s.tPemicu=-10**9
        s.tenangSejak=-1; s.tenangSebelum=0; s.aktif=False; s.tAwalBurst=0
        s.fase=0; s.maxP=0.0; s.tMax=0; s.minP=0.0; s.tLembah=0; s.tRendah=0
        s.riwayat=[]; s.pending=False; s.tPending=0
    def ambang(s):
        base=7.0-(s.sens-1)*(4.5/9)
        return base*1.8 if s.longgar else base
    def _puncak(s,tp,naik):
        """puncak terkonfirmasi pada waktu tp; naik = ms dari lembah ke puncak. return 'none'|'puncak'|'POLA'"""
        if naik>s.NAIK_MAKS:        # hentakan lambat (mengangkat, berayun) bukan goncangan
            s.batal(); return 'none'
        if s.pending:
            s.pending=False; s.batal(); s.riwayat.append(tp); return 'none'
        s.riwayat=[x for x in s.riwayat if tp-x<=s.RIWAYAT_MS]
        sebelumnya=len(s.riwayat)
        s.riwayat.append(tp)
        if tp-s.tPemicu<s.cooldown: return 'none'
        if s.jumlah>0 and (tp-s.tTerakhir>s.JEDA_MAKS_E() or tp-s.tPertama>s.JENDELA):
            s.batal(); s.jumlah=0
            return 'none'
        if s.jumlah>0 and tp-s.tTerakhir<s.MIN_JEDA:
            return 'none'
        if s.jumlah==0:
            if sebelumnya>=2: return 'none'                 # sudah bergerak berirama
            if not s.longgar:
                if s.tenangSebelum<s.TENANG_SEBELUM: return 'none'
                if tp-s.tAwalBurst>s.MULAI_MAKS: return 'none'
            s.jumlah=1; s.tPertama=tp; s.tTerakhir=tp; return 'puncak'
        s.jumlah+=1; s.tTerakhir=tp
        if s.jumlah>=3:
            if s.longgar:
                s.pending=True; s.tPending=tp; return 'puncak'
            s.jumlah=0; s.tPemicu=tp; s.tenangSebelum=0; return 'POLA'
        return 'puncak'
    def JEDA_MAKS_E(s): return 450 if s.longgar else s.JEDA_MAKS
    def batal(s):
        s.jumlah=0; s.tenangSebelum=0
    def proses(s,x,y,z,t):
        if not s.siap:
            s.gx,s.gy,s.gz=x,y,z; s.last=t; s.siap=True; s.tenangSejak=t; s.tRendah=t; s.tLembah=t; return 'none'
        dt=max(1,min(200,t-s.last))/1000.0; s.last=t
        a=s.TAU/(s.TAU+dt)
        s.gx=a*s.gx+(1-a)*x; s.gy=a*s.gy+(1-a)*y; s.gz=a*s.gz+(1-a)*z
        p=math.sqrt((x-s.gx)**2+(y-s.gy)**2+(z-s.gz)**2)
        amb=s.ambang(); base=amb/1.8 if s.longgar else amb
        # --- keheningan / awal burst ---
        if p < base*0.5:
            if s.tenangSejak<0: s.tenangSejak=t
            if s.aktif and t-s.tenangSejak>=s.AKHIR_BURST: s.aktif=False
        else:
            if not s.aktif:
                s.aktif=True; s.tAwalBurst=t
                s.tenangSebelum=(t-s.tenangSejak) if s.tenangSejak>=0 else 0
            s.tenangSejak=-1
        if p < amb*0.45: s.tRendah=t
        # --- puncak lokal ---
        hasil='none'
        if s.fase==0:
            if p>s.maxP: s.maxP=p; s.tMax=t
            if s.maxP>=amb and p<s.maxP*0.6:
                naik=s.tMax-max(s.tLembah,s.tRendah)
                s.fase=1; s.minP=p; s.tLembah=t; s.maxP=0.0
                hasil=s._puncak(s.tMax,naik)
        else:
            if p<s.minP: s.minP=p; s.tLembah=t
            if p>s.minP+0.25*amb:
                s.fase=0; s.maxP=p; s.tMax=t
        if s.pending and t-s.tPending>=s.JEDA_MAKS_E():
            s.pending=False; s.jumlah=0; s.tPemicu=s.tPending; s.tenangSebelum=0; return 'POLA'
        # kadaluarsa urutan tanpa puncak baru
        if s.jumlah>0 and t-s.tTerakhir>s.JEDA_MAKS_E()+100:
            s.batal()
        return hasil
