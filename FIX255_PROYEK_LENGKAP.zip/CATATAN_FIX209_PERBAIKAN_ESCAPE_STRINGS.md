# FIX209 - Perbaikan kompilasi resource strings

Penyebab: mergeReleaseResources/mergeDebugResources gagal di values-en/strings.xml.
- `isi_petunjuk_penggunaan`, `khatam_menu`, `khatam_judul` (values-en): apostrof `'` tanpa escape ("Qur'an", "Android's") -> "Invalid unicode escape sequence".
- `isi_petunjuk_penggunaan` (values & values-en): tanda `%` literal ("2,5%", "10%, 5%", "(0-100%)") dibaca sebagai format ganda -> "Multiple substitutions in non-positional format".

Perbaikan: `'` -> `\'` pada ketiga string en; `%` literal -> `%%` pada isi_petunjuk_penggunaan di values dan values-en.
Salin dua file ini menimpa file lama di app/src/main/res/.
