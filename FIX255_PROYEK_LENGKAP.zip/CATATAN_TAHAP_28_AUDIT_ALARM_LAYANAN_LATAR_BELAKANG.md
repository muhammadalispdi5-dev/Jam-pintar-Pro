Tahap 28 — Audit alarm dan layanan latar belakang

Versi aplikasi dipertahankan: 1.0.68 (versionCode 68).

Perubahan:
- Memperkuat pemasangan alarm Jam Bicara pada BatteryTalkService.
- Bila pemasangan alarm tepat waktu ditolak oleh SecurityException, jalur alarm non-tepat dicoba dengan perlindungan exception.
- Bila perangkat/ROM melempar exception lain saat pemasangan alarm tepat, jalur alarm non-tepat juga dicoba.
- Kegagalan pada jalur cadangan tidak lagi merambat keluar dari fungsi penjadwalan dan berpotensi mengganggu layanan.

Audit statis terkait:
- BootReceiver menghitung ulang alarm setelah boot, pembaruan aplikasi, perubahan waktu/tanggal/zona waktu, serta perubahan izin Jangan Ganggu.
- ExactAlarmPermissionReceiver menghitung ulang alarm setelah izin alarm tepat waktu diberikan.
- PrayerAlarmReceiver menjadwalkan ulang alarm berikutnya setelah pemicu pengingat dan mempertahankan retry pemulihan Jangan Ganggu yang masih aktif.
- BatteryTalkService memiliki pemeriksaan cadangan berkala untuk mengejar jadwal Jam Bicara yang terlambat maksimal 45 detik serta penjaga menit agar tidak mengucapkan jadwal yang sama dua kali.

Batas verifikasi:
- Ini audit kode statis; belum membuktikan perilaku pada perangkat fisik.
- Build Gradle penuh belum dijalankan karena proyek tidak menyertakan Gradle wrapper.
- Perlu uji perangkat: alarm dengan izin tepat aktif/nonaktif, reboot, perubahan zona waktu, dan Jam Bicara saat layar mati.
