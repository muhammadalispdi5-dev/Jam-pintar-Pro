# FIX215: sakelar perangkat tetap tidak berubah - ketahanan dan diagnosa

Gejala: halaman Pengaturan terbuka sesuai perintah, tetapi sakelar tidak diaktifkan/dinonaktifkan.
Karena targetSdk 36, Android melarang aplikasi biasa mengubah Wi-Fi/Bluetooth/data/pesawat/NFC langsung; satu-satunya jalan adalah menekan
sakelar di layar Pengaturan lewat layanan aksesibilitas "Jam Pintar Pro". Perubahan:
1. Bila layanan belum aktif, kini DIUCAPKAN (bukan hanya Toast) bahwa layanan belum aktif dan sakelar harus diubah manual / layanan diaktifkan.
2. PemilihSakelar: bila beberapa sakelar cocok, dipilih yang paling atas (sakelar utama halaman) alih-alih dibatalkan; fallback "satu-satunya sakelar"
   kini berlaku untuk semua jenis kecuali data seluler.
3. Layanan menjadwalkan percobaan pada setiap kejadian aksesibilitas, bukan hanya dari paket Pengaturan.
4. Permintaan kedaluwarsa tidak lagi dibuang tanpa kabar; saat gagal, pesan menyebut paket jendela aktif dan sakelar yang terlihat
   (string perintah_perangkat_gagal_rinci) untuk membantu pelacakan.
Belum dikompilasi dan belum diuji di perangkat.
