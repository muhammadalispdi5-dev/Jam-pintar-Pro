# FIX250 — Asisten suara: mode acara, lokasi terkini, perbarui lokasi, dan cakupan seluruh fitur

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Logika pengenalan ucapan diuji dengan kotlinc (t250/Uji.kt: SEMUA OK).

## Perintah kendali baru (PerintahSuaraActivity.kt)
- Mode acara: "aktifkan mode acara" (opsional "selama 2 jam", bawaan 60 menit), "matikan mode acara", "apakah mode acara aktif". Memakai cakupan tersimpan; bila izin Jangan Ganggu belum ada, jatuh ke cakupan Jam Pintar Pro dan diberi tahu.
- Sebut lokasi: "saat ini saya berada di lokasi mana", "di mana lokasi saya", "sebutkan lokasi saya", "where am I". Mengambil lokasi langsung (GPS/jaringan), mencari nama tempat, lalu menjawab; bila lokasi langsung gagal memakai lokasi tersimpan.
- Perbarui lokasi otomatis: "perbarui lokasi", "update lokasi otomatis", "segarkan lokasi saya". Menyimpan lokasi langsung sebagai lokasi jadwal sholat dan memasang ulang alarm.
- Sakelar: "aktifkan/matikan jadwal sholat" dan "aktifkan/matikan pengumuman otomatis".

## Cakupan seluruh fitur beranda
Selain fitur yang sudah ada, kini dapat dibuka dengan menyebut namanya: pengaturan jadwal sholat, jadwal bulanan (30 hari), penghemat daya, pemicu asisten, pengaturan goncangan, izin perangkat, paket bahasa offline, hubungi pengembang. Aksi menu beranda lewat suara: petunjuk penggunaan, cadangkan, pulihkan, reset (tetap meminta konfirmasi), info aplikasi, periksa pembaruan (MainActivity memproses extra aksi_suara).
