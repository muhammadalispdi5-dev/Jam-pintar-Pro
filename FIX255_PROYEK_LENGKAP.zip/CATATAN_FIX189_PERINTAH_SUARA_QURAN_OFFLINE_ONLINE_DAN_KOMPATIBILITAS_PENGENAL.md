# FIX189 — Perintah Suara Al-Qur'an Offline/Online dan Kompatibilitas Pengenal Suara

Versi aplikasi tetap **1.0.82** (`versionCode=82`, `versionName=1.0.82`).

## Perubahan

1. Perintah suara tidak lagi bergantung hanya pada `createOnDeviceSpeechRecognizer()` atau dukungan pengenal offline Android 12+.
2. Jika pengenal offline tersedia, aplikasi tetap mengutamakannya.
3. Jika paket bahasa offline tidak tersedia/tidak mendukung bahasa, aplikasi mencoba pengenal suara standar perangkat yang dapat menggunakan jaringan.
4. Jika izin mikrofon langsung aplikasi belum tersedia pada sesi biasa (layar tidak terkunci), aplikasi menggunakan antarmuka pengenal suara sistem sebagai jalur kompatibilitas.
5. Jika permintaan pengenal sistem yang mengutamakan offline gagal, aplikasi mencoba sekali lagi dengan mode daring.
6. Indeks audio lokal untuk perintah suara sekarang disiapkan juga untuk surah-surah dalam juz, juz relatif, dan perintah seluruh Al-Qur'an. Pemindaian tetap dikerjakan pada worker thread, bukan main thread.
7. Pemutar perintah suara sekarang mengirim header HTTP `User-Agent` dan `Accept`, mengikuti jalur pemutar Khatam yang sudah memakai header ini.
8. Pemutar mencoba bitrate CDN 128, 64, 48, 40, 32, dan 192 kbps sebelum menyerah.
9. Bila berkas lokal atau qari pilihan gagal, tersedia URL cadangan Alafasy untuk ayat/surah yang sama. Audio lokal tetap menjadi sumber pertama.

## Pemeriksaan

- `versionCode` dan `versionName` dipastikan tetap 82 / 1.0.82.
- Pemeriksaan struktur kurung kurawal dan tanda kurung pada dua berkas Kotlin yang diubah.
- Pemeriksaan integritas arsip ZIP dan XML resource.
- Kompilasi Gradle/AAPT2 belum dijalankan di lingkungan ini karena Android SDK dan Gradle wrapper tidak tersedia. Build final harus dikonfirmasi melalui GitHub Actions.
