PERBAIKAN JAM PINTAR PRO 1.0.68 — LOKALISASI PEMANDU JALAN

- Memperbaiki label "Uji suara pemandu jalan" agar tampil sebagai "Test walking guide voice" saat bahasa tampilan Inggris aktif.
- Menerjemahkan keterangan mesin TTS pada profil Caller Name dan pengaturan suara navigasi Google Maps.
- Melengkapi terjemahan untuk pesan status GPS, status navigasi, dan pemberitahuan lokasi yang sebelumnya berpotensi tetap berbahasa Indonesia.
- Memeriksa kembali teks antarmuka yang digunakan oleh PemanduJalanActivity agar memiliki pasangan terjemahan bahasa Inggris.
- Mempertahankan versionName 1.0.68 dan versionCode 68 sesuai permintaan.

Pemeriksaan statis: lulus melalui tools/verify_final.py. Pemeriksaan ini tidak menggantikan kompilasi Android penuh atau pengujian langsung pada perangkat.
