# FIX134 — Tombol volume menghentikan seluruh pengumuman berangkai

Versi aplikasi tidak diubah. Basis: FIX133. Berkas diubah: `Pembicara.kt`.

## Gejala
Tombol volume yang semula menghentikan seluruh suara notifikasi (seperti telungkup) tidak lagi berfungsi pada banyak pengumuman.

## Temuan
Mekanisme penghentian (`PembungkamTelungkup`, sakelar "tombol volume", penangkapan tombol di `Halaman`, `PerintahSuaraActivity`,
`BeritahuSayaActivity`) sudah diperiksa dan utuh; uji `uji_tombol_volume.py` dan `uji_pembungkam_notifikasi.py` lulus.
Celahnya ada di `Pembicara.ucapkanRangkaian` (pengumuman beberapa kalimat: waktu, tanggal, libur, baterai, info salat):
1. Tiap kalimat yang selesai melepas pendaftaran ke pembungkam, dan kalimat berikut mendaftar lagi. Pada jeda antarkalimat tidak ada
   suara terdaftar, sehingga tombol volume hanya mengubah volume.
2. Tiap pendaftaran baru yang menyalakan ulang pemantau volume (layar mati/latar belakang) memulai masa tenang 1,2 detik, padahal satu
   kalimat sering hanya 2 sampai 3 detik. Tekanan di masa itu diabaikan.
3. Penghentian di sela jeda tidak membatalkan kalimat yang sudah dijadwalkan; kalimat berikutnya tetap dibacakan.
Telungkup lebih jarang terkena karena gerakan memerlukan waktu dan tidak bergantung pada masa tenang yang sama.

## Perbaikan
- Selama rangkaian berjalan, pendaftaran dipertahankan dari kalimat pertama sampai terakhir (`rangkaianBerjalan`); dilepas saat
  rangkaian selesai atau dihentikan.
- Rangkaian diberi nomor (`idRangkaian`); `berhenti()` (dipanggil tombol volume dan telungkup) menaikkannya sehingga kalimat yang
  tertunda tidak dibacakan lagi. Penghentian di sela jeda kini menghentikan seluruh pengumuman.
- Pendaftaran yang macet dibersihkan oleh pembersih 45 detik dan batas 90 detik seperti sebelumnya.

## Tidak diubah
Sumber suara lain (azan dan pengingat salat, alarm jam, nama pemanggil, notifikasi Khatam dan hafalan) memakai pendaftaran
berkelanjutan sendiri. Audio Al-Qur'an tetap diatur volumenya, bukan dihentikan.

## Batas
Bila volume saluran sudah maksimum, tombol volume ATAS tidak mengubah nilai dan tidak terdeteksi dari latar belakang; tombol BAWAH
dan telungkup tetap bekerja (lihat FIX124). BELUM dikompilasi penuh dan BELUM diuji di perangkat.
Uji manual: pengumuman jam lalu tanggal lalu libur; tekan volume di jeda antarkalimat, di awal kalimat, dan saat layar mati.
