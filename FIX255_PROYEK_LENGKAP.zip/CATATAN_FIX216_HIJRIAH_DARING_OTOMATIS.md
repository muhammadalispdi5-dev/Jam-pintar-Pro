# FIX216: kalender Hijriah tidak bergantung pada data lokal dan diperbarui otomatis secara daring

Sebelumnya: tanggal Hijriah dihitung kalender ICU perangkat, dengan koreksi daring hanya untuk satu hari (offset maksimal 3 hari), mode otomatis
bawaan MATI, dan jadwal puasa Ramadan/Syawal memakai hitungan ICU saja.

Sekarang (HijriahDaring.kt, baru):
- Satu bulan Masehi penuh diunduh dari AlAdhan (gToHCalendar), divalidasi (jumlah hari, urutan hari Hijriah, rentang tahun), lalu disimpan.
  Data cacat tidak pernah disimpan.
- Yang diunduh: bulan lalu, bulan ini, dan 13 bulan ke depan (menutup pergantian tahun Masehi/Hijriah dan Ramadan berikutnya).
- Penyegaran otomatis: bulan ini dan bulan depan paling lambat tiap 2 hari (menangkap penyesuaian tanggal), bulan lain tiap 30 hari.
  Dipicu saat aplikasi dibuka, tiap pengumuman jam, membuka Pengaturan Kalender, dan saat jadwal puasa dihitung. Jeda antar percobaan 3 jam,
  tombol "Perbarui kalender Hijriah sekarang" memaksa unduhan.
- Offline: data terakhir tetap dipakai; ICU perangkat hanya cadangan untuk bulan yang belum pernah diunduh.
- Dipakai oleh: ucapan tanggal Hijriah (jam, perintah suara), FastingSchedule (puasa Ramadan, tanggal puasa Syawal).
- Mode "Koreksi otomatis tanggal Hijriah" kini aktif secara bawaan; pengguna yang sudah memilih manual tetap manual (koreksi manual berlaku).
Batasan: sumber daring adalah AlAdhan, bukan server Kemenag; tanggal dapat berbeda satu hari dari sidang isbat Indonesia.
Belum dikompilasi dan belum diuji di perangkat (jaringan tempat saya bekerja tidak dapat mencapai AlAdhan, sehingga bentuk respons
mengikuti dokumentasi API dan kode gToH yang sudah ada). Uji: tools/uji_hijriah_daring.py.
