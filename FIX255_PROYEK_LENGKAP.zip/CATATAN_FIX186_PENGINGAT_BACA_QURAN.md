# FIX186 - Pengingat membaca Al-Qur'an yang dapat diatur penuh

Basis: FIX185. Versi aplikasi tidak diubah.

## Sebelumnya
Hanya satu waktu harian, tanpa pilihan hari, tanpa nada notifikasi, jadwal berupa alarm berulang tidak tepat (bisa meleset), dan tidak ada tes.

## Sekarang (Pengaturan Khatam > Pengingat membaca Al-Qur'an)
- **Waktu pengingat:** sampai 8 waktu per hari; ketuk waktu untuk mengubah atau menghapus, atau tambah waktu baru. Waktu lama (satu jam dan menit) otomatis dibawa sebagai waktu pertama.
- **Hari pengingat:** pilih satu atau beberapa hari (Senin sampai Minggu), atau tombol "Setiap hari".
- **Jenis suara:** nada alarm bawaan Android, nada notifikasi bawaan Android (baru), ucapan Android, atau berkas suara sendiri (nama berkas ditampilkan). Pilihan yang sama berlaku di pengingat hafalan cerdas.
- **Tes pengingat sekarang:** membunyikan pengingat saat itu juga dengan suara terpilih.
- **Tunda:** tombol "Tunda 10 menit" pada notifikasi.
- Status menampilkan kapan pengingat berikutnya berbunyi. Sakelar aktif/nonaktif tersendiri.
- Jadwal memakai alarm tepat waktu (setExactAndAllowWhileIdle) bila izin alarm tepat diberikan, selain itu alarm hemat daya yang tetap dibangunkan saat Doze. Satu alarm untuk kejadian berikutnya dipasang ulang setiap kali bunyi, setelah ponsel dinyalakan ulang, aplikasi diperbarui, atau izin alarm tepat berubah.
- Tombol Kembali sistem di semua dialog ini kembali ke induknya. "Reset pengaturan Khatam" ikut membatalkan alarm.
- Berkas baru `PengingatBaca.kt`; berubah: `KhatamActivity.kt`, `KhatamReminderReceiver.kt`, `KhatamReminderBootReceiver.kt`, `ExactAlarmPermissionReceiver.kt`, `SuaraPengingat.kt`. Uji statis dan simulasi jadwal: `tools/uji_fix186_pengingat_baca.py`.
- Teks mengikuti bahasa aktif (tr(id, en)); pemeriksa bahasa dan resource string lulus. Belum dikompilasi dan belum diuji di perangkat; perilaku alarm dan notifikasi berbeda antar merek, mohon uji dengan penghemat daya aktif.
