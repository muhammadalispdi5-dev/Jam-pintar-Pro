# Catatan pengembangan Jam Pintar Pro 1.0.68

## Pemandu jalan kaki
- Menambahkan kolom lokasi awal dan tujuan.
- Kolom lokasi awal yang kosong menggunakan posisi GPS terkini; lokasi awal yang diisi pengguna digunakan sebagai titik asal tanpa meminta GPS terlebih dahulu.
- Menambahkan pemilihan lokasi tersimpan untuk titik awal dan tujuan.
- Menambahkan penyimpanan tujuan teks/alamat menggunakan nama pilihan pengguna. Data disimpan secara lokal pada perangkat dan menggunakan daftar lokasi tersimpan yang sama dengan fitur Lokasi Terkini.
- Menambahkan pemilihan mesin TTS tersendiri untuk pemandu jalan dan tombol uji suara.
- Petunjuk belokan tetap diberikan oleh Google Maps; pilihan TTS internal Jam Pintar Pro tidak mengubah pengaturan suara Google Maps.

## Lokasi terkini
- Menambahkan pemilihan mesin TTS tersendiri untuk fitur Lokasi Terkini.
- Menambahkan berbagi nama/koordinat/tautan peta melalui menu berbagi Android.
- Menambahkan tindakan membuka titik koordinat melalui intent geo dan chooser aplikasi, sehingga pengguna dapat memilih aplikasi yang mendukungnya untuk meneruskan titik jemput.
- Memperluas daftar lokasi tersimpan agar dapat menampung tujuan berbentuk alamat/teks selain lokasi yang memiliki koordinat GPS.

## Bahasa
- Menambahkan terjemahan label, dialog, dan pesan untuk bahasa Inggris.
- Petunjuk suara profil `pemandu` dan `lokasi` mengikuti bahasa tampilan utama aplikasi. Profil suara lain tetap mengikuti pengaturan bahasa ucapannya sendiri.
- Nama tempat atau label yang dimasukkan pengguna dipertahankan dan tidak diterjemahkan.

## Batasan verifikasi
- Versi aplikasi tetap 1.0.68 / versionCode 68 sesuai permintaan sebelumnya.
- `tools/verify_final.py` lulus dan pemeriksaan sintaks statis Kotlin tidak menemukan kesalahan sintaks.
- Lingkungan kerja ini tidak memiliki Gradle/Gradle Wrapper, sehingga kompilasi APK dan uji pada perangkat Android belum dapat dilakukan di sini.
- Titik jemput dibuka melalui intent lokasi `geo:` dan menu pemilihan aplikasi. Dukungan penerimaan titik tersebut bergantung pada aplikasi transportasi yang terpasang; pengguna tetap perlu memeriksa titik jemput di aplikasi transportasi sebelum memesan.
