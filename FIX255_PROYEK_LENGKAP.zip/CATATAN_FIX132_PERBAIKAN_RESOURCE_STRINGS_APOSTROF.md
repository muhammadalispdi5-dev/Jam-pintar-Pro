# FIX132 — Perbaikan gagal kompilasi `:app:mergeDebugResources` (resource string Inggris)

Versi aplikasi tidak diubah. Basis: FIX131.

## Kesalahan dari CI
`values-en/strings.xml`: Failed to flatten XML for resource 'perintah_fitur_tidak_dikenal' ... Invalid unicode escape sequence in string.
Akibatnya `:app:mergeDebugResources` dan `:app:mergeReleaseResources` gagal.

## Penyebab
String `perintah_fitur_tidak_dikenal` di `values-en` memakai apostrof ASCII tanpa escape: `I couldn't identify ...`.
Resource Android tidak boleh memuat apostrof polos; aapt2 menolak string itu saat meratakan XML. Berkas ini punya kebiasaan
sendiri untuk apostrof (`Qur\'an`, atau tanda ’ pada "Ta’aruf"), dan string baru melanggarnya.
Catatan: nomor baris pada log CI (470) berbeda dari berkas di arsip ini (464); isi string yang sama dan satu-satunya apostrof
polos pada seluruh `res/values*` adalah string ini, sehingga itulah yang diperbaiki.

## Perbaikan
- `values-en/strings.xml`: kalimat disusun ulang tanpa kontraksi: "I could not identify which app feature you meant.
  Please say the feature name." Maknanya sama dan tidak memuat karakter khusus.
- Dua string di `values-en` yang masih berbahasa Indonesia ikut dibenahi karena melanggar aturan bahasa aktif:
  `update_tersedia_isi` ("Version %1$s is available (you are using version %2$s).") dan `update_memeriksa` ("Checking for updates…").
- `values/strings.xml`: `info_jam_awalan` memakai tanda kutip ganda polos ("It is") yang ditelan aapt2 dari teks;
  diganti tanda kutip tipografis “It is” seperti versi Inggrisnya.
- **Pencegahan:** `tools/periksa_resource_strings.py` meniru aturan aapt2 dan dijalankan oleh `tools/verify_project.py`
  (langkah pertama workflow sebelum Gradle). Ia gagal bila ada apostrof polos, `\u` yang tidak diikuti empat digit heksadesimal,
  backslash tak dikenal, kutip ganda polos, awal teks `@`/`?`, format ganda tanpa nomor posisi, atau nama string ganda.
  Diuji pada arsip FIX131 asli: pemeriksa menangkap string ini dan `info_jam_awalan`; pada arsip ini lulus.

## Pemeriksaan
- `tools/periksa_resource_strings.py`: LULUS. `tools/verify_project.py`: LULUS, termasuk `periksa_bahasa_aktif.py`.
- BELUM dijalankan lewat Gradle/aapt2 sungguhan di lingkungan ini (tidak ada Android SDK); build ulang di GitHub Actions diperlukan
  untuk memastikan.

## Bahasa aktif
Perubahan hanya pada resource: `values-en` (teks Inggris diperbaiki, dua string yang tersasar berbahasa Indonesia kini Inggris) dan
`values` (kutip). Kunci kedua berkas tetap sama (433). Pemeriksa bahasa aktif: LULUS.
