# FIX94 — Pemicu perintah suara dengan goncangan

## Fitur
- Menambahkan halaman pengaturan khusus pemicu goncangan, diakses dari bagian pemicu suara pada beranda.
- Sakelar aktif/nonaktif terpisah; keadaan disimpan di SharedPreferences.
- Slider sensitivitas 1–10: 1 memerlukan goncangan lebih kuat, 10 mendeteksi goncangan lebih ringan.
- Deteksi dua puncak goncangan dalam jendela 1,5 detik, dengan jeda antarpemicu 7 detik dan hysteresis untuk menghindari satu gerakan panjang dihitung dua kali.
- Layanan sensor foreground dengan notifikasi tetap dan tindakan untuk menonaktifkan layanan.
- Mengutamakan akselerometer wake-up; bila tidak tersedia, memakai partial wake lock selama fitur aktif agar sensor non-wakeup tetap dapat dipantau saat layar mati. Kondisi ini dapat meningkatkan konsumsi baterai.
- Berusaha memulihkan layanan setelah boot/pembaruan hanya jika sakelar masih aktif.
- Saat dipicu, membuka PerintahSuaraActivity dengan flag layar terkunci; jalur ini tidak bergantung pada sakelar widget Beritahu Saya.
- Semua label dan pemberitahuan tambahan mengikuti bahasa tampilan aplikasi yang tersedia pada proyek (Indonesia/English).

## Batasan Android
- Android/OEM dapat membatasi peluncuran Activity dari latar belakang, akses sensor ketika layar mati, atau mematikan layanan melalui penghemat baterai. Jika pembukaan otomatis ditahan sistem, notifikasi alternatif ditampilkan agar pengguna dapat mengetuk untuk mulai berbicara.
- Pengenalan ucapan tetap memakai layanan pengenalan suara sistem. Ketersediaan dan tampilan layar pengenal saat perangkat terkunci bergantung pada versi Android dan aplikasi pengenal suara.
- Fitur tidak merekam atau mengirim audio secara terus-menerus di latar belakang. Mikrofon baru digunakan ketika layar pengenalan suara dibuka.
- Pengguna dapat mematikan pemicu kapan saja dari sakelar pengaturan atau tindakan notifikasi.

## Berkas utama
- `GoncanganSuaraService.kt`
- `PengaturanGoncanganActivity.kt`
- `PerintahSuaraActivity.kt`
- `MainActivity.kt`
- `BootReceiver.kt`
- `AndroidManifest.xml`

Versi aplikasi dinaikkan menjadi 1.0.70 (versionCode 70).
