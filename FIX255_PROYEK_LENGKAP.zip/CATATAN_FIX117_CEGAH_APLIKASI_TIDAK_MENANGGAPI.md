# FIX117 — Aplikasi tidak menanggapi dan menutup sendiri setelah beberapa perintah suara

Versi aplikasi tidak diubah. Basis: FIX116. Berkas diubah: `HariLibur.kt`.

## Gejala
Perintah suara beberapa kali berjalan normal, lalu aplikasi "tidak menanggapi" (ANR), dan setelah diulang aplikasi menutup sendiri.

## Dugaan penyebab
`HariLibur.nearest` mencari libur terdekat dengan memeriksa sampai 3.660 hari satu per satu di thread utama. Tiap hari memformat
tanggal, membaca SharedPreferences, dan memanggil `Prefs.bahasaAktif` (yang ikut membaca pengaturan dan konfigurasi). Pencarian itu
dipanggil beberapa kali per jawaban (lampau, terkini, mendatang, dua kategori), sehingga membebani thread utama, terutama pada HP
yang lambat atau saat penulisan pengaturan sedang berjalan. Penyebab ini adalah dugaan dari pembacaan kode; log crash belum ada.

## Perbaikan
- `nearest` kini memakai daftar tanggal libur yang dikenal (`tanggalDikenal`: daftar bawaan 2026 + data sinkronisasi tersimpan),
  menyaring menurut arah dan batas 3.660 hari, lalu mengurutkan. Hasil sama dengan sebelumnya, hanya puluhan tanggal yang diperiksa.
- Bahasa aktif dibaca sekali per pencarian, tidak per hari.

## Pemeriksaan
- `verify_project.py` dan `periksa_bahasa_aktif.py` lulus. BELUM dikompilasi penuh dan BELUM diuji di perangkat.
- Bila masih tidak menanggapi, kirim log crash (logcat) atau catat perintah suara apa yang diucapkan sebelum aplikasi macet.
