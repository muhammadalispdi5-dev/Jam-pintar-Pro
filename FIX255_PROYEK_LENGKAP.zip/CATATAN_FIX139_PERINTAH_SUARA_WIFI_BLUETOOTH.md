# FIX139 — Penyempurnaan sakelar Wi-Fi dan Bluetooth

Perubahan dibuat di atas sumber FIX138 dengan mempertahankan identitas versi aplikasi.

- Memperluas pengenalan nama sakelar Wi-Fi dan Bluetooth, termasuk variasi label Android.
- Memperketat pemilihan sakelar agar tidak salah menekan kontrol perangkat lain pada halaman pengaturan gabungan.
- Memperbaiki fallback halaman khusus: satu sakelar yang terlihat dapat dipilih bila tidak ada label yang terbaca dan tidak ada sakelar lain yang berpotensi tertukar.
- Menghapus pembatasan daftar paket pada konfigurasi layanan aksesibilitas agar halaman Pengaturan dari produsen perangkat yang berbeda dapat mengirimkan event; layanan tetap hanya bertindak saat ada perintah pengguna yang masih aktif dan halaman dikenali sebagai Pengaturan.
- Membaca status dari `isChecked` dan `stateDescription` bila tersedia, lalu memverifikasi perubahan sebelum mengumumkan hasil.
- Seluruh pesan dan pengumuman tetap memakai resource bahasa aktif yang sudah ada.

Versi aplikasi tetap: versionCode 81, versionName 1.0.81.

Catatan: kontrol sakelar melalui Accessibility bergantung pada izin layanan aksesibilitas dan struktur tampilan Pengaturan masing-masing perangkat. Pengujian akhir perlu dilakukan pada perangkat fisik; perubahan ini tidak menjamin semua antarmuka OEM mengekspos sakelar dengan struktur yang sama.
