# FIX118 - Layar Khatam kosong dan kursor TalkBack tidak bergerak setelah beberapa perintah suara

Versi aplikasi tidak diubah. Basis: FIX117. Berkas diubah: `KhatamActivity.kt`. Berkas baru: `tools/uji_pemulihan_jendela_khatam.py`.

## Gejala
Setelah beberapa perintah suara, perintah masih ditanggapi tetapi tindakannya tidak berjalan. Saat aplikasi dibuka, posisinya berada di Khatam
dan kursor (fokus TalkBack) tidak dapat digerakkan sama sekali.

## Penyebab (dari pembacaan kode; log crash belum ada)
Sejak FIX87, perintah putar dari layar depan menjalankan Khatam dalam keadaan tersembunyi: tema transparan, konten `INVISIBLE`, alpha jendela 0,
lalu `moveTaskToBack`. Tidak ada kode yang pernah memulihkannya. Khatam berjenis `singleTask`, jadi contoh yang sama (masih tersembunyi)
dipakai lagi. Saat aplikasi dibuka kembali, atau Khatam dibuka dari menu, pengguna berhadapan dengan jendela transparan tanpa elemen terlihat,
sehingga TalkBack tidak punya apa pun untuk difokuskan. Perintah berikutnya diteruskan ke contoh yang macet itu.

## Perbaikan
- `pulihkanJendelaKhatam()`: konten kembali `VISIBLE`, alpha 1, latar jendela opak (warna latar aplikasi), warna bilah status/navigasi, dan
  pemberitahuan perubahan jendela ke TalkBack. Pemutaran audio tidak dihentikan (tidak memakai `recreate()`).
- Dipulihkan saat: Khatam dibuka tanpa perintah latar (`onNewIntent`), Khatam kembali ke depan setelah dikembalikan ke belakang (`onResume`
  setelah `onStop`), dan jaring pengaman 6 detik bila Khatam masih di depan padahal harusnya sudah dikembalikan ke belakang.
- Perintah latar yang baru tetap berjalan tersembunyi (penanda `latarMenunggu`), sehingga perilaku FIX87 tidak berubah.
- Bila sistem membuat ulang Khatam (rotasi, mode gelap, proses dimatikan), perintah lama dan permintaan sembunyi dari intent asli dibuang,
  agar perintah tidak terulang dan jendela tidak tersembunyi lagi.

## Bahasa aktif
Tidak ada teks baru yang terlihat pengguna; pemeriksa bahasa aktif lulus.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, `uji_pemulihan_jendela_khatam.py` lulus; kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat.
- Bila "perintah merespons tetapi tidak bertindak" masih terjadi di luar kasus layar kosong, kirim log crash (logcat) dan catat perintah
  yang diucapkan, apakah dari layar depan atau dari dalam aplikasi, serta apakah audio berbunyi.
