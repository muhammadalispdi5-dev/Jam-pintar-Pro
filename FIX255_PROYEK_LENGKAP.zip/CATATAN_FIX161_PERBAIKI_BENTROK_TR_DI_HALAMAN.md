# FIX161 — Perbaikan galat kompilasi `'tr' hides member of supertype 'Halaman'`

Sumber: FIX160. Menindaklanjuti GitHub Actions Run ID 41778409414 (`:app:compileReleaseKotlin` dan `:app:compileDebugKotlin` gagal).
Versi tetap `versionName 1.0.82`, `versionCode 82`.

## Penyebab
FIX160 menambahkan `protected fun tr(indonesia, english)` ke kelas dasar `Halaman`. Tiga turunan Halaman sudah punya
`private fun tr(id, en)` sendiri dengan tanda tangan yang sama, sehingga Kotlin menolaknya:
- `JamActivity.kt:286`
- `KhatamActivity.kt:183`
- `TaarufDoaActivity.kt:21`
Kotlin mewajibkan `override` bila anggota turunan menyembunyikan anggota induk, dan `Halaman.tr` bukan `open`.

## Perbaikan
Tiga definisi privat itu dihapus; ketiga halaman kini memakai `Halaman.tr`. Perilakunya identik:
- `JamActivity` dan `KhatamActivity`: `if (BahasaAplikasi.tampilan(this) == 1) en else id`, sama persis dengan `Halaman.tr`.
- `TaarufDoaActivity`: `if (english) en else id`, dengan `english` = `BahasaAplikasi.tampilan(this) == 1`, setara. Properti `english` dipertahankan karena dapat dipakai di tempat lain.
Tidak ada pemanggilan `tr` dengan argumen bernama, referensi `::tr`, atau pemakaian di `companion object` yang terpengaruh (pemakaian `tr` terdeteksi hanya di dalam badan kelas turunan).
`Halaman.tr` tetap ada karena `Halaman.kt` sendiri memakainya (blok Volume mandiri dan efek pengumuman).
`PerintahSuaraActivity`, `PemutarQuranService`, dan `TimerJamService` punya `tr` privat sendiri tetapi bukan turunan `Halaman`, jadi tidak bentrok.

## Pencegahan
`tools/periksa_bentrok_anggota_halaman.py` (baru, dipanggil dari `verify_project.py`) memindai turunan `Halaman` dan menandai fungsi atau
properti yang menyembunyikan anggota non-private `Halaman` tanpa `override`. Diuji pada FIX160 asli: mendeteksi tepat tiga galat di atas
(keluar kode 1); pada hasil perbaikan: lulus.

## Pemeriksaan dan batas
- Kurung `()` `{}` `[]` seimbang pada tiga berkas yang diubah.
- `verify_project.py`, `periksa_bahasa_aktif.py`, `periksa_resource_strings.py`, dan seluruh `tools/uji_*.py` lulus.
- Lingkungan ini tidak punya Gradle atau Android SDK, jadi `:app:compileDebugKotlin` BELUM dijalankan. Galat lain yang baru muncul setelah ketiga galat
  ini hilang hanya dapat terlihat saat kompilasi di GitHub Actions.

## Catatan tentang `verify_project.py`
Skrip itu melaporkan "Workflow build.yml tidak ditemukan" pada FIX160 asli maupun hasil ini. Itu bukan akibat perubahan ini: berkas workflow berada
di `.github/workflows/` pada akar repositori, di luar folder `fix159_work` yang dikirim, sehingga tidak terlihat dari sini. Semua pemeriksaan lain di skrip itu lulus.
