# FIX77 — Hafalan per kelompok ayat (jumlah ayat ditentukan pengguna)

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX76. Berkas diubah: `KhatamActivity.kt`.

## Fitur
Pengaturan Khatam > Pengaturan hafalan > **Hafalan per kelompok ayat**:
- **Jumlah ayat per kelompok**: pilihan 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, atau **Angka lain…** (ketik sendiri 1 sampai 100).
- **Jumlah pengulangan kelompok**: 1, 2, 3, 4, 5, 7, 10, 15, 20, terus-menerus, atau **Angka lain…** (1 sampai 99).
- **Setelah kelompok selesai**: lanjut ke kelompok berikutnya (bawaan) atau berhenti.
- **Mode hafalan kelompok**: aktif atau nonaktif. Mengubah jumlah ayat atau pengulangan otomatis mengaktifkannya. Mode juga bisa dipilih di Mode hafalan audio (pilihan ke-4).

## Cara kerja
- Kelompok dimulai dari ayat yang dipilih untuk diputar, lalu mencakup N ayat berikutnya. Kelompok berhenti di akhir surah (tidak melewati batas surah).
- Ayat dalam kelompok diputar berurutan dengan "Jeda antar ayat". Setelah ayat terakhir, seluruh kelompok diulang sebanyak pengaturan, lalu lanjut ke kelompok berikutnya atau berhenti.
- Setiap ayat dalam kelompok tetap memakai "Jumlah pengulangan ayat"; saat mode kelompok diaktifkan nilainya diatur ke 1 (sekali per putaran) agar kelompok tidak terulang terlalu banyak. Dapat diubah kembali.
- Setelah kelompok selesai dan berhenti, posisi kembali ke awal kelompok sehingga tombol putar mengulang kelompok yang sama.
- Status audio menyebut putaran ke berapa; ringkasan "Mode saat ini" di halaman Khatam ikut menampilkan pengaturan kelompok. Pengumuman pergantian mengikuti sakelar TalkBack (FIX52).

## Bahasa
Semua teks baru (menu, dialog, pesan status, pesan salah-input, ringkasan) memakai `tr()` sehingga otomatis mengikuti bahasa aktif aplikasi (Indonesia atau Inggris), termasuk bentuk tunggal/jamak (1 verse / 2 verses, 1 time / 2 times).

## Perbaikan kecil
- Lima baris lama di `KhatamActivity.kt` yang masih memakai tanda `$` pada teks (jumlah surah qari, tombol equalizer, rentang surah, nama surah) diganti penggabungan teks biasa, sejalan dengan FIX53.

## Batas
- Hanya berlaku untuk pemutaran per ayat dengan qari audio per ayat. Qari anak MP3Quran (audio per surah) tidak mendukung hafalan per ayat maupun kelompok.
- Pengaturan yang diubah saat audio sedang berjalan berlaku pada kelompok berikutnya yang dimulai.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: kelompok 3 ayat diulang 3 kali lalu lanjut; kelompok di ujung surah; angka khusus; ganti bahasa; TalkBack.
