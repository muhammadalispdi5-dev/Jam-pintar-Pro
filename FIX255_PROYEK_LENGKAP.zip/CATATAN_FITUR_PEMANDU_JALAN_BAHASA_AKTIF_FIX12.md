PERBAIKAN FIX12 — BAHASA AKTIF PADA PEMANDU JALAN

Perubahan:
- Menambahkan padanan bahasa Inggris untuk label, bantuan, status, pesan GPS, pemilihan mode, penyimpanan/pemilihan lokasi, dan pesan mesin suara di fitur Pemandu Jalan.
- Pesan mode berjalan kaki dan berkendara memiliki padanan lengkap, sehingga nama mode tidak tertinggal dalam bahasa Indonesia saat bahasa Inggris aktif.
- Pesan yang menyertakan nama lokasi yang dipilih pengguna mempertahankan nama lokasi tersebut dan menerjemahkan kalimat di sekelilingnya.
- Bahasa navigasi pada tautan Google Maps tetap mengikuti bahasa tampilan aktif aplikasi (Indonesia/Inggris). Suara petunjuk belokan Google Maps tetap mengikuti pengaturan suara navigasi Google Maps.

Pemeriksaan:
- Arsip sumber diperiksa setelah dibuat.
- Kompilasi APK belum dijalankan di lingkungan ini karena Gradle/Gradle Wrapper tidak tersedia.
