# FIX163 — Penambahan pilihan efek vokal Jam dan Baterai

## Perubahan
- Menambahkan pilihan **Gema lembut (echo-like)**, **Studio vokal**, **Karaoke**, dan **Panggung konser** pada pengaturan efek vokal untuk profil Jam dan Baterai.
- Pilihan lama tetap pada indeks yang sama agar preferensi pengguna yang sudah tersimpan tidak berubah.
- Batas indeks preferensi diperluas dari 7 menjadi 11 pilihan (indeks 0–10).
- Pemetaan memakai preset `PresetReverb` Android yang paling mendekati: echo-like dan studio vokal memakai Plate; Karaoke memakai Medium Room; Panggung konser memakai Large Hall.
- Dialog menjelaskan pemetaan tersebut secara transparan. Android tidak menyediakan efek echo/delay universal yang dapat dijamin bekerja pada semua mesin TTS; karena itu opsi gema merupakan karakter reverb yang menyerupai gema, bukan efek delay berulang murni.
- Efek Khatam Al-Qur'an tidak diubah.
- Bahasa antarmuka mengikuti bahasa aktif aplikasi.
- Versi aplikasi tetap 1.0.82 / versionCode 82.

## Batasan dan pengujian
Efek TTS hanya dapat diterapkan jika mesin TTS/perangkat menyediakan sesi audio yang dapat dikendalikan. Karakter bunyi dapat berbeda antar mesin TTS dan perangkat. Pemeriksaan skrip statis proyek dijalankan; kompilasi Gradle dan pengujian perangkat belum dilakukan di lingkungan ini.
