# FIX175 — Perbaikan pemutaran Al-Qur'an offline melalui asisten suara

Versi aplikasi tetap: `versionCode 82`, `versionName 1.0.82`.

## Perbaikan
1. Perintah untuk memutar satu surah kini mencari berkas audio surah utuh di penyimpanan lokal terlebih dahulu.
2. Jika berkas surah utuh tidak ditemukan, pemutar mencari seluruh audio per ayat untuk surah tersebut. Jika semua ayat tersedia, audio lokal diputar berurutan dari ayat pertama sampai terakhir tanpa meminta audio surah dari internet.
3. Pencocokan berkas tidak lagi bergantung sepenuhnya pada awalan nama qari. Nomor surah/ayat pada nama berkas menjadi identitas utama sehingga perubahan label qari akibat pergantian bahasa tidak memutus pencarian. Nama qari terpilih tetap diprioritaskan saat ditemukan.
4. Pencarian mendukung struktur folder qari yang baru, folder unduhan lama, Download/MediaStore, dan folder khusus SAF yang dipilih pengguna.
5. Nama folder jenis audio mengikuti bahasa aktif: Indonesia menggunakan `Audio Per Surah` / `Audio Per Ayat`; English menggunakan `Audio by Surah` / `Audio by Verse`.

## Bahasa aktif
Seluruh teks baru pada FIX175 menggunakan `tr(teks Indonesia, English text)`. Pemeriksaan `python3 tools/periksa_bahasa_aktif.py` lulus. Aturan tetap dalam `ATURAN_BAHASA_AKTIF.md` tetap berlaku untuk seluruh perubahan berikutnya.

## Pemeriksaan
- Arsip sumber FIX174 valid sebelum perubahan.
- Pemeriksaan bahasa aktif: LULUS (sisa literal lama: 466; tidak bertambah).
- Pemeriksaan resource string: LULUS.
- Pemeriksaan bentrok anggota Halaman: LULUS (39 anggota).
- `tools/verify_project.py` belum lulus karena repositori ZIP ini tidak menyediakan workflow bernama `.github/workflows/build.yml`; pemeriksaan bahasa, resource, dan bentrok anggotanya sendiri lulus.
- Kompilasi Android/Gradle dan uji pada perangkat belum dilakukan. Karena itu FIX175 belum boleh dianggap sudah lolos build atau uji perangkat.
