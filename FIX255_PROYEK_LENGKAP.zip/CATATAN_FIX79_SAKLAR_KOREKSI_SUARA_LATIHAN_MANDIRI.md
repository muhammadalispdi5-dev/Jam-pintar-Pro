# FIX79 - Saklar fitur hafalan di Pengaturan Hafalan
Pengaturan Khatam > Pengaturan Hafalan > "Fitur latihan hafalan (saklar)":
- Koreksi otomatis dengan pengenalan suara (hafalan_koreksi_suara_aktif)
- Latihan hafalan tanpa mikrofon (hafalan_latihan_mandiri_aktif)
Aktif = tombol tampil dan dapat dijalankan di halaman utama Khatam. Nonaktif = tombol disembunyikan dan fungsi menolak berjalan. Default aktif; ikut direset oleh Reset pengaturan. Belum dikompilasi/diuji.
