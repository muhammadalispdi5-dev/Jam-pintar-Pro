# FIX127 — Perintah suara untuk menelepon kontak atau nomor

## Perubahan
- Perintah `telepon`, `telpon`, `panggil`, `hubungi`, `call`, `phone`, atau `dial` tetap dikenali.
- Pengguna dapat menyebut nama/nomor dalam satu kalimat (misalnya `telepon Budi`) atau menyebut `telepon` dahulu, lalu menyebut nama/nomor pada sesi pengenalan suara berikutnya.
- Nomor yang dikenali langsung dibuka pada dialer sistem.
- Pencarian kontak menggunakan izin `READ_CONTACTS` yang diminta saat diperlukan.
- Jika ada beberapa kontak/nomor yang cocok, aplikasi menampilkan daftar pilihan agar pengguna menentukan tujuan yang benar.
- Setelah tujuan dipilih, aplikasi membuka dialer sistem dengan nomor terisi. Dialer perangkat/Android tetap mengatur pemilihan SIM.
- Bahasa petunjuk dan pesan mengikuti bahasa aplikasi aktif.

## Batasan keamanan dan Android
Aplikasi sengaja menggunakan `ACTION_DIAL`, bukan `ACTION_CALL`: aplikasi tidak melakukan panggilan tanpa tindakan sadar pengguna. Pengguna tetap menekan tombol **Panggil** pada dialer. Android tidak menyediakan API umum untuk memaksa semua aplikasi dialer menampilkan dialog pemilihan SIM; dialog SIM muncul sesuai dukungan dialer dan pengaturan SIM perangkat (misalnya pilihan SIM `Tanya setiap kali`).

## Pengujian
Arsip sumber diperiksa integritasnya. Kompilasi Gradle dan pengujian pada perangkat fisik belum dilakukan karena proyek yang diterima tidak menyertakan `gradlew` dan lingkungan ini tidak menyediakan perintah `gradle`. Uji pada perangkat disarankan untuk memverifikasi pengenal suara, izin kontak, dialog pilihan kontak, perilaku SIM, dan dialer sesuai merek HP.
