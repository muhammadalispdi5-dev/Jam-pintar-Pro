# FIX147 — Timer hitung mundur pada fitur Jam

Berasal dari source FIX146_PENYESUAIAN_VOLUME_SEMUA_AUDIO.

## Fitur yang ditambahkan
- Menu **Timer hitung mundur / Countdown timer** pada kategori Jam.
- Pengaturan durasi jam, menit, dan detik; validasi durasi 1 detik sampai 99 jam 59 menit 59 detik.
- Kontrol mulai, jeda, lanjutkan, reset, dan hentikan alarm.
- Foreground service khusus timer agar hitung mundur tetap berjalan ketika layar mati atau pengguna berpindah aplikasi.
- Notifikasi status timer dengan tindakan Jeda/Lanjutkan/Reset/Hentikan alarm.
- Alarm menggunakan nada sistem, suara pembaca, atau keduanya; suara pembaca memakai profil TTS Jam yang aktif.
- Pengumuman sisa waktu dapat diaktifkan/dinonaktifkan; pengumuman dilakukan mendekati 1 menit, 30 detik, dan sepuluh detik terakhir.
- Pemulihan hitung mundur aktif setelah proses layanan dibuat ulang dan setelah perangkat reboot/pembaruan aplikasi, dengan membandingkan waktu akhir yang tersimpan.
- Perintah suara dasar: "pasang timer lima menit", "jeda timer", "lanjutkan timer", "berapa sisa waktu timer", "reset timer", dan "hentikan alarm timer". English equivalents are supported for the corresponding timer/countdown terms and common number words.
- Label, status, notifikasi, dan jawaban suara timer mengikuti bahasa tampilan Indonesia/English. TTS memakai profil suara Jam.

## Catatan teknis dan batas pengujian
- Timer menggunakan waktu akhir sistem (epoch) agar sisa waktu dapat dihitung ulang setelah proses/perangkat dimulai kembali.
- Layanan foreground menggunakan tipe `specialUse` dan deklarasi subtype untuk hitung mundur yang dimulai eksplisit oleh pengguna.
- Source ZIP ini belum dapat dikompilasi di lingkungan penyuntingan karena paket proyek tidak menyertakan `gradlew`/Gradle Wrapper dan executable Gradle tidak tersedia. Pemeriksaan integritas arsip/XML dilakukan sebelum distribusi; kompilasi APK tetap perlu dilakukan oleh pipeline build pengguna.
- Pengumuman TTS akhir dan alarm nada memakai profil suara Jam; pemutaran nada dan TTS bersamaan bergantung pada kebijakan audio focus/volume perangkat.
