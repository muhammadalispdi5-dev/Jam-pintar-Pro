# FIX149 — Gagal kompilasi `:app:mergeReleaseResources` / `:app:mergeDebugResources` (isi_petunjuk_penggunaan)

Versi aplikasi tidak diubah. Basis: FIX148. Berkas diubah: `app/src/main/res/values/strings.xml`, `app/src/main/res/values-en/strings.xml`.

## Kesalahan dari CI
`values/strings.xml:36:4: Failed to flatten XML for resource 'isi_petunjuk_penggunaan' with error: Invalid unicode escape sequence in string`
(jenis kesalahan yang sama dengan FIX132; aapt2 memakai pesan itu untuk string yang memuat apostrof polos).

## Penyebab
Petunjuk penggunaan yang diperpanjang pada FIX148 menambah kalimat tentang Al-Qur'an dan Khatam. Teks itu memuat apostrof ASCII
tanpa backslash: 6 tempat di `values` (mis. "Al-Qur'an dan Khatam") dan 9 tempat di `values-en` ("Qur'an", "player's", "phone's",
"feature's"). Resource Android mewajibkan apostrof ditulis `\'`.

## Perbaikan
Semua apostrof polos pada `isi_petunjuk_penggunaan` di kedua bahasa diberi backslash (`Al-Qur\'an`). Isi kalimat tidak berubah.
Pemeriksa `tools/periksa_resource_strings.py` (FIX132) menangkap kesalahan ini pada arsip FIX148 dan kini lulus.

## Pemeriksaan
- `tools/periksa_resource_strings.py`: LULUS (kedua berkas, seluruh `res/values*`).
- BELUM dijalankan lewat Gradle/aapt2 di lingkungan ini (tidak ada Android SDK); build ulang di GitHub Actions diperlukan.
- `tools/verify_project.py` pada arsip FIX148 sudah gagal sebelum perubahan ini dan tidak diubah: (1) pemeriksa manifest tidak menemukan
  berkas bernama `TimerJamBootReceiver` (kelasnya ada di `TimerJamService.kt`, jadi ini ketidakcocokan pemeriksa, bukan kelas hilang);
  (2) pemeriksa bahasa aktif melaporkan teks Indonesia baru di `JamActivity.kt` (35, batas 25), `PerintahSuaraActivity.kt` (15, batas 0), dan
  `TimerJamService.kt` (5, batas 0). Keempatnya di luar kesalahan build ini.

## Bahasa aktif
Perubahan hanya pada penulisan apostrof di dua berkas resource (Indonesia dan English); kunci dan isi kalimat sama, tidak ada teks baru.
