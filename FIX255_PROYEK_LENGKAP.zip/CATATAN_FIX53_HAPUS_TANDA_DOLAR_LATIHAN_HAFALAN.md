# FIX53 — Tanda "$" pada teks Latihan hafalan tanpa mikrofon

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX52. Perubahan: `KhatamActivity.kt`.

## Masalah
Dialog latihan menampilkan nama variabel ("Surah $nomorSurah, ayat $nomorAyat...") alih-alih nomor surah dan ayat yang sebenarnya.

## Perbaikan
- Seluruh teks yang memakai interpolasi `$nama` / `${...}` di `KhatamActivity.kt` diganti penggabungan teks biasa (`"..." + nilai + "..."`), sehingga tidak ada lagi tanda dolar di kode maupun di layar.
- Hasil di dialog latihan: "Surah 2, ayat 255. Setelah selesai, tampilkan jawaban dan cocokkan setiap kata serta harakat pada mushaf." (juga versi Inggris dan teks petunjuk kata pertama).
- Perbaikan yang sama diterapkan pada teks hasil koreksi suara (kata ke-…, jumlah bagian, kode kesalahan), daftar surah untuk audio, dan status equalizer, agar tidak muncul tanda dolar di sana.

## Pemeriksaan
- Tidak ada karakter "$" tersisa di `KhatamActivity.kt`; keseimbangan tanda kurung sesuai; `verify_project.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat.
