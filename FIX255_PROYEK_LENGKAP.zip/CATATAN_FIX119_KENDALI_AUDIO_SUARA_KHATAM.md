# FIX119 - Perintah suara "hentikan/jeda/lanjut" tidak berefek pada audio yang sedang diputar

Versi aplikasi tidak diubah. Basis: FIX118. Berkas diubah: `KhatamActivity.kt`, `PerintahSuaraActivity.kt`. Berkas baru: `tools/uji_kendali_audio_suara.py`.

## Gejala
Setelah FIX118 aplikasi tidak lagi macet di layar kosong, tetapi saat audio berbunyi, perintah suara "hentikan" hanya menghasilkan jawaban
dan audio tetap berjalan.

## Penyebab (dari pembacaan kode; log crash belum ada)
Audio dari perintah putar dapat berada di dua pemutar: (1) layanan latar belakang `PemutarQuranService`, bila terkunci atau ada isyarat
tambahan seperti pengulangan, atau (2) pemutar milik `KhatamActivity`, pada perintah putar biasa. Perintah berhenti/jeda/lanjut hanya dikirim ke
layanan. Bila audio ada di Khatam, layanan tidak punya apa pun untuk dihentikan namun tetap menjawab "Audio Al-Qur'an dihentikan", jadi ada
respons tanpa efek.

## Perbaikan
- `KhatamActivity.kendaliLatar(aksi)` (baru): meneruskan berhenti/jeda/lanjut ke pemutar Khatam di thread utama. Berhenti selalu diteruskan bila
  Khatam hidup (juga menghentikan terjemahan bersuara dan pemutaran antar-ayat); jeda/lanjut hanya bila ada pemutar yang sesuai kondisinya.
- `PerintahSuaraActivity.kendaliQuran`: mengendalikan Khatam lebih dulu. Berhenti tetap dikirim ke layanan juga agar pemutar mana pun yang aktif
  berhenti. Jeda/lanjut diteruskan ke layanan hanya bila Khatam tidak memegang audionya, sehingga tidak ada lagi jawaban "tidak ada audio"
  yang keliru.
- Jawaban "dihentikan" sekarang benar-benar berarti audio berhenti; tidak ada teks baru yang terlihat pengguna (bahasa aktif tetap terpenuhi).

## Batasan
- Audio Khatam yang sedang dijeda dianggap "selesai" oleh `AudioLatarService` (`audioMasihBerjalan` hanya benar saat berbunyi), sehingga
  layanan penjaga proses dapat berhenti sendiri saat jeda lama di latar belakang. Tidak diubah di sini; dilaporkan bila jeda lalu lanjut gagal.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, `uji_kendali_audio_suara.py`, `uji_pemulihan_jendela_khatam.py` lulus; kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat.
