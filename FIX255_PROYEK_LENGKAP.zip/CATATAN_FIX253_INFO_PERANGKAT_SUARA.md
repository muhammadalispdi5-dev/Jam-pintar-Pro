# FIX253 - Informasi perangkat lewat asisten suara

Perintah baru (Indonesia dan Inggris): RAM total/tersedia, sisa memori internal (plus kartu memori bila ada), perangkat 32 atau 64 bit (perangkat dan mode aplikasi), prosesor/jumlah inti/ABI, model ponsel, versi Android dan patch keamanan, layar (resolusi, dpi, refresh rate), lama menyala, versi aplikasi, dan "informasi perangkat"/"spesifikasi" untuk semuanya.

Berkas: PerintahSuaraActivity.kt (TopikPerangkat, infoPerangkat, Jenis.INFO_PERANGKAT prioritas 95, bacakanInfoPerangkat); petunjuk penggunaan ID butir 37, EN butir 34.
Pertanyaan baterai tidak diambil alih (tetap ke informasi baterai).
Pengujian: logika deteksi diuji dengan kotlinc (t253), semua pemeriksa proyek lulus.
Catatan jujur: belum dikompilasi dengan Gradle, belum diuji di perangkat. Angka RAM/memori adalah nilai yang dilaporkan sistem Android.
