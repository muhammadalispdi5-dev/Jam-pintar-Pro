# FIX190 — Pengelola Paket Bahasa Pengenal Suara Offline

Versi aplikasi tetap `versionCode = 82` dan `versionName = 1.0.82`.

## Perubahan

- Menambahkan halaman `PaketBahasaOfflineActivity` dan pintasan menu pada halaman utama.
- Halaman mengikuti bahasa tampilan aplikasi (Indonesia/English) dan menggunakan komponen halaman yang mendukung TalkBack.
- Bahasa yang diperiksa mengikuti bahasa tampilan: `id-ID` untuk Bahasa Indonesia dan `en-US` untuk English.
- Pada Android 13 (API 33) atau lebih baru, halaman meminta layanan pengenal suara sistem memeriksa dukungan bahasa melalui `checkRecognitionSupport`.
- Menampilkan daftar status bahasa yang dilaporkan layanan: sudah terpasang, menunggu/diunduh, didukung offline tetapi belum terpasang, hanya tersedia daring, atau tidak didukung.
- Tombol unduh memanggil `SpeechRecognizer.triggerModelDownload` untuk meminta layanan pengenal suara mengunduh model bahasa. Aplikasi tidak mengklaim unduhan berhasil sebelum status diperiksa ulang.
- Pada Android di bawah 13, atau bila API pemeriksaan tidak tersedia, pengguna diarahkan ke pengaturan pengenal suara Android.
- Tombol uji membuka alur perintah suara dan diberi penanda khusus agar pengujian tidak terhalang sakelar Beritahu Saya yang sedang nonaktif.
- Mempertahankan perubahan FIX189 untuk audio Al-Qur'an offline/online dan fallback pengenalan suara.

## Batasan Android

Paket bahasa bukan berkas milik Jam Pintar Pro. Pengunduhan dan penyimpanannya dikelola oleh aplikasi/layanan pengenal suara yang dipilih di perangkat. Dukungan Bahasa Indonesia offline berbeda-beda antarperangkat dan penyedia layanan. `triggerModelDownload` hanya mengirim permintaan; hasilnya harus diverifikasi kembali melalui pemeriksaan status dan uji suara.

## Validasi yang dilakukan

- Semua berkas XML dalam proyek berhasil diparse.
- Struktur kurung kurawal dan tanda kurung pada berkas Kotlin yang disentuh seimbang.
- Activity baru terdaftar di AndroidManifest dan tombolnya terpasang pada halaman utama.
- Versi tetap 1.0.82.
- Build Gradle Android tidak dijalankan karena arsip sumber tidak menyertakan Gradle Wrapper dan lingkungan ini tidak memiliki Android SDK/Gradle build tool. Uji akhir kompilasi tetap perlu dilakukan melalui GitHub Actions.

## Catatan pengemasan

Arsip FIX189 sumber tidak menyertakan `.github/workflows`. Saat mengganti sumber di repositori, pertahankan workflow GitHub Actions dan secrets yang sudah digunakan.
