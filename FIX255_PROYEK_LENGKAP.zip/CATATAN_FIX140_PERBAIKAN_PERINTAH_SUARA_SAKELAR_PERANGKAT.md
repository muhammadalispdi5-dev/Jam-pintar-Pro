# FIX140 — Perbaikan operasi sakelar perangkat melalui perintah suara

Basis: FIX139. Versi aplikasi dipertahankan pada `versionName 1.0.81` dan `versionCode 81`.

## Sasaran
Memperbaiki kondisi ketika perintah suara hanya membuka Pengaturan tetapi layanan aksesibilitas tidak menemukan atau tidak berhasil menekan sakelar. Cakupan kontrol:

- Wi-Fi
- Bluetooth
- Lokasi
- Hotspot seluler
- Data seluler
- Mode pesawat
- NFC

## Perubahan

1. `PemilihSakelar.kt` diperluas untuk mengenali label AOSP/OEM dan alias resource ID yang lebih beragam, termasuk panel System UI yang mengekspos sakelar sebagai tombol dengan status.
2. Pemilihan sakelar memakai frasa utuh dan menolak label perangkat lain. Jika ada beberapa kandidat yang sama-sama cocok, layanan tidak memilih secara acak.
3. Layanan mengumpulkan label teks yang berada satu baris dengan sakelar, tetapi menghindari menggabungkan label dari baris sakelar tetangga.
4. Operasi klik mencoba aksi `ACTION_CLICK` pada node dan induk klik terdekat yang aktif.
5. Status sakelar dibaca dari `isChecked`, `stateDescription`, dan label status yang tersedia. Status yang tidak terbaca tidak dianggap OFF.
6. Setelah klik, layanan menunggu perubahan dan memverifikasi ulang. Jika status tidak dapat diverifikasi, layanan tidak mengulang klik secara buta dan tidak mengumumkan keberhasilan palsu.
7. Konfigurasi layanan aksesibilitas menerima lebih banyak jenis event dan jendela interaktif agar perubahan halaman/panel sistem dapat dipantau.
8. Penafsir perintah menerima kata kerja perintah tambahan dalam Bahasa Indonesia, English, Arab, Jawa, dan Sunda. Pengumuman hasil tetap menggunakan `BahasaAplikasi.bungkus` serta resource bahasa aplikasi.

## Batas platform

Android modern membatasi aplikasi biasa untuk mengubah Wi-Fi, Bluetooth, data seluler, mode pesawat, NFC, dan sebagian pengaturan lokasi secara langsung. Karena itu, proses ini mengoperasikan kontrol yang benar-benar ditampilkan oleh halaman/panel resmi Android melalui layanan aksesibilitas.

Layanan **Bantuan Panggilan Jam Pintar Pro** harus diaktifkan di Setelan Android > Aksesibilitas. Jika suatu versi Android atau antarmuka OEM tidak mengekspos sakelar/status sebagai elemen aksesibilitas yang dapat dioperasikan, aplikasi akan melaporkan kegagalan dan tidak mengklaim berhasil. Beberapa dialog konfirmasi sistem/operator tetap memerlukan tindakan pengguna.

## Berkas yang diubah

- `app/src/main/java/com/novan/bateraibicara/PemilihSakelar.kt`
- `app/src/main/java/com/novan/bateraibicara/PanggilanWhatsAppAccessibilityService.kt`
- `app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt`
- `app/src/main/res/xml/panggilan_whatsapp_accessibility.xml`
- `tools/uji_kontrol_wifi_bluetooth.py`

## Pemeriksaan

- Pemeriksaan proyek/Manifest/XML: lulus.
- Pemeriksaan resource string Indonesia dan Inggris: lulus.
- Pemeriksaan bahasa aktif: lulus.
- Seluruh skrip `tools/uji_*.py`: lulus.
- Kompilasi mandiri `PemilihSakelar.kt` dengan Kotlin compiler: lulus.
- Kompilasi APK Android penuh dan uji langsung pada perangkat fisik: belum dilakukan di lingkungan ini.
