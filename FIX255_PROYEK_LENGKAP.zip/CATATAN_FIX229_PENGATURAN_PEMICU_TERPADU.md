# FIX229 - Satu pengaturan untuk semua pemicu asisten suara

- Menu baru di beranda: "Pengaturan Pemicu Asisten Suara" (menggantikan tiga bagian pemicu yang tersebar di beranda).
- Halaman PemicuAsistenActivity memuat: ringkasan pemicu yang aktif; 1) Beritahu Saya (sakelar pemicu dan sakelar sekali ketuk langsung perintah suara); 2) goncangan tiga kali (status dan pintasan ke pengaturannya); 3) tombol volume dan tombol aksesibilitas (pilihan, status layanan aksesibilitas, pintasan); alat bantu: coba perintah suara sekarang dan paket bahasa pengenal suara offline.
- Pengaturan terperinci masing-masing pemicu tidak berubah; hanya penempatan dan ringkasan status.
- Bantuan butir 20 diperbarui. Versi tetap 1.0.86.
- Belum dikompilasi dengan Gradle dan belum diuji di HP.
