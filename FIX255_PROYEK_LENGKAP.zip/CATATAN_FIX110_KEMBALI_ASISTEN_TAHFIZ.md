# FIX110 — Tombol Kembali di Asisten Tahfiz Cerdas Tidak Lagi Melempar ke Halaman Utama Khatam

Versi aplikasi: **1.0.74** (versionCode 74). Basis: FIX109. Perubahan hanya di `KhatamActivity.kt` dan `app/build.gradle.kts`.

## Penyebab
Dialog Asisten Tahfiz dibuka bertingkat, tetapi hanya sebagian yang menangani "kembali":
- Panel utama Asisten hanya punya tombol "Tutup" tanpa tujuan, sehingga tombol kembali sistem menutup semuanya dan pengguna jatuh ke halaman utama Khatam.
- Dialog Asisten Hafalan Inklusif, Asisten Koreksi Bacaan, dan Pengaturan Asisten hanya mengatur tombol "Kembali" di layar. Tombol kembali sistem (dan sentuhan di luar dialog) tidak diatur, sehingga menutup ke halaman utama Khatam.
- Dialog yang dibuka dari Asisten (Latihan tanpa mikrofon, Koreksi suara, Muraja'ah cerdas, pengaturan aksesibilitas, saklar latihan, pengaturan muraja'ah) memakai tujuan "kembali" tetap ke menu lain atau hanya menutup.

## Perbaikan: Kembali selalu naik SATU tingkat (tombol layar, tombol kembali sistem, dan sentuhan di luar dialog)
Jalur: Halaman Khatam > Pengaturan Khatam > **Asisten Tahfiz Cerdas** > (Hafalan Inklusif | Koreksi Bacaan | Pengaturan Asisten | Muraja'ah) > fitur.
- Panel utama Asisten: Kembali menuju **Pengaturan Khatam** (tombol "Tutup" diganti "Kembali ke pengaturan Khatam").
- Asisten Hafalan Inklusif, Asisten Koreksi Bacaan, Pengaturan Asisten: Kembali menuju **panel Asisten**.
- Fitur yang dibuka dari Asisten kini membawa tujuan kembali ("induk") dan naik ke dialog tempat asalnya:
  - Latihan tanpa mikrofon: Kembali pada dialog pengantar, "Batalkan", dan tombol kembali sistem saat latihan atau saat mencocokkan bacaan.
  - Koreksi bacaan dengan suara: Kembali (sebelumnya "Tutup") dan tombol kembali sistem; dialog "pengenalan suara tidak tersedia".
  - Muraja'ah cerdas: dialog ringkasan, pilihan cara, dan pesan "tidak ada ayat".
  - Pengaturan aksesibilitas, saklar fitur latihan, dan pengaturan muraja'ah (termasuk dialog jumlah ayat per sesi) kembali ke dialog Asisten tempat asalnya.
- Bila fitur yang sama dibuka dari tempat lain (menu utama Khatam, Pengaturan Hafalan, sesi muraja'ah), perilaku lama tetap sama; parameter `induk` bernilai kosong.
- Pemanggil kembali ke dialog induk lewat `naikKe()`, yang tidak melakukan apa-apa bila Activity sedang ditutup.

## Yang sengaja tidak diubah
- Dialog Pengaturan Khatam adalah tingkat teratas dari jalur ini; Kembali dari sana tetap menutup ke halaman utama Khatam.
- Alur sesi muraja'ah yang sedang berjalan (dialog nilai, sesi tertunda) tetap memakai logika sesinya sendiri.

## Pemeriksaan dan batas
- `tools/verify_project.py`, `tools/periksa_bahasa_aktif.py`, dan `tools/uji_murajaah_cerdas.py`: LULUS; kurung seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: Pengaturan Khatam > Asisten Tahfiz Cerdas, lalu masuk ke tiap pilihan dan tekan tombol kembali sistem di setiap tingkat (juga dengan TalkBack aktif).
