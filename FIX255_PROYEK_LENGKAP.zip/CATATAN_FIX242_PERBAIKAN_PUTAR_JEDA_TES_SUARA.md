# CATATAN FIX242: Perbaikan Putar/Jeda Tes Suara (Azan, Imsak, Dhuha, Tahajud, dll.)

Versi tetap 1.0.87.

## Penyebab "kadang bisa, kadang tidak"
1. Jeda hanya menyasar pemutar berkas; saat fase melodi pembuka/penutup berbunyi, jeda tidak berefek padahal status sudah "dijeda".
2. Status tes aktif di prefs bisa basi (proses dimatikan sistem atau layanan sudah selesai), sehingga ketukan berikutnya mengirim perintah jeda ke layanan yang tidak memutar apa pun.
3. Perintah kontrol dikirim dengan startForegroundService tanpa startForeground, berisiko membuat layanan gagal bila sudah selesai.
4. Tes baru tidak membersihkan melodi/pemutar/penutup tes sebelumnya, sehingga bisa terjadi suara ganda atau tes terpotong penutup lama; pengatur waktu pengaman terus berjalan saat jeda.

## Perbaikan
- Melodi: ditambah jedaSemua() dan lanjutSemua().
- PrayerAlarmService: penanda tesBerjalan (hanya benar saat layanan benar-benar menjalankan tes); jeda/lanjut kini mencakup melodi, pemutar, dan TTS; pengatur waktu pengaman dibatalkan saat jeda lalu dijadwalkan ulang saat lanjut; tes baru membersihkan sisa tes lama; status basi dibersihkan.
- PrayerSettingsActivity: tesAktifNyata() menggantikan pembacaan prefs mentah; kontrol memakai startService; setelah tiap ketukan label tombol disegarkan dan keadaan diumumkan lewat toast ("diputar", "dijeda", "dihentikan atau selesai") bagi pengguna TalkBack.
- Petunjuk penggunaan (ID/EN) diperbarui.

## Catatan
Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Mohon uji: putar Tahajud, jeda, lanjut, ganti ke Dhuha, jeda saat melodi pembuka, dan tutup/buka ulang pengaturan saat sedang dijeda.
