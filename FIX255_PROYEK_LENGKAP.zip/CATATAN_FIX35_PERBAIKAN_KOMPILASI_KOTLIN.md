# FIX35 — Perbaikan kompilasi Kotlin pada pemilihan surah

- Versi aplikasi dipertahankan: `versionCode 69`, `versionName 1.0.69`.
- Pada `KhatamActivity.kt`, fungsi `pilihSurahUntukAudio()`, ekspresi string-template bertingkat dipecah menjadi variabel lokal `bahasaInggris`, `nomor`, dan `nama`.
- Label daftar surah sekarang dibentuk sebagai `"$nomor. $nama"`, menghindari string-template bertingkat yang dapat memicu kesalahan parsing pada compiler Kotlin tertentu.
- Pemeriksaan statis `python3 tools/verify_project.py`: LULUS.
- Catatan: lingkungan kerja ini tidak memiliki Gradle/Android SDK untuk menjalankan `:app:compileDebugKotlin` atau menghasilkan APK. Karena itu FIX35 belum boleh dianggap berhasil dikompilasi; jalankan ulang workflow GitHub Actions menggunakan sumber FIX35.
