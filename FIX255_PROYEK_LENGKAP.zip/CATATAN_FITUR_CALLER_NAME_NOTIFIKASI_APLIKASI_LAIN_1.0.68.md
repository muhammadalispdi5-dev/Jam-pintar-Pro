# Catatan fitur Caller Name — Notifikasi aplikasi lain

Ditambahkan ke pengaturan Caller Name:
- Pembacaan notifikasi email (Gmail, Outlook, Samsung Email, Yahoo Mail, serta paket email yang dikenali dari nama paket).
- Pembacaan notifikasi Gojek, Grab, inDrive, dan Maxim.
- Setiap kategori memiliki sakelar tersendiri dan semuanya nonaktif secara bawaan.
- Pengumuman awal memakai Bahasa Indonesia atau Bahasa Inggris mengikuti bahasa pengucapan aktif (`jamBahasaIdx`). Judul dan isi notifikasi dibacakan sesuai data yang Android sediakan.
- Pembacaan menggunakan pengaturan jumlah/jeda pengulangan notifikasi yang sudah ada, dan mencegah pengumuman ulang untuk pembaruan teks identik pada kunci notifikasi yang sama.
- Tetap memerlukan Caller Name aktif dan izin Akses notifikasi Android.

Batasan pemeriksaan:
- Nama paket dan format notifikasi dapat berbeda antarversi aplikasi/perangkat. Notifikasi yang tidak menyediakan judul/teks melalui Android tidak dapat dibacakan.
- Pemeriksaan statis proyek lulus. Belum dilakukan kompilasi Android penuh atau uji TTS di perangkat nyata.
