# Audit dan perbaikan lokalisasi bahasa aktif — Jam Pintar Pro 1.0.68

## Tujuan
Bahasa tampilan utama (Bahasa Indonesia atau English) menjadi sumber bahasa untuk seluruh teks visual fitur arah kiblat/kompas, suara azan dan tes suara, pengingat sahur/berbuka, dan pengingat waktu salat. Teks notifikasi dan label tindakan harus mengikuti pilihan tersebut, bukan mencampur dua bahasa.

## Perubahan
- Memperluas pemetaan frasa Indonesia–Inggris pada `BahasaAplikasi` untuk label, petunjuk, status, dialog, tes audio, sahur/berbuka, pengingat waktu salat, dan kompas.
- Memastikan teks arah putaran, status arah kiblat, dan deskripsi jarum mengikuti bahasa tampilan aktif.
- Menyesuaikan bahasa pengumuman arah kiblat berbasis TTS dengan bahasa tampilan aktif (English/Indonesia), termasuk arah mata angin.
- Menyesuaikan judul, isi, dan tindakan pada notifikasi suara azan/tes suara dengan bahasa tampilan aktif.
- Pesan notifikasi sahur dan berbuka sudah dibentuk melalui `FastingSchedule` dengan pilihan bahasa tampilan untuk teks notifikasi.
- Mempertahankan nama kelas, ID resource, preferensi, alur alarm/audio, dan versi aplikasi 1.0.68 / versionCode 68.

## Validasi
- `tools/verify_project.py`: lulus.
- `tools/verify_final.py`: lulus.
- Pemeriksaan Gradle penuh tidak dapat dijalankan pada lingkungan penyuntingan ini karena perintah `gradle` tidak tersedia dan wrapper proyek tidak lengkap. Karena itu, keberhasilan kompilasi APK belum diklaim.

## Uji wajib di GitHub Actions/perangkat
1. Jalankan build debug dan release melalui GitHub Actions.
2. Pilih English dan periksa semua label, petunjuk, dialog, notifikasi, deskripsi TalkBack/pembaca layar, serta pesan dinamis pada empat fitur yang ditargetkan.
3. Ulangi dengan Bahasa Indonesia.
4. Uji notifikasi terjadwal dan tombol Putar/Jeda/Lanjutkan/Hentikan tes suara, bukan hanya teks halaman pengaturan.
