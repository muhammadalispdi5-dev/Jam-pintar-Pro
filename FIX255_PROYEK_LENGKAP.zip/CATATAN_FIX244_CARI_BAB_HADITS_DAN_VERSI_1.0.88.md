# CATATAN FIX244: Pencarian Hadits Berdasarkan Bab, dan Naik Versi 1.0.88

## Versi
1.0.87 (87) menjadi 1.0.88 (88): build.gradle.kts, README, PANDUAN_PEMBARUAN_DAN_KELUHAN, user-agent (OpenMeteo, InfoBmkg, QariSuara, PerintahSuaraActivity), dan tiga uji versi di tools.

## Pencarian bab hadits
- Halaman setiap kitab (Bukhari, Muslim, Arbain, Riyadhus Shalihin) yang sudah diunduh kini punya kolom "Cari bab" dan tombol "Pilih bab populer" (25 tema: Thaharah, Wudhu, Shalat, Jenazah, Zakat dan Sedekah, Puasa dan Ramadhan, Haji dan Umrah, Jual Beli dan Muamalah, Nikah dan Talak, Iman dan Tauhid, Ilmu, Adab dan Akhlak, Doa dan Dzikir, Al-Qur'an dan Tafsir, Makanan dan Minuman, Kurban dan Aqiqah, Pakaian dan Perhiasan, Jihad, Sahabat dan Para Nabi, Kepemimpinan dan Hukum, Fitnah dan Akhirat, Wasiat dan Waris, Sumpah dan Nazar, Pengobatan, Sunnah dan Bid'ah).
- Daftar bab disaring seketika; jumlah bab yang ditemukan diumumkan (live region untuk TalkBack). Ketuk bab untuk membaca hadits-haditsnya (fitur baca per bagian yang sudah ada).
- Nama bab dicocokkan dari edisi Indonesia dan edisi Arab/Inggris sekaligus; ejaan berbeda (sholat, salat, thoharoh, shaum) dan istilah Inggris/Arab dikenali. Kata lebih dari satu harus cocok semuanya; jika tidak ada hasil, cukup salah satu.
- Berkas baru BabHadits.kt (logika murni, diuji dengan kotlinc: 40 kasus pada nama bab Indonesia, Inggris, dan Arab, termasuk "shalat", "thoharoh", "jual beli", "puasa").
- Petunjuk penggunaan ID/EN diperbarui.

## Catatan
- Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
- Pencarian bergantung pada nama bab yang ada pada data unduhan. Bila suatu kitab (misalnya Arbain) tidak menyertakan daftar bab, kolom pencarian tidak ditampilkan dan pencarian nomor tetap tersedia.
