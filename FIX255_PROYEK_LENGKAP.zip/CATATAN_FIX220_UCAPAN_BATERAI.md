# FIX220 — Penyebutan status baterai yang tepat
- Perintah suara baterai: "Baterai tersisa N persen, ..." diganti "Baterai N persen, sedang diisi daya" atau "..., tidak sedang diisi daya" (kata "tersisa" keliru karena menyiratkan sisa saat sedang diisi). Inggris: "Battery N percent, and charging".
- Status baterai di layar utama, notifikasi, widget, dan halaman Baterai memakai kalimat sama: angka lalu kata "persen" (bukan simbol persen dan bukan tanda kurung), diikuti status.
- Kata status disamakan: "sedang diisi daya" / "tidak sedang diisi daya".
