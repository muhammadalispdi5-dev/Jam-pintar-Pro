Tahap 11 — Konsistensi bahasa pada pengaturan kalender

Perubahan:
- Membungkus label kelompok kalender yang ditulis langsung di kode dengan ui(...), agar pemetaan bahasa tampilan aktif dapat menerjemahkannya ketika bahasa Inggris dipilih.
- Mencakup menu dan judul kelompok: tanggal Masehi/pasaran Jawa, tanggal Hijriah, hari libur/cuti bersama, info salat berikutnya, serta suara pembaca tanggal.
- Tidak mengubah bahasa ucapan TTS, perhitungan tanggal, koreksi Hijriah/pasaran, urutan segmen ucapan, maupun versi aplikasi.

Validasi:
- Pemeriksaan perubahan sumber secara statis.
- Arsip ZIP akan diperiksa integritasnya.
- Build Android penuh dan pengujian perangkat belum dijalankan; perubahan belum boleh dianggap terkompilasi atau teruji di perangkat.
- Versi proyek tetap 1.0.68 (versionCode 68).
