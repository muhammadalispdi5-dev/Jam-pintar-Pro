# FIX219 — Kalkulator Zakat dan Waris, serta jadwal salat resmi Kemenag RI

## 1. Kalkulator Zakat menjadi Kalkulator Zakat dan Waris
- Nama menu dan judul halaman diubah menjadi "Kalkulator Zakat dan Waris" (EN: "Zakat and Inheritance Calculator") di values dan values-en.
- Fitur baru "Hitung waris atau faraid" pada KalkulatorZakatActivity (Jenis.WARIS).
- Mesin hitung baru `HitungWaris.kt` (Kotlin murni, pecahan eksak `Pecahan`): hajb, 'aul, radd, Umariyatain, Akdariyah, kakek bersama saudara (pendapat Zaid), saudari sebagai ashabah ma'a ghair, takmilah seperenam.
- Masukan harta: total harta, harta bersama (separuh hak pasangan), utang, biaya jenazah, wasiat (dibatasi sepertiga harta bersih).
- Hasil: bagian pecahan ("1 per 8"), nominal rupiah, per orang, ahli waris terhalang, catatan, dan penafian (KHI: ahli waris pengganti dan wasiat wajibah tidak dihitung).
- Perintah suara "buka kalkulator waris / hitung waris / faraid" membuka halaman yang sama.
- Uji: `tools/uji_waris.sh` (21 kasus baku).

## 2. Jadwal salat resmi Kemenag RI
- Metode 0 (bawaan) = Kemenag RI: Subuh 20 derajat, Isya 18 derajat, ihtiyath 2 menit (Subuh, Dzuhur, Ashar, Maghrib, Isya +2 menit; Terbit -2 menit; Imsak = Subuh resmi -10 menit).
- Jadwal daring (AlAdhan metode 20) tidak memuat ihtiyath, sehingga ditambahkan 2 menit yang sama agar sama dengan perhitungan luring. Cache lama dibuang otomatis (tanda "v219" pada signature).
- Label metode: "Kemenag RI (Subuh 20°, Isya 18°, ihtiyath 2 menit)".

Catatan keterbatasan: belum dapat dibandingkan langsung dengan data bimasislam.kemenag.go.id dari lingkungan pengembangan (jaringan dibatasi). Tabel resmi per kota dapat berbeda beberapa menit karena titik koordinat dan ketinggian; gunakan koreksi menit di Pengaturan bila perlu.
