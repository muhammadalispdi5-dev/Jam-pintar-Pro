# FIX40 — Pencarian Terstruktur dan Pusat Pengaturan Khatam

## Perubahan

1. Dialog **Cari juz, surah, atau ayat untuk diputar** kini menampilkan tiga kolom angka terpisah:
   - Tulis nomor juz (opsional)
   - Tulis nomor surah (opsional)
   - Tulis nomor ayat (opsional)
2. Pengguna cukup mengisi satu kolom. Semua kolom kosong akan diberi pesan agar minimal satu kolom diisi.
3. Nomor juz 1–30 dan nomor surah 1–114 divalidasi. Nomor ayat harus positif dan divalidasi terhadap surah tujuan.
4. Jika hanya nomor ayat diisi, ayat dicari pada surah yang sedang dipilih; keterangan ini ditampilkan sebelum pencarian.
5. Jika nomor juz diisi, juz menjadi tujuan utama. Untuk qari yang hanya mendukung audio per surah, aplikasi memberi penjelasan bahwa pemutaran juz memerlukan qari per ayat.
6. Menu utama Khatam diringkas. Target khatam, aksesibilitas, riwayat, statistik, pengingat, serta pengaturan audio/hafalan dikumpulkan di **Pengaturan Khatam Al-Qur'an**.
7. Setelah menutup pilihan target, aksesibilitas, riwayat, statistik, dan pengingat, pengguna diarahkan kembali ke pusat pengaturan Khatam. Pengaturan qari dan opsi audio tetap kembali ke submenu audio.

## Versi

- versionCode: 69
- versionName: 1.0.69

## Pemeriksaan

- `tools/verify_project.py`: lulus.
- Arsip ZIP: diuji dengan `unzip -t`.
- Pemeriksaan parser Kotlin tanpa classpath Android: tidak menemukan diagnostik sintaks/parser. Ini bukan kompilasi Android penuh.
- Kompilasi Gradle penuh dan uji TalkBack pada perangkat belum dijalankan.
