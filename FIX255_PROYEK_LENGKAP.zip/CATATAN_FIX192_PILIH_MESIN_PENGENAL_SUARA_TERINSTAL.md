# FIX192 — Pemilihan mesin pengenal suara yang terpasang

Versi aplikasi dipertahankan pada `versionCode = 82` dan `versionName = 1.0.82`.

## Perubahan

1. Menambahkan `PengenalSuaraTerpasang.kt` untuk mendeteksi layanan Android yang mendaftarkan `android.speech.RecognitionService` dan memenuhi izin `BIND_SPEECH_RECOGNITION_SERVICE`.
2. Halaman Paket Bahasa Offline sekarang menampilkan mesin pengenal suara yang ditemukan, menyediakan pilihan tiap mesin, dan pilihan untuk kembali memakai mesin bawaan Android.
3. Komponen mesin yang dipilih disimpan di SharedPreferences sehingga tetap digunakan setelah halaman ditutup atau aplikasi dibuka kembali.
4. Pemeriksaan dukungan bahasa (`checkRecognitionSupport`) dan permintaan unduhan model (`triggerModelDownload`) memakai komponen mesin pilihan secara eksplisit.
5. `PerintahSuaraActivity` memakai mesin pilihan yang sama. Jika pengguna tidak memilih mesin, alur sebelumnya tetap dipakai: pengenal on-device Android terlebih dahulu bila tersedia, kemudian pengenal standar sistem.
6. Daftar mesin hanya menampilkan layanan pengenal ucapan Android (speech-to-text), bukan mesin TTS pembaca teks. Mesin TTS tidak menyediakan fungsi pengenalan perintah suara.

## Batasan

- Paket bahasa tetap dikelola oleh masing-masing mesin/layanan pengenal suara. Aplikasi hanya meminta layanan tersebut memeriksa atau mengunduh model; aplikasi tidak dapat memaksa mesin menyediakan bahasa yang tidak didukung.
- `checkRecognitionSupport` dan `triggerModelDownload` memerlukan Android 13 (API 33) atau lebih baru. Pada Android lebih lama, halaman mengarahkan pengguna ke pengaturan pengenal suara.
- Mesin yang terpasang tetapi tidak mendaftarkan `RecognitionService` Android tidak dapat dipakai langsung oleh `SpeechRecognizer` dan tidak akan ditampilkan.
- Kompilasi Gradle/APK belum dapat dijalankan di lingkungan penyuntingan ini karena Android SDK/Gradle Wrapper tidak tersedia. Perlu verifikasi GitHub Actions dan uji perangkat.
