# Catatan penyempurnaan Khatam Al-Qur’an — FIX27

Versi aplikasi tetap 1.0.69 (`versionCode` 69, `versionName` 1.0.69). Perubahan hanya menyentuh fitur Khatam Al-Qur’an.

## Penyempurnaan pada tahap ini
- Ringkasan kemajuan singkat ditampilkan langsung di menu Khatam: jumlah ayat yang ditandai, persentase, ayat hari ini, sisa ayat, dan status target.
- Pembaca kini memiliki pilihan langsung untuk membuka nomor ayat tertentu pada surah yang sedang dibaca. Nomor divalidasi sesuai jumlah ayat surah.
- Tanda ayat selesai bisa dibatalkan bila pengguna salah menekan tombol. Pembatalan juga menghapus ayat itu dari catatan harian sehingga statistik dan riwayat tetap konsisten.
- Statistik target menggunakan jumlah ayat yang masih tersisa dan perkiraan hari target yang tersisa, bukan selalu membagi 6.236 ayat penuh.
- Status audio murattal memberi umpan balik yang lebih jelas dan penanganan jeda/lanjut yang lebih informatif. Audio tetap streaming dan memerlukan internet.

## Fitur yang tetap dipertahankan
Pembacaan teks Arab dan terjemahan, cache teks offline, pilih surah/juz, lanjutkan posisi terakhir, target 30/60/90 hari atau khusus/tanpa target, statistik, riwayat, pengingat harian, pengaturan aksesibilitas, serta bahasa Indonesia/Inggris.

## Pemeriksaan yang dilakukan
- Pemeriksaan arsip ZIP dan validitas XML resource.
- Pemeriksaan statis bahwa fungsi pilihan ayat, pembatalan tanda, ringkasan kemajuan, dan statistik tersedia di sumber.
- Kompilasi Gradle Android dan uji pada perangkat belum dijalankan di lingkungan penyusunan ini. Jalankan GitHub Actions untuk memastikan APK dapat dibangun sebelum dipasang.
