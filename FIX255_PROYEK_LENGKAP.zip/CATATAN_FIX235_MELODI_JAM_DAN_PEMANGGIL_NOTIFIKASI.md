# FIX235 — Melodi pada fitur Jam dan Nama Pemanggil/Notifikasi

Perubahan berbasis proyek FIX234, tanpa mengubah versi aplikasi (tetap 1.0.86 / versionCode 86).

## Jam
- Pemilihan melodi awal dan akhir sekarang memakai pola bertahap seperti Pengingat sebelum salat.
- Daftar tetap terbuka saat melodi dipratinjau.
- Pilihan baru disimpan hanya setelah tombol Simpan; Batal tidak mengubah pengaturan tersimpan.
- Pratinjau memakai atribut audio dan tingkat volume profil suara Jam.
- Setelah disimpan, layanan Jam dimuat ulang agar pengaturan diterapkan.
- Urutan pengumuman yang sudah tersedia dipertahankan: melodi awal → ucapan jam/tanggal → melodi akhir.

## Nama Pemanggil dan Pembacaan Notifikasi
- Pemilihan melodi awal dan akhir panggilan/notifikasi memakai pemilih bertahap yang sama.
- Daftar melodi mencakup opsi Mati/tanpa melodi (indeks 0).
- Pilihan melodi awal/akhir tersimpan terpisah dan tetap dikendalikan sakelar aktif/nonaktif yang sudah ada.
- Panggilan masuk dan pembacaan notifikasi masuk (SMS/chat/pesan suara) tetap menggunakan rangkaian melodi awal → pengumuman → melodi akhir.
- Jika opsi tanpa melodi dipilih, pemutar tidak dijalankan dan tidak menambahkan jeda akhir yang tidak diperlukan.

## Bahasa dan validasi
- Label judul mengambil resource sesuai bahasa aktif aplikasi; daftar melodi memakai resource `values` / `values-en`.
- Tombol Simpan/Batal dan pesan tersimpan mengikuti lokalisasi aplikasi.
- ZIP diuji dengan `unzip -t`. Build Gradle belum dijalankan karena Gradle Wrapper/executable tidak tersedia di lingkungan kerja.
