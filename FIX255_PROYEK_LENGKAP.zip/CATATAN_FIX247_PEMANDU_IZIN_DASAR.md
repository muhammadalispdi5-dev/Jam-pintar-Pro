# FIX247 — Pemandu perizinan dasar otomatis

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.

Berkas baru: PemanduIzinAwal.kt. MainActivity memanggilnya.

Alur:
1. Pertama kali aplikasi dijalankan, setelah petunjuk awal ditutup, pemandu menawarkan izin satu per satu. Tiap langkah punya dialog penjelasan dengan tombol Lanjutkan, Lewati, dan Jangan ingatkan lagi.
2. Izin sistem (satu kali permintaan berturut-turut): notifikasi (Android 13+), lokasi, mikrofon, status telepon, kontak, panggilan telepon.
3. Layar pengaturan khusus, satu per satu, kembali otomatis ke pemandu: notifikasi aplikasi bila dimatikan, alarm tepat waktu (Android 12+), bebas hemat baterai, tampil di atas aplikasi lain, akses notifikasi, Jangan Ganggu, lalu panduan pengaturan khusus merek ponsel.
4. Langkah yang sudah diizinkan dilewati otomatis.
5. Tiap aplikasi dibuka, bila masih ada izin penting yang kurang, pemandu menawarkan lagi paling sering sekali sehari, kecuali pengguna memilih Jangan ingatkan lagi.

Pengganti: pemanggilan lama mintaIzinNotifikasiJikaPerlu dan tampilkanPengingatIzinMerek di MainActivity.
Catatan: Android tidak mengizinkan aplikasi memberi izin khusus (alarm, baterai, overlay, akses notifikasi, Jangan Ganggu) tanpa pengguna mengaktifkannya sendiri di layar sistem; pemandu membukakan layarnya langsung.
