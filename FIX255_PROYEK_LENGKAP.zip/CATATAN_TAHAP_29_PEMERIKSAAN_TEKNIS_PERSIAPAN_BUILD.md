Tahap 29 — Pemeriksaan teknis dan persiapan build

Versi aplikasi tetap 1.0.68 (versionCode 68).

Perubahan yang benar-benar diterapkan:
- Menambahkan tools/verify_project.py untuk pemeriksaan statis sebelum build.
- Skrip memeriksa keberadaan konfigurasi Gradle, mempertahankan versi baseline 1.0.68/68, memvalidasi XML manifest, memeriksa deklarasi android:exported untuk komponen aplikasi, memeriksa apakah kelas yang disebut manifest memiliki berkas sumber, serta memastikan izin boot dan alarm tepat waktu tersedia.
- Workflow GitHub Actions Bangun APK dan Terbitkan Rilis kini menjalankan pemeriksaan tersebut setelah checkout dan sebelum pemasangan JDK/Android SDK/build.

Hasil lokal:
- python3 tools/verify_project.py: LULUS.
- Pemeriksaan sintaks XML manifest melalui parser Python: LULUS.
- Build Gradle penuh belum dijalankan secara lokal; proyek tidak menyertakan Gradle wrapper dan tidak ada Gradle terpasang yang terdeteksi di lingkungan pemeriksaan.

Batasan:
Pemeriksaan statis tidak menjamin kompilasi berhasil atau semua fitur berfungsi di perangkat. Hasil build nyata tetap harus diperiksa pada GitHub Actions.
