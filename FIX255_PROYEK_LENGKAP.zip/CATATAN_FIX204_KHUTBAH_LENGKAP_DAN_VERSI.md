# FIX204: Himpunan Khutbah diperluas (65 naskah) dan versi 1.0.85

Versi: versionCode 85, versionName 1.0.85 (naik tiga tingkat dari 82). User-Agent, README, panduan, dan tiga skrip uji ikut disesuaikan.

Khutbah: dari 10 menjadi 65 naskah dwibahasa.
- KhutbahBaku.kt: pembuka pertama, pembuka kedua, doa penutup (dipakai bersama).
- KhutbahTambahanA.kt (25): tauhid, teladan Rasul, ikhlas, tawakal, husnuzan, tobat, doa, dzikir, Al-Qur'an, kematian, dunia, zakat, sedekah, Ramadhan, Lailatul Qadar, Nuzulul Qur'an, Idul Fitri, hijrah/tahun baru, puasa Muharram, Maulid, Isra Mi'raj, kurban, haji/Arafah, hari Jum'at, memakmurkan masjid.
- KhutbahTambahanB.kt (30): jujur, adil, tawadhu, memaafkan, menahan marah, prasangka/ghibah, dengki, malu, amar makruf, janji, riba, rezeki halal, suap/korupsi, keluarga sakinah, mendidik anak, tetangga, silaturahmi, yang muda/tua, kebersihan, lingkungan, persatuan, musyawarah, tolong-menolong, yatim, etos kerja, pemuda, toleransi, tabayyun digital, amal jariyah/wakaf, memuliakan penyandang disabilitas.
- Halaman daftar: kolom cari tema (judul Indonesia/Inggris atau nomor) agar mudah bagi pembaca layar.

Catatan: seluruh naskah adalah draf asli untuk aplikasi; kutipan Arab dibatasi pada ayat dan hadits masyhur. Hadits yang derajatnya diperselisihkan sengaja tidak dikutip. Perlu ditinjau ustadz/takmir. Belum dikompilasi/diuji.
Bahasa aktif: pemeriksa LULUS.
