FIX236 - MELODI PENGINGAT IMSAK, MATAHARI TERBIT, DHUHA, DAN TAHAJUD

Perubahan:
1. Menambahkan preferensi melodi awal dan akhir yang terpisah untuk key imsak, terbit, dhuha, dan tahajud pada PrayerPrefs.
2. Menambahkan kontrol pemilihan melodi pada kelompok Pengingat waktu sholat. Setiap pengingat memiliki pemilih melodi sebelum dan setelah suara pengingat.
3. Pemilih memakai dialog bertahap yang sudah digunakan pengingat sebelum salat: daftar tetap terbuka selama pratinjau, tombol Simpan menerapkan pilihan, dan Batal mempertahankan nilai tersimpan sebelumnya.
4. PrayerAlarmService memutar melodi awal sebelum suara pengingat dan melodi akhir setelah audio selesai untuk keempat jenis pengingat tersebut.
5. Penjadwalan, aturan hari puasa untuk Imsak, pengaturan suara yang sudah ada, dan sakelar pengingat tidak diubah.
6. Menambahkan terjemahan label/petunjuk untuk bahasa tampilan Inggris melalui BahasaAplikasi.

Versi aplikasi dipertahankan: 1.0.86 (versionCode 86).

Validasi: arsip ZIP diperiksa dengan unzip -t. Build Gradle belum dijalankan karena Gradle Wrapper/executable tidak tersedia di lingkungan kerja.
