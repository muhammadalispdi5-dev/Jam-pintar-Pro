# Penambahan pemilihan aplikasi notifikasi khusus — Jam Pintar Pro 1.0.68

## Perubahan
- Menambahkan pilihan aplikasi tambahan pada menu Caller Name > Incoming Messages and Notifications.
- Pengguna dapat memilih beberapa aplikasi terpasang melalui dialog pilihan banyak yang mendukung pembaca layar.
- Daftar aplikasi berasal dari aplikasi yang memiliki ikon peluncur; aplikasi internal JPP dan aplikasi yang telah memiliki pengaturan khusus (SMS, WhatsApp, email, Gojek, Grab, inDrive, Maxim) tidak diduplikasi.
- Pilihan disimpan di SharedPreferences dan nonaktif secara bawaan. Pengguna dapat menyimpan pilihan atau menghapus semua pilihan.
- CallerListener membacakan notifikasi aplikasi yang dipilih menggunakan judul dan isi yang disediakan Android. Pengumuman memakai bahasa aktif aplikasi (Indonesia/Inggris).
- Menambahkan terjemahan Inggris untuk teks UI baru.
- Versi tetap 1.0.68 / versionCode 68.

## Batasan
- Konten yang dapat dibacakan bergantung pada informasi yang disediakan oleh notifikasi aplikasi pihak ketiga.
- Akses notifikasi Android untuk Jam Pintar Pro harus sudah diizinkan.
- Daftar pilihan hanya menampilkan aplikasi yang terdaftar sebagai aplikasi peluncur dan dapat terlihat melalui package visibility Android.
- Pemeriksaan statis bukan pengganti kompilasi APK dan pengujian perangkat nyata.
