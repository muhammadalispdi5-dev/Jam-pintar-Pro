# Catatan Tahap 15 — Locale kalender Hijriah

- Menstandarkan locale Indonesia yang digunakan saat membuat `IslamicCalendar` dari `Locale("in", "ID")` menjadi kode bahasa ISO modern `Locale("id", "ID")`.
- Tujuannya menghindari penggunaan kode bahasa Indonesia lama/deprecated pada konfigurasi locale perhitungan tanggal Hijriah.
- Tidak mengubah pilihan bahasa ucapan (`jamBahasaIdx`), bahasa tampilan, aturan batas malam pukul 18.00, maupun versi aplikasi.
- Versi tetap 1.0.68 / versionCode 68.
- Pemeriksaan yang dilakukan: verifikasi perubahan sumber dan integritas arsip ZIP. Build Android penuh serta pengujian perangkat belum dilakukan.
