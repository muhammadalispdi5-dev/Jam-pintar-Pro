# FIX172 — Mode pengenalan suara on-device saja

Versi aplikasi dipertahankan: `versionCode 82`, `versionName 1.0.82`.

## Perubahan kode

- `PerintahSuaraActivity` kini membuat recognizer melalui `SpeechRecognizer.createOnDeviceSpeechRecognizer()` (Android 12/API 31 atau lebih baru).
- Ketersediaan diperiksa melalui `SpeechRecognizer.isOnDeviceRecognitionAvailable()`.
- `RecognizerIntent.EXTRA_PREFER_OFFLINE` diaktifkan sebagai lapisan tambahan.
- Jalur `ACTION_RECOGNIZE_SPEECH`/layar pengenal eksternal tidak lagi digunakan oleh asisten suara.
- Tahap lanjutan seperti menyebut nama kontak dan memilih jenis panggilan juga memakai recognizer on-device.
- Jika layanan on-device tidak tersedia/gagal, aplikasi memberi pesan sesuai bahasa aktif dan menutup sesi. Aplikasi tidak diam-diam beralih ke pengenal suara daring.
- Penghentian TalkBack/Vocalizer dan pengelolaan fokus mikrofon dari FIX170 tetap dipertahankan.

## Batasan penting — belum merupakan paket model mandiri

FIX172 menggunakan layanan pengenalan suara on-device yang disediakan Android/perangkat. Kode ini tidak mengirim audio melalui layar pengenal eksternal, tetapi model bahasa tetap berasal dari layanan/paket bahasa yang tersedia di perangkat.

Karena itu:

1. Perangkat harus Android 12/API 31 atau lebih baru.
2. Layanan pengenalan suara pada perangkat harus menyediakan mode on-device dan paket bahasa yang diperlukan harus sudah terpasang.
3. Dukungan bahasa Indonesia, Inggris, Arab, Jawa, dan Sunda tidak dapat dijamin seragam; bergantung pada layanan dan paket bahasa perangkat.
4. Belum ada model sherpa-onnx/Whisper yang dibundel ke APK. Model dan pustaka native belum disertakan pada arsip ini.
5. Beberapa perintah aplikasi tetap memerlukan internet untuk mengambil data daring (misalnya cuaca atau pembaruan data). Pengenalan ucapan lokal tidak membuat sumber data daring menjadi offline.

Dengan demikian, FIX172 adalah peningkatan **offline-only yang fail-closed untuk pengenalan perintah** pada perangkat yang mendukungnya, bukan klaim bahwa seluruh asisten dan seluruh data aplikasi sudah mandiri tanpa internet.

## Validasi

Pemeriksaan sumber dilakukan untuk memastikan tidak ada lagi pemanggilan `startActivityForResult(ACTION_RECOGNIZE_SPEECH)` dari alur asisten. APK belum dikompilasi dan belum diuji di perangkat fisik. Kompilasi memerlukan Android Gradle Plugin/SDK yang sesuai.
