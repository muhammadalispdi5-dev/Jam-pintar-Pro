# FIX167 - Saluran volume audio Khatam (media, alarm, dan seterusnya)

## Perubahan
- Menu baru di Pengaturan Pemutaran Audio: **Saluran volume**, berisi tujuh pilihan seperti "Keluaran suara" pada Jam dan Baterai: media (awal), alarm, notifikasi, dering, aksesibilitas, panggilan suara, dan sistem.
- Dipakai oleh pemutar murattal di layar Khatam dan pemutar latar belakang (perintah suara/layar mati), sehingga keduanya konsisten.
- Selama layar Khatam terbuka, tombol volume fisik mengatur saluran yang dipilih (`volumeControlStream`).
- Volume mandiri audio yang sudah ada tetap bekerja di atas saluran terpilih. Perubahan saluran berlaku pada pemutaran berikutnya.
- Ikut direset oleh "Reset pengaturan Khatam" (kunci `saluran_audio_idx`). Pengaturan Jam dan Baterai tidak berubah.
- Berkas baru `SaluranAudioKhatam.kt`; uji statis `tools/uji_fix167_saluran_audio_khatam.py`.
- Bahasa aktif: semua teks memakai tr(id, en); pemeriksa bahasa dan resource string lulus. Tidak ada templat dolar bersarang.
- Belum dikompilasi dan belum diuji di perangkat. Perilaku saluran seperti alarm dan panggilan suara dapat berbeda antar perangkat/Android.
