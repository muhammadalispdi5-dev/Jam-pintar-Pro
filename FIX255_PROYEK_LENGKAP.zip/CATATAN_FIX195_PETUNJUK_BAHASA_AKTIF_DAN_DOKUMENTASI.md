# FIX195 — Penyempurnaan petunjuk penggunaan dan dokumentasi

Target versi aplikasi tetap **1.0.82** (`versionCode=82`, `versionName=1.0.82`).

## Perubahan
- Menambahkan bagian 21 pada petunjuk penggunaan Bahasa Indonesia dan English mengenai mesin pengenal suara, perbedaan speech recognition dan TTS, bahasa pengenalan yang mengikuti bahasa tampilan, pemeriksaan status paket offline, permintaan unduhan, pemeriksaan ulang, serta batasan versi Android.
- Menjelaskan secara eksplisit bahwa status permintaan unduhan dikirim tidak sama dengan paket telah selesai diunduh.
- Memperbarui README dari informasi versi lama menjadi dokumentasi proyek 1.0.82 dan menambahkan alur pengelola paket bahasa serta daftar pemeriksaan pra-publikasi.
- Memperbarui judul dan bagian dokumentasi pembaruan/keluhan agar tidak lagi menyebut versi 1.0.64 dan menambahkan penjelasan bahasa/paket pengenal suara.
- Tidak mengubah `versionCode`, `versionName`, Application ID, maupun implementasi fitur aplikasi.

## Batas verifikasi
Perubahan dokumentasi dan pemeriksaan sumber tidak membuktikan bahwa semua teks runtime sudah sepenuhnya bilingual. Skrip pemeriksa bahasa adalah pemeriksaan heuristik. Notifikasi, layanan latar belakang, TalkBack, TTS, dan pengenal suara tetap perlu diuji pada APK release di perangkat Android nyata dalam kedua bahasa.
