# FIX249 — Audio berkas pada setiap doa sehari-hari

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.

Halaman tiap doa (184 doa) punya bagian Audio doa: Putar, Jeda atau lanjutkan, Hentikan. Urutan sumber audio:
1. Rekaman bawaan res/raw bernama doa_001 sampai doa_184 (bila nanti ditambahkan ke proyek).
2. Rekaman pengguna di folder aplikasi Android/data/com.novan.bateraibicara/files/DoaAudio, bernama doa_NNN.mp3/m4a/ogg/wav/aac (NNN = nomor urut doa tiga angka).
3. Bila keduanya tidak ada: aplikasi membuat berkas WAV bacaan Arab dari suara Arab perangkat (synthesizeToFile), menyimpannya di cache aplikasi, lalu memutarnya; pemutaran berikutnya langsung dari berkas. Cache dihapus saat mesin suara diganti.

Batasan jujur: lingkungan kerja tidak punya akses ke rekaman qari dan tidak ada mesin suara Arab, sehingga berkas rekaman asli belum dapat disertakan di zip. Untuk audio qari, kirimkan berkas rekamannya dan beri nama sesuai pola di atas; saya akan memasukkannya ke res/raw.
