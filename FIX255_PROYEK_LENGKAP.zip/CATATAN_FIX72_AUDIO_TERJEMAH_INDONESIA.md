# FIX72 — Audio terjemahan Indonesia berupa berkas suara

## Permintaan
Pada Pengaturan Audio, pilihan "Pilihan pemutaran: Arab / terjemahan" dirancang agar memakai berkas audio
terjemahan bahasa Indonesia. Bila tidak ada datanya, fitur dihapus dari daftar.

## Hasil pemeriksaan data
- Server audio yang dipakai aplikasi (api.alquran.cloud / cdn.islamic.network) TIDAK punya edisi audio Indonesia.
  Daftar edisi audio (`/v1/edition/format/audio`) hanya memuat bahasa ar, en, fa, ur, zh, fr, ru, kk, tr, my, uz.
- Data audio terjemahan Indonesia yang ditemukan: Internet Archive, item `quraninindonesia`, 114 berkas MP3
  (satu per surah, nama `NNN` + nama surah, mis. `001AlFaatihah.mp3`; Thaha bernama `020Thaahaa2.mp3`).
  Alamat: `https://archive.org/download/quraninindonesia/<berkas>`. Daftar 114 nama sudah dicocokkan dengan
  halaman item. Isi suara BELUM didengarkan dan belum diuji dari aplikasi.
- Tidak ada data audio terjemahan per ayat, juz, atau halaman.

## Perubahan (KhatamActivity.kt)
1. Mode "terjemahan" kini memutar berkas audio Indonesia per surah penuh (bukan suara mesin TTS).
2. Mode "Murattal Arab lalu terjemahan (satu ayat)" dihapus karena tidak ada data per ayat.
   Pengaturan lama "arab_terjemahan" otomatis kembali ke "arab".
3. Butir "Pilihan pemutaran: Arab / terjemahan Indonesia" hanya tampil bila `daftarBerkasTerjemahanId`
   tidak kosong; bila daftar dikosongkan, butir hilang dan mode otomatis kembali ke Arab.
4. Tombol Putar pada mode terjemahan memutar terjemahan surah yang sedang dibuka dari awal; jeda/lanjut memakai
   tombol yang sama dengan murattal. Teks status dan tombol menyebut "terjemahan", bukan "murattal".
5. Percobaan ulang untuk berkas terjemahan: 1 kali (URL sama), tanpa variasi bitrate CDN.
6. TTS Android tetap dipakai hanya untuk ucapan koreksi hafalan; pendengar "audio terjemahan selesai"
   dihapus karena ikut terpicu oleh ucapan koreksi.
7. Keterangan sumber ditambahkan di halaman Khatam.

## Batasan
- Perlu internet; belum ada unduhan offline untuk audio terjemahan.
- Sumber unggahan komunitas, bukan penyedia resmi; bisa hilang atau berubah di masa depan.
- Tidak ada kompiler Kotlin di lingkungan kerja; perubahan hanya diperiksa kesetimbangan kurung dan diff.
  Mohon jalankan build GitHub Actions dan uji di HP: pilih mode terjemahan, tekan Putar, jeda/lanjut, ganti surah.
