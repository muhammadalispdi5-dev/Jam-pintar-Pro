# ATURAN TETAP: SEMUA FITUR MENGIKUTI BAHASA AKTIF

Aturan ini berlaku untuk SETIAP penyesuaian, perbaikan (FIX), dan penambahan fitur berikutnya, tanpa kecuali.
Siapa pun (pengembang atau asisten AI) yang mengubah proyek ini wajib membaca berkas ini lebih dulu.

## Definisi
Bahasa aktif = bahasa tampilan aplikasi saat ini (Indonesia = 0, English = 1), dibaca lewat
`BahasaAplikasi.tampilan(context)`. Bahasa ini mengikuti bahasa perangkat sampai pengguna memilihnya sendiri.

## Kewajiban
1. Semua teks yang dilihat atau didengar pengguna harus mengikuti bahasa aktif: judul dan isi dialog, label tombol,
   toast, status, pesan galat, contentDescription, pengumuman TalkBack (`announceForAccessibility`), ucapan TTS,
   notifikasi (judul, isi, nama kanal), widget, dan ringkasan.
2. Di Activity: pakai `tr("teks Indonesia", "English text")`. Di Receiver/Service/objek tanpa `tr`:
   `val english = BahasaAplikasi.tampilan(context) == 1` lalu `if (english) "..." else "..."`.
   Untuk teks di berkas sumber daya: tambahkan kunci di `values/strings.xml` DAN `values-en/strings.xml`.
3. Dua bahasa harus selalu lengkap. Menambah teks Indonesia tanpa padanan Inggris (atau sebaliknya) dianggap belum selesai.
4. Teks gabungan: terjemahkan kalimat utuh, bukan potongan kata yang ditempel. Susunan kalimat boleh berbeda.
5. Angka, tanggal, dan waktu: pakai `Locale.ROOT` untuk format teknis; untuk tampilan ke pengguna ikuti bahasa aktif.
6. Nama diri tidak diterjemahkan (nama surah transliterasi Latin, nama qari, nama kontak). Istilah ibadah yang lazim
   (muraja'ah, ayat, surah) tetap dipakai pada kedua bahasa dengan penjelas bila perlu.
7. Fitur baru wajib diuji dalam kedua bahasa, termasuk TalkBack, sebelum dinyatakan selesai.
8. Setiap catatan FIX harus memuat baris "Bahasa aktif:" yang menyebut tempat teks baru dan hasil pemeriksaan.

## Penegakan otomatis
- `python3 tools/periksa_bahasa_aktif.py` dijalankan oleh `tools/verify_project.py` dan oleh workflow GitHub Actions
  sebelum build. Pemeriksa gagal bila:
  - kunci `strings.xml` Indonesia dan Inggris tidak sama;
  - ada teks Indonesia di kode Kotlin yang tidak dibungkus `tr(...)`/`english`/sumber daya, melebihi baseline;
  - berkas Kotlin baru memiliki teks tanpa padanan (batas berkas baru adalah nol).
- Baseline `tools/baseline_bahasa_aktif.json` mencatat sisa teks lama yang belum diterjemahkan. Angkanya hanya boleh
  TURUN. Setelah menerjemahkan teks lama, jalankan `python3 tools/periksa_bahasa_aktif.py --perbarui-baseline`.
  Dilarang menaikkan baseline untuk meloloskan teks baru.
- Pemeriksa bersifat heuristik; kelulusan bukan pengganti uji manual di perangkat.
