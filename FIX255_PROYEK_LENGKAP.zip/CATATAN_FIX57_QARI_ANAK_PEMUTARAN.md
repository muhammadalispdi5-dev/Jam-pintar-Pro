# FIX57 — Qari anak bisa diputar, Muhammad Taha Al-Junayd dipastikan masuk daftar

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX56. Perubahan: `KhatamActivity.kt`.

## Masalah yang ditemukan
1. **Ahmad Saud (dan semua qari anak) tidak mau diputar.** Qari anak hanya punya audio per surah, tetapi cara pemutaran bawaan adalah "Per ayat". Tombol Putar lalu memanggil jalur per ayat yang hanya memunculkan dialog "Audio ayat tidak tersedia", sehingga audio tidak pernah mulai kecuali pengguna mengubah Cara pemutaran sendiri.
2. **Putar surah menuntut teks Al-Qur'an sudah diunduh**, padahal audio per surah MP3Quran tidak memerlukannya.
3. **Katalog hanya dicoba dimuat satu kali per layar.** Bila unduhan katalog sekali gagal (jaringan lambat), daftar qari anak kosong terus dan Muhammad Taha tidak pernah muncul sampai layar dibuka ulang.
4. **Hanya rekaman pertama (`moshaf[0]`) setiap qari yang dipakai**, tanpa percobaan ulang bila server gagal (percobaan MP3Quran = 0).
5. Pencocokan nama qari anak sensitif terhadap spasi/tanda hubung dan hanya memakai nama Latin.

## Perbaikan
- Tombol Putar pada qari per surah (putar biasa) kini langsung memutar **surah penuh** dan memberi tahu lewat toast; tidak perlu mengubah Cara pemutaran. Mode hafalan per ayat tetap memakai dialog penjelasan karena butuh audio per ayat.
- Putar surah untuk qari MP3Quran tidak lagi memaksa teks Al-Qur'an terunduh.
- Katalog dimuat ulang setiap pilihan qari dibuka sampai berhasil; ada pesan "Memuat katalog qari…". Daftar qari anak yang pernah berhasil dimuat disimpan di preferensi dan tetap tampil saat offline.
- Setiap qari memeriksa **semua** rekamannya; yang paling lengkap jadi sumber utama, rekaman lain disimpan sebagai server cadangan. Pemutaran mencoba cadangan (maksimal 2) bila server utama gagal. Server `http://` dinaikkan ke `https://`.
- Pengenalan qari anak memakai nama yang dinormalisasi (tanpa spasi/tanda baca) serta nama Arab dari katalog bahasa Arab: Taha + Junaid/Junayd/Juneid/Junid, Mohamed/Muhammad Taha, Ahmad/Ahmed Saud/Saoud/Sa3ud, Junaid Adam.
- Urutan daftar Qari anak tetap: 1) Muhammad Taha Al-Junayd, 2) Ahmad Saud, 3) Junaid Adam.

## Batasan
- Muhammad Taha Al-Junayd tampil **jika ia ada di katalog MP3Quran**; tidak ada URL yang ditanam secara manual karena tidak bisa diverifikasi tanpa internet. Bila setelah katalog termuat ia tetap tidak muncul, nama persisnya di API perlu dilihat (cari di daftar "Qari audio per surah").
- Audio per ayat, juz, dan halaman tetap tidak tersedia untuk qari anak.

## Pemeriksaan
- Tanda kurung Kotlin seimbang; `verify_project.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat/jaringan. Uji: buka Pilih suara qari > Qari anak (pilihan terbaik); pastikan Muhammad Taha Al-Junayd tampil; pilih Ahmad Saud, tekan Putar, surah penuh harus mulai; ulangi dengan mode pesawat untuk memastikan daftar tetap tampil dari cache.
