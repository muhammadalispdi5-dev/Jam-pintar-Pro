# FIX202: Himpunan Khutbah Jum'at Pilihan

Berkas baru: KhutbahData.kt (10 naskah dwibahasa), KhutbahJumatActivity.kt. Diubah: AndroidManifest.xml, MainActivity.kt (tombol setelah Kitab Hadits), strings.xml id dan en (judul_khutbah, menu_khutbah).

Naskah: Taqwa; Syukur; Sabar; Berbakti kepada orang tua; Persaudaraan sesama muslim; Menjaga lisan; Menjaga amanah; Memuliakan ilmu; Menjaga shalat; Menghargai waktu.
Tiap naskah: khutbah pertama (muqaddimah baku, ayat, isi, hadits) dan khutbah kedua (pembuka, wasiat takwa, doa penutup, ayat An-Nahl 90).
Halaman naskah: Dengarkan (TTS bahasa aktif; kutipan Arab tidak dibacakan), Hentikan, Perbesar/Perkecil huruf (disimpan), Salin, Bagikan.

PENTING: naskah adalah draf asli yang disusun untuk aplikasi (bukan salinan dari penceramah/buku). Kutipan Arab dibatasi pada bacaan baku dan ayat/hadits masyhur. Wajib ditinjau ustadz/takmir sebelum disampaikan di mimbar. Belum dikompilasi/diuji.
Bahasa aktif: setiap blok punya padanan id dan en; antarmuka lewat tr(); pemeriksa LULUS.
