# FIX108 — Asisten Tahfiz Cerdas lebih ramah TalkBack dan pembaca layar

Basis: FIX107. Versi tetap. Berkas: berkas baru `AksesTahfiz.kt` (perangkat bantu), perubahan di `KhatamActivity.kt`.

## Masalah yang ditemukan
1. Tombol panel Asisten Tahfiz Cerdas memakai `contentDescription = "$judul. $uraian"`: nama tombol menjadi kalimat panjang yang berbeda dari teks yang terlihat,
   uraian bercampur dengan nama (tidak bisa dipisahkan oleh pengaturan verbositas TalkBack), nama tidak cocok dengan teks tampilan (menyulitkan Voice Access),
   dan tidak ada tanda posisi "butir ke-N dari M".
2. Pengantar diumumkan lewat `announceForAccessibility` dengan jumlah pilihan yang ditulis tetap ("Empat pilihan") dan fokus dipaksa; pengumuman ini dapat menimpa
   atau menggandakan bacaan judul dialog.
3. `judulDenganPesan` (dipakai di banyak dialog Khatam, termasuk muraja'ah dan pengaturan latihan) memberi `contentDescription` pada kontainer yang anak-anaknya
   juga dapat difokuskan, sehingga judul dan isi terbaca dua kali.
4. Hasil koreksi bacaan menyebut "ditandai merah", padahal pengguna tunanetra tidak dapat memakai warna; kata salah juga tidak diberi nomor urutnya.
5. Judul penilaian muraja'ah tidak menyebut kemajuan sesi ("ayat ke-3 dari 10"); informasi itu hanya muncul di toast yang cepat hilang.
6. Pesan dialog Asisten Hafalan Inklusif dan Asisten Koreksi Bacaan berupa satu paragraf panjang tanpa struktur.

## Perbaikan
- `AksesTahfiz.tombolAksi`: nama tombol = judul (sama dengan teks yang terlihat); uraian dibacakan sebagai petunjuk (Android 8+; di bawahnya digabung ke deskripsi);
  posisi butir "N dari M" lewat info koleksi; tinggi minimum 56 dp; teks mengikuti ukuran font sistem; judul tebal dan uraian sedikit lebih kecil bagi yang melihat.
- `AksesTahfiz.tandaiDaftar`: kontainer tombol diumumkan sebagai daftar berisi N butir.
- `AksesTahfiz.satuBacaan` + `judulDenganPesan`: judul dan pengantar menjadi satu butir berstatus judul (Android 9+: dapat dilompati lewat navigasi judul), terbaca sekali.
- Panel Asisten Tahfiz Cerdas ditulis ulang: judul kustom + pengantar yang menghitung jumlah pilihan dari daftar (bukan angka tetap), pengumuman manual dan paksaan fokus dihapus;
  jalur kembali ("Kembali", "Tutup") tetap seperti semula.
- Pesan dua dialog asisten dipecah menjadi paragraf pendek (cara kerja, aksesibilitas/catatan TalkBack, batas fitur). Catatan baru menjelaskan bahwa saat mikrofon mendengarkan,
  pembaca layar dibisukan sebentar dan getaran berarti mikrofon siap (perilaku yang memang sudah ada sejak FIX50).
- Dialog Pengaturan Asisten Tahfiz memakai judul kustom yang menyebut jumlah pilihan.
- Hasil koreksi: kalimat "ditandai merah" diganti "juga ditandai tebal dan bergaris bawah", dan kata yang perlu diperbaiki disebut dengan nomor urutnya, mis. "kata ke-3: ... · kata ke-5: ...".
- Judul penilaian muraja'ah memuat kemajuan sesi, mis. "Nilai hafalan Anda (3/10) — ...".
- Semua teks tetap memakai `tr(Indonesia, English)`.

## Tidak diubah (disengaja)
- Mode senyap TalkBack saat mikrofon mendengarkan, getar isyarat, dan pengumuman status koreksi tetap memakai mekanisme FIX50/FIX102 yang sudah teruji; tidak diganti
  dengan live region agar tidak ada risiko pengumuman ganda atau bocor ke mikrofon.
- Logika muraja'ah, koreksi suara, dan latihan tanpa mikrofon tidak disentuh.

## Cara menguji dengan TalkBack
1. Buka Khatam > Pengaturan > Asisten Tahfiz Cerdas. Harus terdengar judul dialog dan pengantar sekali, lalu "daftar, 4 butir" saat fokus masuk ke tombol.
2. Geser ke tiap tombol: terdengar nama, "tombol", uraian, dan posisi "1 dari 4" dst. Ketuk dua kali membuka alur tujuan.
3. Di Voice Access, ucapkan nama tombol yang terlihat, mis. "Ketuk Asisten Hafalan Inklusif".
4. Lakukan koreksi bacaan sampai ada kata salah: daftar kata disebut dengan nomor urutnya tanpa merujuk warna.
5. Mulai sesi muraja'ah: judul penilaian menyebut kemajuan sesi.

## Batas pemeriksaan
Belum dikompilasi dan belum diuji dengan TalkBack di perangkat (tidak ada Gradle/SDK di lingkungan ini). Pemeriksaan statis lulus: kurung seimbang, tidak ada escape string tidak sah,
`tools/verify_project.py` lulus.
