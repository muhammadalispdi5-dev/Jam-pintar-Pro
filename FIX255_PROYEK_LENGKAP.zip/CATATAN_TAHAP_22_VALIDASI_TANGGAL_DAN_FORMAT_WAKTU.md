# Tahap 22 — Validasi tanggal dan format waktu jadwal online

## Perubahan
- `PrayerOnlineTimes.kt` tidak hanya memeriksa jumlah entri dalam respons kalender, tetapi juga memastikan setiap tanggal berada pada tahun dan bulan yang diminta.
- Tanggal ganda pada respons ditolak, karena jumlah entri yang tampak lengkap belum tentu berarti semua hari terwakili.
- Parsing tanggal yang tidak valid menghasilkan kegagalan sinkronisasi yang terkendali.
- Waktu salat yang tidak memiliki format jam-menit valid atau memiliki jam di luar 00–23 maupun menit di luar 00–59 tidak diterima sebagai data yang valid.
- Penanda sinkronisasi penuh tidak diperbarui jika pemeriksaan ini gagal.

## Batas perubahan
- Versi aplikasi tetap `versionCode 68`, `versionName 1.0.68`.
- Tidak mengubah rumus waktu salat, koreksi pengguna, alarm, atau bahasa suara.

## Pemeriksaan
- Pemeriksaan statis terhadap perubahan dilakukan.
- Struktur ZIP diperiksa dengan `unzip -t`.
- Build Android penuh dan pengujian respons API nyata belum dilakukan.
