# FIX185 - Tombol Kembali di sub menu Khatam tidak lagi melempar ke tampilan awal

Basis: FIX184 (apostrof Khatam). Versi aplikasi tidak diubah.

## Masalah
Di beberapa sub menu pengaturan Khatam, tombol Kembali (tombol sistem, gestur kembali, atau sentuhan di luar dialog) menutup dialog tanpa membuka induknya, sehingga pengguna kembali ke tampilan awal Khatam.

## Hasil audit
Semua dialog pada pohon Pengaturan Khatam diperiksa satu per satu (hafalan, pemutaran audio, equalizer dan efek, pengingat, target, aksesibilitas, riwayat, statistik). Yang belum punya jalur kembali ke induk, kini sudah diperbaiki:
- Volume mandiri audio: Batal, Kembali, dan tombol sistem kembali ke Pengaturan Pemutaran Audio.
- Pengingat membaca Al-Qur'an: tombol sistem dan sentuhan di luar kini kembali ke Pengaturan Khatam (sebelumnya hanya tombolnya).
- Jenis suara pengingat: Kembali dan tombol sistem kembali ke Pengingat membaca atau Pengingat cerdas hafalan, sesuai asalnya.
- Unduh audio: pilihan juz dan pemilih folder kembali ke dialog Unduh audio (sebelumnya pemilih folder berakhir di layar awal).
- Dialog lain sudah punya jalur kembali dan tidak diubah. Dialog tingkat atas Pengaturan Khatam sengaja kembali ke menu Khatam.
- Uji statis `tools/uji_fix185_kembali_submenu_khatam.py` memastikan 33 dialog sub menu tidak kehilangan jalur kembali.

## Perbaikan tambahan
- `PemutarQuranService.kt`: pemeriksa bahasa aktif gagal di FIX184 karena nama folder "Audio Per Ayat" tertulis langsung. Khatam menamai folder menurut bahasa aktif saat mengunduh (Audio Per Surah / Audio by Surah, Audio Per Ayat / Audio by Verse), padahal pemutar latar hanya mencari nama Indonesia. Kini keduanya dicari, sehingga audio unduhan saat bahasa English juga ditemukan.
- Pemeriksa bahasa aktif dan resource string lulus. Belum dikompilasi dan belum diuji di perangkat.
