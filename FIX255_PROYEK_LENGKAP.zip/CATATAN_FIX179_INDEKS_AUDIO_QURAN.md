# FIX179 — Indeks audio Al-Qur'an lokal

Versi aplikasi dipertahankan pada `versionCode=82` dan `versionName=1.0.82`.

## Fokus perbaikan
- Pencarian berkas audio per surah dan per ayat sekarang membangun indeks untuk satu surah, bukan memindai penyimpanan untuk setiap ayat.
- Hasil indeks disimpan di memori layanan dan digunakan kembali pada perintah berikutnya.
- Indeks diperbarui jika qari aktif berubah.
- Kueri MediaStore dibatasi berdasarkan pola nama berkas dan nomor surah, bukan membaca seluruh koleksi untuk setiap pencarian.
- Mendukung nama berkas yang dibuat fitur Khatam: `Qari_<nama>_Surah_<nomor>_...mp3` dan `Qari_<nama>_S<nomor>_A<nomor>.mp3`.
- Jalur folder bawaan, Download, penyimpanan khusus aplikasi, MediaStore, dan SAF tetap diperiksa.

## Bagian yang tidak diubah
- Pengenalan perintah suara dan penafsiran nama surah.
- Fungsi pembacaan waktu dan jadwal salat.
- Aturan bahasa aktif Indonesia/Inggris dan seluruh fitur lain.

## Catatan pengujian
Arsip ZIP diperiksa integritasnya. Build Gradle/Android dan uji langsung pada perangkat belum dijalankan di lingkungan ini; hasil akhir tetap perlu diverifikasi melalui GitHub Actions dan pengujian di HP.
