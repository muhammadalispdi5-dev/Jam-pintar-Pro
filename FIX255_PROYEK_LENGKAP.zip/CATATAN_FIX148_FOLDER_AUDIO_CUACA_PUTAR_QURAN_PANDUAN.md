# FIX148 — Folder unduhan audio, perintah cuaca, pemutaran seluruh Al-Qur'an, dan panduan lengkap

Sumber: FIX147_TIMER_JAM_HITUNG_MUNDUR.zip.

## Perubahan
1. Menambahkan pemilih folder unduhan audio menggunakan Android Storage Access Framework. Pengguna dapat memilih folder dari dialog Unduh Audio. Izin folder disimpan secara persisten. Dialog unduhan menyediakan pilihan untuk memilih folder lain maupun kembali ke folder bawaan tanpa menghapus berkas yang sudah ada. Berkas audio disimpan pada subfolder `Al-Qur'an/simpan folder audio/<Nama Qari>` di dalam folder pilihan.
2. Tujuan bawaan yang telah digunakan aplikasi tidak dihapus atau diubah. Jika pengguna tidak memilih folder, unduhan tetap menggunakan jalur bawaan sebelumnya. Jika folder pilihan dihapus, dipindah, atau aksesnya dicabut, URI pilihan yang tidak lagi dapat diakses dibersihkan dan penyimpanan kembali ke jalur bawaan. Pilihan folder audio tidak mengubah tujuan unduhan teks.
3. Menambahkan perintah suara cuaca terkini: “bacakan cuaca” / “read the weather”. Menggunakan koordinat yang sudah disimpan pada Pengaturan Jadwal Sholat, mengambil kondisi saat ini dari Open-Meteo, dan membacakan suhu, suhu terasa, kelembapan, kecepatan angin, serta ringkasan kondisi. Lokasi harus disetel terlebih dahulu dan internet tersedia.
4. Menambahkan pengenalan perintah pemutaran seluruh Al-Qur'an. Layanan memutar ayat secara berurutan dari ayat 1 sampai 6236 (Al-Fatihah sampai An-Nas) melalui audio per ayat, sehingga dapat dijeda, dilanjutkan, dan dihentikan. Jika qari yang dipilih hanya menyediakan audio per surah, pemutaran seluruh mushaf memakai Alafasy untuk menjamin semua ayat tersedia.
5. Memperluas petunjuk penggunaan Indonesia dan Inggris dengan urutan langkah untuk Khatam, hafalan, unduhan audio dan pemilihan folder, perintah suara/cuaca, pemutaran seluruh Al-Qur'an, timer, Mode Acara, doa, lokasi, pemandu jalan, fasilitas terdekat, baterai, kalender, nama pemanggil, aksesibilitas, bahasa, dan cadangan/pemulihan.
6. Contoh perintah suara di resource juga diperbarui.

## Kompatibilitas dan batasan
- `versionCode` dan `versionName` dipertahankan sesuai sumber (82 / 1.0.82).
- Pemutaran seluruh Al-Qur'an memerlukan koneksi internet yang stabil dan waktu yang panjang; ini bukan unduhan permanen.
- Cuaca melaporkan kondisi saat ini dari Open-Meteo, bukan prakiraan multi-hari. Data memakai lokasi Jadwal Sholat tersimpan; perbarui lokasi itu jika pengguna berpindah tempat.
- Pengujian perangkat fisik untuk penyedia folder SAF, izin lokasi, jaringan, dan audio tetap diperlukan.
