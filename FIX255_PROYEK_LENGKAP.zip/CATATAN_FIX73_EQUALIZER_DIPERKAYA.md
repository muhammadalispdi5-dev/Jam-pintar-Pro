# FIX73 — Equalizer Audio Diperkaya

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX72. Perubahan hanya di `KhatamActivity.kt`.

## Yang baru
- **Menu Equalizer** kini berisi: pilih preset, atur manual tiap pita, efek tambahan, dengar ringkasan efek aktif, setel ulang semua ke normal. Setelah memilih sesuatu, pengguna kembali ke menu ini sehingga bisa terus menyetel sambil audio berjalan.
- **8 preset bawaan**: Normal, Vokal/bacaan, Bass, Treble, **Jernih** (kata lebih jelas), **Hangat**, **Malam** (halus, tidak tajam), **Speaker ponsel** (kompensasi speaker kecil). Kurva dihitung dengan interpolasi halus pada skala logaritmik frekuensi (tujuh titik jangkar), jadi hasilnya wajar pada perangkat dengan 5 pita maupun 10 pita.
- **3 slot kustom** (Kustom 1, 2, 3), masing-masing tersimpan terpisah. Data Kustom lama tetap terbaca sebagai Kustom 1. Slot kosong langsung membuka penyunting.
- **Isi dari preset**: tombol di penyunting kustom untuk mengisi semua penggeser dari salah satu preset sebagai titik awal.
- **Preset bawaan perangkat** (bila perangkat menyediakan) ikut tampil di daftar preset.
- **Efek tambahan** (dapat dipakai bersama preset apa pun, tersimpan, langsung terdengar):
  - Bass tambahan 0–100 persen (BassBoost).
  - Suara ruang 0–100 persen (Virtualizer), paling terasa pada headphone.
  - Penguat volume 0–10 dB (LoudnessEnhancer), dengan peringatan agar dinaikkan perlahan.
  - Tombol "Matikan semua". Bila perangkat tidak mendukung salah satu efek, alasannya diumumkan, tidak diam saja.
- Semua penggeser memakai label dan `contentDescription` yang dibaca TalkBack beserta nilainya.

## Perbaikan sekaligus
- Cadangan sesi audio: bila perangkat menolak sesi bersama, Equalizer lama kini dilepas lalu dibuat ulang pada sesi pemutar (sebelumnya Equalizer tetap menempel di sesi lama sehingga tidak berpengaruh).
- Sesi audio dibuat terpisah dari Equalizer, sehingga efek tambahan masih bisa bekerja walau Equalizer pita tidak didukung perangkat.
- Semua efek dilepas di `onDestroy`.

## Pemeriksaan dan batas
- `tools/verify_project.py`: lihat hasil di bawah; tanda kurung `{}` dan `[]` seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat (kompilator Kotlin tidak tersedia di lingkungan ini). Mohon bangun APK lalu laporkan bila ada galat kompilasi.
- Efek tetap bergantung pada dukungan perangkat/ROM, dan hanya memengaruhi murattal serta audio terjemahan berupa berkas, tidak memengaruhi suara Text-to-Speech.
