# FIX150 - Pemeriksa bahasa aktif: JamActivity, PerintahSuaraActivity, TimerJamService

Versi aplikasi tidak diubah. Basis: FIX149. Berkas diubah: JamActivity.kt, PerintahSuaraActivity.kt, TimerJamService.kt, PrayerPrefs.kt, tools/baseline_bahasa_aktif.json.

## Temuan
`tools/periksa_bahasa_aktif.py` melaporkan JamActivity.kt (35, batas 25), PerintahSuaraActivity.kt (15, batas 0), TimerJamService.kt (5, batas 0).
Sebagian besar sebenarnya sudah dua bahasa, tetapi memakai pembungkus bernama `tt(...)` (JamActivity) dan `t(...)` (TimerJamService) yang tidak dikenali pemeriksa, atau percabangan `if (bahasa == 1) ... else ...` yang dipecah beberapa baris. Sisanya benar-benar belum diterjemahkan.

## Perbaikan
- JamActivity.kt: `tt` diganti nama menjadi `tr` (aturan proyek). Enam teks yang memang belum dibungkus kini punya padanan Inggris: tiga judul/label (Melodi, tes jam, dan suara; jam dan alarm jam) dan tiga status izin alarm tepat waktu.
- TimerJamService.kt: `t` diganti nama menjadi `tr`; teks tidak berubah.
- PerintahSuaraActivity.kt: sapaan/terima kasih/perpisahan asisten suara, pesan lokasi belum diatur, kalimat cuaca, pesan gagal cuaca, dan "kondisi cuaca tidak diketahui" ditulis ulang dengan `tr(id, en)` (isi kalimat kedua bahasa sama dengan sebelumnya). Perbandingan "Lokasi belum diatur" diganti properti baru `PrayerPrefs.namaTempatTersimpan`.
- Baseline hanya turun (JamActivity 25 -> 0; berkas lain 0).

## Pemeriksaan
- `tools/periksa_bahasa_aktif.py`: LULUS. `tools/periksa_resource_strings.py`: LULUS.
- Keseimbangan kurung kurawal ketiga berkas: 0.
- Belum dikompilasi/diuji di perangkat. `tools/verify_project.py` masih melaporkan satu kegagalan lama di luar perubahan ini: pemeriksa manifest tidak menemukan berkas bernama TimerJamBootReceiver (kelasnya ada di TimerJamService.kt).

## Bahasa aktif
Seluruh teks baru/ditulis ulang memakai tr(id, en) dengan padanan Inggris; tidak ada kunci resource baru. Belum diuji manual dalam dua bahasa/TalkBack.
