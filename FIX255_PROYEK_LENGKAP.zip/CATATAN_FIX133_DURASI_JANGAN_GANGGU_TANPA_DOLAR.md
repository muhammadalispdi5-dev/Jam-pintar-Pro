# FIX133 — Pilihan durasi Mode Jangan Ganggu tertulis "$it menit"

Versi aplikasi tidak diubah. Basis: FIX132. Berkas diubah: `PrayerSettingsActivity.kt`, `PerintahSuaraActivity.kt`.

## Masalah
Pada Pengaturan Jadwal Salat, bagian "Mode Jangan Ganggu otomatis saat salat", pilihan "Durasi Mode Jangan Ganggu" menampilkan
setiap pilihan sebagai teks mentah `$it menit`, bukan "5 menit", "10 menit", dan seterusnya. Pembaca layar membacakan "dolar it menit".
Penyebabnya sama dengan FIX53 dan FIX115: templat teks `"$it menit"` tidak berubah menjadi angka pada tampilan.

## Perbaikan
- `PrayerSettingsActivity.kt`: label pilihan disusun dengan penggabungan teks biasa dan per bahasa:
  "5 menit, 10 menit, 15 menit, 30 menit, 45 menit, 60 menit" (English: "5 minutes ... 60 minutes").
  Toast sesudah memilih juga mengikuti bahasa aktif: "Mode Jangan Ganggu akan berlangsung 45 menit" / "Do Not Disturb mode will last 45 minutes".
  Judul pilihan tetap terhubung ke daftar (`labelFor`), sehingga pembaca layar menyebut "Durasi Mode Jangan Ganggu, 10 menit".
- Tidak ada lagi karakter "$" di `PrayerSettingsActivity.kt`.
- `PerintahSuaraActivity.kt`: tiga templat serupa yang masih ada ikut diganti penggabungan teks biasa, karena akarnya sama dan
  satu di antaranya tampil kepada pengguna pembaca layar: daftar pilihan kontak untuk panggilan ("nama, nomor"), alamat
  `https://wa.me/<nomor>` untuk membuka chat WhatsApp, dan kalimat English pembuka chat WhatsApp.

## Pemeriksaan
- Kurung (), {}, [] seimbang pada kedua berkas; `tools/verify_project.py` lulus (termasuk bahasa aktif dan resource string).
- BELUM dikompilasi dan BELUM diuji di perangkat atau dengan TalkBack.

## Bahasa aktif
Teks baru ada di `PrayerSettingsActivity.kt` (label durasi dan toast), seluruhnya mengikuti bahasa aktif Indonesia dan English.
Tidak ada kunci `strings.xml` baru. Pemeriksa bahasa aktif: LULUS.
