# Perbaikan urutan Call Types and Repetition dan Incoming Messages and Notifications

Versi aplikasi dipertahankan pada 1.0.68 (`versionCode 68`).

## Call Types and Repetition
Urutan pengaturan diubah menjadi:
1. Telepon seluler: sakelar pengaktifan dan kalimat pengumuman pemanggil.
2. WhatsApp Business: sakelar pengaktifan, pengumuman panggilan suara, dan pengumuman panggilan video.
3. WhatsApp Messenger: sakelar pengaktifan, pengumuman panggilan suara, dan pengumuman panggilan video.
4. Pengulangan panggilan: jeda dan batas pengulangan.

## Incoming Messages and Notifications
Urutan pengaturan diubah menjadi:
1. Pesan seluler/SMS: mode pembacaan, sakelar, dan kalimat pengumuman.
2. WhatsApp Business: mode pembacaan, chat pribadi/grup, dan pemberitahuan pesan suara pribadi/grup.
3. WhatsApp Messenger: mode pembacaan, chat pribadi/grup, dan pemberitahuan pesan suara pribadi/grup.
4. Aplikasi lain: email, Gojek, Grab, inDrive, dan Maxim.
5. Pengulangan notifikasi pesan: jumlah pembacaan dan jeda.

Setiap kategori memiliki judul aksesibilitas dan penjelasan fungsi. Ditambahkan padanan bahasa Inggris untuk teks penjelas dan label yang baru agar mengikuti bahasa tampilan utama aplikasi.

## Pemeriksaan
Pemeriksaan statis `tools/verify_final.py` lulus. Arsip ZIP diperiksa setelah dibuat. Ini bukan pengganti kompilasi Android atau pengujian pada perangkat nyata.
