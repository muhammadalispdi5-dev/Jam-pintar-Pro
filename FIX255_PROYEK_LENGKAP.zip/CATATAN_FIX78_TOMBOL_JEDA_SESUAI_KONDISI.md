# FIX78 - Deskripsi tombol jeda sesuai kondisi

- Belum memutar: "Putar audio" / "Play audio".
- Sedang memutar: "Jeda audio" / "Pause audio".
- Dijeda: "Lanjutkan audio" / "Resume audio".
- Tampilan tombol ikut diperbarui saat audio selesai, gagal, atau dimulai ulang.
- Mengikuti bahasa aktif (tr). Belum dikompilasi/diuji.
