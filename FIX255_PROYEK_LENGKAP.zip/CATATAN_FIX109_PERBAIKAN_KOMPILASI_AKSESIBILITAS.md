# FIX109 — Perbaikan galat kompilasi (GitHub Actions run 41288820520)

Basis: FIX108. Tugas gagal: `:app:compileDebugKotlin` (6 galat, semuanya di `AksesTahfiz.kt`).

## Penyebab
Dua penerapan `View.AccessibilityDelegate.onInitializeAccessibilityNodeInfo` memakai parameter nullable `(View?, AccessibilityNodeInfo?)`.
Dengan `compileSdk = 36`, parameter metode itu bertanda non-null, sehingga Kotlin menolak override (“overrides nothing”) dan panggilan `super` tidak cocok tipe.

## Perbaikan
Tanda tangan diubah menjadi `(host: View, info: AccessibilityNodeInfo)`; pemeriksaan null yang tidak lagi diperlukan dihapus. Tidak ada perubahan perilaku.

## Pemeriksaan
Kurung seimbang, `tools/verify_project.py` lulus. Belum dikompilasi di lingkungan ini; mohon jalankan ulang workflow dan kabari bila muncul galat lain.
