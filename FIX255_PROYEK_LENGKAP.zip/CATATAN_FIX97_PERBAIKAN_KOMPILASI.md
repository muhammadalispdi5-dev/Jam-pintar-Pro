# FIX97 — Perbaikan galat kompilasi (GitHub Actions run 41253531415)

Basis: FIX96. Tugas gagal: `:app:compileDebugKotlin` (dan Release) dengan 2 galat "Unsupported escape sequence".

## Penyebab
`PemutarQuranService.kt` baris 550, pada penafsir perintah suara, menulis regex dengan satu garis miring terbalik:
`Regex("[^\p{L}\p{N}]+")`. Di string Kotlin biasa, `\p` bukan escape yang sah (kolom 77 dan 82 yang dilaporkan).

## Perbaikan
Garis miring digandakan agar regex menerimanya: `Regex("[^\\p{L}\\p{N}]+")` (sama dengan penulisan di KhatamActivity).
Hanya satu baris yang diubah; tidak ada perubahan perilaku.

## Pemeriksaan
- Seluruh berkas .kt dipindai untuk escape tidak sah di string biasa: tidak ada sisa.
- `tools/verify_project.py` lulus.
- Belum dikompilasi di lingkungan ini (tidak ada kompilator Kotlin); mohon jalankan ulang workflow dan kabari bila muncul galat lain.
