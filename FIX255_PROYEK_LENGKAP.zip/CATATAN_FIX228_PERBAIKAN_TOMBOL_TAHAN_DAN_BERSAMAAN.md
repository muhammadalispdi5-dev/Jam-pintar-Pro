# FIX228 - Perbaikan pemicu "tahan volume atas" dan "volume atas+bawah bersamaan"

Laporan: dua pola itu belum berfungsi, pola lain berfungsi.

Penyebab yang paling mungkin (belum dapat dipastikan tanpa HP; kode lama bergantung pada hal yang tidak dijamin Android):
1. Pola tahan menunggu peristiwa pengulangan tombol. Sebagian HP tidak mengirim pengulangan untuk volume atas. Kini pola tahan dinilai oleh PEWAKTU (Handler) yang berjalan sesudah lama menahan, tanpa memerlukan pengulangan.
2. Pola bersamaan membandingkan downTime peristiwa, yang dapat berubah ketika peristiwa diteruskan ulang oleh layanan aksesibilitas. Kini semua penilaian memakai waktu kedatangan peristiwa (uptime), jendela bersamaan dilonggarkan menjadi 800 ms, urutan tombol bebas, dan peristiwa lepas yang hilang tidak lagi merusak tekanan berikutnya.

Tambahan diagnosa: layar Tombol Pemicu Asisten Suara memiliki tombol "Tampilkan peristiwa tombol terakhir yang diterima layanan", serta baris "Peristiwa terakhir" saat uji tombol. Bila pola tetap gagal, laporkan teks yang tampil.

Pengujian: tools/UjiTombol.kt (kotlinc) lulus semua, termasuk kasus tanpa pengulangan dan peristiwa lepas yang hilang. Belum dikompilasi dengan Gradle dan belum diuji di HP.
