# Tahap 30 — Audit akhir dan penutupan tahapan

Baseline aplikasi tetap `versionName 1.0.68` dan `versionCode 68`.

## Perubahan
- Menambahkan `tools/verify_final.py` untuk menjalankan pemeriksaan statis proyek dan memeriksa kebijakan tanda tangan workflow.
- Workflow `build.yml`: jika keystore tetap tidak disediakan, build masih dapat menghasilkan APK uji dengan kunci debug runner; log memberi peringatan bahwa APK tersebut bukan untuk memperbarui instalasi rilis sebelumnya. Jika keystore diberikan, workflow memvalidasi kredensial dan alias sebelum build.
- Workflow `rilis.yml`: penerbitan GitHub Release dihentikan jika keystore tetap tidak tersedia atau tidak valid. Menghapus fallback keystore dengan kata sandi tetap yang tertanam di workflow. Ini mencegah APK rilis diterbitkan memakai kunci sementara yang berubah di setiap runner.

## Hasil pemeriksaan lokal
- `python3 tools/verify_project.py`: lulus.
- `python3 tools/verify_final.py`: lulus.
- XML manifest divalidasi oleh pemeriksaan proyek.
- Struktur arsip ZIP diuji setelah paket dibuat.

## Hal yang belum dapat diklaim selesai
- Build Gradle penuh belum dijalankan di lingkungan ini karena proyek tidak menyertakan Gradle wrapper dan Gradle lokal tidak tersedia.
- Tidak ada hasil run GitHub Actions dari repositori pengguna yang diperiksa pada tahap ini.
- Belum dilakukan uji perangkat nyata untuk TalkBack/Jieshuo, Jam Bicara ketika layar mati, alarm setelah boot, notifikasi, pengingat salat, DND, dan kompas.
- Sebelum menjalankan workflow `Terbitkan rilis`, pemilik repositori harus menyimpan keystore rilis yang tetap pada GitHub Actions Secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, dan opsional `KEY_PASSWORD`. Jangan mengganti keystore rilis yang telah dipakai untuk versi terpasang jika ingin pembaruan dapat dipasang di atasnya.

Tahap 30 menutup rangkaian pemeriksaan proyek statis, bukan menyatakan seluruh aplikasi sudah teruji atau bebas masalah. Jika build atau pengujian perangkat menemukan kegagalan, lakukan perbaikan lanjutan sebelum menyatakan rilis final.
