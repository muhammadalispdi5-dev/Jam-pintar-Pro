# Audit pengumuman panggilan dan notifikasi pesan — Jam Pintar Pro 1.0.68

## Perubahan kode

- Deteksi panggilan kini menggunakan kategori/metadata CallStyle Android serta jalur cadangan berbasis tombol Jawab/Tolak atau full-screen intent dengan penanda panggilan untuk aplikasi telepon OEM dan WhatsApp.
- Klasifikasi panggilan memeriksa judul notifikasi juga, bukan hanya teks isi, untuk lebih baik membedakan panggilan masuk, panggilan keluar, dan status panggilan berakhir.
- Jika layanan notifikasi tersambung ulang, hanya notifikasi panggilan yang masih aktif diproses; notifikasi pesan lama tidak otomatis dibacakan ulang.
- Jika izin status telepon baru diberikan setelah layanan tersambung, listener mencoba mendaftarkan callback lagi pada notifikasi berikutnya.
- Pengulangan pengumuman panggilan/pesan berhenti saat fitur utama atau fitur nama pemanggil dimatikan.
- Pesan yang masuk melalui MessagingStyle memakai teks pesan terbaru agar ringkasan percakapan tidak dibacakan sebagai gabungan pesan berulang.
- Pada percakapan grup, nama pengirim diambil dari metadata pesan terakhir bila tersedia; judul grup tidak lagi selalu dianggap sebagai nama pengirim.
- Kalimat notifikasi menggunakan template pesan yang tersimpan di Prefs. Template bawaan dilokalkan menurut bahasa pengucapan aktif (Indonesia, Inggris, Arab, Jawa, atau Sunda), dan token `{nama}`, `{grup}`, `{pesan}`, serta `{jenis}` diganti saat pengumuman dibuat.
- Jika metadata pengirim tidak tersedia, notifikasi tidak otomatis dibuang kecuali ada indikator yang lebih kuat bahwa itu balasan/pesan dari perangkat sendiri.

## Pemeriksaan yang dilakukan

- `tools/verify_project.py`: lulus.
- `tools/verify_final.py`: lulus.
- Parsing semua XML di `app/src/main`: lulus.
- Pemeriksaan statis terhadap jalur deteksi panggilan, template pesan, pengirim grup, dan penghentian pengulangan: lulus.
- Versi aplikasi tetap `1.0.68` (`versionCode 68`).

## Batas validasi

Lingkungan kerja ini tidak menyediakan Android SDK/Gradle wrapper yang dapat dipakai untuk membangun APK penuh. Oleh sebab itu belum ada klaim bahwa kompilasi Android penuh atau uji panggilan nyata pada perangkat sudah lulus. Variasi notifikasi OEM dan aplikasi telepon harus diverifikasi melalui APK pada perangkat fisik, dengan izin akses notifikasi dan izin status telepon yang sesuai.
