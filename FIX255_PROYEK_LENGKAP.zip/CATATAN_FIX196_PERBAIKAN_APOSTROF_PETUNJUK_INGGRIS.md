# FIX196 — Gagal kompilasi `:app:mergeDebugResources` / `:app:mergeReleaseResources` (petunjuk penggunaan English)

Versi aplikasi tidak diubah. Basis: FIX195. Berkas diubah: `app/src/main/res/values-en/strings.xml`.

## Kesalahan dari CI
`values-en/strings.xml:82:4: Failed to flatten XML for resource 'isi_petunjuk_penggunaan' ... Invalid unicode escape sequence in string`
(pesan aapt2 untuk apostrof polos; sama dengan FIX132, FIX149, dan FIX184).

## Penyebab
Teks petunjuk penggunaan versi English yang baru memuat empat apostrof ASCII tanpa backslash: "Android's default", "app's display language",
"Android's speech recognizer", dan "service's notification". Versi Indonesia tidak bermasalah.

## Perbaikan
Keempat apostrof diberi backslash (`Android\'s`). Isi kalimat tidak berubah.
`tools/periksa_resource_strings.py` menangkap tepat string ini sebelum perbaikan dan lulus sesudahnya.

## Pemeriksaan
- `tools/periksa_resource_strings.py`: LULUS. Pemeriksaan bahasa aktif dan bentrok anggota Halaman di `verify_project.py`: LULUS.
- `verify_project.py` hanya melaporkan `build.yml` tidak ditemukan karena folder `.github` berada di luar zip proyek; bukan kesalahan kode.
- BELUM dijalankan lewat Gradle/aapt2 (tidak ada Android SDK); build ulang di GitHub Actions diperlukan.

## Bahasa aktif
Hanya penulisan apostrof di resource English; kunci dan kalimat tetap, tidak ada teks baru.
