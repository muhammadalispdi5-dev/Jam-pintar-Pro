# Tahap 27 — Audit bahasa pada deskripsi aksesibilitas kompas

- Deskripsi aksesibilitas jarum arah kiblat kini mengikuti bahasa tampilan aplikasi (Indonesia/Inggris).
- Deskripsi awal dan deskripsi dinamis saat jarum tepat atau masih perlu diputar telah dipisahkan ke fungsi khusus.
- Perubahan ini menyasar label yang dibacakan pembaca layar; tidak mengubah logika perhitungan arah, sensor, atau preferensi bahasa TTS.
- Versi tetap 1.0.68 (`versionCode` 68).
- Pemeriksaan statis dilakukan; build Android penuh dan pengujian TalkBack pada perangkat belum dilakukan.
