# FIX165 - Pilih surah lalu ayat pada Koreksi hafalan dengan suara

## Masalah
Pada koreksi otomatis dengan suara, memilih surah langsung pindah ke ayat 1 dan menutup layar pemilihan, sehingga pengguna tidak sempat memilih nomor ayat.

## Perbaikan
- "Pilih surah, lalu pilih ayat": setelah surah dipilih, muncul pilihan nomor ayat untuk surah itu (awal 1, teks terpilih sehingga mudah diganti). Perpindahan baru terjadi setelah ayat dipilih ("Buka ayat").
- Tombol/gestur Kembali di daftar surah dan di pilihan ayat kembali ke menu "Pilih yang akan dibaca", tidak keluar dari halaman koreksi.
- Nomor ayat tidak valid: pesan ditampilkan dan pilihan ayat dibuka lagi, bukan ditutup.
- Judul pilihan ayat menyebut nama surah yang dipilih. Pemakaian `pilihSurah()` / `pilihAyat()` di pembaca biasa tidak berubah.
- Bahasa aktif: semua teks memakai tr(id, en); pemeriksa bahasa dan resource string lulus.
- Belum dikompilasi dan belum diuji di perangkat. Tidak ada string bersarang di dalam `${...}`.
