# FIX137 - Perintah suara "hidupkan/matikan lokasi" dan "hidupkan/matikan hotspot" kini menekan sakelarnya

Versi aplikasi tidak diubah (1.0.81). Basis: FIX136. Berkas diubah: `PemilihSakelar.kt`, `PanggilanWhatsAppAccessibilityService.kt`, `PerintahSuaraActivity.kt`,
`res/values/strings.xml`, `res/values-en/strings.xml`, `tools/uji_kontrol_wifi_bluetooth.py`.

## Latar
FIX136 membuat Wi-Fi dan Bluetooth ditekan otomatis oleh layanan aksesibilitas yang sudah ada. Lokasi dan hotspot masih hanya membuka layar pengaturan.

## Perubahan (layanan, pemilih, dan izin aksesibilitas yang sama; tanpa fitur ganda)
- Lokasi: halaman Lokasi punya sakelar utama ("Gunakan lokasi"). Pemilih kini mengenal kata location/lokasi/gps dan sengaja TIDAK menekan sakelar
  "pemindaian Wi-Fi/Bluetooth" yang ada di halaman layanan lokasi.
- Hotspot: dua kemungkinan susunan layar ditangani.
  1. Satu langkah (mis. Samsung "Mobile Hotspot"): sakelar langsung ada di halaman Tethering.
  2. Dua langkah (AOSP/Pixel): halaman Tethering hanya berisi baris "Wi-Fi hotspot". Layanan mengetuk baris itu satu kali (hanya baris di dalam daftar,
     bukan judul halaman; Bluetooth/USB/Ethernet tethering ditolak), menunggu halaman sakelar, menekan sakelar, memverifikasi, lalu kembali dua kali.
  Sakelar tunggal tanpa label tidak pernah ditebak untuk hotspot.
- `PerintahSuaraActivity`: lokasi dan hotspot masuk jalur otomatis bila layanan aksesibilitas aktif, dan mencatat jenis serta tahap awal. Tanpa layanan,
  layar dibuka seperti sebelumnya dan petunjuk mengaktifkan layanan diperluas ke keempat perangkat. Data seluler, mode pesawat, dan NFC tidak diubah (tetap manual).
- Pengumuman hasil memakai nama "Lokasi" dan "hotspot seluler" dari sumber daya dua bahasa; deskripsi layanan dan petunjuk diperbarui agar jujur.

## Batas yang perlu diketahui
- Lokasi: sebagian ponsel lama menampilkan dialog persetujuan "akurasi lokasi" saat lokasi dinyalakan. Dialog itu sengaja TIDAK disetujui otomatis; bila muncul,
  verifikasi gagal dan pengguna diminta mengubahnya manual.
- Hotspot: sebagian ponsel/operator membatasi hotspot, atau menampilkan peringatan (mis. Wi-Fi akan dimatikan). Peringatan tidak disetujui otomatis; hasilnya
  pesan "belum dapat diubah otomatis". Mengubah hotspot juga bisa lebih lambat; batas waktu seluruh proses tetap 25 detik.
- Susunan layar Pengaturan berbeda antarmerek; pemilih sengaja konservatif (lebih baik gagal dengan pesan daripada menekan sakelar yang salah).

## Bahasa aktif
Tidak ada string baru selain pembaruan teks yang sudah ada di `values` dan `values-en`; pengumuman tetap lewat `BahasaAplikasi.bungkus`. Pemeriksa bahasa aktif dan resource string lulus.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, `periksa_resource_strings.py`, dan seluruh uji `tools/uji_*.py` lulus. `uji_kontrol_wifi_bluetooth.py` kini berisi port logika
  pemilih dan pemilih baris hotspot diuji pada susunan layar Pixel/Samsung/panel gabungan; kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: aktifkan layanan "Bantuan Panggilan Jam Pintar Pro", lalu ucapkan "matikan/hidupkan lokasi" dan
  "matikan/hidupkan hotspot" (dua bahasa), juga saat sudah dalam keadaan yang diminta. Jika gagal, catat merek, versi Android, dan teks pada layar Hotspot/Lokasi.
