# Perbaikan kompilasi pemeriksaan dukungan kompas — FIX9

Memperbaiki `QiblaActivity.kt` agar label status dukungan dan rincian sensor disiapkan sebagai variabel terpisah, bukan memakai string literal bersarang di dalam interpolasi Kotlin. Ini menghindari error parser Kotlin pada langkah `compileReleaseKotlin`/`compileDebugKotlin` yang dilaporkan di sekitar baris 139, 144, 152, dan 167.

Fitur pemeriksaan sensor, informasi model/perangkat, dan dukungan bahasa Inggris/Indonesia tetap dipertahankan. Perbaikan ini didasarkan pada log kompilasi yang diberikan; kompilasi Android penuh belum dapat dijalankan di lingkungan kerja ini karena Gradle/wrapper tidak tersedia.
