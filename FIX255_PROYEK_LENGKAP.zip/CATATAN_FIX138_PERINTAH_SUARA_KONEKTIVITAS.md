# FIX138 — Penyempurnaan perintah suara untuk data seluler, mode pesawat, dan NFC

## Perubahan
- Perintah suara untuk menghidupkan/mematikan data seluler kini disiapkan untuk dijalankan melalui panel konektivitas resmi Android pada Android 10 ke atas, atau halaman penggunaan data pada versi lebih lama.
- Perintah suara untuk menghidupkan/mematikan mode pesawat diarahkan ke halaman pengaturan mode pesawat.
- Perintah suara untuk menghidupkan/mematikan NFC diarahkan ke panel NFC Android pada Android 10 ke atas, atau halaman NFC pada versi lebih lama.
- Ketiga perangkat tersebut ditambahkan ke antrean otomasi layanan aksesibilitas yang sudah digunakan untuk Wi-Fi, Bluetooth, lokasi, dan hotspot.
- Pemilih sakelar mengenali label Indonesia dan Inggris serta ID tampilan umum. Untuk data seluler, mode pesawat, dan NFC, pemilih tidak menggunakan tebakan sakelar tunggal jika label target tidak ditemukan, demi mencegah perubahan pengaturan yang salah.
- Nama perangkat, status, dan pesan tetap memakai resource bahasa aplikasi (Bahasa Indonesia/English).

## Cara kerja dan batasan Android
Android membatasi aplikasi biasa untuk mengubah beberapa pengaturan konektivitas secara langsung. Karena itu, otomasi ini menggunakan layanan Bantuan Panggilan Jam Pintar Pro yang harus diaktifkan sendiri oleh pengguna pada Setelan Aksesibilitas Android. Jika perangkat/OEM tidak menampilkan sakelar dengan label atau struktur yang dapat dikenali, aplikasi tidak akan menekan sakelar yang tidak pasti; pengguna dapat mengubahnya secara manual.

## Kompatibilitas
- Versi aplikasi, `versionCode`, `versionName`, `minSdk`, `targetSdk`, dan `compileSdk` tidak diubah.
- Tidak menambah izin Android baru.
- Fitur perintah suara lain tetap dipertahankan.
