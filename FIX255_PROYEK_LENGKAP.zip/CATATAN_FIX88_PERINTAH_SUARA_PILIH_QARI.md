# FIX88 — Perintah suara: memilih qari sesuai perintah

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX87. Berkas diubah: `KhatamActivity.kt`, `PerintahSuaraActivity.kt`, `res/values/strings.xml`, `res/values-en/strings.xml`.

## Perintah yang dikenali
- Hanya memilih qari: "pilih qari Alafasy", "ganti qari ke Sudais", "gunakan qari Husary", "pilih qari Abdul Basit mujawwad", "choose reciter Maher Al Muaiqly", "set reciter to Alafasy".
- Qari anak: "pilih qari anak" (qari anak teratas), "pilih qari anak Ahmad Saud", "pilih qari Muhammad Taha", "choose children's reciter".
- Memilih lalu memutar sekaligus: "putar surah Yasin dengan qari Husary", "pilih qari Sudais lalu putar surah 36 ayat 5", "play surah 36 with reciter Alafasy". Bagian nama qari dibuang dari penafsiran surah/ayat agar nama qari (mis. "Abdurrahman") tidak salah dikira nama surah ("Ar Rahman").
- Hanya "qari" tanpa nama: muncul petunjuk menyebut nama. Nama tidak ditemukan: pesan dengan contoh nama.
- Kata "kari/kori" (sering salah dengar dari "qari/qori") hanya dianggap bila ada kata kerja seperti pilih, ganti, gunakan.

## Cara kerja
- Pencocokan nama bersifat fonetik longgar: Misyari = Mishary, Sudaisi = Sudais, Mahir = Maher, Hudzaifi = Hudhaify, Minsyawi = Minshawi, Jibril = Jibreel. Kunci fonetik + jarak edit; nama yang cocok seluruhnya diutamakan, dan nama dua kata ("Muhammad Taha") mengalahkan satu kata ("Muhammad").
- Kumpulan yang dicari: semua qari per ayat (selalu tersedia, mendukung hafalan), qari anak (termasuk Muhammad Taha cadangan), dan qari per surah yang sudah pernah dimuat. Bila ejaan seri (murattal/mujawwad) disebut, varian itu diutamakan. Qari per ayat diutamakan bila orang yang sama ada di dua katalog.
- Qari yang dipilih disimpan sama seperti pemilihan lewat menu, audio yang sedang berbunyi dihentikan, dan muncul toast konfirmasi ("Perintah suara: qari diganti menjadi ...") yang terbaca TalkBack, juga saat perintah datang dari layar depan (FIX87: setelah itu pengguna dikembalikan ke layar depan).
- Penafsir Beritahu Saya (`PerintahSuara`) kini meneruskan ucapan yang memuat "qari/qori/reciter" ke Khatam, jadi perintah ini juga bekerja dari ikon, pintasan, dan widget Beritahu Saya.
- Memilih qari tidak memerlukan teks Al-Qur'an; hanya perintah memutar yang memerlukannya. Tombol "Putar dengan perintah suara" kini dapat dibuka tanpa teks terunduh; petunjuk di layar suara dan pesan perintah tak dikenal menyebut contoh memilih qari.
- Mengikuti saklar "Perintah suara untuk memutar" yang sudah ada.

## Batas
- Qari per surah non-anak (katalog MP3Quran) hanya bisa dipilih lewat suara bila katalog itu pernah dimuat pada sesi aplikasi berjalan (lewat menu Pilih qari); daftar yang disimpan di HP hanya memuat qari anak. Qari per ayat dan qari anak selalu bisa dipilih.
- Nama sangat mirip pada dua qari bisa memilih yang kurang diinginkan; sebut nama lengkap (mis. "Abdul Basit mujawwad").
- Logika pencocokan nama dan pemisahan klausa diuji dengan simulasi terpisah; kode Kotlin BELUM dikompilasi dan BELUM diuji di perangkat (kurung seimbang, XML valid, verify_project lulus).


## Perbaikan jalur penyimpanan (permintaan pengguna)
- Audio yang diunduh kini disimpan per qari di `Jam Pintar Pro/Al-Qur'an/simpan folder audio/<Nama Qari>/`, bukan lagi bercampur dalam folder `Audio`.
- Nama folder qari dibersihkan dari karakter yang tidak valid untuk nama direktori; nama tampilan qari tetap digunakan sejauh aman.
- Cadangan pengaturan menggunakan satu nama tetap `Jam Pintar Pro/Cadangan/Cadangan_Pengaturan.json`. Penulisan menggunakan berkas sementara dan penggantian berkas lama agar cadangan sebelumnya diganti tanpa menghapusnya sebelum berkas baru siap.
- Android 11+ meminta izin Akses semua berkas dan melanjutkan pencadangan otomatis setelah pengguna kembali dari Pengaturan. Android 7–9 meminta izin penyimpanan. Android 10 memakai lokasi kompatibel `Download/Jam Pintar Pro/Cadangan/` karena pembatasan scoped storage Android 10 tidak mengizinkan penulisan langsung ke folder akar.
- Pesan bantuan dan status pencadangan tersedia dalam bahasa Indonesia dan Inggris mengikuti bahasa aplikasi.
- Pemulihan cadangan dari berkas pilihan pengguna tetap dipertahankan.
- Build Gradle tidak dapat dijalankan di lingkungan pemeriksaan ini; proyek perlu dikompilasi melalui GitHub Actions.

## V6 — Pemutaran perintah suara tanpa menampilkan layar Khatam
- Perintah suara Al-Qur'an dari layar depan sekarang meluncurkan Khatam dengan tema jendela transparan khusus.
- Konten halaman Khatam disembunyikan sebelum frame pertama ditampilkan, sehingga layar aplikasi tidak muncul/berkedip saat perintah suara diproses.
- Pemutaran tetap memakai sesi audio Khatam yang ada dan dijaga oleh `AudioLatarService`; setelah proses dimulai, task aplikasi dikirim ke belakang seperti sebelumnya.
- Perintah suara yang berasal dari dalam aplikasi tetap memakai tampilan Khatam normal.
- Tidak menambah teks antarmuka baru; notifikasi layanan tetap mengikuti bahasa aktif melalui `BahasaAplikasi`.
