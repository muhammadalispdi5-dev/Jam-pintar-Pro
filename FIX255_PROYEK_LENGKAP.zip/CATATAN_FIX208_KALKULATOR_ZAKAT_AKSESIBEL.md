# FIX208 — Penambahan Kalkulator Zakat Aksesibel

## Perubahan
- Menambahkan menu Kalkulator Zakat pada halaman utama Jam Pintar Pro.
- Menambahkan halaman KalkulatorZakatActivity dan mendaftarkannya di AndroidManifest.
- Menyediakan tujuh jenis perhitungan: emas/perak, tabungan/uang, perdagangan, pertanian, fitrah, penghasilan/profesi, serta peternakan kambing/domba, sapi/kerbau, dan unta.
- Menambahkan pemeriksaan input, hasil terperinci, pengumuman hasil untuk pembaca layar, penyimpanan riwayat lokal, serta fungsi melihat dan menghapus riwayat.
- Seluruh teks fitur memakai bahasa tampilan aktif aplikasi: Indonesia atau English. Petunjuk penggunaan diperbarui untuk mencakup peternakan dalam kedua bahasa.
- Memperbarui petunjuk penggunaan pada kedua bahasa.

## Acuan dan asumsi yang ditampilkan kepada pengguna
- Emas: nisab referensi 85 gram; perak: 595 gram; tarif 2,5% setelah haul.
- Tabungan dan perdagangan: nisab setara 85 gram emas; tarif 2,5% setelah haul.
- Pertanian: nisab referensi 653 kg gabah; tarif 10% (alami), 5% (irigasi berbiaya), atau 7,5% (campuran).
- Fitrah: acuan 2,5 kg beras per jiwa; nilai uang dihitung dari harga beras per kilogram yang dimasukkan pengguna.
- Penghasilan: nisab tahunan setara 85 gram emas atau 1/12 untuk metode bulanan; tarif 2,5%.

Harga emas/perak dan beras dimasukkan manual oleh pengguna, tidak diklaim sebagai harga terkini otomatis. Nilai nisab serta metode dapat mengikuti ketentuan lembaga zakat/ulama setempat. Hasil adalah estimasi, bukan fatwa. Zakat peternakan belum dimasukkan pada tahap ini karena memerlukan tabel nisab dan ketentuan terperinci per jenis hewan.

## Aksesibilitas
- Label formulir dihubungkan dengan kolom masukan melalui `labelFor`.
- Tombol memakai nama aksesibilitas yang jelas.
- Hasil perhitungan dapat diumumkan ulang melalui layanan aksesibilitas Android.
- Navigasi menggunakan kontrol Android standar dan tombol kembali halaman dari kelas dasar aplikasi.

## Pemeriksaan
- Berkas XML strings dan AndroidManifest berhasil diparsing.
- Struktur sumber ZIP dipertahankan dan semua entri akan diverifikasi setelah pengemasan.
- Kompilasi APK belum dijalankan di lingkungan ini karena Gradle wrapper dan Android SDK tidak tersedia.


## Catatan khusus zakat peternakan
- Kalkulator ini menerapkan acuan fikih umum untuk ternak gembalaan yang memenuhi haul; hewan yang mayoritas dipelihara dengan pakan beli/intensif tidak dihitung otomatis dengan skema ternak gembalaan.
- Untuk sapi/kerbau, hasil berupa kombinasi tabi' (umur satu tahun) dan musinnah (umur dua tahun) berdasarkan kelompok 30 dan 40 ekor.
- Untuk kambing/domba, acuan jumlah: 40–120 = 1; 121–200 = 2; 201–399 = 3; mulai 400 = 1 setiap 100 ekor.
- Untuk unta, tabel yang ditampilkan mencakup 5–120 ekor. Di atas 120, pengguna diarahkan berkonsultasi dengan amil karena penentuan kategori umur dan kombinasi 40/50 memerlukan tabel terperinci.
- Ternak untuk tujuan perdagangan dapat mengikuti perhitungan zakat perdagangan. Hasil bukan fatwa; verifikasi umur, jenis kelamin, kondisi, dan panduan lembaga zakat setempat.
