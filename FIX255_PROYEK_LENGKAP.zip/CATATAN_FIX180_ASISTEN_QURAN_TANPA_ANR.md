# FIX180 — Pemutaran Al-Qur'an lebih responsif

## Tujuan
Mengurangi risiko Android menampilkan "Jam Pintar Pro tidak menanggapi" setelah perintah pemutaran Al-Qur'an, sekaligus mengurangi pencarian ulang audio lokal.

## Perubahan
1. Pemindaian direktori, MediaStore, dan SAF untuk indeks audio dilakukan oleh satu thread latar khusus, bukan thread utama Android.
2. Penyusunan playlist di thread utama hanya membaca cache; fungsi pencarian lokal tidak lagi melakukan pemindaian penyimpanan secara langsung.
3. Cache indeks dipertahankan pada tingkat proses aplikasi, sehingga tetap tersedia ketika PemutarQuranService selesai dan dibuat kembali untuk perintah berikutnya.
4. Pencarian berkas pada folder langsung dipersempit ke folder qari, `Audio Per Surah`, dan folder ayat untuk nomor surah yang diminta; tidak lagi menelusuri seluruh pohon direktori secara rekursif.
5. MediaStore Downloads diperiksa lebih dahulu. Koleksi Audio dan Files hanya menjadi cadangan bila Downloads tidak menemukan berkas.
6. Permintaan pemutaran yang lebih baru membatalkan hasil permintaan lama yang belum selesai; perintah jeda/lanjut/berhenti juga membatalkan pemutaran yang masih dalam tahap pencarian.
7. Pemutar MediaPlayer dan perubahan status layanan tetap dijalankan melalui alur utama yang sudah ada.

## Batasan pengujian
- `versionCode=82` dan `versionName=1.0.82` dipertahankan.
- Tidak mengubah kode asisten waktu, jadwal salat, atau aturan bahasa aktif.
- Pemeriksaan sumber dilakukan; kompilasi Gradle Android dan uji perangkat belum dapat dilakukan di lingkungan ini karena arsip tidak menyertakan `gradlew` dan Gradle tidak tersedia. Karena itu FIX180 belum boleh dianggap teruji di perangkat.
- Jika audio disimpan melalui folder SAF khusus, pemindaian SAF masih dapat memerlukan waktu; tetapi pemindaian tersebut kini berjalan di thread latar sehingga tidak semestinya membekukan thread utama aplikasi.
