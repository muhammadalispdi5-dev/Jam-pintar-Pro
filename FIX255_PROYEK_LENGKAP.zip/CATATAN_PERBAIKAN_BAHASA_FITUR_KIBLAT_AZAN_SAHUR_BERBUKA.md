# Catatan perbaikan bahasa — Jam Pintar Pro 1.0.68

Perbaikan terfokus pada:
- Qibla Direction and Compass: terjemahan label dan panduan arah mengikuti bahasa tampilan, termasuk ucapan ketika jarum tepat mengarah ke kiblat.
- Adhan Sound and Sound Test: label, pilihan sumber suara, kontrol tes, serta judul notifikasi.
- Suhoor and Iftar Reminders: judul, sakelar, pilihan waktu, pemilihan berkas suara, status, dan judul serta isi notifikasi mengikuti bahasa tampilan. Bahasa pesan TTS tetap mengikuti pilihan bahasa ucapan yang terpisah.
- Pemetaan BahasaAplikasi ditambah untuk teks yang dibangun langsung oleh kode.

Validasi yang dilakukan: XML resource diparsing; arsip proyek dibuat dan diuji. Build APK Android penuh dan pengujian UI pada perangkat belum dijalankan, sehingga perlu verifikasi melalui GitHub Actions dan perangkat.
Versi aplikasi dipertahankan 1.0.68.
