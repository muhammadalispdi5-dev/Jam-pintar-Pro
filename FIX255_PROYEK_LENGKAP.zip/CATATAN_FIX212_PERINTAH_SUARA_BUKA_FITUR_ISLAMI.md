# FIX212: perintah suara membuka fitur pustaka Islami

PerintahSuaraActivity.kt: enum Fitur ditambah HADITS, KHUTBAH, MANASIK_HAJI, KALKULATOR_ZAKAT; bukaFitur membuka HaditsActivity, KhutbahJumatActivity, ManasikHajiActivity, KalkulatorZakatActivity.
Kata kunci (Indonesia dan English) diperiksa paling awal agar "panduan manasik haji dan doa-doanya" tidak salah dibuka sebagai fitur Doa.
Contoh: "buka kitab hadits shahih", "buka hadits Bukhari / Muslim / Arbain Nawawi / Riyadhus Shalihin", "buka himpunan khutbah Jumat pilihan",
"buka panduan manasik haji dan doa-doanya", "buka kalkulator zakat". Menyebut nama fitur saja (maks 6 kata) tanpa kata "buka" juga membuka fitur.
Teks petunjuk (values dan values-en) memuat contoh perintah baru. Belum dikompilasi dan belum diuji di perangkat.
