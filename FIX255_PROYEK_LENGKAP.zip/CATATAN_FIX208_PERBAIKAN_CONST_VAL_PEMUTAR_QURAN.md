# FIX208 — Gagal kompilasi `:app:compileReleaseKotlin` / `:app:compileDebugKotlin` (const val)

Versi aplikasi tidak diubah (1.0.85). Basis: FIX207. Berkas diubah: `PemutarQuranService.kt`, `tools/verify_project.py`. Baru: `tools/periksa_const_val.py`.

## Kesalahan dari CI
`PemutarQuranService.kt:1468:49 Const 'val' initializer must be a constant value.`

## Temuan
Baris itu pada arsip FIX207 adalah `private const val URL_DASAR_TERJEMAHAN_ID = "https://archive.org/download/quraninindonesia/"` di dalam
`object PenafsirQuran`. Di arsip ini isinya literal murni (tanpa templat `$`), jadi saya tidak dapat mereproduksi kesalahan itu tanpa kompiler Kotlin.
Perlu dicatat: nomor baris log CI pernah berbeda dari arsip (FIX132), sehingga berkas di repositori bisa saja memuat versi baris itu yang berbeda.

## Perbaikan
- `URL_DASAR_TERJEMAHAN_ID` diubah dari `private const val` menjadi `private val` (sama seperti padanannya di `KhatamActivity.kt`). Nilai ini hanya dipakai
  saat aplikasi berjalan (menyusun alamat berkas MP3), tidak pada anotasi atau konstanta kompilasi, sehingga syarat `const` tidak diperlukan dan
  kesalahan di baris itu tidak dapat terjadi lagi, apa pun isi inisialisasinya.
- Pencegahan: `tools/periksa_const_val.py` memeriksa semua `const val` dan gagal bila inisialisasinya bukan konstanta kompilasi (templat `$nama`,
  pemanggilan fungsi, rujukan ke variabel biasa). Dihubungkan ke `tools/verify_project.py`. Uji pada contoh: 3 `const val` benar lulus
  (literal URL `https://...`, aritmetika literal, penggabungan dua literal) dan 4 yang salah tertangkap tepat (penggabungan dengan variabel,
  templat string, kurung dengan variabel, `String.format`). Uji pertama menemukan cacat pada pemeriksa itu sendiri: komentar `//` dibaca
  di dalam string sehingga alamat `https://...` salah dilaporkan; sudah diperbaiki (komentar hanya dibuang di luar tanda kutip).
  Pada arsip ini: LULUS.

## Pemeriksaan
- `tools/periksa_const_val.py`, bahasa aktif, resource string, bentrok anggota Halaman: LULUS.
- `verify_project.py` hanya melaporkan `build.yml` tidak ditemukan (folder `.github` di luar zip).
- BELUM dikompilasi (tidak ada Kotlin/Android SDK di sini). Bila build ulang masih menunjuk `const val` di tempat lain, kirim log barunya.

## Bahasa aktif
Tidak ada teks tampilan yang berubah; hanya modifier pada satu konstanta URL dan alat pemeriksa.
