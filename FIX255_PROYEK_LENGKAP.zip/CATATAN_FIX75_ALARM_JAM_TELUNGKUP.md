# FIX75 — Alarm pada Fitur Jam, Dapat Dihentikan dengan Menelungkupkan HP

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX74 (telungkup menghentikan semua notifikasi).

## Fitur baru: Jam > Alarm jam
- Pengguna dapat membuat hingga 20 alarm. Tiap alarm punya: waktu, hari berulang (tanpa hari = sekali lalu mati sendiri), nama, jenis suara, tunda (tanpa/5/10/15 menit), getar, dan sakelar aktif.
- Jenis suara: (0) nada alarm sistem berulang lewat saluran Alarm; (1) bip + ucapan waktu dan nama alarm tiap 9 detik memakai pengaturan suara Jam; (2) nada 5 detik lalu ucapan, bergantian. Bila Mode Acara aktif, ucapan ditahan dan alarm berbunyi sebagai nada agar tidak senyap.
- Halaman alarm menampilkan "Alarm berikutnya", daftar alarm (sakelar aktif/mati + tombol Ubah), tombol Tambah alarm, serta editor dengan tombol Tes alarm dan Hapus. Perubahan langsung tersimpan dan dijadwalkan ulang.
- Penjadwalan memakai `AlarmManager.setAlarmClock` (tepat waktu, tembus Doze, tidak butuh izin alarm tepat waktu). Setelah boot, pembaruan aplikasi, atau perubahan waktu/zona waktu, `BootReceiver` memasang ulang semua alarm dan alarm tunda.

## Telungkup menghentikan alarm
- `AlarmJamService` mendaftar ke `PembungkamTelungkup` (kunci `alarm_jam`) selama alarm berbunyi, persis seperti notifikasi lain di FIX74: sensor hanya menyala selama alarm berbunyi; aturan gerakan sama (HP harus terdeteksi tidak telungkup dahulu, lalu telungkup datar sekitar 0,65 detik).
- Telungkup = matikan (bukan tunda). Nada, ucapan, getar, penahan CPU, dan layanan ditutup.
- Sakelar "Hentikan alarm dengan menelungkupkan HP" di halaman alarm adalah sakelar yang sama dengan di Pengaturan Sholat (`stop_azan_face_down`, bawaan aktif).
- Cara lain tetap ada: tombol Matikan dan Tunda pada notifikasi. Alarm berhenti sendiri setelah 3 menit dan meninggalkan notifikasi "Alarm terlewat".
- Tes alarm di editor juga dapat dihentikan dengan telungkup dan memiliki tombol Matikan (tanpa Tunda).

## Berkas
Baru: `AlarmJam.kt` (model, penyimpanan JSON "alarm_jam", penjadwalan, tunda), `AlarmJamReceiver.kt`, `AlarmJamService.kt`.
Diubah: `JamActivity.kt` (tombol Alarm jam, halaman daftar dan editor), `BootReceiver.kt`, `AndroidManifest.xml` (service dan receiver baru).

## Pemeriksaan dan batas
- `tools/verify_project.py` dijalankan; kurung `{}` `()` `[]` seimbang di semua berkas yang diubah.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: alarm sekali dan berulang, tunda, telungkup saat layar mati, boot ulang, Doze, dan Android 13+ (izin notifikasi).
- Alarm sistem memakai volume Alarm HP; jika volume itu nol, nada tidak terdengar. Ucapan memakai saluran volume pada pengaturan suara Jam.
- Beberapa merek HP (Xiaomi, OPPO, Vivo, dsb.) dapat menunda aplikasi di latar belakang; gunakan halaman izin perangkat aplikasi agar alarm dapat berbunyi.
