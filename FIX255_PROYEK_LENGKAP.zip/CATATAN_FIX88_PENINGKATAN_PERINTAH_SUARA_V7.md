# FIX88 V7 — Jawaban perintah suara yang spesifik

## Perubahan
- Perintah tanggal Masehi menghasilkan hanya tanggal Masehi.
- Perintah tanggal Hijriah menghasilkan hanya tanggal Hijriah, memakai koreksi/sinkronisasi Hijriah yang tersimpan.
- Perintah informasi hari libur menghasilkan ringkasan libur nasional dan cuti bersama saja.
- Perintah waktu salat berikutnya menghasilkan hanya satu informasi jadwal salat berikutnya; tidak lagi bergantung pada sakelar pengumuman otomatis, tetapi tetap memerlukan lokasi/jadwal salat yang telah disetel.
- Pengenalan sasaran spesifik diprioritaskan sebelum kata umum seperti “hari”, sehingga “hari libur” tidak salah ditafsirkan sebagai tanggal.
- Pesan ketika data tidak tersedia disediakan dalam bahasa aplikasi (Indonesia, Inggris, Arab, Jawa, dan Sunda).
- Perintah umum waktu/tanggal, perintah Al-Qur'an, dan pemilihan qari tetap dipertahankan.

## Contoh perintah
- “Sebutkan tanggal Masehi.”
- “Bacakan tanggal Hijriah.”
- “Berikan informasi hari libur.”
- “Kapan waktu salat berikutnya?”
- “Jam berapa sekarang?”
- “Putar surah Al-Baqarah.”

## Pemeriksaan
- `tools/verify_project.py`: lulus.
- Arsip ZIP: diperiksa setelah dibuat.
- Kompilasi Gradle/APK dan pengujian pengenalan suara di perangkat belum dijalankan di lingkungan ini.
