# FIX144 — Mode hafalan dan audio terjemahan di pemutar latar

Perubahan pada `KhatamActivity.kt`:

1. Menambahkan akses langsung **Mode hafalan dan pengulangan ayat** di menu Pengaturan Pemutaran Audio. Pilihan mode yang sudah ada (biasa, ulang ayat pilihan, berurutan, dan kelompok ayat) tetap menggunakan penyimpanan preferensi yang sama sehingga setelan lama dipertahankan.
2. Saat Activity masuk ke latar belakang (`onStop`), jika audio sedang dimuat atau diputar, aplikasi memulai `AudioLatarService`. Ini mencakup murattal biasa, transisi/jeda mode hafalan, dan rekaman audio terjemahan Indonesia.
3. Ketika mode hafalan aktif tetapi pengguna memilih audio terjemahan Indonesia, aplikasi memberi keterangan bahwa rekaman terjemahan tersedia per surah penuh dan bukan per ayat. Tidak mengubah atau memotong berkas sumber.
4. Semua teks baru menggunakan pasangan `tr(Indonesia, English)` mengikuti bahasa aktif aplikasi.
5. Pemilihan Stereo/Mono, equalizer, kecepatan, sumber audio, dan fitur lain tidak diubah.

Catatan batasan: layanan latar depan menjaga proses Activity/pemutar yang sudah berjalan; Android tetap dapat menghentikan proses jika sistem kehabisan sumber daya atau pengguna melakukan force-stop. Audio terjemahan komunitas memerlukan koneksi internet kecuali sudah ada salinan lokal yang dikelola fitur lain.

Kompilasi APK belum dijalankan di lingkungan ini.
