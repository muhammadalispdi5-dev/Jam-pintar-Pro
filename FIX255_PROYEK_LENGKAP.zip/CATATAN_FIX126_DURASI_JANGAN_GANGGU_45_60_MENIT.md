# FIX126 — Durasi Mode Jangan Ganggu: Tambah 45 dan 60 Menit

Versi aplikasi: **1.0.77** (versionCode 77). Basis: FIX125.

## Perubahan
Pilihan **Durasi Mode Jangan Ganggu** (Pengaturan Sholat > Mode Jangan Ganggu saat sholat) kini: **5, 10, 15, 30, 45, dan 60 menit** (sebelumnya hanya 5, 10, 15, 30).

- `PrayerPrefs.kt`: daftar durasi dipusatkan pada `PrayerPrefs.DURASI_DND_MENIT`. Pembacaan dan penyimpanan `dndDuration` kini memvalidasi terhadap daftar ini. Sebelumnya nilai 45 atau 60 akan ditolak diam-diam dan dikembalikan ke 10 menit walau layar pengaturan menampilkannya.
- `PrayerSettingsActivity.kt`: daftar pilihan dan indeks terpilih dibangun dari daftar yang sama, sehingga layar dan penyimpanan tidak mungkin berbeda lagi.
- Nilai tersimpan lama (5, 10, 15, atau 30) tetap berlaku; bawaan tetap 10 menit.
- Pemulihan otomatis Mode Jangan Ganggu memakai batas waktu absolut (`prayer_dnd_active_until`) dan alarm pemulihan sendiri, jadi 45 dan 60 menit tidak memerlukan perubahan lain. Sudah diperiksa bahwa tidak ada batas maksimum 30 menit di kode pemulihan.

## Tidak diubah
- Pengingat sebelum salat (5/10/15/30 menit sebelum waktu salat) adalah pengaturan berbeda dan tidak diubah.
- Durasi pada fitur **Mode Acara** adalah pengaturan berbeda dan tidak diubah.

## Pemeriksaan dan batas
- `tools/verify_project.py` dan `tools/periksa_bahasa_aktif.py`: LULUS; kurung seimbang. Terjemahan Inggris memakai aturan umum "menit" menjadi "minutes". BELUM dikompilasi dan BELUM diuji di perangkat.
