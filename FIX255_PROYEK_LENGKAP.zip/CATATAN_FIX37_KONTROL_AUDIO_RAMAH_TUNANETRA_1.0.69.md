# FIX37 — Penyederhanaan Kontrol Audio dan Aksesibilitas

Versi aplikasi dipertahankan: `versionCode 69`, `versionName 1.0.69`.

## Perubahan
- Kontrol audio di pembaca disederhanakan menjadi Putar/Lanjutkan, Jeda/Lanjutkan, Percepat/Perlambat, dan Hentikan dalam satu kelompok.
- Tombol Putar menggunakan rentang pemutaran yang telah dipilih; tidak lagi membuka menu berisi pilihan qari, juz, surah, dan ayat.
- Rentang pemutaran (per ayat, per surah, per juz) dipindahkan ke Pengaturan Audio dan disimpan sebagai preferensi.
- Tombol Putar/Lanjutkan meneruskan audio yang sedang dijeda, jika pemutar masih tersedia.
- Kecepatan dapat diganti langsung melalui tombol kontrol tanpa menghentikan audio; pilihan tetap tersedia melalui Pengaturan Audio.
- Pencarian juz/surah/ayat tetap tersedia sebagai alat bantu navigasi terpisah.
- Status audio diumumkan melalui `announceForAccessibility` agar pembaca layar mengetahui perubahan status.

## Batasan dan pemeriksaan
- Pemeriksaan statis `tools/verify_project.py`: LULUS.
- Versi aplikasi terverifikasi tetap 1.0.69 / versionCode 69.
- Arsip ZIP diperiksa setelah dibuat.
- Kompilasi Gradle belum dapat dijalankan pada lingkungan ini karena executable `gradle` dan Gradle wrapper tidak tersedia.
- Pengujian TalkBack dan pemutaran pada perangkat Android masih perlu dilakukan.

## Catatan perilaku
- Mode per juz memerlukan qari yang mendukung audio per ayat. Jika qari yang dipilih hanya menyediakan audio per surah, aplikasi akan menampilkan pemberitahuan sesuai pemeriksaan yang sudah ada.
- Mode per surah memutar surah yang sedang dipilih pada pembaca. Mode per ayat memutar ayat yang sedang dipilih.
