package com.novan.bateraibicara

import android.content.Context
import android.os.Build

/** Nomor tujuan dan penyusun isi pesan untuk chat dengan pengembang lewat WhatsApp. */
object KeluhanPesan {

    /** Nomor pengembang (hanya angka, format internasional); kosong bila belum diatur. */
    fun nomor(): String {
        var n = (if (BuildConfig.WHATSAPP_NUMBER.isNotBlank()) BuildConfig.WHATSAPP_NUMBER else AppKonfigurasi.NOMOR_WHATSAPP)
            .filter { it.isDigit() }
        if (n.startsWith("0")) n = "62" + n.substring(1)
        return n
    }

    fun terkonfigurasi(): Boolean = nomor().length >= 8

    fun susun(c: Context, kategori: String, pesan: String, sertakanInfo: Boolean): String {
        val sb = StringBuilder()
        sb.append("[").append(kategori).append("] Jam Pintar Pro ").append(UpdateManager.namaVersi(c)).append('\n')
        if (sertakanInfo) {
            sb.append("Perangkat: ").append(PerangkatIzin.namaPerangkat())
                .append(", Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        }
        sb.append('\n').append(pesan.trim())
        return sb.toString().take(1500)
    }
}
