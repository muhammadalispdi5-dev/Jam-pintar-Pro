package com.novan.bateraibicara

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * FIX247: pemandu perizinan dasar. Saat aplikasi pertama kali dijalankan (dan diingatkan lagi paling sering sekali sehari
 * selama masih ada izin penting yang belum diberikan), pengguna dibawa satu per satu ke setiap izin: dialog izin sistem untuk
 * notifikasi, lokasi, mikrofon, telepon, dan kontak; lalu layar pengaturan khusus untuk alarm tepat waktu, bebas hemat baterai,
 * tampil di atas aplikasi lain, akses notifikasi, dan Jangan Ganggu; terakhir pengaturan khusus merek HP.
 * Setiap langkah bisa dilewati, dan ada tombol untuk berhenti diingatkan.
 */
class PemanduIzinAwal(private val a: Activity, private val tr: (String, String) -> String) {

    private class Langkah(
        val judul: String,
        val isi: String,
        val penting: Boolean,
        val sudah: () -> Boolean,
        val buka: () -> Unit,
        val lewatiSetelahBuka: Boolean = false,
        val layarPengaturan: Boolean = true
    )

    private val pref get() = a.getSharedPreferences("panduan_aplikasi", Activity.MODE_PRIVATE)
    private var antre = ArrayList<Langkah>()
    private var menunggu = false
    private var dialog: AlertDialog? = null

    companion object {
        const val KODE = 21
        private const val SEHARI = 24L * 60L * 60L * 1000L
    }

    private fun izinRuntime(): List<String> {
        val d = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) d.add(Manifest.permission.POST_NOTIFICATIONS)
        d.add(Manifest.permission.ACCESS_FINE_LOCATION)
        d.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        d.add(Manifest.permission.RECORD_AUDIO)
        d.add(Manifest.permission.READ_PHONE_STATE)
        d.add(Manifest.permission.READ_CONTACTS)
        d.add(Manifest.permission.CALL_PHONE)
        return d
    }

    private fun izinRuntimeKurang(): Array<String> =
        izinRuntime().filter { a.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()

    private fun semuaLangkah(): List<Langkah> {
        val l = ArrayList<Langkah>()
        if (Build.VERSION.SDK_INT >= 23) {
            l.add(Langkah(
                tr("Izin dasar aplikasi", "Basic app permissions"),
                tr("Aplikasi membutuhkan beberapa izin agar berfungsi penuh: notifikasi untuk pengingat dan azan, lokasi untuk jadwal sholat, arah kiblat, dan cuaca, mikrofon untuk perintah suara, telepon dan kontak untuk membacakan nama penelepon. Setelah Anda ketuk Lanjutkan, sistem akan menampilkan beberapa pertanyaan izin berturut-turut; pilih Izinkan pada setiap pertanyaan.",
                   "The app needs a few permissions to work fully: notifications for reminders and the adhan, location for prayer times, qibla and weather, microphone for voice commands, phone and contacts to announce caller names. After you tap Continue, the system shows several permission questions in a row; choose Allow on each."),
                true,
                { izinRuntimeKurang().isEmpty() },
                { a.requestPermissions(izinRuntimeKurang(), KODE) },
                false, false
            ))
        }
        l.add(Langkah(
            tr("Notifikasi aplikasi", "App notifications"),
            tr("Notifikasi aplikasi ini sedang dimatikan di pengaturan sistem, sehingga pengingat dan azan tidak akan muncul. Aktifkan notifikasi pada layar berikut.",
               "Notifications for this app are turned off in system settings, so reminders and the adhan will not appear. Turn notifications on in the next screen."),
            true,
            { PerangkatIzin.notifikasiAktif(a) },
            { if (!PerangkatIzin.bukaNotifikasi(a)) PerangkatIzin.bukaInfoAplikasi(a) }
        ))
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Langkah(
                tr("Alarm tepat waktu", "Exact alarms"),
                tr("Agar azan, pengingat sholat, dan alarm berbunyi tepat pada waktunya, aktifkan Alarm dan pengingat pada layar berikut.",
                   "So that the adhan, prayer reminders and alarms ring exactly on time, turn on Alarms and reminders in the next screen."),
                true,
                { PerangkatIzin.alarmTepatWaktu(a) },
                { PerangkatIzin.bukaAlarmTepat(a) }
            ))
        }
        l.add(Langkah(
            tr("Bebas hemat baterai", "Unrestricted battery use"),
            tr("Agar aplikasi tidak dihentikan sistem saat layar mati, izinkan aplikasi berjalan tanpa pembatasan baterai. Pilih Izinkan atau Tanpa batasan pada layar berikut.",
               "So the system does not stop the app while the screen is off, let the app run without battery restrictions. Choose Allow or Unrestricted in the next screen."),
            true,
            { PerangkatIzin.abaikanBaterai(a) },
            { PerangkatIzin.bukaAbaikanBaterai(a) }
        ))
        l.add(Langkah(
            tr("Tampil di atas aplikasi lain", "Display over other apps"),
            tr("Izin ini membantu layar alarm dan pengumuman muncul saat aplikasi lain sedang dipakai. Aktifkan pada layar berikut.",
               "This permission lets alarm and announcement screens appear while other apps are in use. Turn it on in the next screen."),
            true,
            { PerangkatIzin.tampilDiAtas(a) },
            { PerangkatIzin.bukaTampilDiAtas(a) }
        ))
        l.add(Langkah(
            tr("Akses notifikasi", "Notification access"),
            tr("Agar aplikasi dapat membacakan notifikasi aplikasi lain dan nama penelepon, aktifkan akses notifikasi untuk Jam Pintar Pro pada layar berikut.",
               "So the app can read out other apps' notifications and caller names, turn on notification access for Jam Pintar Pro in the next screen."),
            true,
            { PerangkatIzin.aksesNotifikasi(a) },
            { PerangkatIzin.bukaAksesNotifikasi(a) }
        ))
        l.add(Langkah(
            tr("Jangan Ganggu", "Do Not Disturb"),
            tr("Agar ponsel dapat diatur senyap otomatis saat waktu sholat, izinkan akses Jangan Ganggu untuk aplikasi ini pada layar berikut.",
               "So the phone can be silenced automatically at prayer times, allow Do Not Disturb access for this app in the next screen."),
            true,
            { PerangkatIzin.janganGanggu(a) },
            { PerangkatIzin.bukaJanganGanggu(a) }
        ))
        l.add(Langkah(
            tr("Pengaturan khusus merek ponsel", "Phone-brand specific settings"),
            tr("Sebagian merek ponsel punya pengaturan tambahan seperti Mulai otomatis dan Hemat baterai merek. Buka layar panduannya agar aplikasi tidak dimatikan sistem.",
               "Some phone brands have extra settings such as Autostart and brand battery saver. Open the guide screen so the system does not kill the app."),
            false,
            { pref.getBoolean("pengingat_izin_perangkat_tampil", false) },
            { pref.edit().putBoolean("pengingat_izin_perangkat_tampil", true).apply(); a.startActivity(Intent(a, IzinPerangkatActivity::class.java)) },
            true
        ))
        return l
    }

    private fun adaIzinPentingKurang(): Boolean = semuaLangkah().any { it.penting && !it.sudah() }

    /** Dipanggil pertama kali setelah petunjuk awal ditutup: selalu menawarkan semua izin yang belum diberikan. */
    fun mulai() {
        antre = ArrayList(semuaLangkah())
        pref.edit().putLong("izin_awal_terakhir", System.currentTimeMillis()).apply()
        lanjut()
    }

    /** Dipanggil tiap aplikasi dibuka: menawarkan lagi paling sering sekali sehari bila masih ada izin penting yang kurang. */
    fun mulaiBerkala() {
        if (pref.getBoolean("izin_awal_berhenti", false)) return
        if (dialog?.isShowing == true || menunggu) return
        val selesaiAwal = pref.getBoolean("izin_awal_selesai", false)
        val terakhir = pref.getLong("izin_awal_terakhir", 0L)
        val sekarang = System.currentTimeMillis()
        if (selesaiAwal && sekarang - terakhir < SEHARI) return
        if (selesaiAwal && !adaIzinPentingKurang()) return
        mulai()
    }

    /** Dipanggil dari onResume: setelah pengguna kembali dari layar pengaturan, lanjut ke izin berikutnya. */
    fun lanjutJikaMenunggu() {
        if (!menunggu) return
        menunggu = false
        lanjut()
    }

    /** Dipanggil dari onRequestPermissionsResult untuk kode [KODE]. */
    fun hasilIzinRuntime() {
        menunggu = false
        lanjut()
    }

    private fun lanjut() {
        if (a.isFinishing || a.isDestroyed) return
        if (dialog?.isShowing == true) return
        while (antre.isNotEmpty()) {
            val l = antre.removeAt(0)
            if (l.sudah()) continue
            tampilkan(l)
            return
        }
        pref.edit().putBoolean("izin_awal_selesai", true).apply()
    }

    private fun tampilkan(l: Langkah) {
        val b = AlertDialog.Builder(a)
            .setTitle(l.judul)
            .setMessage(l.isi)
            .setPositiveButton(tr("Lanjutkan", "Continue")) { d, _ ->
                d.dismiss()
                menunggu = l.layarPengaturan && !l.lewatiSetelahBuka
                try { l.buka() } catch (_: Exception) { menunggu = false; lanjut() }
                if (l.lewatiSetelahBuka) { menunggu = false; lanjut() }
            }
            .setNegativeButton(tr("Lewati", "Skip")) { d, _ -> d.dismiss(); lanjut() }
            .setNeutralButton(tr("Jangan ingatkan lagi", "Stop reminding me")) { d, _ ->
                d.dismiss()
                antre.clear()
                pref.edit().putBoolean("izin_awal_berhenti", true).putBoolean("izin_awal_selesai", true).apply()
            }
        dialog = b.create().also { it.setCancelable(false); it.show() }
    }
}
