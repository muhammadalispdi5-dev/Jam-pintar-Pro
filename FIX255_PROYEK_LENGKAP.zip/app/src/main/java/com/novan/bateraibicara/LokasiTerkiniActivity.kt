package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.location.Address
import android.location.Geocoder
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Membacakan lokasi GPS terkini dengan kontrol yang dapat dijelajahi pembaca layar. */
class LokasiTerkiniActivity : Halaman() {
    override val judulHalaman = R.string.judul_lokasi_terkini

    private lateinit var status: android.widget.TextView
    private var lokasiTerakhir: Location? = null
    private var namaLokasiTerakhir: String? = null
    private var sedangMencari = false
    private var adaFixLangsung = false
    private var jumlahFixAkurat = 0
    private var waktuFixAkuratPertama = 0L
    private var waktuFixTerakhir = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val timeoutHandler = Handler(Looper.getMainLooper())
    private var tone: ToneGenerator? = null
    private var manager: LocationManager? = null
    // Satu mesin TTS dipakai sepanjang sesi agar pengumuman lokasi tidak saling memotong.
    private var pembicaraLokasi: Pembicara? = null

    private fun ucapkanLokasi(teks: String, gantiAntrean: Boolean = false) {
        if (pembicaraLokasi == null) {
            pembicaraLokasi = Pembicara(this, prefs.suara("lokasi")) { toast(it) }
        }
        pembicaraLokasi?.ucapkan(teks, gantiAntrean)
    }
    private val nadaPencarian = object : Runnable {
        override fun run() {
            if (sedangMencari) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }
                handler.postDelayed(this, 650L)
            }
        }
    }
    private var listener: LocationListener? = null
    private var gnssCallback: GnssStatus.Callback? = null
    private var satelitTerlihat = 0
    private var satelitDipakai = 0
    private var sinyalSatelitTerkuat = 0f
    private var gnssTersedia = false
    private var waktuLaporanSatelit = 0L
    private val laporanSatelitRunnable = object : Runnable {
        override fun run() {
            if (!sedangMencari) return
            val sekarang = System.currentTimeMillis()
            if (sekarang - waktuLaporanSatelit >= 8_000L) {
                waktuLaporanSatelit = sekarang
                val pesan = if (gnssTersedia) {
                    "Pencarian lokasi masih berlangsung. Jumlah satelit GPS yang terdeteksi sebanyak " +
                        satelitTerlihat + ". Jumlah satelit yang sedang digunakan untuk menentukan posisi sebanyak " +
                        satelitDipakai + ". " +
                        (if (satelitDipakai > 0) "Data satelit sudah tersedia. Aplikasi sedang menunggu posisi yang stabil." else "Belum ada satelit yang digunakan untuk menentukan posisi. Cobalah berada di luar ruangan dengan pandangan langit terbuka.")
                } else {
                    "Pencarian lokasi masih berlangsung. Informasi status satelit GPS belum tersedia dari perangkat. Nada pendek berulang menandakan pencarian masih aktif."
                }
                // Pembaruan satelit hanya memperbarui teks layar. Jangan menyisipkan
                // pengumuman TTS berkala karena dapat memotong panduan yang sedang dibaca.
                status.text = ui(pesan)
            }
            handler.postDelayed(this, 12_000L)
        }
    }

    override fun bangun() {
        info("Gunakan tombol Perbarui lokasi terkini untuk mengetahui tempat Anda berada. Jam Pintar Pro akan mencoba membaca nama jalan, kawasan, kelurahan atau desa, kota, dan provinsi bila layanan nama tempat tersedia. Perkiraan ketelitian posisi akan dijelaskan dengan kalimat biasa. Angka koordinat tidak dibacakan dalam ringkasan agar informasi lokasi lebih mudah dipahami. Lokasi tidak dikirim ke pengembang.")
        status = info("Lokasi belum diminta. Tekan Perbarui lokasi terkini.")
        tombol("Perbarui lokasi terkini") { perbaruiLokasi() }
        tombol("Bacakan kembali lokasi terakhir") {
            val l = lokasiTerakhir
            if (l == null) toast("Lokasi belum tersedia. Tekan Perbarui lokasi terkini terlebih dahulu.")
            else bacakanLokasi(l, namaLokasiTerakhir)
        }
        tombol("Buka lokasi terakhir di peta") {
            val l = lokasiTerakhir
            if (l == null) toast("Lokasi belum tersedia. Perbarui lokasi terlebih dahulu.")
            else bukaDiPeta(l.latitude, l.longitude, namaLokasiTerakhir ?: "Lokasi terkini")
        }
        tombol("Pilih mesin suara lokasi terkini") { pilihMesinSuaraLokasi() }
        tombol("Bagikan lokasi terkini") { bagikanLokasi() }
        tombol("Atur titik jemput transportasi daring") { bukaTitikJemput() }
        tombol("Simpan lokasi dengan nama pilihan") { dialogSimpanLokasi() }
        tombol("Kelola lokasi tersimpan") { tampilkanLokasiTersimpan() }
        tombol("Buka setelan lokasi perangkat") {
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            catch (_: Exception) { toast("Setelan lokasi tidak dapat dibuka.") }
        }
    }

    override fun onDestroy() {
        berhentiMencari()
        try { tone?.release() } catch (_: Exception) { }
        tone = null
        try { pembicaraLokasi?.matikan() } catch (_: Exception) { }
        pembicaraLokasi = null
        super.onDestroy()
    }

    private fun perbaruiLokasi() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 715)
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        manager = lm
        val penyedia = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        if (penyedia.isEmpty()) {
            status.text = ui(getString(R.string.info_layanan_lokasi_mati))
            toast("Layanan lokasi sedang mati.")
            return
        }
        berhentiMencari()
        sedangMencari = true
        lokasiTerakhir = null
        adaFixLangsung = false
        satelitTerlihat = 0
        satelitDipakai = 0
        sinyalSatelitTerkuat = 0f
        gnssTersedia = false
        waktuLaporanSatelit = 0L
        jumlahFixAkurat = 0
        waktuFixAkuratPertama = 0L
        waktuFixTerakhir = 0L
        val panduanPencarian = ui("Sedang mencari posisi satelit dan posisi terbaik. Nada pendek berulang menandakan pencarian masih berlangsung. Mohon tunggu hingga 45 detik. Untuk hasil lebih teliti, usahakan berada di tempat terbuka dan jauh dari dinding atau bangunan tinggi.")
        status.text = panduanPencarian
        ucapkanLokasi(panduanPencarian, gantiAntrean = true)
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        handler.removeCallbacks(nadaPencarian)
        handler.post(nadaPencarian)
        handler.removeCallbacks(laporanSatelitRunnable)
        handler.postDelayed(laporanSatelitRunnable, 8_000L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val gnss = object : GnssStatus.Callback() {
                    override fun onSatelliteStatusChanged(gnssStatus: GnssStatus) {
                        if (!sedangMencari) return
                        var terlihat = 0
                        var dipakai = 0
                        var terkuat = 0f
                        for (i in 0 until gnssStatus.satelliteCount) {
                            terlihat++
                            if (gnssStatus.usedInFix(i)) dipakai++
                            val cn0 = gnssStatus.getCn0DbHz(i)
                            if (cn0 > terkuat) terkuat = cn0
                        }
                        satelitTerlihat = terlihat
                        satelitDipakai = dipakai
                        sinyalSatelitTerkuat = terkuat
                        gnssTersedia = true
                    }
                }
                gnssCallback = gnss
                lm.registerGnssStatusCallback(gnss, handler)
            } catch (_: Exception) {
                gnssCallback = null
                gnssTersedia = false
            }
        }
        val callback = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!sedangMencari || location.accuracy <= 0f || location.accuracy > 10_000f) return
                // Utamakan pembacaan langsung, bukan posisi tersimpan dari sesi sebelumnya.
                val old = lokasiTerakhir
                if (!adaFixLangsung || old == null || location.accuracy < old.accuracy ||
                    (location.accuracy <= old.accuracy + 2f && location.time > old.time)) {
                    lokasiTerakhir = location
                }
                adaFixLangsung = true
                if (location.time > waktuFixTerakhir) {
                    waktuFixTerakhir = location.time
                    if (location.accuracy <= 8f) {
                        if (jumlahFixAkurat == 0) waktuFixAkuratPertama = System.currentTimeMillis()
                        jumlahFixAkurat++
                    } else {
                        jumlahFixAkurat = 0
                        waktuFixAkuratPertama = 0L
                    }
                }
                // Jangan selesai pada fix pertama. Tunggu beberapa pembacaan yang akurat dan stabil.
                if (jumlahFixAkurat >= 3 && waktuFixAkuratPertama > 0L &&
                    System.currentTimeMillis() - waktuFixAkuratPertama >= 4_000L) {
                    lokasiTerakhir?.let { selesaiDenganLokasi(it) }
                }
            }
            @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        listener = callback
        try {
            for (p in penyedia) {
                try {
                    @Suppress("MissingPermission")
                    lm.requestLocationUpdates(p, 1_000L, 0f, callback, Looper.getMainLooper())
                } catch (_: Exception) { }
                // Cache hanya digunakan sebagai cadangan bila pembacaan langsung gagal.
                try {
                    @Suppress("MissingPermission")
                    val cached = lm.getLastKnownLocation(p)
                    if (!adaFixLangsung && cached != null &&
                        System.currentTimeMillis() - cached.time in 0L..120_000L &&
                        cached.accuracy > 0f && cached.accuracy <= 10_000f) {
                        val old = lokasiTerakhir
                        if (old == null || cached.accuracy < old.accuracy) lokasiTerakhir = cached
                    }
                } catch (_: Exception) { }
            }
            timeoutHandler.postDelayed({
                if (sedangMencari) {
                    val best = lokasiTerakhir
                    if (best != null) selesaiDenganLokasi(best)
                    else {
                        berhentiMencari()
                        status.text = ui("Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka.")
                        toast("Lokasi belum ditemukan. Silakan coba lagi.")
                    }
                }
            }, 45_000L)
        } catch (_: SecurityException) {
            berhentiMencari()
            status.text = ui("Izin lokasi belum diberikan.")
            toast("Izinkan akses lokasi untuk menggunakan fitur ini.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 715) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) perbaruiLokasi()
            else {
                status.text = ui("Izin lokasi ditolak. Fitur lokasi terkini memerlukan izin lokasi saat digunakan.")
                toast("Izin lokasi diperlukan untuk mengetahui lokasi terkini.")
            }
        }
    }

    private fun selesaiDenganLokasi(location: Location) {
        if (!sedangMencari) return
        // Hentikan pembaruan GPS, tetapi pertahankan nada sampai pencarian alamat selesai.
        hentikanPembaruanGPS()
        timeoutHandler.removeCallbacksAndMessages(null)
        lokasiTerakhir = location
        status.text = ui("Koordinat ditemukan. Sedang mencari nama tempat; jika layanan nama tempat tidak tersedia, koordinat tetap dapat dibacakan.")
        Thread {
            val nama = try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val daftar: List<Address>? = Geocoder(this, Locale("id", "ID")).getFromLocation(location.latitude, location.longitude, 5)
                    daftar?.maxByOrNull { alamat ->
                        (if (!alamat.thoroughfare.isNullOrBlank()) 8 else 0) +
                        (if (!alamat.subThoroughfare.isNullOrBlank()) 5 else 0) +
                        (if (!alamat.premises.isNullOrBlank()) 5 else 0) +
                        (if (!alamat.subLocality.isNullOrBlank()) 3 else 0) +
                        (if (!alamat.locality.isNullOrBlank()) 3 else 0) +
                        (if (!alamat.postalCode.isNullOrBlank()) 1 else 0)
                    }?.let { alamat ->
                        val bagianAlamat = listOfNotNull(
                            alamat.featureName?.trim()?.takeIf { it.isNotEmpty() && !it.all { c -> c.isDigit() || c == '.' || c == '-' } },
                            alamat.premises?.trim()?.takeIf { it.isNotEmpty() },
                            listOfNotNull(
                                alamat.thoroughfare?.trim()?.takeIf { it.isNotEmpty() },
                                alamat.subThoroughfare?.trim()?.takeIf { it.isNotEmpty() }
                            ).joinToString(" ").takeIf { it.isNotBlank() },
                            alamat.subLocality?.trim()?.takeIf { it.isNotEmpty() },
                            (alamat.locality ?: alamat.subAdminArea)?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.adminArea?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.postalCode?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.countryName?.trim()?.takeIf { it.isNotEmpty() }
                        ).distinctBy { it.lowercase(Locale("id", "ID")) }
                        bagianAlamat.joinToString(", ").takeIf { it.isNotBlank() }
                    }?.takeIf { it.isNotBlank() }
                } else null
            } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                berhentiMencari()
                namaLokasiTerakhir = nama
                val hasilLokasi = bersihkanPesanLokasi(ui(susunKalimat(location, nama)))
                status.text = hasilLokasi
                // Antrekan hasil setelah panduan pencarian selesai, jangan memotongnya.
                ucapkanLokasi(hasilLokasi, gantiAntrean = false)
            }
        }.start()
    }

    private fun susunKalimat(location: Location, nama: String?): String {
        // Gunakan penggabungan teks secara eksplisit agar tidak ada placeholder
        // seperti tempat atau lintang yang ikut dibacakan sebagai teks mentah.
        val alamatBersih = nama?.trim()
            ?.split(",")
            ?.map { it.trim() }
            ?.filterNot { bagian ->
                bagian.matches(Regex("(?i)[0-9A-Z]{4,}\\+[0-9A-Z]{2,}.*")) ||
                    bagian.matches(Regex("(?i)plus code.*")) ||
                    bagian.matches(Regex("-?\\d{1,3}\\.\\d{3,}\\s*,\\s*-?\\d{1,3}\\.\\d{3,}"))
            }
            ?.joinToString(", ")
            ?.let { bersihkanSimbolAlamat(it) }
            ?.trim()
            ?.trimEnd('.', ',', ';', ':')
            ?.takeIf { it.isNotBlank() }
        val tempat = if (!alamatBersih.isNullOrBlank()) {
            "Alamat atau wilayah yang terdeteksi: " + alamatBersih + ". "
        } else {
            "Nama jalan dan wilayah belum berhasil didapatkan dari layanan alamat. "
        }
        val namaPenyedia = location.provider ?: "tidak diketahui"
        val ketelitian = location.accuracy.toInt().coerceAtLeast(1)
        if (BahasaAplikasi.tampilan(this) == 1) {
            // Susun seluruh pesan dengan penggabungan teks eksplisit. Ini mencegah
            // placeholder seperti satelitTerlihat atau alamatBersih terbaca mentah.
            val source = when (location.provider) {
                LocationManager.GPS_PROVIDER -> if (gnssTersedia) {
                    "Position source: GPS satellites. The latest check detected " +
                        satelitTerlihat + " satellites. " + satelitDipakai +
                        " satellites are being used to determine the position. "
                } else {
                    "Position source: GPS. Detailed satellite status was unavailable during the check. "
                }
                LocationManager.NETWORK_PROVIDER -> "Position source: Wi-Fi or cellular network. This does not mean the position was calculated from GPS satellites. "
                else -> {
                    val providerEnglish = when (location.provider?.lowercase(Locale.ROOT)) {
                        "gps" -> "GPS"
                        "network" -> "network"
                        "passive" -> "passive location service"
                        else -> "Android location service"
                    }
                    "Position source: " + providerEnglish +
                        ". This source cannot be confirmed as a GPS satellite position. "
                }
            }
            val place = if (!alamatBersih.isNullOrBlank()) {
                "Detected address or area: " + alamatBersih + ". "
            } else {
                "Street and area names could not be retrieved from the address service. "
            }
            val accuracyText = when {
                ketelitian <= 5 -> "Position accuracy is excellent."
                ketelitian <= 10 -> "Position accuracy is good."
                ketelitian <= 20 -> "Position accuracy is moderate. For better accuracy, wait a little or try an open area."
                else -> "Position accuracy is low. This value is an estimated error radius, not an exact distance. Try again outdoors, away from tall buildings or roofs, then update the location."
            }
            return "Your location has been found. " + source + place +
                "Estimated position accuracy is about " + ketelitian + " meters. " + accuracyText
        }
        val infoSumber = when (location.provider) {
            LocationManager.GPS_PROVIDER -> {
                if (gnssTersedia) {
                    "Sumber posisi: GPS satelit. Pada pemantauan terakhir, terdeteksi " + satelitTerlihat +
                        " satelit. Sebanyak " + satelitDipakai + " satelit sedang digunakan untuk menentukan posisi. "
                } else {
                    "Sumber posisi: GPS. Status rinci satelit tidak tersedia pada saat pemeriksaan. "
                }
            }
            LocationManager.NETWORK_PROVIDER -> "Sumber posisi: jaringan Wi-Fi atau seluler, bukan bukti bahwa posisi ini dihitung dari satelit GPS. "
            else -> "Sumber posisi: penyedia lokasi Android " + namaPenyedia + ". Sumber ini tidak dapat dipastikan sebagai posisi satelit GPS. "
        }
        val mutu = when {
            ketelitian <= 5 -> "Ketelitian posisi sangat baik."
            ketelitian <= 10 -> "Ketelitian posisi baik."
            ketelitian <= 20 -> "Ketelitian posisi sedang. Untuk hasil lebih teliti, tunggu beberapa saat atau coba di tempat terbuka."
            else -> "Posisi masih kurang teliti. Angka ini adalah perkiraan radius kesalahan, bukan jarak pasti. Coba lagi di luar ruangan, jauh dari gedung tinggi atau atap, lalu perbarui lokasi."
        }
        return "Lokasi Anda telah ditemukan. " + infoSumber + tempat +
            "Perkiraan ketelitian posisi sekitar " + ketelitian + " meter. " + mutu
    }

    /**
     * FIX64: alamat dari layanan peta kadang berisi simbol (garis miring, kurung, bintang, pagar, emoji, dan sebagainya)
     * yang tampil mengganggu dan dibacakan pembaca layar. Hanya huruf, angka, titik, koma, dan tanda hubung di dalam kata yang dipertahankan.
     */
    private fun bersihkanSimbolAlamat(teks: String): String = teks
        .replace("&", " dan ")
        .replace(Regex("[\\p{So}\\p{Sk}\\p{Sm}\\p{Cs}\\p{Pi}\\p{Pf}/\\\\|_*#~^`<>=+\\[\\]{}()\"\u2022\u00B7\u2014\u2013]"), " ")
        .replace(Regex("(?<=\\s)-+(?=\\s)|^-+|-+$"), " ")
        .replace(Regex("\\s+,"), ",")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun bersihkanPesanLokasi(teks: String): String {
        // Ringkasan lokasi tidak boleh membacakan placeholder atau simbol variabel mentah.
        return teks
            .replace(Regex("\\u0024[A-Za-z_][A-Za-z0-9_]*"), "")
            .replace(Regex("\\s+"), " ")
            .replace(Regex("\\.{2,}"), ".")
            .replace(Regex("\\s+([.,;:!?])")) { m -> m.groupValues[1] }
            .trim()
    }

    private fun bacakanLokasi(location: Location, nama: String?) {
        val kalimat = bersihkanPesanLokasi(ui(susunKalimat(location, nama)))
        status.text = kalimat
        ucapkanLokasi(kalimat, gantiAntrean = true)
    }

    private fun hentikanPembaruanGPS() {
        val lm = manager
        val cb = listener
        if (lm != null && cb != null) try { lm.removeUpdates(cb) } catch (_: Exception) { }
        listener = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val gnss = gnssCallback
            if (lm != null && gnss != null) {
                try { lm.unregisterGnssStatusCallback(gnss) } catch (_: Exception) { }
            }
        }
        gnssCallback = null
    }

    private fun berhentiMencari() {
        sedangMencari = false
        handler.removeCallbacks(nadaPencarian)
        handler.removeCallbacks(laporanSatelitRunnable)
        timeoutHandler.removeCallbacksAndMessages(null)
        hentikanPembaruanGPS()
        try { tone?.stopTone() } catch (_: Exception) { }
        try { tone?.release() } catch (_: Exception) { }
        tone = null
    }

    private fun pilihMesinSuaraLokasi() {
        val pemindai = TextToSpeech(this) { }
        handler.postDelayed({
            try {
                val mesin = pemindai.engines
                val nama = arrayListOf(if (BahasaAplikasi.tampilan(this) == 1) "System default" else "Bawaan sistem")
                nama.addAll(mesin.map { it.label })
                val paket = arrayListOf("")
                paket.addAll(mesin.map { it.name })
                val indeks = paket.indexOf(prefs.suara("lokasi").engine).coerceAtLeast(0)
                AlertDialog.Builder(this).setTitle(ui("Pilih mesin suara lokasi terkini"))
                    .setSingleChoiceItems(nama.toTypedArray(), indeks) { dialog, which ->
                        prefs.suara("lokasi").engine = paket[which]
                        dialog.dismiss()
                        toast(if (paket[which].isBlank()) "Mesin suara mengikuti bawaan sistem." else "Mesin suara lokasi terkini diperbarui.")
                        lokasiTerakhir?.let { bacakanLokasi(it, namaLokasiTerakhir) }
                    }.setNegativeButton(ui("Batal"), null).show()
            } catch (_: Exception) { toast("Daftar mesin suara tidak dapat dibaca.") }
            finally { try { pemindai.shutdown() } catch (_: Exception) { } }
        }, 250L)
    }

    /** Menghindari placeholder mentah seperti label atau {''}{l.latitude} pada teks/tautan yang dibagikan. */
    private fun labelLokasiBersih(labelMentah: String?, labelCadangan: String): String {
        val hasil = (labelMentah ?: "")
            .replace(Regex("\\u0024[A-Za-z_{][A-Za-z0-9_{}]*"), " ")
            .replace(Regex("\\u0024+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('.', ',', ';', ':', '-', '—')
        return hasil.ifBlank { labelCadangan }
    }

    private fun bagikanLokasi() {
        val l = lokasiTerakhir
        val english = BahasaAplikasi.tampilan(this) == 1
        if (l == null) {
            toast(if (english) "Location is not available. Update your current location first." else "Lokasi belum tersedia. Perbarui lokasi terkini terlebih dahulu.")
            return
        }
        val label = labelLokasiBersih(namaLokasiTerakhir, if (english) "Current location" else "Lokasi terkini")
        val latitude = l.latitude.toString()
        val longitude = l.longitude.toString()
        val maps = "https://maps.google.com/?q=" + latitude + "," + longitude
        // Rangkai nilai nyata, bukan template Kotlin; koordinat dan tautan berasal dari Location.
        val teks = StringBuilder()
            .append(label).append('\n')
            .append(latitude).append(", ").append(longitude).append('\n')
            .append(maps)
            .toString()
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, teks) }
        try { startActivity(Intent.createChooser(intent, ui("Bagikan lokasi terkini"))) }
        catch (_: Exception) { toast(if (english) "The sharing menu is not available on this device." else "Menu berbagi tidak tersedia pada perangkat ini.") }
    }

    private fun bukaTitikJemput() {
        val l = lokasiTerakhir
        val english = BahasaAplikasi.tampilan(this) == 1
        if (l == null) {
            toast(if (english) "Update your current location first so the pickup point uses the latest coordinates." else "Perbarui lokasi terkini terlebih dahulu agar titik jemput memakai koordinat terbaru.")
            return
        }
        val label = labelLokasiBersih(namaLokasiTerakhir, if (english) "My pickup point" else "Titik jemput saya")
        // Parameter lokasi dikodekan sebagai nilai URI agar label tidak merusak format titik jemput.
        val geo = Uri.parse(("geo:" + (l.latitude) + "," + (l.longitude)))
            .buildUpon()
            .appendQueryParameter("q", ("" + (l.latitude) + "," + (l.longitude) + " (" + (label) + ")"))
            .build()
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, geo), ui("Pilih aplikasi untuk menggunakan titik jemput")))
        } catch (_: Exception) { bagikanLokasi() }
    }

    private fun bukaPencarianPeta(query: String) {
        val uri = Uri.parse("https://www.google.com/maps/search/").buildUpon().appendQueryParameter("api", "1")
            .appendQueryParameter("query", query).appendQueryParameter("hl", if (BahasaAplikasi.tampilan(this) == 1) "en" else "id").build()
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { toast("Aplikasi peta tidak tersedia.") }
    }

    private fun dialogSimpanLokasi() {
        val l = lokasiTerakhir
        if (l == null) {
            toast("Belum ada lokasi untuk disimpan. Cari lokasi terlebih dahulu.")
            return
        }
        val kolom = EditText(this).apply {
            hint = ui("Contoh: Rumah, masjid, halte, atau tempat parkir")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            contentDescription = ui("Nama atau label lokasi yang akan disimpan")
        }
        AlertDialog.Builder(this)
            .setTitle(ui(getString(R.string.judul_simpan_lokasi)))
            .setMessage(ui(getString(R.string.pesan_simpan_lokasi)))
            .setView(kolom)
            .setNegativeButton(ui("Batal"), null)
            .setPositiveButton(ui("Simpan"), null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val label = kolom.text.toString().trim()
                        if (label.isBlank()) {
                            kolom.error = ui("Nama lokasi harus diisi")
                            kolom.requestFocus()
                        } else {
                            simpanLokasi(label, l, namaLokasiTerakhir)
                            dialog.dismiss()
                            toast(("Lokasi " + (label) + " berhasil disimpan."))
                            status.text = ui(("Lokasi tersimpan dengan nama " + (label) + ". Ketelitian saat disimpan sekitar " + (l.accuracy.toInt().coerceAtLeast(1)) + " meter."))
                        }
                    }
                }
                dialog.show()
                kolom.requestFocus()
            }
    }

    private fun simpanLokasi(label: String, location: Location, alamat: String?) {
        val prefsLokasi = getSharedPreferences("lokasi_tersimpan_jam_pintar", Context.MODE_PRIVATE)
        val arrayLama = try { JSONArray(prefsLokasi.getString("daftar", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val arrayBaru = JSONArray()
        for (i in 0 until arrayLama.length()) {
            val item = arrayLama.optJSONObject(i) ?: continue
            if (!item.optString("label").equals(label, ignoreCase = true)) arrayBaru.put(item)
        }
        val item = JSONObject().apply {
            put("label", label)
            put("latitude", location.latitude)
            put("longitude", location.longitude)
            put("accuracy", location.accuracy.toDouble())
            put("alamat", alamat ?: "")
            put("waktu", System.currentTimeMillis())
        }
        arrayBaru.put(item)
        prefsLokasi.edit().putString("daftar", arrayBaru.toString()).apply()
    }

    private fun bacaDaftarLokasi(): JSONArray {
        val prefsLokasi = getSharedPreferences("lokasi_tersimpan_jam_pintar", Context.MODE_PRIVATE)
        return try { JSONArray(prefsLokasi.getString("daftar", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    }

    private fun tampilkanLokasiTersimpan() {
        val daftar = bacaDaftarLokasi()
        if (daftar.length() == 0) {
            AlertDialog.Builder(this)
                .setTitle(ui(getString(R.string.judul_lokasi_tersimpan)))
                .setMessage(ui(getString(R.string.pesan_belum_ada_lokasi_tersimpan)))
                .setPositiveButton(ui("Mengerti"), null)
                .show()
            return
        }
        val label = ArrayList<String>()
        for (i in 0 until daftar.length()) {
            val item = daftar.optJSONObject(i) ?: continue
            label.add(item.optString("label", "Lokasi tanpa nama"))
        }
        AlertDialog.Builder(this)
            .setTitle(ui(getString(R.string.judul_pilih_lokasi_tersimpan)))
            .setItems(label.toTypedArray()) { _, posisi ->
                val item = daftar.optJSONObject(posisi) ?: return@setItems
                menuLokasiTersimpan(item)
            }
            .setNegativeButton(ui("Tutup"), null)
            .show()
    }

    private fun menuLokasiTersimpan(item: JSONObject) {
        val label = item.optString("label", "Lokasi tersimpan")
        val lat = item.optDouble("latitude", Double.NaN)
        val lon = item.optDouble("longitude", Double.NaN)
        val accuracy = item.optDouble("accuracy", 0.0).toFloat()
        val alamat = item.optString("alamat", "").takeIf { it.isNotBlank() }
        val query = item.optString("query", "").takeIf { it.isNotBlank() }
        if ((!lat.isFinite() || !lon.isFinite()) && query == null) {
            toast(("Data lokasi " + (label) + " tidak valid."))
            return
        }
        val pilihan = arrayOf("Bacakan informasi lokasi", "Buka lokasi di peta", "Hapus lokasi tersimpan", "Kembali").map { ui(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(label)
            .setItems(pilihan) { _, index ->
                when (index) {
                    0 -> {
                        if (query != null && (!lat.isFinite() || !lon.isFinite())) {
                            val kalimat = ("Lokasi tersimpan dengan nama " + (label) + ". Alamat atau tujuan: " + (query) + ".")
                            status.text = ui(kalimat)
                            ucapkanLokasi(ui(kalimat), gantiAntrean = true)
                        } else {
                            val tersimpan = Location("lokasi_tersimpan").apply {
                                latitude = lat; longitude = lon; this.accuracy = accuracy.coerceAtLeast(1f)
                                time = item.optLong("waktu", System.currentTimeMillis())
                            }
                            lokasiTerakhir = tersimpan; namaLokasiTerakhir = alamat
                            val kalimat = ("Lokasi tersimpan dengan nama " + (label) + ". ") + susunKalimat(tersimpan, alamat)
                            status.text = ui(kalimat); ucapkanLokasi(ui(kalimat), gantiAntrean = true)
                        }
                    }
                    1 -> if (query != null && (!lat.isFinite() || !lon.isFinite())) bukaPencarianPeta(query) else bukaDiPeta(lat, lon, label)
                    2 -> AlertDialog.Builder(this)
                        .setTitle(ui(getString(R.string.judul_hapus_lokasi, label)))
                        .setMessage(ui(getString(R.string.pesan_hapus_lokasi)))
                        .setNegativeButton(ui("Batal"), null)
                        .setPositiveButton(ui("Hapus")) { _, _ ->
                            hapusLokasi(label)
                            toast(("Lokasi " + (label) + " telah dihapus."))
                        }.show()
                }
            }
            .setNegativeButton(ui("Tutup"), null)
            .show()
    }

    private fun hapusLokasi(label: String) {
        val lama = bacaDaftarLokasi()
        val baru = JSONArray()
        for (i in 0 until lama.length()) {
            val item = lama.optJSONObject(i) ?: continue
            if (!item.optString("label").equals(label, ignoreCase = true)) baru.put(item)
        }
        getSharedPreferences("lokasi_tersimpan_jam_pintar", Context.MODE_PRIVATE)
            .edit().putString("daftar", baru.toString()).apply()
    }

    private fun bukaDiPeta(latitude: Double, longitude: Double, label: String) {
        val uri = Uri.parse(("geo:" + (latitude) + "," + (longitude) + "?q=" + (latitude) + "," + (longitude) + "(" + (Uri.encode(label)) + ")"))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { toast("Aplikasi peta tidak tersedia.") }
    }
}
