package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * FIX87: penjaga proses saat Al-Qur'an diputar lewat perintah suara dari layar depan.
 *
 * Setelah perintah dijalankan, Khatam dikembalikan ke belakang (pengguna tetap di layar depan) dan audio terus diputar.
 * Layanan latar depan ini hanya menjaga agar proses aplikasi tidak dimatikan sistem selama audio berbunyi, lalu
 * berhenti sendiri ketika audio selesai. Tombol "Hentikan audio" pada notifikasinya menghentikan pemutaran.
 */
class AudioLatarService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var tidakBerjalan = 0
    private val periksa = object : Runnable {
        override fun run() {
            // Toleransi 3 pemeriksaan agar jeda antarayat/terjemahan tidak dianggap selesai.
            if (KhatamActivity.sedangMemutarLatar()) tidakBerjalan = 0 else tidakBerjalan++
            if (tidakBerjalan >= 3) { selesai(); return }
            handler.postDelayed(this, 4000L)
        }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AKSI_HENTIKAN) {
            // Layanan mungkin dimulai baru oleh tombol notifikasi; tetap aman bila langsung berhenti.
            KhatamActivity.hentikanLatar()
            selesai()
            return START_NOT_STICKY
        }
        buatSaluran()
        try { startForeground(NOTIF_ID, bangunNotifikasi()) } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        tidakBerjalan = 0
        handler.removeCallbacks(periksa)
        handler.postDelayed(periksa, 4000L)
        return START_NOT_STICKY
    }

    private fun inggris(): Boolean = BahasaAplikasi.tampilan(this) == 1

    private fun buatSaluran() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        val saluran = NotificationChannel(SALURAN, if (inggris()) "Background Quran audio" else "Audio Al-Qur'an di latar belakang", NotificationManager.IMPORTANCE_LOW)
        saluran.setSound(null, null)
        nm.createNotificationChannel(saluran)
    }

    private fun bangunNotifikasi(): Notification {
        val flag = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val buka = PendingIntent.getActivity(this, 8202, Intent(this, KhatamActivity::class.java), flag)
        val hentikan = PendingIntent.getService(this, 8203, Intent(this, AudioLatarService::class.java).setAction(AKSI_HENTIKAN), flag)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, SALURAN) else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(if (inggris()) "Playing Quran audio" else "Memutar audio Al-Qur'an")
            .setContentText(if (inggris()) "Playing in the background. Tap to open Khatam." else "Diputar di latar belakang. Ketuk untuk membuka Khatam.")
            .setContentIntent(buka)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, if (inggris()) "Stop audio" else "Hentikan audio", hentikan)
        return b.build()
    }

    private fun selesai() {
        handler.removeCallbacks(periksa)
        try { if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true) } catch (_: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(periksa)
        super.onDestroy()
    }

    companion object {
        const val AKSI_HENTIKAN = "com.novan.bateraibicara.AUDIO_LATAR_HENTIKAN"
        private const val SALURAN = "audio_latar"
        private const val NOTIF_ID = 8201

        fun mulai(context: Context) {
            val i = Intent(context, AudioLatarService::class.java)
            try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i) } catch (_: Exception) { }
        }
    }
}
