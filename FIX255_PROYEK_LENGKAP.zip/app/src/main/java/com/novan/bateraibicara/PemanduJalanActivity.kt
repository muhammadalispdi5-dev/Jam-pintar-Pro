package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Pemandu perjalanan aksesibel dengan mode berjalan kaki/berkendara, asal/tujuan, lokasi tersimpan dan pilihan mesin TTS. */
class PemanduJalanActivity : Halaman() {
    override val judulHalaman = R.string.judul_pemandu_jalan

    private lateinit var tujuan: EditText
    private lateinit var awal: EditText
    private lateinit var status: android.widget.TextView
    private var manager: LocationManager? = null
    private var listener: LocationListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sedangMencari = false
    private var pembicaraPanduan: Pembicara? = null
    private var tujuanAktif = ""
    private var modePerjalanan = "walking"
    private val timeout = Runnable {
        if (sedangMencari) {
            berhentiMencari()
            val pesan = "Belum mendapatkan posisi GPS satelit yang memadai. Cobalah di luar ruangan dengan pandangan langit terbuka, lalu coba lagi."
            status.text = ui(pesan)
            ucapkanPanduan(pesan)
            toast("GPS satelit belum mendapatkan posisi. Silakan coba lagi di tempat terbuka.")
        }
    }

    override fun bangun() {
        info("Masukkan lokasi awal dan tujuan. Kosongkan lokasi awal untuk menggunakan posisi GPS terkini. Anda juga dapat memilih lokasi yang pernah disimpan dengan nama pilihan sendiri. Pilih mode berjalan kaki atau berkendara; setelah posisi awal tersedia, Jam Pintar Pro membuka rute sesuai mode di Google Maps.")
        info("Setelah rute dibuka, Google Maps menjadi pemandu utama dan membacakan petunjuk belokan serta perubahan rute untuk mode berjalan kaki maupun berkendara melalui mesin suara perangkat. Pastikan suara navigasi Google Maps aktif dan volume media terdengar. Jam Pintar Pro tidak membuat petunjuk belokan sendiri ketika Google Maps berjalan.")
        info("Panduan ini tidak dapat mendeteksi semua rintangan, lubang, kendaraan, penyeberangan, atau kondisi trotoar. Tetap gunakan tongkat, anjing pemandu, atau bantuan pendamping bila diperlukan. Berhenti di tempat aman sebelum mengoperasikan ponsel.")
        awal = isian("Lokasi awal (kosongkan untuk memakai GPS terkini)", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) { }
        tujuan = isian("Lokasi tujuan", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) { }
        status = info("Status: belum mulai. Pilih mode perjalanan, tentukan tujuan, lalu mulai panduan.")
        tombol("Pilih lokasi tersimpan untuk lokasi awal") { pilihLokasiTersimpan(true) }
        tombol("Pilih lokasi tersimpan untuk tujuan") { pilihLokasiTersimpan(false) }
        tombol("Simpan tujuan dengan nama pilihan") { simpanTujuanBernama() }
        tombol("Pilih mode perjalanan") { pilihModePerjalanan() }
        tombol("Pilih mesin suara pemandu jalan") { pilihMesinSuara("pemandu") }
        tombol("Uji suara pemandu jalan") {
            ucapkanPanduan(if (BahasaAplikasi.tampilan(this) == 1) "The journey guide voice is ready. This feature uses the speech engine selected here." else "Suara pemandu perjalanan siap. Fitur ini menggunakan mesin suara yang dipilih di sini.")
        }
        tombol("Mulai panduan perjalanan") { mulai() }
        tombol("Buka setelan GPS dan lokasi") {
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            catch (_: Exception) { toast("Setelan lokasi tidak dapat dibuka."); ucapkanPanduan("Setelan lokasi tidak dapat dibuka.") }
        }
        tombol("Batalkan pencarian GPS") {
            berhentiMencari()
            status.text = ui("Pencarian GPS dibatalkan.")
            ucapkanPanduan("Pencarian GPS dibatalkan.")
        }
    }

    override fun onDestroy() {
        berhentiMencari()
        pembicaraPanduan?.matikan()
        pembicaraPanduan = null
        super.onDestroy()
    }

    private fun ucapkanPanduan(teks: String, selesai: (() -> Unit)? = null) {
        if (pembicaraPanduan == null) pembicaraPanduan = Pembicara(this, prefs.suara("pemandu")) { toast(it) }
        pembicaraPanduan?.ucapkan(ui(teks), true, selesai)
    }

    private fun mulai() {
        tujuanAktif = tujuan.text?.toString()?.trim().orEmpty()
        if (tujuanAktif.isBlank()) {
            toast("Masukkan alamat atau nama tempat tujuan terlebih dahulu.")
            ucapkanPanduan("Masukkan alamat atau nama tempat tujuan terlebih dahulu.")
            tujuan.requestFocus()
            return
        }
        val awalTeks = awal.text?.toString()?.trim().orEmpty()
        // Lokasi awal yang diisi pengguna langsung dipakai sebagai titik asal; GPS hanya diperlukan jika kosong.
        if (awalTeks.isNotBlank()) {
            val pesan = ("Membuka rute " + (namaModePerjalanan()) + " dari lokasi awal yang dipilih.")
            status.text = ui(pesan)
            ucapkanPanduan(pesan) { bukaNavigasi(awalTeks, tujuanAktif) }
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 871)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        manager = lm
        val gpsAktif = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (_: Exception) { false }
        if (!gpsAktif) {
            val pesan = "GPS satelit belum aktif. Aktifkan GPS atau layanan lokasi perangkat, lalu coba lagi."
            status.text = ui(pesan); ucapkanPanduan(pesan); toast("GPS belum aktif. Buka setelan lokasi perangkat.")
            return
        }
        berhentiMencari()
        sedangMencari = true
        val pesanCari = if (BahasaAplikasi.tampilan(this) == 1) "Searching for a GPS satellite position. Try to stay outdoors with a clear view of the sky." else "Sedang mencari posisi dari satelit GPS. Usahakan berada di luar ruangan dengan pandangan langit terbuka."
        status.text = ui(pesanCari); ucapkanPanduan(pesanCari)
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!sedangMencari || location.accuracy <= 0f || location.accuracy > 150f) return
                berhentiMencari()
                val pesanSiap = if (BahasaAplikasi.tampilan(this@PemanduJalanActivity) == 1) {
                    "GPS position acquired. Opening " + (if (modePerjalanan == "driving") "driving navigation" else "walking navigation") + ". Google Maps will provide turn-by-turn guidance and announce route changes."
                } else {
                    "Posisi GPS diperoleh. Membuka navigasi " + namaModePerjalanan() + ". Petunjuk belokan selanjutnya dan perubahan rute akan dibacakan oleh Google Maps."
                }
                status.text = ui(pesanSiap)
                ucapkanPanduan(pesanSiap) { bukaNavigasi(("" + (location.latitude) + "," + (location.longitude)), tujuanAktif) }
            }
        }
        listener = l
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper())
            handler.postDelayed(timeout, 30_000L)
        } catch (_: SecurityException) {
            berhentiMencari(); toast("Izin lokasi belum diberikan. Izinkan akses lokasi untuk Jam Pintar Pro.")
            ucapkanPanduan("Izin lokasi belum diberikan. Izinkan akses lokasi untuk Jam Pintar Pro.")
        } catch (_: Exception) {
            berhentiMencari(); toast("GPS tidak dapat dimulai pada perangkat ini."); ucapkanPanduan("GPS tidak dapat dimulai pada perangkat ini.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 871) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) mulai()
            else { toast("Izin lokasi diperlukan untuk memperoleh posisi GPS satelit."); ucapkanPanduan("Izin lokasi diperlukan untuk memperoleh posisi GPS satelit.") }
        }
    }

    private fun namaModePerjalanan(): String = if (modePerjalanan == "driving") "berkendara" else "berjalan kaki"

    private fun pilihModePerjalanan() {
        val pilihan = arrayOf(ui("Berjalan kaki"), ui("Berkendara"))
        val terpilih = if (modePerjalanan == "driving") 1 else 0
        AlertDialog.Builder(this)
            .setTitle(ui("Pilih mode perjalanan"))
            .setSingleChoiceItems(pilihan, terpilih) { dialog, which ->
                modePerjalanan = if (which == 1) "driving" else "walking"
                dialog.dismiss()
                val pesan = ("Mode perjalanan dipilih: " + (namaModePerjalanan()) + ".")
                status.text = ui(pesan)
                toast(pesan)
                ucapkanPanduan(pesan)
            }
            .setNegativeButton(ui("Batal"), null)
            .show()
    }

    private fun bukaNavigasi(origin: String, destination: String) {
        val bahasa = if (BahasaAplikasi.tampilan(this) == 1) "en" else "id"
        val uri = Uri.parse("https://www.google.com/maps/dir/").buildUpon()
            .appendQueryParameter("api", "1").appendQueryParameter("origin", origin)
            .appendQueryParameter("destination", destination).appendQueryParameter("travelmode", modePerjalanan)
            .appendQueryParameter("dir_action", "navigate").appendQueryParameter("hl", bahasa).build()
        try {
            // Utamakan aplikasi Google Maps agar mode navigasi suara dan pembaruan belokan
            // ditangani oleh mesin navigasi Maps, bukan hanya membuka halaman web di browser.
            val intentMaps = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
            try {
                startActivity(intentMaps)
            } catch (_: Exception) {
                // Jika Google Maps tidak terpasang, berikan tautan navigasi sebagai alternatif.
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        } catch (_: Exception) {
            val pesan = "Aplikasi peta tidak dapat dibuka. Pasang atau perbarui Google Maps, lalu coba kembali."
            toast(pesan)
            ucapkanPanduan(pesan)
        }
    }

    private fun pilihMesinSuara(profil: String) {
        val pemindai = TextToSpeech(this) { }
        handler.postDelayed({
            try {
                val mesin = pemindai.engines
                val nama = arrayListOf(if (BahasaAplikasi.tampilan(this) == 1) "System default" else "Bawaan sistem")
                nama.addAll(mesin.map { it.label })
                val paket = arrayListOf("")
                paket.addAll(mesin.map { it.name })
                val saatIni = prefs.suara(profil).engine
                val indeks = paket.indexOf(saatIni).coerceAtLeast(0)
                AlertDialog.Builder(this).setTitle(ui("Pilih mesin suara pemandu jalan"))
                    .setSingleChoiceItems(nama.toTypedArray(), indeks) { dialog, which ->
                        prefs.suara(profil).engine = paket[which]
                        pembicaraPanduan?.matikan(); pembicaraPanduan = null
                        dialog.dismiss()
                        toast(if (paket[which].isBlank()) "Mesin suara mengikuti bawaan sistem." else "Mesin suara pemandu jalan diperbarui.")
                        ucapkanPanduan(if (BahasaAplikasi.tampilan(this) == 1) "Voice engine setting updated." else "Pengaturan mesin suara telah diperbarui.")
                    }.setNegativeButton(ui("Batal"), null).show()
            } catch (_: Exception) { toast("Daftar mesin suara tidak dapat dibaca.") }
            finally { try { pemindai.shutdown() } catch (_: Exception) { } }
        }, 250L)
    }

    private fun bacaDaftarLokasi(): JSONArray {
        val sp = getSharedPreferences("lokasi_tersimpan_jam_pintar", MODE_PRIVATE)
        return try { JSONArray(sp.getString("daftar", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    }

    private fun pilihLokasiTersimpan(untukAwal: Boolean) {
        val daftar = bacaDaftarLokasi()
        if (daftar.length() == 0) { toast("Belum ada lokasi tersimpan. Simpan lokasi terlebih dahulu dari fitur lokasi terkini."); return }
        val itemValid = ArrayList<JSONObject>()
        val label = ArrayList<String>()
        for (i in 0 until daftar.length()) {
            val item = daftar.optJSONObject(i) ?: continue
            val nama = item.optString("label").ifBlank { "Lokasi tanpa nama" }
            label.add(nama); itemValid.add(item)
        }
        if (label.isEmpty()) { toast("Belum ada lokasi tersimpan."); return }
        AlertDialog.Builder(this).setTitle(ui(if (untukAwal) "Pilih lokasi awal tersimpan" else "Pilih tujuan tersimpan"))
            .setItems(label.toTypedArray()) { _, index ->
                val item = itemValid[index]
                val query = item.optString("query", "").trim()
                val lat = item.optDouble("latitude", Double.NaN)
                val lon = item.optDouble("longitude", Double.NaN)
                val lokasi = if (query.isNotBlank()) query else if (lat.isFinite() && lon.isFinite()) ("" + (lat) + "," + (lon)) else ""
                if (lokasi.isBlank()) toast("Data lokasi tersimpan tidak valid.")
                else {
                    (if (untukAwal) awal else tujuan).setText(lokasi)
                    toast(if (BahasaAplikasi.tampilan(this) == 1) ("Location " + (label[index]) + " selected.") else ("Lokasi " + (label[index]) + " dipilih."))
                }
            }.setNegativeButton(ui("Batal"), null).show()
    }

    private fun simpanTujuanBernama() {
        val query = tujuan.text?.toString()?.trim().orEmpty()
        if (query.isBlank()) { toast("Isi lokasi tujuan terlebih dahulu, lalu simpan dengan nama pilihan."); tujuan.requestFocus(); return }
        val kolom = EditText(this).apply {
            hint = ui("Contoh: Rumah, sekolah, halte, atau klinik")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            contentDescription = ui("Nama lokasi tersimpan")
        }
        AlertDialog.Builder(this).setTitle(ui("Simpan tujuan dengan nama pilihan"))
            .setMessage(ui("Nama ini akan digunakan untuk menemukan lokasi tersebut lagi di perangkat ini."))
            .setView(kolom).setNegativeButton(ui("Batal"), null)
            .setPositiveButton(ui("Simpan")) { _, _ ->
                val label = kolom.text.toString().trim()
                if (label.isBlank()) toast("Nama lokasi harus diisi.") else {
                    val lama = bacaDaftarLokasi(); val baru = JSONArray()
                    for (i in 0 until lama.length()) {
                        val it = lama.optJSONObject(i) ?: continue
                        if (!it.optString("label").equals(label, true)) baru.put(it)
                    }
                    baru.put(JSONObject().put("label", label).put("query", query).put("alamat", query).put("waktu", System.currentTimeMillis()))
                    getSharedPreferences("lokasi_tersimpan_jam_pintar", MODE_PRIVATE).edit().putString("daftar", baru.toString()).apply()
                    toast(if (BahasaAplikasi.tampilan(this) == 1) ("Location " + (label) + " saved successfully.") else ("Lokasi " + (label) + " berhasil disimpan."))
                }
            }.show()
    }

    private fun berhentiMencari() {
        sedangMencari = false; handler.removeCallbacks(timeout)
        val lm = manager; val l = listener
        if (lm != null && l != null) try { lm.removeUpdates(l) } catch (_: Exception) { }
        listener = null
    }
}
