package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** Pengelola Mode Acara: menahan pengumuman aplikasi dan menerapkan cakupan Jangan Ganggu pilihan pengguna. */
object ModeAcara {
    private const val PREF = "mode_acara"
    private const val K_AKTIF = "aktif"
    private const val K_BERAKHIR = "berakhir"
    private const val K_FILTER_SEBELUM = "filter_sebelum"
    private const val K_FILTER_DIUBAH = "filter_diubah"
    private const val K_FILTER_DITERAPKAN = "filter_diterapkan"
    private const val K_CAKUPAN = "cakupan"

    // Nilai yang disimpan untuk pilihan cakupan Mode Acara.
    const val CAKUPAN_JAM_PINTAR = 0
    const val CAKUPAN_PRIORITAS = 1
    const val CAKUPAN_ALARM = 2
    const val CAKUPAN_SEMUA = 3

    fun cakupan(context: Context): Int = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getInt(K_CAKUPAN, CAKUPAN_SEMUA).coerceIn(CAKUPAN_JAM_PINTAR, CAKUPAN_SEMUA)

    fun aktif(context: Context): Boolean {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!p.getBoolean(K_AKTIF, false)) return false
        val akhir = p.getLong(K_BERAKHIR, 0L)
        if (akhir > 0L && System.currentTimeMillis() >= akhir) {
            selesai(context)
            return false
        }
        return true
    }

    /**
     * Cakupan 0 hanya menahan pengumuman Jam Pintar Pro. Cakupan lain memakai filter
     * Jangan Ganggu Android: PRIORITY, ALARMS, atau NONE. Pengecualian aplikasi lain
     * pada mode PRIORITY tetap diatur pengguna melalui pengaturan sistem Android.
     */
    fun mulai(context: Context, durasiMenit: Int, cakupanDipilih: Int): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val cakupanAman = cakupanDipilih.coerceIn(CAKUPAN_JAM_PINTAR, CAKUPAN_SEMUA)
        val filterTujuan = filterUntuk(cakupanAman)
        if (filterTujuan != null && !nm.isNotificationPolicyAccessGranted) return false

        val sudahAktif = aktif(context)
        if (!sudahAktif) {
            p.edit()
                .putInt(K_FILTER_SEBELUM, nm.currentInterruptionFilter)
                .putBoolean(K_FILTER_DIUBAH, false)
                .putInt(K_FILTER_DITERAPKAN, -1)
                .apply()
        }

        // Jika pengguna mengubah cakupan ketika mode sudah aktif, jangan kehilangan
        // filter awal yang harus dipulihkan saat acara berakhir.
        val filterDiterapkanSebelumnya = p.getInt(K_FILTER_DITERAPKAN, -1)
        if (filterDiterapkanSebelumnya >= 0 && nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == filterDiterapkanSebelumnya && filterTujuan == null) {
            val awal = p.getInt(K_FILTER_SEBELUM, NotificationManager.INTERRUPTION_FILTER_ALL)
            try { nm.setInterruptionFilter(awal) } catch (_: Exception) { }
            p.edit().putBoolean(K_FILTER_DIUBAH, false).putInt(K_FILTER_DITERAPKAN, -1).apply()
        } else if (filterTujuan != null) {
            if (!sudahAktif) {
                p.edit().putBoolean(K_FILTER_DIUBAH, nm.currentInterruptionFilter != filterTujuan).apply()
            } else if (filterDiterapkanSebelumnya < 0) {
                // Mode sebelumnya hanya menahan suara Jam Pintar Pro; simpan filter
                // saat ini sebagai kondisi sebelum perubahan sistem pertama.
                p.edit().putInt(K_FILTER_SEBELUM, nm.currentInterruptionFilter)
                    .putBoolean(K_FILTER_DIUBAH, nm.currentInterruptionFilter != filterTujuan).apply()
            }
            try { nm.setInterruptionFilter(filterTujuan) } catch (_: Exception) { }
            p.edit().putInt(K_FILTER_DITERAPKAN, filterTujuan).apply()
        }

        val akhir = if (durasiMenit > 0) System.currentTimeMillis() + durasiMenit * 60_000L else 0L
        p.edit().putBoolean(K_AKTIF, true).putLong(K_BERAKHIR, akhir).putInt(K_CAKUPAN, cakupanAman).apply()
        // Hentikan suara pengingat yang mungkin sedang berlangsung saat mode diaktifkan.
        try {
            context.startService(Intent(context, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND"))
        } catch (_: Exception) { }
        context.sendBroadcast(Intent("com.novan.jambicarapro.MODE_ACARA_DIAKTIFKAN").setPackage(context.packageName))
        jadwalkan(context, akhir)
        return true
    }

    private fun filterUntuk(cakupan: Int): Int? = when (cakupan) {
        CAKUPAN_JAM_PINTAR -> null
        CAKUPAN_PRIORITAS -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
        CAKUPAN_ALARM -> NotificationManager.INTERRUPTION_FILTER_ALARMS
        else -> NotificationManager.INTERRUPTION_FILTER_NONE
    }

    fun selesai(context: Context) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val sebelumnya = p.getInt(K_FILTER_SEBELUM, NotificationManager.INTERRUPTION_FILTER_ALL)
        val pernahDiubah = p.getBoolean(K_FILTER_DIUBAH, false)
        val filterDiterapkan = p.getInt(K_FILTER_DITERAPKAN, -1)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        p.edit().putBoolean(K_AKTIF, false).putLong(K_BERAKHIR, 0L).putBoolean(K_FILTER_DIUBAH, false).putInt(K_FILTER_DITERAPKAN, -1).apply()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        try { am.cancel(pi) } catch (_: Exception) { }
        // Pulihkan hanya bila filter masih sama dengan yang terakhir diterapkan aplikasi.
        // Jika pengguna mengubahnya secara manual selama acara, jangan menimpa pilihannya.
        if (pernahDiubah && filterDiterapkan >= 0 && nm.isNotificationPolicyAccessGranted &&
            nm.currentInterruptionFilter == filterDiterapkan) {
            try { nm.setInterruptionFilter(sebelumnya) } catch (_: Exception) { }
        }
    }

    private fun jadwalkan(context: Context, akhir: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        try { am.cancel(pi) } catch (_: Exception) { }
        if (akhir <= 0L) return
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, akhir, pi)
            else am.setExact(AlarmManager.RTC_WAKEUP, akhir, pi)
        } catch (_: Exception) {
            try { am.set(AlarmManager.RTC_WAKEUP, akhir, pi) } catch (_: Exception) { }
        }
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, 7711, Intent(context, ModeAcaraReceiver::class.java).setAction("com.novan.jambicarapro.MODE_ACARA_SELESAI"),
        PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    )
}
