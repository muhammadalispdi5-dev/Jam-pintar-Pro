package com.novan.bateraibicara

import android.app.DownloadManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Pembaruan aplikasi tanpa Play Store: periksa berkas JSON versi terbaru, unduh APK lewat
 * DownloadManager, lalu pasang lewat PackageInstaller. Android tidak mengizinkan aplikasi biasa
 * memasang pembaruan secara diam-diam, jadi pengguna tetap mengetuk konfirmasi pemasangan sistem
 * (dan mengizinkan "pasang aplikasi dari sumber ini" sekali saja). APK baru HARUS ditandatangani
 * dengan kunci yang sama dengan aplikasi terpasang.
 *
 * Format JSON: {"versionCode":64,"versionName":"1.0.64","apkUrl":"https://.../JamPintarPro.apk","catatan":"..."}
 */
object UpdateManager {
    class Info(val versionCode: Int, val versionName: String, val apkUrl: String, val catatan: String)

    const val STATUS_GAGAL = 0
    const val STATUS_TERBARU = 1
    const val STATUS_ADA = 2

    const val PASANG_MULAI = 0
    const val PASANG_BERKAS_TIDAK_ADA = 1
    const val PASANG_BERKAS_TIDAK_VALID = 2
    const val PASANG_BUTUH_IZIN = 3
    const val PASANG_GAGAL = 4

    const val AKSI_HASIL_PASANG = "com.novan.bateraibicara.HASIL_PASANG_PEMBARUAN"

    private const val PREF = "pengaturan"
    private const val NAMA_APK = "JamPintarPro-pembaruan.apk"
    private const val JEDA_CEK_MS = 12L * 60 * 60 * 1000
    private const val BATAS_JSON = 256 * 1024

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Sumber pembaruan: berkas JSON bila URL_INFO_UPDATE diisi, jika tidak rilis terbaru GitHub (BuildConfig.GITHUB_REPO). */
    private fun alamatInfo(): String = when {
        AppKonfigurasi.URL_INFO_UPDATE.startsWith("https://") -> AppKonfigurasi.URL_INFO_UPDATE
        BuildConfig.GITHUB_REPO.contains("/") -> "https://api.github.com/repos/" + BuildConfig.GITHUB_REPO + "/releases/latest"
        else -> ""
    }

    fun terkonfigurasi(): Boolean = alamatInfo().startsWith("https://")

    private fun bagianVersi(v: String): List<Int> =
        v.trim().removePrefix("v").removePrefix("V").split(".", "-", "+").take(4)
            .map { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }

    /** True bila nama versi [baru] lebih tinggi daripada [lama] (mis. 1.0.64 > 1.0.63). */
    private fun lebihBaruNama(baru: String, lama: String): Boolean {
        val a = bagianVersi(baru)
        val b = bagianVersi(lama)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /**
     * Mengubah JSON rilis GitHub (tag_name, assets, body) menjadi format yang dipakai pemeriksa
     * (versionCode, versionName, apkUrl, catatan). Rilis GitHub tidak memuat versionCode, jadi bila tag-nya
     * lebih tinggi daripada versi terpasang dipakai versionCode terpasang + 1 sebagai penanda "lebih baru";
     * kecocokan sebenarnya tetap diperiksa pada APK yang diunduh (harus punya versionCode lebih tinggi).
     */
    private fun normalisasi(c: Context, j: JSONObject): JSONObject {
        if (!j.has("tag_name")) return j
        val tag = j.optString("tag_name").removePrefix("v").removePrefix("V")
        val sekarang = versiSaatIni(c)
        var apk = ""
        val aset = j.optJSONArray("assets")
        if (aset != null) {
            for (i in 0 until aset.length()) {
                val a = aset.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    apk = a.optString("browser_download_url")
                    break
                }
            }
        }
        val baru = tag.isNotEmpty() &&
            apk.startsWith("https://github.com/" + BuildConfig.GITHUB_REPO + "/") &&
            lebihBaruNama(tag, namaVersi(c))
        return JSONObject()
            .put("versionCode", if (baru) sekarang + 1 else sekarang)
            .put("versionName", tag)
            .put("apkUrl", apk)
            .put("catatan", j.optString("body", ""))
    }

    fun otomatisAktif(c: Context): Boolean = sp(c).getBoolean("update_otomatis", true)
    fun setOtomatis(c: Context, v: Boolean) { sp(c).edit().putBoolean("update_otomatis", v).apply() }

    fun sudahWaktunyaCek(c: Context): Boolean =
        System.currentTimeMillis() - sp(c).getLong("update_terakhir_cek", 0L) >= JEDA_CEK_MS

    fun catatCek(c: Context) { sp(c).edit().putLong("update_terakhir_cek", System.currentTimeMillis()).apply() }

    @Suppress("DEPRECATION")
    fun versiSaatIni(c: Context): Int = try {
        val pi = c.packageManager.getPackageInfo(c.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (_: Exception) { 0 }

    fun namaVersi(c: Context): String = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** Memeriksa versi terbaru di latar belakang; [hasil] dipanggil di thread utama. */
    fun periksa(c: Context, hasil: (Int, Info?) -> Unit) {
        val app = c.applicationContext
        val alamat = alamatInfo()
        if (!terkonfigurasi()) { hasil(STATUS_GAGAL, null); return }
        Thread {
            var status = STATUS_GAGAL
            var info: Info? = null
            try {
                val conn = URL(alamat).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Accept", "application/vnd.github+json, application/json")
                conn.setRequestProperty("User-Agent", "JamPintarPro-Pembaruan")
                try {
                    if (conn.responseCode == 200) {
                        val teks = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        if (teks.length <= BATAS_JSON) {
                            val j = normalisasi(app, JSONObject(teks))
                            val kode = j.getInt("versionCode")
                            if (kode <= versiSaatIni(app)) {
                                status = STATUS_TERBARU
                            } else {
                                val apk = j.optString("apkUrl")
                                // Hanya HTTPS agar berkas tidak bisa disusupi di jalan.
                                if (apk.startsWith("https://")) {
                                    info = Info(kode, j.optString("versionName", kode.toString()), apk, j.optString("catatan"))
                                    status = STATUS_ADA
                                }
                            }
                        }
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (_: Exception) { }
            Handler(Looper.getMainLooper()).post { hasil(status, info) }
        }.start()
    }

    private fun berkasApk(c: Context): File? {
        val dir = c.applicationContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return null
        return File(dir, NAMA_APK)
    }

    /** Memulai unduhan APK; mengembalikan id unduhan, atau -1 bila gagal dimulai. */
    fun unduh(c: Context, info: Info): Long {
        val app = c.applicationContext
        val tujuan = berkasApk(app) ?: return -1L
        try { tujuan.delete() } catch (_: Exception) { }
        val dm = app.getSystemService(DownloadManager::class.java) ?: return -1L
        val req = DownloadManager.Request(Uri.parse(info.apkUrl))
            .setTitle(app.getString(R.string.update_judul_unduhan, info.versionName))
            .setDescription(app.getString(R.string.update_deskripsi_unduhan))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setMimeType("application/vnd.android.package-archive")
            .setDestinationInExternalFilesDir(app, Environment.DIRECTORY_DOWNLOADS, NAMA_APK)
        val id = dm.enqueue(req)
        sp(app).edit()
            .putLong("update_unduhan_id", id)
            .putInt("update_target_versi", info.versionCode)
            .apply()
        return id
    }

    fun batalkan(c: Context, id: Long) {
        try { c.applicationContext.getSystemService(DownloadManager::class.java)?.remove(id) } catch (_: Exception) { }
    }

    /** Mengembalikan [status DownloadManager atau -1, persen 0..100]. */
    fun progres(c: Context, id: Long): IntArray {
        try {
            val dm = c.applicationContext.getSystemService(DownloadManager::class.java) ?: return intArrayOf(-1, 0)
            dm.query(DownloadManager.Query().setFilterById(id)).use { k ->
                if (!k.moveToFirst()) return intArrayOf(-1, 0)
                val status = k.getInt(k.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val unduh = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val persen = if (total > 0) (unduh * 100 / total).toInt().coerceIn(0, 100) else 0
                return intArrayOf(status, persen)
            }
        } catch (_: Exception) { }
        return intArrayOf(-1, 0)
    }

    fun idUnduhan(c: Context): Long = sp(c).getLong("update_unduhan_id", -1L)

    /** True bila ada APK pembaruan yang sudah selesai diunduh, lebih baru dari versi terpasang, dan belum dipasang. */
    fun siapDipasang(c: Context): Boolean {
        val id = idUnduhan(c)
        if (id < 0) return false
        if (sp(c).getInt("update_target_versi", 0) <= versiSaatIni(c)) return false
        if (berkasApk(c)?.exists() != true) return false
        return progres(c, id)[0] == DownloadManager.STATUS_SUCCESSFUL
    }

    /** Menghapus APK pembaruan lama setelah aplikasi sudah berada di versi tersebut atau lebih baru. */
    fun bersihkan(c: Context) {
        try {
            if (sp(c).getInt("update_target_versi", 0) in 1..versiSaatIni(c)) {
                berkasApk(c)?.delete()
                sp(c).edit().remove("update_unduhan_id").remove("update_target_versi").apply()
            }
        } catch (_: Exception) { }
    }

    @Suppress("DEPRECATION")
    fun pasang(c: Context): Int {
        val app = c.applicationContext
        val f = berkasApk(app)
        if (f == null || !f.exists()) return PASANG_BERKAS_TIDAK_ADA
        // Pastikan berkas benar-benar APK aplikasi ini dan lebih baru dari yang terpasang.
        val arsip = try { app.packageManager.getPackageArchiveInfo(f.absolutePath, 0) } catch (_: Exception) { null }
        if (arsip == null || arsip.packageName != app.packageName) return PASANG_BERKAS_TIDAK_VALID
        val kodeArsip = if (Build.VERSION.SDK_INT >= 28) arsip.longVersionCode.toInt() else arsip.versionCode
        if (kodeArsip <= versiSaatIni(app)) return PASANG_BERKAS_TIDAK_VALID
        if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) return PASANG_BUTUH_IZIN
        return try {
            val installer = app.packageManager.packageInstaller
            val sesi = installer.openSession(installer.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)))
            sesi.use { s ->
                FileInputStream(f).use { masuk ->
                    s.openWrite("pembaruan.apk", 0, f.length()).use { keluar ->
                        masuk.copyTo(keluar)
                        s.fsync(keluar)
                    }
                }
                val i = Intent(app, UpdateInstallReceiver::class.java).setAction(AKSI_HASIL_PASANG)
                val flag = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                s.commit(PendingIntent.getBroadcast(app, 0, i, flag).intentSender)
            }
            PASANG_MULAI
        } catch (_: Exception) {
            PASANG_GAGAL
        }
    }
}
