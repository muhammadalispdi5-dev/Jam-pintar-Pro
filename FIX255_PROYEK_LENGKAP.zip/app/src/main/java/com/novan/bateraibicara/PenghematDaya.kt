package com.novan.bateraibicara

import android.app.Activity
import android.content.Context
import android.os.Bundle

/** Pengaturan hemat daya lokal aplikasi. Tidak mengubah pengaturan baterai Android. */
object PenghematDaya {
    private const val NAMA_PREFS = "pengaturan"
    private const val KEY_AKTIF = "penghemat_daya_global_aktif"
    private const val KEY_LEVEL = "penghemat_daya_global_level_kecerahan"

    fun aktif(context: Context): Boolean = context.getSharedPreferences(NAMA_PREFS, Context.MODE_PRIVATE)
        .getBoolean(KEY_AKTIF, false)

    fun level(context: Context): Int = context.getSharedPreferences(NAMA_PREFS, Context.MODE_PRIVATE)
        .getInt(KEY_LEVEL, 1).coerceIn(0, 2)

    fun simpanAktif(context: Context, aktif: Boolean) {
        context.getSharedPreferences(NAMA_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, aktif).apply()
    }

    fun simpanLevel(context: Context, level: Int) {
        context.getSharedPreferences(NAMA_PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_LEVEL, level.coerceIn(0, 2)).apply()
    }

    /** Dipanggil oleh kelas dasar Halaman, sehingga semua halaman utama mewarisi pengaturan ini. */
    fun terapkan(activity: Activity) {
        val p = activity.getSharedPreferences(NAMA_PREFS, Context.MODE_PRIVATE)
        val aktif = p.getBoolean(KEY_AKTIF, false)
        val level = p.getInt(KEY_LEVEL, 1).coerceIn(0, 2)
        val params = activity.window.attributes
        params.screenBrightness = if (!aktif) {
            android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        } else {
            floatArrayOf(0.20f, 0.35f, 0.50f)[level]
        }
        activity.window.attributes = params
    }
}

/** Satu pintu pengaturan hemat daya untuk seluruh halaman Jam Pintar Pro. */
class PenghematDayaActivity : Halaman() {
    override val judulHalaman: Int = R.string.judul

    override fun bangun() {
        bagian(tr("Penghemat daya seluruh aplikasi", "App-wide power saving"))
        info(tr(
            "Pengaturan ini berlaku pada seluruh halaman Jam Pintar Pro. Saat diaktifkan, aplikasi menurunkan kecerahan layar agar layar menggunakan lebih sedikit daya. Pengaturan kecerahan asli Android akan dipulihkan ketika mode dimatikan.",
            "This setting applies across all Jam Pintar Pro screens. When enabled, the app lowers screen brightness to reduce display power use. Android's normal brightness setting is restored when this mode is turned off."
        ))

        saklar(tr("Aktifkan penghemat daya", "Enable power saving"), PenghematDaya.aktif(this)) { aktif ->
            PenghematDaya.simpanAktif(this, aktif)
            PenghematDaya.terapkan(this)
            toast(tr(if (aktif) "Penghemat daya diaktifkan." else "Penghemat daya dimatikan.", if (aktif) "Power saving enabled." else "Power saving disabled."))
        }

        bagian(tr("Tingkat penghematan layar", "Screen saving level"))
        val daftarTingkat = listOf(
            tr("Hemat tinggi — kecerahan 20%", "High saving — 20% brightness"),
            tr("Seimbang — kecerahan 35%", "Balanced — 35% brightness"),
            tr("Ringan — kecerahan 50%", "Light — 50% brightness")
        )
        pilihan(tr("Pilih tingkat kecerahan", "Choose brightness level"), daftarTingkat, PenghematDaya.level(this)) { level ->
            PenghematDaya.simpanLevel(this, level)
            PenghematDaya.terapkan(this)
            toast(tr("Tingkat penghematan diperbarui.", "Power saving level updated."))
        }

        bagian(tr("Fitur penting tetap berjalan", "Important features remain available"))
        info(tr(
            "Mode ini tidak mematikan alarm, azan, jadwal salat, pengingat, layanan asisten suara, atau pemutaran audio Al-Qur'an. Penghematan terutama berasal dari pengurangan kecerahan layar ketika halaman aplikasi sedang tampil. Mode ini tidak menggantikan pengaturan hemat baterai Android atau izin berjalan di latar belakang.",
            "This mode does not turn off alarms, adhan, prayer schedules, reminders, voice assistant services, or Qur'an audio playback. Savings mainly come from reducing screen brightness while an app screen is visible. It does not replace Android battery settings or background permissions."
        ))

        tombol(tr("Matikan dan pulihkan kecerahan normal", "Turn off and restore normal brightness")) {
            PenghematDaya.simpanAktif(this, false)
            PenghematDaya.terapkan(this)
            recreate()
            toast(tr("Kecerahan normal dipulihkan.", "Normal brightness restored."))
        }
    }
}
