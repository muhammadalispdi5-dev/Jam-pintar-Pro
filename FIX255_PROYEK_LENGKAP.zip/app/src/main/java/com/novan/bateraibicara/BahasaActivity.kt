package com.novan.bateraibicara

import android.content.Intent

/** Satu tempat untuk bahasa antarmuka dan bahasa pengucapan. */
class BahasaActivity : Halaman() {
    override val judulHalaman = R.string.pengaturan_bahasa

    override fun bangun() {
        var tampilanTerpilih = BahasaAplikasi.tampilan(this)
        var ucapanTerpilih = prefs.jamBahasaIdx
        bagian(getString(R.string.bahasa_tampilan_utama))
        pilihan(getString(R.string.bahasa_tampilan_utama), listOf("Bahasa Indonesia", "English"), tampilanTerpilih) {
            tampilanTerpilih = it
        }
        info(getString(R.string.info_pengaturan_bahasa))
        bagian(getString(R.string.bahasa_pengucapan))
        pilihan(getString(R.string.bahasa_pengucapan), larik(R.array.jam_bahasa), ucapanTerpilih) {
            ucapanTerpilih = it
        }
        info(getString(R.string.info_bahasa_pengucapan))
        tombol(getString(R.string.tombol_simpan_bahasa)) {
            BahasaAplikasi.simpanTampilan(this, tampilanTerpilih)
            prefs.jamBahasaIdx = ucapanTerpilih
            muatUlang()
            // Buat ulang seluruh halaman agar bahasa tampilan diterapkan sejak konteks dibuat.
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(i)
            finish()
        }
    }
}
