package com.novan.bateraibicara

/**
 * FIX245: aturan tunggal untuk menentukan aplikasi mana yang sudah punya sakelar notifikasi sendiri (Gojek, Grab, inDrive,
 * Maxim, email, SMS, WhatsApp) dan mana yang boleh dipilih pada "Pilih aplikasi yang akan dibacakan".
 * Dipakai bersama oleh CallerListener (pembaca notifikasi) dan PemanggilActivity (daftar pilihan) agar keduanya selalu sejalan.
 *
 * Sebelumnya semua paket yang mengandung "gojek", "grab", "mail", dan sebagainya dianggap aplikasi transportasi atau email,
 * sehingga GoPay, GoPay Merchant, dan aplikasi lain sekeluarga tidak muncul pada daftar pilihan dan notifikasinya tidak dibacakan.
 * Kini hanya aplikasi yang memang dimaksud oleh sakelar tersebut yang dikecualikan.
 * Murni logika Kotlin (tanpa Android) agar dapat diuji dengan kotlinc.
 */
object KategoriNotifApp {
    const val EMAIL = "email"
    const val GOJEK = "gojek"
    const val GRAB = "grab"
    const val INDRIVE = "indrive"
    const val MAXIM = "maxim"

    private val PESAN_SELULER = Regex("messaging|mms|sms")

    fun pesanSeluler(pkg: String): Boolean = PESAN_SELULER.containsMatchIn(pkg.lowercase())

    fun whatsapp(pkg: String): Boolean = pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"

    private fun adaBagian(p: String, cocok: (String) -> Boolean) = p.split('.').any(cocok)

    /** Kategori aplikasi yang mempunyai sakelar tersendiri, atau null bila aplikasi itu aplikasi umum (boleh dipilih). */
    fun kategori(pkg: String): String? {
        val p = pkg.lowercase()
        return when {
            // Gojek (penumpang dan mitra pengemudi). GoPay, GoPay Merchant, GoBiz, dan lainnya TIDAK termasuk.
            p == "com.gojek.app" || p.startsWith("com.gojek.driver") || p.startsWith("com.gojek.partner.driver") -> GOJEK
            // Grab penumpang dan pengemudi. GrabFood merchant, OVO, dan lainnya tidak termasuk.
            p.startsWith("com.grabtaxi.") -> GRAB
            p.contains("indriver") || p.contains("indrive") -> INDRIVE
            p.contains("taxsee") || adaBagian(p) { it == "maxim" || it == "maximapp" } -> MAXIM
            p == "com.google.android.gm" || p == "com.microsoft.office.outlook" ||
                p == "com.samsung.android.email.provider" || p == "com.yahoo.mobile.client.android.mail" ||
                p == "com.android.email" || p == "com.fsck.k9" ||
                adaBagian(p) { it != "voicemail" && (it == "email" || it == "mail" || it.endsWith("mail")) } -> EMAIL
            else -> null
        }
    }

    /** Aplikasi sudah punya sakelar sendiri, jadi tidak ditawarkan lagi pada pilihan aplikasi tambahan. */
    fun punyaSakelarSendiri(pkg: String): Boolean = whatsapp(pkg) || pesanSeluler(pkg) || kategori(pkg) != null
}
