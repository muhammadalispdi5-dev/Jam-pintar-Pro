package com.novan.bateraibicara

/**
 * FIX227/FIX228: pendeteksi pola tombol fisik untuk membuka perintah suara. Kelas ini murni logika (tanpa Android)
 * agar dapat diuji terpisah. Dipanggil dari satu thread.
 *
 * FIX228: semua penilaian waktu memakai waktu KEDATANGAN peristiwa (uptime milidetik yang diberikan pemanggil), bukan
 * downTime/eventTime peristiwa, karena peristiwa yang diteruskan ulang oleh layanan aksesibilitas dapat berubah cap waktunya.
 * Pola "tahan" tidak lagi bergantung pada peristiwa pengulangan tombol (sebagian HP tidak mengirimnya untuk volume atas);
 * pemanggil menjadwalkan pemeriksaan waktu lewat [cekTahan]. Pola "bersamaan" tidak lagi mensyaratkan selisih downTime.
 *
 * Mode: TAHAN_ATAS / TAHAN_BAWAH (ditahan [tahanMs]), DUA_VOLUME (kedua volume ditekan dalam [SELISIH_BERSAMAAN_MS]),
 * DUA_KALI_ATAS / DUA_KALI_BAWAH (dua tekanan dalam [JEDA_DUA_KALI_MS]), AKSESIBILITAS (ditangani layanan, bukan tombol fisik).
 * Hasil: LEWAT = teruskan ke sistem; TELAN = jangan teruskan; PICU = pola dikenali (peristiwa ditelan).
 */
class PemicuTombol {
    enum class Mode { NONAKTIF, TAHAN_ATAS, TAHAN_BAWAH, DUA_VOLUME, DUA_KALI_ATAS, DUA_KALI_BAWAH, AKSESIBILITAS }
    enum class Hasil { LEWAT, TELAN, PICU }

    var mode: Mode = Mode.NONAKTIF
        set(nilai) { if (field != nilai) { field = nilai; reset() } }
    var tahanMs: Long = 800L

    private var atasTekan = false
    private var bawahTekan = false
    private var awalAtas = 0L
    private var awalBawah = 0L
    private var sudahPicu = false
    private var waktuPicu = 0L
    private var tekanTerakhirAtas = -1_000_000L
    private var tekanTerakhirBawah = -1_000_000L

    fun reset() {
        atasTekan = false; bawahTekan = false; sudahPicu = false
        tekanTerakhirAtas = -1_000_000L; tekanTerakhirBawah = -1_000_000L
    }

    /** true bila [kode] adalah tombol yang dipantau oleh mode pola tahan saat ini. */
    fun tombolTahan(kode: Int): Boolean =
        (mode == Mode.TAHAN_ATAS && kode == KODE_ATAS) || (mode == Mode.TAHAN_BAWAH && kode == KODE_BAWAH)

    /**
     * @param kode KEYCODE_VOLUME_UP (24) atau KEYCODE_VOLUME_DOWN (25); kode lain selalu LEWAT.
     * @param turun true untuk ACTION_DOWN, false untuk ACTION_UP
     * @param ulang repeatCount peristiwa
     * @param waktu waktu kedatangan peristiwa (uptime, ms)
     */
    fun proses(kode: Int, turun: Boolean, ulang: Int, waktu: Long): Hasil {
        val atas = kode == KODE_ATAS
        val bawah = kode == KODE_BAWAH
        if (!atas && !bawah) return Hasil.LEWAT
        if (mode == Mode.NONAKTIF || mode == Mode.AKSESIBILITAS) return Hasil.LEWAT

        if (!turun) {
            val telan = sudahPicu
            if (atas) atasTekan = false else bawahTekan = false
            if (!atasTekan && !bawahTekan) sudahPicu = false
            return if (telan) Hasil.TELAN else Hasil.LEWAT
        }

        val tekananBaru = ulang == 0 || !(if (atas) atasTekan else bawahTekan)
        if (tekananBaru) {
            // Tekanan baru; status "sudah picu" yang tertinggal (peristiwa lepas tidak sampai) dibersihkan.
            if (sudahPicu && waktu - waktuPicu > 1000L) sudahPicu = false
            if (atas) { atasTekan = true; awalAtas = waktu } else { bawahTekan = true; awalBawah = waktu }
        }

        return when (mode) {
            Mode.TAHAN_ATAS -> tahan(atas, tekananBaru, waktu)
            Mode.TAHAN_BAWAH -> tahan(bawah, tekananBaru, waktu)
            Mode.DUA_VOLUME -> {
                if (!tekananBaru) return if (sudahPicu) Hasil.TELAN else Hasil.LEWAT
                val lain = if (atas) bawahTekan else atasTekan
                val awalLain = if (atas) awalBawah else awalAtas
                if (lain && !sudahPicu && waktu - awalLain <= SELISIH_BERSAMAAN_MS) {
                    sudahPicu = true; waktuPicu = waktu
                    Hasil.PICU
                } else Hasil.LEWAT
            }
            Mode.DUA_KALI_ATAS -> duaKali(atas, tekananBaru, waktu, true)
            Mode.DUA_KALI_BAWAH -> duaKali(bawah, tekananBaru, waktu, false)
            else -> Hasil.LEWAT
        }
    }

    private fun tahan(sasaran: Boolean, tekananBaru: Boolean, waktu: Long): Hasil {
        if (!sasaran) return Hasil.LEWAT
        // Tekanan pertama diteruskan (volume berubah satu langkah; layanan mengembalikannya saat pola dikenali).
        if (tekananBaru) return Hasil.LEWAT
        if (sudahPicu) return Hasil.TELAN
        val awal = if (mode == Mode.TAHAN_ATAS) awalAtas else awalBawah
        if (waktu - awal >= tahanMs) {
            sudahPicu = true; waktuPicu = waktu
            return Hasil.PICU
        }
        // Pengulangan sebelum batas waktu ditelan agar volume tidak berubah terus selama ditahan.
        return Hasil.TELAN
    }

    /**
     * Dipanggil oleh pewaktu setelah [tahanMs] sejak tombol ditekan, untuk HP yang tidak mengirim peristiwa pengulangan.
     * @return true bila pola tahan baru saja dikenali (tombol masih ditekan dan belum dipicu).
     */
    fun cekTahan(waktu: Long): Boolean {
        val atas = mode == Mode.TAHAN_ATAS
        if (!atas && mode != Mode.TAHAN_BAWAH) return false
        val tekan = if (atas) atasTekan else bawahTekan
        val awal = if (atas) awalAtas else awalBawah
        if (!tekan || sudahPicu || waktu - awal < tahanMs) return false
        sudahPicu = true; waktuPicu = waktu
        return true
    }

    private fun duaKali(sasaran: Boolean, tekananBaru: Boolean, waktu: Long, atas: Boolean): Hasil {
        if (!sasaran) return Hasil.LEWAT
        if (!tekananBaru) return if (sudahPicu) Hasil.TELAN else Hasil.LEWAT
        val terakhir = if (atas) tekanTerakhirAtas else tekanTerakhirBawah
        if (waktu - terakhir <= JEDA_DUA_KALI_MS) {
            if (atas) tekanTerakhirAtas = -1_000_000L else tekanTerakhirBawah = -1_000_000L
            sudahPicu = true; waktuPicu = waktu
            return Hasil.PICU
        }
        if (atas) tekanTerakhirAtas = waktu else tekanTerakhirBawah = waktu
        return Hasil.LEWAT
    }

    companion object {
        const val KODE_ATAS = 24
        const val KODE_BAWAH = 25
        const val SELISIH_BERSAMAAN_MS = 800L
        const val JEDA_DUA_KALI_MS = 600L

        fun modeDariIndeks(i: Int): Mode = Mode.values().getOrElse(i) { Mode.NONAKTIF }
    }
}
