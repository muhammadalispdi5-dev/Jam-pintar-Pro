package com.novan.bateraibicara

import android.content.Intent
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.TextView
import android.widget.Toast

/** Pengelola model bahasa pengenal suara offline yang dikelola oleh layanan Android. */
class PaketBahasaOfflineActivity : Halaman() {
    override val judulHalaman = R.string.judul_paket_bahasa_offline

    private lateinit var status: TextView
    private var recognizer: SpeechRecognizer? = null
    private var pemeriksaanBerjalan = false
    private var bahasaTag: String = "id-ID"
    private var mesinDipilih: ComponentName? = null

    private fun bahasaAktif(): String = if (BahasaAplikasi.tampilan(this) == 1) "en-US" else "id-ID"

    private fun intentPengenalan(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, bahasaTag)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, bahasaTag)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }

    override fun bangun() {
        bahasaTag = bahasaAktif()
        mesinDipilih = PengenalSuaraTerpasang.dipilih(this)
        info(tr(
            "Halaman ini memeriksa dan meminta pengunduhan model bahasa offline dari layanan pengenal suara Android. Paket bahasa tidak disimpan atau dibuat sendiri oleh Jam Pintar Pro. Ketersediaannya mengikuti HP dan layanan pengenal suara yang digunakan.",
            "This page checks for and requests offline language models from Android's speech recognition service. Jam Pintar Pro does not create or host language packs. Availability depends on your phone and its speech recognition service."
        ))
        bagian(tr("Mesin pengenal suara di ponsel", "Speech recognition engines on this phone"))
        tampilkanDaftarMesin()
        bagian(tr("Bahasa pengenalan yang diperiksa", "Recognition language being checked"))
        info(if (bahasaTag == "en-US") "English (United States)" else "Bahasa Indonesia (Indonesia)")
        status = info(tr("Status paket belum diperiksa.", "Language pack status has not been checked."))
        tombol(tr("Periksa ketersediaan paket bahasa", "Check language pack availability")) { periksaPaket() }
        tombol(tr("Unduh paket bahasa offline", "Download offline language pack")) { unduhPaket() }
        tombol(tr("Buka pengaturan pengenal suara Android", "Open Android speech recognition settings")) { bukaPengaturanSuara() }
        info(tr(
            "Catatan: tombol unduh meminta layanan pengenal suara mengunduh model untuk bahasa aplikasi yang sedang aktif. Android atau layanan Google dapat menampilkan notifikasi/proses unduhan sendiri. Jika bahasa tidak didukung offline, gunakan pengenalan suara dengan internet.",
            "Note: Download requests the speech recognition service to fetch the model for the app's active language. Android or Google services may show their own download notification or progress. If the language is not supported offline, use speech recognition with an internet connection."
        ))
        tombol(tr("Uji perintah suara sekarang", "Test voice command now")) {
            startActivity(Intent(this, PerintahSuaraActivity::class.java)
                .putExtra(PerintahSuaraActivity.EXTRA_DARI_APLIKASI, true)
                .putExtra(PerintahSuaraActivity.EXTRA_UJI_PAKET_OFFLINE, true))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && !pemeriksaanBerjalan) periksaPaket()
    }

    private fun tampilkanDaftarMesin() {
        val mesin = PengenalSuaraTerpasang.daftar(this)
        if (mesin.isEmpty()) {
            info(tr("Belum ditemukan mesin pengenal suara yang dapat dipilih. Aplikasi akan mencoba layanan bawaan Android.", "No selectable speech recognition engine was found. The app will try Android's default service."))
            return
        }
        val aktif = PengenalSuaraTerpasang.dipilih(this)
        info(tr("Pilih mesin yang akan digunakan untuk pemeriksaan, permintaan unduhan, dan perintah suara. Jika tidak memilih, aplikasi menggunakan mesin bawaan Android.", "Choose the engine for language checks, download requests, and voice commands. If none is selected, the app uses Android's default engine."))
        tombol(tr("Gunakan mesin bawaan Android", "Use Android default engine")) {
            PengenalSuaraTerpasang.simpan(this, null)
            mesinDipilih = null
            Toast.makeText(this, tr("Mesin bawaan Android dipilih.", "Android default engine selected."), Toast.LENGTH_SHORT).show()
            recreate()
        }
        mesin.forEach { item ->
            val terpilih = item.komponen == aktif
            tombol((if (terpilih) tr("Terpilih: ", "Selected: ") else "") + item.nama + " — " + item.paket) {
                PengenalSuaraTerpasang.simpan(this, item.komponen)
                mesinDipilih = item.komponen
                Toast.makeText(this, tr("Mesin dipilih: ", "Selected engine: ") + item.nama, Toast.LENGTH_SHORT).show()
                recreate()
            }
        }
    }

    private fun buatRecognizer(): SpeechRecognizer {
        val komponen = PengenalSuaraTerpasang.dipilih(this)
        if (komponen != null && !PengenalSuaraTerpasang.pilihanMasihTersedia(this)) {
            throw IllegalStateException(tr(
                "Mesin yang pernah dipilih sudah tidak tersedia. Pilih mesin lain atau gunakan mesin bawaan Android.",
                "The previously selected engine is no longer available. Choose another engine or use Android's default service."
            ))
        }
        return if (komponen != null) SpeechRecognizer.createSpeechRecognizer(this, komponen)
        else SpeechRecognizer.createSpeechRecognizer(this)
    }

    private fun periksaPaket() {
        bahasaTag = bahasaAktif()
        if (Build.VERSION.SDK_INT < 33) {
            tampilkanStatus(tr(
                "Android versi ini tidak menyediakan pemeriksaan model bahasa melalui aplikasi. Buka pengaturan pengenal suara Android untuk memeriksa atau mengunduh bahasa jika tersedia.",
                "This Android version does not expose language-model status to apps. Open Android speech recognition settings to check or download a language if available."
            ))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            tampilkanStatus(tr(
                "Tidak ditemukan layanan pengenal suara. Pasang atau aktifkan layanan pengenal suara yang mendukung Android, lalu periksa kembali.",
                "No speech recognition service was found. Install or enable an Android-compatible speech recognition service, then check again."
            ))
            return
        }
        val sr = try { buatRecognizer() } catch (e: Exception) {
            tampilkanStatus(tr("Layanan pengenal suara tidak dapat dibuka: ", "Speech recognition service could not be opened: ") + (e.message ?: ""))
            return
        }
        recognizer?.destroy()
        recognizer = sr
        pemeriksaanBerjalan = true
        tampilkanStatus(tr("Sedang memeriksa dukungan bahasa…", "Checking language support…"))
        try {
            sr.checkRecognitionSupport(intentPengenalan(), mainExecutor, object : RecognitionSupportCallback {
                override fun onSupportResult(support: RecognitionSupport) {
                    pemeriksaanBerjalan = false
                    val terpasang = support.installedOnDeviceLanguages
                    val didukung = support.supportedOnDeviceLanguages
                    val tertunda = support.pendingOnDeviceLanguages
                    val daring = support.onlineLanguages
                    val label = if (bahasaTag == "en-US") "English" else "Bahasa Indonesia"
                    val hasil = when {
                        terpasang.any { it.equals(bahasaTag, true) || it.substringBefore('-').equals(bahasaTag.substringBefore('-'), true) } ->
                            tr("Paket offline sudah terpasang dan terdeteksi.", "The offline language pack is installed and detected.")
                        tertunda.any { it.equals(bahasaTag, true) || it.substringBefore('-').equals(bahasaTag.substringBefore('-'), true) } ->
                            tr("Pengunduhan paket offline " + label + " sedang menunggu atau berlangsung.", "The " + label + " offline language pack download is pending or in progress.")
                        didukung.any { it.equals(bahasaTag, true) || it.substringBefore('-').equals(bahasaTag.substringBefore('-'), true) } ->
                            tr("Layanan mendukung " + label + " secara offline, tetapi paketnya belum terdeteksi terpasang. Tekan Unduh paket bahasa offline.", "The service supports " + label + " offline, but its pack is not detected as installed. Tap Download offline language pack.")
                        daring.any { it.equals(bahasaTag, true) || it.substringBefore('-').equals(bahasaTag.substringBefore('-'), true) } ->
                            tr(label + " tersedia melalui pengenalan daring, tetapi belum terdaftar sebagai bahasa offline yang didukung.", label + " is available for online recognition, but is not listed as an available offline language.")
                        else -> tr("Layanan tidak melaporkan dukungan offline untuk " + label + ". Anda masih dapat mencoba pengenalan suara dengan internet atau memilih layanan lain di pengaturan Android.", "The service does not report offline support for " + label + ". You can still try online recognition or choose another service in Android settings.")
                    }
                    tampilkanStatus(hasil)
                }
                override fun onError(error: Int) {
                    pemeriksaanBerjalan = false
                    tampilkanStatus(tr("Pemeriksaan gagal (kode ", "The check failed (code ") + error + tr("). Buka pengaturan pengenal suara Android.", "). Open Android speech recognition settings."))
                }
            })
        } catch (e: Exception) {
            pemeriksaanBerjalan = false
            tampilkanStatus(tr("Pemeriksaan tidak didukung oleh layanan ini: ", "This service does not support the check: ") + (e.message ?: ""))
        }
    }

    private fun unduhPaket() {
        bahasaTag = bahasaAktif()
        if (Build.VERSION.SDK_INT < 33) {
            Toast.makeText(this, tr("Unduhan model dari aplikasi memerlukan Android 13 atau lebih baru. Silakan buka pengaturan pengenal suara.", "In-app model download requires Android 13 or later. Please open speech recognition settings."), Toast.LENGTH_LONG).show()
            bukaPengaturanSuara()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            tampilkanStatus(tr("Tidak ada layanan pengenal suara. Aktifkan atau pasang layanan pengenal suara terlebih dahulu.", "No speech recognition service is available. Enable or install one first."))
            bukaPengaturanSuara()
            return
        }
        try {
            val sr = buatRecognizer()
            recognizer?.destroy()
            recognizer = sr
            sr.triggerModelDownload(intentPengenalan())
            tampilkanStatus(tr(
                "Permintaan unduhan paket bahasa sudah dikirim ke layanan pengenal suara. Pantau notifikasi atau pengaturan layanan tersebut. Setelah selesai, tekan Periksa ketersediaan paket bahasa.",
                "The language pack download request was sent to the speech recognition service. Check its notification or settings. When finished, tap Check language pack availability."
            ))
        } catch (e: Exception) {
            tampilkanStatus(tr("Layanan tidak dapat memulai unduhan: ", "The service could not start the download: ") + (e.message ?: ""))
            bukaPengaturanSuara()
        }
    }

    private fun bukaPengaturanSuara() {
        val kandidat = listOf(
            Intent("android.settings.VOICE_INPUT_SETTINGS"),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in kandidat) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: Exception) { }
        }
        Toast.makeText(this, tr("Pengaturan Android tidak dapat dibuka.", "Android settings could not be opened."), Toast.LENGTH_LONG).show()
    }

    private fun tampilkanStatus(pesan: String) {
        if (!::status.isInitialized) return
        status.text = pesan
        status.contentDescription = pesan
        status.announceForAccessibility(pesan)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
}
