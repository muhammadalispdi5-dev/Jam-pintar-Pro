package com.novan.bateraibicara

import com.novan.bateraibicara.KhutbahData.Blok

/** FIX204: bacaan baku khutbah (pembuka pertama, pembuka kedua, doa penutup) yang dipakai semua naskah. */
object KhutbahBaku {
    private fun teks(arab: String, id: String, en: String, sumber: String? = null) = Blok(arab, id, en, sumber)

    val pembukaPertama = teks(
        "إِنَّ الْحَمْدَ لِلَّهِ نَحْمَدُهُ وَنَسْتَعِينُهُ وَنَسْتَغْفِرُهُ، وَنَعُوذُ بِاللَّهِ مِنْ شُرُورِ أَنْفُسِنَا وَمِنْ سَيِّئَاتِ أَعْمَالِنَا، مَنْ يَهْدِهِ اللَّهُ فَلَا مُضِلَّ لَهُ، وَمَنْ يُضْلِلْ فَلَا هَادِيَ لَهُ. وَأَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ. اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ وَعَلَى آلِهِ وَصَحْبِهِ أَجْمَعِينَ.",
        "Segala puji bagi Allah. Kita memuji-Nya, memohon pertolongan dan ampunan-Nya, serta berlindung kepada-Nya dari keburukan diri dan kejahatan amal kita. Siapa yang Allah beri petunjuk, tidak ada yang dapat menyesatkannya; siapa yang Dia sesatkan, tidak ada yang dapat memberinya petunjuk. Aku bersaksi tiada Tuhan selain Allah semata, tiada sekutu bagi-Nya, dan bahwa Muhammad adalah hamba dan utusan-Nya. Ya Allah, limpahkanlah shalawat dan salam kepada Nabi kita Muhammad, keluarga, dan seluruh sahabatnya.",
        "All praise is for Allah. We praise Him, seek His help and forgiveness, and seek refuge in Him from the evil of ourselves and the wrongs of our deeds. Whoever Allah guides, none can misguide; whoever He lets go astray, none can guide. I bear witness that there is no god but Allah alone, with no partner, and that Muhammad is His servant and Messenger. O Allah, send blessings and peace upon our Prophet Muhammad, his family, and all his companions."
    )

    val pembukaKedua = teks(
        "الْحَمْدُ لِلَّهِ عَلَى إِحْسَانِهِ، وَالشُّكْرُ لَهُ عَلَى تَوْفِيقِهِ وَامْتِنَانِهِ، وَأَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ. اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ وَعَلَى آلِهِ وَصَحْبِهِ أَجْمَعِينَ.",
        "Segala puji bagi Allah atas kebaikan-Nya, dan syukur kepada-Nya atas taufik dan karunia-Nya. Aku bersaksi tiada Tuhan selain Allah semata, tiada sekutu bagi-Nya, dan bahwa Muhammad adalah hamba dan utusan-Nya. Ya Allah, limpahkanlah shalawat dan salam kepada Nabi kita Muhammad, keluarga, dan seluruh sahabatnya.",
        "All praise is for Allah for His kindness, and thanks to Him for His guidance and favor. I bear witness that there is no god but Allah alone, with no partner, and that Muhammad is His servant and Messenger. O Allah, send blessings and peace upon our Prophet Muhammad, his family, and all his companions."
    )

    val penutupDoa = listOf(
        teks(
            "اللَّهُمَّ اغْفِرْ لِلْمُسْلِمِينَ وَالْمُسْلِمَاتِ وَالْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ، الْأَحْيَاءِ مِنْهُمْ وَالْأَمْوَاتِ. رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.",
            "Ya Allah, ampunilah kaum muslimin dan muslimat, kaum mukminin dan mukminat, yang masih hidup maupun yang telah wafat. Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, dan lindungilah kami dari azab neraka.",
            "O Allah, forgive the Muslim men and women and the believing men and women, the living among them and the dead. Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
            "Doa penutup"
        ),
        teks(
            "عِبَادَ اللَّهِ، إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ وَالْإِحْسَانِ وَإِيتَاءِ ذِي الْقُرْبَى وَيَنْهَى عَنِ الْفَحْشَاءِ وَالْمُنْكَرِ وَالْبَغْيِ، يَعِظُكُمْ لَعَلَّكُمْ تَذَكَّرُونَ. فَاذْكُرُوا اللَّهَ الْعَظِيمَ يَذْكُرْكُمْ، وَاشْكُرُوهُ عَلَى نِعَمِهِ يَزِدْكُمْ، وَلَذِكْرُ اللَّهِ أَكْبَرُ.",
            "Hamba-hamba Allah, sungguh Allah memerintahkan berlaku adil, berbuat kebajikan, dan memberi kepada kerabat, serta melarang perbuatan keji, kemungkaran, dan permusuhan. Dia memberi pengajaran kepada kalian agar kalian mengambil pelajaran. Maka ingatlah Allah Yang Maha Agung, niscaya Dia mengingat kalian; bersyukurlah atas nikmat-nikmat-Nya, niscaya Dia menambahkannya; dan sungguh mengingat Allah itu lebih besar.",
            "Servants of Allah, Allah commands justice, good conduct, and giving to relatives, and forbids indecency, wrongdoing, and oppression. He admonishes you so that you may take heed. So remember Allah the Almighty and He will remember you; thank Him for His blessings and He will increase them; and remembering Allah is greater.",
            "Al-Qur'an, An-Nahl 16:90"
        )
    )
}
