package com.novan.bateraibicara

import android.content.Context
import android.location.Geocoder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * FIX254: tempat lain yang disebut pengguna pada perintah cuaca ("cuaca di Mekkah besok", "prediksi BMKG di Bandung").
 * Bagian [ekstrak] dan [dariTabel] murni logika agar dapat diuji; pencarian koordinat memakai tabel bawaan,
 * lalu layanan geokode Open-Meteo, lalu Geocoder perangkat.
 */
object TempatDisebut {
    class Tempat(val lat: Double, val lon: Double, val nama: String, val kodeNegara: String)

    private val penanda = setOf("di", "in", "untuk", "for", "at", "kota", "kabupaten", "city", "wilayah", "daerah", "provinsi", "negara")
    private val pemicu = setOf("cuaca", "weather", "forecast", "prakiraan", "prediksi", "perkiraan", "ramalan", "bmkg", "hujan", "suhu", "angin", "temperature")
    private val henti = setOf("hari", "ini", "sekarang", "besok", "lusa", "today", "tomorrow", "now", "tonight", "nanti", "malam", "pagi", "siang", "sore",
        "bagaimana", "gimana", "apa", "apakah", "berapa", "ya", "dong", "tolong", "please", "kah", "akan", "turun", "hujankah", "nya", "lagi", "minggu", "this", "week",
        "untuk", "for", "how", "what", "is", "will", "it", "be", "like", "yang", "dan", "and", "atau", "or", "bmkg", "menurut", "according", "sampai", "hingga", "selama")
    private val bukanTempat = setOf("sini", "sana", "saya", "aku", "kita", "kami", "sekitar", "lokasi", "terkini", "here", "me", "my", "our", "current", "location", "kini",
        "luar", "outside", "rumah", "home", "ruangan", "perangkat", "hp", "ponsel", "phone", "device", "baterai", "battery", "jadwal", "sholat", "salat", "shalat", "prayer",
        "payung", "umbrella", "uv", "kelembapan", "humidity", "peringatan", "dini", "early", "warning", "ekstrem", "extreme", "terkait", "tentang")

    /** Nama tempat yang disebut dalam ucapan cuaca (huruf kecil, tanpa tanda baca); null bila tidak ada atau hanya lokasi pengguna sendiri. */
    fun ekstrak(t: List<String>): String? {
        if (t.none { it in pemicu || it == "payung" || it == "umbrella" }) return null
        fun bersih(sisa: List<String>): String? {
            val k = sisa.dropWhile { it in penanda }.takeWhile { it !in henti }
            if (k.isEmpty() || k.any { it in bukanTempat }) return null
            return k.take(4).joinToString(" ")
        }
        // 1) kata penanda ("di", "untuk", "in") yang diikuti nama tempat
        for (i in t.indices) {
            if (t[i] in penanda) {
                val h = bersih(t.drop(i + 1))
                if (h != null) return h
            }
        }
        // 2) nama langsung setelah kata cuaca ("cuaca mekkah besok")
        val j = t.indexOfLast { it in setOf("cuaca", "weather", "forecast", "prakiraan", "prediksi", "perkiraan", "ramalan") }
        if (j >= 0) {
            val h = bersih(t.drop(j + 1))
            if (h != null) return h
        }
        // 3) "bmkg mekkah"
        val b = t.indexOf("bmkg")
        if (b >= 0) bersih(t.drop(b + 1))?.let { return it }
        return null
    }

    private fun norm(s: String): String = s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    // nama (ejaan lazim) -> lintang, bujur, nama tampil Indonesia, nama tampil Inggris, kode negara
    private class Baris(val kunci: List<String>, val lat: Double, val lon: Double, val id: String, val en: String, val negara: String)

    private val tabel = listOf(
        Baris(listOf("mekkah", "mekah", "makkah", "mecca", "makah", "mekka", "masjidil haram", "masjid al haram"), 21.4225, 39.8262, "Makkah, Arab Saudi", "Makkah, Saudi Arabia", "SA"),
        Baris(listOf("madinah", "medinah", "medina", "al madinah", "masjid nabawi"), 24.4672, 39.6111, "Madinah, Arab Saudi", "Madinah, Saudi Arabia", "SA"),
        Baris(listOf("jeddah", "jedah", "jiddah", "jidah"), 21.4858, 39.1925, "Jeddah, Arab Saudi", "Jeddah, Saudi Arabia", "SA"),
        Baris(listOf("arafah", "arafat", "padang arafah"), 21.3549, 39.9841, "Arafah, Arab Saudi", "Arafah, Saudi Arabia", "SA"),
        Baris(listOf("mina", "muna"), 21.4133, 39.8933, "Mina, Arab Saudi", "Mina, Saudi Arabia", "SA"),
        Baris(listOf("muzdalifah", "muzdalifa"), 21.3833, 39.9167, "Muzdalifah, Arab Saudi", "Muzdalifah, Saudi Arabia", "SA"),
        Baris(listOf("thaif", "taif", "tha if"), 21.2703, 40.4158, "Thaif, Arab Saudi", "Taif, Saudi Arabia", "SA"),
        Baris(listOf("riyadh", "riyad", "riyadl"), 24.7136, 46.6753, "Riyadh, Arab Saudi", "Riyadh, Saudi Arabia", "SA"),
        Baris(listOf("yerusalem", "jerusalem", "al quds", "baitul maqdis", "masjid al aqsa", "masjidil aqsa"), 31.7683, 35.2137, "Yerusalem", "Jerusalem", "IL"),
        Baris(listOf("kairo", "cairo", "al qahirah"), 30.0444, 31.2357, "Kairo, Mesir", "Cairo, Egypt", "EG"),
        Baris(listOf("istanbul", "istambul"), 41.0082, 28.9784, "Istanbul, Turki", "Istanbul, Turkey", "TR"),
        Baris(listOf("dubai", "dubay"), 25.2048, 55.2708, "Dubai, Uni Emirat Arab", "Dubai, United Arab Emirates", "AE"),
        Baris(listOf("doha"), 25.2854, 51.5310, "Doha, Qatar", "Doha, Qatar", "QA"),
        Baris(listOf("kuala lumpur", "kl"), 3.1390, 101.6869, "Kuala Lumpur, Malaysia", "Kuala Lumpur, Malaysia", "MY"),
        Baris(listOf("singapura", "singapore"), 1.3521, 103.8198, "Singapura", "Singapore", "SG"),
        Baris(listOf("london", "londres"), 51.5072, -0.1276, "London, Inggris", "London, United Kingdom", "GB"),
        Baris(listOf("paris"), 48.8566, 2.3522, "Paris, Prancis", "Paris, France", "FR"),
        Baris(listOf("tokyo", "tokio"), 35.6762, 139.6503, "Tokyo, Jepang", "Tokyo, Japan", "JP"),
        Baris(listOf("new york", "newyork"), 40.7128, -74.0060, "New York, Amerika Serikat", "New York, United States", "US"),
        Baris(listOf("sydney", "sidney"), -33.8688, 151.2093, "Sydney, Australia", "Sydney, Australia", "AU"),
        Baris(listOf("jakarta"), -6.2088, 106.8456, "Jakarta", "Jakarta", "ID"),
        Baris(listOf("surabaya"), -7.2575, 112.7521, "Surabaya", "Surabaya", "ID"),
        Baris(listOf("bandung"), -6.9175, 107.6191, "Bandung", "Bandung", "ID"),
        Baris(listOf("yogyakarta", "jogja", "jogjakarta"), -7.7956, 110.3695, "Yogyakarta", "Yogyakarta", "ID"),
        Baris(listOf("semarang"), -6.9667, 110.4167, "Semarang", "Semarang", "ID"),
        Baris(listOf("medan"), 3.5952, 98.6722, "Medan", "Medan", "ID"),
        Baris(listOf("makassar"), -5.1477, 119.4327, "Makassar", "Makassar", "ID"),
        Baris(listOf("palembang"), -2.9761, 104.7754, "Palembang", "Palembang", "ID"),
        Baris(listOf("denpasar", "bali"), -8.6705, 115.2126, "Denpasar, Bali", "Denpasar, Bali", "ID"),
        Baris(listOf("balikpapan"), -1.2379, 116.8529, "Balikpapan", "Balikpapan", "ID"),
        Baris(listOf("manado"), 1.4748, 124.8421, "Manado", "Manado", "ID"),
        Baris(listOf("jayapura"), -2.5337, 140.7181, "Jayapura", "Jayapura", "ID"),
        Baris(listOf("banda aceh"), 5.5483, 95.3238, "Banda Aceh", "Banda Aceh", "ID"),
        Baris(listOf("malang"), -7.9666, 112.6326, "Malang", "Malang", "ID"),
        Baris(listOf("pontianak"), -0.0263, 109.3425, "Pontianak", "Pontianak", "ID")
    )

    /** Cari di tabel bawaan; cocok penuh pada nama atau frasa. */
    fun dariTabel(nama: String, inggris: Boolean = false): Tempat? {
        val n = norm(nama)
        if (n.isEmpty()) return null
        val b = tabel.firstOrNull { r -> r.kunci.any { it == n } } ?: tabel.firstOrNull { r -> r.kunci.any { it.length > 3 && (n.contains(it) || it.contains(n) && n.length > 3) } }
        return b?.let { Tempat(it.lat, it.lon, if (inggris) it.en else it.id, it.negara) }
    }

    private fun unduh(alamat: String): String {
        val c = URL(alamat).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"; c.connectTimeout = 8_000; c.readTimeout = 10_000; c.useCaches = false
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "JamPintarPro/1.0.88 (Android)")
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP_STATUS:" + c.responseCode)
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { try { c.disconnect() } catch (_: Exception) { } }
    }

    /** Blokir: panggil dari thread latar. Tabel bawaan, lalu geokode Open-Meteo, lalu Geocoder perangkat. */
    fun cari(context: Context, nama: String, inggris: Boolean): Tempat? {
        dariTabel(nama, inggris)?.let { return it }
        try {
            val kode = if (inggris) "en" else "id"
            val j = JSONObject(unduh("https://geocoding-api.open-meteo.com/v1/search?name=" + java.net.URLEncoder.encode(nama, "UTF-8") + "&count=1&language=" + kode + "&format=json"))
            val h = j.optJSONArray("results")?.optJSONObject(0)
            if (h != null && h.has("latitude") && h.has("longitude")) {
                val bagian = listOf(h.optString("name"), h.optString("admin1"), h.optString("country")).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                return Tempat(h.getDouble("latitude"), h.getDouble("longitude"), bagian.joinToString(", "), h.optString("country_code").uppercase(Locale.ROOT))
            }
        } catch (_: Exception) { }
        try {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION")
                val a = Geocoder(context.applicationContext, if (inggris) Locale.ENGLISH else Locale("id", "ID")).getFromLocationName(nama, 1)?.firstOrNull()
                if (a != null) {
                    val bagian = listOf(a.locality ?: a.featureName, a.adminArea, a.countryName).filterNotNull().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                    return Tempat(a.latitude, a.longitude, bagian.joinToString(", ").ifBlank { nama }, (a.countryCode ?: "").uppercase(Locale.ROOT))
                }
            }
        } catch (_: Exception) { }
        return null
    }
}
