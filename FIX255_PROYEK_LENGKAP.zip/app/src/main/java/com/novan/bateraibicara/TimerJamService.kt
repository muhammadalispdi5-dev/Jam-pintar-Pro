package com.novan.bateraibicara

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Timer berjalan sebagai foreground service sehingga tetap menghitung saat layar mati/aplikasi berpindah. */
class TimerJamService : Service() {
    companion object {
        const val ACTION_MULAI = "com.novan.jambicarapro.TIMER_MULAI"
        const val ACTION_JEDA = "com.novan.jambicarapro.TIMER_JEDA"
        const val ACTION_LANJUT = "com.novan.jambicarapro.TIMER_LANJUT"
        const val ACTION_RESET = "com.novan.jambicarapro.TIMER_RESET"
        const val ACTION_STOP_ALARM = "com.novan.jambicarapro.TIMER_STOP_ALARM"
        const val ACTION_PULIHKAN = "com.novan.jambicarapro.TIMER_PULIHKAN"
        private const val PREF = "timer_jam"
        private const val CHANNEL = "timer_jam_aktif"
        private const val NOTIF = 9201
        const val STATE_IDLE = 0
        const val STATE_RUNNING = 1
        const val STATE_PAUSED = 2
        const val STATE_ALARM = 3

        fun kirim(context: Context, action: String, durasiMs: Long? = null, mode: Int? = null, pengumuman: Boolean? = null) {
            val i = Intent(context, TimerJamService::class.java).setAction(action)
            durasiMs?.let { i.putExtra("durasi_ms", it) }
            mode?.let { i.putExtra("mode", it) }
            pengumuman?.let { i.putExtra("pengumuman", it) }
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
            } catch (_: Exception) { }
        }

        fun status(context: Context): Int = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt("state", STATE_IDLE)
        fun sisa(context: Context): Long {
            val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            return when (p.getInt("state", STATE_IDLE)) {
                STATE_RUNNING -> (p.getLong("end_at", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
                STATE_PAUSED -> p.getLong("remaining", 0L)
                else -> 0L
            }
        }
    }

    override fun attachBaseContext(newBase: Context) { super.attachBaseContext(BahasaAplikasi.bungkus(newBase)) }
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences(PREF, Context.MODE_PRIVATE) }
    private var player: MediaPlayer? = null
    private var pembicara: Pembicara? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastAnnounced = -1

    override fun onBind(intent: Intent?): IBinder? = null

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        buatKanal()
        val action = intent?.action
        // Semua jalur yang dipanggil melalui startForegroundService segera memenuhi batas startForeground Android.
        if (action != ACTION_MULAI) startForeground(NOTIF, notifikasi())
        when (action) {
            ACTION_MULAI -> {
                hentikanAlarm()
                val durasi = intent.getLongExtra("durasi_ms", 0L).coerceAtLeast(1000L)
                prefs.edit().putInt("mode", intent.getIntExtra("mode", 2))
                    .putBoolean("pengumuman", intent.getBooleanExtra("pengumuman", true))
                    .putLong("end_at", System.currentTimeMillis() + durasi)
                    .putLong("remaining", durasi).putInt("state", STATE_RUNNING).apply()
                lastAnnounced = -1
                mulaiWakeLock()
                startForeground(NOTIF, notifikasi())
                mulaiTick()
            }
            ACTION_JEDA -> jeda()
            ACTION_LANJUT -> lanjut()
            ACTION_RESET -> reset()
            ACTION_STOP_ALARM -> berhentiAlarm()
            ACTION_PULIHKAN, null -> pulihkan()
            else -> pulihkan()
        }
        return START_STICKY
    }

    private fun pulihkan() {
        when (prefs.getInt("state", STATE_IDLE)) {
            STATE_RUNNING -> {
                if (prefs.getLong("end_at", 0L) <= System.currentTimeMillis()) waktuHabis()
                else { mulaiWakeLock(); startForeground(NOTIF, notifikasi()); mulaiTick() }
            }
            STATE_PAUSED -> { startForeground(NOTIF, notifikasi()); stopForegroundCompat(); stopSelf() }
            STATE_ALARM -> { startForeground(NOTIF, notifikasi()); mulaiAlarm() }
            else -> { stopSelf() }
        }
    }

    private fun mulaiTick() {
        handler.removeCallbacksAndMessages(null)
        val tick = object : Runnable {
            override fun run() {
                if (prefs.getInt("state", STATE_IDLE) != STATE_RUNNING) return
                val sisa = prefs.getLong("end_at", 0L) - System.currentTimeMillis()
                if (sisa <= 0L) { waktuHabis(); return }
                if (prefs.getBoolean("pengumuman", true)) {
                    val detik = (sisa + 999L) / 1000L
                    val ambang = when { detik == 60L -> 60; detik == 30L -> 30; detik in setOf(10L, 5L, 3L, 2L, 1L) -> detik.toInt(); else -> -1 }
                    if (ambang > 0 && ambang != lastAnnounced) {
                        lastAnnounced = ambang
                        ucapkan(if (ambang == 60) tr("Sisa waktu timer satu menit.", "One minute remaining.") else if (ambang == 30) tr("Sisa waktu timer tiga puluh detik.", "Thirty seconds remaining.") else tr("Sisa waktu timer " + detik + " detik.", detik.toString() + " seconds remaining."))
                    }
                }
                getSystemService(NotificationManager::class.java).notify(NOTIF, notifikasi())
                handler.postDelayed(this, 1000L)
            }
        }
        handler.post(tick)
    }

    private fun jeda() {
        if (prefs.getInt("state", STATE_IDLE) != STATE_RUNNING) return
        val sisa = (prefs.getLong("end_at", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
        prefs.edit().putLong("remaining", sisa).putInt("state", STATE_PAUSED).apply()
        handler.removeCallbacksAndMessages(null); lepasWakeLock()
        getSystemService(NotificationManager::class.java).notify(NOTIF, notifikasi())
        stopForegroundCompat(); stopSelf()
    }

    private fun lanjut() {
        if (prefs.getInt("state", STATE_IDLE) != STATE_PAUSED) return
        val sisa = prefs.getLong("remaining", 0L)
        if (sisa <= 0L) { waktuHabis(); return }
        prefs.edit().putLong("end_at", System.currentTimeMillis() + sisa).putInt("state", STATE_RUNNING).apply()
        mulaiWakeLock(); startForeground(NOTIF, notifikasi()); mulaiTick()
    }

    private fun reset() {
        handler.removeCallbacksAndMessages(null); hentikanAlarm(); lepasWakeLock()
        prefs.edit().remove("end_at").remove("remaining").putInt("state", STATE_IDLE).apply()
        getSystemService(NotificationManager::class.java).cancel(NOTIF)
        stopForegroundCompat(); stopSelf()
    }

    private fun waktuHabis() {
        handler.removeCallbacksAndMessages(null); lepasWakeLock()
        prefs.edit().putInt("state", STATE_ALARM).putLong("remaining", 0L).apply()
        startForeground(NOTIF, notifikasi())
        mulaiAlarm()
    }

    private fun mulaiAlarm() {
        hentikanAlarm()
        val mode = prefs.getInt("mode", 2)
        if (mode == 0 || mode == 2) {
            try {
                val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                if (uri != null) {
                    player = MediaPlayer().apply {
                        setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                        setDataSource(this@TimerJamService, uri); isLooping = true; setOnPreparedListener { it.start() }; prepareAsync()
                    }
                }
            } catch (_: Exception) { }
        }
        if (mode == 1 || mode == 2) {
            ucapkan(tr("Waktu timer telah habis.", "The timer has finished."))
            if (mode == 1) jadwalkanUlangUcapan()
        }
        getSystemService(NotificationManager::class.java).notify(NOTIF, notifikasi())
    }

    private fun jadwalkanUlangUcapan() {
        handler.postDelayed({
            if (prefs.getInt("state", STATE_IDLE) == STATE_ALARM && prefs.getInt("mode", 2) == 1) {
                ucapkan(tr("Waktu timer telah habis.", "The timer has finished."))
                jadwalkanUlangUcapan()
            }
        }, 15000L)
    }

    private fun berhentiAlarm() {
        hentikanAlarm(); handler.removeCallbacksAndMessages(null)
        prefs.edit().remove("end_at").remove("remaining").putInt("state", STATE_IDLE).apply()
        getSystemService(NotificationManager::class.java).cancel(NOTIF)
        stopForegroundCompat(); stopSelf()
    }

    private fun ucapkan(teks: String) {
        try {
            val p = pembicara ?: Pembicara(this, Prefs(this).suara("jam"), null).also { pembicara = it }
            p.bisaDibungkam = true
            p.ucapkan(teks, true)
        } catch (_: Exception) { }
    }

    private fun hentikanAlarm() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
    }

    private fun mulaiWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock?.isHeld != true) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:TimerJam").apply { setReferenceCounted(false); acquire(24 * 60 * 60 * 1000L) }
        } catch (_: Exception) { }
    }
    private fun lepasWakeLock() { try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }; wakeLock = null }

    private fun buatKanal() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) nm.createNotificationChannel(NotificationChannel(CHANNEL, tr("Timer Jam", "Clock timer"), NotificationManager.IMPORTANCE_HIGH).apply { description = tr("Status hitung mundur dan alarm timer.", "Countdown status and timer alarm."); setSound(null, null) })
        }
    }

    private fun notifikasi(): Notification {
        val state = prefs.getInt("state", STATE_IDLE)
        val sisa = if (state == STATE_RUNNING) (prefs.getLong("end_at", 0L) - System.currentTimeMillis()).coerceAtLeast(0L) else prefs.getLong("remaining", 0L)
        val judul = when (state) {
            STATE_RUNNING -> tr("Timer sedang berjalan", "Timer running")
            STATE_PAUSED -> tr("Timer dijeda", "Timer paused")
            STATE_ALARM -> tr("Waktu timer habis!", "Timer finished!")
            else -> tr("Timer", "Timer")
        }
        val teks = if (state == STATE_ALARM) tr("Tekan Hentikan alarm untuk menutup suara.", "Press Stop alarm to silence it.") else formatDurasi(sisa)
        val buka = PendingIntent.getActivity(this, 9202, Intent(this, JamActivity::class.java).putExtra("kelompok", "timer"), flag())
        val b = Notification.Builder(this).setSmallIcon(R.drawable.ic_stat_baterai).setContentTitle(judul).setContentText(teks).setContentIntent(buka).setOngoing(state == STATE_RUNNING || state == STATE_ALARM).setCategory(Notification.CATEGORY_ALARM).setOnlyAlertOnce(true)
        if (Build.VERSION.SDK_INT >= 26) b.setChannelId(CHANNEL)
        if (state == STATE_RUNNING) b.addAction(0, tr("Jeda", "Pause"), aksi(ACTION_JEDA, 9203))
        if (state == STATE_PAUSED) b.addAction(0, tr("Lanjutkan", "Resume"), aksi(ACTION_LANJUT, 9204))
        if (state == STATE_ALARM) b.addAction(0, tr("Hentikan alarm", "Stop alarm"), aksi(ACTION_STOP_ALARM, 9205))
        if (state != STATE_IDLE) b.addAction(0, tr("Reset", "Reset"), aksi(ACTION_RESET, 9206))
        return b.build()
    }
    private fun aksi(action: String, id: Int) = PendingIntent.getService(this, id, Intent(this, TimerJamService::class.java).setAction(action), flag())
    private fun flag() = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    private fun formatDurasi(ms: Long): String { val total = (ms + 999) / 1000; val h = total / 3600; val m = total % 3600 / 60; val s = total % 60; return if (h > 0) "%02d:%02d:%02d".format(h,m,s) else "%02d:%02d".format(m,s) }
    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() { if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true) }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); lepasWakeLock(); super.onDestroy() }
}

class TimerJamBootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (TimerJamService.status(context) == TimerJamService.STATE_RUNNING || TimerJamService.status(context) == TimerJamService.STATE_ALARM) {
                TimerJamService.kirim(context, TimerJamService.ACTION_PULIHKAN)
            }
        }
    }
}
