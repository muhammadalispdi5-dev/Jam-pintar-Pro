package com.novan.bateraibicara

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.speech.tts.TextToSpeech

/** Pemilih mesin TTS independen untuk pustaka teks. Pilihan baru disimpan setelah tombol Simpan. */
object MesinSuaraPembaca {
    private const val KUNCI = "mesin_suara_pembaca"

    fun paket(prefs: SharedPreferences): String = prefs.getString(KUNCI, "") ?: ""

    fun tampilkan(activity: Activity, prefs: SharedPreferences, saatBerubah: () -> Unit) {
        var pemeriksa: TextToSpeech? = null
        pemeriksa = TextToSpeech(activity.applicationContext) { status ->
            val tts = pemeriksa
            if (status != TextToSpeech.SUCCESS || tts == null || activity.isFinishing) {
                try { tts?.shutdown() } catch (_: Exception) { }
                activity.runOnUiThread {
                    AlertDialog.Builder(activity)
                        .setMessage(BahasaAplikasi.teks(activity, "Daftar mesin suara tidak dapat dibaca."))
                        .setPositiveButton(BahasaAplikasi.teks(activity, "OK"), null).show()
                }
                return@TextToSpeech
            }
            activity.runOnUiThread {
                try {
                    val daftar = tts.engines.orEmpty().sortedBy { it.label.lowercase() }
                    val aktif = paket(prefs)
                    val paket = listOf("") + daftar.map { it.name }.filter { it.isNotBlank() && it != "" }.distinct()
                    val label = listOf(BahasaAplikasi.teks(activity, "Bawaan sistem")) + daftar
                        .filter { it.name in paket.drop(1) }
                        .map { it.label.toString() + if (it.name == aktif) " (" + BahasaAplikasi.teks(activity, "dipilih") + ")" else "" }
                    var sementara = paket.indexOf(aktif).coerceAtLeast(0)
                    val dialog = AlertDialog.Builder(activity)
                        .setTitle(BahasaAplikasi.teks(activity, "Pilih mesin suara pembaca"))
                        .setSingleChoiceItems(label.toTypedArray(), sementara) { _, which -> sementara = which }
                        .setPositiveButton(BahasaAplikasi.teks(activity, "Simpan")) { _, _ ->
                            prefs.edit().putString(KUNCI, paket[sementara]).apply()
                            saatBerubah()
                            android.widget.Toast.makeText(activity,
                                BahasaAplikasi.teks(activity, "Pengaturan mesin suara telah diperbarui."),
                                android.widget.Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton(BahasaAplikasi.teks(activity, "Batal"), null)
                        .create()
                    dialog.setOnDismissListener { try { tts.shutdown() } catch (_: Exception) { } }
                    dialog.show()
                } catch (_: Exception) {
                    try { tts.shutdown() } catch (_: Exception) { }
                }
            }
        }
    }
}
