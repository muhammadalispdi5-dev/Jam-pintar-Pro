package com.novan.bateraibicara

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import java.util.Calendar

/**
 * Aktivitas transparan yang menjadi pemicu suara dari widget layar utama.
 * Berjalan di task sendiri (lihat manifest) sehingga tidak membuka jendela aplikasi
 * yang masih ada di latar belakang.
 */
class BeritahuSayaActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutup() }
    // FIX124: pengumuman waktu/tanggal dari widget dapat dihentikan dengan tombol volume atau telungkup, seperti notifikasi lainnya.
    private var volumeDikonsumsi = false
    private var generasiBungkamAwal = 0
    private val pantauBungkam = object : Runnable {
        override fun run() {
            if (selesai || isFinishing) return
            if (PembungkamTelungkup.generasi != generasiBungkamAwal) { tutup(); return }
            handler.postDelayed(this, 400L)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) volumeDikonsumsi = false
                if (volumeDikonsumsi) return true
                if (PembungkamTelungkup.bungkamDariTombolVolume(this)) {
                    volumeDikonsumsi = true
                    tutup()
                    return true
                }
            } else if (event.action == KeyEvent.ACTION_UP && volumeDikonsumsi) {
                volumeDikonsumsi = false
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mulai()
    }

    /** Pemicu diklik lagi saat pembacaan sebelumnya masih berjalan: ulang dari awal. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // FIX86: ketukan kedua saat pembacaan masih berjalan menghentikan bacaan dan membuka perintah suara.
        hentikanSuara()
        bukaPerintahSuara()
    }

    private fun bukaPerintahSuara() {
        selesai = true
        try { startActivity(Intent(this, PerintahSuaraActivity::class.java)) } catch (_: Exception) { }
        finish()
    }

    private fun mulai() {
        try {
            val prefs = Prefs(applicationContext)
            if (!prefs.beritahuSayaOn) {
                android.widget.Toast.makeText(
                    this,
                    getString(R.string.beritahu_saya_nonaktif_petunjuk),
                    android.widget.Toast.LENGTH_LONG
                ).show()
                selesai = true
                finish()
                return
            }
            if (prefs.beritahuSayaLangsungSuara) {
                bukaPerintahSuara()
                return
            }
            // Waktu dibacakan oleh suara jam; tanggal, libur, dan info sholat oleh suara pembaca tanggal.
            val c = Calendar.getInstance()
            val waktu = JamWaktu.ucapan(prefs, c)
            val tanggal = JamWaktu.segmenTanggal(prefs, c)
            val p = Pembicara(applicationContext, prefs.suara("jam")).also { it.bisaDibungkam = true }
            pembicara = p
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            generasiBungkamAwal = PembungkamTelungkup.generasi
            handler.removeCallbacks(pantauBungkam)
            handler.postDelayed(pantauBungkam, 400L)
            val bacaTanggal = {
                if (tanggal.isEmpty()) tutup() else {
                    val pt = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
                    pembicaraTanggal = pt
                    pt.ucapkanRangkaian(tanggal, 300L) { tutup() }
                }
            }
            if (waktu.isBlank()) bacaTanggal() else p.ucapkan(waktu, true) { bacaTanggal() }
        } catch (_: Exception) {
            tutup()
        }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        handler.removeCallbacks(pantauBungkam)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        hentikanSuara()
        finish()
    }

    override fun onDestroy() {
        hentikanSuara()
        super.onDestroy()
    }
}
