package com.novan.bateraibicara

import kotlin.math.max
import kotlin.math.sqrt

/**
 * FIX101: pendeteksi pola "tiga goncangan cepat" untuk membuka perintah suara (menggantikan FIX99).
 *
 * Masalah FIX99: syarat "HP harus diam dulu" dan "puncak pertama harus muncul segera sesudah HP mulai bergerak"
 * hampir tidak pernah terpenuhi bila HP dipegang tangan (getaran tangan, gerakan kecil sebelum menggoyang), sehingga
 * goncangan pada sensitivitas maksimum pun jarang dikenali. Getaran tangan juga menghasilkan puncak-puncak palsu yang
 * mengacaukan hitungan. Pada simulasi, tingkat keberhasilan FIX99 hanya sekitar 20 persen.
 *
 * Pendekatan baru: ambang puncak ADAPTIF terhadap kebisingan latar belakang.
 *  1. Latar belakang = akar rata-rata kuadrat (RMS) percepatan tanpa gravitasi selama beberapa detik terakhir,
 *     dibaca [BG_TUNDA_MS] sebelum puncak agar hentakan itu sendiri tidak menaikkan latar.
 *  2. Puncak harus melebihi max(ambang sensitivitas, [FAKTOR_LATAR] x latar). Getaran tangan atau gerakan berirama
 *     (berjalan, kendaraan) menaikkan latar sehingga tidak terhitung, sementara hentakan sengaja tetap jelas lebih besar.
 *  3. Tiap puncak naik cepat (maks. [NAIK_MAKS_MS] dari lembah ke puncak). Gerakan lambat (mengangkat HP) ditolak.
 *  4. Tiga puncak berturut-turut, jeda [MIN_JEDA_MS]..[JEDA_MAKS_MS], selesai dalam [JENDELA_MS].
 *  5. Bila sudah ada [RIWAYAT_MAKS] puncak dalam [RIWAYAT_MS] sebelum urutan dimulai, gerakan dianggap berirama.
 *  6. Mode longgar: ambang dasar 1,8 kali lebih tinggi (untuk dipakai sambil bergerak).
 *  7. [warmMs] pertama sesudah pembacaan sensor dimulai diabaikan agar latar belakang sempat terukur.
 * Setelah pola dikenali, pemicu berikutnya ditahan selama [cooldownMs].
 *
 * Kelas ini murni logika (tanpa Android) sehingga dipakai bersama oleh layanan latar belakang dan layar uji.
 * Dipanggil dari satu thread dengan cap waktu monoton dalam milidetik.
 */
class DetektorGoncangan {
    enum class Hasil { TIDAK_ADA, PUNCAK, POLA }

    /** 1 = perlu goncangan kuat ... 10 = goncangan ringan sudah terdeteksi. */
    var sensitivitas: Int = 5
    /** false = ambang normal; true = ambang 1,8 kali lebih tinggi (boleh sambil bergerak). */
    var longgar: Boolean = false
    var cooldownMs: Long = COOLDOWN_MS
    /** Masa pemanasan sesudah pembacaan sensor dimulai; tidak ada pemicu selama waktu ini. */
    var warmMs: Long = WARM_MS

    /** Jumlah puncak sah pada urutan yang sedang berjalan (0..3), untuk umpan balik pada layar uji. */
    var jumlahPuncak: Int = 0
        private set

    private var siap = false
    private var t0 = 0L
    private var gx = 0f
    private var gy = 0f
    private var gz = 0f
    private var terakhirMs = 0L
    private var tPertama = 0L
    private var tTerakhir = 0L
    private var tPemicu = -1_000_000_000L
    private var fase = 0
    private var maxP = 0f
    private var tMax = 0L
    private var minP = 0f
    private var tLembah = 0L
    private var tRendah = 0L
    private var ema = 0f
    private var bgPertama = 0f
    private val riwayat = ArrayList<Long>()
    private val histT = ArrayDeque<Long>()
    private val histE = ArrayDeque<Float>()

    fun reset() {
        siap = false
        jumlahPuncak = 0
        tPemicu = -1_000_000_000L
        fase = 0
        maxP = 0f
        ema = 0f
        bgPertama = 0f
        riwayat.clear()
        histT.clear()
        histE.clear()
    }

    /** Ambang puncak dasar (m/s^2). Sensitivitas 1 -> 7,0; 5 -> 4,4; 10 -> 1,8. */
    private fun ambangDasar(): Float {
        val s = sensitivitas.coerceIn(1, 10)
        return 7.0f - (s - 1) * ((7.0f - AMBANG_MIN) / 9f)
    }

    /** RMS latar belakang yang terbaca [BG_TUNDA_MS] sebelum [tp]. */
    private fun latarSebelum(tp: Long): Float {
        var b = 0f
        for (i in 0 until histT.size) {
            if (histT[i] <= tp - BG_TUNDA_MS) b = histE[i] else break
        }
        return sqrt(b)
    }

    private fun batal() {
        jumlahPuncak = 0
    }

    /** Satu sampel akselerometer (m/s^2, termasuk gravitasi) pada waktu [t] milidetik. */
    fun proses(x: Float, y: Float, z: Float, t: Long): Hasil {
        if (!siap) {
            gx = x; gy = y; gz = z
            terakhirMs = t
            t0 = t
            siap = true
            tRendah = t
            tLembah = t
            return Hasil.TIDAK_ADA
        }
        val dt = (t - terakhirMs).coerceIn(1L, 200L) / 1000f
        terakhirMs = t
        // Penyaring lolos-tinggi untuk membuang gravitasi.
        val a = TAU_DETIK / (TAU_DETIK + dt)
        gx = a * gx + (1f - a) * x
        gy = a * gy + (1f - a) * y
        gz = a * gz + (1f - a) * z
        val ax = x - gx
        val ay = y - gy
        val az = z - gz
        val p = sqrt(ax * ax + ay * ay + az * az)

        // Latar belakang (RMS dengan tetapan waktu BG_TAU_DETIK) dan riwayatnya.
        val k = dt / (BG_TAU_DETIK + dt)
        ema += k * (p * p - ema)
        histT.addLast(t); histE.addLast(ema)
        while (histT.size > 1 && histT.first() < t - BG_TUNDA_MS * 3) { histT.removeFirst(); histE.removeFirst() }

        val dasar = ambangDasar() * (if (longgar) LONGGAR_X else 1f)
        val latar = if (jumlahPuncak > 0) bgPertama else latarSebelum(t)
        val amb = max(dasar, FAKTOR_LATAR * latar)
        if (p < amb * RENDAH) tRendah = t

        // --- puncak lokal: naik sampai maksimum, terkonfirmasi saat turun di bawah 70% maksimum ---
        var hasil = Hasil.TIDAK_ADA
        if (fase == 0) {
            if (p > maxP) { maxP = p; tMax = t }
            if (maxP >= amb && p < maxP * TURUN) {
                val naik = tMax - max(tLembah, tRendah)
                fase = 1
                minP = p
                tLembah = t
                val tPuncak = tMax
                maxP = 0f
                hasil = puncakTerkonfirmasi(tPuncak, naik)
            }
        } else {
            if (p < minP) { minP = p; tLembah = t }
            if (p > minP + 0.25f * amb) {
                fase = 0
                maxP = p
                tMax = t
            }
        }
        // Urutan kedaluwarsa bila tidak ada puncak baru.
        if (jumlahPuncak > 0 && t - tTerakhir > JEDA_MAKS_MS + 100L) batal()
        return hasil
    }

    private fun puncakTerkonfirmasi(tp: Long, naik: Long): Hasil {
        if (naik > NAIK_MAKS_MS) {          // hentakan lambat (mengangkat, mengayun) bukan goncangan
            batal()
            return Hasil.TIDAK_ADA
        }
        riwayat.removeAll { tp - it > RIWAYAT_MS }
        val sebelumnya = riwayat.size
        riwayat.add(tp)
        if (tp - tPemicu < cooldownMs || tp - t0 < warmMs) return Hasil.TIDAK_ADA
        if (jumlahPuncak > 0 && (tp - tTerakhir > JEDA_MAKS_MS || tp - tPertama > JENDELA_MS)) {
            batal()
            return Hasil.TIDAK_ADA
        }
        if (jumlahPuncak > 0 && tp - tTerakhir < MIN_JEDA_MS) return Hasil.TIDAK_ADA
        if (jumlahPuncak == 0) {
            if (sebelumnya >= RIWAYAT_MAKS) return Hasil.TIDAK_ADA          // sudah bergerak berirama
            jumlahPuncak = 1
            tPertama = tp
            tTerakhir = tp
            bgPertama = latarSebelum(tp)
            return Hasil.PUNCAK
        }
        jumlahPuncak++
        tTerakhir = tp
        if (jumlahPuncak >= 3) {
            jumlahPuncak = 0
            tPemicu = tp
            return Hasil.POLA
        }
        return Hasil.PUNCAK
    }

    companion object {
        private const val AMBANG_MIN = 1.8f
        private const val LONGGAR_X = 1.8f
        private const val FAKTOR_LATAR = 3.0f
        private const val TAU_DETIK = 0.25f
        private const val BG_TAU_DETIK = 1.5f
        private const val BG_TUNDA_MS = 250L
        private const val RENDAH = 0.6f
        private const val TURUN = 0.7f
        private const val MIN_JEDA_MS = 120L
        private const val JEDA_MAKS_MS = 700L
        private const val JENDELA_MS = 2500L
        private const val NAIK_MAKS_MS = 250L
        private const val RIWAYAT_MS = 2000L
        private const val RIWAYAT_MAKS = 3
        private const val WARM_MS = 2000L
        const val COOLDOWN_MS = 7000L
    }
}
