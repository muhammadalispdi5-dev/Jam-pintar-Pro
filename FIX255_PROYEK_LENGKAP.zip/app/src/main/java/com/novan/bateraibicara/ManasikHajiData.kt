package com.novan.bateraibicara

/**
 * FIX203: panduan manasik haji dan doa-doanya (dwibahasa). Disusun ringkas mengikuti pendapat yang lazim dipakai
 * di Indonesia (mazhab Syafi'i), dengan kutipan Arab dibatasi pada ayat, hadits, dan bacaan yang masyhur.
 * Perbedaan pendapat antarmazhab ada; jamaah wajib mengikuti bimbingan pembimbing resmi dan petugas haji.
 */
object ManasikHajiData {

    /** Blok teks: [arab] dan [latin] opsional untuk bacaan/doa; [id] dan [en] adalah isi dan artinya. */
    class Blok(val arab: String?, val latin: String?, val id: String, val en: String, val sumber: String? = null)

    class Bagian(val judul: Blok, val blok: List<Blok>)

    private fun teks(id: String, en: String) = Blok(null, null, id, en)
    private fun teks(arab: String, latin: String, id: String, en: String, sumber: String? = null) = Blok(arab, latin, id, en, sumber)

    private val talbiyah = teks(
        "لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لَا شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لَا شَرِيكَ لَكَ",
        "Labbaikallahumma labbaik, labbaika la syarika laka labbaik, innal hamda wan ni'mata laka wal mulk, la syarika lak.",
        "Aku penuhi panggilan-Mu ya Allah, aku penuhi panggilan-Mu. Aku penuhi panggilan-Mu, tiada sekutu bagi-Mu, aku penuhi panggilan-Mu. Sesungguhnya segala puji, nikmat, dan kerajaan adalah milik-Mu, tiada sekutu bagi-Mu.",
        "Here I am, O Allah, here I am. Here I am, You have no partner, here I am. Indeed all praise, blessing, and dominion belong to You; You have no partner.",
        "Talbiyah, HR. Al-Bukhari dan Muslim"
    )

    private val doaSapuJagat = teks(
        "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
        "Rabbana atina fid-dunya hasanah, wa fil akhirati hasanah, wa qina 'adzaban-nar.",
        "Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, dan lindungilah kami dari azab neraka.",
        "Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
        "Al-Qur'an, Al-Baqarah 2:201"
    )

    private val tahlilArafah = teks(
        "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
        "La ilaha illallahu wahdahu la syarika lah, lahul mulku wa lahul hamdu wa huwa 'ala kulli syai'in qadir.",
        "Tiada Tuhan selain Allah semata, tiada sekutu bagi-Nya. Milik-Nya kerajaan dan milik-Nya segala puji, dan Dia Mahakuasa atas segala sesuatu.",
        "There is no god but Allah alone, with no partner. His is the dominion and His is all praise, and He is able to do all things.",
        "HR. At-Tirmidzi"
    )

    val daftar: List<Bagian> = listOf(

        Bagian(teks("Pengantar dan Syarat Wajib Haji", "Introduction and Conditions of Hajj"), listOf(
            teks("Haji adalah rukun Islam kelima: berkunjung ke Baitullah di Makkah pada waktu tertentu untuk melaksanakan rangkaian ibadah tertentu, semata karena Allah. Haji wajib sekali seumur hidup bagi yang memenuhi syaratnya.",
                "Hajj is the fifth pillar of Islam: visiting the House of Allah in Makkah at a specific time to perform specific acts of worship, solely for Allah. It is obligatory once in a lifetime for those who meet its conditions."),
            teks("Syarat wajib haji: beragama Islam, baligh, berakal, merdeka, dan mampu (istitha'ah), yaitu mampu dari segi bekal, kesehatan, keamanan perjalanan, serta nafkah keluarga yang ditinggalkan. Bagi perempuan, disyaratkan adanya mahram atau rombongan perempuan yang dapat dipercaya menurut pendapat yang dipegang di Indonesia.",
                "Conditions: being Muslim, mature, sane, free, and able (istitha'ah), meaning able in provision, health, safety of travel, and support for the family left behind. For women, a mahram or a trustworthy group of women is required according to the view followed in Indonesia."),
            teks("Panduan ini ringkas dan mengikuti pendapat yang lazim di Indonesia (mazhab Syafi'i). Para ulama berbeda pendapat pada beberapa rincian. Ikutilah bimbingan pembimbing ibadah resmi, KBIHU, dan petugas haji, dan jangan menjadikan aplikasi ini satu-satunya rujukan.",
                "This guide is brief and follows the view common in Indonesia (the Shafi'i school). Scholars differ on some details. Follow your official guide, your group leaders, and hajj officers, and do not treat this app as your only reference.")
        )),

        Bagian(teks("Tiga Cara Berhaji", "Three Ways of Performing Hajj"), listOf(
            teks("Tamattu': berihram umrah lebih dahulu pada bulan-bulan haji, menyelesaikan umrah dan bertahallul, lalu berihram haji pada tanggal 8 Dzulhijjah. Wajib membayar dam (menyembelih kambing). Inilah cara yang paling umum bagi jamaah Indonesia.",
                "Tamattu': enter ihram for umrah first in the months of hajj, finish umrah and exit ihram, then enter ihram for hajj on 8 Dhul Hijjah. A dam (sacrificing a sheep) is required. This is the most common way for Indonesian pilgrims."),
            teks("Qiran: berihram untuk umrah dan haji sekaligus, tetap dalam ihram sampai selesai amalan hari raya kurban. Wajib membayar dam.",
                "Qiran: enter ihram for umrah and hajj together and remain in ihram until the rites of the Day of Sacrifice are done. A dam is required."),
            teks("Ifrad: berihram untuk haji saja, tanpa umrah yang digabungkan. Tidak wajib dam tamattu'.",
                "Ifrad: enter ihram for hajj only, without a combined umrah. The tamattu' dam is not required.")
        )),

        Bagian(teks("Rukun, Wajib, dan Sunnah Haji", "Pillars, Obligations, and Sunnahs of Hajj"), listOf(
            teks("Rukun haji (tidak sah hajinya bila ada yang ditinggalkan, dan tidak dapat diganti dengan dam): 1) ihram, yaitu niat masuk haji; 2) wukuf di Arafah; 3) tawaf ifadhah; 4) sa'i antara Shafa dan Marwah; 5) tahallul, yaitu mencukur atau memotong rambut; 6) tertib, yaitu menjaga urutan rukun-rukun tersebut.",
                "Pillars of hajj (the hajj is invalid if any is left out, and a dam cannot replace them): 1) ihram, the intention to enter hajj; 2) standing at Arafah; 3) tawaf al-ifadah; 4) sa'i between Safa and Marwa; 5) tahallul, shaving or trimming the hair; 6) order, keeping these pillars in sequence."),
            teks("Wajib haji (bila ditinggalkan, hajinya sah tetapi wajib membayar dam): berihram dari miqat, bermalam (mabit) di Muzdalifah, bermalam di Mina pada hari-hari tasyrik, melempar jumrah, dan tawaf wada'.",
                "Obligations of hajj (if left out, the hajj is valid but a dam is due): entering ihram from the miqat, staying overnight at Muzdalifah, staying overnight at Mina on the days of tashriq, stoning the jamarat, and the farewell tawaf."),
            teks("Sunnah haji antara lain: mandi sebelum ihram, tawaf qudum, memperbanyak talbiyah, dzikir dan doa, serta mengikuti tuntunan Rasulullah shallallahu 'alaihi wasallam sebisa mungkin.",
                "Sunnahs include: bathing before ihram, the arrival tawaf, abundant talbiyah, remembrance and supplication, and following the guidance of the Messenger of Allah, peace be upon him, as far as possible.")
        )),

        Bagian(teks("Persiapan dan Doa Safar", "Preparation and Travel Supplications"), listOf(
            teks("Persiapan terpenting adalah batin: tobat yang jujur, meluruskan niat, meminta maaf kepada orang yang pernah kita sakiti, melunasi utang atau menitipkan wasiat, dan memastikan bekal haji berasal dari harta yang halal.",
                "The most important preparation is inward: sincere repentance, correcting the intention, asking forgiveness from those we have wronged, settling debts or leaving a will, and ensuring the funds for hajj are lawful."),
            teks("Persiapan lahir: mempelajari manasik sebelum berangkat, menjaga kesehatan dan vaksinasi, membawa obat pribadi, menyimpan dokumen dan nomor penting, serta melatih fisik dengan berjalan kaki secara rutin.",
                "Outward preparation: learn the rites before leaving, take care of health and vaccinations, bring personal medicine, keep documents and important numbers safe, and build stamina by regular walking."),
            teks("سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ",
                "Subhanalladzi sakhkhara lana hadza wa ma kunna lahu muqrinin, wa inna ila rabbina lamunqalibun.",
                "Maha Suci Allah yang telah menundukkan semua ini bagi kami, padahal kami sebelumnya tidak mampu menguasainya, dan sungguh kepada Tuhan kamilah kami akan kembali.",
                "Glory to Him who has subjected this to us, and we could not have done it ourselves, and to our Lord we will surely return.",
                "Al-Qur'an, Az-Zukhruf 43:13-14. Dibaca ketika naik kendaraan."),
            teks("آيِبُونَ تَائِبُونَ عَابِدُونَ لِرَبِّنَا حَامِدُونَ",
                "Ayibuna ta'ibuna 'abiduna lirabbina hamidun.",
                "Kami kembali, bertobat, beribadah, dan memuji Tuhan kami. Dibaca ketika pulang dari perjalanan.",
                "We return, repenting, worshipping, and praising our Lord. Said when returning from a journey.",
                "HR. Muslim")
        )),

        Bagian(teks("Miqat dan Ihram", "Miqat and Ihram"), listOf(
            teks("Miqat adalah batas tempat untuk memulai ihram. Miqat bagi penduduk Madinah dan yang melewatinya adalah Dzulhulaifah (Bir Ali); bagi arah Syam dan sekitarnya, Juhfah (dekat Rabigh); bagi arah Najd, Qarnul Manazil (As-Sailul Kabir); bagi arah Yaman, Yalamlam; bagi arah Irak, Dzatu 'Irq. Pembimbing akan memberi tahu miqat rombongan Anda, termasuk yang dilewati di udara.",
                "The miqat is the boundary at which ihram begins. For those from Madinah or passing it, Dhul Hulayfah (Bir Ali); for the direction of Sham, Juhfah (near Rabigh); for Najd, Qarn al-Manazil (as-Sayl al-Kabir); for Yemen, Yalamlam; for Iraq, Dhat 'Irq. Your guide will tell you your group's miqat, including those passed over by air."),
            teks("Sebelum berihram: mandi, memotong kuku dan merapikan rambut bila perlu, memakai wangi-wangian di badan (bukan pada kain ihram), lalu mengenakan pakaian ihram. Laki-laki memakai dua lembar kain putih tanpa jahitan. Perempuan memakai pakaian biasa yang menutup aurat; wajah dan telapak tangan terbuka. Setelah itu shalat sunnah dua rakaat bila memungkinkan.",
                "Before ihram: bathe, trim nails and tidy hair if needed, apply perfume to the body (not the ihram cloth), then put on ihram clothing. Men wear two unsewn white sheets. Women wear ordinary clothing that covers the awrah; face and hands uncovered. Then pray two sunnah rak'ahs if possible."),
            teks("نَوَيْتُ الْحَجَّ وَأَحْرَمْتُ بِهِ لِلَّهِ تَعَالَى",
                "Nawaitul hajja wa ahramtu bihi lillahi ta'ala.",
                "Aku berniat haji dan berihram untuk haji karena Allah Ta'ala. Niat letaknya di hati; lafaz ini membantu. Untuk haji tamattu', niat awal adalah umrah.",
                "I intend hajj and enter ihram for it for the sake of Allah, the Exalted. The intention lies in the heart; this wording only helps. For tamattu', the first intention is umrah.",
                "Niat ihram haji"),
            teks("نَوَيْتُ الْعُمْرَةَ وَأَحْرَمْتُ بِهَا لِلَّهِ تَعَالَى",
                "Nawaitul 'umrata wa ahramtu biha lillahi ta'ala.",
                "Aku berniat umrah dan berihram untuk umrah karena Allah Ta'ala.",
                "I intend umrah and enter ihram for it for the sake of Allah, the Exalted.",
                "Niat ihram umrah"),
            talbiyah,
            teks("Setelah berniat, perbanyaklah talbiyah. Laki-laki mengeraskan suaranya, perempuan melirihkannya. Talbiyah berhenti pada saat tawaf umrah dimulai, dan untuk haji berhenti ketika mulai melempar jumrah Aqabah pada 10 Dzulhijjah.",
                "After the intention, recite the talbiyah often. Men raise their voices; women keep theirs low. For umrah the talbiyah stops when tawaf begins; for hajj it stops when stoning Jamrat al-Aqaba begins on 10 Dhul Hijjah.")
        )),

        Bagian(teks("Larangan Selama Ihram", "Prohibitions During Ihram"), listOf(
            teks("Selama berihram dilarang bagi laki-laki dan perempuan: memotong atau mencabut rambut dan kuku, memakai wangi-wangian, berburu atau membunuh hewan buruan darat, akad nikah atau meminang, dan hubungan suami istri beserta pendahulunya.",
                "While in ihram, both men and women must not: cut or pull out hair and nails, wear perfume, hunt or kill land game, conduct or propose marriage, or have marital relations and what leads to them."),
            teks("Khusus laki-laki: menutup kepala dan memakai pakaian berjahit yang membentuk badan. Khusus perempuan: menutup wajah dengan cadar dan memakai sarung tangan. Perempuan tetap menutup auratnya, dan boleh menurunkan kerudung untuk menjaga diri dari pandangan.",
                "For men only: covering the head and wearing fitted sewn clothing. For women only: covering the face with a veil and wearing gloves. Women still cover their awrah and may lower the headscarf for privacy from onlookers."),
            teks("فَلَا رَفَثَ وَلَا فُسُوقَ وَلَا جِدَالَ فِي الْحَجِّ",
                "Fala rafatsa wala fusuqa wala jidala fil hajj.",
                "Tidak boleh berkata kotor, berbuat maksiat, dan bertengkar selama mengerjakan haji.",
                "There is to be no obscenity, no sin, and no quarrelling during hajj.",
                "Al-Qur'an, Al-Baqarah 2:197"),
            teks("Pelanggaran karena lupa atau tidak tahu berbeda hukumnya dengan yang disengaja, dan sebagian pelanggaran dikenai fidyah atau dam. Segera tanyakan kepada pembimbing bila terjadi pelanggaran.",
                "A violation by forgetfulness or ignorance differs in ruling from a deliberate one, and some violations require a fidyah or dam. Ask your guide promptly if a violation occurs.")
        )),

        Bagian(teks("Memasuki Makkah dan Masjidil Haram", "Entering Makkah and the Sacred Mosque"), listOf(
            teks("Setibanya di Makkah, mandi bila mudah, lalu menuju Masjidil Haram. Masuklah dengan kaki kanan, dengan hati yang tenang dan tunduk, dan bacalah doa masuk masjid. Hormati sesama jamaah, jangan mendorong atau berebut tempat.",
                "On arriving in Makkah, bathe if easy, then head to the Sacred Mosque. Enter with the right foot, calm and humble, and recite the supplication for entering a mosque. Be considerate of other pilgrims; do not push or compete for space."),
            teks("اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ",
                "Allahummaftah li abwaba rahmatik.",
                "Ya Allah, bukakanlah bagiku pintu-pintu rahmat-Mu.",
                "O Allah, open for me the doors of Your mercy.",
                "HR. Muslim"),
            teks("Ketika pertama kali melihat Ka'bah, berhentilah sejenak, bersyukur, dan berdoalah dengan doa apa pun yang baik. Waktu itu adalah waktu yang mustajab untuk berdoa.",
                "When first seeing the Ka'bah, pause, give thanks, and make any good supplication you wish. It is a time when supplication is hoped to be answered.")
        )),

        Bagian(teks("Tata Cara Tawaf", "How to Perform Tawaf"), listOf(
            teks("Tawaf adalah mengelilingi Ka'bah tujuh putaran, dimulai dan diakhiri di garis sejajar Hajar Aswad, dengan Ka'bah berada di sisi kiri. Syaratnya antara lain suci dari hadats dan najis, menutup aurat, dan berada di dalam Masjidil Haram. Perempuan yang sedang haid menunggu sampai suci.",
                "Tawaf is circling the Ka'bah seven times, starting and ending in line with the Black Stone, with the Ka'bah on your left. Conditions include being free of minor and major impurity, covering the awrah, and being inside the Sacred Mosque. A woman in her period waits until she is clean."),
            teks("Mulailah dari garis Hajar Aswad: menghadap ke arahnya, lalu mengusap atau mencium bila mudah. Bila ramai, cukup berisyarat dengan tangan kanan tanpa berdesakan. Setiap kali sejajar dengan Hajar Aswad, ucapkan:",
                "Start at the line of the Black Stone: face it, then touch or kiss it if easy. If crowded, simply gesture with the right hand without pushing. Each time you are in line with the Black Stone, say:"),
            teks("بِسْمِ اللَّهِ وَاللَّهُ أَكْبَرُ",
                "Bismillahi wallahu akbar.",
                "Dengan nama Allah, dan Allah Mahabesar.",
                "In the name of Allah, and Allah is the Greatest.",
                "Dikenal dari amalan Ibnu Umar radhiyallahu 'anhuma"),
            teks("Pada tawaf qudum atau tawaf umrah, laki-laki disunnahkan idhtiba' (membuka bahu kanan) dan raml (berjalan agak cepat dengan langkah pendek) pada tiga putaran pertama. Empat putaran sisanya berjalan biasa. Perempuan tidak melakukan keduanya.",
                "In the arrival or umrah tawaf, men are encouraged to do idhtiba' (uncovering the right shoulder) and raml (walking briskly with short steps) in the first three rounds. The remaining four are at normal pace. Women do neither."),
            teks("Di antara Rukun Yamani dan Hajar Aswad, disunnahkan membaca:",
                "Between the Yemeni Corner and the Black Stone, it is recommended to recite:"),
            doaSapuJagat,
            teks("Di putaran lainnya, berdzikir, berdoa, dan membaca Al-Qur'an dengan bahasa Anda sendiri. Tidak ada doa wajib khusus di tiap putaran.",
                "In the other rounds, make remembrance, supplication, and Qur'an recitation in your own words. There is no obligatory specific supplication for each round."),
            teks("Setelah tujuh putaran, tutup bahu kanan, menuju Maqam Ibrahim, lalu shalat sunnah dua rakaat (rakaat pertama Al-Kafirun, kedua Al-Ikhlas) sedekat mungkin; bila ramai, boleh di tempat mana pun di masjid.",
                "After seven rounds, cover the right shoulder, go to the Station of Ibrahim and pray two sunnah rak'ahs (Al-Kafirun in the first, Al-Ikhlas in the second) as near as you can; if crowded, anywhere in the mosque is fine."),
            teks("وَاتَّخِذُوا مِنْ مَقَامِ إِبْرَاهِيمَ مُصَلًّى",
                "Wattakhidzu min maqami Ibrahima mushalla.",
                "Dan jadikanlah sebagian maqam Ibrahim tempat shalat.",
                "And take the Station of Ibrahim as a place of prayer.",
                "Al-Qur'an, Al-Baqarah 2:125"),
            teks("Setelah itu minumlah air zamzam sampai puas sambil berdoa dengan kebaikan dunia dan akhirat.",
                "Then drink zamzam water to your fill while asking for good in this world and the Hereafter.")
        )),

        Bagian(teks("Tata Cara Sa'i", "How to Perform Sa'i"), listOf(
            teks("Sa'i adalah berjalan tujuh kali antara bukit Shafa dan Marwah, dimulai dari Shafa dan berakhir di Marwah. Shafa ke Marwah dihitung satu, Marwah ke Shafa dihitung dua, dan seterusnya. Sa'i dilakukan setelah tawaf. Kesucian dari hadats tidak disyaratkan, tetapi sebaiknya tetap dijaga.",
                "Sa'i is walking seven times between the hills of Safa and Marwa, starting at Safa and ending at Marwa. Safa to Marwa counts as one, Marwa to Safa as two, and so on. It is done after tawaf. Purity from minor impurity is not required but is better kept."),
            teks("إِنَّ الصَّفَا وَالْمَرْوَةَ مِنْ شَعَائِرِ اللَّهِ، أَبْدَأُ بِمَا بَدَأَ اللَّهُ بِهِ",
                "Innash-shafa wal-marwata min sya'airillah, abda'u bima bada'allahu bih.",
                "Sesungguhnya Shafa dan Marwah adalah sebagian syiar Allah. Aku mulai dengan apa yang Allah mulai.",
                "Indeed Safa and Marwa are among the symbols of Allah. I begin with what Allah began with.",
                "Dibaca ketika mendekati Shafa. Al-Baqarah 2:158, HR. Muslim"),
            teks("Naiklah sedikit ke Shafa, menghadap Ka'bah, lalu bertakbir, bertahmid, dan membaca:",
                "Go up a little on Safa, face the Ka'bah, then say takbir and tahmid and recite:"),
            teks("لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ، أَنْجَزَ وَعْدَهُ، وَنَصَرَ عَبْدَهُ، وَهَزَمَ الْأَحْزَابَ وَحْدَهُ",
                "La ilaha illallahu wahdahu la syarika lah, lahul mulku wa lahul hamdu wa huwa 'ala kulli syai'in qadir. La ilaha illallahu wahdah, anjaza wa'dah, wa nashara 'abdah, wa hazamal ahzaba wahdah.",
                "Tiada Tuhan selain Allah semata, tiada sekutu bagi-Nya. Milik-Nya kerajaan dan segala puji, dan Dia Mahakuasa atas segala sesuatu. Tiada Tuhan selain Allah semata, Dia menepati janji-Nya, menolong hamba-Nya, dan mengalahkan pasukan sekutu sendirian.",
                "There is no god but Allah alone, with no partner. His is the dominion and all praise, and He is able to do all things. There is no god but Allah alone; He fulfilled His promise, aided His servant, and defeated the confederates alone.",
                "HR. Muslim. Dibaca tiga kali dengan berdoa di antaranya."),
            teks("Turun dan berjalan menuju Marwah. Di antara dua tanda lampu hijau, laki-laki berlari kecil; perempuan tetap berjalan biasa. Di Marwah, naik sedikit, menghadap Ka'bah, dan ulangi dzikir yang sama. Selesai tujuh kali di Marwah.",
                "Descend and walk to Marwa. Between the two green markers, men jog lightly; women keep a normal walk. At Marwa, go up a little, face the Ka'bah, and repeat the same remembrance. Finish the seventh at Marwa."),
            teks("Jamaah yang lemah, sakit, atau lanjut usia boleh sa'i dengan kursi roda atau kendaraan yang disediakan. Di luar bacaan di atas, berdoalah dengan bahasa sendiri di sepanjang jalan.",
                "Those who are weak, ill, or elderly may perform sa'i using a wheelchair or the provided vehicles. Apart from the recitation above, make supplication in your own words along the way.")
        )),

        Bagian(teks("Tahallul Umrah dan Menanti Hari Haji", "Exiting Ihram After Umrah and Waiting for Hajj"), listOf(
            teks("Setelah sa'i selesai, umrah ditutup dengan tahallul, yaitu memotong rambut (sekurang-kurangnya tiga helai menurut mazhab Syafi'i). Laki-laki lebih utama mencukur gundul pada akhir haji; untuk umrah yang akan disusul haji, sebaiknya memotong pendek agar masih ada rambut yang dicukur saat haji. Perempuan memotong ujung rambutnya sepanjang satu ruas jari.",
                "After sa'i, umrah is closed with tahallul, cutting the hair (at least three hairs in the Shafi'i school). Men are better off shaving completely at the end of hajj; for an umrah followed by hajj, trim short so some hair remains to be shaved at hajj. Women trim a fingertip's length from the ends of the hair."),
            teks("Bagi jamaah tamattu', setelah tahallul umrah seluruh larangan ihram gugur sampai berihram haji kembali. Gunakan waktu ini untuk istirahat, menjaga kesehatan, shalat berjamaah di Masjidil Haram, dan memperbanyak ibadah sunnah, serta memantapkan pemahaman manasik.",
                "For tamattu' pilgrims, after the umrah tahallul all ihram prohibitions lapse until entering ihram for hajj again. Use this time to rest, protect your health, pray in congregation at the Sacred Mosque, increase voluntary worship, and strengthen your understanding of the rites.")
        )),

        Bagian(teks("8 Dzulhijjah: Hari Tarwiyah di Mina", "8 Dhul Hijjah: The Day of Tarwiyah at Mina"), listOf(
            teks("Pada pagi 8 Dzulhijjah, jamaah tamattu' berihram haji dari tempat menginap, mandi, memakai pakaian ihram, berniat haji, dan mengucapkan talbiyah, lalu berangkat ke Mina sesuai jadwal rombongan.",
                "On the morning of 8 Dhul Hijjah, tamattu' pilgrims enter ihram for hajj from where they are staying, bathe, put on ihram clothing, make the intention for hajj, and recite the talbiyah, then leave for Mina according to the group schedule."),
            teks("Di Mina, shalat Zhuhur, Ashar, Maghrib, Isya, dan Subuh dilaksanakan pada waktunya, dengan qashar untuk shalat empat rakaat tanpa jamak. Perbanyak dzikir, talbiyah, dan istirahat, karena hari berikutnya adalah puncak ibadah haji.",
                "At Mina, Zhuhr, Asr, Maghrib, Isha, and Fajr are prayed at their times, shortening the four-rak'ah prayers without combining. Increase remembrance and talbiyah and rest, because the next day is the peak of hajj.")
        )),

        Bagian(teks("9 Dzulhijjah: Wukuf di Arafah", "9 Dhul Hijjah: Standing at Arafah"), listOf(
            teks("الْحَجُّ عَرَفَةُ",
                "Al-hajju 'Arafah.",
                "Haji itu adalah Arafah.",
                "Hajj is Arafah.",
                "HR. Ahmad dan Ashabus Sunan"),
            teks("Wukuf di Arafah adalah rukun haji yang terpenting. Waktunya sejak tergelincir matahari pada 9 Dzulhijjah hingga terbit fajar 10 Dzulhijjah. Cukup hadir di wilayah Arafah, walau sesaat dan dalam keadaan sedang berjalan atau tidur. Orang yang tidak hadir di Arafah pada waktu itu, hajinya tidak sah.",
                "Standing at Arafah is the most important pillar. Its time runs from the sun's decline on 9 Dhul Hijjah until dawn on 10 Dhul Hijjah. Being present within the boundary of Arafah is enough, even briefly and even while moving or sleeping. Whoever is not present at Arafah in that time has no valid hajj."),
            teks("Sebagian besar jamaah berada di Arafah dari Zhuhur hingga Maghrib. Zhuhur dan Ashar dijamak qashar taqdim. Setelah itu sibukkan diri dengan dzikir, istighfar, dan doa sambil menghadap kiblat, mengangkat tangan, dan merendahkan diri. Tidak wajib naik ke Jabal Rahmah.",
                "Most pilgrims are at Arafah from Zhuhr until Maghrib. Zhuhr and Asr are combined and shortened at the earlier time. Then occupy yourself with remembrance, seeking forgiveness, and supplication, facing the qiblah, raising your hands, and humbling yourself. Climbing Jabal Rahmah is not required."),
            teks("Rasulullah shallallahu 'alaihi wasallam bersabda bahwa sebaik-baik doa adalah doa hari Arafah, dan sebaik-baik ucapan beliau dan para nabi sebelumnya adalah:",
                "The Messenger of Allah, peace be upon him, said the best supplication is the supplication of the day of Arafah, and the best of what he and the prophets before him said is:"),
            tahlilArafah,
            teks("اللَّهُمَّ إِنِّي ظَلَمْتُ نَفْسِي ظُلْمًا كَثِيرًا، وَلَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ، فَاغْفِرْ لِي مَغْفِرَةً مِنْ عِنْدِكَ وَارْحَمْنِي، إِنَّكَ أَنْتَ الْغَفُورُ الرَّحِيمُ",
                "Allahumma inni zhalamtu nafsi zhulman katsira, wa la yaghfirudz-dzunuba illa anta, faghfir li maghfiratan min 'indik, warhamni, innaka antal-Ghafurur-Rahim.",
                "Ya Allah, sungguh aku telah banyak menzalimi diriku, dan tidak ada yang dapat mengampuni dosa kecuali Engkau. Maka ampunilah aku dengan ampunan dari sisi-Mu dan rahmatilah aku. Sungguh Engkau Maha Pengampun lagi Maha Penyayang.",
                "O Allah, I have wronged myself greatly, and none forgives sins but You. So forgive me with forgiveness from You and have mercy on me. Indeed You are the Most Forgiving, Most Merciful.",
                "HR. Al-Bukhari dan Muslim"),
            teks("رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",
                "Rabbana zhalamna anfusana wa in lam taghfir lana wa tarhamna lanakunanna minal khasirin.",
                "Ya Tuhan kami, kami telah menzalimi diri kami. Jika Engkau tidak mengampuni kami dan tidak merahmati kami, niscaya kami termasuk orang-orang yang rugi.",
                "Our Lord, we have wronged ourselves, and if You do not forgive us and have mercy on us, we will surely be among the losers.",
                "Al-Qur'an, Al-A'raf 7:23"),
            teks("Doakan diri sendiri, orang tua, keluarga, guru, umat Islam, dan negeri kita. Jaga lisan dan hati dari keluh kesah di tengah panas dan kerumunan.",
                "Pray for yourself, your parents, family, teachers, the Muslims, and our country. Guard tongue and heart from complaint amid the heat and the crowds.")
        )),

        Bagian(teks("Malam Muzdalifah", "The Night at Muzdalifah"), listOf(
            teks("Setelah matahari terbenam pada 9 Dzulhijjah, jamaah bergerak ke Muzdalifah dengan tenang. Di sana shalat Maghrib dan Isya dijamak (qashar untuk Isya) di waktu Isya, lalu bermalam (mabit). Menurut mazhab Syafi'i, mabit sah dengan hadir di Muzdalifah pada separuh malam kedua; yang lemah, sakit, atau lanjut usia diberi keringanan berangkat ke Mina setelah lewat tengah malam.",
                "After sunset on 9 Dhul Hijjah, pilgrims move to Muzdalifah calmly. There Maghrib and Isha are combined (with Isha shortened) at the time of Isha, then the night is spent (mabit). In the Shafi'i school, mabit is valid by being present at Muzdalifah in the second half of the night; the weak, ill, or elderly are given leave to head to Mina after midnight."),
            teks("فَإِذَا أَفَضْتُمْ مِنْ عَرَفَاتٍ فَاذْكُرُوا اللَّهَ عِنْدَ الْمَشْعَرِ الْحَرَامِ",
                "Fa idza afadhtum min 'arafatin fadzkurullaha 'indal masy'aril haram.",
                "Apabila kamu telah bertolak dari Arafah, berdzikirlah kepada Allah di Masy'aril Haram.",
                "When you depart from Arafat, remember Allah at al-Mash'ar al-Haram.",
                "Al-Qur'an, Al-Baqarah 2:198"),
            teks("Setelah shalat Subuh di Muzdalifah, sempatkan berdzikir dan berdoa. Kumpulkan kerikil sebesar biji kacang untuk melempar jumrah (tujuh butir untuk hari pertama; secara keseluruhan sekitar 49 hingga 70 butir untuk seluruh hari). Kerikil boleh diambil di Muzdalifah atau di Mina, dan tidak perlu dicuci.",
                "After Fajr at Muzdalifah, make time for remembrance and supplication. Gather pebbles about the size of a chickpea for stoning (seven for the first day; about 49 to 70 in total for all days). Pebbles may be taken at Muzdalifah or Mina and need not be washed.")
        )),

        Bagian(teks("10 Dzulhijjah: Jumrah Aqabah, Hadyu, dan Tahallul", "10 Dhul Hijjah: Jamrat al-Aqaba, Sacrifice, and Tahallul"), listOf(
            teks("Hari ini ada empat amalan yang disunnahkan berurutan: melempar jumrah Aqabah, menyembelih hadyu, bercukur atau memotong rambut, lalu tawaf ifadhah dan sa'i. Urutan ini lebih utama, tetapi bila terbalik karena uzur atau tidak tahu, tidak mengapa.",
                "Four acts are recommended in order today: stoning Jamrat al-Aqaba, sacrificing the hady, shaving or trimming the hair, then tawaf al-ifadah and sa'i. This order is preferred, but if reversed through excuse or ignorance, there is no harm."),
            teks("Jumrah Aqabah: lempar tujuh kerikil satu per satu ke arah Jumrah Aqabah sambil bertakbir pada setiap lemparan. Mulai melempar, talbiyah dihentikan. Waktu terbaik setelah matahari terbit, dan menurut mazhab Syafi'i sudah boleh sejak lewat tengah malam. Yang tidak sanggup berdesakan dapat mencari waktu yang lebih longgar atau mewakilkan.",
                "Jamrat al-Aqaba: throw seven pebbles one at a time toward it, saying takbir with each. The talbiyah stops once stoning begins. The best time is after sunrise, and in the Shafi'i school it is permitted from after midnight. Those unable to bear the crush can choose a quieter time or delegate."),
            teks("اللَّهُ أَكْبَرُ",
                "Allahu akbar.",
                "Allah Mahabesar. Diucapkan pada setiap lemparan.",
                "Allah is the Greatest. Said with each throw.",
                "HR. Muslim"),
            teks("Hadyu (dam tamattu'): menyembelih seekor kambing, atau berserikat tujuh orang pada seekor sapi atau unta. Bagi yang tidak mampu, berpuasa tiga hari selama haji dan tujuh hari setelah kembali ke tanah air. Penyembelihan umumnya diwakilkan melalui lembaga resmi; pastikan kepada pembimbing.",
                "Hady (tamattu' dam): sacrificing one sheep, or a share of one-seventh in a cow or camel. For those unable, fasting three days during hajj and seven days after returning home. The sacrifice is usually delegated through an official body; confirm with your guide."),
            teks("Tahallul: mencukur atau memotong rambut. Menurut mazhab Syafi'i sekurang-kurangnya tiga helai. Laki-laki lebih utama mencukur gundul; perempuan memotong ujung rambut selebar satu ruas jari. Setelah melempar Aqabah dan bertahallul, sebagian besar larangan ihram gugur, sedangkan larangan yang berkaitan dengan hubungan suami istri tetap berlaku (tahallul awal).",
                "Tahallul: shaving or trimming the hair. In the Shafi'i school, at least three hairs. Men are better off shaving completely; women trim a fingertip's length from the ends. After stoning al-Aqaba and tahallul, most ihram prohibitions lapse, while those relating to marital relations remain in force (the first tahallul)."),
            teks("Tawaf ifadhah adalah rukun haji, dilakukan seperti tawaf biasa tanpa raml dan idhtiba', dilanjutkan sa'i bagi yang belum sa'i haji. Setelah tawaf ifadhah dan sa'i, gugur seluruh larangan ihram (tahallul tsani). Perempuan yang haid saat itu menunggu suci, dan pembimbing akan mengatur jadwalnya.",
                "Tawaf al-ifadah is a pillar of hajj, done like ordinary tawaf without raml and idhtiba', followed by sa'i for those who have not yet done the hajj sa'i. After tawaf al-ifadah and sa'i, all ihram prohibitions lapse (the second tahallul). A woman in her period waits until clean; your guide will arrange the schedule.")
        )),

        Bagian(teks("Hari Tasyrik: Mabit di Mina dan Lempar Jumrah", "Days of Tashriq: Staying at Mina and Stoning the Jamarat"), listOf(
            teks("Pada 11, 12, dan (bagi yang menunda) 13 Dzulhijjah, jamaah bermalam di Mina dan melempar tiga jumrah setiap hari setelah tergelincir matahari, dengan urutan: Jumrah Ula (Shughra), Wustha, lalu Aqabah. Masing-masing tujuh kerikil dengan takbir pada setiap lemparan.",
                "On 11, 12, and (for those who delay) 13 Dhul Hijjah, pilgrims stay overnight at Mina and stone the three jamarat each day after the sun passes its zenith, in order: Ula (Sughra), Wusta, then Aqaba. Seven pebbles each, with takbir on every throw."),
            teks("Setelah melempar Jumrah Ula dan Wustha, sisih sedikit ke tempat lapang, menghadap kiblat, dan berdoa cukup lama. Setelah Jumrah Aqabah, tidak berhenti untuk berdoa.",
                "After stoning Ula and Wusta, step aside to an open spot, face the qiblah, and make a long supplication. After Aqaba, do not stop to pray."),
            teks("فَمَنْ تَعَجَّلَ فِي يَوْمَيْنِ فَلَا إِثْمَ عَلَيْهِ وَمَنْ تَأَخَّرَ فَلَا إِثْمَ عَلَيْهِ لِمَنِ اتَّقَى",
                "Faman ta'ajjala fi yaumaini fala itsma 'alaih, wa man ta'akhkhara fala itsma 'alaih, liman ittaqa.",
                "Barang siapa mempercepat keberangkatan dalam dua hari, tidak ada dosa baginya; dan barang siapa menundanya, tidak ada dosa pula baginya, bagi orang yang bertakwa.",
                "Whoever hastens in two days, there is no sin upon him; and whoever delays, there is no sin upon him, for whoever fears Allah.",
                "Al-Qur'an, Al-Baqarah 2:203"),
            teks("Nafar awal: meninggalkan Mina pada 12 Dzulhijjah setelah melempar tiga jumrah dan sebelum matahari terbenam. Nafar tsani: bermalam lagi pada malam 13 dan melempar jumrah hari itu. Nafar tsani lebih utama. Bila matahari terbenam 12 Dzulhijjah dan masih di Mina, wajib bermalam dan melempar hari ketiga.",
                "Nafar awal: leaving Mina on 12 Dhul Hijjah after stoning the three jamarat and before sunset. Nafar thani: staying the night of the 13th and stoning that day. Nafar thani is better. If sunset on the 12th finds you still at Mina, you must stay and stone on the third day."),
            teks("Jamaah yang uzur boleh mewakilkan melempar jumrah kepada orang lain yang telah melempar untuk dirinya sendiri, sesuai arahan pembimbing.",
                "Pilgrims with a valid excuse may delegate the stoning to someone who has already stoned for themselves, following their guide's direction.")
        )),

        Bagian(teks("Tawaf Wada' dan Kepulangan", "The Farewell Tawaf and Departure"), listOf(
            teks("Sebelum meninggalkan Makkah, kerjakan tawaf wada' sebagai penutup ibadah, dan usahakan menjadi amalan terakhir di Makkah. Perempuan yang sedang haid tidak diwajibkan tawaf wada'. Berdoalah dengan sungguh-sungguh agar haji diterima.",
                "Before leaving Makkah, perform the farewell tawaf as the closing act, and try to make it your last act in Makkah. A woman in her period is not required to do it. Pray earnestly that the hajj be accepted."),
            teks("اللَّهُمَّ اجْعَلْهُ حَجًّا مَبْرُورًا، وَسَعْيًا مَشْكُورًا، وَذَنْبًا مَغْفُورًا",
                "Allahummaj'alhu hajjan mabruran, wa sa'yan masykuran, wa dzanban maghfura.",
                "Ya Allah, jadikanlah ini haji yang mabrur, usaha yang disyukuri, dan dosa yang diampuni.",
                "O Allah, make this an accepted hajj, an appreciated effort, and a forgiven sin.",
                "Doa yang lazim dibaca jamaah"),
            teks("Setelah pulang, jagalah kebaikan yang telah dilatih selama haji: shalat tepat waktu, menjaga lisan, bersabar, dan bersedekah. Itu tanda haji yang diterima.",
                "After returning, keep the good habits trained during hajj: praying on time, guarding the tongue, patience, and charity. These are signs of an accepted hajj.")
        )),

        Bagian(teks("Ziarah ke Madinah", "Visiting Madinah"), listOf(
            teks("Ziarah ke Madinah bukan bagian dari rukun atau wajib haji, tetapi sangat dianjurkan bagi yang berkesempatan. Niatkan perjalanan untuk shalat di Masjid Nabawi, karena shalat di sana lebih utama daripada seribu shalat di masjid lain selain Masjidil Haram.",
                "Visiting Madinah is not a pillar or obligation of hajj, but is highly recommended for those with the opportunity. Intend the trip to pray in the Prophet's Mosque, since a prayer there is better than a thousand prayers in other mosques except the Sacred Mosque."),
            teks("Masuk masjid dengan doa masuk masjid, shalat tahiyatul masjid, lalu bila memungkinkan shalat di Raudhah dan mengucapkan salam kepada Rasulullah, Abu Bakar, dan Umar dengan suara pelan dan penuh adab.",
                "Enter the mosque with the supplication for entering, pray tahiyyat al-masjid, then if possible pray at the Rawdah and greet the Messenger, Abu Bakr, and 'Umar in a low voice with full courtesy."),
            teks("السَّلَامُ عَلَيْكَ يَا رَسُولَ اللَّهِ، السَّلَامُ عَلَيْكَ يَا نَبِيَّ اللَّهِ",
                "Assalamu 'alaika ya Rasulallah, assalamu 'alaika ya Nabiyyallah.",
                "Salam sejahtera atasmu wahai Rasulullah, salam sejahtera atasmu wahai Nabi Allah. Tambahkan shalawat dan doa kebaikan.",
                "Peace be upon you, O Messenger of Allah; peace be upon you, O Prophet of Allah. Add blessings upon him and good supplications.",
                "Salam kepada Rasulullah"),
            teks("Tidak ada ketentuan wajib shalat empat puluh waktu di Masjid Nabawi sebagai bagian dari ibadah haji. Sebagian jamaah melakukannya; yang utama adalah shalat berjamaah semampunya tanpa memberatkan diri.",
                "There is no obligatory requirement to pray forty prayers at the Prophet's Mosque as part of hajj. Some pilgrims do so; what matters is praying in congregation as far as you can without burdening yourself."),
            teks("Tempat lain yang lazim diziarahi: pemakaman Baqi', Masjid Quba (shalat di sana sangat dianjurkan), dan Uhud. Bedakan antara ziarah yang disyariatkan dan hal yang tidak ada tuntunannya; jangan berdoa meminta kepada selain Allah.",
                "Other commonly visited places: the Baqi' cemetery, Quba Mosque (praying there is strongly recommended), and Uhud. Distinguish between prescribed visits and what has no basis; never call upon anyone other than Allah.")
        )),

        Bagian(teks("Kumpulan Doa Al-Qur'an untuk Haji", "Qur'anic Supplications for Hajj"), listOf(
            teks("Doa-doa berikut berasal dari Al-Qur'an dan dapat dibaca kapan saja selama haji, terutama di Multazam, Arafah, dan hari-hari tasyrik. Berdoa dalam bahasa sendiri juga baik.",
                "These supplications come from the Qur'an and may be recited at any time during hajj, especially at the Multazam, Arafah, and the days of tashriq. Praying in your own language is also good."),
            doaSapuJagat,
            teks("رَبَّنَا تَقَبَّلْ مِنَّا إِنَّكَ أَنْتَ السَّمِيعُ الْعَلِيمُ",
                "Rabbana taqabbal minna, innaka antas-sami'ul 'alim.",
                "Ya Tuhan kami, terimalah dari kami. Sungguh Engkaulah Yang Maha Mendengar lagi Maha Mengetahui.",
                "Our Lord, accept this from us. Indeed You are the All-Hearing, All-Knowing.",
                "Al-Qur'an, Al-Baqarah 2:127. Doa Nabi Ibrahim dan Ismail ketika membangun Ka'bah."),
            teks("رَبِّ اغْفِرْ وَارْحَمْ وَأَنْتَ خَيْرُ الرَّاحِمِينَ",
                "Rabbigfir warham wa anta khairur-rahimin.",
                "Ya Tuhanku, ampunilah dan rahmatilah, dan Engkaulah pemberi rahmat yang terbaik.",
                "My Lord, forgive and have mercy, and You are the best of the merciful.",
                "Al-Qur'an, Al-Mu'minun 23:118"),
            teks("رَبَّنَا لَا تُؤَاخِذْنَا إِنْ نَسِينَا أَوْ أَخْطَأْنَا",
                "Rabbana la tu'akhidzna in nasina aw akhtha'na.",
                "Ya Tuhan kami, janganlah Engkau hukum kami jika kami lupa atau salah.",
                "Our Lord, do not hold us accountable if we forget or make a mistake.",
                "Al-Qur'an, Al-Baqarah 2:286"),
            tahlilArafah
        )),

        Bagian(teks("Tips untuk Jamaah Tunanetra dan Penyandang Disabilitas", "Tips for Blind Pilgrims and Pilgrims with Disabilities"), listOf(
            teks("Berangkatlah bersama pendamping yang dapat dipercaya, sebaiknya orang yang sama sepanjang haji. Sepakati cara saling memegang: tangan pada bahu atau siku pendamping, atau tali pendek. Jangan sampai terlepas di keramaian, dan sepakati titik kumpul bila terpisah.",
                "Travel with a trustworthy companion, ideally the same person throughout. Agree on how to hold each other: a hand on the companion's shoulder or elbow, or a short rope. Never let go in a crowd, and agree on a meeting point in case you are separated."),
            teks("Siapkan identitas: gelang atau kartu dengan nama, nomor kloter, hotel, dan nomor petugas, serta pesan singkat dalam bahasa Arab dan Inggris bahwa Anda tunanetra. Hafalkan nama hotel, nomor kamar, dan arah dari pintu masjid ke hotel dengan bantuan pendamping.",
                "Prepare identification: a wristband or card with your name, group number, hotel, and officer's number, plus a short note in Arabic and English that you are blind. Learn your hotel name, room number, and the route from the mosque gate to the hotel with your companion's help."),
            teks("Pelajari manasik lewat rekaman suara dan latihan langsung. Gunakan tongkat lipat bila cocok, perhatikan lantai licin, tangga berjalan, dan kerumunan. Bawa penyumbat telinga hanya bila Anda tetap dapat mendengar arahan.",
                "Learn the rites through audio and hands-on practice. Use a folding cane if suitable, and watch for slippery floors, escalators, and crowds. Bring earplugs only if you can still hear instructions."),
            teks("Di tempat yang sangat padat seperti Hajar Aswad, cukup berisyarat dari kejauhan. Untuk tawaf dan sa'i, jamaah yang tidak sanggup berjalan boleh memakai kursi roda atau dituntun. Waktu yang lebih longgar lebih aman: tengah malam atau dini hari.",
                "In very crowded places such as at the Black Stone, simply gesture from a distance. For tawaf and sa'i, pilgrims unable to walk may use a wheelchair or be guided. Quieter times are safer: late at night or before dawn."),
            teks("Untuk lempar jumrah, Anda dapat melempar sendiri dengan dituntun pendamping pada waktu yang longgar. Bila tidak memungkinkan karena uzur, boleh mewakilkan kepada orang yang telah melempar untuk dirinya. Tanyakan kepada pembimbing agar sesuai ketentuan.",
                "For stoning, you can throw yourself, guided by a companion, at a quiet time. If not possible because of a valid excuse, you may delegate to someone who has stoned for themselves. Ask your guide so it follows the ruling."),
            teks("Banyak minum, berteduh, dan istirahat. Haji bukan lomba; Allah mengetahui kesungguhan dan keterbatasan hamba-Nya.",
                "Drink often, seek shade, and rest. Hajj is not a race; Allah knows the sincerity and limits of His servants.")
        ))
    )
}
