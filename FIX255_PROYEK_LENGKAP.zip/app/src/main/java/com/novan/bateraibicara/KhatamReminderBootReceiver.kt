package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menjadwalkan ulang pengingat Khatam setelah ponsel dinyalakan atau aplikasi diperbarui. */
class KhatamReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        HafalanSrs.jadwalkan(context)
        PengingatBaca.jadwalkan(context)
    }
}
