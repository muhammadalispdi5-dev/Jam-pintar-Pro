package com.novan.bateraibicara

/**
 * Pengaturan milik pengembang. Isi nilai di bawah ini lalu bangun ulang aplikasi.
 * Nilai yang dibiarkan kosong membuat fitur terkait otomatis tidak tampil/nonaktif.
 * Lihat PANDUAN_PEMBARUAN_DAN_KELUHAN.txt di folder proyek untuk contoh dan langkah lengkap.
 */
object AppKonfigurasi {
    /**
     * Alamat HTTPS berkas JSON info versi terbaru, mis.
     * "https://raw.githubusercontent.com/AKUN/REPO/main/version.json".
     * Kosong = gunakan GitHub Releases dari repositori proyek yang ditetapkan di build.gradle.kts.
     */
    val URL_INFO_UPDATE: String = ""

    /**
     * Nomor WhatsApp pengembang (WhatsApp Messenger atau WhatsApp Business) untuk chat dengan pengguna.
     * Format internasional tanpa tanda plus, mis. "6281234567890" (awalan 0 otomatis dianggap Indonesia, 62).
     * Dipakai bila rahasia/properti WHATSAPP_NUMBER saat build kosong. Kosong = fitur chat tidak tampil.
     */
    val NOMOR_WHATSAPP: String = "6281802696080"
}
