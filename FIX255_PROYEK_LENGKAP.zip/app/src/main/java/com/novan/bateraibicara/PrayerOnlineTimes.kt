package com.novan.bateraibicara

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale

/** Sinkronisasi jadwal dari AlAdhan; cache lokal dipakai untuk alarm berikutnya dan fallback offline. */
object PrayerOnlineTimes {
    private const val PREF = "jadwal_sholat_online"

    fun sync(context: Context, finished: (Boolean, String) -> Unit = { _, _ -> }) {
        val app = context.applicationContext
        val pp = PrayerPrefs(app)
        if (!pp.locationSet) { finished(false, BahasaAplikasi.teks(app, "Atur lokasi terlebih dahulu.")); return }
        val prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val signature = ("" + (pp.lat) + "," + (pp.lon) + "," + (pp.method) + "," + (pp.asrFactor) + ",v219")
        val lastSync = prefs.getLong("last_sync", 0L)
        if (prefs.getString("signature", "") == signature && lastSync > 0L && System.currentTimeMillis() - lastSync < 6 * 60 * 60 * 1000L) {
            finished(true, (BahasaAplikasi.teks(app, "Jadwal online masih baru.") + " " + lastSyncLabel(app)))
            return
        }
        Thread {
            var ok = false
            var message = BahasaAplikasi.teks(app, "Internet belum tersedia; jadwal offline tetap digunakan.")
            try {
                val today = LocalDate.now()
                val dates = listOf(today, today.plusMonths(1).withDayOfMonth(1)).distinctBy { it.year to it.monthValue }
                for (monthDate in dates) {
                    val methodId = when (pp.method) {
                        1 -> 3 // MWL
                        2 -> 2 // ISNA
                        3 -> 5 // Egypt
                        4 -> 1 // Karachi
                        5 -> 11 // Singapore
                        6 -> 4 // Umm Al-Qura
                        else -> 20 // Kemenag Indonesia
                    }
                    // AlAdhan memakai school=0 untuk Asar bayangan 1x dan school=1 untuk Hanafi 2x.
                    val schoolId = if (pp.asrFactor == 2) 1 else 0
                    val url = URL(("https://api.aladhan.com/v1/calendar/" + (monthDate.year) + "/" + (monthDate.monthValue) + "?latitude=" + (pp.lat) + "&longitude=" + (pp.lon) + "&method=" + (methodId) + "&school=" + (schoolId)))
                    val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 9000; readTimeout = 12000; requestMethod = "GET" }
                    try {
                        if (conn.responseCode !in 200..299) throw IllegalStateException(BahasaAplikasi.teks(app, "Server jadwal tidak dapat dijangkau."))
                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val data = JSONObject(body).optJSONArray("data") ?: throw IllegalStateException(BahasaAplikasi.teks(app, "Format jadwal online tidak dikenali."))
                        // Jangan menyimpan cache parsial sebagai hasil bulan yang valid.
                        // API semestinya mengembalikan satu entri untuk setiap hari kalender.
                        if (data.length() != monthDate.lengthOfMonth()) {
                            throw IllegalStateException(BahasaAplikasi.teks(app, "Data jadwal online tidak lengkap."))
                        }
                        val sp = app.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                        var validDays = 0
                        val seenDates = HashSet<LocalDate>()
                        for (i in 0 until data.length()) {
                            val item = data.getJSONObject(i)
                            val dateText = item.getJSONObject("date").getJSONObject("gregorian").getString("date")
                            val date = try {
                                LocalDate.parse(dateText, java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.US))
                            } catch (_: Exception) {
                                throw IllegalStateException(BahasaAplikasi.teks(app, "Data jadwal online tidak lengkap."))
                            }
                            // Pastikan tanggal benar-benar milik bulan yang diminta dan tidak ada duplikasi.
                            // Jumlah entri saja tidak cukup: respons bisa berisi tanggal ganda atau bulan yang keliru.
                            if (date.year != monthDate.year || date.monthValue != monthDate.monthValue || !seenDates.add(date)) {
                                throw IllegalStateException(BahasaAplikasi.teks(app, "Data jadwal online tidak lengkap."))
                            }
                            val timings = item.getJSONObject("timings")
                            fun minute(name: String): Int? = timings.optString(name).takeIf { it.isNotBlank() }?.let { raw ->
                                // Cocokkan seluruh nilai waktu, bukan sekadar potongan yang kebetulan
                                // menyerupai HH:mm. AlAdhan dapat menambahkan zona waktu, misalnya
                                // "05:00 (WIB)", sehingga akhiran zona yang wajar tetap diizinkan.
                                val match = Regex("^\\s*(\\d{1,2}):(\\d{2})(?:\\s*\\([^)]*\\))?\\s*\\z").matchEntire(raw)
                                    ?: return@let null
                                val hour = match.groupValues[1].toInt()
                                val minute = match.groupValues[2].toInt()
                                if (hour !in 0..23 || minute !in 0..59) null else hour * 60 + minute
                            }
                            // FIX219: AlAdhan metode 20 tidak memuat ihtiyath. Untuk Kemenag RI, tambahkan
                            // ihtiyath resmi 2 menit agar sama dengan perhitungan lokal dan jadwal resmi.
                            val ih = if (pp.method == 0) PrayerCalc.IHTIYATH_KEMENAG_MENIT else 0
                            val fajrMentah = minute("Fajr") ?: continue
                            val sunriseMentah = minute("Sunrise") ?: continue
                            val fajr = (fajrMentah + ih) % 1440
                            val sunrise = (sunriseMentah - ih + 1440) % 1440
                            val values = JSONObject()
                            values.put("imsak", (fajr - 10 + 1440) % 1440)
                            values.put("subuh", fajr); values.put("terbit", sunrise)
                            values.put("dhuha", (sunriseMentah + 20) % 1440)
                            values.put("dzuhur", ((minute("Dhuhr") ?: continue) + ih) % 1440)
                            values.put("ashar", ((minute("Asr") ?: continue) + ih) % 1440)
                            values.put("maghrib", ((minute("Maghrib") ?: continue) + ih) % 1440)
                            values.put("isya", ((minute("Isha") ?: continue) + ih) % 1440)
                            sp.putString(("times_" + (date)), values.toString())
                            validDays++
                        }
                        if (validDays != monthDate.lengthOfMonth()) {
                            throw IllegalStateException(BahasaAplikasi.teks(app, "Data jadwal online tidak lengkap."))
                        }
                        // Cache tiap bulan boleh disimpan segera, tetapi penanda sinkronisasi
                        // penuh hanya boleh diperbarui setelah SEMUA bulan berhasil diambil.
                        // Jika bulan berikutnya gagal, percobaan berikutnya harus mencoba lagi.
                        sp.apply()
                    } finally { conn.disconnect() }
                }
                // Komit status sinkronisasi setelah seluruh permintaan selesai tanpa error.
                prefs.edit()
                    .putString("signature", signature)
                    .putLong("last_sync", System.currentTimeMillis())
                    .apply()
                ok = true
                message = BahasaAplikasi.teks(app, "Jadwal diperbarui melalui internet. Koreksi menit yang Anda atur tetap diterapkan.")
            } catch (e: Exception) {
                // Tampilkan pesan validasi yang sudah diterjemahkan bila kegagalan
                // memang berasal dari pemeriksaan respons. Untuk error jaringan atau
                // error teknis lain, tetap gunakan pesan umum yang ramah pengguna.
                val pesanValidasi = if (e is IllegalStateException) e.message else null
                message = pesanValidasi?.takeIf { it.isNotBlank() }
                    ?: BahasaAplikasi.teks(app, "Pembaruan online gagal. Jadwal perhitungan offline tetap digunakan.")
            }
            finished(ok, message)
        }.start()
    }

    fun minutes(context: Context, date: LocalDate, key: String, applyAdjustment: Boolean = true): Int? {
        val sp = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val pp = PrayerPrefs(context)
        val signature = ("" + (pp.lat) + "," + (pp.lon) + "," + (pp.method) + "," + (pp.asrFactor) + ",v219")
        if (sp.getString("signature", "") != signature) return null
        val raw = sp.getString(("times_" + (date)), null) ?: return null
        // Cache bisa berasal dari data lama atau berkas preferensi yang rusak.
        // Nilai menit dalam satu hari harus selalu berada pada rentang 0..1439;
        // nilai di luar rentang tidak boleh dipakai untuk menjadwalkan alarm.
        val value = try { JSONObject(raw).optInt(key, -1) } catch (_: Exception) { -1 }
        if (value !in 0..1439) return null
        val adjustmentKey = when (key) {
            "imsak" -> "imsak"; "subuh" -> "subuh"; "terbit" -> "terbit"; "dhuha" -> "dhuha"
            "dzuhur" -> "dzuhur"; "ashar" -> "ashar"; "maghrib" -> "maghrib"; "isya" -> "isya"
            else -> return null
        }
        return ((value + if (applyAdjustment) pp.adjustment(adjustmentKey) else 0) % 1440 + 1440) % 1440
    }

    fun lastSyncLabel(context: Context): String {
        val t = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong("last_sync", 0L)
        if (t == 0L) return BahasaAplikasi.teks(context, "Belum pernah diperbarui melalui internet")

        // Ini adalah informasi antarmuka, bukan ucapan jadwal. Karena itu, nama bulan
        // dan labelnya mengikuti bahasa tampilan, terpisah dari bahasa suara/TTS.
        val localeTampilan = if (BahasaAplikasi.tampilan(context) == 1) Locale.ENGLISH else Locale("id", "ID")
        val tanggal = java.text.SimpleDateFormat("d MMM yyyy, HH:mm", localeTampilan).format(java.util.Date(t))
        val awalan = BahasaAplikasi.teks(context, "Pembaruan terakhir:")
        return ("" + (awalan) + " " + (tanggal))
    }
}
