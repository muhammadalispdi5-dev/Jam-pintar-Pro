package com.novan.bateraibicara

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Build
import android.os.Bundle

/**
 * FIX85: menu ketuk tahan widget di Android 12+ (peluncur yang mendukung "Pengaturan widget") memanggil layar ini.
 * Widget tidak memerlukan konfigurasi, jadi layar ini langsung menyelesaikan hasilnya dan membuka perintah suara.
 * Pada Android 11 ke bawah (dan saat widget baru ditambahkan) layar hanya menutup diri tanpa membuka apa pun.
 */
class BeritahuSayaWidgetConfigActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        if (Build.VERSION.SDK_INT >= 31) {
            try { startActivity(Intent(this, PerintahSuaraActivity::class.java)) } catch (_: Exception) { }
        }
        finish()
    }
}
