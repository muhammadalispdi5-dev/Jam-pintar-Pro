package com.novan.bateraibicara

/**
 * FIX202: himpunan naskah khutbah Jum'at. Naskah disusun sebagai draf asli untuk aplikasi ini (bukan salinan dari
 * penceramah atau buku tertentu). Kutipan Arab dibatasi pada bacaan baku dan ayat/hadits yang masyhur; sebaiknya
 * ditinjau ustadz atau takmir sebelum disampaikan di mimbar.
 */
object KhutbahData {

    /** Satu blok teks. [arab] opsional (kutipan ayat/hadits/doa), [id] dan [en] adalah isi dan terjemahannya. */
    class Blok(val arab: String?, val id: String, val en: String, val sumber: String? = null)

    class Khutbah(
        val judulId: String,
        val judulEn: String,
        val pertama: List<Blok>,
        val kedua: List<Blok>
    )

    private fun teks(id: String, en: String) = Blok(null, id, en)
    private fun teks(arab: String, id: String, en: String, sumber: String? = null) = Blok(arab, id, en, sumber)

    private val pembukaPertama = KhutbahBaku.pembukaPertama
    private val pembukaKedua = KhutbahBaku.pembukaKedua
    private val penutupDoa = KhutbahBaku.penutupDoa

    private val awal: List<Khutbah> = listOf(

        Khutbah(
            "Taqwa, Bekal Terbaik", "Taqwa, the Best Provision",
            listOf(
                pembukaPertama,
                teks("يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ حَقَّ تُقَاتِهِ وَلَا تَمُوتُنَّ إِلَّا وَأَنْتُمْ مُسْلِمُونَ",
                    "Wahai orang-orang yang beriman, bertakwalah kepada Allah dengan sebenar-benar takwa, dan janganlah kamu mati kecuali dalam keadaan muslim.",
                    "O you who believe, fear Allah as He should be feared, and do not die except as Muslims.", "Al-Qur'an, Ali Imran 3:102"),
                teks("Jamaah Jum'at rahimakumullah, marilah kita awali khutbah ini dengan wasiat takwa. Takwa bukan sekadar kata yang diucapkan di mimbar, tetapi kesadaran bahwa Allah selalu melihat kita, sehingga kita menjaga diri dari yang Dia larang dan bersungguh-sungguh dalam yang Dia perintahkan.",
                    "Dear congregation, let us begin this sermon with the counsel of taqwa. Taqwa is not just a word spoken from the pulpit; it is the awareness that Allah is always watching us, so that we guard ourselves from what He forbids and strive in what He commands."),
                teks("Takwa tampak dalam hal-hal kecil: jujur ketika tidak ada yang mengawasi, menahan lisan ketika marah, menunaikan hak orang lain sebelum diminta, dan segera bertobat ketika tergelincir. Orang yang bertakwa tidak merasa dirinya sudah cukup baik, tetapi terus memperbaiki diri.",
                    "Taqwa shows in small things: being honest when no one is watching, restraining the tongue in anger, giving others their rights before being asked, and repenting quickly after a slip. A person of taqwa never feels already good enough, but keeps improving."),
                teks("Rasulullah shallallahu 'alaihi wasallam berpesan agar kita bertakwa kepada Allah di mana pun berada, dan mengiringi keburukan dengan kebaikan yang menghapusnya. Pesan ini diriwayatkan oleh At-Tirmidzi. Artinya, takwa bukan hanya di masjid, tetapi juga di rumah, di pasar, di kantor, dan di dunia maya.",
                    "The Messenger of Allah, peace be upon him, advised us to fear Allah wherever we are and to follow a bad deed with a good one that wipes it out. This advice is reported by at-Tirmidhi. Taqwa is therefore not only for the mosque, but also at home, in the market, at work, and online."),
                teks("Sebagai bekal, mari kita rutinkan shalat tepat waktu, membaca Al-Qur'an setiap hari walau sedikit, bersedekah walau kecil, dan menjaga hubungan baik dengan keluarga dan tetangga. Bekal terbaik bukan harta yang kita tinggalkan, tetapi amal yang kita bawa.",
                    "As provision, let us keep praying on time, read the Qur'an daily even if a little, give charity even if small, and keep good ties with family and neighbors. The best provision is not the wealth we leave behind, but the deeds we carry with us.")
            ),
            listOf(pembukaKedua,
            teks(
                "Jamaah sekalian, kami wasiatkan kepada diri sendiri dan kepada Anda semua untuk senantiasa bertakwa kepada Allah. Mari kita doakan kaum muslimin, orang tua kita, guru-guru kita, dan para pemimpin kita agar diberi petunjuk dan kekuatan menegakkan kebaikan.",
                "Dear brothers and sisters, I counsel myself and all of you to always fear Allah. Let us pray for the Muslims, our parents, our teachers, and our leaders, that they may be guided and strengthened to uphold what is good.")) + penutupDoa
        ),

        Khutbah(
            "Mensyukuri Nikmat Allah", "Being Thankful for Allah's Blessings",
            listOf(
                pembukaPertama,
                teks("وَإِذْ تَأَذَّنَ رَبُّكُمْ لَئِنْ شَكَرْتُمْ لَأَزِيدَنَّكُمْ وَلَئِنْ كَفَرْتُمْ إِنَّ عَذَابِي لَشَدِيدٌ",
                    "Dan ingatlah ketika Tuhanmu memaklumkan: sungguh, jika kamu bersyukur, niscaya Aku akan menambah nikmat kepadamu; tetapi jika kamu mengingkari nikmat-Ku, maka sungguh azab-Ku sangat berat.",
                    "And remember when your Lord proclaimed: if you are grateful, I will surely increase you; but if you are ungrateful, indeed My punishment is severe.", "Al-Qur'an, Ibrahim 14:7"),
                teks("Jamaah Jum'at yang dimuliakan Allah, setiap hari kita menerima nikmat yang tidak sanggup kita hitung: napas, penglihatan, pendengaran, keluarga, makanan, dan iman. Sayangnya, nikmat yang terus ada sering membuat kita lupa bahwa semuanya pemberian.",
                    "Honored congregation, every day we receive blessings we cannot count: breath, sight, hearing, family, food, and faith. Sadly, blessings that never stop often make us forget that all of them are gifts."),
                teks("Syukur memiliki tiga wujud. Pertama, syukur dengan hati: meyakini bahwa semua nikmat berasal dari Allah. Kedua, syukur dengan lisan: memuji-Nya dan menyebut nikmat itu dengan rendah hati. Ketiga, syukur dengan perbuatan: memakai nikmat itu untuk ketaatan dan untuk membantu sesama.",
                    "Gratitude has three forms. First, gratitude of the heart: believing that every blessing comes from Allah. Second, gratitude of the tongue: praising Him and mentioning the blessing humbly. Third, gratitude through action: using the blessing for obedience and for helping others."),
                teks("Orang yang pandai bersyukur melihat ke bawah dalam urusan dunia dan melihat ke atas dalam urusan ibadah. Ia tidak sibuk membandingkan rezekinya dengan rezeki orang lain, tetapi sibuk bertanya: sudahkah nikmat ini kugunakan di jalan yang Allah ridhai?",
                    "A grateful person looks to those with less in worldly matters and to those higher in worship. They are not busy comparing their provision with others', but ask: have I used this blessing in a way Allah is pleased with?"),
                teks("Mari kita mulai dari hal sederhana: mengucap alhamdulillah dengan sadar setelah makan, ketika bangun tidur, dan ketika selamat sampai tujuan; berterima kasih kepada orang yang berbuat baik kepada kita; dan berbagi sebagian rezeki kepada yang membutuhkan.",
                    "Let us start simply: say alhamdulillah mindfully after eating, on waking, and on arriving safely; thank those who do good to us; and share part of our provision with those in need.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, bertakwalah kepada Allah dan jadikan syukur sebagai kebiasaan harian. Semoga Allah menjaga nikmat yang telah ada pada kita dan menambahkan keberkahan atasnya. Marilah kita berdoa.",
                    "Dear brothers and sisters, fear Allah and make gratitude a daily habit. May Allah preserve the blessings we have and add barakah to them. Let us make supplication.")) + penutupDoa
        ),

        Khutbah(
            "Sabar dalam Menghadapi Ujian", "Patience in Times of Trial",
            listOf(
                pembukaPertama,
                teks("يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ",
                    "Wahai orang-orang yang beriman, mohonlah pertolongan dengan sabar dan shalat. Sungguh, Allah bersama orang-orang yang sabar.",
                    "O you who believe, seek help through patience and prayer. Indeed, Allah is with the patient.", "Al-Qur'an, Al-Baqarah 2:153"),
                teks("Jamaah Jum'at rahimakumullah, tidak ada seorang pun yang luput dari ujian: sakit, kehilangan, kesulitan ekonomi, atau konflik dalam keluarga. Ujian bukan tanda Allah membenci kita; sering kali ia cara Allah mengangkat derajat dan membersihkan dosa.",
                    "Dear congregation, no one escapes trials: illness, loss, financial hardship, or conflict in the family. A trial is not a sign that Allah dislikes us; often it is the way Allah raises ranks and cleanses sins."),
                teks("Sabar bukan berarti pasrah tanpa usaha. Sabar adalah menahan diri dari keluh kesah yang tidak pantas, tetap berikhtiar sebaik mungkin, dan menyerahkan hasilnya kepada Allah. Ada sabar dalam menjalankan ketaatan, sabar dalam menjauhi maksiat, dan sabar ketika ditimpa musibah.",
                    "Patience does not mean giving up without effort. Patience is restraining oneself from improper complaint, still striving as best one can, and leaving the outcome to Allah. There is patience in obedience, patience in avoiding sin, and patience when calamity strikes."),
                teks("Rasulullah shallallahu 'alaihi wasallam bersabda bahwa urusan orang beriman itu menakjubkan: bila mendapat kesenangan ia bersyukur, maka itu baik baginya; bila ditimpa kesusahan ia bersabar, maka itu pun baik baginya. Hadits ini diriwayatkan oleh Muslim.",
                    "The Messenger of Allah, peace be upon him, said that the affair of the believer is wondrous: if good comes he is grateful and that is good for him; if hardship comes he is patient and that is also good for him. This hadith is reported by Muslim."),
                teks("Saat ujian datang, mari kita perbanyak shalat dan doa, ceritakan beban kepada orang yang dapat dipercaya, dan jangan menyendiri. Ingatlah bahwa setiap kesulitan ada batasnya dan Allah tidak membebani seseorang di luar kemampuannya.",
                    "When trials come, let us increase prayer and supplication, share our burdens with trustworthy people, and not isolate ourselves. Remember that every hardship has an end and Allah does not burden a soul beyond its capacity.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, kuatkanlah saudara-saudara kita yang sedang diuji dengan kunjungan, doa, dan bantuan nyata. Semoga Allah menguatkan hati kita semua dan menjadikan kita termasuk orang-orang yang sabar.",
                    "Dear brothers and sisters, strengthen those among us who are being tested with visits, prayers, and practical help. May Allah strengthen all our hearts and make us among the patient.")) + penutupDoa
        ),

        Khutbah(
            "Berbakti kepada Orang Tua", "Honoring Parents",
            listOf(
                pembukaPertama,
                teks("وَقَضَى رَبُّكَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا",
                    "Dan Tuhanmu telah memerintahkan agar kamu jangan menyembah selain Dia, dan hendaklah berbuat baik kepada ibu bapak.",
                    "Your Lord has decreed that you worship none but Him, and that you be good to your parents.", "Al-Qur'an, Al-Isra 17:23"),
                teks("Jamaah Jum'at rahimakumullah, perhatikanlah bahwa Allah menyebutkan berbuat baik kepada orang tua langsung setelah perintah mentauhidkan-Nya. Ini menunjukkan betapa tinggi kedudukan berbakti kepada keduanya.",
                    "Dear congregation, note that Allah mentions being good to parents right after the command to worship Him alone. This shows how high the rank of honoring them is."),
                teks("Seorang sahabat bertanya kepada Rasulullah shallallahu 'alaihi wasallam, siapakah orang yang paling berhak dipergauli dengan baik. Beliau menjawab: ibumu, kemudian ibumu, kemudian ibumu, kemudian ayahmu. Hadits ini disepakati oleh Al-Bukhari dan Muslim.",
                    "A companion asked the Messenger of Allah, peace be upon him, who is most deserving of good companionship. He replied: your mother, then your mother, then your mother, then your father. This hadith is agreed upon by al-Bukhari and Muslim."),
                teks("Berbakti bukan hanya ketika orang tua masih kuat. Ketika mereka menua, mereka butuh kesabaran, perhatian, dan kata-kata yang lembut. Jangan sampai kesibukan kita membuat mereka merasa sendiri. Telepon, kunjungi, dengarkan cerita mereka, dan penuhi kebutuhan mereka sesuai kemampuan.",
                    "Honoring parents is not only for when they are strong. As they age, they need patience, attention, and gentle words. Do not let our busyness make them feel alone. Call, visit, listen to their stories, and meet their needs as far as we are able."),
                teks("Bila orang tua telah wafat, pintu bakti belum tertutup: doakan mereka, lunasi utang dan janji mereka, sambung silaturahmi dengan kerabat dan sahabat mereka, dan teruskan amal jariyah atas nama mereka.",
                    "If our parents have passed away, the door of devotion is not closed: pray for them, settle their debts and promises, keep ties with their relatives and friends, and continue charity on their behalf.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, mari kita mohon ampunan bagi orang tua kita, yang masih hidup maupun yang telah tiada, dan memohon agar Allah menjadikan kita anak-anak yang menyejukkan hati mereka.",
                    "Dear brothers and sisters, let us ask forgiveness for our parents, living and deceased, and ask Allah to make us children who bring comfort to their hearts.")) + penutupDoa
        ),

        Khutbah(
            "Persaudaraan Sesama Muslim", "Brotherhood and Sisterhood in Islam",
            listOf(
                pembukaPertama,
                teks("إِنَّمَا الْمُؤْمِنُونَ إِخْوَةٌ فَأَصْلِحُوا بَيْنَ أَخَوَيْكُمْ وَاتَّقُوا اللَّهَ لَعَلَّكُمْ تُرْحَمُونَ",
                    "Sesungguhnya orang-orang mukmin itu bersaudara. Maka damaikanlah antara kedua saudaramu dan bertakwalah kepada Allah agar kamu mendapat rahmat.",
                    "The believers are but brothers, so make peace between your brothers and fear Allah that you may receive mercy.", "Al-Qur'an, Al-Hujurat 49:10"),
                teks("Jamaah Jum'at rahimakumullah, iman mengikat kita dalam persaudaraan yang melampaui suku, daerah, dan golongan. Ikatan ini mahal, namun mudah retak oleh prasangka, gunjingan, dan sikap merasa paling benar.",
                    "Dear congregation, faith binds us in a brotherhood and sisterhood beyond tribe, region, and group. This bond is precious, yet easily cracked by suspicion, gossip, and self-righteousness."),
                teks("Rasulullah shallallahu 'alaihi wasallam menggambarkan orang beriman terhadap orang beriman lainnya seperti satu bangunan yang saling menguatkan. Hadits ini diriwayatkan oleh Al-Bukhari dan Muslim. Bayangkan jika satu batu dicabut: bangunan itu melemah.",
                    "The Messenger of Allah, peace be upon him, likened the believer to another believer as parts of one building that strengthen each other. This hadith is reported by al-Bukhari and Muslim. Imagine one brick removed: the building weakens."),
                teks("Wujud persaudaraan itu sederhana: menyapa dengan salam, menjenguk yang sakit, membantu yang kesulitan, memaafkan yang bersalah, membela kehormatan saudara yang tidak hadir, dan tidak menyebarkan kabar yang belum jelas kebenarannya.",
                    "Brotherhood and sisterhood is expressed simply: greeting with salam, visiting the sick, helping those in difficulty, forgiving those who err, defending the honor of an absent brother or sister, and not spreading news of uncertain truth."),
                teks("Bila terjadi perselisihan, jangan menunggu menjadi besar. Datangi, bicara baik-baik, dan carilah penengah yang adil. Ingatlah bahwa mengalah demi persatuan bukan kekalahan.",
                    "When disputes arise, do not wait until they grow. Approach, speak kindly, and seek a fair mediator. Remember that yielding for the sake of unity is not defeat.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, mari bersihkan hati dari dengki dan prasangka. Semoga Allah menyatukan hati kaum muslimin dan menjadikan masjid ini tempat tumbuhnya kasih sayang.",
                    "Dear brothers and sisters, let us cleanse our hearts of envy and suspicion. May Allah unite the hearts of the Muslims and make this mosque a place where compassion grows.")) + penutupDoa
        ),

        Khutbah(
            "Menjaga Lisan", "Guarding the Tongue",
            listOf(
                pembukaPertama,
                teks("يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَقُولُوا قَوْلًا سَدِيدًا. يُصْلِحْ لَكُمْ أَعْمَالَكُمْ وَيَغْفِرْ لَكُمْ ذُنُوبَكُمْ",
                    "Wahai orang-orang yang beriman, bertakwalah kepada Allah dan ucapkanlah perkataan yang benar. Niscaya Dia memperbaiki amal-amalmu dan mengampuni dosa-dosamu.",
                    "O you who believe, fear Allah and speak words of truth. He will rectify your deeds for you and forgive your sins.", "Al-Qur'an, Al-Ahzab 33:70-71"),
                teks("Jamaah Jum'at rahimakumullah, lisan hanya segumpal daging yang tidak bertulang, namun bisa membangun atau menghancurkan. Satu kalimat dapat menenangkan hati, dan satu kalimat lain dapat melukai bertahun-tahun.",
                    "Dear congregation, the tongue is just a small piece of flesh without bone, yet it can build or destroy. One sentence can calm a heart, and another can wound for years."),
                teks("مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ",
                    "Barang siapa beriman kepada Allah dan hari akhir, hendaklah ia berkata baik atau diam.",
                    "Whoever believes in Allah and the Last Day, let him speak good or remain silent.", "HR. Al-Bukhari dan Muslim"),
                teks("Di zaman gawai, lisan kita bukan hanya yang keluar dari mulut, tetapi juga jari yang mengetik dan membagikan. Menyebarkan kabar bohong, menghina, atau membuka aib orang lain di media sosial sama beratnya dengan mengucapkannya langsung.",
                    "In the age of phones, our tongue is not only what comes from the mouth but also the fingers that type and share. Spreading false news, insulting, or exposing others' faults online is as grave as saying it face to face."),
                teks("Latih diri dengan tiga pertanyaan sebelum berbicara atau mengirim pesan: apakah ini benar, apakah ini bermanfaat, dan apakah ini pantas disampaikan sekarang? Bila salah satunya tidak terpenuhi, diam lebih selamat.",
                    "Train yourself with three questions before speaking or sending a message: is it true, is it useful, and is it appropriate to say now? If any is missing, silence is safer.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, marilah kita basahi lisan dengan dzikir, ucapan baik, dan nasihat yang lembut. Siapa yang pernah kita sakiti dengan ucapan, segeralah minta maaf.",
                    "Dear brothers and sisters, let us keep our tongues moist with remembrance of Allah, good words, and gentle advice. Whoever we have hurt with our words, let us hurry to apologize.")) + penutupDoa
        ),

        Khutbah(
            "Menjaga Amanah", "Keeping Trusts",
            listOf(
                pembukaPertama,
                teks("إِنَّ اللَّهَ يَأْمُرُكُمْ أَنْ تُؤَدُّوا الْأَمَانَاتِ إِلَى أَهْلِهَا",
                    "Sesungguhnya Allah menyuruh kamu menyampaikan amanat kepada yang berhak menerimanya.",
                    "Indeed, Allah commands you to render trusts to whom they are due.", "Al-Qur'an, An-Nisa 4:58"),
                teks("Jamaah Jum'at rahimakumullah, amanah tidak hanya berupa uang titipan. Jabatan, waktu, rahasia, anak-anak, ilmu, dan kesehatan kita semuanya amanah yang kelak ditanya oleh Allah.",
                    "Dear congregation, a trust is not only money left in our care. Position, time, secrets, children, knowledge, and our health are all trusts about which Allah will ask."),
                teks("Rasulullah shallallahu 'alaihi wasallam menyebut tanda orang munafik ada tiga: bila berbicara ia berdusta, bila berjanji ia mengingkari, dan bila dipercaya ia berkhianat. Hadits ini disepakati oleh Al-Bukhari dan Muslim. Maka menjaga amanah adalah cermin iman.",
                    "The Messenger of Allah, peace be upon him, named three signs of a hypocrite: when he speaks he lies, when he promises he breaks it, and when entrusted he betrays. This hadith is agreed upon by al-Bukhari and Muslim. Keeping trusts is therefore a mirror of faith."),
                teks("Seorang pekerja yang amanah datang tepat waktu dan tidak mengambil yang bukan haknya. Seorang pemimpin yang amanah mendahulukan kepentingan orang banyak. Seorang orang tua yang amanah mendidik anaknya dengan ilmu dan teladan. Seorang pedagang yang amanah tidak menyembunyikan cacat barang.",
                    "A trustworthy worker comes on time and takes nothing that is not theirs. A trustworthy leader puts the public interest first. A trustworthy parent raises children with knowledge and example. A trustworthy merchant does not hide a defect in goods."),
                teks("Mulailah dari hal kecil: tepati janji, kembalikan pinjaman tepat waktu, dan jaga rahasia orang yang percaya kepada kita. Amanah yang kecil melatih kita memikul amanah yang besar.",
                    "Start small: keep promises, return loans on time, and guard the secrets of those who trust us. Small trusts train us to bear great ones.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, mari kita mohon kepada Allah agar dijadikan hamba yang dapat dipercaya, dan para pemimpin kita diberi kejujuran serta kemampuan menunaikan amanahnya.",
                    "Dear brothers and sisters, let us ask Allah to make us trustworthy servants, and to grant our leaders honesty and the ability to fulfill their trusts.")) + penutupDoa
        ),

        Khutbah(
            "Memuliakan Ilmu, Menghormati Penuntutnya", "Honoring Knowledge, Honoring Its Seekers",
            listOf(
                pembukaPertama,
                teks("يَرْفَعِ اللَّهُ الَّذِينَ آمَنُوا مِنْكُمْ وَالَّذِينَ أُوتُوا الْعِلْمَ دَرَجَاتٍ",
                    "Allah akan mengangkat derajat orang-orang yang beriman di antara kamu dan orang-orang yang diberi ilmu beberapa derajat.",
                    "Allah will raise those who believe among you and those given knowledge by degrees.", "Al-Qur'an, Al-Mujadilah 58:11"),
                teks("Jamaah Jum'at rahimakumullah, wahyu pertama yang turun adalah perintah membaca. Ini menunjukkan bahwa Islam adalah agama yang mencintai ilmu dan menjadikannya jalan mengenal Allah.",
                    "Dear congregation, the first revelation was the command to read. This shows that Islam loves knowledge and makes it a path to knowing Allah."),
                teks("Rasulullah shallallahu 'alaihi wasallam bersabda bahwa siapa yang menempuh jalan untuk mencari ilmu, Allah mudahkan baginya jalan menuju surga. Hadits ini diriwayatkan oleh Muslim. Maka setiap langkah ke majelis ilmu, setiap buku yang dibaca dengan niat baik, bernilai ibadah.",
                    "The Messenger of Allah, peace be upon him, said that whoever travels a path seeking knowledge, Allah makes easy for him a path to Paradise. This hadith is reported by Muslim. Every step to a gathering of knowledge, every book read with good intention, is worship."),
                teks("Ilmu yang bermanfaat melahirkan adab, bukan kesombongan. Semakin banyak seseorang tahu, semakin ia merasa butuh belajar. Ia menghormati guru, sabar terhadap yang belum paham, dan mengamalkan apa yang diketahuinya.",
                    "Beneficial knowledge gives rise to good manners, not arrogance. The more a person knows, the more they feel the need to learn. They respect teachers, are patient with those who do not yet understand, and act on what they know."),
                teks("Mari kita sisihkan waktu setiap hari untuk belajar agama, mendorong anak-anak mencintai Al-Qur'an dan ilmu, dan mendukung para penuntut ilmu, entah dengan tenaga, pikiran, maupun harta.",
                    "Let us set aside time each day to learn our religion, encourage our children to love the Qur'an and knowledge, and support seekers of knowledge with effort, thought, or wealth.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, semoga Allah menganugerahkan kita ilmu yang bermanfaat, hati yang khusyuk, dan amal yang diterima. Marilah kita berdoa.",
                    "Dear brothers and sisters, may Allah grant us beneficial knowledge, a humble heart, and accepted deeds. Let us make supplication.")) + penutupDoa
        ),

        Khutbah(
            "Menjaga Shalat", "Preserving the Prayer",
            listOf(
                pembukaPertama,
                teks("إِنَّ الصَّلَاةَ تَنْهَى عَنِ الْفَحْشَاءِ وَالْمُنْكَرِ",
                    "Sesungguhnya shalat itu mencegah dari perbuatan keji dan mungkar.",
                    "Indeed, prayer prevents indecency and wrongdoing.", "Al-Qur'an, Al-Ankabut 29:45"),
                teks("Jamaah Jum'at rahimakumullah, shalat adalah tiang ibadah dan penghubung langsung antara hamba dengan Tuhannya, lima kali setiap hari. Tidak ada ibadah lain yang diulang sesering itu.",
                    "Dear congregation, prayer is the pillar of worship and the direct link between the servant and the Lord, five times every day. No other act of worship is repeated so often."),
                teks("Rasulullah shallallahu 'alaihi wasallam menegaskan bahwa pembatas antara seseorang dengan kesyirikan dan kekafiran adalah meninggalkan shalat. Hadits ini diriwayatkan oleh Muslim. Karena itu, shalat tidak boleh dianggap sepele, apalagi ditunda sampai di akhir waktu tanpa uzur.",
                    "The Messenger of Allah, peace be upon him, stressed that what separates a person from shirk and disbelief is abandoning prayer. This hadith is reported by Muslim. Prayer must therefore not be taken lightly, let alone delayed to the very end of its time without excuse."),
                teks("Shalat yang khusyuk dimulai dari persiapan: wudhu yang tenang, hadir lebih awal, dan menjauhkan gawai. Di dalam shalat, pahami makna bacaan yang kita ucapkan, agar hati ikut berbicara kepada Allah.",
                    "A humble prayer starts with preparation: calm wudhu, arriving early, and putting devices away. In prayer, understand the meaning of what we recite so that the heart also speaks to Allah."),
                teks("Ajaklah keluarga untuk shalat berjamaah, biasakan anak-anak sejak dini, dan saling mengingatkan dengan lembut. Rumah yang hidup dengan shalat akan dipenuhi ketenangan.",
                    "Invite the family to pray in congregation, accustom the children from an early age, and remind each other gently. A home alive with prayer is filled with calm.")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, mari kita mohon kepada Allah agar dijadikan orang-orang yang mendirikan shalat, beserta anak cucu kita. Marilah kita berdoa.",
                    "Dear brothers and sisters, let us ask Allah to make us, and our children and grandchildren, among those who establish the prayer. Let us make supplication.")) + penutupDoa
        ),

        Khutbah(
            "Menghargai Waktu", "Valuing Time",
            listOf(
                pembukaPertama,
                teks("وَالْعَصْرِ. إِنَّ الْإِنْسَانَ لَفِي خُسْرٍ. إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ",
                    "Demi masa. Sungguh, manusia benar-benar berada dalam kerugian, kecuali orang-orang yang beriman, mengerjakan kebajikan, saling menasihati untuk kebenaran, dan saling menasihati untuk kesabaran.",
                    "By time. Indeed, mankind is in loss, except those who believe, do righteous deeds, advise one another to truth, and advise one another to patience.", "Al-Qur'an, Al-'Asr 103:1-3"),
                teks("Jamaah Jum'at rahimakumullah, Allah bersumpah dengan waktu karena waktu adalah modal terbesar manusia. Ia berjalan tanpa bisa dihentikan atau dibeli kembali. Setiap detik yang lewat tidak akan pernah kembali.",
                    "Dear congregation, Allah swears by time because time is mankind's greatest capital. It moves on and cannot be stopped or bought back. Every second that passes never returns."),
                teks("Rasulullah shallallahu 'alaihi wasallam bersabda bahwa ada dua nikmat yang banyak manusia tertipu padanya: kesehatan dan waktu luang. Hadits ini diriwayatkan oleh Al-Bukhari. Kita baru menyadari nilainya ketika sakit dan ketika waktu sudah sempit.",
                    "The Messenger of Allah, peace be upon him, said there are two blessings in which many people are deceived: health and free time. This hadith is reported by al-Bukhari. We realize their value only when ill and when time has run short."),
                teks("Menghargai waktu berarti menyusun prioritas: ibadah yang wajib, tanggung jawab kepada keluarga, pekerjaan yang halal, dan belajar. Kurangi waktu yang terbuang untuk hiburan tanpa batas, gulir layar tanpa tujuan, dan percakapan yang tidak bermanfaat.",
                    "Valuing time means setting priorities: obligatory worship, duties to family, lawful work, and learning. Reduce time lost to endless entertainment, aimless scrolling, and unhelpful talk."),
                teks("Mulailah hari dengan shalat Subuh tepat waktu, buat daftar sederhana tentang apa yang ingin diselesaikan, dan akhiri hari dengan muhasabah: apa yang sudah kulakukan hari ini untuk bekal akhiratku?",
                    "Begin the day with Fajr on time, make a simple list of what you want to accomplish, and end the day with self-reflection: what have I done today for my Hereafter?")
            ),
            listOf(pembukaKedua,
                teks("Jamaah sekalian, semoga Allah memberkahi umur kita dan menjadikan akhir hidup kita yang terbaik. Marilah kita berdoa.",
                    "Dear brothers and sisters, may Allah bless our lives and make the end of our lives the best. Let us make supplication.")) + penutupDoa
        )
    )

    /** Seluruh naskah: sepuluh naskah awal, lalu tambahan bertema ibadah/akidah/hari besar dan akhlak/keluarga/masyarakat. */
    val daftar: List<Khutbah> = awal + KhutbahTambahanA.daftar + KhutbahTambahanB.daftar + KhutbahTambahanC.daftar + KhutbahTambahanD.daftar
}
