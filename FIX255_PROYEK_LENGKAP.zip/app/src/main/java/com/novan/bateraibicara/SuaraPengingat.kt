package com.novan.bateraibicara

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Pengaturan bersama sumber suara untuk pengingat membaca dan pengingat hafalan. */
object SuaraPengingat {
    data class Konfigurasi(val channelId: String, val sound: Uri?, val gunakanTts: Boolean, val alarm: Boolean)

    fun siapkan(
        context: Context,
        channelDasar: String,
        namaChannel: String,
        prefs: android.content.SharedPreferences,
        prefix: String
    ): Konfigurasi {
        val mode = prefs.getString("${prefix}_mode", "alarm") ?: "alarm"
        val uri = when (mode) {
            "custom" -> prefs.getString("${prefix}_uri", null)?.let { Uri.parse(it) }
            "alarm" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            "notif" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            else -> null
        }
        val tts = mode == "tts"
        val suffix = Integer.toHexString((mode + "_" + (uri?.toString() ?: "speech")).hashCode())
        val channelId = "${channelDasar}_$suffix"
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(channelId, namaChannel, NotificationManager.IMPORTANCE_DEFAULT)
            val attributes = AudioAttributes.Builder()
                .setUsage(if (mode == "alarm") AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            channel.setSound(if (tts) null else uri, if (tts) null else attributes)
            manager.createNotificationChannel(channel)
        }
        return Konfigurasi(channelId, uri, tts, mode == "alarm")
    }

    fun aturSuara(builder: Notification.Builder, konfigurasi: Konfigurasi) {
        if (Build.VERSION.SDK_INT < 26) {
            if (!konfigurasi.gunakanTts && konfigurasi.sound != null) {
                val attributes = AudioAttributes.Builder()
                    .setUsage(if (konfigurasi.alarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                builder.setSound(konfigurasi.sound, attributes)
            } else builder.setSound(null)
        }
    }

    /** Jalankan TTS singkat dari BroadcastReceiver dan selesaikan goAsync setelah ucapan berakhir. */
    fun ucapkan(context: Context, kalimat: String, english: Boolean, selesai: () -> Unit) {
        val utama = Handler(Looper.getMainLooper())
        var tts: TextToSpeech? = null
        var selesaiSekali = false
        fun akhiri() {
            if (selesaiSekali) return
            selesaiSekali = true
            try { tts?.stop() } catch (_: Exception) { }
            try { tts?.shutdown() } catch (_: Exception) { }
            selesai()
        }
        utama.postDelayed({ akhiri() }, 18_000L)
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (selesaiSekali) return@TextToSpeech
                if (status != TextToSpeech.SUCCESS) { akhiri(); return@TextToSpeech }
                try {
                    val engine = tts ?: run { akhiri(); return@TextToSpeech }
                    engine.setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                    val locale = if (english) Locale.US else Locale("id", "ID")
                    val hasil = engine.setLanguage(locale)
                    if (hasil == TextToSpeech.LANG_MISSING_DATA || hasil == TextToSpeech.LANG_NOT_SUPPORTED) {
                        akhiri(); return@TextToSpeech
                    }
                    engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) = Unit
                        override fun onDone(utteranceId: String?) { utama.post { akhiri() } }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { utama.post { akhiri() } }
                        override fun onError(utteranceId: String?, errorCode: Int) { utama.post { akhiri() } }
                    })
                    val params = android.os.Bundle()
                    engine.speak(kalimat, TextToSpeech.QUEUE_FLUSH, params, "reminder_" + UUID.randomUUID())
                } catch (_: Exception) { akhiri() }
            }
        } catch (_: Exception) { akhiri() }
    }
}
