package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Menerima pemicu alarm jam: membunyikan alarm, menonaktifkan alarm sekali pakai, dan memasang jadwal berikutnya. */
class AlarmJamReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmJam.AKSI_BUNYI) return
        val app = context.applicationContext
        val id = intent.getIntExtra("alarm_id", -1)
        val tunda = intent.getBooleanExtra("tunda", false)
        val item = AlarmJam.cari(app, id)
        if (item == null) {
            AlarmJam.jadwalkanSemua(app)
            return
        }
        if (tunda) {
            AlarmJam.hapusTunda(app, id)
        } else {
            if (!item.aktif) { AlarmJam.jadwalkanSemua(app); return }
            // Alarm sekali pakai mati setelah berbunyi; alarm berulang dijadwalkan ke kemunculan berikutnya.
            if (item.hari == 0) { item.aktif = false; AlarmJam.perbarui(app, item) } else AlarmJam.jadwalkanSemua(app)
        }
        val layanan = Intent(app, AlarmJamService::class.java).putExtra("alarm_id", id)
        try {
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(layanan) else app.startService(layanan)
        } catch (_: Exception) { }
    }
}
