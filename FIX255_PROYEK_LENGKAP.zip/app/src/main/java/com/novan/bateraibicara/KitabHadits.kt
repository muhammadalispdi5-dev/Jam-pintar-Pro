package com.novan.bateraibicara

import android.content.Context
import android.util.JsonReader
import android.util.JsonWriter
import java.util.Locale
import android.util.JsonToken
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX198: data Kitab Hadits. Teks hadits TIDAK ditulis di dalam aplikasi; diunduh sekali dari layanan hadits publik
 * (proyek fawazahmed0/hadith-api lewat jsDelivr, cadangan GitHub), disimpan di penyimpanan aplikasi, lalu dibaca
 * secara bertahap (streaming) sehingga memori tetap kecil dan dapat dibaca tanpa internet.
 */
object KitabHadits {

    class Kitab(
        val kode: String,
        val judulId: String,
        val judulEn: String,
        /** Kandidat nama edisi Arab (dicoba berurutan). */
        val arab: List<String>,
        /** Kandidat nama edisi terjemahan Indonesia (opsional). */
        val indo: List<String>,
        /** Kitab yang seluruh haditsnya shahih (derajat tidak perlu dibaca dari data). */
        val seluruhShahih: Boolean,
        /** Sumber berkas SQL (cadangan bila edisi tidak ada di layanan JSON); dikonversi di perangkat. */
        val sumberSql: List<String> = emptyList()
    )

    val daftar = listOf(
        Kitab("bukhari", "Shahih Bukhari", "Sahih al-Bukhari", listOf("ara-bukhari"), listOf("ind-bukhari"), true),
        Kitab("muslim", "Shahih Muslim", "Sahih Muslim", listOf("ara-muslim"), listOf("ind-muslim"), true),
        Kitab("arbain", "Arbain Nawawi (40 Hadits)", "Forty Hadith of an-Nawawi", listOf("ara-nawawi"), listOf("ind-nawawi"), false),
        // FIX201: Riyadhus Shalihin tidak ada di layanan JSON; diunduh dari berkas SQL terjemahan Indonesia (MIT) lalu dikonversi.
        Kitab("riyadus", "Riyadhus Shalihin", "Riyad as-Salihin", listOf("ara-riyadus"), listOf("ind-riyadus"), false,
            listOf(
                "https://raw.githubusercontent.com/irsyadulibad/hadits-database/main/riyadhus-shalihin.sql",
                "https://cdn.jsdelivr.net/gh/irsyadulibad/hadits-database@main/riyadhus-shalihin.sql"
            ))
    )

    fun cari(kode: String?): Kitab? = daftar.firstOrNull { it.kode == kode }

    class Hadis(val nomor: String, val teks: String, val bagian: Int, val derajat: String)

    /** [indoSaja]: berkas hanya memuat teks terjemahan Indonesia (tanpa teks Arab). */
    class Hasil(val bagian: Map<Int, String>, val item: List<Hadis>, val adaLagi: Boolean, val indoSaja: Boolean = false)

    private fun folder(context: Context): File = File(context.filesDir, "hadits").also { it.mkdirs() }

    private fun berkas(context: Context, edisi: String) = File(folder(context), edisi + ".json")

    /** Berkas edisi pertama dari daftar kandidat yang sudah diunduh, atau null. */
    fun berkasAda(context: Context, kandidat: List<String>): File? =
        kandidat.map { berkas(context, it) }.firstOrNull { it.exists() && it.length() > 1024 }

    fun tersedia(context: Context, k: Kitab): Boolean = berkasAda(context, k.arab) != null

    fun hapus(context: Context, k: Kitab) {
        (k.arab + k.indo).forEach { try { berkas(context, it).delete() } catch (_: Exception) { } }
    }

    private fun alamat(edisi: String): List<String> = listOf(
        "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/" + edisi + ".min.json",
        "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/" + edisi + ".json",
        "https://raw.githubusercontent.com/fawazahmed0/hadith-api/1/editions/" + edisi + ".json"
    )

    /**
     * Unduh edisi pertama yang berhasil dari [kandidat]. Dipanggil dari utas latar.
     * [lapor] menerima jumlah byte yang sudah diterima. Mengembalikan berkas, atau null bila semua gagal.
     */
    fun unduh(context: Context, kandidat: List<String>, lapor: (Long) -> Unit): File? {
        for (edisi in kandidat) {
            for (url in alamat(edisi)) {
                val sementara = File(folder(context), edisi + ".part")
                var koneksi: HttpURLConnection? = null
                try {
                    koneksi = (URL(url).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000; readTimeout = 30000; requestMethod = "GET"; instanceFollowRedirects = true
                    }
                    if (koneksi.responseCode !in 200..299) continue
                    var total = 0L
                    koneksi.inputStream.use { masuk ->
                        FileOutputStream(sementara).use { keluar ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = masuk.read(buf)
                                if (n < 0) break
                                keluar.write(buf, 0, n)
                                total += n
                                lapor(total)
                            }
                        }
                    }
                    // Validasi: harus bisa dibaca dan memuat setidaknya satu hadits.
                    val uji = baca(sementara, 0, 1, false) { _, _ -> true }
                    if (total > 1024 && uji.item.isNotEmpty()) {
                        val tujuan = berkas(context, edisi)
                        tujuan.delete()
                        if (sementara.renameTo(tujuan)) return tujuan
                    }
                    sementara.delete()
                } catch (_: Exception) {
                    try { sementara.delete() } catch (_: Exception) { }
                } finally {
                    try { koneksi?.disconnect() } catch (_: Exception) { }
                }
            }
        }
        return null
    }

    private fun JsonReader.teksAtauKosong(): String = when (peek()) {
        JsonToken.STRING, JsonToken.NUMBER -> nextString()
        JsonToken.NULL -> { nextNull(); "" }
        else -> { skipValue(); "" }
    }

    private fun rapikanNomor(n: String): String = if (n.endsWith(".0")) n.substring(0, n.length - 2) else n

    /**
     * Baca berkas edisi secara bertahap. [lewati] hadits yang cocok dilompati, lalu diambil paling banyak [batas].
     * [hanyaMetadata] = berhenti begitu daftar hadits dimulai (untuk mengambil nama bagian saja).
     */
    fun baca(file: File, lewati: Int, batas: Int, hanyaMetadata: Boolean, cocok: (String, Int) -> Boolean): Hasil {
        val bagian = LinkedHashMap<Int, String>()
        val item = ArrayList<Hadis>()
        var adaLagi = false
        var dilewati = 0
        var indoSaja = false
        val pembaca = JsonReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8).buffered())
        try {
            pembaca.beginObject()
            while (pembaca.hasNext()) {
                when (pembaca.nextName()) {
                    "metadata" -> {
                        if (pembaca.peek() != JsonToken.BEGIN_OBJECT) { pembaca.skipValue(); continue }
                        pembaca.beginObject()
                        while (pembaca.hasNext()) {
                            val kunciMeta = pembaca.nextName()
                            if (kunciMeta == "name") {
                                if (pembaca.teksAtauKosong() == "id-only") indoSaja = true
                            } else if (kunciMeta == "section" && pembaca.peek() == JsonToken.BEGIN_OBJECT) {
                                pembaca.beginObject()
                                while (pembaca.hasNext()) {
                                    val kunci = pembaca.nextName()
                                    val nilai = pembaca.teksAtauKosong().trim()
                                    val angka = kunci.toIntOrNull()
                                    if (angka != null && nilai.isNotEmpty()) bagian[angka] = nilai
                                }
                                pembaca.endObject()
                            } else pembaca.skipValue()
                        }
                        pembaca.endObject()
                    }
                    "hadiths" -> {
                        if (hanyaMetadata) return Hasil(bagian, item, false, indoSaja)
                        if (pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                        pembaca.beginArray()
                        while (pembaca.hasNext()) {
                            var nomor = ""
                            var teks = ""
                            var buku = 0
                            val derajat = ArrayList<String>()
                            pembaca.beginObject()
                            while (pembaca.hasNext()) {
                                when (pembaca.nextName()) {
                                    "hadithnumber" -> nomor = rapikanNomor(pembaca.teksAtauKosong())
                                    "text" -> teks = pembaca.teksAtauKosong()
                                    "grades" -> {
                                        if (pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                                        pembaca.beginArray()
                                        while (pembaca.hasNext()) {
                                            if (pembaca.peek() != JsonToken.BEGIN_OBJECT) { pembaca.skipValue(); continue }
                                            var nama = ""
                                            var nilai = ""
                                            pembaca.beginObject()
                                            while (pembaca.hasNext()) {
                                                when (pembaca.nextName()) {
                                                    "name" -> nama = pembaca.teksAtauKosong()
                                                    "grade" -> nilai = pembaca.teksAtauKosong()
                                                    else -> pembaca.skipValue()
                                                }
                                            }
                                            pembaca.endObject()
                                            if (nilai.isNotBlank()) derajat.add(if (nama.isBlank()) nilai else nilai + " (" + nama + ")")
                                        }
                                        pembaca.endArray()
                                    }
                                    "reference" -> {
                                        if (pembaca.peek() != JsonToken.BEGIN_OBJECT) { pembaca.skipValue(); continue }
                                        pembaca.beginObject()
                                        while (pembaca.hasNext()) {
                                            if (pembaca.nextName() == "book") buku = pembaca.teksAtauKosong().toDoubleOrNull()?.toInt() ?: 0
                                            else pembaca.skipValue()
                                        }
                                        pembaca.endObject()
                                    }
                                    else -> pembaca.skipValue()
                                }
                            }
                            pembaca.endObject()
                            if (nomor.isEmpty() || !cocok(nomor, buku)) continue
                            if (dilewati < lewati) { dilewati++; continue }
                            if (item.size >= batas) { adaLagi = true; return Hasil(bagian, item, true, indoSaja) }
                            item.add(Hadis(nomor, teks.trim(), buku, derajat.joinToString("; ")))
                        }
                        pembaca.endArray()
                    }
                    else -> pembaca.skipValue()
                }
            }
        } catch (_: Exception) {
            // Berkas rusak atau terpotong: kembalikan apa yang sudah terbaca.
        } finally {
            try { pembaca.close() } catch (_: Exception) { }
        }
        return Hasil(bagian, item, adaLagi, indoSaja)
    }

    /** Ambil teks terjemahan untuk himpunan nomor tertentu dari satu berkas edisi. */
    fun terjemahan(file: File, nomor: Set<String>): Map<String, String> {
        val hasil = HashMap<String, String>()
        if (nomor.isEmpty()) return hasil
        val pembaca = JsonReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8).buffered())
        try {
            pembaca.beginObject()
            while (pembaca.hasNext()) {
                if (pembaca.nextName() != "hadiths" || pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                pembaca.beginArray()
                while (pembaca.hasNext()) {
                    var no = ""
                    var teks = ""
                    pembaca.beginObject()
                    while (pembaca.hasNext()) {
                        when (pembaca.nextName()) {
                            "hadithnumber" -> no = rapikanNomor(pembaca.teksAtauKosong())
                            "text" -> teks = pembaca.teksAtauKosong()
                            else -> pembaca.skipValue()
                        }
                    }
                    pembaca.endObject()
                    if (no in nomor && teks.isNotBlank()) {
                        hasil[no] = teks.trim()
                        if (hasil.size >= nomor.size) return hasil
                    }
                }
                pembaca.endArray()
            }
        } catch (_: Exception) {
        } finally {
            try { pembaca.close() } catch (_: Exception) { }
        }
        return hasil
    }

    /**
     * FIX246: cari nomor hadits yang isinya cocok dengan kata kunci (tidak bergantung pada daftar bab kitab).
     * Semua kata kunci harus ada (AND); bila tidak ada yang cocok, hadits yang memuat sebagian kata kunci (OR) dipakai.
     * Hasil dibatasi [batas] nomor agar memori dan layar tetap ringan.
     */
    fun cariNomorDariTeks(file: File, pencarian: BabHadits.PencarianTeks, batas: Int = 5000): List<String> {
        if (pencarian.kosong) return emptyList()
        val semua = ArrayList<String>()
        val sebagian = ArrayList<String>()
        val pembaca = JsonReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8).buffered())
        try {
            pembaca.beginObject()
            while (pembaca.hasNext()) {
                if (pembaca.nextName() != "hadiths" || pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                pembaca.beginArray()
                while (pembaca.hasNext()) {
                    var no = ""
                    var teks = ""
                    pembaca.beginObject()
                    while (pembaca.hasNext()) {
                        when (pembaca.nextName()) {
                            "hadithnumber" -> no = rapikanNomor(pembaca.teksAtauKosong())
                            "text" -> teks = pembaca.teksAtauKosong()
                            else -> pembaca.skipValue()
                        }
                    }
                    pembaca.endObject()
                    if (no.isEmpty() || teks.isBlank()) continue
                    if (pencarian.cocokSemua(teks)) { if (semua.size < batas) semua.add(no) }
                    else if (semua.isEmpty() && sebagian.size < batas && pencarian.cocokSebagian(teks)) sebagian.add(no)
                }
                pembaca.endArray()
            }
        } catch (_: Exception) {
        } finally {
            try { pembaca.close() } catch (_: Exception) { }
        }
        return if (semua.isNotEmpty()) semua else sebagian
    }

    // ---------- FIX201: konversi berkas SQL (Riyadhus Shalihin) ----------

    private class BarisSql(val nomor: String, val arab: String?, val indo: String?)

    /** Unduh berkas SQL lalu ubah menjadi berkas JSON edisi yang sama bentuknya dengan layanan lain. */
    fun unduhSql(context: Context, k: Kitab, lapor: (Long) -> Unit): Boolean {
        for (url in k.sumberSql) {
            var koneksi: HttpURLConnection? = null
            try {
                koneksi = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000; readTimeout = 30000; requestMethod = "GET"; instanceFollowRedirects = true
                }
                if (koneksi.responseCode !in 200..299) continue
                val penampung = java.io.ByteArrayOutputStream()
                var total = 0L
                koneksi.inputStream.use { masuk ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = masuk.read(buf)
                        if (n < 0) break
                        penampung.write(buf, 0, n)
                        total += n
                        lapor(total)
                    }
                }
                val baris = uraiSql(penampung.toString("UTF-8"))
                if (baris.isEmpty()) continue
                simpanKonversi(context, k, baris)
                return true
            } catch (_: Exception) {
            } finally {
                try { koneksi?.disconnect() } catch (_: Exception) { }
            }
        }
        return false
    }

    private fun simpanKonversi(context: Context, k: Kitab, baris: List<BarisSql>) {
        // Mode Arab hanya bila SEMUA baris memuat teks Arab pada baris yang sama; pasangan lintas berkas tidak ditebak.
        val modeArab = baris.all { it.arab != null }
        val primer = berkas(context, k.arab.first())
        val terjemah = berkas(context, k.indo.first())
        terjemah.delete()
        tulisJson(primer, if (modeArab) "arab" else "id-only", baris.map { Pair(it.nomor, if (modeArab) it.arab!! else (it.indo ?: it.arab ?: "")) })
        if (modeArab) {
            val bahasaIndo = baris.filter { it.indo != null }.map { Pair(it.nomor, it.indo!!) }
            if (bahasaIndo.isNotEmpty()) tulisJson(terjemah, "indonesia", bahasaIndo)
        }
    }

    private fun tulisJson(file: File, nama: String, isi: List<Pair<String, String>>) {
        val w = JsonWriter(java.io.OutputStreamWriter(FileOutputStream(file), Charsets.UTF_8).buffered())
        try {
            w.beginObject()
            w.name("metadata").beginObject().name("name").value(nama).endObject()
            w.name("hadiths").beginArray()
            for ((no, teks) in isi) {
                w.beginObject().name("hadithnumber").value(no).name("text").value(teks).endObject()
            }
            w.endArray()
            w.endObject()
        } finally {
            try { w.close() } catch (_: Exception) { }
        }
    }

    private fun fraksiArab(s: String): Double {
        var huruf = 0
        var arab = 0
        for (c in s) if (c.isLetter()) { huruf++; if (c in '\u0600'..'\u06FF') arab++ }
        return if (huruf == 0) 0.0 else arab.toDouble() / huruf
    }

    private fun bersihHtml(s: String): String =
        s.replace(Regex("<[^>]*>"), " ").replace("&nbsp;", " ").replace(Regex("[ \\t]+"), " ").trim()

    /** Urai pernyataan INSERT ... VALUES dari dump SQL tanpa mengandalkan urutan kolom yang pasti. */
    private fun uraiSql(teks: String): List<BarisSql> {
        val hasil = ArrayList<BarisSql>()
        val dipakai = HashSet<String>()
        val namaNomor = setOf("nomor", "no", "number", "hadis_no", "no_hadis", "nomor_hadis", "hadits_no", "no_hadits")
        var kolomBuat: List<String> = emptyList()
        val buat = teks.indexOf("CREATE TABLE", ignoreCase = true)
        if (buat >= 0) {
            val akhir = teks.indexOf(';', buat).let { if (it < 0) teks.length else it }
            kolomBuat = Regex("^\\s*[`\"]([^`\"]+)[`\"]", RegexOption.MULTILINE).findAll(teks.substring(buat, akhir)).map { it.groupValues[1] }.toList()
        }
        var urut = 0
        var cari = 0
        while (true) {
            val awal = teks.indexOf("INSERT INTO", cari, ignoreCase = true)
            if (awal < 0) break
            val nilaiAwal = teks.indexOf("VALUES", awal, ignoreCase = true)
            if (nilaiAwal < 0) break
            val kepala = teks.substring(awal, nilaiAwal)
            var kolom = kolomBuat
            val kurung = kepala.indexOf('(')
            if (kurung >= 0) {
                kolom = Regex("[`\"]?([A-Za-z0-9_]+)[`\"]?").findAll(kepala.substring(kurung + 1, kepala.lastIndexOf(')').let { if (it < kurung) kepala.length else it }))
                    .map { it.groupValues[1] }.toList()
            }
            var p = nilaiAwal + 6
            val n = teks.length
            while (p < n) {
                val c = teks[p]
                if (c == ';') { p++; break }
                if (c != '(') { p++; continue }
                p++
                val nilai = ArrayList<String?>()
                while (p < n) {
                    while (p < n && teks[p] == ' ') p++
                    if (p >= n) break
                    if (teks[p] == '\'') {
                        p++
                        val sb = StringBuilder()
                        while (p < n) {
                            val ch = teks[p]
                            if (ch == '\\' && p + 1 < n) {
                                val nx = teks[p + 1]
                                sb.append(when (nx) { 'n' -> '\n'; 'r' -> ' '; 't' -> ' '; '0' -> ' '; else -> nx })
                                p += 2
                            } else if (ch == '\'') {
                                if (p + 1 < n && teks[p + 1] == '\'') { sb.append('\''); p += 2 } else { p++; break }
                            } else { sb.append(ch); p++ }
                        }
                        nilai.add(sb.toString())
                    } else {
                        val mulai = p
                        while (p < n && teks[p] != ',' && teks[p] != ')') p++
                        val t = teks.substring(mulai, p).trim()
                        nilai.add(if (t.equals("NULL", true)) null else t)
                    }
                    while (p < n && teks[p] == ' ') p++
                    if (p < n && teks[p] == ',') { p++; continue }
                    if (p < n && teks[p] == ')') { p++; break }
                }
                urut++
                val panjang = nilai.mapNotNull { it }.filter { it.length > 15 }
                val arab = panjang.filter { fraksiArab(it) > 0.5 }.maxByOrNull { it.length }?.let { bersihHtml(it) }
                val indo = panjang.filter { fraksiArab(it) < 0.2 }.maxByOrNull { it.length }?.let { bersihHtml(it) }
                if (arab == null && indo == null) continue
                var nomor = urut.toString()
                val idx = kolom.indexOfFirst { it.lowercase(Locale.ROOT) in namaNomor }
                if (idx >= 0 && idx < nilai.size) {
                    val v = nilai[idx]?.trim() ?: ""
                    if (v.isNotEmpty() && v.all { it.isDigit() }) nomor = v.trimStart('0').ifEmpty { "0" }
                }
                if (!dipakai.add(nomor)) { nomor = urut.toString(); if (!dipakai.add(nomor)) continue }
                hasil.add(BarisSql(nomor, arab, indo))
            }
            cari = p
        }
        return hasil
    }
}
