package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import java.util.Calendar
import java.util.Locale

/**
 * FIX186: jadwal pengingat membaca Al-Qur'an yang dapat diatur pengguna: beberapa waktu per hari (sampai [MAKS_WAKTU]),
 * pilihan hari, alarm tepat waktu bila izin tersedia, tunda, dan tes. Disimpan pada SharedPreferences "khatam_quran":
 * "pengingat_aktif", "pengingat_waktu" (menit sejak tengah malam, dipisah koma; diturunkan dari "pengingat_jam" dan
 * "pengingat_menit" milik versi lama bila belum ada) dan "pengingat_hari" (bit 0 = Minggu ... bit 6 = Sabtu, awal semua hari).
 * Satu alarm tunggal untuk kejadian berikutnya dipasang ulang setiap kali pengingat berbunyi.
 */
object PengingatBaca {
    const val MAKS_WAKTU = 8
    const val SEMUA_HARI = 127
    const val AKSI_TUNDA_KLIK = "com.novan.bateraibicara.PENGINGAT_BACA_TUNDA"
    const val AKSI_BUNYI_ULANG = "com.novan.bateraibicara.PENGINGAT_BACA_BUNYI_ULANG"
    const val AKSI_UJI = "com.novan.bateraibicara.PENGINGAT_BACA_UJI"
    const val MENIT_TUNDA = 10
    private const val RC_UTAMA = 6901
    private const val RC_TUNDA = 6911

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE)

    fun aktif(c: Context): Boolean = prefs(c).getBoolean("pengingat_aktif", false)

    /** Daftar waktu (menit sejak tengah malam), terurut dan tanpa duplikat. */
    fun waktu(p: SharedPreferences): List<Int> {
        val mentah = p.getString("pengingat_waktu", null)
        val daftar = if (mentah == null) {
            listOf(p.getInt("pengingat_jam", 20).coerceIn(0, 23) * 60 + p.getInt("pengingat_menit", 0).coerceIn(0, 59))
        } else mentah.split(',').mapNotNull { it.trim().toIntOrNull() }.filter { it in 0..1439 }
        return daftar.distinct().sorted().take(MAKS_WAKTU)
    }

    fun simpanWaktu(p: SharedPreferences, daftar: List<Int>) {
        val bersih = daftar.filter { it in 0..1439 }.distinct().sorted().take(MAKS_WAKTU)
        p.edit().putString("pengingat_waktu", bersih.joinToString(",")).apply()
    }

    fun hari(p: SharedPreferences): Int = p.getInt("pengingat_hari", SEMUA_HARI).coerceIn(0, SEMUA_HARI)

    fun format(menit: Int): String = String.format(Locale.ROOT, "%02d:%02d", menit / 60, menit % 60)

    /** Nama hari menurut Calendar.DAY_OF_WEEK (1 = Minggu ... 7 = Sabtu). */
    fun namaHari(hariKalender: Int, english: Boolean, singkat: Boolean = false): String {
        val id = arrayOf("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
        val en = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val nama = (if (english) en else id)[(hariKalender - 1).coerceIn(0, 6)]
        return if (singkat) nama.take(3) else nama
    }

    fun ringkasHari(mask: Int, english: Boolean): String {
        if (mask == SEMUA_HARI) return if (english) "every day" else "setiap hari"
        if (mask == 0) return if (english) "no day selected" else "tidak ada hari dipilih"
        val urut = listOf(2, 3, 4, 5, 6, 7, 1)
        return urut.filter { mask and (1 shl (it - 1)) != 0 }.joinToString(", ") { namaHari(it, english, true) }
    }

    /** Waktu pengingat berikutnya (epoch ms) setelah [sekarang], atau null bila tidak ada waktu atau hari. */
    fun berikutnya(p: SharedPreferences, sekarang: Long): Long? {
        val daftar = waktu(p)
        val mask = hari(p)
        if (daftar.isEmpty() || mask == 0) return null
        for (selisih in 0..7) {
            val hariIni = Calendar.getInstance().apply { timeInMillis = sekarang; add(Calendar.DAY_OF_YEAR, selisih) }
            if (mask and (1 shl (hariIni.get(Calendar.DAY_OF_WEEK) - 1)) == 0) continue
            for (menit in daftar) {
                val t = (hariIni.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, menit / 60); set(Calendar.MINUTE, menit % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                if (t > sekarang) return t
            }
        }
        return null
    }

    private fun intentUtama(c: Context, aksi: String? = null, kode: Int = RC_UTAMA): PendingIntent {
        val i = Intent(c, KhatamReminderReceiver::class.java).apply { if (aksi != null) action = aksi }
        return PendingIntent.getBroadcast(c, kode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Pendingintent untuk tombol Tunda pada notifikasi. */
    fun intentTundaKlik(c: Context): PendingIntent = intentUtama(c, AKSI_TUNDA_KLIK, 6912)

    private fun pasang(c: Context, t: Long, pi: PendingIntent) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, t, pi)
            }
        } catch (_: SecurityException) {
            try { am.set(AlarmManager.RTC_WAKEUP, t, pi) } catch (_: Exception) { }
        }
    }

    /** Pasang ulang alarm untuk kejadian berikutnya; membatalkan alarm lama (termasuk alarm berulang versi lama). */
    fun jadwalkan(context: Context) {
        val c = context.applicationContext
        batalkanUtama(c)
        val p = prefs(c)
        if (!p.getBoolean("pengingat_aktif", false)) return
        val t = berikutnya(p, System.currentTimeMillis()) ?: return
        pasang(c, t, intentUtama(c))
    }

    private fun batalkanUtama(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = intentUtama(c)
        try { am.cancel(pi); pi.cancel() } catch (_: Exception) { }
    }

    fun batalkan(context: Context) {
        val c = context.applicationContext
        batalkanUtama(c)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pt = intentUtama(c, AKSI_BUNYI_ULANG, RC_TUNDA)
        try { am.cancel(pt); pt.cancel() } catch (_: Exception) { }
    }

    /** Bunyikan lagi satu kali setelah [menit] menit (tombol Tunda pada notifikasi). */
    fun tunda(context: Context, menit: Int = MENIT_TUNDA) {
        val c = context.applicationContext
        pasang(c, System.currentTimeMillis() + menit * 60_000L, intentUtama(c, AKSI_BUNYI_ULANG, RC_TUNDA))
    }
}
