package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Switch
import android.widget.Toast

/** Pengaturan khusus pemicu suara dengan goncangan, terpisah dari sakelar Beritahu Saya. */
class PengaturanGoncanganActivity : Halaman() {
    override val judulHalaman = R.string.judul_pengaturan_goncangan
    private val pengaturan by lazy { getSharedPreferences("pengaturan", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var tingkat: TextView
    private var sedangMenyusun = false
    private lateinit var saklarGoncangan: Switch
    private lateinit var statusUji: TextView
    private lateinit var tombolUji: android.widget.Button
    private var sedangUji = false
    private val detektorUji = DetektorGoncangan().apply { cooldownMs = 1500L; warmMs = 800L }
    private val pendengarUji = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type != Sensor.TYPE_ACCELEROMETER || event.values.size < 3) return
            detektorUji.sensitivitas = pengaturan.getInt(GoncanganSuaraService.KEY_SENSITIVITAS, 5).coerceIn(1, 10)
            detektorUji.longgar = pengaturan.getInt(GoncanganSuaraService.KEY_MODE, GoncanganSuaraService.MODE_KETAT) == GoncanganSuaraService.MODE_LONGGAR
            when (detektorUji.proses(event.values[0], event.values[1], event.values[2], event.timestamp / 1_000_000L)) {
                DetektorGoncangan.Hasil.PUNCAK -> {
                    getar(30L)
                    statusUji.text = teks("Hentakan terhitung: ", "Shakes counted: ") + detektorUji.jumlahPuncak + teks(" dari 3.", " of 3.")
                }
                DetektorGoncangan.Hasil.POLA -> {
                    getar(350L)
                    val pesan = teks(
                        "Pola tiga goncangan cepat dikenali. Perintah suara akan terbuka bila ini terjadi di luar uji.",
                        "Three-quick-shake pattern recognized. Voice commands would open if this happened outside the test."
                    )
                    statusUji.text = pesan
                    statusUji.announceForAccessibility(pesan)
                }
                else -> Unit
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }

    private fun teks(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun bangun() {
        bagian(teks("Aktivasi perintah suara dengan goncangan", "Shake-to-activate voice commands"))
        info(teks(
            "Goyangkan HP TIGA kali dengan cepat dan sengaja untuk membuka pengenalan perintah suara. Satu goncangan adalah satu hentakan cepat; lakukan tiga hentakan berturut-turut sekitar tiga kali per detik. Satu atau dua goncangan, berjalan, mengangkat atau meletakkan HP tidak membuka perintah suara. Pemicu tetap bekerja saat layar mati atau terkunci selama layanan diizinkan berjalan oleh Android.",
            "Shake the phone THREE times quickly and deliberately to open voice recognition. One shake is one quick jolt; make three jolts in a row, about three per second. One or two shakes, walking, or picking up or putting down the phone do not open voice commands. The trigger can work while the screen is off or locked while Android allows the service to run."
        ))

        val aktifAwal = pengaturan.getBoolean(GoncanganSuaraService.KEY_AKTIF, false)
        saklarGoncangan = saklar(teks("Aktifkan pemicu goncangan", "Enable shake trigger"), aktifAwal) { aktif ->
            if (sedangMenyusun) return@saklar
            if (aktif) {
                val manager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                if (manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true) == null && manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null) {
                    Toast.makeText(this, teks("Sensor akselerometer tidak tersedia pada HP ini.", "The accelerometer sensor is not available on this phone."), Toast.LENGTH_LONG).show()
                    sedangMenyusun = true
                    // Saklar dikembalikan pada keadaan nonaktif tanpa menyimpan status aktif.
                    recreate()
                    return@saklar
                }
                pengaturan.edit().putBoolean(GoncanganSuaraService.KEY_AKTIF, true).apply()
                mintaIzinLayarKunci()
                try {
                    GoncanganSuaraService.mulai(this)
                    status.text = teks("Pemicu goncangan aktif. Tunggu sekitar dua detik, lalu goyangkan HP tiga kali cepat untuk mencoba.", "Shake trigger is active. Wait about two seconds, then shake the phone three times quickly to test.")
                } catch (_: Exception) {
                    pengaturan.edit().putBoolean(GoncanganSuaraService.KEY_AKTIF, false).apply()
                    sedangMenyusun = true
                    saklarGoncangan.isChecked = false
                    sedangMenyusun = false
                    status.text = teks("Layanan tidak dapat dimulai. Periksa izin dan pembatasan baterai Android.", "The service could not start. Check Android permissions and battery restrictions.")
                }
            } else {
                pengaturan.edit().putBoolean(GoncanganSuaraService.KEY_AKTIF, false).apply()
                GoncanganSuaraService.hentikan(this)
                status.text = teks("Pemicu goncangan dinonaktifkan.", "Shake trigger is disabled.")
            }
        }

        bagian(teks("Sensitivitas goncangan", "Shake sensitivity"))
        val nilaiAwal = pengaturan.getInt(GoncanganSuaraService.KEY_SENSITIVITAS, 5).coerceIn(1, 10)
        tingkat = info("")
        val seek = SeekBar(this).apply {
            max = 9
            progress = nilaiAwal - 1
            contentDescription = teks("Sensitivitas goncangan dari 1 paling rendah sampai 10 paling tinggi", "Shake sensitivity from 1 lowest to 10 highest")
        }
        root.addView(seek, android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            dp(56)
        ))
        perbaruiLabelSensitivitas(nilaiAwal)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val nilai = progress + 1
                perbaruiLabelSensitivitas(nilai)
                if (fromUser) pengaturan.edit().putInt(GoncanganSuaraService.KEY_SENSITIVITAS, nilai).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        info(teks(
            "1 = paling rendah (perlu goncangan lebih kuat). 10 = paling tinggi (goncangan ringan lebih mudah terdeteksi). Jika sering aktif tanpa sengaja, turunkan sensitivitas.",
            "1 = lowest (requires a stronger shake). 10 = highest (lighter shakes are detected more easily). If it triggers accidentally, lower the sensitivity."
        ))

        bagian(teks("Cara mengenali goncangan", "How shakes are recognized"))
        val modeAwal = pengaturan.getInt(GoncanganSuaraService.KEY_MODE, GoncanganSuaraService.MODE_KETAT).coerceIn(0, 1)
        pilihan(
            teks("Mode pengenalan goncangan", "Shake recognition mode"),
            listOf(
                teks("Normal: goyang tiga kali cepat; ambang mengikuti getaran tangan (paling mudah dipicu)", "Normal: shake three times quickly; the threshold adapts to hand tremor (easiest to trigger)"),
                teks("Longgar: boleh sambil bergerak; perlu hentakan lebih kuat (paling aman dari goncangan tidak sengaja)", "Loose: works while moving; needs firmer jolts (safest against accidental shakes)")
            ),
            modeAwal
        ) { pengaturan.edit().putInt(GoncanganSuaraService.KEY_MODE, it).apply() }
        info(teks(
            "Mode normal memakai ambang sesuai tingkat sensitivitas dan otomatis menyesuaikan diri dengan getaran tangan atau gerakan di sekitar, jadi HP tidak perlu diam dulu. Cukup goyangkan HP tiga kali cepat dan tegas dalam sekitar satu detik. Mode longgar memerlukan hentakan 1,8 kali lebih kuat sehingga lebih aman dipakai sambil bergerak. Setelah layanan dinyalakan, tunggu sekitar dua detik sebelum menggoyang.",
            "Normal mode uses the threshold set by the sensitivity level and automatically adapts to hand tremor or surrounding movement, so the phone does not need to be still first. Just shake it three times quickly and firmly within about a second. Loose mode needs jolts 1.8 times stronger, which is safer while moving. After the service starts, wait about two seconds before shaking."
        ))
        bagian(teks("Uji goncangan", "Shake test"))
        info(teks(
            "Tekan Mulai uji, lalu goyangkan HP. Setiap hentakan yang sah terasa sebagai getar singkat dan jumlahnya ditampilkan; bila tiga hentakan cepat dikenali, HP bergetar lebih panjang. Selama uji, pola tidak membuka perintah suara. Gunakan uji ini untuk menyetel sensitivitas.",
            "Press Start test, then shake the phone. Each valid jolt gives a short vibration and the count is shown; when three quick jolts are recognized the phone vibrates longer. During the test the pattern does not open voice commands. Use this test to tune sensitivity."
        ))
        statusUji = info(teks("Uji belum dimulai.", "The test has not started."))
        tombolUji = tombol(teks("Mulai uji goncangan", "Start shake test")) { alihkanUji() }

        bagian(teks("Cara kerja dan privasi", "How it works and privacy"))
        info(teks(
            "Saat aktif, layanan sensor berjalan sebagai layanan latar depan dan menampilkan notifikasi tetap. Goncangan hanya membuka pengenalan suara; mikrofon baru digunakan oleh layanan pengenalan suara setelah layar perintah dibuka. Pada HP tanpa akselerometer wake-up, layanan perlu menjaga CPU tetap aktif sehingga baterai bisa lebih boros. Nonaktifkan sakelar ini untuk menghentikan pemantauan sensor.",
            "When enabled, the sensor runs as a foreground service with an ongoing notification. A shake only opens voice recognition; the microphone is used by the speech-recognition service after the command screen opens. Phones without a wake-up accelerometer may need the CPU held awake, which can use more battery. Turn this switch off to stop sensor monitoring."
        ))
        status = info(if (aktifAwal) teks("Status: pemicu goncangan aktif.", "Status: shake trigger is active.") else teks("Status: pemicu goncangan nonaktif.", "Status: shake trigger is off."))
        bagian(teks("Agar berfungsi saat layar terkunci", "To work while the screen is locked"))
        info(teks(
            "Izinkan mikrofon agar pengenalan suara berjalan langsung di atas layar kunci (tanpa layar pengenal aplikasi lain yang ditahan saat terkunci), izinkan notifikasi agar notifikasi layar penuh \"Perintah suara siap\" dapat membuka layar perintah, lalu izinkan notifikasi layar penuh bila Android 14 ke atas memintanya. Saat terkunci, membaca waktu, tanggal, hari libur, dan jadwal sholat langsung berjalan. Memutar Al-Qur'an (surah, ayat, juz) langsung berjalan di latar belakang tanpa membuka kunci; katakan berhenti, jeda, atau lanjut untuk mengendalikannya. Perintah yang membuka aplikasi, menelepon, memilih qari, atau membacakan pesan pribadi meminta Anda membuka kunci layar lebih dulu.",
            "Allow the microphone so voice recognition runs directly above the lock screen (other apps' recognition screens are held back while locked), allow notifications so the full-screen \"Voice command is ready\" notification can open the command screen, then allow full-screen notifications if Android 14 or newer asks for it. While locked, the time, date, holidays, and prayer times are read right away. Qur'an playback (surah, verse, juz) runs in the background without unlocking; say stop, pause, or resume to control it. Commands that open apps, place calls, choose a reciter, or read private messages ask you to unlock the screen first."
        ))
        tombol(teks("Izinkan mikrofon dan notifikasi", "Allow microphone and notifications")) { mintaIzinLayarKunci(tampilkanPesan = true) }
        tombol(teks("Izinkan notifikasi layar penuh", "Allow full-screen notifications")) { bukaIzinLayarPenuh() }
        tombol(teks("Buka pengaturan optimasi baterai Android", "Open Android battery optimization settings")) {
            try {
                val intent = android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, teks("Pengaturan baterai tidak dapat dibuka.", "Battery settings could not be opened."), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun alihkanUji() {
        if (sedangUji) { hentikanUji(); return }
        val manager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensor == null) {
            statusUji.text = teks("Sensor akselerometer tidak tersedia pada HP ini.", "The accelerometer sensor is not available on this phone.")
            return
        }
        detektorUji.reset()
        GoncanganSuaraService.sedangUji = true
        sedangUji = manager.registerListener(pendengarUji, sensor, SensorManager.SENSOR_DELAY_GAME)
        if (!sedangUji) {
            GoncanganSuaraService.sedangUji = false
            statusUji.text = teks("Uji tidak dapat dimulai.", "The test could not start.")
            return
        }
        tombolUji.text = teks("Hentikan uji goncangan", "Stop shake test")
        statusUji.text = teks("Uji berjalan. Goyangkan HP tiga kali cepat dan tegas.", "Test running. Shake the phone three times quickly and firmly.")
        statusUji.announceForAccessibility(statusUji.text)
    }

    private fun hentikanUji() {
        if (!sedangUji && !GoncanganSuaraService.sedangUji) return
        try { (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(pendengarUji) } catch (_: Exception) { }
        sedangUji = false
        GoncanganSuaraService.sedangUji = false
        if (::tombolUji.isInitialized) tombolUji.text = teks("Mulai uji goncangan", "Start shake test")
        if (::statusUji.isInitialized) statusUji.text = teks("Uji dihentikan.", "The test was stopped.")
    }

    override fun onPause() {
        hentikanUji()
        super.onPause()
    }

    override fun onDestroy() {
        hentikanUji()
        super.onDestroy()
    }

    /** FIX95: izin yang perlu diberikan sebelum layar terkunci (tidak dapat diminta saat terkunci). */
    private fun mintaIzinLayarKunci(tampilkanPesan: Boolean = false) {
        val perlu = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) perlu.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) perlu.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perlu.isNotEmpty()) {
            requestPermissions(perlu.toTypedArray(), 9411)
        } else if (tampilkanPesan) {
            Toast.makeText(this, teks("Izin mikrofon dan notifikasi sudah diberikan.", "Microphone and notification permissions are already granted."), Toast.LENGTH_LONG).show()
        }
    }

    private fun bukaIzinLayarPenuh() {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + packageName)))
            } else {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            }
        } catch (_: Exception) {
            Toast.makeText(this, teks("Pengaturan notifikasi tidak dapat dibuka.", "Notification settings could not be opened."), Toast.LENGTH_LONG).show()
        }
    }

    private fun perbaruiLabelSensitivitas(nilai: Int) {
        tingkat.text = teks("Tingkat sensitivitas: ", "Sensitivity level: ") + nilai + "/10" + when {
            nilai <= 3 -> teks(" (rendah)", " (low)")
            nilai <= 7 -> teks(" (sedang)", " (medium)")
            else -> teks(" (tinggi)", " (high)")
        }
    }
}
