package com.novan.bateraibicara

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.app.AlertDialog
import java.text.NumberFormat
import java.util.Locale
import org.json.JSONArray

/**
 * Kalkulator zakat mandiri. Semua masukan memakai label yang terhubung ke EditText
 * agar terbaca pembaca layar. Rumus dan asumsi ditampilkan bersama hasil.
 */
class KalkulatorZakatActivity : Halaman() {

    override val judulHalaman = R.string.judul_kalkulator_zakat

    private enum class Jenis {
        EMAS_PERAK, TABUNGAN, PERDAGANGAN, PERTANIAN, FITRAH, PENGHASILAN, PETERNAKAN, WARIS
    }

    private var jenisAktif: Jenis? = null
    private lateinit var menuJenis: LinearLayout
    private lateinit var formulir: LinearLayout
    private lateinit var hasil: TextView
    private val isian = LinkedHashMap<String, EditText>()
    private var saklarHaul: android.widget.Switch? = null
    private var pilihanLogam: Spinner? = null
    private var pilihanIrigasi: Spinner? = null
    private var pilihanFitrah: Spinner? = null
    private var pilihanPeriode: Spinner? = null
    private var pilihanHewan: Spinner? = null
    private var pilihanGembala: Spinner? = null
    private var pilihanPewaris: Spinner? = null
    private var hasilTerakhir: String = ""

    override fun bangun() {
        info(tr(
            "Kalkulator ini memuat perhitungan zakat dan pembagian waris. Pilih salah satu, isi angka tanpa pemisah ribuan, lalu tekan tombol hitung. Hasil disertai penjelasan asumsi perhitungan.",
            "This calculator covers zakat and inheritance division. Choose one, enter numbers without thousands separators, then tap the calculate button. The result includes the calculation assumptions."
        ))
        menuJenis = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        formulir = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        root.addView(menuJenis)
        root.addView(formulir)

        tambahMenu(Jenis.EMAS_PERAK, tr("Zakat emas dan perak", "Gold and silver zakat"),
            tr("Hitung berdasarkan berat, harga per gram, nisab, dan haul.", "Calculate using weight, price per gram, nisab, and haul."))
        tambahMenu(Jenis.TABUNGAN, tr("Zakat tabungan dan uang", "Savings and cash zakat"),
            tr("Hitung harta bersih yang memenuhi nisab dan haul.", "Calculate net eligible wealth subject to nisab and haul."))
        tambahMenu(Jenis.PERDAGANGAN, tr("Zakat perdagangan", "Business and trade zakat"),
            tr("Hitung aset usaha bersih yang memenuhi nisab dan haul.", "Calculate net business assets subject to nisab and haul."))
        tambahMenu(Jenis.PERTANIAN, tr("Zakat pertanian", "Agricultural zakat"),
            tr("Hitung hasil panen berdasarkan nisab dan metode pengairan.", "Calculate harvest based on the nisab and irrigation method."))
        tambahMenu(Jenis.FITRAH, tr("Zakat fitrah", "Zakat al-Fitr"),
            tr("Hitung kebutuhan beras atau nilai uang untuk seluruh anggota keluarga.", "Calculate rice quantity or cash value for the household."))
        tambahMenu(Jenis.PENGHASILAN, tr("Zakat penghasilan atau profesi", "Income or professional zakat"),
            tr("Hitung dengan metode nisab bulanan atau tahunan.", "Calculate using a monthly or annual nisab method."))
        tambahMenu(Jenis.PETERNAKAN, tr("Zakat peternakan", "Livestock zakat"),
            tr("Hitung zakat kambing atau domba, sapi atau kerbau, dan unta berdasarkan jumlah ternak.", "Calculate zakat for goats or sheep, cattle or buffalo, and camels based on herd size."))
        tambahMenu(Jenis.WARIS, tr("Hitung waris atau faraid", "Inheritance (faraid) calculator"),
            tr("Hitung bagian setiap ahli waris dari harta peninggalan setelah utang, biaya jenazah, dan wasiat.", "Calculate each heir's share of the estate after debts, funeral costs, and bequests."))

        info(tr(
"Catatan: kalkulator ini alat bantu. Perbedaan ketentuan fikih dapat terjadi. Ikuti pedoman lembaga zakat, Pengadilan Agama, atau ulama tepercaya di wilayah Anda.",
            "Note: this calculator is a guide. Jurisprudential rules may differ. Follow the guidance of a trusted zakat institution, religious court, or scholar in your area."
        ))
        tombolAkses(menuJenis, tr("Riwayat perhitungan zakat dan waris", "Zakat and inheritance calculation history")) { tampilkanRiwayat() }
    }

    private fun tambahMenu(jenis: Jenis, judul: String, keterangan: String) {
        val b = tombolAkses(menuJenis, judul) { bukaForm(jenis) }
        b.contentDescription = judul + ". " + keterangan
        val tv = TextView(this).apply {
            text = keterangan
            textSize = 14f
            setTextColor(warnaPetunjuk())
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        menuJenis.addView(tv)
    }

    private fun tombolAkses(parent: LinearLayout, label: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 16f
        b.minimumHeight = dp(52)
        b.setTextColor(android.graphics.Color.WHITE)
        b.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(warnaAksen())
            cornerRadius = dp(14).toFloat()
        }
        b.contentDescription = label
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        b.setOnClickListener { aksi() }
        parent.addView(b, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(5); bottomMargin = dp(5) })
        return b
    }

    private fun bukaForm(jenis: Jenis) {
        jenisAktif = jenis
        menuJenis.visibility = View.GONE
        formulir.visibility = View.VISIBLE
        formulir.removeAllViews()
        isian.clear()
        saklarHaul = null
        pilihanLogam = null
        pilihanIrigasi = null
        pilihanFitrah = null
        pilihanPeriode = null
        pilihanHewan = null
        pilihanGembala = null
        pilihanPewaris = null
        hasilTerakhir = ""

        tombolAkses(formulir, tr("Ganti jenis zakat", "Choose another zakat type")) {
            formulir.visibility = View.GONE
            menuJenis.visibility = View.VISIBLE
            jenisAktif = null
        }
        val judul = when (jenis) {
            Jenis.EMAS_PERAK -> tr("Zakat emas dan perak", "Gold and silver zakat")
            Jenis.TABUNGAN -> tr("Zakat tabungan dan uang", "Savings and cash zakat")
            Jenis.PERDAGANGAN -> tr("Zakat perdagangan", "Business and trade zakat")
            Jenis.PERTANIAN -> tr("Zakat pertanian", "Agricultural zakat")
            Jenis.FITRAH -> tr("Zakat fitrah", "Zakat al-Fitr")
            Jenis.PENGHASILAN -> tr("Zakat penghasilan atau profesi", "Income or professional zakat")
            Jenis.PETERNAKAN -> tr("Zakat peternakan", "Livestock zakat")
            Jenis.WARIS -> tr("Hitung waris atau faraid", "Inheritance (faraid) calculator")
        }
        tambahJudul(formulir, judul)

        when (jenis) {
            Jenis.EMAS_PERAK -> {
                pilihanLogam = tambahPilihan(formulir, tr("Jenis logam", "Metal type"),
                    listOf(tr("Emas", "Gold"), tr("Perak", "Silver")))
                tambahAngka("berat", tr("Berat logam dalam gram", "Metal weight in grams"), "0")
                tambahAngka("harga", tr("Harga per gram dalam rupiah", "Price per gram in rupiah"), "0")
                tambahHaul()
                tambahCatatan(tr(
                    "Acuan nisab: emas 85 gram atau perak 595 gram. Tarif 2,5% jika telah dimiliki satu haul. Pastikan harga per gram diperbarui sendiri.",
                    "Reference nisab: 85 grams of gold or 595 grams of silver. Rate is 2.5% after one lunar year of ownership. Update the per-gram price yourself."
                ))
            }
            Jenis.TABUNGAN -> {
                tambahAngka("harta", tr("Total tabungan, uang tunai, dan harta sejenis yang memenuhi syarat (rupiah)", "Total eligible savings, cash, and similar assets (rupiah)"), "0")
                tambahAngka("utang", tr("Utang jatuh tempo yang boleh diperhitungkan (rupiah)", "Due debts that may be deducted (rupiah)"), "0")
                tambahAngka("harga", tr("Harga emas per gram (rupiah)", "Gold price per gram (rupiah)"), "0")
                tambahHaul()
                tambahCatatan(tr(
                    "Nisab acuan setara 85 gram emas. Harta bersih dihitung setelah pengurangan utang jatuh tempo yang diperbolehkan. Ketentuan pengurangan utang dapat berbeda.",
                    "Reference nisab equals 85 grams of gold. Net wealth is calculated after eligible due debts. Debt deductions may differ by guidance."
                ))
            }
            Jenis.PERDAGANGAN -> {
                tambahAngka("aset", tr("Nilai persediaan barang, kas, dan piutang tertagih (rupiah)", "Value of inventory, cash, and collectible receivables (rupiah)"), "0")
                tambahAngka("utang", tr("Kewajiban usaha jangka pendek yang diperhitungkan (rupiah)", "Eligible short-term business liabilities (rupiah)"), "0")
                tambahAngka("harga", tr("Harga emas per gram (rupiah)", "Gold price per gram (rupiah)"), "0")
                tambahHaul()
                tambahCatatan(tr(
                    "Nisab acuan setara 85 gram emas dan tarif 2,5%. Masukkan nilai pada akhir haul; perlakuan aset dan kewajiban mengikuti pedoman zakat perdagangan yang Anda gunakan.",
                    "Reference nisab equals 85 grams of gold and the rate is 2.5%. Enter values at the end of the haul; asset and liability treatment should follow your chosen trade-zakat guidance."
                ))
            }
            Jenis.PERTANIAN -> {
                tambahAngka("panen", tr("Hasil panen setara gabah dalam kilogram", "Harvest in kilograms, expressed as unhusked-rice equivalent"), "0")
                pilihanIrigasi = tambahPilihan(formulir, tr("Sumber pengairan", "Irrigation source"),
                    listOf(tr("Air hujan atau alami (10%)", "Rainwater or natural (10%)"),
                        tr("Irigasi berbiaya (5%)", "Costly irrigation (5%)"),
                        tr("Campuran (7,5%)", "Mixed (7.5%)")))
                tambahCatatan(tr(
                    "Acuan yang digunakan: nisab 653 kg gabah. Masukkan hasil panen dalam satuan setara gabah. Tarif mengikuti jenis pengairan.",
                    "Reference used: nisab of 653 kg of unhusked rice. Enter harvest in unhusked-rice equivalent. The rate depends on irrigation."
                ))
            }
            Jenis.FITRAH -> {
                tambahAngka("orang", tr("Jumlah jiwa yang dibayarkan zakat fitrahnya", "Number of people covered"), "1", bilanganBulat = true)
                pilihanFitrah = tambahPilihan(formulir, tr("Pembayaran dengan", "Payment as"),
                    listOf(tr("Beras", "Rice"), tr("Uang", "Cash")))
                tambahAngka("beras", tr("Beras per orang dalam kilogram (acuan 2,5 kg)", "Rice per person in kilograms (2.5 kg reference)"), "2.5")
                tambahAngka("harga", tr("Harga beras per kilogram (rupiah), untuk pembayaran uang", "Rice price per kilogram (rupiah), for cash payment"), "0")
                tambahCatatan(tr(
                    "Acuan beras 2,5 kg per jiwa. Nilai uang mengikuti harga beras dan ketentuan lembaga zakat setempat; periksa ketetapan daerah Anda.",
                    "Reference is 2.5 kg of rice per person. Cash value follows rice prices and local zakat authority guidance; check your area's current ruling."
                ))
            }
            Jenis.PENGHASILAN -> {
                pilihanPeriode = tambahPilihan(formulir, tr("Periode perhitungan", "Calculation period"),
                    listOf(tr("Bulanan", "Monthly"), tr("Tahunan", "Annual")))
                tambahAngka("penghasilan", tr("Penghasilan kotor pada periode yang dipilih (rupiah)", "Gross income for the selected period (rupiah)"), "0")
                tambahAngka("harga", tr("Harga emas per gram (rupiah)", "Gold price per gram (rupiah)"), "0")
                tambahCatatan(tr(
                    "Nisab acuan setara 85 gram emas per tahun. Untuk metode bulanan, nisab tahunan dibagi 12. Zakat penghasilan memiliki perbedaan pandangan; gunakan metode yang sesuai dengan pedoman lembaga atau ulama yang Anda ikuti.",
                    "Reference nisab equals 85 grams of gold per year. For the monthly method, annual nisab is divided by 12. Opinions differ on income zakat; follow the method of your trusted zakat authority or scholar."
                ))
            }
            Jenis.PETERNAKAN -> {
                pilihanHewan = tambahPilihan(formulir, tr("Jenis ternak", "Livestock type"),
                    listOf(tr("Kambing atau domba", "Goats or sheep"), tr("Sapi atau kerbau", "Cattle or buffalo"), tr("Unta", "Camels")))
                tambahAngka("jumlahHewan", tr("Jumlah hewan ternak (ekor, bilangan bulat)", "Number of livestock (head, whole number)"), "0", bilanganBulat = true)
                pilihanGembala = tambahPilihan(formulir, tr("Pola pemeliharaan", "Herd management"),
                    listOf(tr("Digembalakan dan mencari pakan sendiri sebagian besar tahun", "Grazes freely for most of the year"), tr("Mayoritas diberi pakan yang dibeli atau dipelihara intensif", "Mostly stall-fed or supplied with purchased feed")))
                tambahHaul()
                tambahCatatan(tr(
                    "Acuan umum ternak zakat: kambing/domba mulai 40 ekor; sapi/kerbau mulai 30 ekor; unta mulai 5 ekor. Umumnya disyaratkan mencapai haul dan digembalakan bebas sebagian besar tahun. Ternak yang diperdagangkan dapat mengikuti aturan zakat perdagangan. Rincian jenis, umur, dan kondisi ternak harus diperiksa sesuai pedoman lembaga zakat/ulama setempat. Untuk unta lebih dari 120 ekor, kalkulator meminta konsultasi karena kombinasi umur dan jumlah memiliki tabel khusus.",
                    "General livestock references: goats/sheep start at 40; cattle/buffalo at 30; camels at 5. A haul and free grazing for most of the year are generally required. Livestock held for trade may follow trade-zakat rules. Animal type, age, and condition must be checked against local zakat guidance. For more than 120 camels, consult an authority because the age-and-count schedule is specialized."
                ))
            }
            Jenis.WARIS -> bentukFormWaris()
        }

        tombolAkses(formulir, if (jenis == Jenis.WARIS) tr("Hitung waris", "Calculate inheritance") else tr("Hitung zakat", "Calculate zakat")) { hitung() }
        hasil = TextView(this).apply {
            text = tr("Hasil perhitungan akan ditampilkan di sini.", "The calculation result will appear here.")
            textSize = 17f
            setTextColor(warnaTeks())
            setPadding(dp(10), dp(14), dp(10), dp(14))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            if (android.os.Build.VERSION.SDK_INT >= 19) accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        formulir.addView(hasil)
        tombolAkses(formulir, tr("Bacakan ulang hasil", "Read result again")) {
            if (hasilTerakhir.isNotBlank()) hasil.announceForAccessibility(hasilTerakhir)
            else hasil.announceForAccessibility(tr("Belum ada hasil. Tekan tombol hitung terlebih dahulu.", "There is no result yet. Tap the calculate button first."))
        }
        tombolAkses(formulir, tr("Simpan hasil", "Save result")) { simpanHasil() }
        tombolAkses(formulir, tr("Lihat riwayat", "View history")) { tampilkanRiwayat() }
    }

    private fun tambahJudul(parent: LinearLayout, teks: String) {
        parent.addView(TextView(this).apply {
            text = teks
            textSize = 21f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(warnaAksen())
            setPadding(0, dp(12), 0, dp(8))
        })
    }

    private fun tambahCatatan(teks: String) {
        formulir.addView(TextView(this).apply {
            text = teks
            textSize = 14f
            setTextColor(warnaPetunjuk())
            setPadding(dp(4), dp(8), dp(4), dp(12))
        })
    }

    private fun tambahAngka(kunci: String, label: String, awal: String, bilanganBulat: Boolean = false) {
        val tv = TextView(this).apply {
            id = View.generateViewId()
            text = label
            textSize = 16f
            setTextColor(warnaTeks())
            setPadding(0, dp(10), 0, dp(2))
        }
        val et = EditText(this).apply {
            id = View.generateViewId()
            inputType = if (bilanganBulat) InputType.TYPE_CLASS_NUMBER
                else InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = label
            contentDescription = label
            setTextColor(warnaTeksIsian())
            setHintTextColor(warnaPetunjuk())
            setText(awal)
            tv.labelFor = id
        }
        isian[kunci] = et
        formulir.addView(tv)
        formulir.addView(et)
    }

    private fun tambahHaul() {
        val s = android.widget.Switch(this).apply {
            text = tr("Harta telah dimiliki satu haul (satu tahun Hijriah)", "Wealth has been held for one haul (one Hijri year)")
            isChecked = false
            textSize = 16f
            setTextColor(warnaTeks())
            contentDescription = text
            setPadding(0, dp(12), 0, dp(12))
        }
        saklarHaul = s
        formulir.addView(s)
    }

    private fun tambahPilihan(parent: LinearLayout, label: String, opsi: List<String>): Spinner {
        val tv = TextView(this).apply {
            id = View.generateViewId()
            text = label
            textSize = 16f
            setTextColor(warnaTeks())
            setPadding(0, dp(12), 0, dp(4))
        }
        val sp = Spinner(this)
        sp.id = View.generateViewId()
        tv.labelFor = sp.id
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opsi)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        parent.addView(tv)
        parent.addView(sp)
        return sp
    }

    private fun angka(kunci: String): Double {
        val raw = isian[kunci]?.text?.toString()?.trim().orEmpty()
        if (raw.isBlank()) return 0.0
        // Izinkan koma sebagai tanda desimal; pemisah ribuan tidak dianjurkan di petunjuk input.
        return raw.replace(',', '.').toDoubleOrNull() ?: Double.NaN
    }

    private fun rupiah(nilai: Double): String {
        // Tanpa simbol mata uang (Rp atau tanda dolar) agar pembaca layar membaca jelas: angka lalu kata "rupiah".
        val locale = if (BahasaAplikasi.tampilan(this) == 1) Locale.US else Locale("id", "ID")
        val angka = NumberFormat.getNumberInstance(locale).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }.format(nilai.coerceAtLeast(0.0))
        return angka + " rupiah"
    }

    private fun hitung() {
        val jenis = jenisAktif ?: return
        val nol = tr("Masukkan angka yang valid dan tidak negatif pada semua kolom.", "Enter valid, non-negative numbers in all fields.")
        val nilai = isian.mapValues { angka(it.key) }
        if (nilai.values.any { it.isNaN() || it.isInfinite() || it < 0.0 }) {
            hasil.text = nol
            hasil.announceForAccessibility(nol)
            return
        }
        if (jenis == Jenis.WARIS) { hitungWaris(nilai); return }
        var wajib = 0.0
        var ringkasan = ""
        var dasar = ""
        var status = ""
        when (jenis) {
            Jenis.WARIS -> {}
            Jenis.EMAS_PERAK -> {
                val perak = (pilihanLogam?.selectedItemPosition ?: 0) == 1
                val berat = nilai["berat"] ?: 0.0
                val harga = nilai["harga"] ?: 0.0
                val nisab = if (perak) 595.0 else 85.0
                val haul = saklarHaul?.isChecked == true
                if (berat >= nisab && harga <= 0.0) {
                    hasil.text = tr("Masukkan harga logam per gram yang valid.", "Enter a valid metal price per gram.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                val tercapai = berat >= nisab && haul
                wajib = if (tercapai) berat * harga * 0.025 else 0.0
                dasar = tr("Nisab", "Nisab") + ": $nisab " + tr("gram", "grams") +
                    "; " + tr("tarif 2,5%", "2.5% rate")
                status = when {
                    berat < nisab -> tr("Belum mencapai nisab.", "Nisab has not been reached.")
                    !haul -> tr("Belum memenuhi haul satu tahun Hijriah.", "The one Hijri-year haul has not been completed.")
                    else -> tr("Nisab dan haul terpenuhi.", "Nisab and haul are met.")
                }
                ringkasan = tr("Berat", "Weight") + ": $berat g; " + tr("nilai", "value") + ": ${rupiah(berat * harga)}"
            }
            Jenis.TABUNGAN -> {
                val bersih = ((nilai["harta"] ?: 0.0) - (nilai["utang"] ?: 0.0)).coerceAtLeast(0.0)
                val nisab = 85.0 * (nilai["harga"] ?: 0.0)
                val haul = saklarHaul?.isChecked == true
                val tercapai = nisab > 0 && bersih >= nisab && haul
                wajib = if (tercapai) bersih * 0.025 else 0.0
                dasar = tr("Harta bersih", "Net wealth") + ": ${rupiah(bersih)}; " + tr("nisab 85 gram emas", "85-gram gold nisab") + ": ${rupiah(nisab)}"
                status = when {
                    nisab <= 0 -> tr("Masukkan harga emas per gram.", "Enter the gold price per gram.")
                    bersih < nisab -> tr("Harta bersih belum mencapai nisab.", "Net wealth is below nisab.")
                    !haul -> tr("Belum memenuhi haul satu tahun Hijriah.", "The one Hijri-year haul has not been completed.")
                    else -> tr("Nisab dan haul terpenuhi.", "Nisab and haul are met.")
                }
                ringkasan = tr("Harta bersih setelah pengurangan", "Net wealth after deduction") + ": ${rupiah(bersih)}"
            }
            Jenis.PERDAGANGAN -> {
                val bersih = ((nilai["aset"] ?: 0.0) - (nilai["utang"] ?: 0.0)).coerceAtLeast(0.0)
                val nisab = 85.0 * (nilai["harga"] ?: 0.0)
                val haul = saklarHaul?.isChecked == true
                val tercapai = nisab > 0 && bersih >= nisab && haul
                wajib = if (tercapai) bersih * 0.025 else 0.0
                dasar = tr("Aset bersih usaha", "Net business assets") + ": ${rupiah(bersih)}; " + tr("nisab", "nisab") + ": ${rupiah(nisab)}; 2,5%"
                status = when {
                    nisab <= 0 -> tr("Masukkan harga emas per gram.", "Enter the gold price per gram.")
                    bersih < nisab -> tr("Aset bersih belum mencapai nisab.", "Net assets are below nisab.")
                    !haul -> tr("Belum memenuhi haul satu tahun Hijriah.", "The one Hijri-year haul has not been completed.")
                    else -> tr("Nisab dan haul terpenuhi.", "Nisab and haul are met.")
                }
                ringkasan = tr("Nilai aset bersih", "Net asset value") + ": ${rupiah(bersih)}"
            }
            Jenis.PERTANIAN -> {
                val panen = nilai["panen"] ?: 0.0
                val tarif = when (pilihanIrigasi?.selectedItemPosition ?: 0) { 1 -> 0.05; 2 -> 0.075; else -> 0.10 }
                val nisab = 653.0
                wajib = if (panen >= nisab) panen * tarif else 0.0
                dasar = tr("Nisab acuan 653 kg gabah", "Reference nisab 653 kg unhusked rice") + "; " +
                    tr("tarif", "rate") + ": " + (tarif * 100).toString().replace('.', ',') + "%"
                status = if (panen >= nisab) tr("Nisab panen terpenuhi.", "Harvest nisab is met.")
                    else tr("Hasil panen belum mencapai nisab.", "Harvest is below nisab.")
                ringkasan = tr("Hasil panen", "Harvest") + ": $panen kg"
            }
            Jenis.FITRAH -> {
                val orang = nilai["orang"] ?: 0.0
                val kgPerOrang = nilai["beras"] ?: 0.0
                val harga = nilai["harga"] ?: 0.0
                if (orang % 1.0 != 0.0) {
                    hasil.text = tr("Jumlah jiwa harus berupa bilangan bulat.", "The number of people must be a whole number.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                val totalKg = orang * kgPerOrang
                val uang = totalKg * harga
                val denganUang = pilihanFitrah?.selectedItemPosition == 1
                if (denganUang && orang > 0.0 && harga <= 0.0) {
                    hasil.text = tr("Masukkan harga beras per kilogram yang valid untuk menghitung pembayaran uang.", "Enter a valid rice price per kilogram to calculate cash payment.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                wajib = if (denganUang) uang else totalKg
                dasar = if (denganUang) tr("Nilai uang berdasarkan berat beras dan harga per kilogram", "Cash value based on rice weight and price per kilogram")
                    else tr("Jumlah beras yang perlu disiapkan", "Total rice to provide")
                status = tr("Periksa ketetapan zakat fitrah dari lembaga zakat setempat.", "Check the local zakat authority's current zakat al-Fitr guidance.")
                ringkasan = tr("Jumlah jiwa", "People") + ": ${orang.toInt()}; " + tr("total beras", "total rice") + ": $totalKg kg"
            }
            Jenis.PENGHASILAN -> {
                val income = nilai["penghasilan"] ?: 0.0
                val harga = nilai["harga"] ?: 0.0
                val tahunan = pilihanPeriode?.selectedItemPosition == 1
                val nisabTahunan = 85.0 * harga
                val nisabPeriode = if (tahunan) nisabTahunan else nisabTahunan / 12.0
                val tercapai = nisabPeriode > 0 && income >= nisabPeriode
                wajib = if (tercapai) income * 0.025 else 0.0
                dasar = tr("Nisab acuan", "Reference nisab") + ": ${rupiah(nisabPeriode)}; 2,5%"
                status = when {
                    nisabPeriode <= 0 -> tr("Masukkan harga emas per gram.", "Enter the gold price per gram.")
                    tercapai -> tr("Penghasilan mencapai nisab pada metode yang dipilih.", "Income reaches nisab under the selected method.")
                    else -> tr("Penghasilan belum mencapai nisab pada metode yang dipilih.", "Income is below nisab under the selected method.")
                }
                ringkasan = tr("Penghasilan periode ini", "Income for this period") + ": ${rupiah(income)}"
            }
            Jenis.PETERNAKAN -> {
                val jumlah = nilai["jumlahHewan"] ?: 0.0
                if (jumlah % 1.0 != 0.0) {
                    hasil.text = tr("Jumlah ternak harus berupa bilangan bulat.", "Livestock count must be a whole number.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                if (jumlah > 1000000.0) {
                    hasil.text = tr("Jumlah ternak terlalu besar untuk kalkulator ini. Silakan konsultasikan perhitungan kawanan besar kepada amil zakat.", "The herd count is too large for this calculator. Consult a zakat authority for a large-herd calculation.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                val n = jumlah.toInt()
                val jenisHewan = pilihanHewan?.selectedItemPosition ?: 0
                val digembala = pilihanGembala?.selectedItemPosition == 0
                val haul = saklarHaul?.isChecked == true
                val labelHewan = when (jenisHewan) {
                    1 -> tr("sapi atau kerbau", "cattle or buffalo")
                    2 -> tr("unta", "camels")
                    else -> tr("kambing atau domba", "goats or sheep")
                }
                val rincian: String
                val nisab: Int
                when (jenisHewan) {
                    1 -> {
                        nisab = 30
                        // Fiqh schedule: one tabi' for each 30, one musinnah for each 40.
                        // Find an exact decomposition to avoid undercounting a due category.
                        var best: Pair<Int, Int>? = null
                        var sisaTerbaik = Int.MAX_VALUE
                        for (musinnah in 0..(n / 40)) {
                            val sisa = n - musinnah * 40
                            val tabi = sisa / 30
                            val sisaAkhir = sisa - tabi * 30
                            if (sisaAkhir < 30 && sisaAkhir < sisaTerbaik) {
                                sisaTerbaik = sisaAkhir
                                best = tabi to musinnah
                            }
                        }
                        rincian = when {
                            n < 30 -> tr("Belum mencapai nisab sapi/kerbau 30 ekor.", "Below the cattle/buffalo nisab of 30.")
                            best != null -> {
                                val (tabi, musinnah) = best!!
                                buildString {
                                    if (tabi > 0) append("$tabi ").append(tr("ekor tabi' (sapi umur 1 tahun)", "tabi' (one-year-old bovine)"))
                                    if (tabi > 0 && musinnah > 0) append(tr(" dan ", " and "))
                                    if (musinnah > 0) append("$musinnah ").append(tr("ekor musinnah (sapi umur 2 tahun)", "musinnah (two-year-old bovine)"))
                                }
                            }
                            else -> tr("Jumlah ini berada di antara kelipatan nisab 30 dan 40. Periksa tabel perhitungan ternak kepada lembaga zakat setempat.", "This count falls between 30- and 40-head increments. Check the livestock schedule with a local zakat authority.")
                        }
                    }
                    2 -> {
                        nisab = 5
                        rincian = when (n) {
                            in 0..4 -> tr("Belum mencapai nisab unta 5 ekor.", "Below the camel nisab of 5.")
                            in 5..9 -> tr("1 ekor kambing/domba.", "1 sheep or goat.")
                            in 10..14 -> tr("2 ekor kambing/domba.", "2 sheep or goats.")
                            in 15..19 -> tr("3 ekor kambing/domba.", "3 sheep or goats.")
                            in 20..24 -> tr("4 ekor kambing/domba.", "4 sheep or goats.")
                            in 25..35 -> tr("1 ekor bint makhad (unta betina umur 1 tahun).", "1 bint makhad (one-year-old female camel).")
                            in 36..45 -> tr("1 ekor bint labun (unta betina umur 2 tahun).", "1 bint labun (two-year-old female camel).")
                            in 46..60 -> tr("1 ekor hiqqah (unta betina umur 3 tahun).", "1 hiqqah (three-year-old female camel).")
                            in 61..75 -> tr("1 ekor jadha'ah (unta betina umur 4 tahun).", "1 jadha'ah (four-year-old female camel).")
                            in 76..90 -> tr("2 ekor bint labun.", "2 bint labun camels.")
                            in 91..120 -> tr("2 ekor hiqqah.", "2 hiqqah camels.")
                            else -> tr("Untuk unta lebih dari 120 ekor, jumlah dan umur ternak harus dihitung dengan kombinasi khusus kelipatan 40 dan 50. Silakan konsultasikan kepada amil zakat.", "For more than 120 camels, the number and age categories require a special combination of groups of 40 and 50. Consult a zakat authority.")
                        }
                    }
                    else -> {
                        nisab = 40
                        rincian = when (n) {
                            in 0..39 -> tr("Belum mencapai nisab kambing/domba 40 ekor.", "Below the goat/sheep nisab of 40.")
                            in 40..120 -> tr("1 ekor kambing atau domba.", "1 goat or sheep.")
                            in 121..200 -> tr("2 ekor kambing atau domba.", "2 goats or sheep.")
                            in 201..399 -> tr("3 ekor kambing atau domba.", "3 goats or sheep.")
                            else -> "${n / 100} " + tr("ekor kambing atau domba (satu ekor setiap 100 ekor)", "goats or sheep (one for every 100 head)")
                        }
                    }
                }
                val memenuhiJumlah = n >= nisab
                status = when {
                    !memenuhiJumlah -> tr("Jumlah ternak belum mencapai nisab.", "The herd has not reached nisab.")
                    !haul -> tr("Nisab jumlah tercapai, tetapi haul satu tahun Hijriah belum ditandai terpenuhi.", "The count reaches nisab, but the one Hijri-year haul is not marked as completed.")
                    !digembala -> tr("Nisab dan haul mungkin terpenuhi, tetapi mayoritas pakan dibeli atau ternak dipelihara intensif. Perhitungan zakat ternak gembalaan ini tidak diterapkan; periksa ketentuan zakat perdagangan atau konsultasikan kepada amil.", "Nisab and haul may be met, but the animals are mostly stall-fed or intensively raised. This grazing-livestock calculation is not applied; check trade-zakat rules or consult a zakat authority.")
                    jenisHewan == 2 && n > 120 -> tr("Perlu konsultasi amil untuk unta di atas 120 ekor.", "Consult a zakat authority for more than 120 camels.")
                    else -> tr("Nisab, haul, dan syarat penggembalaan ditandai terpenuhi. Verifikasi umur serta kondisi hewan sebelum penyerahan.", "Nisab, haul, and grazing conditions are marked as met. Verify animal age and condition before payment.")
                }
                wajib = 0.0 // Livestock zakat is due in specified animals, not a fixed cash percentage.
                dasar = tr("Nisab acuan", "Reference nisab") + ": $nisab " + tr("ekor", "head") + "; " + tr("ketentuan umum ternak", "general livestock schedule")
                ringkasan = tr("Jumlah", "Count") + " $labelHewan: $n " + tr("ekor", "head") + "; " + tr("bentuk zakat", "zakat due") + ": $rincian"
                hasilTerakhir = buildString {
                    append(tr("Hasil kalkulasi zakat", "Zakat calculation result")); append("\n")
                    append(tr("Jenis", "Type")); append(": "); append(tr("Peternakan", "Livestock")); append("\n")
                    append(ringkasan); append("\n"); append(dasar); append("\n"); append(status)
                    append("\n\n"); append(tr("Zakat ternak umumnya ditunaikan dalam bentuk hewan sesuai umur dan ketentuan fikih, bukan otomatis dalam bentuk uang.", "Livestock zakat is generally paid in eligible animals according to age and jurisprudential rules, not automatically as cash."))
                    append("\n\n"); append(tr("Estimasi ini bukan fatwa. Ketentuan dapat berbeda menurut mazhab dan lembaga zakat. Ternak untuk perdagangan dapat dihitung sebagai zakat perdagangan.", "This estimate is not a religious ruling. Rules may differ by school and zakat authority. Livestock held for trade may be assessed as trade zakat."))
                }
                hasil.text = hasilTerakhir
                hasil.announceForAccessibility(hasilTerakhir)
                return
            }
        }

        val jumlah = if (jenis == Jenis.FITRAH && pilihanFitrah?.selectedItemPosition != 1)
            String.format(Locale.US, "%.2f kg", wajib) else rupiah(wajib)
        hasilTerakhir = buildString {
            append(tr("Hasil kalkulasi zakat", "Zakat calculation result"))
            append("\n")
            append(tr("Jenis", "Type")); append(": "); append(when (jenis) {
                Jenis.EMAS_PERAK -> tr("Emas dan perak", "Gold and silver")
                Jenis.TABUNGAN -> tr("Tabungan dan uang", "Savings and cash")
                Jenis.PERDAGANGAN -> tr("Perdagangan", "Trade")
                Jenis.PERTANIAN -> tr("Pertanian", "Agriculture")
                Jenis.FITRAH -> tr("Fitrah", "Al-Fitr")
                Jenis.PENGHASILAN -> tr("Penghasilan", "Income")
                Jenis.PETERNAKAN -> tr("Peternakan", "Livestock")
                Jenis.WARIS -> tr("Waris", "Inheritance")
            })
            append("\n"); append(ringkasan)
            append("\n"); append(dasar)
            append("\n"); append(status)
            append("\n"); append(tr("Jumlah zakat yang dihitung", "Calculated zakat amount")); append(": "); append(jumlah)
            if (jenis == Jenis.FITRAH && pilihanFitrah?.selectedItemPosition == 1) {
                append("\n"); append(tr("Pembayaran uang", "Cash payment")); append(": "); append(rupiah(wajib))
            }
            append("\n\n"); append(tr(
                "Perhitungan ini merupakan estimasi berdasarkan data dan acuan yang dimasukkan, bukan fatwa. Pastikan nisab, harga, haul, dan ketentuan setempat.",
                "This is an estimate based on the entered data and selected references, not a religious ruling. Verify nisab, prices, haul, and local rules."
            ))
        }
        hasil.text = hasilTerakhir
        hasil.announceForAccessibility(hasilTerakhir)
    }


    // ---------------------------------------------------------------- Waris (faraid)

    private fun bentukFormWaris() {
        tambahCatatan(tr(
            "Isi jumlah ahli waris yang masih hidup. Isi 0 bila tidak ada. Masukkan jumlah harta dalam rupiah tanpa pemisah ribuan. Pembagian mengikuti faraid menurut pendapat jumhur dan mazhab Syafii.",
            "Enter the number of surviving heirs. Enter 0 if none. Enter amounts in rupiah without thousands separators. The division follows faraid according to the majority view and the Shafii school."
        ))
        pilihanPewaris = tambahPilihan(formulir, tr("Jenis kelamin pewaris (orang yang meninggal)", "Sex of the deceased"),
            listOf(tr("Laki-laki", "Male"), tr("Perempuan", "Female")))
        tambahAngka("totalHarta", tr("Total harta peninggalan (rupiah)", "Total estate (rupiah)"), "0")
        tambahAngka("hartaBersama", tr("Dari total itu, berapa harta bersama suami istri atau gono-gini (rupiah). Separuhnya menjadi hak pasangan yang masih hidup", "Of that total, the joint marital property (rupiah). Half belongs to the surviving spouse"), "0")
        tambahAngka("utang", tr("Utang pewaris yang harus dilunasi (rupiah)", "Debts of the deceased to be settled (rupiah)"), "0")
        tambahAngka("biayaJenazah", tr("Biaya pengurusan jenazah (rupiah)", "Funeral costs (rupiah)"), "0")
        tambahAngka("wasiat", tr("Wasiat kepada bukan ahli waris (rupiah). Paling banyak sepertiga", "Bequest to non-heirs (rupiah). At most one third"), "0")
        tambahAngka("pasangan", tr("Jumlah pasangan yang masih hidup. Istri 0 sampai 4 bila pewaris laki-laki; suami 0 atau 1 bila pewaris perempuan", "Number of surviving spouses. 0 to 4 wives if the deceased is male; 0 or 1 husband if female"), "0", bilanganBulat = true)
        tambahAngka("anakL", tr("Jumlah anak laki-laki", "Number of sons"), "0", bilanganBulat = true)
        tambahAngka("anakP", tr("Jumlah anak perempuan", "Number of daughters"), "0", bilanganBulat = true)
        tambahAngka("cucuL", tr("Jumlah cucu laki-laki dari anak laki-laki", "Number of grandsons through a son"), "0", bilanganBulat = true)
        tambahAngka("cucuP", tr("Jumlah cucu perempuan dari anak laki-laki", "Number of granddaughters through a son"), "0", bilanganBulat = true)
        tambahAngka("ayah", tr("Ayah masih hidup: isi 1, bila tidak isi 0", "Father alive: enter 1, otherwise 0"), "0", bilanganBulat = true)
        tambahAngka("ibu", tr("Ibu masih hidup: isi 1, bila tidak isi 0", "Mother alive: enter 1, otherwise 0"), "0", bilanganBulat = true)
        tambahAngka("kakek", tr("Kakek dari pihak ayah masih hidup: isi 1, bila tidak isi 0", "Paternal grandfather alive: enter 1, otherwise 0"), "0", bilanganBulat = true)
        tambahAngka("nenekIbu", tr("Nenek dari pihak ibu masih hidup: isi 1, bila tidak isi 0", "Maternal grandmother alive: enter 1, otherwise 0"), "0", bilanganBulat = true)
        tambahAngka("nenekAyah", tr("Nenek dari pihak ayah masih hidup: isi 1, bila tidak isi 0", "Paternal grandmother alive: enter 1, otherwise 0"), "0", bilanganBulat = true)
        tambahAngka("skL", tr("Jumlah saudara laki-laki kandung", "Number of full brothers"), "0", bilanganBulat = true)
        tambahAngka("skP", tr("Jumlah saudara perempuan kandung", "Number of full sisters"), "0", bilanganBulat = true)
        tambahAngka("saL", tr("Jumlah saudara laki-laki seayah", "Number of paternal half-brothers"), "0", bilanganBulat = true)
        tambahAngka("saP", tr("Jumlah saudara perempuan seayah", "Number of paternal half-sisters"), "0", bilanganBulat = true)
        tambahAngka("sbL", tr("Jumlah saudara laki-laki seibu", "Number of maternal half-brothers"), "0", bilanganBulat = true)
        tambahAngka("sbP", tr("Jumlah saudara perempuan seibu", "Number of maternal half-sisters"), "0", bilanganBulat = true)
        tambahCatatan(tr(
            "Kalkulator ini belum memuat ahli waris yang lebih jauh seperti paman, keponakan, atau sepupu. Bila tidak ada ahli waris yang diisi atau masih tersisa harta, konsultasikan ke Pengadilan Agama atau ulama.",
            "This calculator does not include more distant heirs such as uncles, nephews, or cousins. If no heirs are entered or part of the estate remains, consult a religious court or a scholar."
        ))
    }

    private fun pesanWaris(teks: String) {
        hasil.text = teks
        hasil.announceForAccessibility(teks)
    }

    private fun namaAhli(a: HitungWaris.Ahli, laki: Boolean): String = when (a) {
        HitungWaris.Ahli.SUAMI -> tr("Suami", "Husband")
        HitungWaris.Ahli.ISTRI -> tr("Istri", "Wife")
        HitungWaris.Ahli.ANAK_L -> tr("Anak laki-laki", "Son")
        HitungWaris.Ahli.ANAK_P -> tr("Anak perempuan", "Daughter")
        HitungWaris.Ahli.CUCU_L -> tr("Cucu laki-laki dari anak laki-laki", "Grandson through a son")
        HitungWaris.Ahli.CUCU_P -> tr("Cucu perempuan dari anak laki-laki", "Granddaughter through a son")
        HitungWaris.Ahli.AYAH -> tr("Ayah", "Father")
        HitungWaris.Ahli.IBU -> tr("Ibu", "Mother")
        HitungWaris.Ahli.KAKEK -> tr("Kakek dari pihak ayah", "Paternal grandfather")
        HitungWaris.Ahli.NENEK_IBU -> tr("Nenek dari pihak ibu", "Maternal grandmother")
        HitungWaris.Ahli.NENEK_AYAH -> tr("Nenek dari pihak ayah", "Paternal grandmother")
        HitungWaris.Ahli.SK_L -> tr("Saudara laki-laki kandung", "Full brother")
        HitungWaris.Ahli.SK_P -> tr("Saudara perempuan kandung", "Full sister")
        HitungWaris.Ahli.SA_L -> tr("Saudara laki-laki seayah", "Paternal half-brother")
        HitungWaris.Ahli.SA_P -> tr("Saudara perempuan seayah", "Paternal half-sister")
        HitungWaris.Ahli.SB_L -> tr("Saudara laki-laki seibu", "Maternal half-brother")
        HitungWaris.Ahli.SB_P -> tr("Saudara perempuan seibu", "Maternal half-sister")
    }

    /** Pecahan diucapkan sebagai "1 per 8" agar pembaca layar tidak membacanya sebagai tanggal atau garis miring. */
    private fun ucapPecahan(p: Pecahan): String {
        if (p.d == 1L) return p.n.toString()
        return p.n.toString() + tr(" per ", " over ") + p.d.toString()
    }

    private fun namaDasar(d: HitungWaris.Dasar): String = when (d) {
        HitungWaris.Dasar.FARDH -> tr("bagian tetap", "fixed share")
        HitungWaris.Dasar.ASHABAH -> tr("sisa harta (ashabah)", "residue (asabah)")
        HitungWaris.Dasar.ASHABAH_BERSAMA -> tr("sisa harta bersama saudara atau keturunan perempuan (ashabah)", "residue shared with siblings or female descendants (asabah)")
        HitungWaris.Dasar.FARDH_DAN_ASHABAH -> tr("bagian tetap ditambah sisa harta", "fixed share plus residue")
        HitungWaris.Dasar.RADD -> tr("bagian tetap dan pengembalian sisa (radd)", "fixed share plus returned surplus (radd)")
        HitungWaris.Dasar.MUQASAMAH -> tr("pembagian bersama (muqasamah)", "joint division (muqasamah)")
    }

    private fun namaCatatan(c: HitungWaris.Catatan): String = when (c) {
        HitungWaris.Catatan.AUL -> tr("Terjadi aul: jumlah bagian tetap melebihi seluruh harta, sehingga setiap bagian dikurangi secara sebanding.", "Aul occurred: the fixed shares exceed the whole estate, so each share is reduced proportionally.")
        HitungWaris.Catatan.RADD -> tr("Terjadi radd: harta masih bersisa dan tidak ada ashabah, sehingga sisa dikembalikan kepada ahli waris bagian tetap selain suami atau istri.", "Radd occurred: surplus remained with no residuary heir, so it was returned to the fixed-share heirs other than the spouse.")
        HitungWaris.Catatan.RADD_PASANGAN -> tr("Hanya pasangan yang menjadi ahli waris, sehingga sisa harta dikembalikan kepadanya menurut pendapat yang dipakai di Indonesia. Konfirmasikan kepada Pengadilan Agama atau ulama.", "Only the spouse is an heir, so the surplus is returned to the spouse following the view used in Indonesia. Confirm with a religious court or a scholar.")
        HitungWaris.Catatan.UMARIYATAIN -> tr("Kasus Umariyatan: ibu menerima sepertiga dari sisa setelah bagian pasangan.", "Umariyatayn case: the mother receives one third of what remains after the spouse's share.")
        HitungWaris.Catatan.AKDARIYAH -> tr("Kasus Akdariyah: kakek dan saudari berbagi dengan perbandingan 2 banding 1 setelah aul. Kasus ini khusus, mohon dikonfirmasi kepada ulama.", "Akdariyyah case: the grandfather and sister share 2 to 1 after aul. This is a special case; please confirm with a scholar.")
        HitungWaris.Catatan.KAKEK_SAUDARA -> tr("Kakek bersama saudara dihitung menurut pendapat Zaid bin Tsabit, yaitu bagian terbaik antara seperenam harta, sepertiga sisa, atau muqasamah. Ada perbedaan pendapat antar mazhab.", "The grandfather with siblings is calculated by the view of Zayd ibn Thabit: the best of one sixth of the estate, one third of the remainder, or muqasamah. Schools differ on this.")
        HitungWaris.Catatan.TANPA_PENERIMA_SISA -> tr("Sebagian harta tidak terbagi kepada ahli waris yang diisi. Sisanya menjadi hak kerabat lain atau diserahkan menurut ketentuan setempat.", "Part of the estate is not assigned to the heirs entered. The rest belongs to other relatives or is handled under local rules.")
        HitungWaris.Catatan.SISA_KERABAT_LAIN -> tr("Masih ada sisa untuk kerabat lain.", "A remainder exists for other relatives.")
    }

    private fun hitungWaris(nilai: Map<String, Double>) {
        val kunci = listOf("pasangan", "anakL", "anakP", "cucuL", "cucuP", "ayah", "ibu", "kakek", "nenekIbu", "nenekAyah",
            "skL", "skP", "saL", "saP", "sbL", "sbP")
        val j = HashMap<String, Int>()
        for (k in kunci) {
            val v = nilai[k] ?: 0.0
            if (v % 1.0 != 0.0 || v > 99.0) {
                pesanWaris(tr("Jumlah ahli waris harus berupa bilangan bulat 0 sampai 99.", "The number of heirs must be a whole number from 0 to 99."))
                return
            }
            j[k] = v.toInt()
        }
        val pewarisLaki = (pilihanPewaris?.selectedItemPosition ?: 0) == 0
        val pasangan = j["pasangan"] ?: 0
        if ((pewarisLaki && pasangan > 4) || (!pewarisLaki && pasangan > 1)) {
            pesanWaris(if (pewarisLaki) tr("Jumlah istri paling banyak 4.", "The number of wives is at most 4.")
                else tr("Jumlah suami paling banyak 1.", "The number of husbands is at most 1."))
            return
        }
        for (k in listOf("ayah", "ibu", "kakek", "nenekIbu", "nenekAyah")) {
            if ((j[k] ?: 0) > 1) {
                pesanWaris(tr("Ayah, ibu, kakek, dan nenek diisi 0 atau 1.", "Father, mother, grandfather, and grandmothers must be 0 or 1."))
                return
            }
        }
        val m = HitungWaris.Masukan(
            suami = if (!pewarisLaki) pasangan else 0, istri = if (pewarisLaki) pasangan else 0,
            anakL = j["anakL"] ?: 0, anakP = j["anakP"] ?: 0, cucuL = j["cucuL"] ?: 0, cucuP = j["cucuP"] ?: 0,
            ayah = j["ayah"] ?: 0, ibu = j["ibu"] ?: 0, kakek = j["kakek"] ?: 0,
            nenekIbu = j["nenekIbu"] ?: 0, nenekAyah = j["nenekAyah"] ?: 0,
            skL = j["skL"] ?: 0, skP = j["skP"] ?: 0, saL = j["saL"] ?: 0, saP = j["saP"] ?: 0,
            sbL = j["sbL"] ?: 0, sbP = j["sbP"] ?: 0
        )
        if (!m.adaAhli()) {
            pesanWaris(tr("Belum ada ahli waris yang diisi. Isi jumlah ahli waris yang masih hidup.", "No heirs entered yet. Enter the number of surviving heirs."))
            return
        }

        val total = nilai["totalHarta"] ?: 0.0
        val bersama = minOf(nilai["hartaBersama"] ?: 0.0, total)
        val utang = nilai["utang"] ?: 0.0
        val biaya = nilai["biayaJenazah"] ?: 0.0
        val wasiat = nilai["wasiat"] ?: 0.0
        val hakPasangan = if (pasangan > 0) bersama / 2.0 else 0.0
        val setelahKewajiban = total - hakPasangan - biaya - utang
        val adaNominal = total > 0.0
        if (adaNominal && setelahKewajiban <= 0.0) {
            pesanWaris(tr("Harta tidak cukup untuk dibagikan setelah hak pasangan, biaya jenazah, dan utang dipenuhi. Tidak ada harta yang diwariskan.",
                "The estate is not enough to distribute after the spouse's right, funeral costs, and debts. Nothing is left to inherit."))
            return
        }
        val batasWasiat = if (adaNominal) setelahKewajiban / 3.0 else 0.0
        val wasiatBerlaku = minOf(wasiat, batasWasiat)
        val warisan = if (adaNominal) setelahKewajiban - wasiatBerlaku else 0.0

        val h = HitungWaris.hitung(m)
        hasilTerakhir = buildString {
            append(tr("Hasil perhitungan waris (faraid)", "Inheritance (faraid) calculation result")); append("\n")
            append(tr("Pewaris", "Deceased")); append(": "); append(if (pewarisLaki) tr("laki-laki", "male") else tr("perempuan", "female")); append("\n")
            if (adaNominal) {
                append(tr("Total harta peninggalan", "Total estate")); append(": "); append(rupiah(total)); append("\n")
                if (hakPasangan > 0.0) { append(tr("Hak pasangan dari harta bersama", "Spouse's right from joint property")); append(": "); append(rupiah(hakPasangan)); append("\n") }
                if (biaya > 0.0) { append(tr("Biaya pengurusan jenazah", "Funeral costs")); append(": "); append(rupiah(biaya)); append("\n") }
                if (utang > 0.0) { append(tr("Utang", "Debts")); append(": "); append(rupiah(utang)); append("\n") }
                if (wasiatBerlaku > 0.0) { append(tr("Wasiat yang berlaku", "Bequest applied")); append(": "); append(rupiah(wasiatBerlaku)); append("\n") }
                if (wasiat > batasWasiat) {
                    append(tr("Wasiat melebihi sepertiga sehingga dibatasi sepertiga harta bersih. Kelebihannya perlu persetujuan seluruh ahli waris.",
                        "The bequest exceeds one third, so it is capped at one third of the net estate. The excess needs the consent of all heirs.")); append("\n")
                }
                append(tr("Harta yang dibagikan kepada ahli waris", "Estate distributed to the heirs")); append(": "); append(rupiah(warisan)); append("\n")
            } else {
                append(tr("Jumlah harta belum diisi, sehingga hanya bagian pecahan yang ditampilkan.", "No estate amount entered, so only fractional shares are shown.")); append("\n")
            }
            append("\n"); append(tr("Bagian setiap ahli waris", "Each heir's share")); append(":\n")
            var nomor = 1
            for (b in h.bagian) {
                append(nomor); append(". "); append(namaAhli(b.ahli, pewarisLaki))
                append(" "); append(b.jumlah); append(tr(" orang", if (b.jumlah > 1) " persons" else " person")); append(": ")
                append(tr("bagian", "share")); append(" "); append(ucapPecahan(b.total)); append(tr(" dari harta", " of the estate"))
                append(", "); append(namaDasar(b.dasar))
                if (adaNominal) {
                    val nominal = b.total.nilai() * warisan
                    append(tr(", sebesar ", ", amounting to ")); append(rupiah(nominal))
                    if (b.jumlah > 1) { append(tr(", masing-masing ", ", each ")); append(rupiah(nominal / b.jumlah)) }
                }
                append("\n"); nomor++
            }
            if (h.terhalang.isNotEmpty()) {
                append("\n"); append(tr("Terhalang dan tidak menerima bagian", "Blocked and receiving nothing")); append(": ")
                append(h.terhalang.joinToString("; ") { namaAhli(it, pewarisLaki) }); append("\n")
            }
            if (adaNominal && wasiatBerlaku > 0.0) {
                append("\n"); append(tr("Wasiat dibayarkan lebih dahulu kepada penerima wasiat sebesar ", "The bequest is paid first to the beneficiary: ")); append(rupiah(wasiatBerlaku)); append("\n")
            }
            if (h.catatan.isNotEmpty()) {
                append("\n"); append(tr("Catatan", "Notes")); append(":\n")
                for (c in h.catatan) { append(namaCatatan(c)); append("\n") }
            }
            if (h.sisaTakTerbagi.positif() && adaNominal) {
                append(tr("Sisa harta yang belum terbagi", "Estate not yet assigned")); append(": "); append(rupiah(h.sisaTakTerbagi.nilai() * warisan)); append("\n")
            }
            append("\n"); append(tr(
                "Hasil ini estimasi menurut faraid mazhab Syafii dan pendapat jumhur, bukan putusan hukum. Di Indonesia, Kompilasi Hukum Islam mengenal ahli waris pengganti dan wasiat wajibah yang tidak dihitung di sini. Keluarga juga dapat berdamai membagi harta dengan kesepakatan bersama. Untuk penetapan resmi, hubungi Pengadilan Agama atau ulama.",
                "This is an estimate under Shafii faraid and the majority view, not a legal ruling. In Indonesia the Compilation of Islamic Law recognizes substitute heirs and obligatory bequests that are not calculated here. Families may also agree to divide the estate by mutual consent. For an official determination, contact a religious court or a scholar."
            ))
        }
        hasil.text = hasilTerakhir
        hasil.announceForAccessibility(hasilTerakhir)
    }

    private fun simpanHasil() {
        if (hasilTerakhir.isBlank()) {
            hasil.announceForAccessibility(tr("Hitung terlebih dahulu.", "Calculate first."))
            return
        }
        val prefsRiwayat = getSharedPreferences("riwayat_kalkulator_zakat", MODE_PRIVATE)
        val lama = try { JSONArray(prefsRiwayat.getString("data", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val baru = JSONArray().put(hasilTerakhir)
        for (i in 0 until minOf(lama.length(), 19)) baru.put(lama.optString(i))
        prefsRiwayat.edit().putString("data", baru.toString()).apply()
        hasil.announceForAccessibility(tr("Hasil perhitungan berhasil disimpan.", "Calculation result saved."))
    }

    private fun tampilkanRiwayat() {
        val arr = try {
            JSONArray(getSharedPreferences("riwayat_kalkulator_zakat", MODE_PRIVATE).getString("data", "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            AlertDialog.Builder(this)
                .setTitle(tr("Riwayat zakat", "Zakat history"))
                .setMessage(tr("Belum ada hasil perhitungan yang disimpan.", "No saved calculations yet."))
                .setPositiveButton(tr("Mengerti", "OK"), null).show()
            return
        }
        val daftar = Array(arr.length()) { i -> arr.optString(i) }
        AlertDialog.Builder(this)
            .setTitle(tr("Riwayat perhitungan zakat", "Zakat calculation history"))
            .setItems(daftar.map { it as CharSequence }.toTypedArray()) { _, which ->
                AlertDialog.Builder(this).setTitle(tr("Detail hasil", "Result details"))
                    .setMessage(daftar[which])
                    .setPositiveButton(tr("Tutup", "Close"), null).show()
            }
            .setNegativeButton(tr("Tutup", "Close"), null)
            .setNeutralButton(tr("Hapus riwayat", "Clear history")) { _, _ ->
                getSharedPreferences("riwayat_kalkulator_zakat", MODE_PRIVATE).edit().remove("data").apply()
            }.show()
    }
}
