package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/** Pengaturan kategori Baterai: tampilan baterai, kapan berbicara, dan suara. */
class BateraiActivity : Halaman() {

    override val judulHalaman = R.string.kategori_baterai

    private lateinit var teksBaterai: TextView
    private lateinit var bar: ProgressBar
    private var persen = 0

    private val penerima = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            perbarui(intent)
        }
    }

    override fun bangun() {
        when (kodeKelompok()) {
            "bicara" -> grupBicara()
            "kalimat" -> grupKalimat()
            "suara" -> grupSuara()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        // ----- Tampilan baterai -----
        teksBaterai = info("")
        teksBaterai.textSize = 18f
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)))

        saklar(getString(R.string.sw_baterai_on), prefs.bateraiOn) { prefs.bateraiOn = it; muatUlang() }
        
        tombolKelompok(getString(R.string.judul_bat_kapan), "bicara")
        tombolKelompok(getString(R.string.judul_bat_kalimat), "kalimat")
        tombolKelompok(getString(R.string.judul_bat_suara), "suara")
    
        tombolResetPengaturan("baterai") {
                    val kunci = setOf(
                        "baterai_on", "step", "bat_cara", "bat_interval", "level_mode",
                        "low", "lemah", "kritis", "batas_kritis", "penuh", "charger",
                        "usb", "engine", "rate", "pitch", "stream", "volume_persen", "efek_pengumuman", "efek_ruang",
                        "penuh_ulang", "penuh_ulang_jumlah", "penuh_ulang_jeda", "batas_penuh",
                        "kal_level", "kal_lemah", "kal_kritis", "kal_penuh", "kal_penuh_100",
                        "kal_charger_on", "kal_charger_off", "kal_usb_on", "kal_usb_off"
                    )
                    hapusKunciPengaturan("pengaturan") { it in kunci }
                    muatUlang()
                }
}

    private fun grupBicara() {
        judulGrup(getString(R.string.judul_bat_kapan))
        // ----- Kapan berbicara -----
        bagian(getString(R.string.bagian_ucapan))
        pilihan(getString(R.string.cara_baterai), larik(R.array.bat_cara), prefs.batCara) { prefs.batCara = it; muatUlang() }
        pilihan(getString(R.string.bat_interval_label), larik(R.array.bat_interval), prefs.batIntervalIdx) { prefs.batIntervalIdx = it; muatUlang() }
        pilihan(getString(R.string.setiap), larik(R.array.langkah), prefs.stepIdx) { prefs.stepIdx = it; muatUlang() }
        pilihan(getString(R.string.persen_saat), larik(R.array.mode_level), prefs.levelMode) { prefs.levelMode = it; muatUlang() }
        saklar(getString(R.string.sw_lemah), prefs.lemahOn) { prefs.lemahOn = it; muatUlang() }
        pilihan(getString(R.string.batas_lemah), larik(R.array.batas_lemah), prefs.lowIdx) { prefs.lowIdx = it; muatUlang() }
        saklar(getString(R.string.sw_kritis), prefs.kritisOn) { prefs.kritisOn = it; muatUlang() }
        val pilihanBatasKritis = intArrayOf(1, 2, 3, 5, 7, 10, 15, 20)
        pilihan(getString(R.string.batas_kritis), larik(R.array.batas_kritis), pilihanBatasKritis.indexOf(prefs.batasKritis).coerceAtLeast(0)) {
            prefs.batasKritis = pilihanBatasKritis[it]
            muatUlang()
        }
        saklar(getString(R.string.sw_penuh), prefs.penuhOn) { prefs.penuhOn = it; muatUlang() }
        pilihan(getString(R.string.batas_penuh), larik(R.array.batas_penuh), (prefs.batasPenuh - 80) / 5) {
            prefs.batasPenuh = 80 + it * 5
            muatUlang()
        }
        saklar(getString(R.string.sw_penuh_ulang), prefs.penuhUlangOn) { prefs.penuhUlangOn = it; muatUlang() }
        info(getString(R.string.info_penuh_ulang))
        pilihan(getString(R.string.penuh_ulang_jumlah), larik(R.array.penuh_ulang_jumlah), when (prefs.penuhUlangJumlah) { 1 -> 0; 3 -> 1; 5 -> 2; 10 -> 3; else -> 4 }) {
            prefs.penuhUlangJumlah = intArrayOf(1, 3, 5, 10, 20)[it]
        }
        pilihan(getString(R.string.penuh_ulang_jeda), larik(R.array.penuh_ulang_jeda), when (prefs.penuhUlangJeda) { 10 -> 0; 30 -> 1; 60 -> 2; 120 -> 3; else -> 4 }) {
            prefs.penuhUlangJeda = intArrayOf(10, 30, 60, 120, 300)[it]
        }
        saklar(getString(R.string.sw_charger), prefs.chargerOn) { prefs.chargerOn = it; muatUlang() }
        saklar(getString(R.string.sw_usb), prefs.usbOn) { prefs.usbOn = it; muatUlang() }

    }

    private fun grupKalimat() {
        judulGrup(getString(R.string.judul_bat_kalimat))
        bagian(getString(R.string.bagian_kalimat_baterai))
        info(getString(R.string.info_kalimat_baterai))
        val fLevel = isian(getString(R.string.kal_level_label), prefs.kalLevel, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalLevel = it }
        tombol(getString(R.string.sisipkan_persen, getString(R.string.kal_level_label))) { sisipkan(fLevel, "{persen}") }
        tombol(getString(R.string.tes_kal_level)) {
            tesSuara("bat", prefs.kalLevel.replace("{persen}", persen.toString()))
        }

        val fLemah = isian(getString(R.string.kal_lemah_label), prefs.kalLemah, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalLemah = it }
        tombol(getString(R.string.sisipkan_persen, getString(R.string.kal_lemah_label))) { sisipkan(fLemah, "{persen}") }
        tombol(getString(R.string.tes_kal_lemah)) {
            tesSuara("bat", prefs.kalLemah.replace("{persen}", prefs.lowThreshold.toString()))
        }

        val fKritis = isian(getString(R.string.kal_kritis_label), prefs.kalKritis, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalKritis = it }
        tombol(getString(R.string.sisipkan_persen, getString(R.string.kal_kritis_label))) { sisipkan(fKritis, "{persen}") }
        tombol(getString(R.string.tes_kal_kritis)) {
            tesSuara("bat", prefs.kalKritis.replace("{persen}", prefs.batasKritis.toString()))
        }

        val fPenuh = isian(getString(R.string.kal_penuh_label), prefs.kalPenuh, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalPenuh = it }
        tombol(getString(R.string.sisipkan_persen, getString(R.string.kal_penuh_label))) { sisipkan(fPenuh, "{persen}") }
        tombol(getString(R.string.tes_kal_penuh)) {
            val contohPenuh = if (prefs.batasPenuh >= 100) 95 else prefs.batasPenuh
            tesSuara("bat", prefs.kalPenuh.replace("{persen}", contohPenuh.toString()))
        }

        val fPenuh100 = isian(getString(R.string.kal_penuh_100_label), prefs.kalPenuh100, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalPenuh100 = it }
        tombol(getString(R.string.sisipkan_persen, getString(R.string.kal_penuh_100_label))) { sisipkan(fPenuh100, "{persen}") }
        tombol(getString(R.string.tes_kal_penuh_100)) {
            tesSuara("bat", prefs.kalPenuh100.replace("{persen}", "100"))
        }

        isian(getString(R.string.kal_charger_on_label), prefs.kalChargerOn, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalChargerOn = it }
        tombol(getString(R.string.tes_kal_charger_on)) { tesSuara("bat", prefs.kalChargerOn) }
        isian(getString(R.string.kal_charger_off_label), prefs.kalChargerOff, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalChargerOff = it }
        tombol(getString(R.string.tes_kal_charger_off)) { tesSuara("bat", prefs.kalChargerOff) }

        isian(getString(R.string.kal_usb_on_label), prefs.kalUsbOn, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalUsbOn = it }
        tombol(getString(R.string.tes_kal_usb_on)) { tesSuara("bat", prefs.kalUsbOn) }
        isian(getString(R.string.kal_usb_off_label), prefs.kalUsbOff, android.text.InputType.TYPE_CLASS_TEXT) { prefs.kalUsbOff = it }
        tombol(getString(R.string.tes_kal_usb_off)) { tesSuara("bat", prefs.kalUsbOff) }

        // Pulihkan semua kalimat kustom ke nilai bawaan tanpa mengubah pengaturan lainnya.
        tombol(getString(R.string.tombol_reset_kalimat)) {
            android.app.AlertDialog.Builder(this)
                .setMessage(R.string.konfirmasi_reset_kalimat)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    prefs.kalLevel = ""
                    prefs.kalLemah = ""
                    prefs.kalKritis = ""
                    prefs.kalPenuh = ""
                    prefs.kalPenuh100 = ""
                    prefs.kalChargerOn = ""
                    prefs.kalChargerOff = ""
                    prefs.kalUsbOn = ""
                    prefs.kalUsbOff = ""
                    toast(R.string.kalimat_dikembalikan)
                    recreate()
                }
                .show()
        }

    }

    private fun grupSuara() {
        judulGrup(getString(R.string.judul_bat_suara))
        // ----- Suara -----
        blokSuara("bat") { prefs.kalLevel.replace("{persen}", persen.toString()) }
    }

    override fun onResume() {
        super.onResume()
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(penerima, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(penerima, f)
        }
        if (sticky != null) perbarui(sticky)
    }

    override fun onPause() {
        try { unregisterReceiver(penerima) } catch (e: Exception) { }
        super.onPause()
    }

    private fun sisipkan(field: android.widget.EditText, token: String) {
        val posisi = field.selectionStart.coerceAtLeast(0).coerceAtMost(field.text.length)
        field.text.insert(posisi, token)
        field.requestFocus()
    }

    private fun perbarui(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        persen = if (level < 0) 0 else level * 100 / skala
        val mengisi = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val suhu = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        if (!::teksBaterai.isInitialized) return // tampilan baterai hanya ada di halaman daftar utama
        teksBaterai.text = getString(R.string.tampilan_baterai, persen, status, suhu, volt)
        teksBaterai.contentDescription = getString(R.string.aksesibilitas_status_baterai, persen, status, suhu, volt)
        bar.progress = persen
    }
}
