package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors

/**
 * FIX198: Kitab Hadits Shahih (Bukhari, Muslim, Arbain Nawawi, Riyadhus Shalihin).
 * Beranda daftar kitab -> halaman kitab (unduh, cari nomor, daftar bagian) -> halaman baca (Arab + terjemahan Indonesia).
 * Semua teks mengikuti bahasa tampilan aktif; teks hadits sendiri berasal dari data unduhan.
 */
class HaditsActivity : Halaman() {
    override val judulHalaman = R.string.judul_hadits

    private val latar = Executors.newSingleThreadExecutor()

    private companion object {
        @Volatile var cacheCariKunci: String? = null
        @Volatile var cacheCariNomor: Set<String>? = null
    }
    private var sudahJeda = false
    private var statusUnduh: TextView? = null

    private val ukuranHalaman = 5
    private val simpanSuara by lazy { getSharedPreferences("kitab_hadits_suara", MODE_PRIVATE) }

    private fun hidup() = !isFinishing && !isDestroyed

    // ---------- Audio (FIX201): teks-ke-ucapan Android, bukan rekaman qari ----------

    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private var tertunda: (() -> Unit)? = null

    private fun pecahTeks(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        var sisa = teks.trim()
        while (sisa.length > maks) {
            var potong = sisa.lastIndexOfAny(charArrayOf('.', '\n', '\u060C', ';', ':'), maks)
            if (potong < maks / 2) potong = sisa.lastIndexOf(' ', maks)
            if (potong <= 0) potong = maks - 1
            hasil.add(sisa.substring(0, potong + 1).trim())
            sisa = sisa.substring(potong + 1).trim()
        }
        if (sisa.isNotEmpty()) hasil.add(sisa)
        return hasil
    }

    private fun pilihMesinSuara() {
        MesinSuaraPembaca.tampilkan(this, simpanSuara) {
            try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
            tts = null; ttsSiap = false; tertunda = null
        }
    }

    private fun ucapkanTeks(teks: String, arab: Boolean) {
        val aksi: () -> Unit = {
            val m = tts
            if (m != null) {
                val bahasa = if (arab) Locale("ar") else Locale("id", "ID")
                val r = m.setLanguage(bahasa)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    toast(if (arab) tr("Suara bahasa Arab belum terpasang di perangkat. Pasang data suara Arab pada pengaturan teks-ke-ucapan Android.",
                        "An Arabic voice is not installed on this device. Install Arabic voice data in Android text-to-speech settings.")
                    else tr("Suara bahasa Indonesia belum terpasang di perangkat. Pasang data suara Indonesia pada pengaturan teks-ke-ucapan Android.",
                        "An Indonesian voice is not installed on this device. Install Indonesian voice data in Android text-to-speech settings."))
                } else {
                    m.stop()
                    val maks = minOf(3500, TextToSpeech.getMaxSpeechInputLength() - 100)
                    var pertama = true
                    for (potongan in pecahTeks(teks, maks)) {
                        m.speak(potongan, if (pertama) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "hadits_" + System.nanoTime())
                        pertama = false
                    }
                }
            }
        }
        if (ttsSiap) { aksi(); return }
        tertunda = aksi
        if (tts == null) {
            val mesin = MesinSuaraPembaca.paket(simpanSuara).ifBlank { null }
            tts = TextToSpeech(applicationContext, { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsSiap = true
                    val a = tertunda
                    tertunda = null
                    a?.invoke()
                } else {
                    toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = null
                    tertunda = null
                }
            }, mesin)
        }
    }

    override fun onPause() {
        sudahJeda = true
        try { tts?.stop() } catch (_: Exception) { }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        // Setelah kembali dari halaman lain, segarkan status unduhan pada beranda dan halaman kitab.
        if (sudahJeda) { sudahJeda = false; recreate() }
    }

    override fun onDestroy() {
        latar.shutdown()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    override fun bangun() {
        val kitab = KitabHadits.cari(intent.getStringExtra("kitab"))
        if (kitab == null) { beranda(); return }
        when (intent.getStringExtra("mode") ?: "") {
            "bagian", "semua", "nomor", "cari" -> halamanBaca(kitab)
            else -> halamanKitab(kitab)
        }
    }

    private fun namaKitab(k: KitabHadits.Kitab) = tr(k.judulId, k.judulEn)

    private fun buka(k: KitabHadits.Kitab, mode: String, bagian: Int = 0, halaman: Int = 0, nomor: String = "", ganti: Boolean = false, kueri: String = "") {
        val i = Intent(this, HaditsActivity::class.java)
            .putExtra("kitab", k.kode).putExtra("mode", mode)
            .putExtra("bag", bagian).putExtra("hal", halaman).putExtra("nomor", nomor).putExtra("kueri", kueri)
        startActivity(i)
        if (ganti) finish()
    }

    // ---------- Beranda ----------

    private fun beranda() {
        info(tr(
            "Pilih kitab hadits. Teks hadits diunduh sekali dari layanan hadits publik, lalu disimpan di perangkat sehingga dapat dibaca tanpa internet. Setiap hadits ditampilkan dengan teks Arab dan terjemahan Indonesia bila tersedia.",
            "Choose a hadith book. The hadith text is downloaded once from a public hadith service and then saved on this device so you can read it without internet. Each hadith is shown in Arabic with an Indonesian translation when available."
        ))
        tombol(tr("Pilih mesin suara pembaca", "Choose reading speech engine")) { pilihMesinSuara() }
        for (k in KitabHadits.daftar) {
            val status = if (KitabHadits.tersedia(this, k)) tr("tersimpan di perangkat", "saved on this device") else tr("perlu diunduh", "needs download")
            tombol(namaKitab(k) + ", " + status) { buka(k, "") }
        }
        info(tr(
            "Shahih Bukhari dan Shahih Muslim memuat hadits-hadits shahih. Untuk kitab lain, derajat hadits ditampilkan bila datanya menyertakannya.",
            "Sahih al-Bukhari and Sahih Muslim contain authentic hadiths. For other books, the grade of a hadith is shown when the data includes it."
        ))
    }

    // ---------- Halaman kitab ----------

    private fun halamanKitab(k: KitabHadits.Kitab) {
        bagian(namaKitab(k), 22f)
        val berkasArab = KitabHadits.berkasAda(this, k.arab)
        if (berkasArab == null) {
            info(tr(
                "Data kitab ini belum ada di perangkat. Unduh sekali; setelah itu kitab dapat dibaca tanpa internet. Ukuran unduhan bisa beberapa megabita, sebaiknya gunakan Wi-Fi.",
                "This book's data is not on the device yet. Download it once; after that you can read it without internet. The download can be several megabytes, so Wi-Fi is recommended."
            ))
            val status = TextView(this)
            status.textSize = 16f
            status.setTextColor(warnaTeks())
            status.setPadding(0, dp(8), 0, dp(8))
            if (Build.VERSION.SDK_INT >= 19) status.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            root.addView(status)
            statusUnduh = status
            lateinit var tombolUnduh: android.widget.Button
            tombolUnduh = tombol(tr("Unduh kitab ini", "Download this book")) { mulaiUnduh(k, tombolUnduh) }
            return
        }

        val berkasIndo = KitabHadits.berkasAda(this, k.indo)
        // Nama bagian: utamakan edisi Indonesia bila bahasa aktif Indonesia, selain itu edisi Arab/Inggris yang tersedia.
        val sumberBagian = if (berkasIndo != null && BahasaAplikasi.tampilan(this) == 0) berkasIndo else berkasArab

        val kolom = isian(tr("Nomor hadits", "Hadith number"), "", InputType.TYPE_CLASS_NUMBER) { }
        tombol(tr("Buka hadits dengan nomor ini", "Open the hadith with this number")) {
            val no = kolom.text.toString().trim().trimStart('0')
            if (no.isEmpty()) toast(tr("Tuliskan nomor hadits terlebih dahulu.", "Enter a hadith number first."))
            else buka(k, "nomor", nomor = no)
        }
        tombol(tr("Baca dari hadits pertama", "Read from the first hadith")) { buka(k, "semua") }

        // FIX244: pencarian bab berdasarkan tema (shalat, thaharah, zakat, puasa, jual beli, dan lain-lain).
        var saringan: (String) -> Unit = { }
        val kolomBab = isian(
            tr("Cari bab (misalnya shalat, thaharah, zakat, puasa)", "Search chapters (for example prayer, purification, zakat, fasting)"),
            "", InputType.TYPE_CLASS_TEXT
        ) { saringan(it) }
        val tombolTema = tombol(tr("Pilih bab populer", "Choose a popular chapter")) {
            val nama = BabHadits.daftar.map { tr(it.id, it.en) }
            AlertDialog.Builder(this)
                .setTitle(tr("Bab populer", "Popular chapters"))
                .setItems(nama.toTypedArray()) { _, i -> kolomBab.setText(nama[i]); kolomBab.setSelection(kolomBab.text.length) }
                .setNegativeButton(tr("Batal", "Cancel"), null)
                .show()
        }
        // FIX246: pencarian isi hadits tidak bergantung pada daftar bab, sehingga selalu tersedia.
        tombol(tr("Cari di isi hadits", "Search inside the hadiths")) {
            val q = kolomBab.text.toString().trim()
            if (q.isEmpty()) toast(tr("Tuliskan kata kunci terlebih dahulu, misalnya shalat atau wudhu.", "Enter a keyword first, for example prayer or ablution."))
            else if (BabHadits.PencarianTeks(q).kosong) toast(tr("Kata kunci terlalu pendek. Coba kata lain.", "That keyword is too short. Try another word."))
            else buka(k, "cari", kueri = q)
        }
        val hitungBab = TextView(this)
        hitungBab.textSize = 16f
        hitungBab.setTextColor(warnaTeks())
        hitungBab.setPadding(0, dp(4), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 19) hitungBab.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        root.addView(hitungBab)
        // FIX246: kolom pencarian selalu terlihat; bila daftar bab kosong, pencarian dilakukan pada isi hadits.
        saringan = { hitungBab.text = tr("Memuat daftar bab… Anda tetap dapat memakai tombol Cari di isi hadits.", "Loading chapters… You can already use the Search inside the hadiths button.") }
        saringan(kolomBab.text.toString())

        val tampilan = TextView(this)
        tampilan.text = tr("Memuat daftar bagian…", "Loading the list of sections…")
        tampilan.textSize = 16f
        tampilan.setTextColor(warnaTeks())
        tampilan.setPadding(0, dp(12), 0, dp(4))
        root.addView(tampilan)
        val tempatAwal = root.indexOfChild(tampilan)
        latar.execute {
            val hasil = try { KitabHadits.baca(sumberBagian, 0, 0, true) { _, _ -> false } } catch (_: Exception) { null }
            // Nama bab dari edisi lain (Arab/Indonesia) ikut dicocokkan agar "shalat" menemukan bab berbahasa Arab maupun Inggris.
            val sumberLain = if (sumberBagian == berkasIndo) berkasArab else berkasIndo
            val hasilLain = try { if (sumberLain != null) KitabHadits.baca(sumberLain, 0, 0, true) { _, _ -> false } else null } catch (_: Exception) { null }
            runOnUiThread {
                if (!hidup()) return@runOnUiThread
                val peta = hasil?.bagian ?: emptyMap()
                if (peta.isEmpty()) {
                    tampilan.text = tr("Daftar bagian tidak tersedia untuk kitab ini. Gunakan nomor hadits, baca dari awal, atau ketik kata kunci lalu ketuk Cari di isi hadits.", "No section list is available for this book. Use a hadith number, read from the start, or type a keyword and tap Search inside the hadiths.")
                    saringan = { hitungBab.text = tr("Daftar bab tidak tersedia untuk kitab ini. Ketuk Cari di isi hadits untuk mencari berdasarkan kata kunci.", "No chapter list for this book. Tap Search inside the hadiths to search by keyword.") }
                    saringan(kolomBab.text.toString())
                } else {
                    tampilan.text = tr("Bagian kitab", "Sections")
                    tampilan.setTypeface(tampilan.typeface, Typeface.BOLD)
                    if (Build.VERSION.SDK_INT >= 28) tampilan.isAccessibilityHeading = true
                    var sisip = tempatAwal + 1
                    val tombolBab = LinkedHashMap<Int, android.widget.Button>()
                    val namaGabung = LinkedHashMap<Int, String>()
                    for ((no, nama) in peta) {
                        namaGabung[no] = nama + " " + (hasilLain?.bagian?.get(no) ?: "")
                        val b = android.widget.Button(this)
                        tombolBab[no] = b
                        b.isAllCaps = false
                        b.textSize = 16f
                        b.minimumHeight = dp(48)
                        b.text = no.toString() + ". " + nama
                        b.setOnClickListener { buka(k, "bagian", bagian = no) }
                        root.addView(b, sisip++)
                    }
                    saringan = { kueri ->
                        val cocok = BabHadits.saring(namaGabung, kueri).toSet()
                        for ((no, b) in tombolBab) b.visibility = if (no in cocok) View.VISIBLE else View.GONE
                        hitungBab.text = when {
                            kueri.isBlank() -> tr("Menampilkan semua " + peta.size + " bab.", "Showing all " + peta.size + " chapters.")
                            cocok.isEmpty() -> tr("Tidak ada bab yang cocok. Coba kata lain seperti shalat, thaharah, zakat, puasa, atau haji.", "No matching chapter. Try another word such as prayer, purification, zakat, fasting, or hajj.")
                            else -> tr("Bab ditemukan: " + cocok.size + ". Ketuk salah satu bab untuk membaca haditsnya.", "Chapters found: " + cocok.size + ". Tap a chapter to read its hadiths.")
                        }
                    }
                    saringan(kolomBab.text.toString())
                }
                // Tombol hapus ditempatkan paling akhir.
                tombol(tr("Hapus data unduhan kitab ini", "Delete this book's downloaded data")) {
                    AlertDialog.Builder(this)
                        .setTitle(tr("Hapus data kitab?", "Delete book data?"))
                        .setMessage(tr("Data akan dihapus dari perangkat. Anda dapat mengunduhnya lagi kapan saja.", "The data will be removed from this device. You can download it again at any time."))
                        .setPositiveButton(tr("Hapus", "Delete")) { _, _ ->
                            KitabHadits.hapus(this, k)
                            toast(tr("Data kitab dihapus.", "Book data deleted."))
                            recreate()
                        }
                        .setNegativeButton(tr("Batal", "Cancel"), null)
                        .show()
                }
            }
        }
    }

    private fun mulaiUnduh(k: KitabHadits.Kitab, tombolUnduh: android.widget.Button) {
        tombolUnduh.isEnabled = false
        statusUnduh?.text = tr("Mengunduh… mohon tunggu.", "Downloading… please wait.")
        latar.execute {
            var terakhirLapor = 0L
            fun lapor(label: String, byte: Long) {
                val sekarang = System.currentTimeMillis()
                if (sekarang - terakhirLapor < 1500L) return
                terakhirLapor = sekarang
                val mb = String.format(Locale.ROOT, "%.1f", byte / 1048576.0)
                runOnUiThread { if (hidup()) statusUnduh?.text = label + " " + mb + " MB" }
            }
            if (k.sumberSql.isNotEmpty()) {
                val ok = KitabHadits.unduhSql(this, k) { lapor(tr("Mengunduh data:", "Downloading data:"), it) }
                runOnUiThread {
                    if (!hidup()) return@runOnUiThread
                    if (ok) { toast(tr("Kitab berhasil diunduh.", "The book was downloaded.")); recreate() }
                    else {
                        tombolUnduh.isEnabled = true
                        statusUnduh?.text = tr(
                            "Unduhan gagal. Periksa internet Anda lalu coba lagi.",
                            "The download failed. Check your internet connection and try again."
                        )
                    }
                }
                return@execute
            }
            val arab = KitabHadits.unduh(this, k.arab) { lapor(tr("Mengunduh teks Arab:", "Downloading Arabic text:"), it) }
            if (arab == null) {
                runOnUiThread {
                    if (!hidup()) return@runOnUiThread
                    tombolUnduh.isEnabled = true
                    statusUnduh?.text = tr(
                        "Unduhan gagal. Periksa internet Anda lalu coba lagi. Bila terus gagal, kitab ini mungkin belum tersedia di layanan data yang dipakai.",
                        "The download failed. Check your internet connection and try again. If it keeps failing, this book may not be available from the data service in use."
                    )
                }
                return@execute
            }
            val indo = KitabHadits.unduh(this, k.indo) { lapor(tr("Mengunduh terjemahan Indonesia:", "Downloading the Indonesian translation:"), it) }
            runOnUiThread {
                if (!hidup()) return@runOnUiThread
                val pesan = if (indo == null)
                    tr("Teks Arab terunduh, tetapi terjemahan Indonesia tidak tersedia untuk kitab ini.", "The Arabic text was downloaded, but no Indonesian translation is available for this book.")
                else tr("Kitab berhasil diunduh.", "The book was downloaded.")
                toast(pesan)
                recreate()
            }
        }
    }

    // ---------- Halaman baca ----------

    /** FIX246: nomor hadits hasil pencarian isi; disimpan sementara agar pindah halaman tidak memindai ulang berkas. */
    private fun nomorHasilCari(k: KitabHadits.Kitab, kueri: String, berkasArab: java.io.File, berkasIndo: java.io.File?): Set<String> {
        val kunci = k.kode + "|" + kueri
        cacheCariKunci?.let { if (it == kunci) cacheCariNomor?.let { n -> return n } }
        val pencarian = BabHadits.PencarianTeks(kueri)
        val daftar = LinkedHashSet<String>()
        if (berkasIndo != null) daftar.addAll(KitabHadits.cariNomorDariTeks(berkasIndo, pencarian))
        if (daftar.isEmpty()) daftar.addAll(KitabHadits.cariNomorDariTeks(berkasArab, pencarian))
        cacheCariKunci = kunci
        cacheCariNomor = daftar
        return daftar
    }

    private fun halamanBaca(k: KitabHadits.Kitab) {
        val mode = intent.getStringExtra("mode") ?: "semua"
        val bag = intent.getIntExtra("bag", 0)
        val hal = intent.getIntExtra("hal", 0)
        val nomorCari = intent.getStringExtra("nomor") ?: ""
        val kueri = intent.getStringExtra("kueri") ?: ""
        bagian(namaKitab(k), 22f)
        val berkasArab = KitabHadits.berkasAda(this, k.arab)
        if (berkasArab == null) { info(tr("Data kitab belum diunduh.", "The book data has not been downloaded.")); return }
        val berkasIndo = KitabHadits.berkasAda(this, k.indo)

        val muat = TextView(this)
        muat.text = tr("Memuat hadits…", "Loading hadiths…")
        muat.textSize = 16f
        muat.setTextColor(warnaTeks())
        muat.setPadding(0, dp(8), 0, dp(8))
        if (Build.VERSION.SDK_INT >= 19) muat.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        root.addView(muat)

        latar.execute {
            var jumlahCari = 0
            val hasil = try {
                when (mode) {
                    "cari" -> {
                        val nomorSet = nomorHasilCari(k, kueri, berkasArab, berkasIndo)
                        jumlahCari = nomorSet.size
                        KitabHadits.baca(berkasArab, hal * ukuranHalaman, ukuranHalaman, false) { no, _ -> no in nomorSet }
                    }
                    "nomor" -> KitabHadits.baca(berkasArab, 0, 1, false) { no, _ -> no == nomorCari }
                    "bagian" -> KitabHadits.baca(berkasArab, hal * ukuranHalaman, ukuranHalaman, false) { _, b -> b == bag }
                    else -> KitabHadits.baca(berkasArab, hal * ukuranHalaman, ukuranHalaman, false) { _, _ -> true }
                }
            } catch (_: Exception) { null }
            val terjemah = try {
                if (hasil != null && berkasIndo != null) KitabHadits.terjemahan(berkasIndo, hasil.item.map { it.nomor }.toSet()) else emptyMap()
            } catch (_: Exception) { emptyMap<String, String>() }
            runOnUiThread {
                if (!hidup()) return@runOnUiThread
                root.removeView(muat)
                tampilkanHasil(k, mode, bag, hal, nomorCari, hasil, terjemah, berkasIndo != null, kueri, jumlahCari)
            }
        }
    }

    private fun tampilkanHasil(
        k: KitabHadits.Kitab, mode: String, bag: Int, hal: Int, nomorCari: String,
        hasil: KitabHadits.Hasil?, terjemah: Map<String, String>, adaEdisiIndo: Boolean,
        kueri: String = "", jumlahCari: Int = 0
    ) {
        if (hasil == null || hasil.item.isEmpty()) {
            info(if (mode == "nomor") tr("Hadits dengan nomor itu tidak ditemukan di kitab ini.", "No hadith with that number was found in this book.")
                 else if (mode == "cari") tr("Tidak ada hadits yang cocok dengan \"" + kueri + "\". Coba kata lain, misalnya shalat, wudhu, zakat, atau puasa.", "No hadith matches \"" + kueri + "\". Try another word, for example prayer, ablution, zakat, or fasting.")
                 else tr("Tidak ada hadits untuk ditampilkan.", "There are no hadiths to show."))
            if (mode != "nomor" && hal > 0) tombol(tr("Halaman sebelumnya", "Previous page")) { buka(k, mode, bag, hal - 1, ganti = true, kueri = kueri) }
            return
        }
        if (mode == "bagian") {
            val nama = hasil.bagian[bag]
            if (nama != null) { val t = info(bag.toString() + ". " + nama); t.setTypeface(t.typeface, Typeface.BOLD) }
        }
        if (mode == "cari") {
            val t = info(tr("Hasil pencarian \"" + kueri + "\": " + jumlahCari + " hadits ditemukan. Halaman " + (hal + 1) + ".", "Search results for \"" + kueri + "\": " + jumlahCari + " hadiths found. Page " + (hal + 1) + "."))
            t.setTypeface(t.typeface, Typeface.BOLD)
        }
        tombol(tr("Pilih mesin suara pembaca", "Choose reading speech engine")) { pilihMesinSuara() }
        tombol(tr("Hentikan suara", "Stop audio")) { try { tts?.stop() } catch (_: Exception) { } }
        for (h in hasil.item) kartuHadis(k, h, terjemah[h.nomor], adaEdisiIndo, hasil.indoSaja)

        if (mode == "nomor") {
            val n = nomorCari.toIntOrNull()
            if (n != null) {
                tombol(tr("Hadits berikutnya", "Next hadith")) { buka(k, "nomor", nomor = (n + 1).toString(), ganti = true) }
                if (n > 1) tombol(tr("Hadits sebelumnya", "Previous hadith")) { buka(k, "nomor", nomor = (n - 1).toString(), ganti = true) }
            }
        } else {
            if (hasil.adaLagi) tombol(tr("Halaman berikutnya", "Next page")) { buka(k, mode, bag, hal + 1, ganti = true, kueri = kueri) }
            if (hal > 0) tombol(tr("Halaman sebelumnya", "Previous page")) { buka(k, mode, bag, hal - 1, ganti = true, kueri = kueri) }
        }
    }

    private fun kartuHadis(k: KitabHadits.Kitab, h: KitabHadits.Hadis, indoDariBerkas: String?, adaEdisiIndo: Boolean, indoSaja: Boolean) {
        val indo = if (indoSaja) h.teks else indoDariBerkas
        val judul = TextView(this)
        judul.text = namaKitab(k) + ", " + tr("hadits nomor ", "hadith number ") + h.nomor
        judul.textSize = 18f
        judul.setTypeface(judul.typeface, Typeface.BOLD)
        judul.setTextColor(warnaAksen())
        judul.setPadding(0, dp(22), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) judul.isAccessibilityHeading = true
        root.addView(judul)

        val derajat = if (k.seluruhShahih) tr("Derajat: shahih", "Grade: sahih") else if (h.derajat.isNotBlank()) tr("Derajat: ", "Grade: ") + h.derajat else ""
        if (derajat.isNotEmpty()) {
            val d = TextView(this)
            d.text = derajat
            d.textSize = 15f
            d.setTextColor(warnaPetunjuk())
            root.addView(d)
        }

        if (!indoSaja) {
            val arab = TextView(this)
            arab.text = h.teks
            arab.textSize = 24f
            arab.setTextColor(warnaTeks())
            arab.layoutDirection = View.LAYOUT_DIRECTION_RTL
            arab.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            arab.setLineSpacing(0f, 1.3f)
            arab.setPadding(0, dp(8), 0, dp(8))
            root.addView(arab)
        }

        val arti = TextView(this)
        arti.text = indo ?: (if (adaEdisiIndo) tr("Terjemahan nomor ini tidak ditemukan.", "No translation was found for this number.")
                              else tr("Terjemahan Indonesia tidak tersedia untuk kitab ini.", "No Indonesian translation is available for this book."))
        arti.textSize = 17f
        arti.setTextColor(warnaTeks())
        arti.setPadding(0, dp(4), 0, dp(8))
        root.addView(arti)

        val gabung = namaKitab(k) + " " + h.nomor + "\n\n" + (if (indoSaja) "" else h.teks + "\n\n") + (indo ?: "")
        if (!indoSaja) tombol(tr("Dengarkan teks Arab hadits nomor ", "Listen to the Arabic text of hadith number ") + h.nomor) { ucapkanTeks(h.teks, true) }
        if (indo != null) tombol(tr("Dengarkan terjemahan hadits nomor ", "Listen to the translation of hadith number ") + h.nomor) { ucapkanTeks(indo, false) }
        tombol(tr("Salin hadits nomor ", "Copy hadith number ") + h.nomor) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("hadits", gabung))
                toast(tr("Hadits disalin.", "Hadith copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan hadits nomor ", "Share hadith number ") + h.nomor) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, gabung)
                startActivity(Intent.createChooser(i, tr("Bagikan hadits", "Share hadith")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan hadits.", "No app is available to share this hadith."))
            }
        }
    }
}
