package com.novan.bateraibicara

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Pengingat lokal membaca Al-Qur'an (waktu dan hari diatur pengguna, lihat [PengingatBaca]). */
class KhatamReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        when (intent?.action) {
            PengingatBaca.AKSI_TUNDA_KLIK -> {
                try { manager.cancel(6903) } catch (_: Exception) { }
                PengingatBaca.tunda(context)
                return
            }
            PengingatBaca.AKSI_UJI -> { tampilkan(context, prefs, manager, true); return }
            PengingatBaca.AKSI_BUNYI_ULANG -> {
                if (prefs.getBoolean("pengingat_aktif", false)) tampilkan(context, prefs, manager, false)
                return
            }
        }
        if (!prefs.getBoolean("pengingat_aktif", false)) return
        // Pasang dulu kejadian berikutnya agar jadwal tetap berjalan walau penayangan notifikasi gagal.
        PengingatBaca.jadwalkan(context)
        val hariIni = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        if (PengingatBaca.hari(prefs) and (1 shl hariIni) == 0) return
        tampilkan(context, prefs, manager, false)
    }

    @Suppress("DEPRECATION")
    private fun tampilkan(context: Context, prefs: android.content.SharedPreferences, manager: NotificationManager, uji: Boolean) {
        val english = BahasaAplikasi.tampilan(context) == 1
        val suara = SuaraPengingat.siapkan(
            context, "khatam_quran_reminder",
            if (english) "Qur'an reading reminder" else "Pengingat membaca Al-Qur'an",
            prefs, "pengingat_baca_suara"
        )
        val open = PendingIntent.getActivity(context, 6902, Intent(context, KhatamActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, suara.channelId)
            else android.app.Notification.Builder(context)
        builder
            .setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(if (english) "A gentle Qur'an reminder" else "Pengingat membaca Al-Qur'an")
            .setContentText(if (english) "Continue at your own pace. Every verse counts." else "Lanjutkan sesuai kemampuan. Setiap ayat berarti.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0,
                if (english) "Snooze " + PengingatBaca.MENIT_TUNDA + " minutes" else "Tunda " + PengingatBaca.MENIT_TUNDA + " menit",
                PengingatBaca.intentTundaKlik(context))
        SuaraPengingat.aturSuara(builder, suara)
        val notification = builder.build()
        try { manager.notify(6903, notification) } catch (_: SecurityException) { }
        if (suara.gunakanTts && manager.areNotificationsEnabled() &&
            (Build.VERSION.SDK_INT < 26 || manager.getNotificationChannel(suara.channelId)?.importance != NotificationManager.IMPORTANCE_NONE)) {
            val pending = goAsync()
            SuaraPengingat.ucapkan(context,
                if (english) "It is time to read the Qur'an. Continue at your own pace; every verse counts."
                else "Saatnya membaca Al-Qur'an. Lanjutkan sesuai kemampuan; setiap ayat berarti.", english
            ) { pending.finish() }
        }
        // FIX74: menelungkupkan HP dalam 20 detik pertama menghentikan bunyi/getar dan menyingkirkan notifikasi ini.
        PembungkamTelungkup.mulai(context, "khatam_notif", 20_000L) { try { manager.cancel(6903) } catch (_: Exception) { } }
    }
}
