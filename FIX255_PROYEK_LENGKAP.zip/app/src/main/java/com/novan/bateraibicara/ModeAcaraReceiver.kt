package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ModeAcaraReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (ModeAcara.aktif(context)) ModeAcara.selesai(context)
    }
}
