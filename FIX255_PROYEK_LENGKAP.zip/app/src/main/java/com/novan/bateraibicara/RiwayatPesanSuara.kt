package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Cache privat lokal untuk pesan masuk yang memang ditampilkan oleh notifikasi Android. */
object RiwayatPesanSuara {
    private const val PREF = "riwayat_pesan_perintah_suara"
    private const val KEY = "items"
    private const val BATAS = 50
    private const val UMUR_MAKS = 7L * 24L * 60L * 60L * 1000L

    private fun bacaArray(raw: String?): JSONArray {
        return try {
            JSONArray(raw ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
    }

    @Synchronized
    fun simpan(context: Context, pengirim: String, isi: String, aplikasi: String) {
        val nama = pengirim.trim()
        val pesan = isi.trim()
        if (nama.isBlank() || pesan.isBlank()) return

        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val lama: JSONArray = bacaArray(prefs.getString(KEY, null))
        val sekarang = System.currentTimeMillis()
        val baru = JSONArray()

        for (i in 0 until lama.length()) {
            val item: JSONObject = lama.optJSONObject(i) ?: continue
            val umur = sekarang - item.optLong("waktu")
            if (umur >= 0L && umur <= UMUR_MAKS) {
                baru.put(item)
            }
        }

        val itemBaru = JSONObject()
            .put("pengirim", nama)
            .put("isi", pesan.take(1500))
            .put("aplikasi", aplikasi)
            .put("waktu", sekarang)
        baru.put(itemBaru)

        val ringkas = JSONArray()
        val awal = (baru.length() - BATAS).coerceAtLeast(0)
        for (i in awal until baru.length()) {
            val item: JSONObject? = baru.optJSONObject(i)
            if (item != null) ringkas.put(item)
        }
        prefs.edit().putString(KEY, ringkas.toString()).apply()
    }

    @Synchronized
    fun cari(context: Context, nama: String): String? {
        val target = nama.trim()
        if (target.isBlank()) return null

        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null)
        val arr: JSONArray = bacaArray(raw)
        val sekarang = System.currentTimeMillis()

        for (i in arr.length() - 1 downTo 0) {
            val item: JSONObject = arr.optJSONObject(i) ?: continue
            val umur = sekarang - item.optLong("waktu")
            if (umur < 0L || umur > UMUR_MAKS) continue

            val pengirim = item.optString("pengirim", "")
            val isi = item.optString("isi", "")
            if ((pengirim.equals(target, ignoreCase = true) ||
                    pengirim.contains(target, ignoreCase = true)) && isi.isNotBlank()) {
                return pengirim + ". " + isi
            }
        }
        return null
    }

    @Synchronized
    fun terbaru(context: Context): String? {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, null)
        val arr: JSONArray = bacaArray(raw)
        val sekarang = System.currentTimeMillis()

        for (i in arr.length() - 1 downTo 0) {
            val item: JSONObject = arr.optJSONObject(i) ?: continue
            val umur = sekarang - item.optLong("waktu")
            if (umur < 0L || umur > UMUR_MAKS) continue

            val isi = item.optString("isi", "")
            if (isi.isNotBlank()) {
                val pengirim = item.optString("pengirim", "")
                return pengirim + ". " + isi
            }
        }
        return null
    }
}
