package com.novan.bateraibicara

import android.content.Context
import android.content.Intent
import android.widget.Switch
import android.widget.TextView

/**
 * FIX229: satu halaman pengaturan untuk SEMUA pemicu asisten/perintah suara, agar pengguna mudah mencari dan
 * mengaktifkannya: Beritahu Saya (ikon aplikasi dan widget), goncangan tiga kali, tombol volume, dan tombol aksesibilitas.
 * Setiap pemicu menampilkan statusnya; pengaturan terperinci dibuka dari halaman masing-masing.
 */
class PemicuAsistenActivity : Halaman() {
    override val judulHalaman = R.string.judul_pemicu_asisten

    private val pengaturan by lazy { getSharedPreferences("pengaturan", Context.MODE_PRIVATE) }
    private val prefsApp by lazy { Prefs(applicationContext) }
    private lateinit var ringkasan: TextView
    private lateinit var statusBeritahu: TextView
    private lateinit var statusGoncangan: TextView
    private lateinit var statusTombol: TextView
    private lateinit var saklarBeritahu: Switch
    private lateinit var saklarLangsung: Switch
    private var menyusun = false

    private fun namaModeTombol(m: PemicuTombol.Mode): String = when (m) {
        PemicuTombol.Mode.NONAKTIF -> tr("nonaktif", "off")
        PemicuTombol.Mode.TAHAN_ATAS -> tr("tahan volume atas", "hold volume up")
        PemicuTombol.Mode.TAHAN_BAWAH -> tr("tahan volume bawah", "hold volume down")
        PemicuTombol.Mode.DUA_VOLUME -> tr("volume atas dan bawah bersamaan", "volume up and down together")
        PemicuTombol.Mode.DUA_KALI_ATAS -> tr("volume atas dua kali", "double-press volume up")
        PemicuTombol.Mode.DUA_KALI_BAWAH -> tr("volume bawah dua kali", "double-press volume down")
        PemicuTombol.Mode.AKSESIBILITAS -> tr("tombol aksesibilitas", "accessibility button")
    }

    override fun bangun() {
        info(tr(
            "Di sini Anda dapat memilih dan mengaktifkan semua cara membuka asisten atau perintah suara. Aktifkan satu atau beberapa pemicu sesuai kebutuhan. Setiap pemicu menampilkan statusnya, dan tombol di bawahnya membuka pengaturan lengkapnya.",
            "Here you can choose and turn on every way to open the voice assistant or voice commands. Turn on one or several triggers as needed. Each trigger shows its status, and the button below it opens its full settings."
        ))
        bagian(tr("Ringkasan", "Summary"))
        ringkasan = info("")

        // 1. Beritahu Saya
        bagian(tr("1. Beritahu Saya: ikon aplikasi dan widget", "1. Beritahu Saya: app icon and widget"))
        statusBeritahu = info("")
        saklarBeritahu = saklar(getString(R.string.sw_beritahu_saya), prefsApp.beritahuSayaOn) { aktif ->
            if (menyusun) return@saklar
            prefsApp.beritahuSayaOn = aktif
            BeritahuSayaWidgetProvider.perbaruiSemua(this)
            toast(if (aktif) R.string.beritahu_saya_diaktifkan else R.string.beritahu_saya_dimatikan)
            segarkan()
        }
        saklarLangsung = saklar(getString(R.string.sw_beritahu_saya_langsung_suara), prefsApp.beritahuSayaLangsungSuara) { aktif ->
            if (menyusun) return@saklar
            prefsApp.beritahuSayaLangsungSuara = aktif
            BeritahuSayaWidgetProvider.perbaruiSemua(this)
            toast(if (aktif) R.string.beritahu_saya_langsung_suara_on else R.string.beritahu_saya_langsung_suara_off)
            segarkan()
        }
        info(getString(R.string.info_beritahu_saya))

        // 2. Goncangan
        bagian(tr("2. Goyangkan HP tiga kali", "2. Shake the phone three times"))
        statusGoncangan = info("")
        tombol(tr("Pengaturan aktivasi dengan goncangan", "Shake activation settings")) {
            startActivity(Intent(this, PengaturanGoncanganActivity::class.java))
        }
        info(tr(
            "Goyangkan HP tiga kali cepat untuk membuka perintah suara, termasuk saat layar terkunci. Pembatasan Android dan penghemat baterai perangkat dapat memengaruhi kerja di latar belakang.",
            "Shake the phone three times quickly to open voice commands, including while the screen is locked. Android and device battery-saver restrictions may affect background operation."
        ))

        // 3 dan 4. Tombol
        bagian(tr("3. Tombol volume dan tombol aksesibilitas", "3. Volume buttons and accessibility button"))
        statusTombol = info("")
        tombol(getString(R.string.judul_pemicu_tombol)) {
            startActivity(Intent(this, PemicuTombolActivity::class.java))
        }
        info(tr(
            "Pilih tombol tahan volume atas atau bawah, kedua volume bersamaan, volume dua kali, atau tombol aksesibilitas. Perlu mengaktifkan layanan aksesibilitas pemicu tombol sekali. Tombol daya tidak dapat dipakai oleh aplikasi biasa.",
            "Choose hold volume up or down, both volume buttons together, double-press volume, or the accessibility button. The button trigger accessibility service must be turned on once. The power button cannot be used by ordinary apps."
        ))

        bagian(tr("Alat bantu", "Tools"))
        tombol(tr("Coba perintah suara sekarang", "Try voice commands now")) {
            startActivity(Intent(this, PerintahSuaraActivity::class.java).putExtra(PerintahSuaraActivity.EXTRA_DARI_APLIKASI, true))
        }
        tombol(tr("Paket bahasa pengenal suara offline", "Offline speech language packs")) {
            startActivity(Intent(this, PaketBahasaOfflineActivity::class.java))
        }
        segarkan()
    }

    override fun onResume() {
        super.onResume()
        if (::ringkasan.isInitialized) segarkan()
    }

    private fun segarkan() {
        menyusun = true
        if (saklarBeritahu.isChecked != prefsApp.beritahuSayaOn) saklarBeritahu.isChecked = prefsApp.beritahuSayaOn
        if (saklarLangsung.isChecked != prefsApp.beritahuSayaLangsungSuara) saklarLangsung.isChecked = prefsApp.beritahuSayaLangsungSuara
        menyusun = false

        val beritahu = prefsApp.beritahuSayaOn
        val goncangan = pengaturan.getBoolean(GoncanganSuaraService.KEY_AKTIF, false)
        val mode = PemicuTombol.modeDariIndeks(pengaturan.getInt(TombolSuaraAccessibilityService.KEY_MODE, 0))
        val layanan = PemicuSuara.layananAktif(this)
        val tombolAktif = mode != PemicuTombol.Mode.NONAKTIF && layanan

        statusBeritahu.text = ui(tr("Status: ", "Status: ") + if (beritahu) tr("AKTIF.", "ON.") else tr("nonaktif.", "off."))
        statusGoncangan.text = ui(tr("Status: ", "Status: ") + if (goncangan) tr("AKTIF.", "ON.") else tr("nonaktif.", "off."))
        statusTombol.text = ui(
            tr("Pilihan: ", "Choice: ") + namaModeTombol(mode) + tr(". Layanan aksesibilitas: ", ". Accessibility service: ") +
                (if (layanan) tr("aktif.", "on.") else tr("belum aktif.", "not on yet.")) +
                (if (mode != PemicuTombol.Mode.NONAKTIF && !layanan) tr(" Aktifkan layanannya agar tombol bekerja.", " Turn the service on so the button works.") else "")
        )

        val aktif = ArrayList<String>()
        if (beritahu) aktif.add(tr("Beritahu Saya", "Beritahu Saya"))
        if (goncangan) aktif.add(tr("goncangan tiga kali", "shake three times"))
        if (tombolAktif) aktif.add(namaModeTombol(mode))
        ringkasan.text = ui(
            if (aktif.isEmpty()) tr("Belum ada pemicu yang aktif.", "No trigger is on yet.")
            else tr("Pemicu aktif: ", "Active triggers: ") + aktif.joinToString(", ") + "."
        )
    }
}
