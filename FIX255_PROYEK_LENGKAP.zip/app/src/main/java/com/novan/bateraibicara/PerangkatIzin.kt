package com.novan.bateraibicara

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

/**
 * Bantuan perizinan lintas merek HP. Android standar hanya mengenal izin umum (notifikasi, alarm tepat
 * waktu, abaikan optimalisasi baterai, tampil di atas aplikasi lain). Banyak merek (Xiaomi, OPPO/Realme/
 * OnePlus, Vivo, Huawei/Honor, Transsion, Asus, dll.) menambahkan pengaturan sendiri seperti "Mulai otomatis"
 * dan "Pop-up di latar belakang". Menu itu tidak punya alamat resmi, jadi tiap calon alamat dicoba
 * berurutan (mulai dari yang cocok dengan merek HP) sampai ada yang berhasil dibuka.
 */
object PerangkatIzin {

    enum class Kategori { MULAI_OTOMATIS, BATERAI_MEREK, POPUP_LATAR }

    // ---------- Merek ----------

    /** Keluarga merek: xiaomi, oppo, vivo, huawei, transsion, asus, nokia, letv, samsung, atau lain. */
    fun keluarga(): String {
        val s = ((Build.MANUFACTURER ?: "") + " " + (Build.BRAND ?: "")).lowercase()
        fun ada(vararg k: String) = k.any { s.contains(it) }
        return when {
            ada("xiaomi", "redmi", "poco", "blackshark") -> "xiaomi"
            ada("oppo", "realme", "oneplus") -> "oppo"
            ada("vivo", "iqoo") -> "vivo"
            ada("huawei", "honor") -> "huawei"
            ada("tecno", "infinix", "itel", "transsion") -> "transsion"
            ada("asus") -> "asus"
            ada("nokia", "hmd") -> "nokia"
            ada("letv", "leeco") -> "letv"
            ada("samsung") -> "samsung"
            else -> "lain"
        }
    }

    fun samsung(): Boolean = keluarga() == "samsung"

    /** Nama perangkat yang mudah dibaca, mis. "Xiaomi 2201117TY". */
    fun namaPerangkat(): String {
        val merek = (Build.MANUFACTURER ?: "").replaceFirstChar { it.uppercase() }
        val model = Build.MODEL ?: ""
        return if (model.lowercase().startsWith(merek.lowercase())) model else (merek + " " + model).trim()
    }

    fun panduanRes(): Int = when (keluarga()) {
        "xiaomi" -> R.string.panduan_xiaomi
        "oppo" -> R.string.panduan_oppo
        "vivo" -> R.string.panduan_vivo
        "huawei" -> R.string.panduan_huawei
        "transsion" -> R.string.panduan_transsion
        "samsung" -> R.string.panduan_samsung
        else -> R.string.panduan_lain
    }

    // ---------- Status izin standar ----------

    fun notifikasiAktif(c: Context): Boolean = try {
        c.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
    } catch (_: Exception) { true }

    fun alarmTepatWaktu(c: Context): Boolean = try {
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() else true
    } catch (_: Exception) { true }

    fun abaikanBaterai(c: Context): Boolean = try {
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    } catch (_: Exception) { false }

    fun tampilDiAtas(c: Context): Boolean = try { Settings.canDrawOverlays(c) } catch (_: Exception) { false }

    fun aksesNotifikasi(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == c.packageName }
    }

    fun janganGanggu(c: Context): Boolean = try {
        c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
    } catch (_: Exception) { false }

    // ---------- Membuka pengaturan ----------

    private fun uriPaket(c: Context) = Uri.parse("package:" + c.packageName)

    /** Mencoba tiap Intent sampai satu berhasil dibuka. True bila ada yang terbuka. */
    private fun coba(a: Activity, daftar: List<Intent>): Boolean {
        for (i in daftar) {
            try { a.startActivity(i); return true } catch (_: Exception) { }
        }
        return false
    }

    fun bukaInfoAplikasi(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    fun bukaNotifikasi(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.packageName),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    fun bukaAlarmTepat(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, uriPaket(a)),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    fun bukaAbaikanBaterai(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, uriPaket(a)),
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    /** Halaman "Tampil di atas aplikasi lain"; aplikasi hanya terdaftar di sana bila manifest memuat SYSTEM_ALERT_WINDOW. */
    fun bukaTampilDiAtas(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uriPaket(a)),
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    fun bukaAksesNotifikasi(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    fun bukaJanganGanggu(a: Activity): Boolean = coba(a, listOf(
        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uriPaket(a))
    ))

    private fun k(paket: String, kelas: String) = Intent().setComponent(ComponentName(paket, kelas))

    private fun calon(a: Activity, kategori: Kategori): List<Pair<String, Intent>> {
        val paket = a.packageName
        val label = try { a.applicationInfo.loadLabel(a.packageManager).toString() } catch (_: Exception) { paket }
        return when (kategori) {
            Kategori.MULAI_OTOMATIS -> listOf(
                "xiaomi" to k("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
                "oppo" to k("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
                "oppo" to k("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
                "oppo" to k("com.oplus.battery", "com.oplus.startupapp.view.StartupAppListActivity"),
                "oppo" to k("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
                "oppo" to k("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"),
                "vivo" to k("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
                "vivo" to k("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
                "vivo" to k("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
                "vivo" to k("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity"),
                "huawei" to k("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
                "huawei" to k("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"),
                "huawei" to k("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
                "transsion" to k("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"),
                "asus" to k("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"),
                "letv" to k("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"),
                "nokia" to k("com.evenwell.powersaving.g3", "com.evenwell.powersaving.g3.exception.PowerSaverExceptionActivity")
            )
            Kategori.BATERAI_MEREK -> listOf(
                "xiaomi" to k("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")
                    .putExtra("package_name", paket).putExtra("package_label", label),
                "oppo" to k("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerUsageModelActivity"),
                "oppo" to k("com.coloros.oppoguardelf", "com.coloros.powermanager.fuelgaue.PowerConsumptionActivity"),
                "oppo" to k("com.oplus.battery", "com.oplus.powermanager.fuelgaue.PowerUsageModelActivity"),
                "vivo" to k("com.vivo.abe", "com.vivo.applicationbehaviorengine.ui.ExcessivePowerManagerActivity"),
                "vivo" to k("com.iqoo.powersaving", "com.iqoo.powersaving.PowerSavingManagerActivity"),
                "huawei" to k("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity"),
                "asus" to k("com.asus.mobilemanager", "com.asus.mobilemanager.powersaver.PowerSaverSettings"),
                "samsung" to k("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"),
                "samsung" to k("com.samsung.android.sm_cn", "com.samsung.android.sm.ui.battery.BatteryActivity")
            )
            Kategori.POPUP_LATAR -> listOf(
                "xiaomi" to Intent("miui.intent.action.APP_PERM_EDITOR")
                    .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                    .putExtra("extra_pkgname", paket),
                "xiaomi" to Intent("miui.intent.action.APP_PERM_EDITOR")
                    .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
                    .putExtra("extra_pkgname", paket),
                "xiaomi" to Intent("miui.intent.action.APP_PERM_EDITOR").putExtra("extra_pkgname", paket)
            )
        }
    }

    /**
     * Membuka menu khusus merek untuk [kategori]. Calon yang cocok dengan merek HP dicoba lebih dulu, lalu
     * sisanya (sebagian ROM memakai komponen merek lain). True bila ada menu yang terbuka.
     */
    fun bukaKhusus(a: Activity, kategori: Kategori): Boolean {
        val semua = calon(a, kategori)
        val fam = keluarga()
        val urut = semua.filter { it.first == fam } + semua.filter { it.first != fam }
        return coba(a, urut.map { it.second })
    }
}
