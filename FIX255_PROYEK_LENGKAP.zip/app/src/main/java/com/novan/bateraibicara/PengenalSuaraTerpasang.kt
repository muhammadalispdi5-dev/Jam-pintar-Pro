package com.novan.bateraibicara

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognitionService

/** Daftar dan pilihan mesin SpeechRecognizer yang benar-benar terpasang di perangkat. */
object PengenalSuaraTerpasang {
    private const val PREFS = "pengaturan_pengenal_suara"
    private const val KOMPONEN_DIPILIH = "komponen_mesin_dipilih"

    data class Mesin(val komponen: ComponentName, val nama: String, val paket: String)

    @Suppress("DEPRECATION")
    fun daftar(context: Context): List<Mesin> {
        return try {
            val intent = Intent(RecognitionService.SERVICE_INTERFACE)
            val hasil = context.packageManager.queryIntentServices(intent, PackageManager.GET_META_DATA)
            hasil.mapNotNull { resolve ->
                val info = resolve.serviceInfo ?: return@mapNotNull null
                // Hanya layanan yang aktif, dapat dipanggil aplikasi lain, dan memenuhi
                // kontrak keamanan SpeechRecognizer Android yang ditampilkan kepada pengguna.
                if (!info.enabled || !info.exported) return@mapNotNull null
                if (info.permission != "android.permission.BIND_SPEECH_RECOGNITION_SERVICE") return@mapNotNull null
                val aplikasiAktif = try {
                    context.packageManager.getApplicationInfo(info.packageName, 0).enabled
                } catch (_: Exception) { false }
                if (!aplikasiAktif) return@mapNotNull null
                val component = ComponentName(info.packageName, info.name)
                val label = try { info.loadLabel(context.packageManager)?.toString() } catch (_: Exception) { null }
                Mesin(component, label?.takeIf { it.isNotBlank() } ?: info.packageName, info.packageName)
            }.distinctBy { it.komponen.flattenToString() }.sortedBy { it.nama.lowercase() }
        } catch (_: Exception) { emptyList() }
    }

    fun dipilih(context: Context): ComponentName? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KOMPONEN_DIPILIH, null) ?: return null
        val component = ComponentName.unflattenFromString(raw) ?: return null
        return if (daftar(context).any { it.komponen == component }) component else null
    }

    fun simpan(context: Context, component: ComponentName?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KOMPONEN_DIPILIH, component?.flattenToString()).apply()
    }

    fun namaDipilih(context: Context): String? {
        val component = dipilih(context) ?: return null
        return daftar(context).firstOrNull { it.komponen == component }?.nama
    }

    /** Memastikan pilihan tersimpan masih terpasang dan bisa dipakai sebelum membuat recognizer. */
    fun pilihanMasihTersedia(context: Context): Boolean {
        val component = dipilih(context) ?: return true // null berarti pakai layanan bawaan Android
        return daftar(context).any { it.komponen == component }
    }
}
