package com.novan.bateraibicara

/**
 * FIX219: mesin hitung waris (faraid) murni Kotlin tanpa dependensi Android agar dapat diuji sendiri.
 * Mengikuti pendapat jumhur/mazhab Syafi'i: hajb (penghalang), 'aul, radd, Umariyatain, kakek bersama saudara,
 * dan Akdariyah. Semua pecahan dihitung eksak (tanpa pembulatan) sampai tahap nominal rupiah.
 */
class Pecahan private constructor(val n: Long, val d: Long) : Comparable<Pecahan> {
    companion object {
        val NOL = Pecahan(0, 1)
        val SATU = Pecahan(1, 1)
        private fun fpb(a: Long, b: Long): Long { var x = Math.abs(a); var y = Math.abs(b); while (y != 0L) { val t = x % y; x = y; y = t }; return if (x == 0L) 1L else x }
        fun dari(n: Long, d: Long = 1L): Pecahan {
            require(d != 0L)
            val g = fpb(n, d)
            val s = if (d < 0) -1L else 1L
            return Pecahan(s * n / g, s * d / g)
        }
    }
    operator fun plus(o: Pecahan) = dari(n * o.d + o.n * d, d * o.d)
    operator fun minus(o: Pecahan) = dari(n * o.d - o.n * d, d * o.d)
    operator fun times(o: Pecahan) = dari(n * o.n, d * o.d)
    operator fun div(o: Pecahan) = dari(n * o.d, d * o.n)
    operator fun times(k: Long) = dari(n * k, d)
    fun bagi(k: Long) = dari(n, d * k)
    override fun compareTo(other: Pecahan): Int = (n * other.d).compareTo(other.n * d)
    override fun equals(other: Any?) = other is Pecahan && n == other.n && d == other.d
    override fun hashCode() = (n * 31 + d).hashCode()
    fun nol() = n == 0L
    fun positif() = n > 0L
    fun nilai(): Double = n.toDouble() / d.toDouble()
    override fun toString() = if (d == 1L) n.toString() else "$n/$d"
}

object HitungWaris {
    enum class Ahli {
        SUAMI, ISTRI, ANAK_L, ANAK_P, CUCU_L, CUCU_P, AYAH, IBU, KAKEK, NENEK_IBU, NENEK_AYAH,
        SK_L, SK_P, SA_L, SA_P, SB_L, SB_P
    }
    enum class Dasar { FARDH, ASHABAH, ASHABAH_BERSAMA, FARDH_DAN_ASHABAH, RADD, MUQASAMAH }
    enum class Catatan { AUL, RADD, RADD_PASANGAN, UMARIYATAIN, AKDARIYAH, KAKEK_SAUDARA, TANPA_PENERIMA_SISA, SISA_KERABAT_LAIN }

    data class Masukan(
        val suami: Int = 0, val istri: Int = 0, val anakL: Int = 0, val anakP: Int = 0,
        val cucuL: Int = 0, val cucuP: Int = 0, val ayah: Int = 0, val ibu: Int = 0, val kakek: Int = 0,
        val nenekIbu: Int = 0, val nenekAyah: Int = 0,
        val skL: Int = 0, val skP: Int = 0, val saL: Int = 0, val saP: Int = 0, val sbL: Int = 0, val sbP: Int = 0
    ) {
        fun jumlah(a: Ahli): Int = when (a) {
            Ahli.SUAMI -> suami; Ahli.ISTRI -> istri; Ahli.ANAK_L -> anakL; Ahli.ANAK_P -> anakP
            Ahli.CUCU_L -> cucuL; Ahli.CUCU_P -> cucuP; Ahli.AYAH -> ayah; Ahli.IBU -> ibu; Ahli.KAKEK -> kakek
            Ahli.NENEK_IBU -> nenekIbu; Ahli.NENEK_AYAH -> nenekAyah
            Ahli.SK_L -> skL; Ahli.SK_P -> skP; Ahli.SA_L -> saL; Ahli.SA_P -> saP; Ahli.SB_L -> sbL; Ahli.SB_P -> sbP
        }
        fun adaAhli(): Boolean = Ahli.values().any { jumlah(it) > 0 }
    }

    /** Bagian satu kelompok ahli waris; [total] adalah bagian seluruh kelompok dari harta bersih. */
    data class Bagian(val ahli: Ahli, val jumlah: Int, val total: Pecahan, val dasar: Dasar)
    data class Hasil(val bagian: List<Bagian>, val terhalang: List<Ahli>, val catatan: List<Catatan>, val sisaTakTerbagi: Pecahan)

    private val SEPEREMPAT = Pecahan.dari(1, 4)
    private val SEPERENAM = Pecahan.dari(1, 6)

    fun hitung(m: Masukan): Hasil {
        val fard = LinkedHashMap<Ahli, Pecahan>()      // bagian tetap seluruh kelompok
        val dasar = HashMap<Ahli, Dasar>()
        val ashabah = ArrayList<Pair<String, List<Ahli>>>() // kelompok ashabah berurutan menurut prioritas
        val catatan = LinkedHashSet<Catatan>()

        fun fardhkan(a: Ahli, p: Pecahan, d: Dasar = Dasar.FARDH) { fard[a] = p; dasar[a] = d }

        val anak = m.anakL + m.anakP
        val furu = anak > 0 || m.cucuL + m.cucuP > 0
        val saudaraSemua = m.skL + m.skP + m.saL + m.saP + m.sbL + m.sbP
        val adaAyah = m.ayah > 0
        val spouse = m.suami > 0 || m.istri > 0

        // Hajb cucu dari anak laki-laki.
        val cL = if (m.anakL > 0) 0 else m.cucuL
        val cP = if (m.anakL > 0 || (m.anakP >= 2 && m.cucuL == 0)) 0 else m.cucuP
        val furuLaki = m.anakL > 0 || cL > 0
        val furuPerempuan = m.anakP > 0 || cP > 0

        // Saudara kandung dan seayah terhalang oleh keturunan laki-laki dan ayah.
        val saudaraAktifUmum = !furuLaki && !adaAyah
        val kakekAktif = m.kakek > 0 && !adaAyah
        val skL = if (saudaraAktifUmum) m.skL else 0
        val skP = if (saudaraAktifUmum) m.skP else 0
        val saLNominal = if (saudaraAktifUmum) m.saL else 0
        val saPNominal = if (saudaraAktifUmum) m.saP else 0
        val kakekBersamaSaudara = kakekAktif && (skL + skP + saLNominal + saPNominal) > 0

        // Pasangan.
        if (m.suami > 0) fardhkan(Ahli.SUAMI, if (furu) SEPEREMPAT else Pecahan.dari(1, 2))
        if (m.istri > 0) fardhkan(Ahli.ISTRI, if (furu) Pecahan.dari(1, 8) else SEPEREMPAT)

        // Anak.
        if (m.anakL > 0) ashabah.add("ANAK" to listOf(Ahli.ANAK_L, Ahli.ANAK_P))
        else if (m.anakP == 1) fardhkan(Ahli.ANAK_P, Pecahan.dari(1, 2))
        else if (m.anakP >= 2) fardhkan(Ahli.ANAK_P, Pecahan.dari(2, 3))

        // Cucu dari anak laki-laki.
        if (cL > 0) ashabah.add("CUCU" to listOf(Ahli.CUCU_L, Ahli.CUCU_P))
        else if (cP > 0) {
            when {
                m.anakP == 0 -> fardhkan(Ahli.CUCU_P, if (cP == 1) Pecahan.dari(1, 2) else Pecahan.dari(2, 3))
                m.anakP == 1 -> fardhkan(Ahli.CUCU_P, SEPERENAM)
            }
        }

        // Ayah, atau kakek bila tidak bersama saudara yang berhak.
        val bapak: Ahli? = if (adaAyah) Ahli.AYAH else if (kakekAktif && !kakekBersamaSaudara) Ahli.KAKEK else null
        if (bapak != null) {
            when {
                furuLaki -> fardhkan(bapak, SEPERENAM)
                furuPerempuan -> { fardhkan(bapak, SEPERENAM, Dasar.FARDH_DAN_ASHABAH); ashabah.add("BAPAK" to listOf(bapak)) }
                else -> ashabah.add("BAPAK" to listOf(bapak))
            }
        }

        // Ibu, dengan kasus Umariyatain.
        if (m.ibu > 0) {
            val umariyatain = !furu && saudaraSemua < 2 && adaAyah && spouse
            if (umariyatain) {
                val sisaPasangan = Pecahan.SATU - (fard[Ahli.SUAMI] ?: Pecahan.NOL) - (fard[Ahli.ISTRI] ?: Pecahan.NOL)
                fardhkan(Ahli.IBU, sisaPasangan.bagi(3))
                catatan.add(Catatan.UMARIYATAIN)
            } else {
                fardhkan(Ahli.IBU, if (furu || saudaraSemua >= 2) SEPERENAM else Pecahan.dari(1, 3))
            }
        }

        // Nenek.
        val nenekIbuBerhak = m.nenekIbu > 0 && m.ibu == 0
        val nenekAyahBerhak = m.nenekAyah > 0 && m.ibu == 0 && !adaAyah
        val kelompokNenek = (if (nenekIbuBerhak) 1 else 0) + (if (nenekAyahBerhak) 1 else 0)
        if (kelompokNenek > 0) {
            // Seperenam dibagi rata antara nenek yang berhak.
            val orang = (if (nenekIbuBerhak) 1 else 0) + (if (nenekAyahBerhak) 1 else 0)
            if (nenekIbuBerhak) fardhkan(Ahli.NENEK_IBU, SEPERENAM.bagi(orang.toLong()))
            if (nenekAyahBerhak) fardhkan(Ahli.NENEK_AYAH, SEPERENAM.bagi(orang.toLong()))
        }

        // Saudara seibu terhalang oleh keturunan, ayah, dan kakek.
        val seibuAktif = !furu && !adaAyah && m.kakek == 0
        if (seibuAktif && (m.sbL + m.sbP) > 0) {
            val n = m.sbL + m.sbP
            val total = if (n == 1) SEPERENAM else Pecahan.dari(1, 3)
            // Laki-laki dan perempuan seibu sama bagiannya; simpan per kelompok menurut jumlah orang.
            if (m.sbL > 0) { fard[Ahli.SB_L] = total.times(m.sbL.toLong()).bagi(n.toLong()); dasar[Ahli.SB_L] = Dasar.FARDH }
            if (m.sbP > 0) { fard[Ahli.SB_P] = total.times(m.sbP.toLong()).bagi(n.toLong()); dasar[Ahli.SB_P] = Dasar.FARDH }
        }

        val akdariyah = kakekBersamaSaudara && m.suami == 1 && m.ibu == 1 && m.kakek == 1 &&
            m.anakL + m.anakP + m.cucuL + m.cucuP + m.istri == 0 && skL + saLNominal == 0 && (skP + saPNominal) == 1 &&
            m.nenekIbu + m.nenekAyah == 0

        val bagianLangsung = ArrayList<Bagian>()

        if (akdariyah) {
            catatan.add(Catatan.AKDARIYAH)
            val p27 = { x: Long -> Pecahan.dari(x, 27) }
            bagianLangsung.add(Bagian(Ahli.SUAMI, 1, p27(9), Dasar.FARDH))
            bagianLangsung.add(Bagian(Ahli.IBU, 1, p27(6), Dasar.FARDH))
            bagianLangsung.add(Bagian(Ahli.KAKEK, 1, p27(8), Dasar.MUQASAMAH))
            bagianLangsung.add(Bagian(if (skP == 1) Ahli.SK_P else Ahli.SA_P, 1, p27(4), Dasar.MUQASAMAH))
            return buat(m, bagianLangsung, catatan, Pecahan.NOL)
        }

        // Saudara kandung dan seayah, bila tidak bersama kakek.
        if (!kakekBersamaSaudara && !kakekAktif && saudaraAktifUmum) {
            if (skL > 0) ashabah.add("SK" to listOf(Ahli.SK_L, Ahli.SK_P))
            else if (skP > 0) {
                if (furuPerempuan) ashabah.add("SK_BERSAMA" to listOf(Ahli.SK_P))
                else fardhkan(Ahli.SK_P, if (skP == 1) Pecahan.dari(1, 2) else Pecahan.dari(2, 3))
            }
            val seayahTertutup = skL > 0 || (skP > 0 && furuPerempuan)
            if (!seayahTertutup) {
                if (saLNominal > 0) ashabah.add("SA" to listOf(Ahli.SA_L, Ahli.SA_P))
                else if (saPNominal > 0) {
                    when {
                        skP == 0 && furuPerempuan -> ashabah.add("SA_BERSAMA" to listOf(Ahli.SA_P))
                        skP == 0 -> fardhkan(Ahli.SA_P, if (saPNominal == 1) Pecahan.dari(1, 2) else Pecahan.dari(2, 3))
                        skP == 1 -> fardhkan(Ahli.SA_P, SEPERENAM)
                        // skP >= 2: saudari seayah terhalang kecuali ada saudara seayah laki-laki (sudah ditangani di atas).
                    }
                }
            }
        }

        // Kakek bersama saudara kandung/seayah.
        var kakekTambahan = Pecahan.NOL
        val bagianKakekSaudara = ArrayList<Bagian>()
        if (kakekBersamaSaudara) {
            catatan.add(Catatan.KAKEK_SAUDARA)
            var lain = Pecahan.NOL
            for (v in fard.values) lain = lain + v
            val sisa = Pecahan.SATU - lain
            val unitK = skL.toLong() * 2 + skP
            val unitA = saLNominal.toLong() * 2 + saPNominal
            val unit = unitK + unitA
            val a = SEPERENAM
            val b = if (sisa.positif()) sisa.bagi(3) else Pecahan.NOL
            val c = if (sisa.positif()) sisa * Pecahan.dari(2, 2 + unit) else Pecahan.NOL
            var bagianKakek = a
            var dasarKakek = Dasar.FARDH
            if (b > bagianKakek) { bagianKakek = b; dasarKakek = Dasar.ASHABAH }
            if (c > bagianKakek) { bagianKakek = c; dasarKakek = Dasar.MUQASAMAH }
            if (bagianKakek >= sisa) {
                // Tidak tersisa bagi saudara; kakek memperoleh bagian tetap, minimal seperenam (dapat terkena 'aul).
                fardhkan(Ahli.KAKEK, bagianKakek, Dasar.FARDH)
            } else {
                var sisaSaudara = sisa - bagianKakek
                // Saudara kandung didahulukan; saudari kandung saja dibatasi bagian tetapnya (1/2 atau 2/3).
                val kandungAda = unitK > 0
                var untukKandung = Pecahan.NOL
                var untukSeayah = Pecahan.NOL
                if (kandungAda) {
                    untukKandung = sisaSaudara
                    if (skL == 0 && !furuPerempuan) {
                        val batas = if (skP == 1) Pecahan.dari(1, 2) else Pecahan.dari(2, 3)
                        if (untukKandung > batas) untukKandung = batas
                    }
                    val lebih = sisaSaudara - untukKandung
                    if (lebih.positif()) {
                        if (unitA > 0) { untukSeayah = lebih } else { bagianKakek = bagianKakek + lebih }
                    }
                } else untukSeayah = sisaSaudara
                if (untukSeayah.positif() && saLNominal == 0 && !furuPerempuan) {
                    val batas = if (saPNominal == 1) Pecahan.dari(1, 2) else Pecahan.dari(2, 3)
                    if (untukSeayah > batas) { bagianKakek = bagianKakek + (untukSeayah - batas); untukSeayah = batas }
                }
                bagianKakekSaudara.add(Bagian(Ahli.KAKEK, 1, bagianKakek, dasarKakek))
                fun bagiSaudara(total: Pecahan, l: Ahli, p: Ahli, jl: Int, jp: Int) {
                    val u = jl.toLong() * 2 + jp
                    if (u == 0L || !total.positif()) return
                    if (jl > 0) bagianKakekSaudara.add(Bagian(l, jl, total * Pecahan.dari(jl.toLong() * 2, u), Dasar.ASHABAH_BERSAMA))
                    if (jp > 0) bagianKakekSaudara.add(Bagian(p, jp, total * Pecahan.dari(jp.toLong(), u), Dasar.ASHABAH_BERSAMA))
                }
                bagiSaudara(untukKandung, Ahli.SK_L, Ahli.SK_P, skL, skP)
                bagiSaudara(untukSeayah, Ahli.SA_L, Ahli.SA_P, saLNominal, saPNominal)
            }
        }

        // Jumlahkan bagian tetap; terapkan 'aul bila melebihi satu.
        var totalFard = Pecahan.NOL
        for (v in fard.values) totalFard = totalFard + v
        val ada = ArrayList<Bagian>()
        var sisaSetelah = Pecahan.NOL

        if (kakekBersamaSaudara && bagianKakekSaudara.isNotEmpty()) {
            for ((a, v) in fard) ada.add(Bagian(a, m.jumlah(a), v, dasar[a] ?: Dasar.FARDH))
            ada.addAll(bagianKakekSaudara)
            return buat(m, ada, catatan, Pecahan.NOL)
        }

        if (totalFard > Pecahan.SATU) {
            catatan.add(Catatan.AUL)
            for ((a, v) in fard) ada.add(Bagian(a, m.jumlah(a), v / totalFard, dasar[a] ?: Dasar.FARDH))
            return buat(m, ada, catatan, Pecahan.NOL)
        }

        for ((a, v) in fard) ada.add(Bagian(a, m.jumlah(a), v, dasar[a] ?: Dasar.FARDH))
        val sisa = Pecahan.SATU - totalFard

        if (sisa.positif()) {
            val kelompok = ashabah.firstOrNull()
            if (kelompok != null) {
                val daftar = kelompok.second
                val laki = if (daftar.size == 2) daftar[0] else null
                val perempuan = if (daftar.size == 2) daftar[1] else daftar[0]
                val jl = if (laki != null) hitungJumlah(m, laki, cL, cP, skL, skP, saLNominal, saPNominal) else 0
                val jp = hitungJumlah(m, perempuan, cL, cP, skL, skP, saLNominal, saPNominal)
                if (daftar.size == 1) {
                    // ayah, kakek, atau saudari yang menjadi ashabah bersama keturunan perempuan.
                    val a = daftar[0]
                    val ex = ada.indexOfFirst { it.ahli == a }
                    if (ex >= 0) ada[ex] = ada[ex].copy(total = ada[ex].total + sisa, dasar = Dasar.FARDH_DAN_ASHABAH)
                    else ada.add(Bagian(a, jp, sisa, if (kelompok.first.endsWith("BERSAMA")) Dasar.ASHABAH_BERSAMA else Dasar.ASHABAH))
                } else {
                    val unit = jl.toLong() * 2 + jp
                    if (jl > 0) ada.add(Bagian(laki!!, jl, sisa * Pecahan.dari(jl.toLong() * 2, unit), Dasar.ASHABAH))
                    if (jp > 0) {
                        val ex = ada.indexOfFirst { it.ahli == perempuan }
                        val bagianP = sisa * Pecahan.dari(jp.toLong(), unit)
                        if (ex >= 0) ada[ex] = ada[ex].copy(total = ada[ex].total + bagianP)
                        else ada.add(Bagian(perempuan, jp, bagianP, Dasar.ASHABAH))
                    }
                }
            } else {
                // Radd: sisa dikembalikan kepada penerima bagian tetap selain suami/istri.
                val penerima = ada.filter { it.ahli != Ahli.SUAMI && it.ahli != Ahli.ISTRI && it.total.positif() }
                if (penerima.isNotEmpty()) {
                    var jumlahPenerima = Pecahan.NOL
                    for (b in penerima) jumlahPenerima = jumlahPenerima + b.total
                    var pasangan = Pecahan.NOL
                    for (b in ada) if (b.ahli == Ahli.SUAMI || b.ahli == Ahli.ISTRI) pasangan = pasangan + b.total
                    val untukPenerima = Pecahan.SATU - pasangan
                    for (i in ada.indices) {
                        val b = ada[i]
                        if (b.ahli != Ahli.SUAMI && b.ahli != Ahli.ISTRI && b.total.positif())
                            ada[i] = b.copy(total = b.total / jumlahPenerima * untukPenerima)
                    }
                    catatan.add(Catatan.RADD)
                } else if (ada.isNotEmpty()) {
                    // Hanya pasangan yang ada: sisa dikembalikan kepadanya (pendapat yang dipakai di Indonesia bila tidak ada kerabat lain).
                    for (i in ada.indices) ada[i] = ada[i].copy(total = ada[i].total / totalFard)
                    catatan.add(Catatan.RADD_PASANGAN)
                } else {
                    sisaSetelah = sisa
                    catatan.add(Catatan.TANPA_PENERIMA_SISA)
                }
            }
        }
        return buat(m, ada, catatan, sisaSetelah)
    }

    private fun hitungJumlah(m: Masukan, a: Ahli, cL: Int, cP: Int, skL: Int, skP: Int, saL: Int, saP: Int): Int = when (a) {
        Ahli.ANAK_L -> m.anakL; Ahli.ANAK_P -> m.anakP; Ahli.CUCU_L -> cL; Ahli.CUCU_P -> cP
        Ahli.SK_L -> skL; Ahli.SK_P -> skP; Ahli.SA_L -> saL; Ahli.SA_P -> saP
        else -> m.jumlah(a)
    }

    private fun buat(m: Masukan, b: List<Bagian>, catatan: Set<Catatan>, sisa: Pecahan): Hasil {
        val daftar = urut(b)
        val menerima = daftar.map { it.ahli }.toSet()
        val tertutup = Ahli.values().filter { m.jumlah(it) > 0 && it !in menerima }
        return Hasil(daftar, tertutup, catatan.toList(), sisa)
    }

    private fun urut(b: List<Bagian>): List<Bagian> {
        val urutan = Ahli.values().toList()
        return b.filter { it.jumlah > 0 && it.total.positif() }.sortedBy { urutan.indexOf(it.ahli) }
    }
}
