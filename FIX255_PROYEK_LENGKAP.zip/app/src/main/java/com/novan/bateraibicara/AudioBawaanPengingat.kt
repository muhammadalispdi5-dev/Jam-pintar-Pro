package com.novan.bateraibicara

import android.content.Context

/**
 * FIX238: audio pengingat bawaan aplikasi (res/raw). Untuk Tahajud, berkas res/raw/pemberitahuan_tahajud (mp3/ogg/m4a)
 * dicari saat aplikasi berjalan; bila belum ada, pilihan "suara bawaan aplikasi" tidak ditawarkan dan suara azan/umum dipakai.
 * Cukup menaruh berkasnya di res/raw dengan nama itu agar pilihan otomatis aktif tanpa mengubah kode.
 */
object AudioBawaanPengingat {
    /** ID resource audio bawaan untuk [key] (imsak, terbit, dhuha, tahajud), atau 0 bila tidak ada. */
    fun id(context: Context, key: String): Int = when (key) {
        "imsak" -> R.raw.pemberitahuan_imsak
        "terbit" -> R.raw.pemberitahuan_matahari_terbit
        "dhuha" -> R.raw.pemberitahuan_dhuha
        "tahajud" -> context.resources.getIdentifier("pemberitahuan_tahajud", "raw", context.packageName)
        else -> 0
    }
}
