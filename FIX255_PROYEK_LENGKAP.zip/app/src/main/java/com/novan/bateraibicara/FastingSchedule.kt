package com.novan.bateraibicara

import android.content.Context
import android.icu.util.IslamicCalendar
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Date
import java.util.TimeZone

/** Aturan hari puasa untuk pengingat sahur, Imsak, dan berbuka. */
object FastingSchedule {
    const val NONE = "none"
    const val RAMADAN = "ramadan"
    const val MON_THU = "mon_thu"
    const val DAWUD = "dawud"
    const val SHAWWAL = "shawwal"

    fun isFastingDay(context: Context, date: LocalDate, prefs: PrayerPrefs = PrayerPrefs(context)): Boolean {
        return when (prefs.fastingType) {
            RAMADAN -> hijri(context, date).second == 8
            MON_THU -> date.dayOfWeek.value == 1 || date.dayOfWeek.value == 4
            DAWUD -> {
                val start = runCatching { LocalDate.parse(prefs.dawudStartDate) }.getOrNull() ?: return false
                val distance = ChronoUnit.DAYS.between(start, date)
                distance >= 0 && distance % 2L == 0L
            }
            SHAWWAL -> date.toString() in prefs.shawwalSelectedDates
            else -> false
        }
    }

    /**
     * Tahun Hijriah, bulan 0-based, dan tanggal. FIX216: memakai tabel Hijriah daring bila mode otomatis aktif dan bulannya sudah
     * diunduh (dan memicu pembaruan di latar); bila tidak, hitungan ICU perangkat.
     */
    fun hijri(context: Context, date: LocalDate): Triple<Int, Int, Int> {
        if (!Prefs(context).kalenderHijriAuto) return HijriahDaring.hitungIcu(date)
        HijriahDaring.segarkan(context)
        return HijriahDaring.hijri(context, date)
    }

    fun upcomingShawwalYear(context: Context, today: LocalDate = LocalDate.now()): Int {
        val (year, month, _) = hijri(context, today)
        return if (month <= 9) year else year + 1
    }

    /** Tanggal Masehi untuk tanggal-tanggal Syawal dalam tahun Hijriah yang diminta (FIX216: mengikuti tabel Hijriah daring). */
    fun shawwalDates(context: Context, year: Int): List<Pair<Int, LocalDate>> {
        // Perkiraan awal Syawal dari ICU, lalu cari di sekitarnya dengan sumber yang sama dengan tanggal harian.
        val islamic = IslamicCalendar(Date()).apply {
            clear()
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, 9) // Syawal, bulan ke-10; indeks dimulai dari nol.
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 12)
        }
        val g = Calendar.getInstance(TimeZone.getDefault()).apply { time = islamic.time }
        val perkiraan = LocalDate.of(g.get(Calendar.YEAR), g.get(Calendar.MONTH) + 1, g.get(Calendar.DAY_OF_MONTH))
        val hasil = LinkedHashMap<Int, LocalDate>()
        for (offset in -5L..36L) {
            val tanggal = perkiraan.plusDays(offset)
            val (t, b, h) = hijri(context, tanggal)
            if (t == year && b == 9 && h !in hasil) hasil[h] = tanggal
        }
        return hasil.entries.sortedBy { it.key }.map { it.key to it.value }
    }

    fun typeLabel(type: String, language: Int): String {
        val labels = when (type) {
            RAMADAN -> arrayOf("puasa Ramadan", "Ramadan fasting", "رمضان", "siyam Ramadhan", "puasa Ramadan")
            MON_THU -> arrayOf("puasa sunah Senin dan Kamis", "Monday and Thursday Sunnah fasting", "الاثنين والخميس", "siyam sunah Senen Kemis", "puasa sunat Senén sareng Kemis")
            DAWUD -> arrayOf("puasa sunah Nabi Dawud", "Prophet Dawud's alternating fast", "داود", "siyam sunah Nabi Dawud", "puasa sunat Nabi Dawud")
            SHAWWAL -> arrayOf("puasa sunah Syawal", "Shawwal Sunnah fasting", "شوال", "siyam sunah wulan Syawal", "puasa sunat Syawal")
            else -> arrayOf("puasa", "fasting", "الصيام", "siyam", "puasa")
        }
        return labels[language.coerceIn(0, 4)]
    }

    fun sahurMessage(type: String, minutes: Int, language: Int, test: Boolean = false): String {
        val label = typeLabel(type, language)
        return when (language.coerceIn(0, 4)) {
            1 -> (if (test) "Sahur reminder test for " else "Sahur reminder for ") + label + (". Imsak is in " + (minutes) + " minutes.")
            2 -> (if (test) "اختبار تنبيه السحور لصيام " else "تنبيه السحور لصيام ") + label + (". بقي " + (minutes) + " دقيقة على الإمساك.")
            3 -> (if (test) "Tes pènget wekdal sahur kanggé " else "Pènget wekdal sahur kanggé ") + label + (". Wekdal imsak kirang langkung " + (minutes) + " menit malih.")
            4 -> (if (test) "Tés panginget sahur kanggo " else "Panginget sahur kanggo ") + label + ". Waktos imsak badé lebet " + JamBahasa.sundaKata(minutes) + " menit deui."
            else -> (if (test) "Tes suara pengingat sahur untuk " else "Waktu sahur untuk ") + label + (". Waktu Imsak tinggal " + (minutes) + " menit lagi.")
        }
    }

    fun berbukaMessage(type: String, offset: Int, language: Int, test: Boolean = false): String {
        val label = typeLabel(type, language)
        val timing = when {
            offset < 0 -> if (language == 1) ("" + (-offset) + " minutes before Maghrib") else if (language == 2) ("قبل المغرب بـ " + (-offset) + " دقيقة") else if (language == 3) ("" + (-offset) + " menit sadèrèngipun Maghrib") else if (language == 4) JamBahasa.sundaKata(-offset) + " menit sateuacan Magrib" else ("" + (-offset) + " menit sebelum Maghrib")
            offset > 0 -> if (language == 1) ("" + (offset) + " minutes after Maghrib") else if (language == 2) ("بعد المغرب بـ " + (offset) + " دقيقة") else if (language == 3) ("" + (offset) + " menit sasampunipun Maghrib") else if (language == 4) JamBahasa.sundaKata(offset) + " menit saatos Magrib" else ("" + (offset) + " menit setelah Maghrib")
            else -> if (language == 1) "at Maghrib" else if (language == 2) "عند المغرب" else if (language == 3) "pas wekdal Maghrib" else if (language == 4) "pas waktos Magrib" else "tepat saat Maghrib"
        }
        return when (language.coerceIn(0, 4)) {
            1 -> (if (test) "Iftar reminder test for " else "Iftar reminder for ") + label + (": " + (timing) + ".")
            2 -> (if (test) "اختبار تنبيه الإفطار لصيام " else "تنبيه الإفطار لصيام ") + label + (": " + (timing) + ".")
            3 -> (if (test) "Tes pènget buka puasa kanggé " else "Pènget buka puasa kanggé ") + label + (": " + (timing) + ".")
            4 -> (if (test) "Tés panginget buka puasa kanggo " else "Panginget buka puasa kanggo ") + label + (": " + (timing) + ".")
            else -> (if (test) "Tes pengingat berbuka puasa untuk " else "Pengingat berbuka puasa untuk ") + label + (": " + (timing) + ".")
        }
    }
}
