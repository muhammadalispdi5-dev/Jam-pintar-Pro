
## FIX65 — simbol pada fitur sebut nama pemanggil
- `CallerListener.kt`: fungsi baru `bersihkanSimbolNotif` membuang emoji, tanda arah teks tak terlihat, "~" (kontak WhatsApp tak tersimpan), kurung, bintang, garis bawah, pagar, garis miring, tanda kutip, "&", "@", dan simbol sejenis; tanda baca biasa dan angka dipertahankan. Dipakai pada nama pemanggil, nama pengirim pesan, nama grup, isi pesan, serta judul/isi notifikasi aplikasi lain, sehingga teks yang tampil dan yang dibacakan sama-sama bersih. Nomor tanpa nama tetap dibaca angka demi angka. Bila nama hanya berisi simbol, dipakai "Pengirim tidak diketahui" / "grup tidak diketahui".
- `PemanggilActivity.kt`: "app(s)" menjadi "apps"; keterangan "(tidak terpasang)" pada daftar aplikasi menjadi ", tidak terpasang".
- Belum dikompilasi/diuji di perangkat. Sumber simbol yang saya tebak adalah isi notifikasi (nama, grup, pesan); bila simbol yang mengganggu ada di tempat lain, kirim contoh teks persisnya.
