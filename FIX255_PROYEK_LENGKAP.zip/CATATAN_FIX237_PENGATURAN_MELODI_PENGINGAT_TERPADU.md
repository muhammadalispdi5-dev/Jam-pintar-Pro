# FIX237 — Satu Pengaturan Melodi Pengingat

## Perubahan
- Semua pilihan melodi pengingat kini dikumpulkan di satu halaman baru: **Pengaturan Melodi Pengingat** (menu Pengaturan Jadwal Sholat dan Pengingat, tepat setelah "Pengingat sebelum sholat").
- Urutan di halaman itu: sahur, berbuka, sebelum Subuh, sebelum Dzuhur, sebelum Ashar, sebelum Maghrib, sebelum Isya, Imsak, Matahari terbit, Dhuha, Tahajud. Tiap pengingat punya dua tombol: melodi sebelum suara dan melodi setelah suara.
- Tombol melodi dihapus dari tiga tempat lama (Pengingat waktu sholat, Pengingat Waktu Sahur dan Berbuka, Pengingat sebelum sholat). Sakelar, waktu, jenis puasa, dan jenis suara di tempat-tempat itu tidak berubah.
- Cara kerja pemilih tidak berubah: daftar tetap terbuka saat pratinjau, Simpan menerapkan, Batal mempertahankan pilihan lama.
- Preferensi tersimpan, penjadwalan, dan pemutaran di PrayerAlarmService tidak diubah, jadi pilihan melodi yang sudah dibuat pengguna tetap terbawa.
- Teks halaman baru memakai tr(id, en) sehingga mengikuti bahasa aktif. Pemeriksa bahasa aktif kini lulus (sebelumnya berkas ini melebihi batas baseline).
- Versi tetap 1.0.86 (versionCode 86).

## Pemeriksaan
- periksa_resource_strings, periksa_const_val, periksa_bahasa_aktif, periksa_bentrok_anggota_halaman: LULUS.
- Pemeriksaan sintaks Kotlin dilakukan; Gradle belum dijalankan dan belum diuji di perangkat.

## Uji yang disarankan
1. Buka Pengaturan Jadwal Sholat dan Pengingat, pilih Pengaturan Melodi Pengingat; pastikan 11 pengingat tampil berurutan.
2. Ubah melodi tiap kelompok, Simpan, lalu buka kembali; label menampilkan pilihan baru.
3. Pastikan halaman Pengingat waktu sholat, Sahur dan Berbuka, serta Pengingat sebelum sholat tidak lagi memuat tombol melodi.
4. Uji pengingat sahur, berbuka, sebelum salat, dan Imsak/terbit/Dhuha/Tahajud: melodi awal, suara, melodi akhir.
5. Uji bahasa Indonesia dan Inggris.
