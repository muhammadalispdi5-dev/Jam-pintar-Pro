# FIX76 — Tombol volume menghentikan semua suara notifikasi aplikasi

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX75. Berkas diubah: `PembungkamTelungkup.kt`, `Halaman.kt`, `PrayerPrefs.kt`, `PrayerSettingsActivity.kt`, `JamActivity.kt`, `BahasaAplikasi.kt`.

## Fitur
Selama ada suara notifikasi aplikasi yang berbunyi (azan, pengingat salat, alarm jam, pengumuman baterai dan jam, nama pemanggil, notifikasi Khatam), menekan **volume atas atau volume bawah** menghentikannya. Jalurnya sama dengan fitur telungkup (FIX74), yaitu pusat `PembungkamTelungkup`, sehingga semua sumber yang sudah terdaftar otomatis ikut berhenti: nada, ucapan, getar, penahan CPU, dan layanannya.

## Cara kerja
- **Aplikasi terbuka** (halaman mana pun): `Halaman.dispatchKeyEvent` menangkap tombol volume. Suara berhenti dan volume tidak berubah. Tekan-tahan tidak diteruskan ke pengatur volume.
- **Aplikasi di latar belakang atau layar mati**: selama ada sumber suara terdaftar, aplikasi mendengarkan siaran sistem `VOLUME_CHANGED_ACTION`. Begitu volume berubah, suara dihentikan dan volume dikembalikan ke nilai sebelum tombol ditekan, supaya alarm berikutnya tidak menjadi lebih pelan.
- Tidak ada suara aplikasi yang berbunyi: tombol volume bekerja seperti biasa. Tes suara di pengaturan tidak terdaftar sehingga tidak terpengaruh.
- Sakelar baru **"Hentikan azan dan semua suara notifikasi dengan tombol volume"** (bawaan aktif) di Pengaturan Sholat > Suara, dan **"Hentikan alarm dengan tombol volume"** di Jam > Alarm jam. Keduanya satu pengaturan (`stop_dengan_volume`). Sakelar telungkup tetap terpisah; salah satu cukup untuk mendaftarkan suara, dan sensor gerak hanya menyala bila telungkup aktif.

## Batas yang perlu diketahui
- Jalur latar belakang memakai siaran sistem yang tidak terdokumentasi resmi. Pada versi Android atau merek HP tertentu siaran ini bisa tidak terkirim, dan pada volume yang sudah di batas atas, menekan volume atas tidak mengubah volume sehingga tidak terbaca. Bila itu terjadi, tekan volume bawah atau gunakan tombol Matikan pada notifikasi atau telungkup.
- Saat layar mati sebagian merek HP tidak mengubah volume saat tombol ditekan; pada kasus itu jalur latar belakang tidak terpicu.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: alarm jam saat aplikasi terbuka, saat di layar utama, dan saat layar mati; azan; Android 13 ke atas.

## Pemeriksaan
- Kurung `{}` `()` `[]` seimbang di semua berkas yang diubah; `verify_project.py` dijalankan.
