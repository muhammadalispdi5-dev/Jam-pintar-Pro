# FIX105 - Muraja'ah cerdas + aturan tetap bahasa aktif
Berkas diubah: HafalanSrs.kt, KhatamActivity.kt. Berkas baru: ATURAN_BAHASA_AKTIF.md, tools/periksa_bahasa_aktif.py,
tools/baseline_bahasa_aktif.json, tools/uji_murajaah_cerdas.py. Diubah: tools/verify_project.py (memanggil pemeriksa bahasa; ikut berjalan di build.yml dan rilis.yml).

## Muraja'ah cerdas (sesi ulasan terpandu di atas pengulangan berjarak FIX103)
- Antrean cerdas: ayat jatuh tempo diurutkan menurut keterdesakan (terlambat x3 + sering salah x2 + tingkat rendah), dibatasi ukuran sesi (5/10/20, bawaan 10). Bila sesi belum penuh dan "Penguatan ayat lemah" aktif (bawaan aktif), ditambah ayat yang pernah salah (tingkat 0-2) yang belum jatuh tempo, ditandai "penguatan".
- Penilaian tiga tingkat: Lancar (tingkat naik, jarak melebar), Ragu-ragu (tingkat tetap, jarak dipendekkan setengah, minimal 1 hari), Lupa (tingkat 0, ulas besok).
  - Koreksi suara: benar pada percobaan pertama = Lancar; benar setelah gagal pada ayat yang sama = Ragu-ragu; ada selisih = Lupa. (Berlaku juga di luar sesi.)
  - Latihan tanpa mikrofon dalam sesi: dialog tiga pilihan + "Ulangi latihan ayat ini".
- Alur sesi: pilih cara (suara/tanpa mikrofon; hanya yang aktif dan tersedia) > tiap ayat dinilai > dialog "Ayat berikutnya / Akhiri sesi" dengan komentar hasil > ringkasan akhir (lancar/ragu/lupa, ayat perlu perhatian, sisa jatuh tempo hari ini, jatuh tempo besok, rangkaian hari beruntun). Ayat yang ditutup tanpa nilai: Coba lagi / Lewati / Akhiri.
- Posisi bacaan terakhir pengguna dipulihkan setelah sesi; menu disegarkan agar hitungan ayat mutakhir. Pembaca kini digambar ulang saat ayat ulasan berganti (perlu untuk sesi berurutan).
- Pintu masuk: tombol menu Khatam "Muraja'ah cerdas (N ayat)" (tampil bila ada antrean), butir pertama pada "Ulas hafalan hari ini", dan Pengaturan Hafalan > "Muraja'ah cerdas" (ukuran sesi, penguatan, mulai sekarang). Kunci pengaturan ikut direset; riwayat/rangkaian tidak dihapus.
- Kunci baru: murajaah_ukuran_sesi, murajaah_penguatan_aktif, murajaah_hari_terakhir, murajaah_rangkaian, murajaah_total_sesi.

## Bahasa aktif
Seluruh teks FIX105 (dialog, tombol, toast, contentDescription, ringkasan) memakai tr(id, en) dan mengikuti BahasaAplikasi.tampilan. Aturan ini kini tetap dan ditegakkan otomatis: lihat ATURAN_BAHASA_AKTIF.md. Pemeriksa (tools/periksa_bahasa_aktif.py) membandingkan kunci strings.xml dua bahasa dan menghitung teks Indonesia yang tidak dibungkus terhadap baseline (hanya boleh turun). Hasil: LULUS, nol teks baru tanpa padanan.

## Pemeriksaan
- tools/verify_project.py: LULUS (termasuk pemeriksa bahasa aktif). tools/uji_murajaah_cerdas.py: LULUS (port Python logika + kontrak sumber). Keseimbangan kurung Kotlin: sesuai.
- BELUM dikompilasi (Gradle/kotlinc tidak tersedia di lingkungan ini) dan BELUM diuji di perangkat. Jalankan GitHub Actions, lalu uji sesi di HP dalam bahasa Indonesia dan English, dengan dan tanpa TalkBack.
- Pemeriksa bahasa bersifat heuristik; tiga literal lama di KhatamActivity (deskripsi qari) tetap tercatat di baseline karena diterjemahkan lewat fungsi pengganti, bukan tr().
