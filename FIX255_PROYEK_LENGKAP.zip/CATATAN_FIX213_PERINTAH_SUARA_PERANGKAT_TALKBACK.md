# FIX213: perintah suara untuk perangkat, TalkBack, dan mesin suara TalkBack

Sudah ada sebelumnya (FIX138): aktifkan/matikan Bluetooth, Wi-Fi, hotspot seluler, data seluler, mode pesawat, NFC, lokasi (lewat layanan aksesibilitas).
Baru (PerintahSuaraActivity.kt):
1. "ubah / ganti / alihkan / toggle / switch / change" + nama perangkat tanpa kata hidup/mati: status dibaca dulu lalu dibalik.
   Status dibaca dari Settings.Global (Wi-Fi, Bluetooth, data seluler, mode pesawat), LocationManager, NfcAdapter, dan refleksi (hotspot).
   Bila status tidak terbaca, asisten meminta pengguna mengucapkan "aktifkan" atau "matikan".
2. TalkBack: "aktifkan / matikan TalkBack". Dengan izin WRITE_SECURE_SETTINGS (diberikan sekali lewat ADB:
   `adb shell pm grant com.novan.bateraibicara android.permission.WRITE_SECURE_SETTINGS`) TalkBack dihidupkan/dimatikan langsung.
   Tanpa izin itu, halaman Aksesibilitas Android dibuka dan pengguna diberi tahu (Android melarang aplikasi biasa mengubahnya).
3. Mesin suara TalkBack: "ganti mesin suara utama TalkBack ke Google / Samsung / eSpeak". Dengan izin yang sama, mesin TTS bawaan sistem diganti
   langsung (TalkBack mengikutinya bila pilihan mesinnya "bawaan sistem"). Tanpa izin atau tanpa menyebut nama mesin, pengaturan Teks-ke-ucapan dibuka
   dan daftar mesin terpasang disebutkan.
Manifest: izin WRITE_SECURE_SETTINGS dideklarasikan. Teks petunjuk dan pesan "perangkat tidak dikenal" diperbarui (Indonesia dan English).
Belum dikompilasi dan belum diuji di perangkat.
