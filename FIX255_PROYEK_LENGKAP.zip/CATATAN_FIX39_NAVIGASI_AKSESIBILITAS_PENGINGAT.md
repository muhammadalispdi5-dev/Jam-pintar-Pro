# FIX39 — Navigasi konsisten dan pengaturan pengingat khatam

## Perubahan
- Menambahkan tombol **Kembali ke halaman sebelumnya** sebagai kontrol pertama pada setiap halaman fitur yang mewarisi `Halaman`; halaman utama tidak menampilkan tombol kembali.
- Tombol kembali ditempatkan sebelum judul dan isi halaman sehingga menjadi elemen pertama pada urutan fokus TalkBack.
- Pada pembaca Al-Qur'an, tombol kembali ke menu Khatam dipindahkan ke bagian paling atas. Tombol Back Android saat pembaca terbuka juga kembali ke menu Khatam; dari menu Khatam Back kembali ke halaman sebelumnya.
- Menghapus tombol pengingat terpisah dari menu utama Khatam.
- Memindahkan **Pengingat membaca dan hafalan** ke dalam **Pengaturan audio dan mode hafalan**.
- Setelah memilih pengaturan audio (qari, mode hafalan, pengulangan, kecepatan, jeda, target pemutaran, atau pengingat), daftar pengaturan audio ditampilkan kembali. Tombol kembali pada submenu juga membawa pengguna ke daftar pengaturan audio.
- Menghapus tombol Tutup dari daftar utama pengaturan audio; navigasi dilakukan dengan Back Android atau kontrol kembali yang disediakan.

## Batasan dan pengujian
- Versi tetap `1.0.69`, `versionCode 69`.
- Pemeriksaan statis proyek dan pemeriksaan ZIP dapat dilakukan; kompilasi Gradle penuh dan uji TalkBack pada perangkat belum dijalankan di lingkungan ini.
- `BeritahuSayaActivity` merupakan aktivitas transparan pemicu widget tanpa antarmuka, sehingga tidak diberi tombol navigasi visual.
