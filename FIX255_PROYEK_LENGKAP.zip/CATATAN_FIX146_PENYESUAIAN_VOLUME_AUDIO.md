# FIX146 — Penyesuaian Volume Seluruh Audio Aplikasi

Perbaikan berdasarkan FIX145.

## Perubahan
- Keluaran TTS diberi parameter volume digital normal 1.0 tanpa mengubah volume sistem Android.
- Permintaan fokus audio TTS diubah dari `AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK` menjadi `AUDIOFOCUS_GAIN_TRANSIENT`, sehingga audio aplikasi lain tidak sengaja tertahan pada volume ducking saat asisten berbicara.
- Pemutar audio Al-Qur'an mengatur keluaran Stereo/Mono ke level digital normal saat mulai.
- Jalur AudioTrack Mono secara eksplisit memakai gain 1.0 agar seimbang dengan MediaPlayer Stereo.
- Penanganan fokus layanan audio tidak lagi meninggalkan pemutar pada 30% ketika menerima permintaan ducking.
- Tidak ada perubahan pada volume media sistem, pengaturan volume pengguna, pilihan mesin TTS, bahasa, fitur salam, mode hafalan, atau fitur aplikasi lainnya.

## Catatan pengujian
Arsip diperiksa integritasnya. Kompilasi Gradle dan uji suara langsung pada perangkat belum dilakukan di lingkungan ini. Level 1.0 adalah gain digital normal, bukan penguat di atas batas normal; hasil akhir tetap dipengaruhi volume media perangkat, profil TTS, speaker, dan pengaturan efek audio.
