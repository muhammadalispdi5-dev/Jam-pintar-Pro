# FIX240 — Tambahan doa harian dan pelengkapan petunjuk penggunaan

## Doa sehari-hari: 159 menjadi 184 doa, 19 kelompok
Kelompok baru: **Haji, Umrah, dan Kurban**. Doa baru (semua bersumber Al-Qur’an atau hadits, derajat dicantumkan pada tiap doa):
- Shalat: Ayat Kursi setelah shalat wajib; doa rukuk (Muslim); doa sujud "sajada wajhi" (Muslim).
- Ibadah malam: doa membuka shalat malam (Rabb Jibril, Mikail, Israfil; Muslim); doa tahajud "Engkau Penegak langit dan bumi" (Bukhari dan Muslim).
- Kesulitan: doa memohon kemudahan "la sahla illa ma ja’altahu sahla" (Ibnu Hibban); Al-Baqarah 250.
- Permohonan umum dari Al-Qur’an: Ali ‘Imran 8; penutup Al-Baqarah 286; Al-Kahfi 10; Al-Qashash 24; Yusuf 101.
- Keluarga: Nuh 71:28. Perjalanan: Al-Mu’minun 29; Al-Isra’ 80. Taubat: Ali ‘Imran 147. Perlindungan: Al-Mu’minun 97-98. Syukur: Al-Baqarah 127.
- Alam: ketika ayam berkokok dan keledai meringkik (Bukhari dan Muslim). Pergaulan: "Ma sya’allah la quwwata illa billah" (Al-Kahfi 39).
- Haji, Umrah, Kurban: talbiyah (Bukhari dan Muslim); doa antara Rukun Yamani dan Hajar Aswad (Abu Dawud, hasan); dzikir di Shafa dan Marwah (Muslim); doa hari Arafah (At-Tirmidzi, hasan); doa Nabi ketika menyembelih kurban (Muslim).
Doa yang kurang saya yakini sumber atau derajatnya sengaja tidak dimasukkan. Disarankan seorang ustadz memeriksa kembali teks Arabnya sebelum rilis final.
Perintah suara: kata topik baru (haji, umrah, talbiyah, arafah, kurban, sembelih, thawaf, shafa, marwah, ayam, keledai, tahajud, kemudahan, dan padanan Inggris hajj/sacrifice/pilgrimage) sehingga "doa tahajud", "doa talbiyah", "doa di hari Arafah", "doa menyembelih kurban" langsung membuka doanya. Perintah lama tetap lulus uji.

## Petunjuk penggunaan (Indonesia dan English)
Ditambahkan butir 23-28 (Indonesia) dan 20-25 (English) yang mencakup: pengingat sahur/Imsak/berbuka/Matahari terbit/Dhuha/Tahajud beserta pilihan jenis suara; Pengaturan Melodi Pengingat terpadu; menghentikan suara dengan menelungkupkan HP atau tombol volume dan Penghemat daya; Kitab Hadits, Khutbah Jumat, dan Manasik Haji; putar Al-Qur’an per halaman dengan jumlah ulangan; serta Doa Sehari-hari dan perintah suaranya. Butir lama diperbarui (jumlah doa, contoh perintah halaman). Penomoran butir English yang sebelumnya melompat (16 ke 20) dirapikan menjadi berurutan.
Butir lama tentang pemicu asisten suara (butir 20 Indonesia), Khatam, hafalan, zakat, waris, bahasa, dan cadangan sudah sesuai dan tidak diubah.

## Pemeriksaan
- Empat pemeriksa proyek dan tiga skrip uji: LULUS. Uji kotlinc pada data doa (nama unik, kategori valid, 184 doa, 19 kelompok, 41 ucapan suara) dan pada penafsir perintah halaman (satu/dua/tiga/sepuluh kali, tanpa batas, English) lulus.
- Gradle belum dijalankan; belum diuji di perangkat. Versi tetap 1.0.87.
