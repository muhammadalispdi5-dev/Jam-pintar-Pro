# FIX87 — Perintah suara dari layar depan tidak membawa pengguna masuk ke aplikasi

Versi tetap **1.0.69**. Basis: FIX86.

## Masalah
Perintah suara "Beritahu Saya" dari layar depan (widget, ikon, pintasan) memang terbuka di luar aplikasi (layar pengenalan suara sistem).
Perintah waktu/tanggal juga selesai di luar aplikasi. Tetapi perintah memutar Al-Qur'an ("putar surah Yasin") membuka layar Khatam
dan pengguna tertinggal di dalam aplikasi.

## Perbaikan
- Perintah putar dari luar aplikasi kini dijalankan Khatam lalu **Khatam langsung dikembalikan ke belakang** (`moveTaskToBack`),
  sehingga pengguna kembali ke layar depan sementara audio terus diputar. Animasi peralihan dimatikan; tunda pemrosesan dipersingkat (150 md).
- Konfirmasi perintah ("Perintah suara: putar surah ...") tetap muncul sebagai toast di layar depan sehingga terbaca TalkBack.
- Kasus yang dulu membuka dialog di dalam aplikasi kini berupa toast, lalu kembali ke layar depan:
  teks Al-Qur'an belum diunduh, saklar "Perintah suara untuk memutar" mati, perintah tidak dikenali / nomor tidak sah.
- Layanan baru **`AudioLatarService`** (latar depan, notifikasi senyap): menjaga proses aplikasi tetap hidup selama audio berbunyi dari latar belakang,
  berhenti sendiri saat audio selesai, dan notifikasinya punya tombol **Hentikan audio**. Mengetuk notifikasi membuka Khatam.
- Bila perintah suara dibuka dari **dalam** aplikasi (ketuk tahan saklar pemicu di halaman utama; tombol suara di dalam Khatam),
  perilaku lama dipertahankan: pengguna tetap di Khatam (`EXTRA_DARI_APLIKASI`).

## Berkas
- Baru: AudioLatarService.kt.
- Ubah: KhatamActivity.kt (jalankanPerintahDariLuar, kembaliKeLayarDepan, companion), PerintahSuaraActivity.kt, MainActivity.kt, AndroidManifest.xml.

## Batasan
- Khatam masih harus dibuat sesaat (sekitar sepertiga detik hingga satu detik) sebelum dikembalikan; pada HP lambat layar Khatam bisa berkedip singkat dan
  TalkBack dapat menyebut nama layar sekilas. Pemutaran tanpa membuka layar sama sekali menuntut pemutar audio dipindah ke layanan penuh (perubahan besar).
- Status audio yang biasanya diumumkan di layar Khatam tidak terdengar saat di latar belakang; yang terdengar adalah toast konfirmasi dan audionya.
- Belum dikompilasi/diuji (tidak ada kompiler di lingkungan kerja); kurung seimbang dan XML manifest valid.
