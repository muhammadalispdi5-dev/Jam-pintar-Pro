# FIX56 — Katalog "Qari anak (pilihan terbaik)"

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX55. Perubahan: `KhatamActivity.kt`.

## Fitur
- Pengaturan Khatam > Pengaturan pemutaran audio > Pilih suara qari kini punya tiga katalog; yang pertama **Qari anak (pilihan terbaik)**, lalu qari per ayat/juz, lalu qari per surah.
- Isi katalog anak diambil dari katalog MP3Quran yang dimuat aplikasi, dicocokkan dengan nama, dan diurutkan dari yang paling dikenal:
  1. Muhammad Taha Al-Junayd
  2. Ahmad Saud
  3. Junaid Adam
  Hanya qari yang benar-benar ada di katalog yang tampil, sehingga tidak ada tautan audio mati.
- Pencocokan nama dibuat longgar terhadap variasi ejaan Latin dan Arab (Junaid/Junayd/Junaed, Ahmad/Ahmed Saud/Saoud).

## Batasan yang perlu diketahui
- Qari anak di MP3Quran tersedia sebagai audio **per surah**, bukan per ayat. Untuk audio per ayat dan mode hafalan per ayat, pakai qari dari katalog per ayat. Setelah memilih qari anak, status audio mengingatkan agar Cara pemutaran diatur ke "Per surah".
- Katalog dimuat dari internet saat Pilih suara qari dibuka. Bila gagal dimuat, muncul pesan agar memeriksa koneksi lalu membuka pilihan itu lagi.
- Kata "terbaik" bersifat subjektif; urutan mengikuti popularitas dan jumlah rekaman, bukan penilaian kualitas bacaan.

## Pemeriksaan
- Tanda kurung Kotlin seimbang; `verify_project.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: buka katalog Qari anak, pilih satu qari, putar satu surah.
