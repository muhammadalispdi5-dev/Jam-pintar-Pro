# FIX103 - Pengingat cerdas hafalan (pengulangan berjarak)
Berkas baru: HafalanSrs.kt (data + logika + alarm), HafalanSrsReceiver.kt (notifikasi (nama surah ditulis langsung, bukan nomor)). Diubah: KhatamActivity.kt, KhatamReminderBootReceiver.kt (jadwal ulang saat boot), AndroidManifest.xml (receiver).

Cara kerja
- Tiap ayat yang dilatih dicatat dengan tingkat 0..6. Benar: jatuh tempo berikutnya = 1, 2, 4, 7, 14, 30, 60 hari sesuai tingkat, lalu tingkat naik. Salah: tingkat 0, salah+1, ulas besok.
- Pencatatan otomatis dari: Koreksi otomatis dengan pengenalan suara (cocok = benar, ada selisih = salah; hasil kosong tidak dicatat) dan Latihan tanpa mikrofon ("Sudah sesuai"/"Perlu diulang"). Ayat juga dapat ditambah/dihapus manual.
- Pengingat harian (bawaan nonaktif, bawaan pukul 19.30) hanya muncul bila ada ayat jatuh tempo; isinya "N ayat perlu diulang: Nama surah ayat N, ..." dan menyebut keterlambatan bila >= 3 hari. Urutan: paling terlambat, lalu paling sering salah. Mengetuk notifikasi (nama surah ditulis langsung, bukan nomor) membuka daftar ulasan.
- Halaman utama Khatam: tombol "Ulas hafalan hari ini (N ayat)" tampil bila ada ayat jatuh tempo. Memilih ayat lalu memilih Koreksi suara atau Latihan mandiri (sesuai saklar yang aktif). Membuka pembaca menyimpan ayat itu sebagai posisi bacaan terakhir.
- Pengaturan: Pengaturan Khatam > Pengaturan Hafalan > Pengingat cerdas hafalan (aktif/nonaktif, waktu, ulas, tambah/hapus ayat terakhir, kosongkan daftar). Reset pengaturan Khatam mengembalikan saklar dan waktu pengingat, tetapi tidak menghapus daftar/riwayat.
- Alarm tidak persis (setInexactRepeating), jadi bisa bergeser beberapa menit; dijadwalkan ulang setelah boot/pembaruan aplikasi.
Belum dikompilasi/diuji.

## Revisi: nama surah
Notifikasi dan daftar ulasan menulis nama surah langsung (mis. "Al-Baqarah ayat 255", "Yasin ayat 5"). Nama (transliterasi Latin, 114 surah) tersimpan di HafalanSrs.NAMA_SURAH sehingga tersedia tanpa memuat teks Al-Qur'an.
