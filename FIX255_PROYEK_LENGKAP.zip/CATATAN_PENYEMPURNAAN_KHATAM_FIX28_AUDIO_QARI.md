# Penyempurnaan Khatam Al-Qur'an — FIX28 Audio dan Pilihan Qari

Versi aplikasi dipertahankan pada 1.0.69 (`versionCode 69`, `versionName 1.0.69`). Perubahan utama ada pada `KhatamActivity.kt`.

## Fitur audio yang ditambahkan/diperbaiki
- Pilihan qari tersendiri, tersedia 9 pilihan: Mishary Rashid Alafasy, Mahmoud Khalil Al-Husary, Mohamed Siddiq Al-Minshawi, Abdurrahman As-Sudais, Saud Al-Shuraim, Abdul Basit Abdus Samad, Ahmed ibn Ali Al-Ajamy, Muhammad Ayyoub, dan Ali Al-Hudhaify.
- Qari terakhir disimpan pada perangkat dan tetap terpilih ketika halaman/aplikasi dibuka kembali.
- Tombol untuk memutar audio ayat yang sedang dibaca.
- Tombol untuk memutar audio seluruh surah.
- Tombol jeda/lanjutkan dan hentikan audio.
- Status pemutaran dibacakan/dapat dibaca pembaca layar; pesan kesalahan menjelaskan agar memeriksa internet atau mencoba qari lain.
- Bila host audio utama gagal, aplikasi mencoba host cadangan sebelum menyatakan gagal.
- Saat berpindah ayat/surah atau meninggalkan pembaca, audio yang sedang berjalan dihentikan untuk mencegah suara lama terus berjalan.
- Label tombol audio ayat dan audio surah dibedakan supaya TalkBack tidak membingungkan pengguna.

## Sumber dan keterbatasan
Audio menggunakan streaming HTTPS dari Al Quran Cloud CDN. Referensi pola audio ayat dan surah serta identifier qari: https://alquran.cloud/cdn. Karena streaming, koneksi internet diperlukan. Berkas audio tidak dimasukkan ke APK dan tidak tersedia offline pada tahap ini.

## Pemeriksaan
Jalankan `python3 tools/verify_project.py` dan workflow GitHub Actions `Bangun APK`. Pemeriksaan lokal bersifat statis; kompilasi Android dan uji audio nyata di ponsel belum dapat dinyatakan berhasil sampai workflow dan perangkat benar-benar diuji.
