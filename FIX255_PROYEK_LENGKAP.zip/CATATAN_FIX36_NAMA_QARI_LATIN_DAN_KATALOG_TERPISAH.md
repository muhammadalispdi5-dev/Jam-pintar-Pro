# FIX36 — Nama Qari Latin dan Katalog Audio Terpisah

Versi aplikasi dipertahankan: `versionCode 69`, `versionName 1.0.69`.

## Perubahan
- Daftar qari audio per ayat/juz tetap berisi edisi `versebyverse`.
- Katalog MP3Quran yang menyediakan rekaman per surah dipisahkan ke daftar tersendiri; tidak lagi bercampur dengan daftar qari per ayat.
- Dialog pemilihan qari terlebih dahulu meminta pengguna memilih jenis katalog: audio per ayat/juz atau audio per surah. Nama kategori dan qari menggunakan huruf Latin.
- Permintaan katalog MP3Quran menggunakan `language=eng`; bila layanan tetap mengembalikan nama Arab, beberapa nama populer dipetakan ke ejaan Latin dan fallback menghindari pembacaan aksara Arab.
- Pemutaran yang sudah ada tetap mengikuti kapabilitas qari: MP3Quran untuk surah penuh; edisi verse-by-verse untuk ayat dan juz.

## Pemeriksaan
- `tools/verify_project.py`: lulus.
- Pemeriksaan parser `kotlinc` tanpa Android classpath: tidak menemukan pesan kesalahan sintaks; unresolved references Android/project memang diharapkan tanpa classpath Gradle.
- ZIP: diperiksa dengan `unzip -t`.
- Belum menjalankan build APK Gradle penuh atau uji TalkBack/perangkat. Keberhasilan kompilasi dan hasil TTS perlu dikonfirmasi di workflow Android.
