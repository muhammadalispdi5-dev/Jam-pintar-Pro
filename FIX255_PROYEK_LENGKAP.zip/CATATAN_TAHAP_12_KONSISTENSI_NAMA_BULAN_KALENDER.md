Tahap 12 — Konsistensi nama bulan pada ucapan kalender

Perubahan:
- Ucapan tanggal Hijriah kini memilih nama bulan sesuai bahasa ucapan: Indonesia, Inggris, Arab, Jawa, atau Sunda.
- Ucapan tanggal Masehi berbahasa Jawa memakai ejaan nama bulan Jawa/serapan Jawa dan perumusan yang diselaraskan.
- Pengaturan bahasa ucapan tetap terpisah dari bahasa tampilan.
- Versi aplikasi dipertahankan pada 1.0.68 / versionCode 68.

Pemeriksaan:
- Perubahan sumber dilakukan pada KalenderTanggal.kt.
- Arsip ZIP diperiksa integritasnya setelah dibuat.
- Build Android penuh dan uji TTS di perangkat belum dilakukan; hasil kompilasi tidak diklaim.
