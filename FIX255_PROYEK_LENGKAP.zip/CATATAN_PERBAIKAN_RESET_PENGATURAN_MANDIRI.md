# Perbaikan tombol reset pengaturan mandiri

- Khatam Al-Qur'an: tombol reset hanya menghapus preferensi pengaturan khatam, latihan, audio, target, dan pengingat. Posisi bacaan/kemajuan serta cache katalog qari tetap dipertahankan.
- Jadwal salat: reset mengembalikan preferensi jadwal dan pengingat ke nilai bawaan, menjadwalkan ulang alarm, dan mempertahankan lokasi/koordinat yang sudah dipilih.
- Nama pemanggil dan notifikasi: reset hanya menghapus kunci preferensi yang dimiliki fitur pemanggil/notifikasi, termasuk pola pesan, pilihan aplikasi, pengulangan, dan profil suara pemanggil.
- Baterai: reset hanya menghapus preferensi fitur baterai dan kalimat pengumuman baterai, lalu memuat ulang layanan.
- Jam dan alarm: reset hanya menghapus preferensi jam, membatalkan alarm dan tunda yang terjadwal, menghapus daftar alarm buatan pengguna, lalu memperbarui penjadwalan.
- Tidak menambahkan tombol reset pada bahasa, lokasi terkini, atau pemandu jalan.
- Label tombol, dialog konfirmasi, dan hasil reset menggunakan mekanisme lokalisasi aktif aplikasi; padanan bahasa Inggris ditambahkan ke kamus aplikasi.

Reset memerlukan konfirmasi dan tidak menyentuh pengaturan fitur lain.
