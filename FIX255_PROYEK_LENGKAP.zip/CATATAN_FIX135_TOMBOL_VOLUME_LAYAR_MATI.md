# FIX135 — Tombol volume menghentikan suara notifikasi saat layar mati

Versi aplikasi tidak diubah. Basis: FIX134. Berkas diubah: `PembungkamTelungkup.kt`.

## Gejala
Tombol volume menghentikan suara notifikasi saat layar menyala, tetapi tidak saat layar mati.

## Penyebab (dari pembacaan kode dan perilaku Android; belum ada log, belum diuji di perangkat)
Saat layar mati, Android hanya meneruskan tombol volume ke pengatur volume bila ada pemutaran aktif di saluran media. Pemantau volume
aplikasi (siaran `VOLUME_CHANGED_ACTION` dan pembacaan berkala FIX124) hanya bereaksi bila sebuah nilai volume berubah. Suara notifikasi
yang memakai saluran lain (alarm, notifikasi, aksesibilitas, dering, dan seterusnya, sesuai pilihan "keluaran suara") tidak membuat
saluran media aktif, sehingga tombol tidak mengubah volume apa pun dan tidak ada yang terdeteksi. Saat layar menyala, tombol
sampai lewat jalur layar.

## Perbaikan
- Selama ada suara terdaftar dan layar mati, `PembungkamTelungkup` memutar keheningan total (PCM nol, `USAGE_MEDIA`, tanpa meminta
  fokus audio, tanpa bunyi) agar saluran media aktif dan tombol volume tetap menghasilkan perubahan yang terbaca pemantau.
  Perubahan volume media (saluran 3) sudah dipantau dan dikembalikan seperti biasa setelah suara dihentikan.
- Keheningan dimatikan bersama pemantau volume: saat suara selesai, dibungkam, atau kedaluwarsa.
- Dinyalakan bila layar mati pada saat pemantau mulai, atau menyusul (diperiksa tiap 0,2 detik) bila layar baru mati di tengah suara. Saat layar menyala, jalur lama tidak berubah.
- Sumber yang diuji pengguna: azan dan pengingat sebelum salat (`PrayerAlarmService`, saluran alarm bawaan), yang sudah terdaftar di pembungkam.

## Batas
- Bila volume media sudah maksimum, tombol volume ATAS tidak mengubah nilai dan tidak terdeteksi; tombol BAWAH dan telungkup tetap bekerja.
- Tidak mengubah audio Al-Qur'an maupun pemutar lain. BELUM dikompilasi penuh dan BELUM diuji di perangkat.
- Uji manual: matikan layar, picu pengumuman jam, tekan volume bawah dan atas; ulangi untuk azan dan nama pemanggil.
