# FIX246 — Cari isi hadits, jadwal sholat aktif bawaan, stereo di semua keluaran suara

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.

## 1. Pencarian hadits berdasarkan isi (tidak bergantung pada daftar bab)
- Halaman kitab: kolom "Cari bab" kini selalu terlihat setelah kitab diunduh (dahulu disembunyikan bila daftar bab kosong, sehingga tidak terlihat).
- Tombol baru "Cari di isi hadits": mencari kata kunci (shalat, wudhu, zakat, puasa, jual beli, dan sebagainya) langsung di teks terjemahan Indonesia (bila tidak ada, teks Arab). Kata kunci tema diperluas ke ejaan dan padanannya; semua kata harus ada, bila tidak ada yang cocok dipakai hasil sebagian kata.
- Hasil tampil per halaman (5 hadits), dengan jumlah hasil diumumkan; tombol halaman berikutnya/sebelumnya membawa kata kunci. Hasil dicache sementara agar pindah halaman cepat.
- Berkas: KitabHadits.kt (cariNomorDariTeks), BabHadits.kt (PencarianTeks), HaditsActivity.kt (mode "cari"). Logika murni diuji dengan kotlinc (t244/Uji.kt: SEMUA OK).

## 2. Jadwal sholat dan fitur pendukung aktif bawaan
PrayerPrefs: bawaan kini aktif untuk jadwal sholat (enabled), pengingat tiap waktu (azan/Imsak/terbit/Dhuha/Tahajud), pengingat sebelum sholat, pengingat sahur dan berbuka, serta ucapan arah kiblat otomatis. Pilihan yang pernah disimpan pengguna tetap dihormati. MainActivity memasang ulang alarm saat dibuka bila lokasi sudah diatur.
Tetap atas pilihan pengguna: lokasi (perlu diatur sekali), jenis puasa, Jangan Ganggu (butuh izin sistem), waktu khusus Dhuha/Tahajud, getar kiblat.

## 3. Stereo di semua keluaran suara
Pemutar murattal Khatam: pada saluran volume alarm, notifikasi, panggilan suara, dan sistem, pilihan Stereo kini memakai AudioTrack dua kanal sungguhan (PemutarMono(stereoPenuh = true)), sehingga kiri dan kanan tetap terpisah; sumber mono digandakan ke dua sisi. Media, dering, dan aksesibilitas tetap memakai MediaPlayer seperti sebelumnya. Pabrik pemutar: SaluranAudioKhatam.buatPemutar, dipakai KhatamActivity dan PemutarQuranService (termasuk pramuat).
Catatan jujur: penyebab di perangkat pengguna belum bisa diverifikasi tanpa uji fisik; bila masih mono pada suatu keluaran, mohon laporkan perangkat dan keluarannya.
