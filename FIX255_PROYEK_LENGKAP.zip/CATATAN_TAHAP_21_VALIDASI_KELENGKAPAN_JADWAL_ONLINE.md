# Tahap 21 — Validasi kelengkapan data jadwal online

## Perubahan
- `PrayerOnlineTimes.kt` sekarang memeriksa bahwa respons API memiliki satu entri untuk setiap hari dalam bulan yang diminta.
- Sebelum cache bulan disimpan, kode memeriksa bahwa setiap hari memiliki data waktu salat wajib yang diperlukan. Entri yang tidak lengkap tidak lagi diam-diam dilewati lalu dianggap sukses.
- Jika data bulan tidak lengkap, sinkronisasi masuk ke jalur gagal dan tidak memperbarui penanda sinkronisasi penuh (`last_sync`/`signature`).
- Menambahkan padanan bahasa Inggris untuk pesan `Data jadwal online tidak lengkap.` di `BahasaAplikasi.kt`.

## Dampak yang diharapkan
Mencegah respons parsial dari layanan online ditandai sebagai sinkronisasi penuh, sehingga cache jadwal tidak dianggap sepenuhnya segar ketika ada hari yang hilang.

## Pemeriksaan
- Versi dipertahankan: `versionCode 68`, `versionName 1.0.68`.
- Perubahan diperiksa secara statis.
- Build Android penuh dan pengujian jaringan/perangkat belum dijalankan.
