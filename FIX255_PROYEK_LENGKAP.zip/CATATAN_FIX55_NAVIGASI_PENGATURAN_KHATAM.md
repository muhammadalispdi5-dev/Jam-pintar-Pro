# FIX55 — Susunan dan navigasi Pengaturan Khatam Al-Qur'an

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX54. Perubahan: `KhatamActivity.kt`.

## Susunan
Pengaturan Khatam
- Pengaturan hafalan > Mode hafalan | Jumlah pengulangan ayat | Jeda antar ayat
- Pengaturan pemutaran audio > Suara qari (katalog > daftar qari) | Pemutaran Arab/terjemahan | Cara pemutaran | Stereo/Mono | Equalizer (> Kustom) | Kecepatan
- Pengingat membaca dan hafalan
- Target khatam (> target khusus)
- Pengaturan aksesibilitas
- Riwayat khatam
- Kemajuan dan statistik

## Aturan navigasi (semua sub menu)
- Tombol Kembali pada tiap dialog bernama induknya ("Kembali ke pengaturan audio", "Kembali ke pengaturan hafalan", "Kembali ke pengaturan Khatam", dst.).
- Menutup dialog dengan tombol Kembali Android atau sentuhan di luar dialog juga menuju induknya, bukan menu utama Khatam. Hanya Pengaturan Khatam (puncak) yang kembali ke menu utama.
- Helper `kembaliKe(label, induk)` dipakai agar tombol dan penutupan dialog selalu konsisten.

## Celah yang ditutup
- Pengaturan hafalan dan Pengaturan pemutaran audio: menutup dialog langsung ke menu utama (kini ke Pengaturan Khatam).
- Kecepatan audio dan Target khatam: tanpa tombol/penutupan menuju induk (kini ada).
- Target khusus: salah input atau Kembali kini kembali ke pilihan target, bukan ke atas.
- Pengingat: label tombol salah ("pengaturan audio") diperbaiki; membatalkan pemilih jam kembali ke dialog pengingat.
- Jumlah pengulangan ayat: label tombol salah diperbaiki.
- Pilih qari: daftar kosong tidak lagi menutup dialog tanpa tujuan; Kembali dari daftar qari menuju katalog; pemanggilan dari dialog putar audio tidak lagi melempar ke pengaturan audio.
- Equalizer kustom: bila equalizer/pita tidak tersedia, kembali ke pengaturan audio.
- Stereo/Mono > Pengaturan mono sistem: setelah kembali dari pengaturan Android, dialog dibuka lagi.
- Aksesibilitas: setelah mengubah pilihan tetap di grup aksesibilitas (bisa diubah berulang); unduh ulang teks kembali ke grup ini setelah selesai atau dibatalkan.

## Pemeriksaan
- Tanda kurung Kotlin seimbang; `verify_project.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat.
