# FIX92 — Pencarian dan pembacaan pesan melalui perintah suara

## Perubahan
- Menambahkan cache lokal `RiwayatPesanSuara` untuk cuplikan pesan masuk yang tersedia pada notifikasi Android dan memang diizinkan oleh pengaturan pembacaan notifikasi.
- Cache dibatasi maksimum 50 pesan dan masa simpan 7 hari; data tidak dikirim ke server.
- Mendukung perintah “cari pesan dari Ali Bima” dan “bacakan pesan terbaru dari Ali Bima”.
- Mendukung “bacakan pesan terbaru” untuk pesan masuk terbaru yang tersedia.
- “Buka WhatsApp” tetap membuka aplikasi WhatsApp; setelah itu pengguna dapat menjalankan perintah pencarian sebagai perintah suara berikutnya.
- Respons bantuan/kondisi pesan kosong mengikuti bahasa aktif aplikasi: Indonesia, Inggris, Arab, Jawa, dan Sunda. Isi pesan dibacakan apa adanya sesuai bahasa pengirim.

## Batasan dan privasi
- Fitur hanya membaca isi yang disediakan Android melalui notifikasi pesan masuk. Pesan lama yang tidak lagi tersedia sebagai notifikasi, pesan yang disembunyikan, atau isi yang tidak ditampilkan aplikasi sumber tidak dapat dicari.
- Akses notifikasi harus diaktifkan dan sumber pesan harus diizinkan pada pengaturan Jam Pintar Bro.
- Tidak membaca pesan keluar atau mengirim/membalas pesan. Tidak membuka percakapan privat secara otomatis.
- Cache disimpan lokal pada SharedPreferences aplikasi, dibatasi 50 item/7 hari.

## Pemeriksaan
- `python tools/verify_project.py`: lulus.
- Uji Kotlin terisolasi: “cari pesan dari Ali Bima” dikenali sebagai CARI_PESAN; “bacakan pesan terbaru” dikenali sebagai BACA_PESAN.
- Belum menjalankan kompilasi Android penuh atau pengujian pada perangkat fisik.
