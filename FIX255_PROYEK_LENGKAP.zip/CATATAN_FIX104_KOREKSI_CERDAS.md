# FIX104 - Koreksi cerdas (menyatu dengan Koreksi otomatis)
Tidak ada tombol/fitur baru; yang sudah ada ditingkatkan agar tidak ganda: "Koreksi otomatis dengan pengenalan suara" (FIX102 audio koreksi dan FIX103 pengingat tetap dipakai).
- Diagnosis tingkat kata: selaraskanKata kini mencatat indeks kata ayat yang salah/terlewat (varian tanpa basmalah digeser dengan benar).
- Kata yang salah ditandai (latar merah, tebal, bergaris bawah) pada "Teks ayat asli" di dialog, dan daftar kata ditulis ("Kata yang perlu diperbaiki: ...").
- Pengumuman TalkBack menyebut jumlah dan 3 kata pertama yang perlu diperbaiki sebelum audio benar diputar (jeda 4,5 detik agar sempat terbaca).
- Adaptif per ayat dalam satu sesi: gagal berturut-turut >= 2 menambah petunjuk (kata pertama ayat) dan memutar audio yang benar dua kali. Berhasil setelah beberapa percobaan menampilkan "Alhamdulillah, berhasil setelah N percobaan". Penghitung direset saat dialog ditutup.
- Saklar: Pengaturan Hafalan > Fitur latihan hafalan > "Koreksi cerdas" (hafalan_koreksi_cerdas_aktif, bawaan aktif). Bila nonaktif, perilaku kembali ke FIX102.
Belum dikompilasi/diuji; penandaan kata bergantung pada ketepatan pengenalan suara.
