# FIX145 — Asisten Suara: Salam, Sapaan, dan Perkenalan

Perubahan berbasis FIX144:

- Menambahkan pengenalan salam Islam dengan beberapa variasi pengucapan/transkripsi, termasuk Assalamu'alaikum dan variasi ejaan yang umum dikenali mesin speech recognition.
- Menambahkan respons untuk sapaan umum, selamat pagi/siang/sore/malam, ucapan terima kasih, dan ucapan perpisahan.
- Pada sapaan pertama yang dikenali, asisten menjawab salam/sapaan, menyambut pengguna di Jam Pintar Pro, memperkenalkan diri, lalu menawarkan bantuan. Perkenalan ditandai selesai setelah seluruh rangkaian TTS berhasil selesai, agar tidak dianggap sudah disampaikan bila terpotong.
- Pada sapaan berikutnya, asisten menjawab singkat tanpa mengulang perkenalan panjang.
- Respons menggunakan bahasa tampilan aplikasi (Indonesia/Inggris), tetapi tetap memakai mesin TTS dan profil suara Jam yang dipilih pengguna.
- Respons dibacakan berurutan dengan jeda antarkalimat dan tetap dapat dihentikan melalui mekanisme pembungkam yang sudah ada.
- Perintah lain tetap diteruskan ke penafsir perintah suara yang lama.

Catatan:
- Keberhasilan pengenalan bergantung pada hasil yang diberikan mesin SpeechRecognizer Android dan ketersediaan paket bahasa/mesin TTS di perangkat.
- Arsip sumber belum dikompilasi menjadi APK pada lingkungan ini. Pengujian runtime di perangkat belum dilakukan.
