# FIX223 — Pilihan unduh audio plus terjemahan
- Menu Khatam > "Unduh audio Al-Qur'an dan terjemahan" kini diawali pilihan isi unduhan: (1) audio Al-Qur'an saja, (2) audio plus terjemahan Indonesia, (3) terjemahan Indonesia saja. Pilihan terakhir diingat.
- Setelah itu pengguna memilih cakupan seperti sebelumnya (seluruh Al-Qur'an, satu surah, ayat satu surah, atau satu juz). Audio terjemahan hanya tersedia per surah penuh, sehingga untuk unduhan per ayat atau per juz terjemahan diunduh per surah yang tercakup.
- Terjemahan disimpan terpisah: Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an/Terjemahan Indonesia/Terjemahan_Indonesia_Surah_NNN.mp3.
- Pemutar (di Khatam dan lewat perintah suara "putar surah ... plus terjemah") memakai berkas terjemahan yang sudah diunduh, dan memakai internet bila belum ada.
