# FIX218 — Gagal kompilasi `:app:compileReleaseKotlin` / `:app:compileDebugKotlin` (const val URL di InfoBmkg)

Versi aplikasi tidak diubah. Basis: FIX217. Berkas diubah: `InfoBmkg.kt`, `tools/periksa_const_val.py`.

## Kesalahan dari CI
`InfoBmkg.kt:22:31`, `23:30`, `24:37`, dan `25:29`: Const 'val' initializer must be a constant value.

## Temuan
Keempat baris adalah `const val URL_AUTOGEMPA`, `URL_GEMPA_M5`, `URL_GEMPA_DIRASAKAN`, dan `URL_NOWCAST`, masing-masing berisi satu literal
`"https://..."` murni, tanpa templat `$`. Ini pola yang sama dengan FIX207/FIX208 (`URL_DASAR_TERJEMAHAN_ID`). Dengan literal semurni itu seharusnya
kompiler menerimanya, jadi sebab pastinya di lingkungan CI belum saya ketahui. Yang pasti: di CI, setiap `const val` berisi alamat `https://` ditolak,
dan `const val` lain di proyek (angka, aritmetika, literal tanpa URL) tidak bermasalah.

## Perbaikan
- Keempat konstanta URL diubah dari `const val` menjadi `val` biasa. Nilainya hanya dipakai saat berjalan (diteruskan ke `ambil(...)` dan
  `daftarGempa(...)`), bukan pada anotasi, sehingga syarat `const` tidak diperlukan.
- `tools/periksa_const_val.py` kini juga gagal untuk setiap `const val` yang berisi `://`, dengan pesan "pakai val biasa". Pemeriksa versi FIX208
  hanya menilai apakah ekspresi tampak konstan, sehingga lolos pada kasus ini. Diuji pada arsip FIX217 asli: tepat keempat baris ini tertangkap;
  pada arsip ini: LULUS. Terhubung ke `tools/verify_project.py`.

## Pemeriksaan
- `tools/periksa_const_val.py`, `tools/uji_bmkg.py` (LULUS), bahasa aktif, resource string, bentrok anggota Halaman: LULUS.
- `verify_project.py` hanya melaporkan `build.yml` tidak ditemukan (folder `.github` di luar zip).
- BELUM dikompilasi (tidak ada Kotlin/Android SDK di sini). Bila build ulang menunjuk kesalahan lain, kirim log barunya.

## Bahasa aktif
Tidak ada teks tampilan yang berubah; hanya modifier empat konstanta URL dan alat pemeriksa.
