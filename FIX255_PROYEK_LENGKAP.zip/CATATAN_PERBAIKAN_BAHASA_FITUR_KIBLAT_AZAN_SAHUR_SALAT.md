CATATAN PERBAIKAN BAHASA — FITUR KIBLAT, AZAN, SAHUR/BERBUKA, DAN PENGINGAT SALAT

Berkas sumber diperiksa pada area:
- QiblaActivity.kt (arah kiblat dan deskripsi jarum kompas)
- PrayerAlarmService.kt (notifikasi/pengingat salat dan tes suara)
- PrayerSettingsActivity.kt (pengaturan pengingat, suara azan, dan kompas)
- FastingSchedule.kt (teks pengingat sahur dan berbuka)
- BahasaAplikasi.kt (pemetaan teks Indonesia-Inggris untuk fitur terkait)

Perbaikan yang diterapkan:
1. Mengganti kalimat aksesibilitas jarum kompas yang berbahasa Inggris pada jalur teks Indonesia menjadi bahasa Indonesia.
2. Memperbaiki teks pengingat sebelum salat yang sebelumnya muncul dalam bahasa Inggris pada jalur Indonesia.
3. Memperbaiki teks pemberitahuan hitung mundur salat yang sebelumnya berbunyi campuran bahasa Indonesia dan Inggris menjadi “Waktu salat [nama salat] tinggal [jumlah] menit lagi.”
4. Mempertahankan pemetaan bahasa Inggris yang memang diperlukan saat pengguna memilih bahasa Inggris.
5. Mempertahankan teks khusus bahasa daerah yang sudah tersedia pada FastingSchedule.kt.

Catatan verifikasi:
- Ini adalah perbaikan pada kode sumber di dalam arsip ZIP, bukan APK yang sudah dikompilasi.
- Kompilasi Android dan pengujian langsung di perangkat belum dijalankan pada lingkungan ini. Mohon lakukan build dan uji fitur pada perangkat, terutama pengumuman kompas, tes suara azan, pengingat sahur/berbuka, serta pengingat waktu salat.
