# FIX231 — Audio per halaman, melodi, dan unduhan terjemahan

- Perintah suara pemutar latar belakang mengenali `halaman` / `page` 1–604. Rentang ayat diambil dari metadata halaman pada cache `quran_ar.json`, sehingga mengikuti halaman mushaf Madinah yang sama dengan fitur Khatam.
- Pengulangan jumlah putaran mengikuti direktif perintah suara yang sudah ada (`sekali`, `dua kali`, `tiga kali`, atau angka + `kali`). Pengulangan berlaku untuk seluruh daftar ayat pada halaman; direktif `setiap ayat` tetap menggunakan mode pengulangan per ayat.
- Melodi diputar langsung ketika dipilih pada pengaturan Jam dan Nama Pemanggil; tombol uji melodi terpisah di kedua bagian tersebut dihilangkan.
- Audio sirine dari lampiran ditambahkan sebagai pilihan terakhir dalam daftar melodi dan disematkan ke `res/raw/sirine_pengguna.mp3`.
- Pengingat sahur dan berbuka memperoleh pilihan melodi sebelum dan sesudah suara pengingat. Kedua pengaturan berdiri sendiri dan mengikuti daftar melodi yang sama.
- URL audio terjemahan unduhan kini menggunakan fungsi URL kanonis yang juga dipakai pemutar perintah suara. Pemilihan isi unduhan disinkronkan dengan preferensi tersimpan dan unduhan dibatalkan bila berkas terjemahan untuk cakupan yang dipilih tidak tersedia.
- Versi aplikasi tidak diubah: `versionCode 86`, `versionName 1.0.86`.

Catatan pengujian:
- XML resource diperiksa dan seluruhnya valid.
- Build Gradle belum dapat dijalankan di lingkungan penyuntingan ini karena arsip proyek tidak menyertakan Gradle Wrapper dan executable `gradle` tidak tersedia. Jalankan GitHub Actions untuk verifikasi kompilasi APK.
- Perintah suara halaman memerlukan cache teks Al-Qur'an lengkap yang memuat metadata halaman. Jika belum tersedia, aplikasi memberi pesan agar teks lengkap diunduh melalui fitur Khatam.
