# FIX222 — Perintah suara memutar Al-Qur'an salah mendeteksi "tidak ada jaringan"
Keluhan: Samsung SM-M127F, Android 13. Lewat asisten suara muncul keterangan tidak ada jaringan, padahal internet lancar dan pemutaran dari dalam aplikasi normal.
Penyebab: `adaInternet()` hanya memeriksa `activeNetwork`; layanan yang dipanggil dari asisten suara (latar belakang, penghemat data) bisa mendapat nilai kosong, lalu pemutaran online langsung dihentikan.
Perbaikan: deteksi memeriksa activeNetwork, semua jaringan berkemampuan internet, dan activeNetworkInfo. Pemutaran online tidak lagi dihentikan dini; bila status jaringan tak terbaca, aplikasi tetap mencoba memutar dan baru melaporkan kegagalan bila pemutar benar-benar gagal.
