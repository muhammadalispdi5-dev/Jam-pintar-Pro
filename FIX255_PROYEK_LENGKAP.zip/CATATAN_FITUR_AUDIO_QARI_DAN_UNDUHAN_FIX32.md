# FIX32 — Perluasan qari, pemutaran juz, dan unduhan audio

Versi aplikasi tetap `1.0.69` (`versionCode 69`).

## Fitur yang ditambahkan pada sumber kode
- Daftar qari utama diperluas, dengan qari pilihan seperti Mishary Alafasy, Al-Husary, Al-Minshawi, As-Sudais, Ash-Shuraim, Abdul Basit, Al-Ajamy, Muhammad Ayyoub, Al-Hudhaify, Ash-Shaatree, Maher Al-Muaiqly, Yasser Al-Dosari, Nasser Al-Qatami, dan Hani Ar-Rifai.
- Katalog audio ayat Al Quran Cloud dimuat dari API saat menu qari dibuka.
- Katalog MP3Quran dimuat dari API dan menambahkan reciter yang menyediakan audio per surah. Nama yang cocok dengan Ahmad Saud, Junaid Adam Abdullah, atau Muhammad Taha diberi label kategori “Anak”; ketersediaannya mengikuti hasil API saat aplikasi terhubung ke internet.
- Pemutaran juz berurutan per ayat untuk qari CDN, menggunakan metadata juz pada teks Al-Qur'an yang sudah diunduh.
- Unduhan seluruh 114 surah untuk qari yang dipilih, satu surah penuh, semua ayat dalam surah sebagai MP3 terpisah, atau semua ayat dalam juz sebagai MP3 terpisah.
- Pada Android 10+, unduhan disimpan ke folder bersama `Jam Pintar Pro/Al-Qur'an` pada penyimpanan internal bersama, melalui MediaStore. Pada Android versi lama, fallback berada di folder penyimpanan khusus aplikasi.
- Pemilihan qari disimpan; pilihan qari tambahan MP3Quran menggunakan sumber audio per surah, sedangkan pemutaran/unduhan per ayat atau juz dibatasi ke qari CDN.
- Percobaan bitrate audio ayat/surah CDN mencakup 128, 64, 48, 40, 32, dan 192 kbps.

## Catatan penting
- Daftar qari anak bukan penilaian keagamaan/artistik; nama anak hanya ditandai jika API katalog mengembalikan nama yang cocok. Tidak semua qari memiliki semua surah atau endpoint audio per ayat.
- Audio satu surah dari katalog MP3Quran memakai server dan daftar surah yang disediakan API. Unduhan seluruh Qur'an bisa besar; aplikasi melaporkan jumlah berkas yang berhasil dan gagal.
- Android 10+ path yang ditargetkan adalah folder bersama di root penyimpanan internal: `Jam Pintar Pro/Al-Qur'an`. Versi Android lama menggunakan direktori khusus aplikasi demi kompatibilitas dan keamanan penyimpanan.
- Teks Al-Qur'an harus sudah diunduh agar aplikasi bisa menghitung rentang juz dan membuat daftar unduhan per ayat.

## Verifikasi
- `python3 tools/verify_project.py`: lulus untuk pemeriksaan statis versi, konfigurasi dan manifest.
- Pemeriksaan parser Kotlin tanpa Android classpath: tidak ditemukan pesan sintaks `expecting` setelah perbaikan.
- Build Gradle/APK dan pengujian pada ponsel belum dijalankan. Katalog API, setiap URL qari, izin penyimpanan, serta pemutaran/unduhan harus diuji pada perangkat nyata sebelum menyatakan semua qari dan semua surah tersedia.
