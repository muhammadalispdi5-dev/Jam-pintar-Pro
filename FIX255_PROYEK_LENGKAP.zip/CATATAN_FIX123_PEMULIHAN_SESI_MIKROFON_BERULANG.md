# FIX123 — Pemulihan sesi mikrofon berulang

## Tujuan
Menangani kondisi ketika pemicu goncangan / widget Beritahu Saya tetap terdeteksi tetapi sesi pengenalan suara berikutnya gagal membuka mikrofon setelah beberapa kali penggunaan.

## Perubahan
1. `PerintahSuaraActivity`
   - Kepemilikan layar perintah suara diserialkan: instance sebelumnya ditutup dan diberi jeda 650 ms untuk melepas `SpeechRecognizer` serta audio focus sebelum instance baru mulai.
   - Aktivasi ulang manual dari widget selalu memulai sesi pengenalan baru, termasuk bila sesi sebelumnya sedang membacakan jawaban.
   - Restart membersihkan callback tertunda, melepas pengenal dan audio focus, membatalkan layar pengenal sistem lama, mereset status retry, lalu memulai sesi baru setelah jeda singkat.
   - `onDestroy()` memastikan status sesi dan seluruh resource mikrofon/audio dilepas di semua jalur penghancuran Activity.
2. `BeritahuSayaWidgetProvider`
   - PendingIntent perintah suara menggunakan `CLEAR_TOP | SINGLE_TOP`, sehingga ketukan berulang diarahkan ke instance yang ada, bukan menumpuk Activity.
   - Ketukan widget ditandai sebagai pemicu manual agar sesi pengenalan dapat dimulai ulang secara eksplisit.
3. `GoncanganSuaraService`
   - Penjaga waktu monotonic mencegah callback sensor/notifikasi ganda meluncurkan layar perintah suara lebih dari sekali dalam rentang 2,5 detik.
   - Cooldown pendeteksi pola goncangan yang sudah ada tetap dipertahankan; tidak ada batas jumlah penggunaan.

## Perilaku yang dipertahankan
- Pengenalan suara tetap menggunakan layar pengenal sistem pada jalur normal.
- Jalur `SpeechRecognizer` langsung tetap digunakan untuk skenario yang memang memerlukannya (misalnya pemicu goncangan / layar kunci dan izin mikrofon sudah tersedia).
- Izin mikrofon tetap dikelola Android; aplikasi tidak merekam audio di latar belakang.
- Bahasa pengenalan, teks, dan pesan tetap mengikuti bahasa aktif aplikasi.
- Getar/nada siap tetap dipicu saat pengenal langsung menyatakan siap.

## Pemeriksaan
- Arsip sumber diperiksa dan struktur ZIP diverifikasi setelah perubahan.
- Gradle wrapper tidak tersedia di arsip dan perintah `gradle` tidak terpasang pada lingkungan ini; karena itu kompilasi Android dan uji mikrofon pada perangkat fisik belum dapat dijalankan.
