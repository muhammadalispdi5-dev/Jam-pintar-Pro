# Tahap 16 — Lokalisasi pratinjau jadwal jam

## Perubahan
- Pratinjau jadwal pengucapan berikutnya pada halaman Jam kini memakai locale bahasa tampilan aktif: Inggris untuk tampilan Inggris, Indonesia untuk tampilan Indonesia.
- Sebutan hari Ahad dipertahankan khusus pada tampilan Indonesia; tampilan Inggris menggunakan nama hari Inggris (Sunday, Monday, dan seterusnya).
- Bahasa tampilan tetap terpisah dari `jamBahasaIdx`, yaitu pilihan bahasa untuk TTS. Perubahan ini tidak menimpa pengaturan suara pengguna.
- Versi aplikasi tetap 1.0.68 (`versionCode` 68).

## Pemeriksaan
- Perubahan diterapkan pada satu blok yang sebelumnya selalu memakai locale Indonesia.
- Tidak ada Gradle wrapper `gradlew` pada arsip proyek, sehingga build Android penuh tidak dijalankan.
- Belum dilakukan uji perangkat/TalkBack. Perlu memeriksa pratinjau pada kedua bahasa tampilan dan memastikan ucapan TTS tetap mengikuti bahasa ucapan yang dipilih.
