# FIX142 - Perintah putar audio tanpa membuka layar aplikasi

Semua perintah suara putar Al-Qur'an kini dijalankan `PemutarQuranService` (layanan latar belakang). Layar Khatam tidak pernah dibuka, baik saat layar terkunci maupun tidak, sehingga TalkBack tidak terganggu.

## Yang berubah
- `PerintahSuaraActivity`: cabang `Jenis.QURAN` selalu memanggil `putarQuranLatarBelakang`. `bukaKhatam` dihapus.
- `QariSuara.kt` (baru): memilih qari lewat suara ("pilih qari Alafasy", "putar surah Yasin dengan qari Sudais", "pilih qari anak"), logika pencocokan sama dengan Khatam, memakai katalog cache Khatam.
- `EfekAudioLatar.kt` (baru): menerapkan preset equalizer, slot kustom, bass, suara ruang, penguat volume dari pengaturan Khatam pada pemutar latar.
- `PemutarQuranService`: menangani klausa qari, memakai pengulangan per ayat dan jeda antar ayat bawaan Khatam bila perintah tidak menyebutnya, memasang/melepas efek per pemutar.
- Semua teks mengikuti bahasa aktif (`tr`). Tes baru: `tools/uji_putar_tanpa_layar.py`.

## Tidak dipindahkan (tetap di layar Khatam)
Mode hafalan (kelompok ayat, koreksi), audio terjemahan Indonesia.

## Tambahan (FIX143): mode Stereo/Mono
`PemutarQuranService` kini memakai `PemutarAudio` (PemutarStereo atau PemutarMono) sesuai pengaturan `keluaran_suara_audio` di Khatam. `PemutarAudio` mendapat `setVolume` (untuk ducking fokus audio). Layanan menambah kunci CPU parsial karena pemutar mono mendekode di thread sendiri.

## Catatan
Belum dikompilasi dan belum diuji di perangkat (kotlinc dan android.jar tidak tersedia di lingkungan ini). Pemeriksaan statis proyek lulus.
