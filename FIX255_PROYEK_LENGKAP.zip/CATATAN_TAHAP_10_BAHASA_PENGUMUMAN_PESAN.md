# Tahap 10 — Bahasa pengumuman notifikasi pesan

Versi aplikasi tetap 1.0.68 (versionCode 68, versionName 1.0.68).

## Perubahan
- Awalan pengumuman standar untuk SMS/chat dan keterangan grup/pesan suara kini dipilih menurut `Prefs.jamBahasaIdx` (Indonesia, English, Arab, Jawa, atau Sunda).
- Pola pesan khusus yang diisi pengguna tetap dipertahankan dan tidak diterjemahkan otomatis, agar teks personal tidak berubah diam-diam.
- Isi pesan dan nama kontak tetap dibacakan apa adanya karena keduanya merupakan konten dari pengirim/pengguna, bukan teks antarmuka.

## Batasan dan pengujian
- Ini perubahan statis pada `CallerListener.kt`; belum ada kompilasi Android penuh atau pengujian langsung pada perangkat.
- Kualitas pengucapan Arab/Jawa/Sunda bergantung pada mesin TTS dan suara yang tersedia di perangkat.
- Bila pengguna mengisi pola khusus dengan bahasa tertentu, pola tersebut tetap mengikuti teks yang mereka tulis. Ini disengaja.
