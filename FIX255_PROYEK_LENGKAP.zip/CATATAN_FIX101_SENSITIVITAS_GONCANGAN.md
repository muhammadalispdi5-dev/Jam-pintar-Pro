# FIX101 - Goncangan sulit mengaktifkan perintah suara
Penyebab (ditemukan lewat simulasi gerakan tangan, bukan uji di HP): DetektorGoncangan FIX99 mensyaratkan HP "diam" (ambang tetap) minimal 0,7 detik dan puncak pertama muncul <0,45 detik sesudah mulai bergerak. Getaran tangan atau gerakan kecil sebelum menggoyang membuat syarat itu gagal; satu percobaan gagal juga membuat sisa goncangan pada gerakan yang sama ditolak. Sensitivitas 10 tidak membantu karena syarat diam yang gagal. Keberhasilan pada simulasi: sekitar 20 persen.
Perbaikan: DetektorGoncangan ditulis ulang.
- Ambang puncak adaptif = max(ambang sensitivitas, 3 x RMS latar belakang beberapa detik terakhir). Syarat "HP harus diam" dan "mulai segera" dihapus.
- Sensitivitas 10 kini 1,8 m/s2 (sebelumnya 2,5); rentang 1-10 tetap.
- Kenaikan puncak maks. 250 ms (sebelumnya 150), jeda antarpuncak maks. 700 ms (500), jendela 2,5 detik (1,8), konfirmasi puncak di 70 persen (60).
- Pemanasan 2 detik sesudah layanan mulai (0,8 detik di layar uji) agar latar terukur.
- Mode ketat menjadi "Normal" (ambang adaptif); mode longgar tetap 1,8 kali lebih kuat, tidak lagi membatalkan pada hentakan keempat.
Hasil simulasi (324 skenario hentakan dengan getaran tangan dan gerakan pendahulu): FIX99 sekitar 20 persen -> FIX101 sekitar 90 persen; 0 dari 55 skenario berjalan/kendaraan/gerakan acak memicu palsu. Belum dikompilasi dan belum diuji pada HP nyata; bila masih sulit/terlalu mudah, FAKTOR_LATAR dan AMBANG_MIN di DetektorGoncangan.kt dapat disetel.
