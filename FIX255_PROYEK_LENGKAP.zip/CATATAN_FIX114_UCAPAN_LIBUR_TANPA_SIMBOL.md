# FIX114 — Info libur nasional dan cuti bersama diucapkan tanpa simbol yang tidak dipahami

Versi aplikasi tidak diubah. Basis: FIX113. Berkas diubah: `HariLibur.kt`. Baru: `tools/uji_nama_libur.py`.

## Masalah
Mesin suara membacakan tanda baca dan singkatan secara harfiah saat menyebut libur nasional dan cuti bersama:
- Ringkasan memakai tanggal angka `dd-MM-yyyy` (mis. 01-01-2026), terbaca "nol satu strip nol satu strip dua ribu...".
- Kalimat memakai titik dua sebelum nama libur ("Hari ini terdapat libur nasional: X"), terbaca "titik dua".
- Nama dari sumber daring (`dayoffapi`) dapat memuat tanda kurung, garis miring, "&", garis hubung, tanda kutip dan apostrof
  (Isra Mi'raj), "(Tentatif)", singkatan "S.A.W.", "SAW", "RI", akhiran tahun "1447H" atau "1447 H", "2026 M", "2570 BE".
  Semua itu terbaca harfiah ("kurung buka", "garis miring", "es a we", "bee", "ha").
- Nama dari API sering diawali "Cuti Bersama ..." sehingga kalimat menjadi "cuti bersama terakhir yaitu Cuti Bersama ...".

## Perbaikan
- **Tanggal berkata.** Semua ringkasan memakai `tanggal()` seperti bagian lain: "hari Kamis tanggal 1 Januari 2026"
  (English: "Thursday, January 1, 2026"). Format angka dihapus.
- **Tanpa titik dua.** Kalimat memakai kata penyambung per bahasa: Indonesia "yaitu", Jawa "inggih menika", Sunda "nyaéta",
  Arab "وهي", English "Today there is a national holiday, X, on ...".
- **Nama dirapikan sebelum diterjemahkan** (`rapikanNama`): keterangan "(Tentatif)/(Perkiraan)" dibuang; tanda kutip dan apostrof
  dibuang ("Mi'raj" menjadi "Mikraj"); "S.A.W." menjadi "SAW"; "RI" dan "R.I." menjadi "Republik Indonesia"; "1447 H" menjadi
  "1447 Hijriah", "2026 M" menjadi "2026 Masehi", "2570 BE" menjadi "2570 Buddhis"; "&" dan "+" menjadi "dan"; "/" menjadi "atau";
  rentang angka "23-24" menjadi "23 sampai 24"; garis hubung berspasi dan tanda kurung menjadi jeda koma; titik dua dan titik koma
  menjadi koma; simbol lain (* # @ ~ ^ _ | < > =) dibuang; awalan "Cuti Bersama" dan "Libur Nasional" dibuang karena sudah
  disebut kalimat pembukanya. Daftar nama bawaan bahasa Inggris tidak diubah (apostrof "New Year's Day" dipertahankan).
- **Singkatan diperjelas sesudah terjemahan** (`ucapanAkhir`): "SAW" menjadi "Shalallahu Alaihi Wasalam" (Indonesia, Jawa, Sunda),
  "peace be upon him" (English), "صلى الله عليه وسلم" (Arab). Sisa "H/M/BE" menjadi Hijriah/Masehi/Buddhis (English: Hijri, CE,
  Buddhist Era; Arab: هجرية، ميلادية، بوذية). Padanan English dan Arab untuk "Masehi" dan "Buddhis" ditambahkan.
- Bila nama menjadi kosong sesudah dirapikan, dibacakan label umum ("libur nasional" atau "cuti bersama") sesuai bahasa.

## Contoh sesudah perbaikan
- "Isra Mi'raj Nabi Muhammad S.A.W." menjadi "Isra Mikraj Nabi Muhammad Shalallahu Alaihi Wasalam" (English: "Isra and Mi'raj")
- "Cuti Bersama Hari Raya Idul Fitri 1447 H" menjadi "Hari Raya Idul Fitri 1447 Hijriah" (English: "Eid al-Fitr 1447 Hijri")
- "Hari Raya Waisak 2570 BE" menjadi "Hari Raya Waisak 2570 Buddhis" (English: "Vesak Day 2570 Buddhist Era")
- "Hari Kemerdekaan RI" menjadi "Hari Kemerdekaan Republik Indonesia"

## Pemeriksaan
- `tools/uji_nama_libur.py` (cerminan Python; membaca daftar padanan langsung dari `HariLibur.kt`) menjalankan 19 nama gaya sumber daring
  dan memeriksa semua nama bawaan: tidak ada simbol atau singkatan tersisa, dan format `dd-MM-yyyy` sudah tidak dipakai. Lulus.
- `tools/verify_project.py` lulus (termasuk `periksa_bahasa_aktif.py`); kurung seimbang. BELUM dikompilasi dan BELUM diuji di HP.
- Catatan proses: pemeriksa bahasa aktif sempat gagal (65 literal Indonesia, batas 62) karena tiga kalimat ringkasan semula lolos hanya
  karena barisnya memuat `ofPattern(`. Kalimat itu kini disusun sebagai kalimat utuh dua bahasa lewat pembantu `dua(english, id, en)`
  (cabang English terpisah dihapus, hasilnya sama). Baseline diperbarui (turun 1).

## Bahasa aktif
Teks baru ada di `HariLibur.kt`, dan semuanya mengikuti bahasa aktif: kalimat ringkasan dan jawaban memakai kalimat utuh per bahasa
(Indonesia, English, Arab, Jawa, Sunda); penyambung pengganti titik dua tersedia di kelima bahasa; nama libur dirapikan lalu
diterjemahkan sesuai bahasa aktif dan singkatan diperjelas per bahasa (`ucapanAkhir`). Tidak ada kunci `strings.xml` baru.
Pemeriksa `tools/periksa_bahasa_aktif.py`: LULUS.

## Batas
- Cerminan Python hanya meniru logika regex; perilaku `\p{L}` pada Kotlin sama dengan huruf Unicode di sana.
- Nama dari sumber daring yang benar-benar baru dan tidak ada di daftar padanan tetap diucapkan sebagaimana adanya setelah dirapikan.
  Pada bahasa English/Arab/Jawa/Sunda, nama seperti itu diganti label umum agar tidak bercampur bahasa (perilaku lama).
