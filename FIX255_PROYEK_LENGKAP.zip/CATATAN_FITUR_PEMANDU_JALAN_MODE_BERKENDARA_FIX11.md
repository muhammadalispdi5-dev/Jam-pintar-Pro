# FIX11 — Mode Berjalan Kaki dan Berkendara

Perubahan pada `PemanduJalanActivity.kt`:
- Menambahkan dialog aksesibel untuk memilih **Berjalan kaki** atau **Berkendara**.
- Mode awal tetap berjalan kaki agar perilaku sebelumnya tidak berubah bagi pengguna lama.
- Mode pilihan diteruskan ke parameter Google Maps `travelmode=walking` atau `travelmode=driving`.
- Pengumuman suara/status menyebut mode yang dipilih.
- Google Maps tetap bertanggung jawab atas petunjuk belokan dan pembaruan rute berkelanjutan.

Catatan: sumber proyek ini belum dikompilasi menjadi APK dalam lingkungan ini. Mode berkendara dimaksudkan untuk pengemudi yang aman mengoperasikan navigasi; pengguna tunanetra sebaiknya memakai pendamping/pengemudi dan tidak mengoperasikan ponsel saat kendaraan bergerak.
