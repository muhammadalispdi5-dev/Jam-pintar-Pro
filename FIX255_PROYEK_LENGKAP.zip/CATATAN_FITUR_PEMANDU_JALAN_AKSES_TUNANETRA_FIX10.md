Perubahan fitur Pemandu Jalan – FIX10

- Pemandu Jalan kini memprioritaskan membuka rute langsung di aplikasi Google Maps, bukan membiarkan Android memilih browser terlebih dahulu.
- Navigasi berjalan kaki memakai parameter tujuan, asal, bahasa tampilan aplikasi, dan mode navigasi yang sudah ada.
- Jika Google Maps tidak tersedia/tidak dapat dibuka, aplikasi mencoba membuka tautan rute melalui aplikasi lain yang dapat menangani tautan tersebut.
- Google Maps adalah komponen yang menghitung rute, mendeteksi belokan/perubahan rute, dan menyuarakan instruksi secara berkelanjutan. Jam Pintar Pro tidak mengarang instruksi belokan sendiri.
- Ditambahkan penjelasan aksesibel agar pengguna memastikan suara navigasi Google Maps dan volume media aktif.
- Peringatan keselamatan tetap menegaskan bahwa GPS/peta tidak mendeteksi semua rintangan fisik; pengguna tetap perlu tongkat, anjing pemandu, atau pendamping bila dibutuhkan.

Catatan: perubahan sumber belum diuji dengan kompilasi Gradle di lingkungan ini.
