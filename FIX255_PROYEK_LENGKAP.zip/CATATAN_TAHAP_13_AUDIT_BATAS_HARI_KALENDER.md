Tahap 13 — Penyatuan patokan pergantian hari kalender

Perubahan:
- Menyatukan pemeriksaan pergantian hari ke malam pada satu fungsi internal `sudahMalam`.
- Patokan tetap pukul 18.00 waktu lokal; tidak mengubah pengaturan bahasa tampilan maupun bahasa ucapan.
- Fungsi ini dipakai untuk penentuan tanggal sasaran Hijriah/pasaran dan sebutan hari/malam dalam semua bahasa yang didukung.
- Urutan ucapan tidak diubah: waktu, pasaran (jika aktif), tanggal Masehi (jika aktif), lalu tanggal Hijriah (jika aktif).
- Versi tetap 1.0.68 / versionCode 68.

Pemeriksaan:
- Audit statis memastikan tidak ada pemeriksaan jam >= 18 yang tersisa di file kalender di luar fungsi `sudahMalam`.
- ZIP proyek diuji dengan `unzip -t`.
- Build Android penuh dan uji TTS pada perangkat belum dilakukan.
