# FIX214: sakelar perangkat tidak berubah, hanya halaman Pengaturan terbuka

Penyebab paling mungkin: layananAksesibilitasPanggilanAktif() membandingkan ComponentName.flattenToString() dengan isi
Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES. Banyak ponsel menyimpan bentuk pendek ("com.novan.bateraibicara/.PanggilanWhatsAppAccessibilityService"),
sehingga layanan yang aktif dianggap mati; siapkanKontrolOtomatis() tidak dipanggil dan sakelar tidak pernah ditekan.
Perbaikan: komponen diurai (unflattenFromString) dan dibandingkan; AccessibilityManager.getEnabledAccessibilityServiceList dipakai sebagai pemeriksa kedua.
Ikut memperbaiki perintah panggilan WhatsApp yang memakai pemeriksaan yang sama.
Belum dikompilasi dan belum diuji di perangkat. Syarat tetap: layanan "Jam Pintar Pro" harus aktif di Pengaturan > Aksesibilitas.
