# FIX151 – Daftar qari perempuan

- Pilihan baru "Qari perempuan" di dialog "Pilih jenis katalog qari" (KhatamActivity.kt).
- Qari perempuan dari katalog MP3Quran (hanya yang lengkap 114 surah) diberi label "Perempuan · " (Female · pada bahasa Inggris). Pengenalan nama ada di `qariPerempuan()`; tambahkan nama baru di sana.
- Cadangan: Noreen Muhammad Siddiq (`archive.org/download/noreen-sedeeq/001.mp3` dst), dipakai bila katalog tidak memuatnya. Sumber ini belum diverifikasi dari lingkungan pengembangan (tidak ada akses jaringan ke archive.org).
- Riwayat Noreen: Ad-Duri 'an Abi 'Amr, bukan Hafs; ada keterangan di judul daftar dan saat dipilih.
- Label ikut disimpan di cache katalog; QariSuara.kt mengenali awalan baru.
- Bahasa aktif: semua teks baru memakai tr(id, en); pemeriksa bahasa dan resource string lulus, baseline tidak naik.
- Belum dikompilasi dan belum diuji.
