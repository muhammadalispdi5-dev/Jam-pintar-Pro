# FIX159 — Cakupan Asisten Suara, Volume Mandiri, dan Efek Audio

## Dasar perubahan
- Sumber berasal dari FIX158_DIAGNOSTIK_LAYANAN_CUACA.zip.
- Perbaikan cuaca sebelumnya dipertahankan apa adanya; tidak menjadi fokus perubahan FIX159.
- `versionName` tetap `1.0.82` dan `versionCode` tetap `82`.

## Asisten suara
- Audit rute pembuka mencakup 13 kategori utama pada halaman depan: Baterai, Jam, Kalender, Nama Pemanggil, Jadwal Sholat, Lokasi Terkini, Pemandu Jalan, Kiblat, Fasilitas Terdekat, Doa, Khatam Al-Qur'an, Mode Acara, dan Bahasa.
- Menambahkan perintah informasi baterai: misalnya “berapa baterai saya”, “status baterai”, atau “battery level”. Jawaban membaca persentase dan status pengisian saat itu.
- Jawaban informasi baterai memakai profil suara Baterai sehingga volume mandiri dan bahasa aktif sesuai pengaturan.
- Rute pembuka kategori dan perintah suara inti lain yang telah ada tetap dipertahankan (waktu/tanggal, sholat berikutnya, timer, Quran, kendali audio, panggilan/pesan, dan kontrol perangkat yang didukung).
- Catatan batas cakupan: audit ini memverifikasi kategori utama dapat dibuka lewat suara dan beberapa operasi inti dapat dijalankan. Belum semua kontrol internal setiap subhalaman (setiap sakelar, pilihan, dan isian) diubah menjadi perintah suara.

## Volume mandiri dan efek audio
- Profil suara Jam dan Baterai kini mempunyai volume digital mandiri 0–100% dan pilihan efek awal pengumuman: tanpa efek, bip singkat, atau bip ganda.
- Pengaturan tersedia melalui tombol roda gigi pada kelompok Suara. Volume tidak mengubah volume sistem atau profil kategori lain.
- Volume Jam berlaku pada TTS, melodi pengumuman, dan nada alarm jam.
- Volume Baterai berlaku pada pengumuman TTS baterai.
- Khatam Al-Qur'an memiliki volume mandiri 0–100% pada Pengaturan Khatam > Pengaturan Pemutaran Audio. Volume diterapkan pada pemutar layar dan layanan pemutar latar belakang.
- Efek audio Khatam tetap dapat diatur melalui Equalizer/preset efek audio yang sudah tersedia.
- Petunjuk penggunaan Indonesia dan English diperbarui.

## Pemeriksaan
- `uji_cakupan_asisten_suara.py` — lulus.
- `uji_volume_dan_efek_audio_mandiri.py` — lulus.
- Seluruh skrip `uji_*.py` — lulus.
- `periksa_bahasa_aktif.py` — lulus.
- `periksa_resource_strings.py` — lulus.
- XML resource diperiksa dan valid.
- Versi aplikasi tidak dinaikkan.

## Batas verifikasi
Tidak ada Gradle wrapper / Android SDK yang digunakan untuk build pada lingkungan ini. Karena itu kompilasi Kotlin, APK, dan pengujian fisik belum dinyatakan berhasil. Jalankan GitHub Actions untuk validasi build akhir.
