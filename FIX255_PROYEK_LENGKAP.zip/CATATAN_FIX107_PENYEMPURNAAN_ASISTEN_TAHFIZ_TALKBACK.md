# FIX107 — Penyempurnaan Asisten Tahfiz Cerdas dan TalkBack

## Perubahan
- Mengganti dialog daftar pilihan Asisten Tahfiz Cerdas yang sebelumnya memakai `setItems` menjadi panel gulir dengan tombol aksi nyata.
- Setiap tombol memiliki nama dan uraian pada `contentDescription`, dapat difokuskan pembaca layar, dan menjalankan aksi yang sesuai.
- Saat panel dibuka, pengantar mengumumkan bahwa panel tersedia dan memberi tahu jumlah pilihan agar pengguna TalkBack mengetahui konteksnya.
- Panel ditata vertikal dan dapat digulir sehingga tetap dapat digunakan pada layar kecil serta pembesaran teks.
- Tombol menutup panel induk sebelum membuka alur tujuan agar fokus TalkBack tidak tertahan pada dialog lama.
- Semua label dan uraian menggunakan `tr(id, en)` sehingga mengikuti bahasa tampilan aktif.

## Integrasi tanpa duplikasi
- Muraja'ah Cerdas tetap memakai `mulaiMurajaahCerdas()` dan antrean `HafalanSrs` yang sudah ada.
- Hafalan Inklusif tetap memakai `latihanKoreksiHafalan()` serta pengaturan aksesibilitas yang sudah ada.
- Koreksi Bacaan tetap memakai `mulaiKoreksiOtomatisHafalan()` dan recognizer yang sudah ada.
- Tidak ditambahkan mesin pengenalan suara, penilaian tajwid, atau penyimpanan hafalan baru.

## Batasan pemeriksaan
- Pemeriksaan sumber dilakukan pada perubahan Kotlin dan struktur proyek.
- Build Gradle dan uji perangkat/TalkBack belum dapat dijalankan di lingkungan ini karena Gradle wrapper/Gradle dan Android SDK tidak tersedia.
- Setelah dipasang, uji dengan TalkBack: buka Pengaturan Khatam > Asisten Tahfiz Cerdas, geser fokus melewati pengantar, lalu aktifkan masing-masing tombol.
