# FIX158 — Diagnostik Kegagalan Layanan Cuaca

## Latar belakang
Pada FIX157, pesan kegagalan jaringan masih terlalu umum. Semua `IOException`, termasuk respons HTTP gagal dari server, diperlakukan seolah-olah layanan tidak dapat dihubungi. Hal ini dapat menyalahkan koneksi internet ponsel padahal penyebabnya bisa berupa pembatasan permintaan, gangguan server penyedia, DNS, TLS, atau sambungan yang terputus.

## Perbaikan
- Memisahkan status HTTP non-2xx dari gangguan koneksi. Status 429 memberi arahan menunggu karena pembatasan permintaan; status 5xx dijelaskan sebagai gangguan server; status 4xx dilaporkan sebagai permintaan yang ditolak.
- Membedakan kegagalan DNS (`UnknownHostException`), TLS/sertifikat (`SSLException`), sambungan terputus (`SocketException`), dan waktu tunggu (`SocketTimeoutException`).
- Kesalahan struktur JSON atau data suhu tidak lagi dikategorikan sebagai kegagalan jaringan.
- Pesan Indonesia dan English diperbarui agar tidak langsung menyuruh pengguna memeriksa internet ketika bukti penyebabnya belum menunjukkan jaringan perangkat.
- Tetap menggunakan Open-Meteo melalui HTTPS dan alur lokasi langsung/cadangan yang telah ada pada FIX157.
- Tidak mencatat atau mengirim koordinat lokasi ke pengembang.
- Versi aplikasi tetap 1.0.82 / versionCode 82.

## Pemeriksaan
- `tools/uji_cuaca_lokasi_langsung.py`: lulus.
- `tools/periksa_bahasa_aktif.py`: lulus.
- `tools/periksa_resource_strings.py`: lulus.
- Seluruh 16 skrip `tools/uji_*.py`: lulus.
- Kompilasi Gradle/Kotlin dan uji langsung di ponsel belum dapat dilakukan di lingkungan ini; jalankan GitHub Actions.

## Catatan
FIX158 memperbaiki klasifikasi dan informasi kesalahan agar penyebab dapat dikenali. Keberhasilan komunikasi langsung ke server Open-Meteo tetap perlu diverifikasi melalui pengujian APK pada perangkat dan pesan diagnostik baru yang muncul.
