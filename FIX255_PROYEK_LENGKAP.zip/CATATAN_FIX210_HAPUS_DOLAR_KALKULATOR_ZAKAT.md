# FIX210: bersihkan simbol dolar di Kalkulator Zakat

KalkulatorZakatActivity.kt:
- tambahMenu: contentDescription memakai penggabungan teks (judul + ". " + keterangan), bukan templat dolar, sehingga pembaca layar tidak pernah menerima tulisan "$judul. $keterangan".
- rupiah(): sebelumnya memakai format mata uang; pada bahasa Inggris menghasilkan tanda "$". Kini hanya angka berformat lalu kata "rupiah" (mis. "1.500.000 rupiah" / "1,500,000 rupiah"), tanpa simbol mata uang apa pun.
