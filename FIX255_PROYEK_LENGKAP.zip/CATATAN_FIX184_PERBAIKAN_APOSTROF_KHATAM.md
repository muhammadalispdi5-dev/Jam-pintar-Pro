# FIX184 — Gagal kompilasi `:app:mergeDebugResources` / `:app:mergeReleaseResources` (apostrof di strings.xml)

Versi aplikasi tidak diubah. Basis: FIX183. Berkas diubah: `app/src/main/res/values/strings.xml`, `app/src/main/res/values-en/strings.xml`.

## Kesalahan dari CI
`values/strings.xml`: Failed to flatten XML for resource 'isi_petunjuk_penggunaan' (baris 36), 'khatam_menu' (224), dan 'khatam_judul' (428)
dengan pesan "Invalid unicode escape sequence in string". Pesan itu dipakai aapt2 untuk apostrof polos pada string (sama dengan FIX132 dan FIX149).

## Penyebab
Ketiga string memuat apostrof ASCII tanpa backslash, terutama "Al-Qur'an" dan "Qur'an": `isi_petunjuk_penggunaan` (7 tempat pada
Indonesia, 10 pada English), `khatam_menu` dan `khatam_judul` (1 tempat tiap berkas). Resource Android mewajibkan `\'`.

## Perbaikan
Semua apostrof polos pada ketiga string, di kedua bahasa, kini `\'` (21 tempat). Isi kalimat tidak berubah.
`tools/periksa_resource_strings.py` menangkap tepat ketiga string itu (6 temuan) sebelum perbaikan dan lulus sesudahnya.

## Pemeriksaan
- `tools/periksa_resource_strings.py`: LULUS. BELUM dijalankan lewat Gradle/aapt2 (tidak ada Android SDK); build ulang di GitHub Actions diperlukan.

## Bahasa aktif
Hanya penulisan apostrof di resource Indonesia dan English; kunci dan kalimat tetap, tidak ada teks baru.
