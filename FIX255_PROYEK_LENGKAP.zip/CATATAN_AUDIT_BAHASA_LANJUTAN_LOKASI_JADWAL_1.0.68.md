# Audit bahasa lanjutan — Jam Pintar Pro 1.0.68

Perbaikan ini menargetkan teks yang ditemukan pengguna pada pilihan suara/volume, halaman jadwal salat, serta halaman lokasi terkini.

- Menambahkan `values-en/arrays.xml` agar daftar kecepatan, nada, volume audio, interval baterai/jam, melodi, format jam, dan hari menggunakan bahasa Inggris saat bahasa tampilan Inggris dipilih. Urutan item dipertahankan agar indeks pengaturan tidak berubah.
- Menyesuaikan format tanggal halaman jadwal salat agar mengikuti bahasa tampilan.
- Menerjemahkan label dan status pada ringkasan jadwal salat serta teks privasi dan penjelasan lokasi terkini.
- Mempertahankan nama tempat yang berasal dari geocoder sebagai nama tempat, bukan menerjemahkannya.

Validasi yang perlu dilakukan sesudahnya: build GitHub Actions dan uji perangkat dengan bahasa tampilan Inggris pada layar Jadwal Salat, Lokasi Terkini, Caller Name, pilihan kecepatan/nada/volume, dan dialog lokasi. Ini bukan klaim bahwa seluruh jalur runtime telah diuji pada perangkat.
