# FIX124 - Tombol volume tidak menghentikan pengingat Dhuha, dan audit semua suara notifikasi

Versi aplikasi tidak diubah. Basis: FIX123 (perbaikan tautan unduh). Berkas diubah: `PembungkamTelungkup.kt`, `HafalanSrsReceiver.kt`,
`BeritahuSayaActivity.kt`. Berkas baru: `tools/uji_pembungkam_notifikasi.py`.

## Gejala
Menekan tombol volume tidak menghentikan suara pengingat waktu Dhuha.

## Penyebab (dari pembacaan kode; belum ada log, belum diuji di perangkat)
1. Pengingat Dhuha diputar `PrayerAlarmService` dan sudah terdaftar pada `PembungkamTelungkup`. Saat aplikasi tidak terbuka (layar mati,
   layar depan), tombol volume dibaca dari siaran sistem VOLUME_CHANGED_ACTION, tetapi penerimanya hanya menerima saluran volume 1 sampai 5.
   Pilihan "volume keluaran" pengguna dapat berupa volume aksesibilitas (saluran 10) atau panggilan (saluran 0); perubahan pada saluran itu
   tidak pernah dianggap sebagai tombol penghenti. Siaran itu juga tersembunyi dan tidak dijamin terkirim pada Android baru.
2. Audit seluruh sumber suara menemukan dua celah lain:
   - Notifikasi "Saatnya mengulas hafalan" (FIX103) berbunyi dengan kanal bawaan tetapi tidak pernah didaftarkan ke pembungkam.
   - Pengumuman waktu/tanggal dari widget Beritahu Saya tidak dapat dibungkam (bukan `bisaDibungkam`, tidak menangani tombol volume).

## Perbaikan
- `PembungkamTelungkup`: penerima siaran menerima SEMUA jenis saluran. Ditambah pemantau cadangan yang tidak bergantung pada siaran:
  selama ada sumber suara terdaftar, volume saluran 0,1,2,3,4,5,10 dibaca tiap 200 ms; perubahan nilai setelah masa tenang 1,2 detik dianggap
  tekanan tombol volume, suara dihentikan, dan volume dikembalikan ke nilai semula. Pemantau mati bersama pemantau lain saat tidak ada suara.
- `HafalanSrsReceiver`: bunyi notifikasi didaftarkan (tombol volume atau telungkup membatalkan notifikasi dalam 20 detik pertama), sama dengan Khatam.
- `BeritahuSayaActivity`: kedua pembicara (waktu dan tanggal) dapat dibungkam; tombol volume saat layar transparan ini di depan menghentikan
  dan menutupnya; pembungkaman dari latar belakang atau telungkup juga menutupnya (dipantau tiap 0,4 detik).

## Hasil audit sumber suara notifikasi
- Sudah terdaftar dan benar: azan dan semua pengingat salat termasuk Dhuha, Imsak, Terbit, sahur, berbuka (`PrayerAlarmService`), alarm jam
  (`AlarmJamService`), pengumuman jam dan baterai (`BatteryTalkService`), nama pemanggil (`CallerListener`), pengingat Khatam, jawaban suara
  `PerintahSuaraActivity` (FIX122).
- Diperbaiki di sini: pengingat hafalan, pengumuman widget Beritahu Saya, dan penerima siaran volume.
- Sengaja tidak terdaftar: pemutar Al-Qur'an (murattal, `PemutarQuranService`/`AudioLatarService`) dan pemandu kiblat/jalan, karena itu audio yang
  sedang dikendalikan pengguna, bukan pemberitahuan; tombol volume mengatur volumenya.
- Notifikasi lain senyap (kanal tanpa suara) sehingga tidak ada bunyi yang perlu dihentikan.
`python3 tools/uji_pembungkam_notifikasi.py` mencetak audit ini otomatis dan gagal bila ada kanal berbunyi baru yang tidak terdaftar.

## Batas yang diketahui
- Bila volume saluran yang dipakai sudah di batas maksimum, menekan tombol volume ATAS tidak mengubah nilai sehingga tidak terdeteksi dari latar
  belakang (sistem tidak mengirim perubahan). Tombol volume BAWAH tetap menghentikan; telungkup juga tetap bekerja. Saat salah satu halaman aplikasi
  terbuka, kedua tombol bekerja karena ditangkap langsung.
- Masa tenang 1,2 detik pertama mengabaikan tekanan tombol agar perubahan volume otomatis saat suara mulai tidak dianggap tekanan.
- Perubahan volume oleh aplikasi lain atau sistem selama pengingat berbunyi juga menghentikannya.
- Sakelar "Hentikan azan dan semua suara notifikasi dengan tombol volume" (bawaan aktif) tetap berlaku.

## Bahasa aktif
Tidak ada teks baru yang terlihat pengguna; pemeriksa bahasa aktif lulus.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, `uji_tombol_volume.py`, dan `uji_pembungkam_notifikasi.py` lulus; kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat. Bila pengingat Dhuha masih tidak berhenti, catat mode "volume keluaran" yang dipilih, jenis
  HP/Android, dan apakah volume saat itu sudah maksimum.
