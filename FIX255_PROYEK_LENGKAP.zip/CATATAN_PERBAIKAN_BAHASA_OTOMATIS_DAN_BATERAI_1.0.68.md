# Perbaikan bahasa otomatis dan pengucapan baterai — Jam Pintar Pro 1.0.68

- Instalasi baru mengikuti bahasa sistem perangkat: English bila bahasa perangkat Inggris, selain itu Bahasa Indonesia.
- Pilihan bahasa tampilan yang disimpan secara manual tetap dipertahankan. Preferensi eksplisit dari versi sebelumnya dimigrasikan sebagai pilihan manual.
- Notifikasi layanan baterai dan teks widget baterai menggunakan konteks bahasa tampilan aplikasi, termasuk deskripsi aksesibilitas widget.
- Templat ucapan baterai (persentase, baterai lemah/kritis/penuh, charger dan kabel USB) mengikuti bahasa pengucapan aktif untuk templat bawaan. Kalimat yang benar-benar dikustomisasi pengguna tetap dipertahankan.
- Pemeriksaan statis proyek dan XML lulus. Kompilasi Android penuh serta uji langsung pada perangkat belum dijalankan karena Gradle wrapper/executable tidak tersedia pada lingkungan pemeriksaan.
