# FIX52 — Pilihan suara TalkBack saat pergantian audio

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX51. Perubahan: `KhatamActivity.kt`.

## Fitur
- Pengaturan Khatam > Pengaturan aksesibilitas > **Suara TalkBack saat pergantian audio**: "tetap aktif" (bawaan, perilaku lama) atau "dimatikan". Tersimpan di preferensi `senyap_talkback_pergantian_audio`.
- Bila dimatikan, saat audio berpindah OTOMATIS ke audio berikutnya (lanjut ayat pada juz/halaman/rentang, pengulangan ayat, hafalan berurutan, Arab lalu terjemahan), aplikasi:
  1. tidak mengirim pengumuman TalkBack (status "Sedang memutar audio…", "Jeda hafalan, ayat berikutnya…", peringatan equalizer, status terjemahan);
  2. menghentikan ucapan TalkBack yang sedang berjalan agar tidak menimpa audio berikutnya.
- Audio yang dimulai manual oleh pengguna tetap diumumkan seperti biasa.

## Catatan
- Aplikasi hanya mengendalikan pengumuman miliknya. Bila fokus TalkBack sedang berada pada tombol yang teksnya berubah, TalkBack bisa tetap membacanya; pengaturan "audio ducking" TalkBack ada di pengaturan TalkBack, bukan di aplikasi.
- BELUM dikompilasi dan BELUM diuji di perangkat. Jalankan GitHub Actions lalu uji dengan TalkBack aktif.
