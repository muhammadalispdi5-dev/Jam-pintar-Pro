# FIX34 — Pengaturan Audio, Mode Hafalan, dan Aksesibilitas

Versi aplikasi dipertahankan pada **1.0.69** (`versionCode 69`). Perubahan berfokus pada `KhatamActivity.kt`.

## Perubahan
- Menata menu Khatam Al-Qur'an ke dalam kelompok berurutan: Bacaan dan Navigasi; Pengaturan Audio dan Mode Hafalan; Pemutaran Audio; Target dan Riwayat Khatam; Sumber.
- Menghapus tombol **Kembali ke beranda**. Tombol kembali Android tetap menjadi jalur untuk kembali dari layar Khatam.
- Menambahkan satu menu **Pengaturan audio & mode hafalan** yang memuat pilihan qari, mode hafalan, jumlah pengulangan, kecepatan audio, dan jeda antar ayat.
- Mode hafalan: Putar biasa (satu kali), Hafalan ayat (mengulang ayat terpilih), dan Hafalan berurutan (mengulang ayat sesuai jumlah pengulangan lalu melanjutkan ke ayat berikutnya secara otomatis).
- Jeda antar ayat: 0, 2, 5, atau 10 detik.
- Mempertahankan pilihan qari, pengulangan, kecepatan, mode hafalan, dan jeda di preferensi aplikasi.
- Mengumumkan perubahan qari, status pemutaran, dan ayat berikutnya melalui accessibility announcement untuk membantu pengguna pembaca layar.
- Merapikan kontrol pembaca dengan satu area Audio dan Hafalan; kontrol jeda/hentikan tidak diduplikasi.

## Pemeriksaan
- `tools/verify_project.py`: LULUS.
- `versionCode 69` dan `versionName 1.0.69` dipertahankan.
- Pemeriksaan parser Kotlin mandiri tidak menemukan pesan sintaks seperti `Expecting` atau `unexpected tokens`. Kompilasi mandiri penuh tidak dapat dinilai karena classpath Android tidak disertakan.
- Belum dilakukan kompilasi Gradle penuh atau pengujian di perangkat Android/TalkBack. Mohon uji terutama mode hafalan berurutan, qari MP3Quran yang menyediakan surah penuh saja, dan navigasi tombol Kembali.
