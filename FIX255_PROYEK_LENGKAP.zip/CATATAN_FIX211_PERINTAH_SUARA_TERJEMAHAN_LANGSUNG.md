# FIX211: "putar surah X dan terjemahan Indonesia" langsung memutar yang diminta

Masalah: layanan menyusun daftar putar [murattal surah penuh] + [berkas terjemahan]. Berkas terjemahan (Internet Archive "quraninindonesia")
sudah memuat bacaan surah beserta terjemahannya, sehingga pengguna mendengar surah tanpa terjemahan dulu, lalu surah plus terjemahan.

Perbaikan (PemutarQuranService.kt, putar()): bila terjemahan diminta untuk satu surah penuh, hanya berkas terjemahan yang diputar,
tanpa murattal di depannya. "terjemahan saja" tetap memutar berkas yang sama. Perintah dengan ayat/juz tidak berubah (Arab saja + pemberitahuan).
Belum dikompilasi dan belum diuji di perangkat; sumber audio tidak dapat saya periksa langsung dari sini.
