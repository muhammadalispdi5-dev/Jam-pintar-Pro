# FIX153 - Nama surah dalam huruf Latin untuk pembaca layar (Koreksi hafalan dengan suara)

Versi aplikasi tidak diubah (1.0.82, versionCode 82). Basis: FIX152. Berkas diubah: `KhatamActivity.kt`, `tools/verify_project.py`.
Berkas baru: `tools/uji_nama_surah_latin.py`.

## Permintaan
Pada fitur Koreksi hafalan dengan suara, khususnya "Pilih surah atau ayat", daftar nama surah masih bertulisan Arab. Tidak semua ponsel punya mesin suara
yang mendukung tulisan Arab, sehingga pembaca layar tidak dapat membacakannya. Daftar harus tampil dalam huruf Latin.

## Penyebab
`pilihSurah` (dipakai pembaca dan Koreksi hafalan) mengambil nama dari data Al-Qur'an: bahasa Indonesia memakai kolom `name` (tulisan Arab), bahasa English
memakai `englishName`. Hal yang sama terjadi pada `pilihSurahUntukAudio` dan judul surah di pembaca.

## Perbaikan
- Pembantu baru `namaSurahLatin(nomor)`: bahasa Indonesia memakai daftar transliterasi aplikasi (`HafalanSrs.NAMA_SURAH`, 114 nama ASCII: Al-Fatihah, Al-Baqarah, ...),
  yang sama dengan pengingat hafalan dan asisten tahfiz; English tetap memakai `englishName` dari data, dan bila kosong jatuh ke daftar aplikasi.
- Daftar "Pilih surah" (Koreksi hafalan, pembaca, menu Khatam) dan "Pilih surah untuk diputar" kini berbentuk "2. Al-Baqarah (286 ayat)" tanpa tulisan Arab.
- Judul surah pada pembaca menampilkan nama Latin. Nama Arab tetap tampil sebagai baris visual tambahan bagi pembaca yang melihat, tetapi diberi
  `importantForAccessibility = no` sehingga pembaca layar tidak membacakannya.
- Petunjuk dialog Koreksi dan pesan status saat berpindah ayat kini memuat nama Latin dan nomor: "Ayat yang diperiksa: surah Al-Baqarah (2), ayat 255" dan
  "Berpindah ke surah Al-Baqarah (2), ayat 1. Tekan Mulai membaca."
- Tidak ada perubahan pada pemilihan ayat, perintah suara, logika koreksi, audio, bahasa pengucapan, dan fitur lain.

## Bahasa aktif
Daftar mengikuti bahasa tampilan (ayat/verses; nama Latin Indonesia atau English). Seluruh teks baru memakai `tr(id, en)`. Pemeriksa bahasa aktif lulus.

## Pemeriksaan
- `verify_project.py` (aturan nama surah diperbarui: nama Arab tidak boleh lagi dipakai pada daftar yang dibacakan), `periksa_bahasa_aktif.py`,
  `periksa_resource_strings.py`, `uji_koreksi_pilih_ayat.py`, dan `uji_nama_surah_latin.py` lulus; kurung Kotlin seimbang.
- `uji_nama_surah_latin.py` memeriksa daftar 114 nama (hanya ASCII, tanpa duplikat), port pembuat label untuk dua bahasa (tanpa karakter Arab, termasuk bila
  `englishName` kosong), dan kontrak sumber pada tiga tempat tampilan nama.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: buka Koreksi hafalan dengan suara, tekan Pilih surah atau ayat, lalu Pilih surah; jelajahi daftar dengan TalkBack di
  ponsel tanpa suara Arab, dalam bahasa Indonesia dan English; periksa judul pembaca dan status "Berpindah ke surah ...".
