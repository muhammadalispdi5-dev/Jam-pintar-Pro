# FIX122 - Tombol volume tidak lagi menghentikan suara notifikasi aplikasi

Versi aplikasi tidak diubah. Basis: FIX121. Berkas diubah: `Halaman.kt`, `PerintahSuaraActivity.kt`. Berkas baru: `tools/uji_tombol_volume.py`.
Fitur asal: FIX76 (tombol volume menghentikan semua suara notifikasi lewat `PembungkamTelungkup`).

## Gejala
Tombol volume yang seharusnya menghentikan seluruh suara notifikasi aplikasi tidak lagi berfungsi.

## Penyebab (dari pembacaan kode; belum ada log, belum diuji di perangkat)
1. `Halaman.dispatchKeyEvent` menyimpan status `volumeDikonsumsi` yang hanya dibersihkan oleh ACTION_UP. Bila ACTION_UP tidak pernah sampai ke
   halaman itu (halaman jeda, jendela kehilangan fokus, Khatam dipindah ke belakang oleh perintah suara), status tetap true dan SEMUA
   tekanan volume berikutnya ditelan: suara tidak berhenti dan volume biasa pun mati. Khatam berjenis `singleTask` sehingga contoh yang
   sama bertahan lama, dan sejak perintah suara berjalan di latar (FIX87/118/119) peluang ini membesar.
2. `PerintahSuaraActivity` bukan turunan `Halaman`, sehingga tidak pernah menangkap tombol volume; selain itu jawaban suaranya (waktu, tanggal,
   libur, baca pesan) tidak didaftarkan sebagai suara yang dapat dihentikan (`bisaDibungkam` bawaannya false).

## Perbaikan
- `Halaman`: tekanan baru (repeatCount 0) selalu dinilai ulang dan membersihkan sisa status lama; status juga dibersihkan saat `onPause` dan saat
  jendela kehilangan fokus. Tekan-tahan tetap tidak diteruskan ke pengatur volume.
- `PerintahSuaraActivity`: menangani tombol volume dengan aturan yang sama; semua jawaban suaranya (4 tempat) didaftarkan sebagai dapat dibungkam,
  sehingga volume dan telungkup menghentikannya. Setelah dihentikan, layar ditutup dan audio Khatam yang dijeda untuk mikrofon dilanjutkan
  (telungkup dipantau tiap 0,4 detik lewat `PembungkamTelungkup.generasi`).
- Tidak diubah: tombol volume tetap mengatur volume biasa bila tidak ada suara notifikasi yang berbunyi; audio Khatam/murattal tidak terdaftar sebagai
  notifikasi sehingga volume tetap mengatur volumenya, bukan menghentikannya.

## Batas
- Jalur latar belakang/layar mati masih memakai siaran `VOLUME_CHANGED_ACTION` (lihat batas di FIX76); tidak diubah.
- Bila yang dimaksud adalah menghentikan audio Khatam dengan tombol volume, itu perilaku yang berbeda dan tidak diubah di sini.

## Bahasa aktif
Tidak ada teks baru yang terlihat pengguna; pemeriksa bahasa aktif lulus.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, dan empat uji (`uji_tombol_volume` memuat port mesin status lama vs baru yang
  memperlihatkan bug dan perbaikannya) lulus; kurung Kotlin seimbang. BELUM dikompilasi dan BELUM diuji di perangkat.
- Uji manual: azan atau alarm saat aplikasi terbuka, saat di Khatam, saat layar mati; jawaban perintah suara (waktu/tanggal) lalu tekan volume;
  tekan volume dua kali berturut-turut; volume biasa saat tidak ada suara.
