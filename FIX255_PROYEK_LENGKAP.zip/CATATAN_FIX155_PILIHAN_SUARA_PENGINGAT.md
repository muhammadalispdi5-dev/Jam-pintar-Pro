# FIX155 — Pilihan suara pengingat membaca dan hafalan

Basis: proyek FIX154 yang dilampirkan pengguna. Versi aplikasi dipertahankan pada `1.0.82` (`versionCode 82`).

## Perubahan
- Pengingat membaca Al-Qur'an memiliki pilihan sumber suara tersendiri: ucapan Android (TTS), nada alarm bawaan Android, atau berkas audio pilihan pengguna.
- Pengingat cerdas hafalan memiliki pilihan sumber suara yang terpisah dari pengingat membaca.
- Pemilihan berkas memakai Android Storage Access Framework (`ACTION_OPEN_DOCUMENT`, `audio/*`) dan menyimpan izin URI agar berkas dapat dipakai kembali oleh notifikasi terjadwal.
- TTS membacakan kalimat khusus sesuai fungsi pengingat membaca atau pengulangan hafalan dan memilih locale Indonesia/Inggris berdasarkan bahasa aktif aplikasi.
- Kanal notifikasi dibuat dengan ID berbeda sesuai mode dan sumber suara. Ini diperlukan karena Android 8+ menyimpan konfigurasi suara pada kanal notifikasi.
- Suara TTS hanya diputar bila notifikasi aplikasi/kanal diizinkan.
- Preferensi mode dan URI suara dimasukkan ke daftar cadangan/pemulihan pengaturan Khatam.
- Petunjuk penggunaan Indonesia dan Inggris diperbarui.

## Pengujian statis
- `tools/uji_suara_pengingat_baca_hafalan.py`: lulus 12 pemeriksaan.
- Semua skrip `tools/uji_*.py`: lulus setelah dua audit kontrak lama disesuaikan dengan struktur sumber saat ini.
- `tools/periksa_bahasa_aktif.py`: lulus.
- `tools/periksa_resource_strings.py`: lulus.
- Arsip ZIP diperiksa dengan `unzip -t`.

## Batasan verifikasi
- Tidak ada `gradlew`/Gradle wrapper, instalasi Gradle, atau Android SDK di lingkungan pemeriksaan ini; kompilasi Kotlin/Android belum dapat dilakukan.
- Arsip sumber FIX154 yang diberikan tidak memuat `.github/workflows/build.yml`; karena itu `tools/verify_project.py` melaporkan workflow build tidak ditemukan. Pemeriksaan lain di dalam skrip tersebut (bahasa dan resource string) lulus.
- Belum diuji pada perangkat fisik. Pemutaran ucapan TTS memerlukan mesin TTS Android dengan paket bahasa aktif yang tersedia. Berkas audio pilihan harus tetap ada dan izinnya tidak dicabut.
