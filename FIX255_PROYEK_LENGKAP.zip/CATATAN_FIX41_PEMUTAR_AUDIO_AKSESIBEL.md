FIX41 — PENATAAN PEMUTAR AUDIO PROFESIONAL DAN AKSESIBEL

Perubahan utama pada KhatamActivity.kt:
- Kontrol pemutar dikelompokkan menjadi dua baris horizontal: trek sebelumnya / putar-jeda / trek berikutnya, lalu perlambat / indikator kecepatan / percepat.
- Tombol utama memiliki area sentuh lebih tinggi dan label aksesibilitas yang berubah sesuai status.
- Tombol sebelumnya/berikutnya menavigasi ayat dalam pemutaran ayat atau juz, dan surah dalam pemutaran surah. Batas awal/akhir juz dihormati.
- Kecepatan dapat diubah bertahap melalui tombol perlambat/percepat: 0,75x, 1,0x, 1,25x, dan 1,5x. Kecepatan disimpan dan diterapkan pada pemutar aktif.
- Status kecepatan diumumkan melalui aksesibilitas.
- Tombol utama memulai pemutaran jika belum ada audio, serta menjeda/melanjutkan bila audio sudah siap.
- Kontrol tersedia di halaman utama Khatam dan halaman pembaca.

Versi aplikasi dipertahankan: versionCode 69, versionName 1.0.69.

Verifikasi: tools/verify_project.py lulus. Pemeriksaan ini bersifat statis. Kompilasi Gradle penuh dan pengujian langsung pada perangkat/TalkBack belum dilakukan karena wrapper Gradle tidak tersedia pada paket ini.
