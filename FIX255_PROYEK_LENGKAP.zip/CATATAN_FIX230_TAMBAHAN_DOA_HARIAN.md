# FIX230 - Tambahan koleksi Doa Sehari-hari Sesuai Sunnah

- Koleksi bertambah dari 89 menjadi 159 doa, dalam 18 kategori. Empat kategori baru: Taubat dan Istighfar; Perlindungan dari Keburukan; Syukur, Pujian, dan Shalawat; Ibadah Malam, Puasa, dan Al-Qur'an.
- Tambahan pada kategori lama, antara lain: terbangun malam, mimpi buruk, takut saat tidur; minum susu dan doa bagi yang memberi makan; melepas pakaian; basmalah wudhu; iftitah lain, i'tidal, doa sujud, doa sebelum salam; doa pagi dan petang lengkap (Muslim), fitrah Islam, tasbih sebanyak makhluk; naik kapal, takbir naik dan tasbih turun, safar saat sahur; takut kepada suatu kaum, ruqyah Jibril, doa Nabi Ayyub dan Musa, penyembuhan; surga dan neraka, perbaikan agama dan dunia, husnul khatimah; minta izin, masuk pasar, melunasi utang; istisqa dan hujan lebat; memejamkan mata dan memasukkan jenazah ke liang lahat.
- Setiap doa tetap memuat Arab, Latin, arti, kapan dibaca, sumber dan derajat (shahih/hasan). Perintah suara mengenali topik baru ("doa qunut", "doa masuk pasar", "doa naik kapal", "doa taubat", dan lainnya).
- Teks Arab, Latin, dan derajat ditulis dari hafalan tanpa membandingkan dengan kitab (jaringan terblokir); mohon ditinjau ustadz. Beberapa derajat hadits berbeda antarulama; yang ditulis mengikuti penilaian yang umum.
- Versi tetap 1.0.86. Belum dikompilasi dengan Gradle dan belum diuji di HP.
