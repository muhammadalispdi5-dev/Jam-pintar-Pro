# FIX217: asisten suara membacakan informasi BMKG langsung (real time)

File baru InfoBmkg.kt; PerintahSuaraActivity.kt memanggilnya (Jenis.BMKG, bacakanBmkg).
Perintah yang dikenali (Indonesia dan English):
- "gempa terbaru / gempa terkini / gempa terakhir" -> autogempa.json (tanggal, jam, berapa menit lalu, magnitudo, kedalaman, wilayah, potensi, dirasakan)
- "gempa dirasakan" -> gempadirasakan.json (3 terbaru)
- "daftar gempa magnitudo 5 atau lebih" -> gempaterkini.json (3 terbaru)
- "potensi tsunami" -> kolom Potensi gempa terbaru, dikutip apa adanya + anjuran mengikuti arahan resmi BMKG
- "peringatan dini cuaca", "cuaca ekstrem", "waspada hujan lebat" -> RSS nowcast BMKG + berkas CAP; untuk lokasi aktif perangkat,
  atau wilayah yang disebut ("peringatan dini cuaca di Jawa Barat"). Pencocokan berdasarkan nama wilayah.
- "informasi BMKG" -> gempa terbaru + peringatan dini untuk lokasi Anda.
Real time: setiap permintaan mengunduh langsung dari BMKG (tanpa cache, penambah parameter waktu, header no-cache). Batas BMKG 60 permintaan/menit/IP.
Akurasi: isi kolom BMKG diucapkan apa adanya; "n menit lalu" dihitung dari kolom DateTime BMKG; setiap jawaban menyebut "Sumber: BMKG" (syarat BMKG).
Kegagalan jaringan/format dijelaskan dengan jelas dan tidak mengarang data.
Tidak termasuk: prakiraan cuaca BMKG per kelurahan (butuh kode wilayah adm4). "Cuaca" biasa tetap memakai Open-Meteo.
Belum dikompilasi dan belum diuji terhadap server BMKG (jaringan sesi ini tidak menjangkaunya). Uji: tools/uji_bmkg.py.
