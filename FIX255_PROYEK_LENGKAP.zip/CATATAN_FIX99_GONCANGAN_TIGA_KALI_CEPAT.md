# FIX99 — Goncangan Pemicu Perintah Suara: Pola Tiga Kali Cepat

Versi aplikasi: **1.0.73** (versionCode 73). Basis: FIX98.

## Masalah
Pemicu goncangan hanya menghitung **dua** puncak percepatan dalam 1,5 detik, tanpa memeriksa apakah HP sedang diam atau
sedang bergerak biasa. Akibatnya gerakan sehari-hari (berjalan, mengangkat atau meletakkan HP, ketukan, getaran
kendaraan) mudah memicu perintah suara tanpa sengaja.

## Perbaikan: hanya pola TIGA goncangan cepat yang dikenali
Logika deteksi dipindah ke kelas baru `DetektorGoncangan` (murni logika, tanpa Android) yang dipakai bersama oleh layanan
latar belakang dan layar uji. Satu "goncangan" = satu hentakan percepatan. Pola sah bila:
1. Ada **tiga hentakan berturut-turut**; jeda antarhentakan 120–500 ms; ketiganya selesai dalam 1,8 detik.
2. Tiap hentakan **naik cepat** (maks. 150 ms dari lembah ke puncak). Gerakan lambat (mengangkat HP, mengayun) ditolak.
3. **Mode ketat (bawaan):** HP harus diam sekitar 0,7 detik sebelumnya dan hentakan pertama harus muncul segera setelah HP
   mulai bergerak. "Angkat HP lalu langsung goyang" tidak dihitung; diamkan sebentar dulu.
4. Bila sudah ada dua hentakan atau lebih dalam 2 detik sebelumnya, gerakan dianggap berirama (berjalan, berlari,
   kendaraan) dan ditolak.
5. **Mode longgar (opsional, boleh sambil berjalan):** ambang hentakan 1,8 kali lebih tinggi dan jumlahnya harus **tepat
   tiga** (hentakan keempat dalam 450 ms membatalkan). Tidak disarankan saat berlari.
6. Setelah pola dikenali, pemicu berikutnya ditahan 7 detik (seperti sebelumnya).

Perbaikan teknis tambahan: penyaring gravitasi memakai tetapan waktu 0,1 detik yang tidak bergantung laju sampel sensor;
waktu memakai cap waktu sensor (bukan waktu peristiwa diterima); puncak dikenali sebagai maksimum lokal sehingga getaran
berkesinambungan tetap terhitung benar.

## Perubahan tampilan
- Teks petunjuk di pengaturan, notifikasi layanan, dan pesan "Tidak ada perintah yang terdengar" kini menyebut **tiga kali cepat**.
- Pengaturan goncangan: bagian baru **Cara mengenali goncangan** (pilih mode ketat/longgar) dan **Uji goncangan**
  (setiap hentakan sah memberi getar singkat dan jumlahnya ditampilkan; pola tiga hentakan memberi getar panjang dan
  pengumuman). Selama uji, pola tidak membuka perintah suara (`GoncanganSuaraService.sedangUji`).
- Sensitivitas 1–10 tetap berlaku (ambang 7,0 → 2,5 m/s²; mode longgar dikali 1,8).

## Cara melakukan
Diamkan HP sekitar satu detik, lalu hentakkan tiga kali dengan cepat (sekitar tiga hentakan per detik). Satu atau dua
hentakan tidak membuka perintah suara.

## Berkas
- Baru: `DetektorGoncangan.kt`, `tools/simulasi_goncangan_detektor.py`, `tools/uji_simulasi_goncangan.py`.
- Diubah: `GoncanganSuaraService.kt`, `PengaturanGoncanganActivity.kt`, `res/values/strings.xml`, `res/values-en/strings.xml`,
  `app/build.gradle.kts`.

## Pemeriksaan dan batas
- `tools/uji_simulasi_goncangan.py` menjalankan cerminan algoritma di Python dengan 30 skenario sintetis (tiga hentakan
  cepat dengan berbagai jeda, satu/dua hentakan, lima hentakan, hentakan lambat, berjalan, berjalan cepat, berlari,
  angkat lalu goyang, goyang sinus 3–5 Hz, ayunan lambat, getaran kecil, meletakkan HP, ketukan, sensitivitas rendah dan
  tinggi, dua urutan, masa tahan 7 detik): semuanya lulus. Ini hanya sinyal buatan, bukan data sensor asli.
- `tools/verify_project.py`: LULUS; kurung dan XML seimbang. BELUM dikompilasi dan BELUM diuji pada HP.
- Angka ambang dan waktu (konstanta di awal `DetektorGoncangan`) mungkin perlu disetel pada HP nyata; gunakan layar
  Uji goncangan. Bila terlalu sulit memicu, naikkan sensitivitas atau pakai mode longgar; bila masih terlalu mudah, turunkan.
