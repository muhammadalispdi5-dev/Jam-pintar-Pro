# FIX152 - Koreksi hafalan dengan suara: pilih surah/ayat dan pindah ke ayat sebelumnya/berikutnya

Versi aplikasi tidak diubah (1.0.82, versionCode 82). Basis: FIX151. Berkas diubah: `KhatamActivity.kt`, `tools/verify_project.py`.
Berkas baru: `tools/uji_koreksi_pilih_ayat.py`.

## Permintaan
Pada fitur "Koreksi hafalan dengan suara": tambahkan opsi memilih surah atau ayat yang akan dibaca, dan opsi untuk memutar/pindah ke ayat sebelumnya atau berikutnya.

## Yang ditambahkan (di dalam dialog Koreksi hafalan dengan suara, di bawah status)
- Pilih surah atau ayat: membuka pilihan "Pilih surah (mulai dari ayat 1)" atau "Pilih nomor ayat dalam surah ini". Memakai ulang daftar surah dan isian nomor ayat yang
  sudah ada di pembaca (`pilihSurah` dan `pilihAyat` kini menerima callback opsional, tanpa duplikasi kode).
- Ayat sebelumnya / Ayat berikutnya: memindahkan ayat yang diperiksa tanpa menutup dialog, melintasi batas surah (2:286 -> 3:1, 3:1 -> 2:286). Di ayat pertama dan terakhir
  Al-Qur'an muncul pesan, bukan berpindah. Tombol sebelumnya/berikutnya di pembaca kini memakai fungsi yang sama (`ayatTetangga`), perilakunya tetap.
- Putar audio ayat ini: memutar bacaan yang benar untuk ayat yang sedang diperiksa (mekanisme FIX102 yang sama, qari per ayat), kapan saja, bukan hanya setelah salah baca.
- Kotak centang "Putar audio otomatis saat berpindah ayat" (bawaan mati agar ayat tidak terdengar sebelum Anda membacanya dari hafalan). Pilihan disimpan dan ikut direset
  bersama pengaturan Khatam.
- Saat berpindah: pengenalan suara dan audio yang berjalan dihentikan (termasuk jadwal pemutaran koreksi dari ayat sebelumnya, agar ayat baru tidak terputar tanpa sengaja),
  pembaca digambar ulang, ayat baru disembunyikan, petunjuk dan status dikembalikan ke awal ("Berpindah ke surah X, ayat Y. Tekan Mulai membaca."), tombol kembali
  "Mulai membaca"/"Hentikan". Hasil koreksi dicatat untuk ayat yang sedang aktif (pengingat cerdas hafalan).
- Posisi bacaan terakhir ikut berpindah ke ayat yang dipilih (sama dengan perilaku pembaca saat berpindah ayat).
- Tidak tampil pada sesi Muraja'ah cerdas, karena ayatnya ditentukan antrean sesi.

## Bahasa aktif
Seluruh teks baru (19 teks) memakai `tr(id, en)` dan mengikuti bahasa tampilan; tombol memiliki contentDescription dua bahasa; pesan status diumumkan TalkBack. Pemeriksa bahasa aktif lulus.

## Perbaikan alat bantu yang ditemukan saat verifikasi (sudah ada di FIX151, bukan dari perubahan ini)
- `tools/verify_project.py` salah menyatakan `.TimerJamBootReceiver` hilang karena kelasnya berada di `TimerJamService.kt`, bukan berkas bernama sama. Pemeriksa kini mencari
  deklarasi kelas di seluruh sumber. Tanpa perbaikan ini langkah verifikasi (dan build GitHub Actions) gagal.
- Dua uji lama sudah usang dan gagal juga pada FIX151 asli: `uji_kontrol_wifi_bluetooth.py` (mengunci versi 1.0.81) dan `uji_tombol_volume.py` (menghitung bentuk penulisan
  Pembicara lama). Tidak diubah di sini; tidak dipanggil oleh `verify_project.py`.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, `periksa_resource_strings.py`, dan `uji_koreksi_pilih_ayat.py` lulus (port logika ayat sebelumnya/berikutnya diuji pada 114 surah,
  total 6236 ayat, maju dan mundur seluruh Al-Qur'an); kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: buka Koreksi hafalan dengan suara, tekan Ayat berikutnya/sebelumnya (termasuk batas surah dan 1:1/114:6), pilih surah lalu
  pilih nomor ayat, bacakan ayat baru dan periksa hasilnya, aktifkan putar otomatis, putar audio manual, dalam bahasa Indonesia dan English, dengan dan tanpa TalkBack.
