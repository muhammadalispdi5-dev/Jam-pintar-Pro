# Tahap 26 — Validasi integritas cache waktu salat

## Perubahan
- `PrayerOnlineTimes.minutes()` kini hanya menerima nilai menit cache dalam rentang 0 sampai 1439.
- Nilai negatif, lebih besar dari 1439, atau nilai yang gagal dibaca dianggap tidak valid dan mengembalikan `null`, sehingga pemanggil dapat menggunakan jalur fallback yang sudah ada alih-alih menjadwalkan waktu yang tidak masuk akal.
- Pemeriksaan tanda tangan lokasi/metode sinkronisasi tetap dipertahankan.
- Tidak ada perubahan pada perhitungan waktu salat, koreksi menit pengguna, alarm, bahasa, maupun versi aplikasi.

## Pemeriksaan
- Perubahan diperiksa secara statis.
- Versi tetap `versionCode 68`, `versionName 1.0.68`.
- Build Android penuh dan uji perangkat belum dijalankan. Perlu uji khusus untuk cache rusak dan nilai di luar rentang.
