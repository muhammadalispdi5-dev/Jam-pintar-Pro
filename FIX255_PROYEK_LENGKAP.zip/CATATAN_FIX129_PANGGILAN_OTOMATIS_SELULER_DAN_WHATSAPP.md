# FIX129 — Panggilan otomatis seluler dan WhatsApp

- Panggilan seluler tetap menggunakan `ACTION_CALL` setelah izin runtime `CALL_PHONE` diberikan.
- WhatsApp Messenger dan WhatsApp Business kini meminta pilihan lisan `telepon suara` atau `telepon video` bila jenis belum disebutkan.
- Setelah jenis panggilan dikonfirmasi, aplikasi membuka chat tujuan dan layanan aksesibilitas khusus mencoba menekan kontrol yang labelnya cocok dengan jenis panggilan.
- Layanan hanya bekerja pada paket WhatsApp yang diminta, untuk permintaan yang kedaluwarsa setelah 45 detik, dan tidak membaca isi chat atau mengirim pesan.
- Pengguna harus mengaktifkan layanan `Bantuan Panggilan Jam Pintar Pro` secara manual di Setelan > Aksesibilitas. Android tidak mengizinkan aplikasi mengaktifkan layanan aksesibilitas secara diam-diam.
- Antarmuka WhatsApp berbeda menurut versi/bahasa/perangkat. Jika label tombol tidak dikenali, layanan tidak menekan kontrol lain secara spekulatif; pengguna perlu melakukan panggilan secara manual.
- Pemeriksaan ZIP dilakukan; kompilasi dan pengujian perangkat nyata tetap diperlukan.
