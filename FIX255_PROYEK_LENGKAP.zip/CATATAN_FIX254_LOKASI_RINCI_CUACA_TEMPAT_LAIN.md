# FIX254 - Lokasi rinci dan cuaca tempat lain lewat suara

1. "Saya berada di mana" kini menyebut alamat serinci mungkin (jalan, kelurahan, kecamatan/kota, provinsi, negara) dan ketelitian dalam meter (NamaLokasi.rinci; cadangan BigDataCloud). Pengenalan ucapan diperluas: "sekarang di mana", "alamat saya sekarang", "saya di jalan apa", "where am I".
2. Cuaca tempat lain: TempatDisebut.kt mengambil nama tempat dari ucapan ("cuaca di Mekkah", "prediksi BMKG di Madinah besok"). Koordinat dari tabel bawaan (Makkah, Madinah, Jeddah, Arafah, Mina, kota besar dunia dan Indonesia), lalu geokode Open-Meteo, lalu Geocoder perangkat. Kata "prediksi/perkiraan/ramalan" kini dikenali sebagai cuaca, termasuk bila ada kata BMKG.
3. BMKG hanya untuk Indonesia: tempat di Indonesia mendapat peringatan dini BMKG; luar negeri diberi catatan memakai Open-Meteo.
4. Petunjuk penggunaan: ID butir 38, EN butir 35.
Uji: kotlinc (t254) lulus; semua pemeriksa proyek lulus. Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Nama Geocoder bergantung pada layanan perangkat.
