# FIX238 — Pilihan jenis suara Tahajud

## Perubahan
- Tahajud kini memiliki "Pilih jenis suara untuk Tahajud" seperti Imsak, Matahari terbit, dan Dhuha: (1) suara azan bawaan atau suara umum, (2) suara pengingat Tahajud bawaan aplikasi, (3) berkas suara sendiri dari penyimpanan.
- Memilih berkas sendiri otomatis mengatur jenis suara Tahajud ke berkas itu. Tombol "Gunakan suara umum atau bawaan untuk Tahajud" mengembalikan ke bawaan.
- PrayerAlarmService memakai jenis suara Tahajud saat pengingat nyata maupun tes. Melodi awal/akhir dari FIX236/FIX237 tetap berlaku.
- AudioBawaanPengingat.kt baru: mencari audio bawaan di res/raw.

## Audio Tahajud
Audio yang Anda kirim (pengingat_shalat_tahajud.m4a, AAC, sekitar 92 detik) dimasukkan sebagai `app/src/main/res/raw/pemberitahuan_tahajud.m4a`. Karena berkasnya sudah ada, pilihan "Suara pengingat Tahajud bawaan aplikasi" tampil di dialog dan menjadi pilihan awal pada instalasi baru. Pengguna yang sudah memilih berkas sendiri tetap memakai pilihannya.
Bila berkas ini suatu saat dihapus, dialog otomatis hanya menampilkan dua pilihan dan Tahajud memakai suara azan/umum.

Versi tetap 1.0.86. Gradle belum dijalankan; pemeriksa proyek lulus.
