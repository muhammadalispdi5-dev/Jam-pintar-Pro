# FIX136 - Perintah suara "hidupkan/matikan Wi-Fi atau Bluetooth" kini menekan sakelarnya

Versi aplikasi tidak diubah (1.0.81). Basis: FIX135. Berkas diubah: `PanggilanWhatsAppAccessibilityService.kt`, `PerintahSuaraActivity.kt`,
`res/xml/panggilan_whatsapp_accessibility.xml`, `res/values/strings.xml`, `res/values-en/strings.xml`. Berkas baru: `PemilihSakelar.kt`,
`tools/uji_kontrol_wifi_bluetooth.py`.

## Gejala
Perintah suara untuk menghidupkan atau mematikan Wi-Fi dan Bluetooth hanya membuka layar pengaturannya; sakelarnya tidak ditekan.

## Penyebab
Sesuai catatan FIX130, Android 10+ tidak mengizinkan aplikasi biasa mengubah Wi-Fi, dan `BluetoothAdapter.enable/disable` tidak berlaku untuk aplikasi
yang menargetkan Android 13+ (proyek ini targetSdk 36). Perintah hanya membuka layar resmi dan tidak ada yang menekan sakelar di sana.
Satu-satunya jalur yang tersedia bagi aplikasi biasa adalah layanan aksesibilitas, yang sudah ada di aplikasi (Bantuan Panggilan WhatsApp).

## Perbaikan (tanpa fitur ganda: layanan aksesibilitas yang sama dipakai)
- `PanggilanWhatsAppAccessibilityService` kini juga menangani permintaan kontrol Wi-Fi/Bluetooth: setelah layar Pengaturan terbuka, ia mencari sakelar
  yang tepat, memeriksa statusnya, menekannya bila perlu, memverifikasi hasilnya (hingga 3 percobaan, batas 25 detik), lalu mengumumkan hasilnya
  (toast dan suara) dan menutup layar Pengaturan. Bila sudah sesuai, diumumkan "sudah aktif/mati" tanpa menekan apa pun.
- Pemilihan sakelar (`PemilihSakelar.kt`): hanya sakelar yang tampil dan aktif; utamakan yang teks/id-nya menyebut Wi-Fi atau Bluetooth;
  sakelar lain pada panel gabungan (data seluler, mode pesawat, hotspot, NFC, lokasi) tidak ditekan; bila tidak ada yang cocok dan ada beberapa
  sakelar, tidak ada yang ditekan (gagal dengan pesan, bukan menekan yang salah).
- `PerintahSuaraActivity`: bila layanan aksesibilitas aktif, Wi-Fi memakai halaman pengaturan penuh (sakelar utama selalu ada), Bluetooth memakai halaman
  Bluetooth, dan permintaan dicatat untuk layanan. Bila layanan belum aktif, perilaku lama dipertahankan (panel dibuka) ditambah petunjuk mengaktifkan
  layanan. Permintaan dibersihkan bila layar gagal dibuka. Hotspot, data seluler, mode pesawat, lokasi, dan NFC tidak berubah.
- Layanan hanya bertindak untuk permintaan yang baru diucapkan (kedaluwarsa 25 detik) dan hanya pada paket Pengaturan/System UI; konfigurasi
  ditambah paket itu dan `flagReportViewIds`. Deskripsi layanan diperbarui agar jujur tentang kegunaan barunya.

## Bahasa aktif
Sembilan string baru ada di `values` dan `values-en`; semua pengumuman memakai `BahasaAplikasi.bungkus`. Pemeriksa bahasa aktif dan resource string lulus.

## Yang perlu diperhatikan
- Layanan "Bantuan Panggilan Jam Pintar Pro" harus aktif di Setelan Aksesibilitas Android (cukup sekali; sama dengan yang dipakai untuk WhatsApp).
- Susunan layar Pengaturan berbeda antarmerek dan versi Android; pemilihnya sengaja konservatif. Bila gagal, pengguna mendengar pesan untuk mengubah
  sakelar secara manual. Bila ada merek yang gagal, catat merek/versi Android dan teks pada sakelar di layar tersebut.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: aktifkan layanan, ucapkan "matikan Wi-Fi", "hidupkan Wi-Fi", "matikan Bluetooth", "hidupkan Bluetooth"
  (dua bahasa), juga saat sudah dalam keadaan yang diminta, dan saat layanan belum aktif.
