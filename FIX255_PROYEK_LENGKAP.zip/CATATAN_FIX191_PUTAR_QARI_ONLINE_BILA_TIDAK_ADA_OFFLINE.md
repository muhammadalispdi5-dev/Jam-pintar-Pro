# FIX191 - Perintah suara memutar audio online bila qari yang diminta tidak ada di daftar offline

Versi aplikasi tidak diubah (1.0.82, versionCode 82). Basis: FIX190. Berkas diubah: `PemutarQuranService.kt`, `QariSuara.kt`, `KhatamActivity.kt`
(hanya mendelegasikan dua pembantu), `AndroidManifest.xml`. Berkas baru: `tools/uji_putar_qari_online.py`.

## Permintaan
Asisten tidak hanya memutar audio offline, tetapi juga dapat diperintah memutar audio secara online bila qari yang diminta tidak tersedia di daftar offline.

## Kondisi sebelum perubahan (dari pembacaan kode)
- FIX189 sudah menambah cadangan URL Alafasy dan pemilihan qari di jalur latar. Namun qari yang tidak ada di daftar offline tetap dijawab "tidak dikenali" dan tidak ada yang diputar. Daftar
  offline hanya memuat 22 qari per ayat dan qari anak dari cache; qari MP3Quran lain (mis. yang hanya tersedia sebagai audio per surah) tidak pernah dikenali oleh asisten.
- Pencarian berkas lokal menerima berkas qari mana pun. Bila qari yang diminta belum diunduh tetapi qari lain sudah, asisten memutar qari lain itu secara offline, bukan qari yang diminta secara online.

## Perubahan
1. Pencarian qari online (`QariSuara.cariOnline`): bila nama qari yang diucapkan tidak ada di daftar offline dan ada internet, katalog MP3Quran diambil (di thread latar, bukan thread utama), qari dicocokkan
   dengan algoritma fonetik yang sama, dipilih, dan diputar secara online. Toast "Qari belum ada di daftar offline; mencari secara online." Katalog yang diunduh juga disimpan ke berkas katalog Khatam
   bila berkas itu belum ada (tidak pernah menimpanya), jadi pencarian berikutnya tanpa jaringan.
2. Katalog lengkap offline: `QariSuara.cari` kini juga membaca berkas katalog lengkap yang disimpan Khatam (`katalog_qari_mp3quran.json`), bukan hanya cache qari anak, sehingga qari MP3Quran yang pernah
   termuat dikenali tanpa jaringan.
3. Pencocokan berkas lokal dengan qari yang diminta: saat ADA internet, hanya berkas qari yang diminta yang dipakai secara offline (dicocokkan lewat nama berkas dan nama folder unduhan Khatam); bagian yang
   belum tersimpan diputar online. Saat TIDAK ADA internet, berkas qari lain tetap dipakai agar pemutaran offline tidak hilang. Qari bawaan tanpa nama tersimpan dipetakan ke labelnya dari katalog.
   Indeks audio di-cache terpisah untuk kedua mode (`S` ketat, `L` longgar).
4. Pemberitahuan: "Audio untuk qari ini belum tersimpan di HP; memutar secara online." Bila seluruhnya harus online tetapi tidak ada internet: pesan jelas untuk mengunduh audionya di menu Khatam atau
   menghubungkan internet, tanpa menunggu pemutar gagal berulang kali. Qari yang tidak dikenali kini dibedakan: tidak ada di daftar offline maupun online, atau tidak dapat dicari karena tanpa internet.
5. Tidak menggandakan: cadangan URL Alafasy dan variasi bitrate dari FIX189 dipertahankan apa adanya; `sumberMoshafQari` dan `namaQariLatin` di Khatam kini memanggil versi bersama di `QariSuara`.
6. Izin baru `ACCESS_NETWORK_STATE` (izin biasa, tanpa dialog) untuk memeriksa ketersediaan internet. Bila status jaringan tidak terbaca, internet dianggap ada agar pemutaran online tidak diblokir.

## Bahasa aktif
Semua teks baru memakai `tr(id, en)`; tidak ada string XML baru. Pemeriksa bahasa aktif dan resource string lulus.

## Pemeriksaan dan batas
- `periksa_bahasa_aktif.py`, `periksa_resource_strings.py`, dan `uji_putar_qari_online.py` (port pencocokan berkas dan pemilihan rekaman katalog, plus kontrak sumber) lulus; kurung Kotlin seimbang.
- Kegagalan yang sudah ada pada FIX190 asli dan tidak terkait: `verify_project.py` ("Workflow build.yml tidak ditemukan", karena arsip tidak menyertakan `.github`), `uji_mikrofon_perintah_suara.py`, dan
  `verify_final.py` (petunjuk penggunaan). Tidak diubah di sini.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: (a) "putar surah Yasin dengan qari Saad Al-Ghamdi" (atau qari MP3Quran lain yang belum pernah dipilih) saat ada internet; (b) qari yang sudah diunduh
  sebagian; (c) qari yang diminta belum diunduh sementara qari lain sudah (harus online); (d) mode pesawat dengan audio qari lain tersimpan (harus memutar offline) dan tanpa audio apa pun (harus ada pesan);
  (e) nama qari yang sengaja salah; dalam bahasa Indonesia dan English.
