# Tahap 24 — Tampilkan pesan validasi sinkronisasi yang tepat

## Perubahan
- Sebelumnya, `PrayerOnlineTimes.sync()` membuat pesan spesifik untuk format respons yang tidak dikenali, data jadwal yang tidak lengkap, dan server yang tidak dapat dijangkau, tetapi blok `catch` menggantinya dengan pesan kegagalan umum.
- Sekarang, kegagalan validasi yang sengaja dilempar sebagai `IllegalStateException` mempertahankan pesan yang sudah diterjemahkan melalui `BahasaAplikasi.teks()`.
- Kesalahan jaringan atau kesalahan teknis yang tidak memiliki pesan validasi khusus tetap menampilkan pesan umum yang mudah dipahami.
- Fallback jadwal offline tetap dipertahankan; tahap ini tidak mengubah rumus waktu salat atau pengaturan alarm.

## Pemeriksaan
- Perubahan diverifikasi secara statis dengan memeriksa alur `throw IllegalStateException(...)` ke blok `catch`.
- Arsip proyek dibangun ulang dari direktori proyek sebenarnya, bukan dengan membungkus seluruh arsip tahap terdahulu berulang-ulang.
- Build Android penuh dan uji jaringan/perangkat belum dilakukan.
- Versi aplikasi tetap 1.0.68 (`versionCode 68`).
