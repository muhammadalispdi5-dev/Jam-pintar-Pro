# Laporan audit Jam Pintar Pro 1.0.48

## Ruang lingkup
Audit statis terhadap sumber proyek 1.0.46 yang diterima, kemudian perbaikan sumber untuk versi 1.0.48. Pemeriksaan mencakup konfigurasi build, manifest, alarm waktu salat, pemulihan Mode Jangan Ganggu, pengumuman waktu, dan penggabungan segmen kalender/libur dalam bahasa aktif.

## Perbaikan sumber

1. **Pemulihan Mode Jangan Ganggu**
   - Filter gangguan sebelum aplikasi mengubah mode disimpan bersama waktu akhir dalam satu transaksi SharedPreferences.
   - Pemulihan tidak membuang catatan status jika akses kebijakan notifikasi dicabut atau pemanggilan pemulihan gagal.
   - Alarm pemulihan terpisah tetap dijadwalkan, dan status aktif dijadwalkan ulang saat aplikasi memproses boot/update/perubahan waktu.
   - Pengaturan menonaktifkan Dzuhur Jumat sekarang juga diterapkan pada alarm Jangan Ganggu.

2. **Penjadwalan**
   - Receiver memproses ulang jadwal setelah jam, tanggal, atau zona waktu perangkat berubah.
   - Perubahan akses Mode Jangan Ganggu memicu pemeriksaan ulang pemulihan.
   - Saat Mode Jangan Ganggu otomatis diaktifkan pada Android 12+, halaman pengaturan menawarkan izin alarm tepat waktu bila belum tersedia; ada tombol manual untuk membuka izin tersebut.

3. **Bahasa pengucapan**
   - Segmen tanggal Masehi, Hijriah, pasaran, serta informasi libur telah diberi susunan khusus untuk Indonesia, English, Arab, dan Jawa krama.
   - Data nama hari libur daring yang tidak dikenal tidak dibiarkan menyisipkan kalimat Indonesia ke rangkaian Jawa; untuk nama yang belum dapat dipadankan, digunakan keterangan umum dalam bahasa aktif.
   - Bilangan Jawa 11–29 dan puluhan diperbarui. Bentuk angka 17–19 menggunakan pitulas, wolulas, sangalas; 21–25 menggunakan selikur, kalih likur, tiga likur, sekawan likur, selangkung. Tahun menggunakan pola ribuan dan puluhan biasa.
   - Pengucapan jam-menit-detik tidak memakai kata penghubung antara menit dan detik.

## Hasil pemeriksaan yang benar-benar dilakukan

- Arsip ZIP sumber awal dapat dibuka dan lolos `testzip()`.
- Parser Kotlin dijalankan untuk memeriksa kesalahan sintaks. Pemeriksaan penuh dengan kotlinc tidak dapat menyelesaikan referensi Android karena Android SDK tidak tersedia; tidak ditemukan laporan kesalahan parser setelah perbaikan.
- Helper bilangan Jawa dikompilasi dan diuji terpisah menggunakan stub sederhana. Contoh tahun 2026 menghasilkan `kalih ewu kalih dasa enem`.
- Manifest dan berkas XML diperiksa secara sintaksis.
- Nama artefak workflow disamakan dengan petunjuk README menjadi `JamPintarPro-APK`.

## Hal yang belum diverifikasi

- **Belum ada build APK penuh** melalui Gradle/GitHub Actions pada audit ini.
- Belum diuji pada perangkat Android apakah alarm pemulihan Jangan Ganggu benar-benar dijalankan tepat waktu pada semua vendor; Doze, pembatasan baterai, izin khusus, dan perubahan manual oleh pengguna dapat memengaruhi perilaku.
- Belum diuji audio langsung dengan mesin TTS bahasa Jawa. Locale `jv-ID` hanya permintaan bahasa; ketersediaan dan kewajaran suara bergantung pada mesin TTS di perangkat.
- Bahasa Jawa diselaraskan ke ragam krama dan rujukan bilangan krama. Istilah *Krama Inggil* secara linguistik bukan sekadar mengganti semua angka; penutur Jawa krama tetap perlu menilai keluwesan tuturan.
- Jadwal salat tetap perlu diuji dengan lokasi nyata, koreksi waktu, mode offline/online, dan pergantian tanggal.

## Skenario wajib sebelum rilis

1. Build `assembleRelease` di GitHub Actions dan pastikan artefak APK tersedia.
2. Dengan filter awal Android disetel ke Normal, uji durasi DND 5 menit; pastikan kembali ke Normal.
3. Ulangi ketika filter awal disetel ke mode lain; pastikan mode awal yang sama dipulihkan.
4. Uji layar mati, Doze/penghemat baterai, restart perangkat, perubahan zona waktu, dan izin DND dicabut/diberikan kembali.
5. Uji pengumuman waktu 16:17:20 untuk semua bahasa, lalu aktifkan bergantian tanggal Masehi, Hijriah, pasaran, libur nasional, dan cuti bersama. Pastikan rangkaian Jawa tidak menyisipkan kalimat Indonesia dan dengarkan hasilnya dengan penutur Jawa krama.
6. Uji interval otomatis, jam mulai/berhenti, lewat tengah malam, perubahan bahasa, dan mesin TTS yang tidak mendukung `jv-ID`.


## Perbaikan lanjutan izin alarm tepat waktu (1.0.48)

- Mengganti deklarasi ganda `USE_EXACT_ALARM` + `SCHEDULE_EXACT_ALARM` menjadi hanya `SCHEDULE_EXACT_ALARM` tanpa `maxSdkVersion`, sehingga Android 12+ menggunakan jalur akses khusus yang memang dapat diaktifkan pengguna.
- Menambahkan `ExactAlarmPermissionReceiver` untuk menjadwalkan ulang alarm ketika Android memberi akses tersebut.
- Tombol pengaturan alarm membuka halaman izin yang ditujukan ke paket aplikasi.
- Versi proyek dinaikkan ke 1.0.48 (versionCode 48).
- Perubahan ini divalidasi secara statis; build Gradle penuh dan pengujian pada perangkat Android 16 belum dilakukan dalam lingkungan ini.
