# FIX115 — Tanda "$" pada ucapan info libur nasional dan cuti bersama

Versi aplikasi tidak diubah. Basis: FIX114. Berkas diubah: `HariLibur.kt`, `tools/baseline_bahasa_aktif.json`.

## Masalah
Setelah FIX114, mesin suara masih membacakan simbol dolar dan nama variabel ("dolar label ...", "dolar tanggal") pada info libur,
terutama pada jawaban perintah suara libur spesifik dan kalimat Indonesia/English hasil `dua(...)` di `jawabanKhusus`.
Penyebabnya sama dengan FIX53: interpolasi `$nama` / `${...}` pada teks yang diucapkan.

## Perbaikan
- Seluruh interpolasi `$nama` dan `${...}` di `HariLibur.kt` diganti penggabungan teks biasa (`"..." + (nilai) + "..."`),
  untuk kelima bahasa (Indonesia, English, Arab, Jawa, Sunda). Tidak ada lagi karakter "$" di berkas ini.
- Isi kalimat dan urutan kata tidak diubah.
- Baseline pemeriksa bahasa aktif `HariLibur.kt` dari 61 menjadi 62 (kalimat Indonesia yang sama, kini terbaca pemeriksa
  karena tidak lagi berada dalam templat).

## Pemeriksaan
- Tidak ada "$" tersisa di `HariLibur.kt`; jumlah kurung (), {}, [] seimbang.
- `tools/verify_project.py`, `tools/periksa_bahasa_aktif.py`, `tools/uji_nama_libur.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat.

## Catatan
Interpolasi "$" masih ada di luar info libur (mis. pesan "Tidak ditemukan pesan masuk terbaru dari $nama" di
`PerintahSuaraActivity.kt` dan teks pengingat di `HafalanSrsReceiver.kt`); tidak diubah karena di luar permintaan ini.

## Lanjutan: tanda "$" di bagian lain
Interpolasi `$nama` / `${...}` pada teks yang tampil atau diucapkan juga diganti penggabungan teks biasa di:
- `PerintahSuaraActivity.kt` (pesan "tidak ditemukan pesan masuk dari <nama>", lima bahasa);
- `HafalanSrsReceiver.kt` (teks pengingat ayat yang perlu diulang);
- `KhatamActivity.kt` (jumlah pendamping latihan);
- `PemutarQuranService.kt` dan `GoncanganSuaraService.kt` (label kunci daya, tidak diucapkan; diseragamkan).
Sisa karakter "$" di proyek hanya jangkar regex (`...x$`) dan rujukan grup regex `"\$1"`, tidak pernah diucapkan.
Placeholder `%1$s` pada `strings.xml` semuanya dipanggil dengan argumen (diperiksa), jadi tidak terbaca harfiah.
`verify_project.py` dan `periksa_bahasa_aktif.py` lulus; BELUM dikompilasi dan BELUM diuji di perangkat.
