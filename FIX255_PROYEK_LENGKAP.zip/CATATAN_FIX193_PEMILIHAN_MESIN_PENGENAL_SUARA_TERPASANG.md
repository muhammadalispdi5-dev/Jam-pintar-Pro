FIX193 – Penyempurnaan pemakaian mesin pengenal suara terpasang
Versi aplikasi dipertahankan: versionCode 82 / versionName 1.0.82

Perubahan:
1. Daftar mesin diambil dari layanan Android RecognitionService yang aktif, diekspor, dan memiliki izin BIND_SPEECH_RECOGNITION_SERVICE.
2. Pengguna dapat memilih mesin tertentu atau menghapus pilihan untuk memakai mesin bawaan Android.
3. Daftar diperbarui langsung dengan recreate() setelah pilihan berubah, sehingga status pilihan yang dibacakan TalkBack juga diperbarui.
4. Pemeriksaan dukungan bahasa dan permintaan unduhan model dibuat menggunakan komponen mesin pilihan melalui SpeechRecognizer.createSpeechRecognizer(context, component).
5. PerintahSuaraActivity juga menggunakan komponen mesin yang sama untuk pengenalan suara langsung.
6. Jika mesin yang tersimpan sudah dihapus atau dinonaktifkan, aplikasi memberi penjelasan dan meminta pengguna memilih mesin lain; tidak diam-diam menganggap mesin itu masih tersedia.
7. Label menjelaskan bahwa mesin yang dipilih adalah mesin pengenal ucapan (speech-to-text), bukan mesin TTS/pembaca layar.

Catatan kompatibilitas:
- Pemeriksaan status model dan permintaan unduhan melalui API Android SpeechRecognizer tersedia pada Android 13 (API 33) ke atas.
- Pada Android lebih lama, halaman tetap menyediakan pengaturan layanan suara Android sebagai jalur manual.
- Mesin yang terpasang belum tentu menyediakan model offline untuk semua bahasa. Layanan tersebut menentukan bahasa dan model yang didukung.
- Permintaan unduhan dikirim ke mesin pilihan, tetapi proses dan progres unduhan tetap dikelola oleh mesin/layanan itu.
- Jalur dialog sistem ACTION_RECOGNIZE_SPEECH yang mungkin dipakai sebagai cadangan tidak dapat dipastikan menggunakan mesin pilihan secara eksplisit; jalur utama SpeechRecognizer langsung memakai komponen pilihan dan memerlukan izin mikrofon aplikasi.

Pemeriksaan yang dilakukan pada arsip:
- Semua berkas XML divalidasi dengan parser XML.
- Arsip ZIP diuji integritasnya.
- Pemeriksaan keseimbangan kurawal dan tanda kurung pada tiga berkas Kotlin yang diubah.
- Versi aplikasi diperiksa tetap 1.0.82.

Belum dilakukan kompilasi Gradle/Android SDK maupun pengujian perangkat. Jalankan GitHub Actions untuk memastikan kompilasi dan uji pada ponsel dengan beberapa mesin pengenal suara terpasang.
