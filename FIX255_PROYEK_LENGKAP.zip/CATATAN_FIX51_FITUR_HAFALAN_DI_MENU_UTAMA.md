# FIX51 — Latihan hafalan dipindahkan ke menu utama Khatam Al-Qur'an

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX50. Perubahan: `KhatamActivity.kt`.

## Perubahan
- Bagian baru **LATIHAN HAFALAN** di menu utama Khatam (di bawah "Bacaan dan Navigasi") berisi dua tombol:
  - Koreksi otomatis dengan pengenalan suara
  - Latihan hafalan tanpa mikrofon
- Kedua item dihapus dari Pengaturan Khatam > Pengaturan Hafalan, yang kini hanya berisi mode hafalan audio, jumlah pengulangan ayat, dan jeda antar ayat.
- `pastikanDiPembaca()` kini aman dipanggil dari menu utama: memuat posisi bacaan terakhir yang tersimpan, memuat cache teks bila perlu, dan menampilkan dialog "Unduh sekarang" bila teks Al-Qur'an belum diunduh (sebelumnya hanya toast).
- Logika pengenalan suara, perbandingan kata, mode senyap TalkBack, dan alur latihan mandiri tidak diubah.

## Pemeriksaan
- Keseimbangan tanda kurung Kotlin: sesuai.
- BELUM dikompilasi dan BELUM diuji di perangkat. Jalankan GitHub Actions lalu uji di HP.
