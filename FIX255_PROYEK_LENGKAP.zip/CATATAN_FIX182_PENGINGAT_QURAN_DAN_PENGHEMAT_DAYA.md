# FIX182 – Pengingat membaca Al-Qur'an dan Penghemat Daya Global

## Dasar keputusan pengingat
- Pengingat lama tidak dihapus karena fungsinya adalah pengingat rutin untuk membaca Al-Qur'an.
- Fitur `Pengingat cerdas hafalan` tetap berada di Pengaturan Hafalan dan khusus mengatur pengulangan ayat/murajaah.
- Label pengingat lama diubah menjadi `Pengingat membaca Al-Qur'an` agar tidak terkesan menduplikasi pengingat hafalan.
- Preferensi dan jadwal lama `pengingat_aktif`, jam, menit, serta pilihan suaranya tetap dipertahankan.

## Penghemat daya
- Ditambahkan `PenghematDaya.kt` dan `PenghematDayaActivity`.
- Pintasan ditempatkan di beranda dalam bagian `Pengaturan seluruh aplikasi`, terpisah dari kategori Baterai (kategori Baterai hanya mengatur pengumuman baterai).
- Pengaturan menggunakan SharedPreferences `pengaturan`, sehingga ikut pencadangan, pemulihan, dan reset semua pengaturan yang sudah ada.
- Pilihan: nonaktif, hemat tinggi 20%, seimbang 35%, ringan 50% kecerahan layar.
- `Halaman.onResume()` menerapkan pengaturan pada seluruh halaman turunan `Halaman`; layar perintah suara juga menerapkannya saat dibuka.
- Saat dimatikan, `BRIGHTNESS_OVERRIDE_NONE` memulihkan kendali kecerahan normal Android.
- Mode tidak menonaktifkan alarm, azan, jadwal salat, pengingat, asisten suara, atau pemutar audio.

## Batasan yang disengaja
Mode ini adalah penghemat daya pada tingkat aplikasi, terutama melalui pengurangan kecerahan layar saat aplikasi tampil. Ia tidak mengubah mode hemat daya sistem Android dan tidak mengklaim mengendalikan konsumsi CPU/radio dari semua layanan atau aplikasi lain.

## Versi
Tetap `versionCode=82`, `versionName=1.0.82`.
