# FIX226 - Doa Sehari-hari Sesuai Sunnah (versi 1.0.86, versionCode 86)

- Menu baru di beranda: "Doa Sehari-hari Sesuai Sunnah", sebelum menu Taaruf/Doa.
- 89 doa dalam 14 kategori: tidur dan bangun, makan dan minum, pakaian, bersuci dan toilet, rumah dan masjid, adzan dan shalat, dzikir pagi dan petang, perjalanan, kesulitan/sakit/musibah, permohonan umum, keluarga dan pernikahan, pergaulan, cuaca, wafat dan ziarah kubur.
- Setiap doa: Arab, cara baca Latin, arti (Indonesia/Inggris), kapan dibaca, sumber dan derajat (shahih/hasan). Sumber: Al-Qur'an, Al-Bukhari, Muslim, Abu Dawud, At-Tirmidzi, An-Nasa'i, Ibnu Majah, Ahmad.
- Dapat didengarkan: bacaan Arab (perlu suara Arab terpasang), cara baca Latin, dan arti. Ada pencarian, salin, bagikan, ukuran huruf, doa sebelumnya/berikutnya.
- Perintah suara: "doa sebelum makan", "doa naik kendaraan", dst. langsung membuka doanya; "doa harian" membuka beranda.
- Berkas: DoaHarianData.kt, DoaHarianActivity.kt (baru); perubahan pada manifest, MainActivity, PerintahSuaraActivity, strings.
- Catatan: derajat hadits mengikuti penilaian umum ulama hadits; teks Arab dan Latin sebaiknya ditinjau ustadz sebelum dipakai sebagai rujukan baku. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
