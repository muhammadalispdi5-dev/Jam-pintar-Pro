# FIX84 - Perintah suara dari pemicu Beritahu Saya (ketuk tahan)

## Cara memakai
- Ketuk tahan ikon Beritahu Saya di layar depan HP, lalu pilih pintasan "Perintah suara" (Android 7.1 ke atas).
  Dengan TalkBack: ketuk dua kali dan tahan pada ikon, lalu pilih "Perintah suara".
- Di dalam aplikasi: ketuk tahan saklar "Aktifkan pemicu Beritahu Saya" di halaman utama.
- Layar pengenalan suara sistem terbuka (id-ID atau en-US sesuai bahasa tampilan; tanpa izin mikrofon aplikasi).
- Pemicu Beritahu Saya harus aktif; bila nonaktif muncul petunjuk yang sama dengan pemicu biasa.

## Perintah
- Waktu: "informasikan waktu", "jam berapa", "tell me the time".
- Tanggal: "informasikan tanggal", "hari ini", "tell me the date".
- Keduanya: "informasikan waktu dan tanggal", "beritahu saya", "tell me".
  Pembacaan memakai suara jam dan suara tanggal yang sama dengan pemicu biasa (termasuk libur dan info sholat).
- Al-Qur'an: "putarkan surah Al Baqarah", "putar surah 36 ayat 5", "putar juz 30", "bacakan ayat 255", "play surah Yasin verse 5".
  Diteruskan ke Khatam (penafsir yang sama dengan FIX80), yang memutar audionya. Mengikuti saklar
  "Perintah suara untuk memutar" di Pengaturan Pemutaran Audio; bila mati, muncul pesan untuk menyalakannya.
  Teks Al-Qur'an harus sudah diunduh di Khatam.
- Perintah tak dikenal: getar singkat dan pesan contoh perintah.

## Bahasa
Semua teks baru ada di values dan values-en; layar mengikuti bahasa tampilan utama (attachBaseContext). Pengenalan suara id-ID/en-US mengikuti bahasa tampilan.
Pengaturan "Suara TalkBack saat mikrofon dipakai" (FIX83) berlaku: bila dimatikan, TalkBack disenyapkan, ada getar, jeda 0,8 detik, tanpa teks petunjuk.

## Berkas
- Baru: PerintahSuaraActivity.kt (aktivitas + penafsir PerintahSuara), res/xml/shortcuts.xml.
- Ubah: AndroidManifest.xml (aktivitas baru, meta-data pintasan di BeritahuSayaActivity, Khatam launchMode singleTask),
  MainActivity.kt (ketuk tahan saklar), KhatamActivity.kt (onNewIntent + EXTRA_PERINTAH_SUARA), strings id/en.

## Batasan
- Ketuk tahan WIDGET Beritahu Saya dikendalikan peluncur HP (menu ubah ukuran/hapus), tidak bisa diambil alih aplikasi.
  Gunakan ketuk tahan ikon aplikasi Beritahu Saya atau saklar di halaman utama.
- Pintasan butuh Android 7.1+; di Android 7.0 gunakan ketuk tahan saklar di aplikasi.
- Khatam kini singleTask: perintah dari luar memakai Khatam yang sudah terbuka (tidak ada dua pemutar sekaligus).
- Belum dikompilasi/diuji (tidak ada kompiler di lingkungan kerja); hanya diperiksa kesetimbangan kurung dan XML.

# FIX85 - Perintah suara dari widget Beritahu Saya (perbaikan setelah uji)
Uji lapangan FIX84: ketuk tahan widget Beritahu Saya di layar depan tidak bereaksi. Penyebab: ketuk tahan widget dikuasai
peluncur HP, bukan aplikasi, sehingga tidak dapat langsung dipasangi aksi. Perbaikan:
- Widget kini punya dua tombol berdampingan: "Beritahu Saya" (membacakan waktu) dan "Perintah suara" (satu ketukan, tanpa tahan).
  Lebar minimal widget menjadi 180dp; widget lama perlu dihapus lalu dipasang ulang agar tata letak baru terpakai.
- Menu ketuk tahan widget di Android 12+ pada peluncur yang menampilkan "Pengaturan widget": layar itu membuka perintah suara
  (BeritahuSayaWidgetConfigActivity). Bergantung pada peluncur; peluncur yang tidak mendukung tidak menampilkannya.
- Pintasan dinamis "Perintah suara" didaftarkan di MainActivity (selain pintasan statis FIX84) untuk menu ketuk tahan ikon aplikasi
  Beritahu Saya; label mengikuti bahasa aktif. Muncul setelah aplikasi dibuka sekali.
- Ketuk tahan saklar pemicu di halaman utama aplikasi tetap berfungsi (FIX84).
Belum dikompilasi/diuji.

# FIX86 - Satu tombol Beritahu Saya langsung ke perintah suara
Permintaan: cukup ketuk tahan tombol Beritahu Saya di layar depan agar perintah suara aktif otomatis.
Kendala teknis: widget hanya mendukung ketuk biasa; ketuk tahan dikuasai peluncur HP dan tidak dapat dideteksi aplikasi.
Pengganti terdekat:
- Saklar baru di halaman utama (bagian pemicu Beritahu Saya): "Sekali ketuk Beritahu Saya langsung perintah suara".
  Aktif = widget menjadi SATU tombol Beritahu Saya (tombol Perintah suara terpisah disembunyikan); sekali ketuk membuka
  perintah suara. Ikon aplikasi Beritahu Saya ikut berperilaku sama. Nonaktif (bawaan) = ketuk membacakan waktu seperti dulu.
- Ketukan kedua saat pembacaan waktu masih berjalan menghentikan bacaan dan membuka perintah suara (berlaku di kedua mode).
- Pengaturan: Prefs.beritahuSayaLangsungSuara (kunci beritahu_saya_langsung_suara). Teks id/en ditambahkan.
Belum dikompilasi/diuji.
