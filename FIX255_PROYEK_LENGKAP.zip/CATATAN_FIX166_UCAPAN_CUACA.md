# FIX166 - Perbaikan pengucapan informasi cuaca

## Masalah
Informasi cuaca terdengar hanya sebagai kata "dolar" berulang, sehingga isinya tidak dapat dipahami. Itu berarti kalimat yang sampai ke mesin suara masih berisi simbol templat dolar, bukan nilai yang sudah terisi. Pada log kompilasi sebelumnya, pipeline build juga terbukti merusak teks Kotlin yang memakai templat dolar bersarang.

## Perbaikan
- Seluruh kalimat cuaca (Open-Meteo, cadangan wttr.in, dan pesan penolakan server) kini disusun dengan penyambungan teks biasa, tanpa templat dolar sama sekali, sehingga isinya (lokasi, kondisi, suhu, terasa seperti, kelembapan, angin) selalu terisi.
- Lapisan pengaman di `Pembicara.kt`: sebelum diucapkan, sisa simbol dolar, templat `${...}`, dan kurung kurawal dibuang, sehingga mesin suara tidak pernah membacanya sebagai kata "dolar". Pengaman ini berlaku untuk semua pengumuman, bukan hanya cuaca.
- Teks tetap mengikuti bahasa aktif (tr(id, en)); pemeriksa bahasa dan resource string lulus.
- Belum dikompilasi dan belum diuji di perangkat.
