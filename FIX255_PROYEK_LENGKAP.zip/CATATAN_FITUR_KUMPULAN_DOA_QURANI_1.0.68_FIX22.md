# Jam Pintar Pro 1.0.68 — FIX22

## Penambahan fitur
- Menambahkan menu **Kumpulan doa Al-Qur'an / Collection of Qur'anic supplications** di bagian Ta'aruf > Saling Mendoakan.
- Menyediakan enam doa atau kutipan doa Qur'ani beserta teks Arab, transliterasi, makna sesuai bahasa aplikasi, dan rujukan surah/ayat.
- Pengguna dapat membaca detail doa lalu memilih **Gunakan doa ini / Use this supplication** untuk memasukkan teks Arab, makna, dan rujukan ke kolom doa. Pengguna kemudian dapat menyunting, menyimpan, atau membagikannya.
- Teks UI di halaman Ta'aruf dan Saling Mendoakan disesuaikan langsung dengan bahasa aktif aplikasi (Indonesia atau Inggris). Teks Arab ayat tetap dalam bahasa aslinya.
- Draf doa dan nama penerima disimpan lokal di perangkat; tidak ada pengunggahan otomatis.
- Versi tetap `versionName = 1.0.68` dan `versionCode = 68`.

## Sumber doa
Semua teks doa Arab yang dimasukkan merupakan kutipan ayat Al-Qur'an, dengan rujukan yang ditampilkan di aplikasi:
- Al-Baqarah 2:201
- Ali 'Imran 3:8
- Ibrahim 14:41
- Al-Hasyr 59:10
- Al-Furqan 25:74
- Ghafir 40:7 (bagian dari doa para malaikat)

Terjemahan disajikan sebagai makna dalam bahasa aktif aplikasi. Referensi dapat diperiksa di mushaf Al-Qur'an atau sumber Al-Qur'an tepercaya.

## Pemeriksaan
- `tools/verify_project.py`: lulus.
- Struktur arsip ZIP diperiksa setelah dibuat.
- Build Gradle dan pengujian pada perangkat belum dijalankan di lingkungan pembuatan arsip ini.
