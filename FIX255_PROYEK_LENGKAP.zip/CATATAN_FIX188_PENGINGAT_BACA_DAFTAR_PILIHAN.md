# FIX188 - Daftar pilihan Pengingat membaca Al-Qur'an tidak tampil

Basis: FIX187. Versi aplikasi tidak diubah.

## Penyebab sebenarnya
Dialog "Pengingat membaca Al-Qur'an" (Pengaturan Khatam) memakai `setMessage(status)` bersama `setItems(...)`. AlertDialog Android menampilkan salah satu saja: bila ada pesan, daftar pilihan tidak digambar. Akibatnya pengguna hanya melihat/membaca teks status dan tombol Kembali; waktu, hari, jenis suara, tes, dan sakelar tidak dapat dipilih, baik dengan sentuhan maupun pembaca layar. Pengingat cerdas hafalan tidak terkena karena judul dan statusnya dipasang lewat `judulDenganPesan` (judul khusus).

Jadi perbaikan FIX186 dan FIX187 (beberapa waktu, hari, suara alarm/notifikasi/berkas, pemilih waktu aksesibel) sudah ada di kode, tetapi menu yang memuatnya tidak pernah tampil.

## Perbaikan
- Status dipasang lewat `judulDenganPesan`, seperti Pengingat cerdas hafalan: judul dan status dibaca sekali oleh pembaca layar, lalu daftar pilihan (waktu, hari, suara notifikasi, tes, aktif/nonaktif) tampil dan dapat difokus satu per satu.
- Seluruh dialog di semua berkas diperiksa: tidak ada lagi dialog dengan setMessage bersama daftar pilihan. Uji statis `tools/uji_fix186_pengingat_baca.py` kini menolak pola itu (terbukti menangkapnya pada FIX184 asli).
- Pemeriksa bahasa dan resource string lulus. Belum dikompilasi dan belum diuji di perangkat.
