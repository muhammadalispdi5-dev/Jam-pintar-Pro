# FIX47 — Perbaikan Equalizer Audio

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX46. Perubahan hanya di `KhatamActivity.kt`.

## Penyebab
- Equalizer dibuat ulang untuk setiap ayat tepat saat audio siap, lalu dilepas setiap kali audio berhenti; saat audio belum diputar pengaturan "belum aktif" dan hanya menunggu putaran berikutnya.
- Penguatan preset terlalu kecil (maksimum sekitar ±3 dB) sehingga nyaris tidak terdengar.
- Efek diaktifkan setelah level pita diatur; sebagian perangkat mengabaikan level pita saat efek belum aktif.

## Perbaikan
- Satu sesi audio bersama (`AudioManager.generateAudioSessionId`) dipasang ke setiap pemutar sebelum prepare. Equalizer dibuat sekali, dapat diatur kapan saja, dan langsung berlaku pada audio yang sedang diputar. Cadangan: bila sesi bersama ditolak, dipakai sesi milik pemutar.
- Penguatan preset dinaikkan (Vokal, Bass, Treble sekitar ±3 s.d. 6 dB) menurut frekuensi pusat tiap pita.
- Efek diaktifkan lebih dulu; preset Bass juga memakai BassBoost bila perangkat mendukung.
- Preset baru **Kustom**: satu penggeser per pita (langkah 1 dB), terdengar langsung saat digeser, tombol Simpan, Setel ulang, dan Batal. Label penggeser memuat frekuensi dan dB untuk TalkBack.
- Pesan status kini jujur: menyebut jumlah pita perangkat atau alasan efek tidak tersedia.

## Pemeriksaan dan batas
- `tools/verify_project.py`: LULUS; keseimbangan tanda kurung Kotlin sesuai.
- BELUM dikompilasi dan BELUM diuji di perangkat. Efek tetap bergantung pada dukungan perangkat/ROM.
- Equalizer hanya memengaruhi murattal (MediaPlayer), tidak memengaruhi suara terjemahan dari Text-to-Speech.
