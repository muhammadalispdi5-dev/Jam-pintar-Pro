# FIX46 — Perbaikan Koreksi Hafalan (suara) dan Latihan Mandiri

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX45-1. Perubahan: `KhatamActivity.kt`, `AndroidManifest.xml`.

## Penyebab
1. Kedua fitur dibuka dari menu pengaturan, termasuk saat layar pembaca belum tampil. Referensi `ayatArab` kosong/usang sehingga ayat tidak pernah tersembunyi. Penanda `sedangDiPembaca` juga tidak pernah bernilai true.
2. Koreksi suara hanya memakai `SpeechRecognizer` langsung. Bila layanan gagal (kode CLIENT/SERVER/BUSY/bahasa tidak didukung) atau tidak terdeteksi, fitur berhenti tanpa jalur cadangan.
3. Setelah hasil muncul, tombol "Mulai membaca" berubah menjadi "Tampilkan ayat" sehingga tidak bisa mengulang.
4. Perbandingan kata terlalu ketat: ejaan mushaf (العٰلمين) dibanding hasil suara (العالمين), ة/ه, bentuk hamzah, dan basmalah di ayat 1 dihitung sebagai kesalahan.
5. Manifest belum mendeklarasikan visibilitas aksi `RECOGNIZE_SPEECH` (Android 11+).

## Perbaikan
- Kedua fitur kini memastikan layar pembaca tampil lebih dulu (`pastikanDiPembaca`), lalu menyembunyikan ayat.
- Koreksi suara: jalur layanan langsung + jalur cadangan layar suara sistem (`startActivityForResult`), hasil sementara, hingga 5 kandidat, jeda diam lebih panjang, pesan kesalahan lebih jelas.
- Setelah hasil: "Ulangi membaca" dan "Sembunyikan/Tampilkan ayat" dapat dipakai berulang.
- Pembanding kata lebih toleran terhadap ejaan, menampilkan kata yang berbeda/terlewat, dan basmalah ayat pertama bersifat opsional.
- Latihan mandiri: satu alur yang konsisten, petunjuk kata pertama, tombol "Ulangi latihan".
- `sedangDiPembaca` kini diset true di layar pembaca, sehingga tombol Kembali Android menuju menu Khatam sesuai rancangan FIX34.

## Pemeriksaan
- `tools/verify_project.py`: LULUS. Keseimbangan tanda kurung Kotlin: sesuai. Manifest XML: valid.
- `tools/verify_final.py` gagal pada berkas dasar FIX45-1 maupun hasil ini (pemeriksa lama mencari kata kunci audio yang sudah tidak ada); tidak terkait perubahan ini.
- BELUM dikompilasi (Gradle/kotlinc tidak tersedia di lingkungan ini) dan BELUM diuji di perangkat. Jalankan GitHub Actions lalu uji di HP.
- Pengenalan suara tetap tidak menilai tajwid/makhraj; hasilnya perkiraan.
