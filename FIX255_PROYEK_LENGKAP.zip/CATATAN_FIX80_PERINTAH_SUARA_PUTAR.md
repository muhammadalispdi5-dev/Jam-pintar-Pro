# FIX80 - Perintah suara untuk memutar ayat/surah/juz
Halaman utama Khatam > PEMUTARAN AUDIO > tombol "Putar dengan perintah suara".
Layar pengenalan suara sistem (id-ID atau en-US sesuai bahasa tampilan) dibuka; tidak perlu izin mikrofon aplikasi.
Contoh: "putar surah Al Baqarah", "putar surah 36 ayat 5", "putar ayat 255", "putar juz 30", "play surah Yasin verse 5".
Nama surah dicocokkan dari daftar nama Latin (daftarBerkasTerjemahanId) dan englishName; kata bilangan Indonesia/Inggris diubah menjadi angka.
Hasil diteruskan ke prosesPencarianAudioTerstruktur (jalur yang sama dengan "Cari juz, surah, atau ayat"). Belum dikompilasi/diuji.

## Saklar (tambahan)
Pengaturan Khatam > Pengaturan Pemutaran Audio > "Perintah suara untuk memutar" (kunci perintah_suara_putar_aktif, default aktif).
Nonaktif = tombol perintah suara disembunyikan dan fungsinya menolak berjalan. Ikut direset oleh Reset pengaturan.
