# FIX116 — Perintah suara hanya menjawab yang diminta

Versi aplikasi tidak diubah. Basis: FIX115. Berkas diubah: `PerintahSuaraActivity.kt`, `JamWaktu.kt`.

## Masalah
Perintah "informasikan pasaran Jawa hari ini" dijawab dengan rangkaian tanggal, libur, sampai info salat berikutnya.
Kata "pasaran" tidak punya jalur sendiri; ia dianggap perintah "tanggal" umum, dan perintah umum itu membacakan seluruh segmen.

## Perbaikan
- Jenis perintah baru `PASARAN` (kata "pasaran", "pasarannya", "weton"): hanya membacakan pasaran Jawa hari ini sesuai bahasa aktif
  dan koreksi pasaran di pengaturan (mis. "Hari Ahad, Pahing"). Prioritasnya sama dengan perintah spesifik lain (Masehi, Hijriah, libur, salat).
- Perintah "tanggal" / "waktu dan tanggal" kini membacakan waktu dan/atau tanggal kalender saja (Masehi, pasaran, Hijriah
  sesuai sakelar pengaturan), tanpa libur dan info salat. Bila semua sakelar kalender mati, tanggal Masehi tetap dibacakan.
- Jenis baru `SEMUA` untuk permintaan eksplisit "semua", "lengkap", atau perintah umum pendek ("informasi"): waktu, tanggal,
  libur, dan info salat seperti sebelumnya.
- `JamWaktu.segmenKalender` baru; `segmenTanggal` (dipakai tombol dan layar lain) tidak berubah hasilnya.

## Pemeriksaan
- `verify_project.py` dan `periksa_bahasa_aktif.py` lulus; kurung seimbang. BELUM dikompilasi dan BELUM diuji di perangkat.
