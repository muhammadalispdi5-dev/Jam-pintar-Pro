# FIX239 — Versi dinaikkan ke 1.0.87

- versionName 1.0.86 menjadi 1.0.87, versionCode 86 menjadi 87 (app/build.gradle.kts).
- Diselaraskan: User-Agent (OpenMeteo, InfoBmkg, QariSuara, PerintahSuaraActivity), README, PANDUAN_PEMBARUAN_DAN_KELUHAN, dan pemeriksaan versi pada tiga skrip uji di tools/.
- Memuat perubahan FIX237 (Pengaturan Melodi Pengingat terpadu) dan FIX238 (pilihan jenis suara Tahajud beserta audio bawaannya).
- Catatan FIX lama tidak diubah. Gradle belum dijalankan.
