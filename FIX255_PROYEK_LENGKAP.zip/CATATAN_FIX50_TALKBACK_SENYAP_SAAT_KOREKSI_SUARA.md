# FIX50 — TalkBack Senyap Saat Koreksi Otomatis Hafalan

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX49. Perubahan hanya di `KhatamActivity.kt`.

## Masalah
Saat pengenalan suara mulai berjalan, TalkBack masih membacakan status dan pengumuman, sehingga mengganggu dan suaranya tertangkap mikrofon.

## Perbaikan
- Begitu "Mulai membaca" ditekan: ucapan TalkBack yang sedang berjalan diinterupsi (`AccessibilityManager.interrupt()`), isi dialog (petunjuk dan status) disembunyikan dari TalkBack, dan semua `announceForAccessibility` dimatikan selama persiapan dan perekaman.
- Mikrofon baru dibuka setelah jeda ±1 detik supaya sisa ucapan TalkBack selesai.
- Saat mikrofon siap, pengguna diberi isyarat **getar** pendek sebagai pengganti pengumuman suara.
- Tombol Hentikan dan Tutup tetap dapat dijangkau TalkBack.
- Setelah hasil/kesalahan/dihentikan, TalkBack dipulihkan dan hasil diumumkan. Bila TalkBack aktif, suara Text-to-Speech tambahan dilewati agar tidak tumpang tindih dengan TalkBack.

## Batas
- TalkBack tidak dapat dimatikan penuh oleh aplikasi. Dialog izin mikrofon (sekali saja) dan layar suara sistem Google (jalur cadangan) berada di luar kendali aplikasi.
- Belum dikompilasi dan belum diuji di perangkat dengan TalkBack. `tools/verify_project.py`: LULUS.
