# FIX173 — Prioritas Audio Al-Qur'an Lokal

## Masalah

Perintah suara dari layar depan/layar kunci diproses oleh `PemutarQuranService`. Sebelumnya layanan ini selalu membentuk URL CDN untuk audio surah/ayat lalu langsung memberikannya ke pemutar. Akibatnya, berkas MP3 yang sudah diunduh melalui fitur Khatam tidak diperiksa terlebih dahulu.

## Perbaikan

- Sebelum memutar URL streaming, layanan perintah suara mencari berkas audio lokal berdasarkan qari, nomor surah, dan nomor ayat.
- Pencarian mencakup folder `Jam Pintar Pro/Al-Qur'an/simpan folder audio`, folder `Download/Jam Pintar Pro/Al-Qur'an/simpan folder audio`, penyimpanan khusus aplikasi untuk perangkat lama, MediaStore Downloads, dan folder pilihan pengguna melalui Storage Access Framework.
- Audio surah penuh yang diunduh dipakai untuk perintah surah penuh, misalnya “putar surah Al-Ikhlas”.
- Audio per ayat yang diunduh dipakai untuk perintah ayat/rentang ayat jika berkasnya tersedia.
- Jika berkas lokal untuk bagian yang diminta tidak ditemukan, perilaku streaming lama tetap menjadi cadangan. Jika pengguna ingin benar-benar tanpa internet, perintah harus ditujukan pada audio yang memang sudah diunduh.
- Pencocokan nama berkas mengabaikan keterangan qari setelah nama pokok agar tetap menemukan unduhan ketika bahasa aplikasi berubah.
- Konfirmasi singkat menyebutkan jumlah berkas lokal yang digunakan.

## Versi dan batas pengujian

- `versionCode` tetap `82`.
- `versionName` tetap `1.0.82`.
- Tidak ada perubahan pada mekanisme pengenalan suara offline FIX172.
- Arsip proyek diperiksa integritasnya setelah dibuat.
- APK belum dikompilasi dan belum diuji pada perangkat Android. Pengujian perangkat tetap diperlukan untuk memastikan izin folder dan variasi penyimpanan pada HP pengguna.
