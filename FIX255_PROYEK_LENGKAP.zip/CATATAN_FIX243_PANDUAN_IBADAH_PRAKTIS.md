# CATATAN FIX243: Panduan Ibadah Praktis Sesuai Sunnah

Versi tetap 1.0.87 (versionCode 87).

## Fitur baru
Menu utama "Panduan Ibadah Praktis Sesuai Sunnah" (PanduanIbadahActivity + PanduanIbadahData), memakai pola halaman Panduan Manasik Haji: daftar bagian, lalu tiap bagian berisi teks, bacaan Arab, Latin, arti, dan sumber hadits, dengan tombol Dengarkan bagian ini, Dengarkan bacaan Arab ini, Pilih mesin suara pembaca, Hentikan suara, ukuran huruf, Salin, Bagikan, serta bagian berikutnya/sebelumnya. Dwibahasa Indonesia/Inggris.

## 19 bagian
Cara memakai panduan; wudhu; mandi wajib dan tayammum; adzan, iqamah, dan menjawabnya; tata cara shalat (1) takbir sampai sujud dan (2) tasyahud sampai salam; dzikir setelah shalat; shalat berjamaah dan adab masjid; rawatib, Dhuha, witir, tahajud; istikharah, sujud sahwi/tilawah/syukur; shalat Jumat; shalat safar dan sakit; shalat jenazah; shalat Id; puasa Ramadhan dan sunnah; zakat fitrah dan mal; adab harian (tidur, makan, buang hajat, keluar rumah); sunnah fitrah; tips ibadah bagi tunanetra. Total 100 blok, 38 bacaan Arab lengkap dengan Latin dan arti.

## Perintah suara
"buka panduan ibadah", "tuntunan ibadah", "ibadah praktis", "tata cara shalat", "worship guide", "how to pray".

## Pemeriksaan
- Uji kompilasi logika (kotlinc): 19 bagian, judul unik, tidak ada teks kosong, tiap bacaan Arab punya Latin.
- Empat pemeriksa proyek dan uji cakupan asisten suara lulus. Petunjuk penggunaan ID/EN ditambah (item 29 / 26).

## Catatan
- Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
- Dalil dibatasi pada ayat dan hadits yang masyhur; pada rincian yang diperselisihkan ulama dipilih yang kuat dalilnya. Ini draf bukan fatwa; sebaiknya ditinjau ustadz sebelum dijadikan rujukan.
