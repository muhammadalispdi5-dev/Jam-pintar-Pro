# FIX170 - Penghentian TalkBack/Vocalizer yang lebih tegas saat mikrofon aktif

- Pengaturan **Suara TalkBack saat pergantian audio dan saat mikrofon dipakai** kini menggunakan dua lapis tindakan saat opsi senyap aktif:
  1. Meminta `AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE` dengan atribut komunikasi suara agar layanan audio lain diminta menghentikan keluaran, bukan hanya mengecilkan volume.
  2. Memanggil `AccessibilityManager.interrupt()` untuk memotong ucapan TalkBack/Vocalizer yang sedang berlangsung. Interupsi diulang setelah jeda singkat agar antrean ucapan yang terlambat tidak masuk ke rekaman mikrofon.
- Jalur **Perintah Suara** meminta fokus eksklusif saat memakai `SpeechRecognizer` internal. Saat beralih ke layar pengenalan sistem, fokus aplikasi dilepas agar tidak menghalangi layanan pengenal yang mengelola audionya sendiri.
- Jalur **Koreksi Hafalan dengan Suara** meminta fokus eksklusif sebelum mikrofon dimulai, menjaga dialog tersembunyi dari TalkBack selama perekaman, dan melepaskan fokus saat sesi selesai, gagal, dibatalkan, berpindah ke dialog pengenalan sistem, atau Activity dihancurkan.
- Fokus audio dilepas setelah sesi mikrofon agar TalkBack/Vocalizer dapat berbicara kembali. Opsi yang tidak diaktifkan tidak memaksa senyap pada pengenalan biasa.
- Batasan Android: aplikasi tidak dapat mengendalikan langsung proses internal mesin TTS pihak ketiga. `interrupt()` dan fokus audio eksklusif adalah mekanisme publik Android paling kuat yang dapat diminta aplikasi; kepatuhan akhir tetap dapat dipengaruhi versi Android, TalkBack, dan mesin Vocalizer perangkat.
- Nomor versi aplikasi tidak diubah.
