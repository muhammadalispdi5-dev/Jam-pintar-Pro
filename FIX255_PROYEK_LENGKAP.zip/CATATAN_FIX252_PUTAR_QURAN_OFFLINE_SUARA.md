# FIX252 — Putar Al-Qur’an offline lewat asisten suara

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Logika pencocokan nama diuji dengan kotlinc (t252/Uji.kt).

- Mode offline pada perintah putar Al-Qur’an: kata offline, luring, tanpa internet, tersimpan, penyimpanan, folder, memori, dan sebagainya membuat PemutarQuranService hanya memutar berkas lokal, tanpa cadangan online; bagian yang belum tersimpan dilewati dan disebutkan, dan bila kosong dijelaskan cara mengunduh/meletakkan berkas.
- Nama qari dicocokkan longgar dengan nama folder (QariSuara.mirip): Ayman Suwaid = Ayman Sowaid. Kata offline, plus, beserta, terjemahnya, dan sebagainya tidak lagi terbawa ke nama qari.
- Folder dikenali: Audio/Murattal Per Surah, Audio/Murattal Per Ayat (folder per surah: 002 - Al-Baqarah, 002 Al-Baqarah, 2), dengan nama berkas ayat bebas pola (S002_A001, 001.mp3, 002001.mp3). Terjemahan: Terjemahan Indonesia, Indonesian Translation, Terjemah Bahasa Indonesia, Terjemahan Bahasa Indonesia, Terjemah Indonesia; nama berkas bebas selama memuat nomor surah.
- Petunjuk penggunaan: butir 36 (Indonesia) dan 33 (English).

Catatan jujur: terjemahan Indonesia yang dikenal aplikasi adalah satu berkas per surah penuh yang sudah memuat bacaan Arab (FIX209), sehingga perintah surah dan terjemahnya memutar berkas itu, bukan murattal per ayat disusul terjemahan. Bila folder Anda berbeda, kirimkan contoh nama folder dan berkasnya.
