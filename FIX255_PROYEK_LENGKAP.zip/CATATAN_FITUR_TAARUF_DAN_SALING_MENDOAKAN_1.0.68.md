# Jam Pintar Pro 1.0.68 — Ta’aruf dan Saling Mendoakan

## Penambahan
- Menu baru di beranda: Ta’aruf / Berkenalan dan Saling Mendoakan.
- Profil ta’aruf: nama/panggilan, usia opsional, kota/daerah, minat, dan tujuan berkenalan. Profil disimpan lokal dan dibagikan hanya jika pengguna menekan tombol bagikan.
- Doa pribadi: penerima opsional, isian doa, contoh doa sesuai bahasa aplikasi, simpan lokal, bagikan doa, dan bagikan doa umum bagi sesama muslim.
- Label, petunjuk, pesan konfirmasi, isi contoh doa, dan teks yang dibagikan mengikuti bahasa tampilan aplikasi (Indonesia atau Inggris).
- Aktivitas terdaftar di AndroidManifest dan nomor versi aplikasi dipertahankan pada 1.0.68 (versionCode 68).

## Privasi dan batasan
Data profil dan doa disimpan di SharedPreferences lokal. Aplikasi tidak menyediakan server, pencarian anggota, akun, atau pesan masuk antar pengguna; untuk bertukar perkenalan/doa, pengguna memilih aplikasi tujuan pada menu berbagi Android. Data hanya dibagikan setelah pengguna memilih tindakan berbagi.

## Verifikasi
`python3 tools/verify_project.py` adalah pemeriksaan statis; kompilasi Gradle dan uji pada perangkat belum dijalankan di lingkungan ini.
