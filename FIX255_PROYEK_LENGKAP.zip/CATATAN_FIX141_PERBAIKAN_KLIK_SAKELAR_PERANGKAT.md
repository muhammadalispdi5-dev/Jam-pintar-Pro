# FIX141 – Perbaikan tindakan klik sakelar perangkat

Versi aplikasi tetap **1.0.81** (`versionCode` 81). Perubahan ini melanjutkan FIX140 dan tidak mengubah nomor versi.

## Masalah yang ditangani
Pada sebagian antarmuka Pengaturan Android/OEM, `AccessibilityNodeInfo.performAction(ACTION_CLICK)` dapat diterima tetapi tidak benar-benar mengubah sakelar. Akibatnya aplikasi hanya sampai ke halaman pengaturan.

## Perubahan
- Tetap mencoba aksi klik aksesibilitas native pada node sakelar/induk klik.
- Jika status belum berubah setelah waktu verifikasi, layanan mencoba satu ketukan layar melalui `dispatchGesture()` pada batas koordinat sakelar dan induk terkait.
- Mengaktifkan `canPerformGestures` pada konfigurasi layanan aksesibilitas.
- Memverifikasi kembali status setelah tindakan. Aplikasi hanya mengumumkan berhasil jika status yang terbaca sama dengan tujuan perintah.
- Membatasi percobaan ketukan cadangan agar sakelar tidak terus-menerus dibalik.
- Jika status tidak dapat dibaca, tindakan tetap dicoba satu kali melalui node yang telah cocok; status tetap diverifikasi dan aplikasi tidak mengumumkan berhasil tanpa bukti.
- Saat perintah baru masuk, status percobaan/gestur sebelumnya dibersihkan.
- Bahasa UI tetap mengikuti resource bahasa aktif dan versi aplikasi tetap 1.0.81.

## Fitur dalam cakupan
Wi-Fi, Bluetooth, lokasi, hotspot, data seluler, mode pesawat, dan NFC.

## Batasan Android
Android versi baru membatasi perubahan langsung sejumlah sakelar sistem oleh aplikasi biasa. Karena itu mekanisme ini mengoperasikan antarmuka Pengaturan melalui layanan aksesibilitas yang harus diaktifkan oleh pengguna. Beberapa dialog konfirmasi, kebijakan operator, perangkat terkelola, atau tampilan OEM mungkin tetap mengharuskan tindakan manual. Ketukan koordinat bergantung pada tata letak yang benar-benar ditampilkan; tidak ada jaminan identik pada semua merek/model.

## Pengujian
Pemeriksaan statis proyek, resource bahasa, pemilih sakelar, dan kontrak fallback klik/gestur dijalankan. Kompilasi APK Gradle penuh dan uji fisik pada perangkat belum tersedia di lingkungan kerja ini; karena itu perubahan ini belum boleh dianggap tervalidasi pada semua perangkat.
