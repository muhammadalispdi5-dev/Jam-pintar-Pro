# FIX49 — Daftar Pilihan Equalizer Tidak Muncul

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX48. Perubahan hanya di `KhatamActivity.kt`.

## Penyebab
Dialog Equalizer memakai `setMessage` bersamaan dengan `setSingleChoiceItems`. Pada `AlertDialog` bawaan Android, pesan teks menggantikan daftar, sehingga pilihan Normal / Vokal / Bass / Treble / Kustom tidak pernah tampil. Pola yang sama ditemukan pada dialog "Pilihan pemutaran audio" (Arab / terjemahan) dan "Unduh audio".

## Perbaikan
- Fungsi baru `judulDenganPesan(judul, pesan)`: pesan penjelasan dipindahkan ke judul kustom (`setCustomTitle`) sehingga daftar pilihan tampil. Teks tetap terbaca TalkBack.
- Dipakai pada tiga dialog di atas. Dialog lain sudah diperiksa dan tidak memiliki pola ini.

## Pemeriksaan
- `tools/verify_project.py`: LULUS; tanda kurung Kotlin seimbang. Belum dikompilasi dan belum diuji di perangkat.
