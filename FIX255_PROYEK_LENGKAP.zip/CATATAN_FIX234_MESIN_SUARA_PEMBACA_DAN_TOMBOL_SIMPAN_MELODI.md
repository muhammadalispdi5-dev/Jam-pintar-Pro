# FIX234 — Mesin suara pembaca dan tombol Simpan melodi

Perubahan berangkat dari FIX233, mempertahankan versi aplikasi 1.0.86 / versionCode 86.

## Perbaikan pemilih melodi
- Mengganti tombol simbol `✓` menjadi tombol teks `Simpan` pada dialog daftar melodi.
- Tombol `Batal` tetap tersedia.
- Pratinjau melodi tetap dapat dilakukan dengan memilih item satu per satu; pilihan baru disimpan hanya setelah `Simpan` ditekan.
- Pembatalan atau menutup dialog menghentikan pratinjau dan tidak mengubah pilihan tersimpan.

## Mesin suara pembaca
- Menambahkan pemilih mesin TTS perangkat melalui daftar mesin suara yang terpasang.
- Menyediakan pilihan `Bawaan sistem` dan tombol `Simpan` / `Batal`.
- Preferensi mesin suara disimpan secara terpisah per fitur: Doa Harian, Kitab Hadits, Khutbah Jumat, dan Manasik Haji.
- Saat pilihan mesin berubah, instance TTS lama dihentikan dan dibuat ulang saat pembacaan berikutnya.
- Pembacaan Arab, Latin, dan terjemahan tetap memakai pengaturan bahasa masing-masing yang telah ada.
- Label baru mengikuti bahasa tampilan aktif melalui BahasaAplikasi.

## Validasi
- Memeriksa perubahan sumber dan struktur arsip ZIP.
- Android Gradle build belum dapat dijalankan di lingkungan ini karena arsip proyek tidak menyertakan Gradle Wrapper dan executable Gradle tidak tersedia. Jalankan GitHub Actions untuk verifikasi kompilasi final.
