# FIX106 — Asisten Tahfiz Cerdas, Inklusif, dan Koreksi Bacaan

## Perubahan
- Menambahkan pintu masuk **Asisten Tahfiz Cerdas** pada menu Pengaturan Khatam Al-Qur'an.
- Asisten Tahfiz Cerdas mengarahkan pengguna ke muraja'ah cerdas terpandu, Asisten Hafalan Inklusif, Asisten Koreksi Bacaan, serta pengaturan terkait.
- Asisten Hafalan Inklusif memakai alur latihan tanpa mikrofon yang sudah tersedia dan pengaturan aksesibilitas/TalkBack yang sudah ada.
- Asisten Koreksi Bacaan memakai alur pengenalan suara, penandaan kata, petunjuk, dan audio koreksi yang sudah ada.
- Tidak menambahkan SpeechRecognizer, mesin pembanding, penyimpanan hafalan, atau mekanisme latihan kedua. Fitur baru merupakan pintu masuk terpadu ke fungsi yang sudah ada.
- Seluruh teks baru menggunakan `tr(Indonesia, English)`, sehingga mengikuti bahasa tampilan aktif aplikasi (Indonesia/English).

## Batasan yang disampaikan ke pengguna
Pengenalan suara hanya perkiraan pencocokan teks. Fitur ini tidak mengesahkan tajwid, makhraj, sifat huruf, atau kualitas tartil. Latihan inklusif tanpa mikrofon adalah pencocokan mandiri oleh pengguna, bukan penilaian otomatis.

## Pengujian
Perubahan perlu diverifikasi dengan kompilasi Gradle dan uji perangkat, termasuk TalkBack, kedua bahasa tampilan, izin mikrofon, serta keadaan saat fitur latihan dinonaktifkan.
