# FIX95 - Goncangan membuka perintah suara saat layar terkunci

## Penyebab (dari pembacaan kode FIX94)
1. Layanan sensor memanggil startActivity() dari latar belakang. Android 10+ menahan peluncuran seperti ini secara
   diam-diam (tanpa exception), sehingga notifikasi cadangan lama tidak pernah muncul dan layar perintah tidak terbuka.
2. Walau layar perintah terbuka, pengenalan suara memakai layar pengenal milik aplikasi lain (RecognizerIntent) yang
   tidak tampil di atas layar kunci, sehingga hasilnya dibatalkan.

## Perbaikan
- GoncanganSuaraService: peluncuran kini lewat notifikasi layar penuh "Perintah suara siap" (kanal baru prioritas tinggi,
  tanpa suara, terlihat di layar kunci) ditambah peluncuran langsung; CPU ditahan 15 detik selama peluncuran.
  Izin baru USE_FULL_SCREEN_INTENT di manifest.
- PerintahSuaraActivity:
  * Saat dipicu goncangan atau saat terkunci dan izin mikrofon sudah diberikan, pengenalan suara berjalan LANGSUNG di layar
    ini (SpeechRecognizer), bukan di layar aplikasi lain. Petunjuk: TalkBack disenyapkan, getar, jeda 0,7 detik, lalu
    nada bip "silakan bicara". Gagal atau tanpa izin: otomatis kembali ke layar pengenal sistem seperti sebelumnya.
  * Pemicu ganda (peluncuran langsung dan notifikasi) diabaikan oleh onNewIntent; notifikasi dihapus saat layar terbuka.
  * Saat terkunci, perintah yang membuka aplikasi/fitur, menelepon, memutar Al-Qur'an, atau membacakan pesan pribadi
    meminta buka kunci layar dulu (requestDismissKeyguard, Android 8+). Waktu, tanggal, libur, dan sholat langsung dibacakan.
- PengaturanGoncanganActivity: bagian baru "Agar berfungsi saat layar terkunci" dengan tombol izin mikrofon + notifikasi
  dan tombol izin notifikasi layar penuh; izin mikrofon/notifikasi juga diminta saat sakelar diaktifkan.
- Versi dinaikkan menjadi 1.0.71 (versionCode 71). Teks id/en.

## Yang perlu dilakukan pengguna sekali
Buka Pengaturan goncangan: izinkan mikrofon, izinkan notifikasi, izinkan notifikasi layar penuh (Android 14+), dan
atur baterai aplikasi ke "Tidak dibatasi". Tanpa izin mikrofon, layar terkunci tetap memakai layar pengenal sistem
(yang dapat ditahan Android saat terkunci).

## Batasan
- Sebagian merek (Xiaomi, OPPO, Vivo, Samsung hemat daya) menahan layanan/notifikasi layar penuh; izinkan "Mulai otomatis",
  "Tampil di layar kunci", dan "Tampil di atas aplikasi lain" untuk aplikasi ini.
- Belum dikompilasi/diuji di perangkat (tidak ada kompiler di lingkungan kerja); hanya diperiksa kesetimbangan kurung dan XML.

# FIX96 - Memutar audio Al-Qur'an dengan perintah suara saat layar terkunci
Sebelumnya (FIX95) perintah putar Al-Qur'an saat terkunci meminta buka kunci karena pemutarnya bagian dari layar Khatam.
Kini ada pemutar latar belakang mandiri: PemutarQuranService (layanan foreground mediaPlayback).
- Saat layar terkunci, "putar surah Al Baqarah", "putar surah 36 ayat 5", "putar surah 2 ayat 255 sampai 257",
  "putar juz 30", "putar ayat 10" (surah terakhir dibuka) langsung diputar tanpa membuka layar apa pun dan tanpa buka kunci.
  Layar yang tidak terkunci tetap memakai alur Khatam seperti FIX87 (tidak berubah).
- Memakai qari dan kecepatan yang tersimpan di Khatam. Qari per-surah (MP3Quran/anak) yang tidak punya audio per ayat atau
  juz memakai Alafasy untuk perintah itu (diberi tahu lewat pesan). Surah utuh memakai berkas surah dari qari pilihan.
  Pengaturan Khatam "target pemutaran" selain "ayat" membuat "surah X ayat N" lanjut sampai akhir surah.
- Kendali dengan suara: "berhenti"/"hentikan"/"stop", "jeda"/"pause", "lanjut"/"lanjutkan"/"resume" (ucapan pendek);
  juga tombol Jeda/Lanjut dan Berhenti pada notifikasi. Dihormati saklar "Perintah suara untuk memutar" di Khatam.
- Menjaga pemutaran saat layar mati: layanan foreground, partial wake lock (MediaPlayer.setWakeMode), Wi-Fi lock, fokus audio
  (jeda saat panggilan, lanjut otomatis), jeda saat headset dicabut. Bitrate cadangan 64/192 bila 128 gagal; ayat yang
  gagal dilewati (maks. 4 berturut-turut).
- "Pilih qari ..." saat terkunci tetap meminta buka kunci (dikerjakan Khatam).
- Berkas: PemutarQuranService.kt (baru, memuat juga PenafsirQuran dengan tabel jumlah ayat 114 surah = 6236 dan awal 30 juz),
  PerintahSuaraActivity.kt, AndroidManifest.xml (FOREGROUND_SERVICE_MEDIA_PLAYBACK, layanan baru), PengaturanGoncanganActivity.kt.
  Versi 1.0.72 (versionCode 72).
- Batasan: perlu internet; penafsir mandiri memakai nama surah Latin (Al Baqarah, Yasin, dll.) tanpa nama Inggris dari JSON;
  belum dikompilasi/diuji di perangkat.
