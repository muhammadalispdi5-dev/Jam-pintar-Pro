# FIX100 — Perintah suara memutar surah yang salah (terutama saat layar terkunci)

Versi aplikasi tetap **1.0.73** (versionCode 73). Basis: FIX99.
Berkas diubah: `PemutarQuranService.kt` (penafsir `PenafsirQuran` dan layanan), `KhatamActivity.kt` (penafsir Khatam).
Baru: `tools/uji_penafsir_quran.py`.

## Masalah yang dilaporkan
Perintah "putar surah Al-Ikhlas ayat 1 sebanyak 3 kali" yang diucapkan saat layar terkunci malah memutar An-Nas.

## Penyebab (dua hal bersamaan)
1. **Nama surah tidak cocok.** Saat terkunci, perintah dijalankan `PemutarQuranService` yang memakai `PenafsirQuran`. Daftar
   namanya hanya satu ejaan per surah ("AlIkhlash"), sedangkan pengenal suara menulis "Al Ikhlas". Hasilnya nama tidak terbaca.
   Penafsir Khatam (layar tidak terkunci) menolong dirinya dengan nama Inggris dari teks yang sudah diunduh ("Al-Ikhlaas"),
   yang tidak dimiliki layanan latar belakang. Itu sebabnya masalah hanya muncul saat terkunci. Pencocok lama juga gagal pada
   "Al Kausar" (daftar: "Kautsar") dan ejaan bebas lain.
2. **Menebak diam-diam.** Karena "ayat 1" terbaca tetapi nama surah tidak, layanan memakai surah yang terakhir dibuka
   (`terakhir_surah`, di sini An-Nas, surah ke-114) tanpa memberi tahu.

## Perbaikan
- **Pencocokan nama yang tahan ejaan** (`PenafsirQuran`): kunci fonetik (sh/sy, kh/k, th/t, ts/s, q/k, e/i, o/u, huruf kembar disamakan),
  daftar alias ejaan lazim untuk surah yang sering diminta (juz 30, Fatihah, Baqarah, Kahfi, Yasin, Rahman, Waqiah, Mulk, dan lain-lain),
  bentuk tanpa awalan Al/An/Ar/As, dan toleransi satu atau dua salah huruf (huruf pertama harus sama dan panjang minimal 6,
  supaya kata sehari-hari tidak dikira nama surah). Nama yang lebih panjang menang (An-Nasr tidak tertukar dengan An-Nas).
- **Tidak ada lagi tebakan diam-diam.** Bila ada kata yang tersisa yang bukan nama surah yang dikenali, perintah ditolak dan
  tidak ada audio yang diputar. Pesan: `Nama surah "xxx" tidak dikenali, jadi tidak ada audio yang diputar. Ucapkan nomor surah,
  misalnya: putar surah 112 ayat 1.` Memakai surah terakhir hanya terjadi bila ayat disebut tanpa kata lain ("putar ayat 10").
- **Kandidat hasil pengenalan dinilai berurutan prioritas** (`tafsirLengkap`): (1) kandidat yang menyebut surah atau juz dengan jelas,
  (2) bila ada kandidat bernama tak dikenal, tolak (jangan pakai kandidat lain yang tanpa nama), (3) kandidat yang hanya menyebut ayat.
- **Konfirmasi yang bisa diperiksa:** toast dan notifikasi kini menyebut nama surah, mis. "Surah 112 (Al-Ikhlas) ayat 1, diulang 3 kali".
- **Khatam (layar tidak terkunci)** ikut diperbaiki: memakai pencocok nama yang sama sebagai cadangan, dan menolak nama yang tidak
  dikenali alih-alih memutar surah terakhir.

## Pemeriksaan
- `tools/uji_penafsir_quran.py` (cerminan Python dari logika Kotlin) menjalankan 49 ucapan: kasus yang dilaporkan beserta variannya
  ("Al Ikhlas", "Al-Ikhlas", "Alikhlas", "Iklas", "tiga kali"), nama tak dikenal, ayat tanpa nama, semua contoh perintah FIX98
  (pengulangan, rentang, sampai akhir, berikutnya, ulangi, kecepatan, jeda), dan 17 nama surah pendek. Hasil: semua lulus.
  Dengan pencocok lama, "al ikhlas" menghasilkan tidak ada surah (dikonfirmasi) sehingga jatuh ke surah terakhir.
- `tools/verify_project.py` lulus; kurung seimbang. BELUM dikompilasi dan BELUM diuji di HP.

## Batas
- Alias ejaan ditulis dari pengetahuan umum, bukan dari data pengenal suara nyata. Bila ada nama yang masih tidak dikenali,
  ucapkan nomor surahnya (mis. "putar surah 112 ayat 1") dan catat ejaan yang didengar agar bisa ditambahkan ke `aliasNama`.
- Nama surah yang panjang dan jarang (mis. "Al-Muddassir", "Al-Mursalat") bergantung pada kunci fonetik dan toleransi salah huruf,
  bukan alias khusus.
