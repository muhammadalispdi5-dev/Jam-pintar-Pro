# FIX168 - Cuaca menyebut nama daerah lokasi aktif

## Masalah
Informasi cuaca mengucapkan kalimat umum "lokasi perangkat saat ini" (atau "lokasi tersimpan"), bukan nama tempat sebenarnya.

## Perbaikan
- Nama daerah dicari dari koordinat yang dipakai (lokasi langsung perangkat, atau lokasi tersimpan Jadwal Sholat) dan diucapkan, misalnya kelurahan/kecamatan, kota, dan provinsi, sesuai bahasa aktif (Indonesia atau English).
- Urutan pencarian: (1) nama tersimpan yang spesifik untuk lokasi tersimpan; (2) Geocoder perangkat (`NamaLokasi.cari`); (3) layanan geokode cadangan BigDataCloud; (4) pada jalur cadangan wttr.in, nama area dari wttr.in. Bila semuanya gagal, dipakai kalimat umum "lokasi Anda saat ini" agar cuaca tetap dibacakan.
- Kalimat cuaca tetap disusun tanpa templat dolar (FIX166).
- Pencarian nama berjalan di thread latar dan tidak menggagalkan pengambilan cuaca. Belum dikompilasi dan belum diuji di perangkat; Geocoder bergantung layanan perangkat dan internet.
- Uji statis: `tools/uji_fix168_nama_daerah_cuaca.py`.
