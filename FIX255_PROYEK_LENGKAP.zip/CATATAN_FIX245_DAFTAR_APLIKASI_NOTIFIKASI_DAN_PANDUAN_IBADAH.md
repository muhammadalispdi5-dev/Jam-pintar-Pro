# CATATAN FIX245: Daftar Aplikasi Pembaca Notifikasi dan Pengayaan Panduan Ibadah

Versi tetap 1.0.88 (versionCode 88).

## 1. Pilih aplikasi yang akan dibacakan
Penyebab GoPay, GoPay Merchant, dan aplikasi lain tidak muncul:
- Semua paket yang namanya mengandung "gojek", "grab", "mail", "sms", "mms", "messaging", dan sebagainya dibuang dari daftar karena dianggap aplikasi transportasi, email, atau SMS yang sudah punya sakelar sendiri. Akibatnya com.gojek.gopay, com.gojek.merchant, dan sekeluarganya ikut terbuang.
- Pembaca notifikasi (CallerListener) memakai aturan yang sama, sehingga notifikasi aplikasi sekeluarga itu tidak dibacakan walaupun dipilih.
- Daftar hanya memuat aplikasi yang memiliki ikon peluncur, sehingga aplikasi tanpa ikon tidak tampil.

Perbaikan:
- Berkas baru KategoriNotifApp.kt: satu aturan bersama (dipakai daftar dan pembaca notifikasi). Hanya Gojek penumpang/mitra pengemudi (com.gojek.app, com.gojek.driver*), Grab penumpang/pengemudi (com.grabtaxi.*), inDrive, Maxim, aplikasi email dikenal, SMS, dan WhatsApp yang dikecualikan; selebihnya (GoPay, GoPay Merchant, bank, dompet digital, belanja, dan lain-lain) dapat dipilih.
- Daftar kini memuat semua aplikasi terpasang yang berguna: yang berikon peluncur, semua aplikasi pasangan pengguna (termasuk yang tanpa ikon), dan aplikasi sistem yang pernah diperbarui. Aplikasi sistem tanpa ikon dilewati agar daftar tidak penuh. Dua aplikasi bernama sama dibedakan dengan nama paketnya.
- AndroidManifest: izin QUERY_ALL_PACKAGES ditambahkan (diperlukan Android 11 ke atas agar semua aplikasi terpasang terlihat). Aplikasi ini dipasang manual, bukan lewat Play Store, sehingga kebijakan izin Play tidak berlaku.
- Uji kotlinc KategoriNotifApp: 15 paket seperti com.gojek.gopay dan com.gojek.merchant dapat dipilih; Gojek, Grab, inDrive, Maxim, Gmail, ProtonMail, dan aplikasi pesan tetap dikecualikan.
- Petunjuk penggunaan ID/EN: item baru 30/27.

## 2. Panduan Ibadah Praktis diperkaya
Dari 19 menjadi 33 bagian (156 blok, 60 bacaan Arab lengkap dengan Latin dan arti). Bagian baru:
surah-surah pendek pilihan (Al-Ikhlas, Al-Falaq, An-Nas, Al-Kautsar, Al-Ashr, An-Nasr, Al-Kafirun); tarawih dan doa qunut witir; shalat gerhana dan istisqa; dzikir pagi dan petang pilihan (termasuk sayyidul istighfar); shalat sunnah wudhu, taubat, dan antara dua adzan; najis dan cara mensucikannya; mengusap khuf; ibadah muslimah (haid, istihadhah, nifas); mendidik anak beribadah dan aqiqah; adab safar; adab salam, bersin, dan menguap; adab saat sakit dan ruqyah; adab berdoa; rutinitas harian menurut sunnah.
Teks pengantar halaman dan petunjuk penggunaan ID/EN diperbarui.

## 3. Perbaikan uji lama
tools/uji_cuaca_lokasi_langsung.py memeriksa teks lama "bacakanCuaca()" padahal kode sudah memakai bacakanCuaca(kandidat); diperbarui agar sesuai (bukan kegagalan fitur).

## Catatan
- Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Mohon uji pada HP: buka Pilih aplikasi yang akan dibacakan, pastikan GoPay dan GoPay Merchant tampil, lalu pilih dan uji notifikasinya.
- Naskah panduan ibadah adalah draf, bukan fatwa; sebaiknya ditinjau ustadz.
Dua uji lama (uji_cuaca_lokasi_langsung dan uji_suara_pengingat_baca_hafalan) memeriksa teks usang dan disesuaikan dengan kode/petunjuk saat ini.
