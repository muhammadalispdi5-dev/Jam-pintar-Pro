# FIX93 — Perbaikan kompilasi RiwayatPesanSuara

Memperbaiki `RiwayatPesanSuara.kt` yang menyebabkan kegagalan `:app:compileDebugKotlin` dan `:app:compileReleaseKotlin`.

Perubahan:
- Memindahkan `bacaArray` ke bagian awal objek dan menuliskannya sebagai fungsi blok eksplisit.
- Mengganti ekspresi `takeIf { ... } ?: continue` dengan pemeriksaan `isNotBlank()` eksplisit.
- Menghindari interpolasi string bersarang untuk nama pengirim.
- Menambahkan tipe eksplisit untuk nilai `JSONArray` dan `JSONObject` agar inferensi tipe Kotlin tidak ambigu.
- Mempertahankan batas penyimpanan 50 pesan dan masa simpan 7 hari.
- Tidak mengubah alur izin notifikasi, pembacaan pesan, atau aturan bahasa aktif.

Validasi:
- `tools/verify_project.py`: LULUS.
- `kotlinc` pada file `RiwayatPesanSuara.kt` dengan stub Android/JSON: LULUS.
- Build Gradle Android penuh belum dapat dijalankan pada lingkungan ini karena Gradle/Gradle Wrapper tidak tersedia.
