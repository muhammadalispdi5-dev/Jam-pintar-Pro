# FIX121 - Mikrofon perintah suara gagal aktif beberapa kali setelah 6-7 pemakaian (layar pengenal sistem tampil, getar/nada ada)

Versi aplikasi tidak diubah. Basis: FIX120. Berkas diubah: `PerintahSuaraActivity.kt`, `res/values/strings.xml`, `res/values-en/strings.xml`, `tools/uji_mikrofon_perintah_suara.py`.

## Informasi dari pengguna
Layar pengenal suara sistem muncul dan ada getar/nada siap, tetapi mikrofon beberapa kali gagal aktif setelah 6-7 pemakaian yang lancar. Pemicu: goncangan dan widget Beritahu Saya.

## Dugaan penyebab (dari pembacaan kode; log crash belum ada, jadi ini belum terbukti)
1. Pemicu goncangan memakai `CLEAR_TOP|SINGLE_TOP`: bila layar perintah suara sebelumnya masih ada (layar sistem macet, mikrofon tidak aktif),
   goncangan berikutnya hanya diteruskan ke `onNewIntent` yang sengaja mengabaikannya (untuk pemicu ganda). Pengguna lalu terus
   berhadapan dengan layar pengenal lama yang macet dan pemicu baru tidak berefek.
2. Hasil gagal dari layar pengenal sistem (kode galat audio/klien/server/jaringan, atau dibatalkan segera) langsung menutup layar tanpa
   percobaan ulang dan tanpa pemberitahuan.
3. Pada jalur cadangan, layar sistem dibuka seketika setelah pengenal dalam dilepas, padahal layanan pengenal belum selesai melepas sesi.
4. (Dari FIX120) permintaan fokus audio eksklusif ikut dipegang saat layar sistem tampil, padahal layar sistem meminta fokus sendiri.

## Perbaikan
- Pemicu baru yang datang lebih dari 6 detik setelah pengenalan dimulai (dan belum ada hasil) memulai ulang pengenalan dari awal: layar
  sistem lama ditutup, hasilnya diabaikan (kode permintaan per generasi), lalu mikrofon dibuka lagi. Pemicu ganda dalam 6 detik tetap diabaikan.
- Galat mikrofon dari layar sistem (atau pembatalan dalam kurang dari 1,5 detik) diulang satu kali setelah jeda 0,9 detik, memakai pengenal
  dalam aplikasi bila izin mikrofon ada, jika tidak layar sistem lagi. Bila tetap gagal: getar panjang, pesan "Mikrofon belum dapat
  diaktifkan..." (Indonesia dan Inggris), lalu layar ditutup dan audio yang dijeda dilanjutkan.
- Jalur cadangan menunggu 0,5 detik sebelum membuka layar sistem.
- Fokus audio sementara kini hanya diminta untuk pengenal dalam aplikasi; layar sistem meminta fokus audionya sendiri seperti sebelum FIX120.
  Audio Khatam tetap dijeda eksplisit selama mikrofon dibuka.

## Bahasa aktif
Satu teks baru (`perintah_suara_mikrofon_gagal`) ditambahkan di `values` dan `values-en`; pemeriksa bahasa aktif lulus.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, dan tiga uji kontrak lulus; kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat. Kegagalan yang berasal dari aplikasi Google (layanan pengenal suara) tidak dapat dihilangkan
  seluruhnya dari sisi aplikasi; perbaikan ini membuatnya pulih sendiri atau memberi tahu pengguna. Bila masih terjadi, kirim log
  (logcat) saat gagal serta perkiraan jumlah pemakaian sebelum gagal, dan apakah pemicu ke-7 terasa "tidak berbuat apa-apa" atau menampilkan layar sistem.
