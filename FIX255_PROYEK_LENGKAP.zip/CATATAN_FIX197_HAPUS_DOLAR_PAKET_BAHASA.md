# FIX197: hapus tanda dolar pada status paket bahasa offline

PaketBahasaOfflineActivity.kt: semua templat dengan label bahasa diganti penggabungan teks biasa (+ label +), sehingga tidak ada karakter dolar di teks status, baik Indonesia maupun Inggris. Tidak ada tr() lain di proyek yang memakai templat dolar.
