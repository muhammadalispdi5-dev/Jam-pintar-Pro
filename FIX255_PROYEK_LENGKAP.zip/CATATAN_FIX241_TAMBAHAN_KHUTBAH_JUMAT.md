# CATATAN FIX241: Tambahan Koleksi Khutbah Jumat

Versi tetap 1.0.87 (versionCode 87).

## Perubahan
- Koleksi Himpunan Khutbah Jumat Pilihan bertambah dari 84 menjadi 114 naskah (30 naskah baru) dalam berkas baru `KhutbahTambahanD.kt`, didaftarkan di `KhutbahData.daftar`.
- Tiap naskah memuat: kutipan dalil berbahasa Arab, terjemahan Indonesia dan Inggris, sumber, tiga bagian isi, penutup khutbah kedua, serta doa baku.
- Petunjuk penggunaan (ID dan EN) kini menyebut jumlah 114 naskah.

## Tema baru
Iman kepada Qadha dan Qadar; Iman kepada Hari Akhir; Ihsan; Shalawat kepada Nabi; Istighfar; Menebar Salam; Bersuci dan Wudhu; Khusyuk dalam Shalat; Qiyamullail; Mencintai Rasulullah dan Sunnahnya; Meneladani Sahabat; Menjauhi Kezaliman; Berutang dan Menunaikan Utang; Menutup Aib; Mendamaikan yang Berselisih; Melawan Hawa Nafsu; Puasa Enam Hari Syawal; Bijak Bermedia Sosial; Menjenguk Orang Sakit dan Mengantar Jenazah; Menjauhi Kikir; Tafakkur; Tujuh Golongan di Bawah Naungan Allah; Memudahkan Pernikahan; Muhasabah Diri; Berdakwah dengan Hikmah; Menjaga Pandangan; Menenangkan Hati dari Cemas dan Sedih; Adab Berbeda Pendapat; Selaras Ucapan dan Perbuatan; Meninggalkan yang Tidak Bermanfaat.

## Pemeriksaan
- Uji kompilasi logika (kotlinc): total 114 naskah, judul unik 114, tidak ada teks Indonesia/Inggris kosong, 30 naskah baru semuanya berdalil Arab.
- Empat pemeriksa proyek lulus.

## Catatan
- Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
- Naskah adalah draf; sebaiknya ditinjau ustadz atau takmir, terutama redaksi hadits dan terjemahannya, sebelum disampaikan di mimbar.
