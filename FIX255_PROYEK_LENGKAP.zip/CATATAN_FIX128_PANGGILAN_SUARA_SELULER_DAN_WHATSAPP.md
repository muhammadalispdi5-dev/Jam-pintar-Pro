# FIX128 — Panggilan melalui perintah suara

## Perubahan
- Perintah `telepon/panggil/hubungi <nama atau nomor>` untuk telepon seluler kini memakai `ACTION_CALL` setelah pengguna memberikan izin runtime `CALL_PHONE`. Dengan demikian, panggilan seluler dapat langsung dimulai tanpa menekan tombol Panggil di dialer.
- Jika izin panggilan ditolak atau dicabut, aplikasi kembali membuka dialer dengan nomor terisi; tidak memaksa panggilan.
- Jika kontak yang cocok lebih dari satu, pengguna tetap harus memilih kontak yang benar sebelum panggilan dilakukan.
- Perintah `telepon WhatsApp <nama/nomor>` membuka percakapan di WhatsApp Messenger. `telepon WhatsApp Business <nama/nomor>` membuka percakapan di WhatsApp Business. Format nomor lokal Indonesia yang diawali 0 atau 8 dibantu diubah ke format 62.
- Pesan arahan mengikuti bahasa aplikasi yang aktif.

## Batasan platform yang penting
WhatsApp Messenger dan WhatsApp Business tidak menyediakan API publik/intent resmi untuk memulai panggilan suara atau video langsung dari aplikasi pihak ketiga. Karena itu aplikasi hanya dapat membuka chat yang benar; pengguna perlu menekan ikon panggilan suara/video di dalam WhatsApp. Otomasi klik UI/accessibility tidak ditambahkan karena rapuh, dapat salah menekan kontrol, dan tidak didukung sebagai antarmuka panggilan resmi.

## Privasi dan keselamatan
Panggilan seluler hanya dilakukan setelah perintah suara panggilan eksplisit dan izin Android `CALL_PHONE` diberikan. Bila kontak ambigu, pilihan kontak tetap diminta.

## Verifikasi
Manifest dan kode sumber diperbarui. Arsip ZIP diperiksa integritasnya. Kompilasi Gradle dan pengujian pada perangkat fisik belum dilakukan pada lingkungan ini.
