# FIX48 — Keluaran Suara Stereo / Mono

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX47.

## Penyebab
Menu "Keluaran suara: Stereo / Mono" hanya dialog informasi yang mengarahkan ke pengaturan Audio mono sistem Android. Tidak ada pilihan yang tersimpan maupun berpengaruh pada pemutaran, karena MediaPlayer tidak menyediakan downmix mono.

## Perbaikan
- Berkas baru `PemutarAudio.kt`: antarmuka `PemutarAudio`, `PemutarStereo` (MediaPlayer seperti semula), dan `PemutarMono`.
- `PemutarMono` mendekode audio dengan `MediaExtractor` + `MediaCodec`, merata-ratakan semua kanal menjadi satu, lalu memutar lewat `AudioTrack` mono. Jeda/lanjut, kecepatan 0,75x–1,5x, penyelesaian trek, pengulangan hafalan, dan Equalizer (lewat sesi audio bersama FIX47) tetap berjalan.
- Menu kini berisi pilihan Stereo / Mono yang disimpan (`keluaran_suara_audio`) dan berlaku pada audio berikutnya. Tombol "Pengaturan mono sistem" tetap ada untuk mono tingkat sistem.
- `KhatamActivity.kt` memakai `PemutarAudio` sebagai pengganti MediaPlayer langsung.

## Pemeriksaan dan batas
- `tools/verify_project.py`: LULUS; keseimbangan tanda kurung Kotlin sesuai.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji terutama: mono pada audio ayat dan surah penuh, jeda/lanjut, kecepatan, pindah ayat, mode hafalan berurutan, Equalizer saat mono.
- Mono tidak memengaruhi suara terjemahan dari Text-to-Speech.
