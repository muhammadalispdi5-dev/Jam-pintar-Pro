# FIX162 — Efek vokal Jam/Baterai, koreksi katalog qari, dan cadangan cuaca

Sumber kerja: paket FIX161 yang diunggah pengguna. Versi aplikasi dipertahankan pada `1.0.82` / `versionCode 82`.

## 1. Efek vokal untuk Jam dan Baterai
- Mengganti pilihan bip tunggal/ganda pada pengaturan suara Jam dan Baterai dengan preset efek ruang untuk suara TTS.
- Pilihan: normal, ruang kecil, ruang sedang, ruang besar, aula sedang, aula besar, dan studio/plate.
- Efek diterapkan memakai Android `PresetReverb` pada audio session TTS untuk Android 8.0+ bila mesin TTS/perangkat mendukungnya. Bila tidak didukung, pengumuman tetap berjalan dengan suara normal.
- Volume digital independen Jam dan Baterai tetap dipertahankan. Reset Baterai juga menghapus preferensi efek ruang; reset Jam mengikuti prefiks `jam_`.
- Efek dan equalizer Khatam Al-Qur'an tidak diubah.

## 2. Katalog qari perempuan
- Menghapus pilihan katalog qari perempuan yang sebelumnya memakai sumber rekaman Noreen yang identitas/karakter suaranya tidak dapat dipastikan sesuai permintaan pengguna.
- Menghapus fallback rekaman tersebut dan klasifikasi otomatis qari perempuan dari katalog MP3Quran.
- Mengabaikan entri cache lama berlabel `Perempuan ·`.
- Jika qari yang tersimpan sebelumnya adalah entri Noreen/perempuan lama, pilihan dikembalikan ke Mishary Rashid Alafasy agar aplikasi tidak terus memutar pilihan yang keliru.
- Katalog qari dewasa, qari anak, dan katalog audio per ayat tetap tersedia.

## 3. Informasi cuaca
- Open-Meteo tetap menjadi sumber utama.
- Jika sumber utama mengalami timeout, gangguan DNS/TLS/soket, respons HTTP gagal, atau data tidak dapat dibaca, aplikasi mencoba sumber cadangan `wttr.in` memakai koordinat yang sama.
- Jika sumber cadangan berhasil, asisten membacakan kondisi, suhu, dan data tambahan yang tersedia serta menyebut sumber cadangannya.
- Jika kedua sumber tidak tersedia, pesan kegagalan tidak lagi menyimpulkan bahwa koneksi internet ponsel pasti bermasalah.
- Lokasi langsung perangkat dan lokasi tersimpan Jadwal Sholat sebagai cadangan tetap dipertahankan.

## 4. Bahasa dan aksesibilitas
- Label pengaturan, opsi efek, dan petunjuk penggunaan tersedia dalam Bahasa Indonesia dan English.
- Spinner efek diberi deskripsi aksesibilitas.

## 5. Pemeriksaan
- Skrip uji sumber terkait efek vokal, qari, dan cuaca: lulus.
- Semua skrip `uji_*.py` yang selesai dijalankan selain skrip penafsir Qur'an yang berjalan sangat lama: lulus.
- Pemeriksaan resource string dan konsistensi bahasa: lulus.
- Pemeriksaan ZIP: dilakukan setelah paket dibuat.
- Belum menjalankan kompilasi Gradle/Kotlin atau pengujian pada perangkat Android. Karena itu, keberhasilan APK tetap harus dikonfirmasi lewat GitHub Actions.
