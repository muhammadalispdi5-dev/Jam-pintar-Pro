# FIX125 — Pola putar/jeda pada tes suara pengingat sebelum waktu shalat

Basis: FIX124. Berkas: `PrayerSettingsActivity.kt`, `PrayerAlarmService.kt`, `BahasaAplikasi.kt`.

## Masalah
Tombol "Tes suara pengingat sebelum ..." selalu memulai tes baru. Mengetuknya lagi saat suara sedang diputar memutar ulang dari awal, tidak menjeda.
Tes suara azan sudah memakai pola putar/jeda (ketukan kedua pada tes yang sama = jeda, ketukan berikutnya = lanjut), tetapi tes pengingat belum.

## Perbaikan
- Tombol berjudul "Putar atau jeda tes suara pengingat sebelum <waktu>" (terjemahan Inggris ditambahkan).
- Ketuk pertama memulai tes; ketuk pada tes pengingat yang sama menjeda atau melanjutkan (aksi `TOGGLE_TEST_PLAYBACK`); mengetuk tes lain (waktu shalat lain atau tes azan) memulai tes itu.
- Berlaku untuk semua jenis suara pengingat:
  - suara bawaan aplikasi dan berkas pilihan pengguna: dijeda di tempat dan dilanjutkan dari posisi yang sama;
  - ucapan mesin TTS: tidak dapat dijeda di tengah kalimat, jadi dihentikan saat jeda dan diucapkan ulang dari awal saat dilanjutkan.
- Notifikasi tes pengingat kini memiliki tombol Jeda/Lanjutkan dan Hentikan, dengan judul "Tes suara pengingat sebelum salat <waktu> — dijeda/sedang diputar".
- Perbaikan terkait pada jalur TTS (juga memengaruhi tes sahur): penutup otomatis 15 detik tidak lagi memotong tes yang sedang dijeda. Saat dijeda, layanan menunggu paling lama 10 menit lalu berhenti sendiri.
- Tombol "ulangi tes aktif" yang dipanggil setelah mengganti berkas suara kini mengenali tes pengingat (sebelumnya akan salah memutar sebagai azan).

## Cara menguji
1. Pengaturan Sholat > bagian pengingat sebelum waktu shalat > "Putar atau jeda tes suara pengingat sebelum Subuh": suara mulai.
2. Ketuk lagi saat suara berjalan: suara berhenti sementara (notifikasi "dijeda").
3. Ketuk lagi: lanjut (berkas: dari titik jeda; TTS: dari awal kalimat).
4. Coba dengan tiga jenis suara: bawaan, berkas sendiri, dan TTS; lalu ketuk tes waktu shalat lain di tengah pemutaran (harus memulai tes yang baru).

## Batas pemeriksaan
Belum dikompilasi dan belum diuji di perangkat. Pemeriksaan statis lulus: kurung seimbang, tidak ada escape tidak sah, `tools/verify_project.py` lulus.
