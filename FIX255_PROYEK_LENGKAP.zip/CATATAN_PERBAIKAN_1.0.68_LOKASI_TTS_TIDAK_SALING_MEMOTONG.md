# Perbaikan pembacaan suara fitur Ketahui Lokasi Terkini

- Fitur memakai satu instance `Pembicara` selama sesi lokasi, bukan membuat mesin suara baru pada setiap pembaruan.
- Panduan awal pencarian dibacakan satu kali.
- Pembaruan status jumlah satelit berkala hanya memperbarui teks status, tidak lagi menyela/mengganti ucapan yang sedang berjalan.
- Setelah koordinat dan nama tempat selesai diproses, ringkasan lokasi masuk ke antrean TTS sesudah panduan awal selesai.
- Perintah pengguna seperti “Bacakan kembali lokasi terakhir” dan pemilihan lokasi tersimpan tetap dapat mengganti antrean agar hasil yang diminta segera dibacakan.
- Mesin suara sesi lokasi dihentikan dan dibersihkan ketika halaman ditutup.
- Tidak ada perubahan yang disengaja pada alur pengambilan lokasi GPS, GNSS, geocoder, atau fitur lokasi tersimpan lainnya.

Catatan validasi: sumber telah diperbarui dan arsip ZIP diperiksa. Kompilasi Gradle dan uji perangkat Android belum dijalankan di lingkungan ini.
