# Catatan Perbaikan FIX33 — Audio Qari dan Pencarian Bacaan

Versi aplikasi tetap `1.0.69` / `versionCode 69`.

## Perubahan
- Label qari di menu utama dan pembaca disimpan sebagai referensi tampilan dan diperbarui setelah qari diganti, agar tidak tetap menampilkan Mishary Alafasy saat qari MP3Quran lain dipilih.
- Menambahkan pintu pemutaran terpadu **Putar murattal / Pilih cara pemutaran** dengan opsi ganti qari, putar juz, putar seluruh surah, putar ayat saat ini, dan pencarian.
- Menambahkan pencarian berdasarkan `Juz 30`, nama/nomor surah, `2:255`, `2/255`, atau `Surah 2 ayat 255`.
- Pencarian memvalidasi nomor surah (1–114) dan ayat berdasarkan panjang surah dari teks Qur'an yang tersimpan.
- Untuk qari MP3Quran yang hanya menyediakan audio per surah, aplikasi menjelaskan bahwa audio ayat/juz terpisah tidak tersedia; permintaan ayat diputar sebagai surah penuh sesuai fallback yang diberi tahu pengguna.
- Percobaan ulang bitrate yang identik untuk URL MP3Quran dihentikan. Bila server qari tersebut gagal, aplikasi lebih cepat menampilkan status kegagalan alih-alih mencoba URL yang sama berkali-kali.

## Pemeriksaan
- `tools/verify_project.py`: LULUS; versi tetap 1.0.69 / versionCode 69.
- Pemeriksaan parser Kotlin tidak menemukan error sintaks (`expecting`, `syntax error`, `unexpected tokens`).
- Kompilasi Android/Gradle penuh dan uji pemutaran pada perangkat nyata belum dilakukan dalam lingkungan ini. Keberhasilan URL server khusus qari MP3Quran tetap perlu diuji di perangkat dengan koneksi internet.
- Jika pengguna meminta ayat tertentu sementara qari MP3Quran hanya menyediakan surah penuh, aplikasi menampilkan dialog pilihan: putar surah penuh, ganti ke qari yang mendukung audio per ayat, atau batal. Dengan demikian aplikasi tidak mengklaim sedang memutar satu ayat ketika sebenarnya memutar surah penuh.
