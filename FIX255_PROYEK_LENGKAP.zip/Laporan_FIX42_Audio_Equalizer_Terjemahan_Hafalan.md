# FIX42 — Penyempurnaan Audio dan Hafalan

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis proyek: FIX41.

## Perubahan

1. **Equalizer audio** dengan preset Normal, Vokal/Bacaan, Bass, dan Treble. Equalizer memakai efek audio Android yang terhubung ke sesi MediaPlayer. Jika perangkat tidak mendukung efek tersebut, audio tetap berjalan normal.
2. **Stereo/Mono**: ditambahkan pintasan ke pengaturan Aksesibilitas Android dan petunjuk bahwa Mono Audio merupakan pengaturan sistem (umumnya Aksesibilitas > Peningkatan pendengaran > Audio mono). Android MediaPlayer pada implementasi ini tidak menyediakan downmix mono per-aplikasi; aplikasi tidak mengklaim mengubah kanal mono sendiri.
3. **Audio terjemahan**: pilihan Murattal Arab, Terjemahan saja, atau Murattal Arab lalu Terjemahan. Terjemahan dibacakan oleh Text-to-Speech Android memakai terjemahan yang telah diunduh dan bahasa aktif aplikasi. Mode terjemahan dan mode gabungan saat ini ditujukan untuk ayat yang dipilih; pemutaran surah penuh/juz tetap menggunakan murattal Arab. Ketersediaan suara bergantung pada mesin TTS dan paket bahasa di perangkat.
4. **Latihan koreksi hafalan mandiri**: teks ayat dapat disembunyikan saat pengguna membaca dari hafalan, lalu ditampilkan kembali untuk dicocokkan. Fitur ini tidak mengklaim melakukan pengenalan bacaan, penilaian tajwid, atau koreksi makhraj otomatis.
5. Semua pilihan disimpan di preferensi aplikasi, label dialog tersedia dalam bahasa Indonesia dan Inggris, serta tombol kembali mengarah ke pengaturan audio.

## Pemeriksaan

- `tools/verify_project.py`: **LULUS**.
- Arsip ZIP diperiksa dengan `unzip -t`.
- Pemeriksaan parser Kotlin tidak menemukan diagnostik sintaks (`Expecting`, `unexpected tokens`, atau `Unterminated`).
- **Belum** dilakukan kompilasi Gradle penuh karena proyek yang tersedia tidak menyertakan `gradlew` dan lingkungan ini tidak menyediakan perintah `gradle`.
- **Belum** dilakukan pengujian pada perangkat Android, termasuk uji Equalizer hardware, TTS, TalkBack, dan pengaturan Mono tiap merek perangkat.

## Batasan penting

- Mono Audio diaktifkan melalui pengaturan sistem Android, bukan dipaksa dari dalam aplikasi.
- Audio terjemahan menggunakan TTS perangkat, bukan rekaman qari/voice-over studio.
- Latihan koreksi hafalan adalah metode mandiri dengan pencocokan visual; bukan koreksi otomatis berbasis AI.
