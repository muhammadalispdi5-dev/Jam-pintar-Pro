# FIX169 — "Pilih suara qari" langsung terbuka

Basis: FIX168. Berkas: `KhatamActivity.kt`, uji baru `tools/uji_pilih_qari_cepat.py`.

## Masalah
Mengetuk "Pilih suara qari" membuat pengguna menunggu cukup lama (muncul toast "Memuat katalog qari…") sebelum dialog terbuka.

## Penyebab
`pilihQari` baru membuka dialog setelah katalog MP3Quran diunduh dari jaringan: tiga permintaan HTTP berurutan (batas waktu 20 detik untuk sambung dan 30 detik untuk baca)
ditambah pemeriksaan kelengkapan surah tiap qari. Cache lokal hanya melengkapi daftar qari anak dan tidak menandai katalog sebagai "sudah dimuat", jadi unduhan ini terulang pada
setiap sesi aplikasi, dan terasa jauh lebih lama saat jaringan lambat atau mati.

## Perbaikan
- Dialog pilihan katalog qari kini terbuka seketika dari data lokal; `pilihQari` tidak lagi membuat thread jaringan di jalur tampilan.
- Katalog lengkap (semua qari MP3Quran yang punya 114 surah, bukan hanya qari anak) disimpan ke berkas lokal `katalog_qari_mp3quran.json` setelah unduhan berhasil, dibaca satu kali per sesi
  dengan cepat, sehingga ketiga kategori (anak, per surah, terbaik per surah) langsung terisi pada sesi berikutnya, juga tanpa internet. Kategori "per ayat / juz" memakai daftar bawaan dan tidak pernah menunggu.
- Pembaruan katalog berjalan di latar belakang: dimulai 2,5 detik setelah layar Khatam terbuka bila belum ada cache atau cache lebih dari 7 hari, dan juga saat "Pilih suara qari" dibuka bila perlu.
- Hanya pada pemakaian pertama (belum ada cache dan belum ada internet cepat): memilih kategori yang butuh katalog menampilkan dialog "Memuat daftar qari…" yang otomatis diganti dengan daftar begitu unduhan selesai
  (tanpa perlu membuka ulang). Jika unduhan gagal dan data tidak ada, muncul pesan lama dan pengguna kembali ke pilihan katalog.
- Tombol Kembali, kembali sistem, dan sentuhan di luar dialog tetap naik satu tingkat; pilihan qari tetap tersimpan sebagai `qari_audio_id` dan menghentikan audio seperti sebelumnya.
- Pencarian qari lewat perintah suara ikut cepat karena memakai cache yang sama.

## Bahasa aktif
Semua teks baru memakai `tr(Indonesia, English)`: "Memuat daftar qari… Daftar akan tampil otomatis begitu siap." / "Loading the reciter list… It will appear automatically when ready."
Pemeriksaan bahasa aktif dan resource string lulus.

## Cara menguji
1. Pasang, buka Khatam, tunggu beberapa detik (katalog diunduh di latar belakang). Buka Pengaturan audio > Pilih suara qari: dialog harus langsung muncul, tanpa toast "Memuat katalog".
2. Pilih tiap kategori: daftar qari langsung tampil. Pilih satu qari: tersimpan dan diumumkan seperti biasa.
3. Tutup aplikasi sepenuhnya, matikan internet, buka lagi dan ulangi: kategori masih terisi dari berkas lokal.
4. Uji pemakaian pertama: Hapus data aplikasi, buka "Pilih suara qari" segera dengan internet hidup: kategori per surah menampilkan "Memuat daftar qari…" lalu daftar muncul sendiri.

## Batas pemeriksaan
Belum dikompilasi dan belum diuji di perangkat (tidak ada Gradle/SDK di lingkungan ini). Pemeriksaan statis lulus: kurung seimbang, tidak ada escape tidak sah, `verify_project.py`,
pemeriksaan bahasa aktif, dan semua `tools/uji_*.py` termasuk uji baru lulus.
