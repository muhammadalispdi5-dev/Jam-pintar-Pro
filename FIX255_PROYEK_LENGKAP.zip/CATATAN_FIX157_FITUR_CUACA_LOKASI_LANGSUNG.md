# FIX157 — Perbaikan Informasi Cuaca Berbasis Lokasi Perangkat

## Temuan
Fitur perintah suara cuaca ternyata sudah ada dan sudah terhubung ke Open-Meteo. Masalah utamanya adalah fungsi lama hanya memakai koordinat yang tersimpan di Pengaturan Jadwal Sholat (`PrayerPrefs`). Izin lokasi Android yang aktif tidak otomatis berarti koordinat tersebut sudah tersimpan, sehingga aplikasi dapat menampilkan pesan kegagalan walaupun layanan lokasi perangkat aktif.

## Perbaikan
- Perintah “bacakan cuaca” sekarang mencoba memperoleh lokasi perangkat terkini melalui GPS dan penyedia jaringan saat izin lokasi tersedia.
- Pencarian lokasi langsung dibatasi sekitar 12 detik; lokasi terakhir yang masih baru dapat dipakai sebagai cadangan.
- Jika lokasi perangkat tidak tersedia, aplikasi memakai koordinat valid yang tersimpan pada Pengaturan Jadwal Sholat.
- Jika kedua sumber lokasi tidak tersedia, asisten menjelaskan bahwa lokasi belum berhasil diperoleh dan memberi langkah yang relevan.
- Permintaan HTTPS ke Open-Meteo menetapkan metode GET, header JSON, tanpa cache, mengikuti pengalihan, dan batas waktu yang lebih longgar.
- Pesan kegagalan dibedakan antara layanan yang lambat, layanan data yang tidak dapat dihubungi, dan respons yang tidak dapat dibaca; tidak lagi selalu menyalahkan izin/lokasi.
- Petunjuk Indonesia dan English diperbarui agar menjelaskan prioritas lokasi perangkat dan lokasi tersimpan sebagai cadangan.
- Perintah tetap berada di Asisten Suara/Beritahu Saya, tanpa menambah menu terpisah yang menduplikasi fungsi.
- Tidak mengirim atau menyimpan koordinat lokasi ke pengembang. Koordinat hanya dipakai untuk permintaan data cuaca.

## Pemeriksaan
- `tools/uji_cuaca_lokasi_langsung.py`: lulus.
- `tools/periksa_bahasa_aktif.py`: lulus.
- `tools/periksa_resource_strings.py`: lulus.
- Seluruh skrip `tools/uji_*.py`: lulus pada pemeriksaan sebelumnya; uji khusus cuaca ditambahkan dan lulus.
- XML resource dan manifest: valid.
- Versi dipertahankan pada `1.0.82` / `versionCode 82`.

## Batas verifikasi
Lingkungan kerja ini tidak menyediakan Gradle wrapper/Android SDK dan workflow GitHub Actions tidak termasuk dalam arsip sumber. Karena itu kompilasi Kotlin/APK dan uji langsung di perangkat belum dilakukan. Jalankan GitHub Actions untuk memastikan hasil kompilasi sebelum memasang APK.
