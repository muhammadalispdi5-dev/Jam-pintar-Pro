# FIX112 — Merapikan bagian "Latihan Hafalan" di menu utama Khatam

Versi aplikasi: **1.0.76** (versionCode 76). Basis: FIX111. Berkas diubah: `KhatamActivity.kt`, `app/build.gradle.kts`.

## Pertanyaan: masih relevankah dua tombol itu di menu utama?
Sebagian. Sejak Asisten Tahfiz Cerdas dipindah ke menu utama (FIX111), kedua fitur sudah dapat dicapai dari dalam Asisten:
- **Latihan hafalan tanpa mikrofon**: Asisten Tahfiz Cerdas > Asisten Hafalan Inklusif > Mulai latihan tanpa mikrofon (juga tombol netral di Asisten Koreksi Bacaan).
- **Koreksi otomatis dengan pengenalan suara**: Asisten Tahfiz Cerdas > Asisten Koreksi Bacaan > Mulai koreksi bacaan.

Akibatnya bagian LATIHAN HAFALAN memuat dua jalan masuk ke fungsi yang sama, dan hingga enam butir bagi pengguna pembaca layar (Asisten, Ulas hafalan hari ini, Muraja'ah cerdas, Koreksi otomatis, Latihan tanpa mikrofon, ditambah teks pengantar). Tujuan permintaan awal (tidak perlu masuk Pengaturan) tetap terpenuhi, karena Asisten bukan bagian Pengaturan.
Harga yang dibayar: dua ketukan lebih banyak untuk memulai (menu utama > Asisten > pilihan > Mulai, bukan satu ketukan). Karena itu pintasan tidak dihapus, hanya dijadikan pilihan.

## Perubahan
- Menu utama Khatam, LATIHAN HAFALAN: tombol **Koreksi otomatis dengan pengenalan suara** dan **Latihan hafalan tanpa mikrofon** kini **tersembunyi secara bawaan**. Yang tersisa: Asisten Tahfiz Cerdas, serta "Ulas hafalan hari ini" dan "Muraja'ah cerdas" hanya bila ada ayat yang jatuh tempo (tidak diubah).
- Teks pengantar bagian itu kini menyebut nama kedua fitur dan mengarahkan pengguna ke Asisten, supaya pengguna lama tahu ke mana tombolnya pindah.
- Panel Asisten: uraian butir memakai nama fitur persis seperti pada tombol lama ("Latihan hafalan tanpa mikrofon", "Koreksi otomatis dengan pengenalan suara").
- Pengaturan Khatam > Pengaturan hafalan > Fitur latihan hafalan (saklar): butir baru **Pintasan dua latihan di menu utama Khatam** (tampil/tersembunyi, bawaan tersembunyi). Mengubahnya langsung menampilkan atau menyembunyikan kedua tombol tanpa membangun ulang menu. Saklar aktif/nonaktif tiap fitur tetap berlaku untuk Asisten maupun pintasan; pintasan hanya tampil bila fitur terkait aktif **dan** pintasan diaktifkan.
- Tombol "Atur ulang pengaturan Khatam" ikut mengembalikan kunci baru `hafalan_pintasan_menu_aktif` ke bawaan.
- Teks id/en lewat `tr()`.

## Dampak bagi pengguna yang sudah memakai FIX111
Dua tombol itu hilang dari menu utama setelah pembaruan sampai pengguna menyalakan pintasan. Fiturnya tidak hilang; lokasinya di Asisten Tahfiz Cerdas.

## Pemeriksaan dan batas
- Kurung `()` `{}` `[]` seimbang; `tools/verify_project.py`, `periksa_bahasa_aktif.py`, `uji_murajaah_cerdas.py`, dan `uji_penafsir_quran.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: menu utama tanpa pintasan, menyalakan pintasan dari dialog saklar, mematikan salah satu fitur lalu menyalakan pintasan, urutan sapuan TalkBack, dan ganti bahasa.
