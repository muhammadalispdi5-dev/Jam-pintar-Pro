# FIX187 - Pemilih waktu pengingat yang ramah pembaca layar

Basis: FIX186. Versi aplikasi tidak diubah.

## Masalah
Waktu pada Pengingat membaca Al-Qur'an dipilih dengan jam analog Android (TimePickerDialog), yang sulit dipakai dengan TalkBack.

## Perbaikan
- Pemilih baru `dialogJamMenit`: dua penggulung angka berlabel "Jam" dan "Menit". Dengan TalkBack, geser ke atas atau bawah pada penggulung untuk mengubah angka; pengguna biasa dapat mengetuk tombol tambah/kurang atau mengetik angkanya. Waktu terpilih ditulis besar dan diumumkan otomatis setiap berubah ("Waktu terpilih: 20:30"). Tombol Simpan dan Batal; Kembali sistem kembali ke daftar waktu.
- Dipakai di Pengingat membaca (tambah atau ubah waktu) dan di Pengingat cerdas hafalan. Tidak ada lagi TimePickerDialog di Khatam.
- Menu pengingat memakai kalimat yang lebih jelas: "Ubah waktu pengingat: ..." dan "Suara notifikasi pengingat: ...".
- Fitur FIX186 tetap: beberapa waktu, pilihan hari, suara alarm/notifikasi/ucapan/berkas sendiri, tes, tunda, dan jadwal tepat waktu.
- Pemeriksa bahasa dan resource string lulus; uji `tools/uji_fix186_pengingat_baca.py` diperluas. Belum dikompilasi dan belum diuji di perangkat.
