# Tahap 19 — Mencegah status sinkronisasi sukses palsu saat unduhan parsial

## Temuan
Sinkronisasi mengambil jadwal untuk bulan berjalan dan bulan berikutnya. Sebelumnya, `signature` dan `last_sync` ditulis di dalam loop setelah setiap bulan. Jika bulan pertama berhasil tetapi permintaan bulan berikutnya gagal, aplikasi masih dapat menyimpan penanda waktu/sinkronisasi terbaru. Percobaan berikutnya lalu dapat menganggap data masih baru selama enam jam meskipun pengambilan jadwal belum lengkap.

## Perubahan
- Cache jadwal per bulan tetap disimpan setelah data bulan itu diterima.
- Penanda `signature` dan `last_sync` kini baru ditulis setelah semua permintaan bulan yang diperlukan selesai tanpa exception.
- Jika sinkronisasi berhenti di tengah jalan, penanda sukses penuh tidak diperbarui, sehingga aplikasi dapat mencoba sinkronisasi lagi.
- Tidak mengubah rumus waktu salat, penyesuaian menit, bahasa antarmuka, bahasa TTS, atau versi aplikasi.

## Pemeriksaan
- Perubahan Kotlin diperiksa secara statis dan blok penanda sinkronisasi dipastikan berada di luar loop bulanan.
- ZIP diuji integritasnya.
- Build Android penuh dan pengujian jaringan/perangkat belum dilakukan.
- Versi tetap 1.0.68 (`versionCode` 68).
