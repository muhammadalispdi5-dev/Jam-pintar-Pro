# FIX89 — Perintah suara kontekstual dan spesifik (V8)

## Perbaikan inti
- Penafsiran perintah suara sekarang mengevaluasi seluruh alternatif hasil pengenalan suara, bukan berhenti pada alternatif pertama yang kebetulan dikenali.
- Intent spesifik (tanggal Hijriah, tanggal Masehi, hari libur, waktu salat berikutnya, dan Al-Qur'an) diprioritaskan atas intent umum seperti waktu/tanggal.
- Ditambahkan variasi ejaan/pengenalan "hijriah/hijriyah", "salat/shalat/sholat/solat", serta nama salat.
- Frasa pertanyaan "tanggal Hijriah malam ini" hanya memanggil pembaca tanggal Hijriah. Frasa "jadwal salat yang akan datang" hanya memanggil pembaca waktu salat berikutnya.
- Perintah eksplisit membuka fitur diarahkan ke halaman fitur yang diminta: baterai, jam, kalender, pemanggil, jadwal salat, lokasi terkini, pemandu jalan, kiblat, fasilitas terdekat, doa, Khatam/Al-Qur'an, mode acara, dan bahasa.
- "Buka Al-Qur'an" membuka halaman Khatam; perintah putar surah/ayat/juz atau pemilihan qari tetap diteruskan ke penafsir audio Khatam.
- Bahasa pengenalan suara disesuaikan dengan bahasa aktif aplikasi: Indonesia, Inggris, Arab, Jawa, dan Sunda. Jika layanan pengenalan suara perangkat tidak mendukung bahasa tertentu, ketersediaannya tetap bergantung pada layanan Android yang terpasang.

## Prinsip keselamatan
- Perintah navigasi hanya membuka halaman fitur; tidak mengubah sakelar, menghapus data, memulihkan cadangan, atau melakukan tindakan destruktif tanpa konfirmasi dari UI fitur terkait.
- Bila maksud tidak dikenali, aplikasi meminta pengguna menyebutkan nama fitur/perintah dengan lebih jelas daripada menjalankan fitur yang salah.

## Validasi
- Periksa struktur proyek dan XML dengan tools/verify_project.py.
- Kompilasi Gradle dan uji pengenalan suara langsung pada perangkat tetap perlu dilakukan di CI/perangkat Android.
