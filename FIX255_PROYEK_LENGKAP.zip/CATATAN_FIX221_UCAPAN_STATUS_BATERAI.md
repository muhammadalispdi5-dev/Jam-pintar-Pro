# FIX221 — Ucapan status baterai oleh asisten suara
Kalimat perintah suara baterai kini: "Status baterai: delapan puluh lima persen. Tidak sedang diisi daya." (EN: "Battery status: eighty-five percent. Not charging.").
Angka dieja dengan kata (Indonesia dan Inggris) agar tidak bergantung pada pembacaan digit oleh mesin suara; keadaan pengisian menjadi kalimat tersendiri. Kata "tersisa" tidak dipakai.
