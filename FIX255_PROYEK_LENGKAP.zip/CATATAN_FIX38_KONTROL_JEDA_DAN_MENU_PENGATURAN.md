FIX38 — PENYEMPURNAAN KONTROL JEDA DAN NAVIGASI PENGATURAN AUDIO
Versi aplikasi dipertahankan: 1.0.69 (versionCode 69)

Perubahan:
1. Tombol jeda ditempatkan tepat setelah status audio dan sebelum tombol Putar pada halaman menu pemutaran maupun halaman pembaca. Ukuran tombol diperbesar agar lebih mudah ditemukan dan dijangkau.
2. Label dan contentDescription tombol berubah sesuai keadaan: jeda saat audio berjalan, lanjutkan saat audio dijeda, dan petunjuk saat audio belum dimulai. Status jeda/lanjutkan diumumkan melalui aksesibilitas.
3. Enam pilihan pengaturan audio tidak lagi diberi nomor di depan label, termasuk Pilih suara qari, Mode hafalan, dan Jumlah pengulangan ayat.
4. Setelah qari, mode hafalan, jumlah pengulangan, kecepatan, jeda antar ayat, atau cara pemutaran diubah, daftar utama Pengaturan Audio dibuka kembali. Pengguna tidak perlu masuk lagi dari halaman pembaca.
5. Perubahan mode hafalan dan cara pemutaran tidak lagi membangun ulang halaman pembaca saat pilihan disimpan, sehingga alur pengaturan tidak terputus.

Pemeriksaan:
- tools/verify_project.py: LULUS.
- Arsip ZIP: diperiksa dengan unzip -t.
- Pemeriksaan parser Kotlin tanpa Android/project classpath: tidak menemukan pola kesalahan sintaks (Expecting/Syntax error/Unexpected tokens). Pemeriksaan ini bukan kompilasi Android.
- Kompilasi Gradle penuh dan uji TalkBack pada perangkat belum dilakukan di lingkungan ini.
