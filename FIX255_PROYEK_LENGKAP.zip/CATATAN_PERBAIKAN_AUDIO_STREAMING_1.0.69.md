# Catatan perbaikan audio streaming — Jam Pintar Pro 1.0.69

## Perubahan pada paket sumber
- Pemutar audio memakai `MediaPlayer.setDataSource(context, Uri, headers)` dengan `User-Agent` dan `Accept` eksplisit untuk permintaan HTTP CDN.
- Percobaan ulang tetap memakai host `cdn.islamic.network`; fallback ke `cdn.alislam.ru` yang belum terverifikasi struktur endpoint-nya dihapus.
- Jalur percobaan memakai bitrate 128/64 kbps pada host yang sama. Timeout, penanganan error, dan pelepasan `MediaPlayer` ketika inisialisasi gagal tetap ditangani.
- Pemulihan pilihan pengulangan ayat sekarang menerima semua nilai 0 sampai 10; nilai 0 berarti terus-menerus. Sebelumnya hanya 0, 1, 3, dan 5 yang dipulihkan.
- Versi aplikasi tidak diubah: `versionCode 69`, `versionName 1.0.69`.
- Izin `INTERNET` sudah ada pada manifest dan dipertahankan.

## Batas verifikasi
- `tools/verify_project.py` lulus: konfigurasi versi, manifest, dan pemeriksaan struktur statis.
- Build Gradle dan uji pada perangkat Android belum dijalankan. Lingkungan pemeriksaan ini tidak memiliki Gradle wrapper pada proyek dan koneksi DNS ke CDN tidak tersedia; karena itu belum dapat diklaim bahwa audio sudah berhasil diputar pada perangkat.
- Perbaikan ini menargetkan jalur permintaan HTTP dan pengelolaan pemutar, tetapi harus diuji dengan audio ayat serta audio surah penuh di perangkat yang sebelumnya mengalami masalah.
