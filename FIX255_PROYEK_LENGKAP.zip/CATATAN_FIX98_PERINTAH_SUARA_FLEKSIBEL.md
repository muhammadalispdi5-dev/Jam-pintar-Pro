# FIX98 — Perintah suara Al-Qur'an yang fleksibel (pengulangan dan lainnya)

Basis: FIX97. Versi tetap. Perubahan utama di `PemutarQuranService.kt` (penafsir `PenafsirQuran` dan pemutar), dengan penyesuaian kecil di
`PerintahSuaraActivity.kt` dan `KhatamActivity.kt`.

## Contoh perintah yang kini dipahami
Pengulangan
- "putar surah Al Fatihah ayat 7 sebanyak 5 kali" · "putar surah 1 ayat 7 5 kali" · "putar surah 1 ayat 7 5x" · "play surah 1 verse 7 five times"
- "putar surah 36 ayat 1 sampai 10 tiga kali" (seluruh rentang diulang 3 putaran)
- "putar surah Al Ikhlas setiap ayat 3 kali" (tiap ayat diulang 3 kali berturut-turut; juga "tiap", "masing-masing")
- "putar Yasin 5 kali" (nama surah tanpa kata "surah")
- "putar surah Al Baqarah ayat 255 terus menerus" (juga "tanpa batas", "selamanya", "forever"); hentikan dengan "berhenti"
Rentang
- "putar surah Al Kahfi mulai ayat 10 sampai akhir" · "ayat 5 sampai ayat terakhir" · "dari ayat 3 hingga selesai"
Navigasi relatif (dari posisi terakhir yang diputar/dibaca)
- "ayat berikutnya" · "ayat sebelumnya" · "surah berikutnya" · "surah sebelumnya" · "juz berikutnya"
Mengulang perintah terakhir
- "ulangi" · "ulangi 3 kali" · "putar lagi" (memakai perintah putar terakhir; jumlah ulangan boleh diganti)
Kecepatan dan jeda (berlaku untuk perintah itu saja)
- "putar juz 30 pelan" (0,75x) · "cepat" (1,25x), "cepat cepat" (1,5x) · "normal"
- "putar surah 1 ayat 7 5 kali jeda 3 detik" (jeda antarbagian, 0–60 detik)
Perintah lama tetap sama: "putar surah 36 ayat 5", "putar juz 30", "putar surah Yasin", "berhenti/jeda/lanjut".

## Cara kerja
- Isyarat tambahan diekstrak lebih dulu dari ucapan (`ekstrakDirektif`), sisanya ditafsirkan seperti sebelumnya sehingga angka "5 kali" tidak lagi terbaca sebagai nomor ayat.
- Pengulangan tidak memperbesar daftar: pemutar menghitung bagian ke-i dari daftar dasar (batas 999 kali, atau tanpa batas).
- Pelacakan posisi: `terakhir_surah` dan `terakhir_ayat` diperbarui pada setiap ayat yang diputar (dipakai juga oleh Khatam dan "ayat berikutnya").
- Notifikasi menampilkan kemajuan, mis. "Surah 1 ayat 7, diulang 5 kali · 3/5", atau "putaran 4" untuk ulangan tanpa batas.
- Jeda antarbagian tetap menghormati Jeda/Lanjut/Berhenti, juga saat sedang menunggu.
- "Ayat saja" lebih diutamakan: bila ada ulangan pada satu ayat, hanya ayat itu yang diulang walau pengaturan Khatam "target pemutaran" bukan "ayat".

## Perutean (penting)
- Perintah dengan isyarat tambahan SELALU dijalankan pemutar latar belakang, juga saat layar tidak terkunci (hanya pemutar itu yang memahaminya).
- Perintah biasa tanpa isyarat tambahan tetap seperti FIX96/FIX97 (terkunci: pemutar latar belakang; tidak terkunci: Khatam).
- Perintah yang memilih qari tetap lewat Khatam; isyarat pengulangan di dalamnya dibersihkan dan Khatam memutar tanpa pengulangan (ada toast penjelasan).
- Jalur dalam aplikasi (tombol suara di Khatam) juga membersihkan isyarat tambahan agar tidak salah tafsir.
- Pemutar latar belakang memakai qari dan kecepatan yang tersimpan; Equalizer, mono/stereo, dan mode hafalan Khatam belum diterapkan di sana (sama seperti FIX96).

## Batasan
- Bilangan berurutan dalam kata ("ayat tujuh lima kali") digabung menjadi satu angka oleh pembaca angka yang sudah ada; sebut "sebanyak" atau pakai angka (mesin suara biasanya menulis angka).
- Belum dikompilasi/diuji di perangkat. Logika penafsiran diuji dengan tiruan Python pada 16 contoh ucapan; escape string seluruh berkas .kt dipindai ulang (aman), kurung seimbang, `verify_project.py` lulus.
