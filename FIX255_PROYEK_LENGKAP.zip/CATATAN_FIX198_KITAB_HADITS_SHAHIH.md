# FIX198: Fitur Kitab Hadits Shahih

Berkas baru: KitabHadits.kt (data, unduhan, pembaca JSON bertahap), HaditsActivity.kt (halaman).
Diubah: AndroidManifest.xml (activity), MainActivity.kt (tombol di beranda setelah Khatam), strings.xml id dan en (judul_hadits, menu_hadits).

Cara kerja:
- Teks hadits tidak ditulis di aplikasi. Diunduh sekali dari jsDelivr (cadangan GitHub) proyek fawazahmed0/hadith-api: edisi Arab dan terjemahan Indonesia.
- Disimpan di filesDir/hadits lalu dibaca secara streaming (memori kecil, bisa offline).
- Kitab: Shahih Bukhari (ara-bukhari, ind-bukhari), Shahih Muslim (ara-muslim, ind-muslim), Arbain Nawawi (ara-nawawi, ind-nawawi), Riyadhus Shalihin (ara-riyadussalihin, ind-riyadussalihin).
- Halaman kitab: unduh, cari nomor hadits, daftar bagian, baca dari awal, hapus data.
- Halaman baca: 5 hadits per halaman, teks Arab (RTL) + terjemahan, derajat, Salin, Bagikan, halaman/hadits berikutnya dan sebelumnya.
- Bila edisi Indonesia tidak ada, teks Arab tetap tampil dengan keterangan. Bila edisi Arab tidak ada (404), muncul pesan gagal unduh.

BELUM DIVERIFIKASI (sandbox tanpa akses jaringan ke layanan itu): nama edisi, terutama nawawi dan riyadussalihin, dan bentuk JSON (metadata.section, hadiths[].hadithnumber/text/grades/reference.book). Daftar kandidat ada di KitabHadits.daftar, mudah diubah.

Bahasa aktif: semua teks baru lewat tr() dan resource id/en; nama kitab dwibahasa. Pemeriksa bahasa aktif dan resource string LULUS.

## FIX199
Perbaikan: validasi unduhan memanggil baca(..., hanyaMetadata=true) sehingga tidak ada hadits terbaca dan semua unduhan ditolak. Kini hanyaMetadata=false.

## FIX200
Riyadhus Shalihin disembunyikan dari daftar karena tidak ada di layanan data (permintaan pengguna). Judul menu diperbarui. Sumber kandidat bila dilanjutkan: irsyadulibad/hadits-database (SQL, MIT).

## FIX201
- Riyadhus Shalihin kembali, bersumber dari berkas SQL repo irsyadulibad/hadits-database (MIT, terjemah Indonesia). Diunduh lalu dikonversi di perangkat ke JSON edisi (ara-riyadus, ind-riyadus). Pengurai SQL tidak bergantung pada urutan kolom (teks Arab = kolom mayoritas huruf Arab, terjemahan = teks terpanjang non-Arab). Pasangan Arab dari berkas lain TIDAK ditebak; bila baris tidak memuat Arab, hanya terjemahan Indonesia yang tampil.
- Audio: tombol "Dengarkan teks Arab" dan "Dengarkan terjemahan" per hadits (teks-ke-ucapan Android, bahasa Arab dan Indonesia), serta "Hentikan suara". Ini bukan rekaman qari; perlu data suara Arab/Indonesia terpasang. Berhenti saat halaman dijeda.
- BELUM DIVERIFIKASI: skema berkas SQL sebenarnya (sandbox tidak dapat membukanya).
Bahasa aktif: semua teks baru lewat tr() dan resource id/en; pemeriksa LULUS.
