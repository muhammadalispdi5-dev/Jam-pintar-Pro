# FIX102 - Koreksi otomatis memutar audio yang benar saat salah baca
Koreksi otomatis dengan pengenalan suara: bila hasil perbandingan menemukan bagian yang berbeda (jumlah > 0), audio ayat yang benar diputar otomatis sekitar 2,8 detik kemudian (memberi waktu untuk umpan balik singkat). Hasil kosong/tidak terbaca (-1) tidak memutar audio.
- Ucapan panjang (teks asli, teks dikenali, detail) tidak dibacakan TalkBack pada kasus salah baca agar tidak menimpa audio; teks lengkap tetap tampil di dialog. Yang diucapkan: "Ada bacaan yang kurang tepat. Mendengarkan bacaan yang benar."
- Audio memakai qari terpilih; bila qari MP3Quran (hanya per surah) dipakai qari per ayat Alafasy untuk koreksi saja tanpa mengubah pilihan qari.
- Saat audio koreksi selesai: status "Audio bacaan yang benar selesai. Tekan Ulangi membaca...", ada getar singkat, dan TIDAK kembali ke menu utama (FIX82 dilewati lewat flag koreksiAudioAktif). Menutup dialog atau menekan Ulangi membaca menghentikan audio koreksi.
- Saklar baru di Pengaturan Hafalan > Fitur latihan hafalan: "Putar audio yang benar saat salah baca" (kunci hafalan_audio_koreksi_aktif, default aktif, ikut direset).
Belum dikompilasi/diuji.
