# FIX203: Panduan Manasik Haji dan Doa-doanya

Berkas baru: ManasikHajiData.kt (17 bagian dwibahasa), ManasikHajiActivity.kt. Diubah: AndroidManifest.xml, MainActivity.kt (tombol setelah Khutbah), strings.xml id dan en.

Bagian: pengantar dan syarat; tiga cara berhaji; rukun/wajib/sunnah; persiapan dan doa safar; miqat dan ihram (niat, talbiyah); larangan ihram; masuk Makkah; tawaf; sa'i; tahallul umrah; 8 Dzulhijjah (Mina); 9 Dzulhijjah (Arafah); Muzdalifah; 10 Dzulhijjah (jumrah Aqabah, hadyu, tahallul, tawaf ifadhah); hari tasyrik; tawaf wada'; ziarah Madinah; doa-doa Al-Qur'an; tips jamaah tunanetra dan disabilitas.
Setiap bacaan: teks Arab, Latin, arti, sumber. Fitur: dengarkan bagian (bahasa aktif), dengarkan bacaan Arab per doa (suara Arab perangkat), ukuran huruf, salin, bagikan, bagian berikutnya/sebelumnya.

Catatan: mengikuti pendapat yang lazim di Indonesia (mazhab Syafi'i); perbedaan antarmazhab ada. Kutipan Arab dibatasi pada ayat, hadits, dan bacaan masyhur. Perlu ditinjau pembimbing/KBIHU. Doa "Allahummaj'alhu hajjan mabruran..." dan ucapan salam di Madinah ditandai sebagai doa lazim, bukan hadits tertentu. Belum dikompilasi/diuji.
Bahasa aktif: setiap blok punya id dan en; antarmuka lewat tr(); pemeriksa LULUS.
