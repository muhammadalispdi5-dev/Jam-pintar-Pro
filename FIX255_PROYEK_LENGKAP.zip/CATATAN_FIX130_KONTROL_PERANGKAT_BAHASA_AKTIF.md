# FIX130 — Perintah suara untuk pengaturan perangkat

## Perubahan
- Menambahkan perintah suara untuk membuka kontrol Bluetooth, Wi-Fi, hotspot seluler, data seluler, mode pesawat, lokasi, dan NFC.
- Mengenali instruksi Indonesia dan English, termasuk aktifkan/nyalakan/hidupkan dan matikan/nonaktifkan serta turn on/enable dan turn off/disable.
- Menangani perintah pengaturan sebelum kata "matikan" diproses sebagai perintah berhenti audio, agar "matikan Wi-Fi" tidak salah menghentikan pemutar Al-Qur'an.
- Memakai panel/pengaturan resmi Android dengan fallback ke pengaturan umum jika halaman khusus tidak tersedia pada perangkat.
- Tidak mengubah fitur panggilan seluler/WhatsApp, pemicu goncangan, widget Beritahu Saya, dan fungsi lain yang sudah ada.
- Memindahkan pesan fallback dari perintah suara yang sebelumnya masih literal Indonesia ke pasangan sumber daya Indonesia/English. Petunjuk perintah suara juga diperbarui dalam dua bahasa.

## Batasan Android
Aplikasi biasa yang menargetkan Android modern tidak dapat secara langsung mengubah Wi-Fi (Android 10+), dan BluetoothAdapter.enable/disable tidak berlaku untuk aplikasi yang menargetkan Android 13+ kecuali aplikasi istimewa/terkelola. Pengaturan hotspot juga dibatasi oleh Android dan produsen perangkat. Karena itu perintah suara membuka panel atau halaman pengaturan resmi; pengguna menyelesaikan perubahan sakelar di sana. Rujukan: dokumentasi Android WifiManager, perubahan perilaku Android 13, dan Settings.Panel.

## Bahasa aktif
Semua pesan baru, nama kontrol, dan petunjuk perintah disimpan di `values/strings.xml` dan `values-en/strings.xml`; Activity menggunakan `getString(...)` sehingga otomatis mengikuti bahasa tampilan aktif melalui `BahasaAplikasi.bungkus(...)`. Enam literal fallback baru dari fitur panggilan/pesan/aplikasi pada revisi sebelumnya juga dipindahkan ke pasangan sumber daya dua bahasa, bersama delapan literal lama yang sudah terdeteksi pemeriksa. Pemeriksaan `tools/periksa_bahasa_aktif.py` lulus dan jumlah literal lama turun dari baseline.

## Pemeriksaan
- XML Indonesia dan English valid; seluruh kunci sumber daya berpasangan.
- `python3 tools/periksa_bahasa_aktif.py`: lulus.
- `python3 tools/verify_project.py`: lulus.
- Kompilasi Gradle dan uji pada perangkat fisik belum dilakukan di lingkungan ini.
