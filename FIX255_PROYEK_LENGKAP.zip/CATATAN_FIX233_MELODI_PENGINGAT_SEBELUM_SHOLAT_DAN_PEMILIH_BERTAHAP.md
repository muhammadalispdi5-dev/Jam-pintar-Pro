# FIX233 — Melodi pengingat sebelum salat dan pemilih melodi bertahap

## Perubahan
- Menambahkan preferensi melodi sebelum dan sesudah suara pengingat pendahuluan untuk Subuh, Dzuhur, Ashar, Maghrib, dan Isya.
- Urutan pemutaran: melodi awal (jika dipilih) → suara pengingat yang telah dipilih sebelumnya (TTS/audio bawaan/berkas pengguna) → melodi akhir (jika dipilih).
- Pengingat sebelum salat tetap memakai pengaturan menit, sumber suara, penjadwalan, dan perilaku lama.
- Pemilih melodi sahur, berbuka, dan sebelum salat kini menampilkan daftar yang tetap terbuka saat setiap item dipilih; item langsung dipratinjau.
- Tombol centang membuka konfirmasi; tombol Simpan menerapkan pilihan. Batal tidak mengubah pilihan yang tersimpan. Pratinjau dihentikan saat dialog ditutup.
- Teks baru mengikuti mekanisme bahasa aktif Indonesia/Inggris aplikasi.
- Indeks melodi memakai katalog global yang sama, termasuk sirine pada indeks terakhir.
- Version name/code tetap 1.0.86 / 86.

## Pemeriksaan
- Pemeriksaan perubahan kode dan konsistensi referensi dilakukan.
- Arsip proyek berhasil dibuat dan diuji integritas ZIP-nya.
- Kompilasi Gradle belum dapat dijalankan di lingkungan ini karena arsip sumber tidak menyertakan `gradlew`/Gradle Wrapper dan executable Gradle tidak tersedia. Jalankan GitHub Actions untuk verifikasi kompilasi akhir.

## Uji regresi yang disarankan
1. Pilih beberapa melodi berturut-turut di daftar sahur/berbuka/pengingat sebelum salat; pastikan dialog tetap terbuka dan tiap pilihan langsung berbunyi.
2. Tutup dengan Batal dan pastikan pilihan tersimpan tidak berubah.
3. Centang lalu pilih Batal pada konfirmasi Simpan; pastikan pilihan lama tetap.
4. Centang lalu Simpan; pastikan pilihan baru tampil setelah halaman dimuat ulang.
5. Uji masing-masing salat dengan melodi awal dan akhir, serta tanpa melodi; pastikan suara TTS/audio pengingat tetap terdengar di antara keduanya.
6. Uji bahasa Indonesia dan Inggris serta uji pengingat sahur/berbuka untuk memastikan perilaku lama tidak berubah.
