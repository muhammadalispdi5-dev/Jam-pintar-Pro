# FIX90 — Pembacaan notifikasi pesan: hanya pesan MASUK

Versi tetap **1.0.69** (`versionCode 69`). Basis: FIX89 (V8). Berkas diubah: `CallerListener.kt` saja.

## Masalah
Penyaring pesan keluar lama hanya menolak pesan bila ada riwayat balasan dan pengirimnya kosong, atau bila teks memuat kata
status ("terkirim", "sent", "You:"). Akibatnya pesan buatan sendiri masih bisa dibacakan sebagai chat masuk:
- balasan lewat notifikasi tanpa riwayat balasan terbaca,
- notifikasi yang diperbarui setelah kita membalas memasang pesan masuk lama sebagai pesan terbaru,
- pesan dengan pengirim berupa diri sendiri (Person pemilik perangkat) tidak dikenali,
- notifikasi non-pesan WhatsApp (pengiriman media berjalan, cadangan, "WhatsApp Web aktif") ikut dibacakan.
Sebaliknya, pesan masuk yang isinya kebetulan memuat kata seperti "terkirim" atau "sent" ikut terbuang karena penilaian memakai teks isi.

## Perbaikan
Arah pesan kini dinilai dengan tiga hasil tegas: **MASUK, KELUAR, TIDAK_PASTI** (`arahDariMessagingStyle`), berdasarkan pesan TERBARU
pada metadata MessagingStyle, yaitu pesan yang akan dibacakan:
1. Pengirim sama dengan pemilik perangkat (`android.messagingUser`, `android.selfDisplayName`, atau kata Anda/You/Saya/Me) → **KELUAR**.
   Ini juga mencakup chat ke diri sendiri.
2. Pesan terbaru tanpa pengirim → **KELUAR** bila pesan lain pada notifikasi itu punya pengirim atau ada riwayat balasan
   (pola balasan lewat notifikasi). Tanpa bukti itu → TIDAK_PASTI.
3. Pengirim orang lain → **MASUK**. Pada hasil jelas (MASUK/KELUAR), teks isi pesan tidak dipakai sama sekali.
4. Pesan masuk lama yang dipasang ulang setelah balasan (ada riwayat balasan dan pesan terbaru lebih dari 2 menit) → tidak dibacakan.
5. Hanya bila notifikasi tidak punya metadata pengirim (TIDAK_PASTI) dipakai petunjuk cadangan seperti sebelumnya: riwayat balasan,
   kata status pengiriman, awalan "You:/Anda:", dan status SMS terkirim.
6. Khusus WhatsApp Messenger dan WhatsApp Business: notifikasi tetap/berjalan, layanan latar, atau berprogres (`FLAG_ONGOING_EVENT`,
   `FLAG_FOREGROUND_SERVICE`, `EXTRA_PROGRESS_*`, kategori progress/service/status/system/error/transport) tidak pernah diumumkan sebagai chat.
Aturan 1–5 berlaku untuk WhatsApp, WhatsApp Business, dan aplikasi SMS. Panggilan masuk/keluar tidak diubah (sudah dibedakan lewat
`apakahMasuk`).

## Pengujian manual yang disarankan (WhatsApp dan WhatsApp Business)
- Pesan teks masuk pribadi dan grup: dibacakan. Pesan suara masuk: dibacakan sebagai pesan suara.
- Balas dari notifikasi: balasan kita TIDAK dibacakan; pesan masuk berikutnya dibacakan.
- Kirim pesan dari dalam aplikasi/WhatsApp Web: tidak dibacakan.
- Kirim foto/video (progres unggah) dan cadangan: tidak dibacakan.
- Chat ke diri sendiri ("Pesan ke diri sendiri"): tidak dibacakan.
- Pesan masuk yang berisi kata "terkirim" atau "sent": tetap dibacakan.

## Batas
- Pemeriksaan hanya statis (kurung seimbang, verify_project lulus); belum dikompilasi dan belum diuji di perangkat.
  Format notifikasi dapat berbeda antarversi WhatsApp dan antarmerek HP.
- Bila ada versi WhatsApp yang tidak menyertakan pengirim pada pesan masuk dan tidak ada pesan lain bersama pengirim,
  hasilnya TIDAK_PASTI dan pesan tetap dibacakan seperti sebelumnya (disengaja, agar tidak senyap total).
