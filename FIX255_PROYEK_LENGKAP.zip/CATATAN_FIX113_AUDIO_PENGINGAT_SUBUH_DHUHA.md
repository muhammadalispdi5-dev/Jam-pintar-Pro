# FIX113 – Audio Pengingat Subuh dan Dhuha

- Mengganti audio pengingat sebelum Subuh dengan audio M4A yang dilampirkan pengguna.
- Mengganti audio pengingat Dhuha dengan audio M4A yang dilampirkan pengguna.
- Nama resource Android dipertahankan (`pengingat_sebelum_subuh` dan `pemberitahuan_dhuha`), sehingga jadwal, pemicu, dan fungsi pemutaran yang sudah ada tetap digunakan tanpa membuat pemutar atau fitur ganda.
- Kedua audio menjalani normalisasi kenyaringan dua tahap dan pembatasan true peak maksimum -1 dBTP. Hasil pengukuran akhir berada sekitar -16,5 LUFS (Subuh) dan -16,7 LUFS (Dhuha), mendekati audio lama (sekitar -16,2 LUFS), sehingga perbedaan kenyaringan rata-rata diminimalkan tanpa clipping.
- Pemutaran tetap melalui `playRawSound()` dan `PrayerPrefs.volumeMode`; pengaturan kelompok volume pengguna tidak diubah.
- `app/build.gradle.kts` sudah mengatur `noCompress += "m4a"`, sesuai kebutuhan `openRawResourceFd()`.
- Teks antarmuka dan notifikasi tetap mengikuti bahasa aktif melalui lokalisasi aplikasi. Berkas audio yang dilampirkan diputar apa adanya; isi rekaman tidak diterjemahkan atau diganti berdasarkan bahasa.
