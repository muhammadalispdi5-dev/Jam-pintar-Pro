# FIX54 — Unduhan audio dan teks tersimpan otomatis di folder "Jam Pintar Pro"

Versi aplikasi tetap **1.0.69** (`versionCode 69`). Basis: FIX53. Perubahan: `KhatamActivity.kt`, `AndroidManifest.xml`.

## Hasil
Folder **Jam Pintar Pro** dibuat otomatis di memori internal HP:
- `Jam Pintar Pro/Audio` : audio murattal yang diunduh (MP3 per ayat; unduhan surah/juz/halaman = banyak berkas ayat).
- `Jam Pintar Pro/Teks` : salinan teks Arab (Uthmani) dan terjemahan Indonesia/Inggris (JSON). Teks yang dibaca aplikasi tetap memakai cache internal aplikasi.

## Izin (diminta sekali)
- Android 11+: izin "Akses semua berkas" (`MANAGE_EXTERNAL_STORAGE`). Sebelum unduhan pertama muncul penjelasan dengan tombol Buka pengaturan; setelah izin diaktifkan dan pengguna kembali ke aplikasi, unduhan berlanjut otomatis.
- Android 7-9: izin penyimpanan (`WRITE_EXTERNAL_STORAGE`, maksimal API 28).
- Android 10, atau pengguna memilih Lanjut tanpa izin: berkas disimpan di `Download/Jam Pintar Pro/...` supaya unduhan tidak gagal. (Android tidak mengizinkan folder tingkat atas memori internal tanpa izin di atas.)

## Perbaikan terkait
- Sebelumnya unduhan audio di Android 10+ memakai `RELATIVE_PATH` "Jam Pintar Pro/Al-Qur'an" pada koleksi Downloads, yang ditolak Android (harus diawali "Download/"). Kini jalur itu diperbaiki.
- Teks info di menu Khatam diperbarui (sebelumnya menyebut audio offline belum tersedia).
- Berkas di folder diindeks (MediaScanner) agar terlihat di aplikasi berkas/pemutar.

## Pemeriksaan
- Tanda kurung Kotlin seimbang; manifest valid; `verify_project.py` lulus.
- BELUM dikompilasi dan BELUM diuji di perangkat. Uji: unduh teks, unduh satu surah audio, lalu cek folder di aplikasi berkas.
