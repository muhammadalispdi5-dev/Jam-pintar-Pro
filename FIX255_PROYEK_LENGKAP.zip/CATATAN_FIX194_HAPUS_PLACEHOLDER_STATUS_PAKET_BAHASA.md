# FIX194 — Perbaikan teks status paket bahasa offline

Versi aplikasi tetap 1.0.82 (tidak ada perubahan versi).

Perubahan pada `PaketBahasaOfflineActivity.kt`:

- Indonesia: `Paket offline sudah terpasang dan terdeteksi.`
- English: `The offline language pack is installed and detected.`
- Indonesia: `Permintaan unduhan paket bahasa sudah dikirim ke layanan pengenal suara. Pantau notifikasi atau pengaturan layanan tersebut. Setelah selesai, tekan Periksa ketersediaan paket bahasa.`
- English: `The language pack download request was sent to the speech recognition service. Check its notification or settings. When finished, tap Check language pack availability.`

Placeholder `$label` dan `$bahasaTag` di dua pesan tersebut dihilangkan. Tanda baca dan maksud pesan dipertahankan.
