# FIX205 – Perintah suara: "putar surah X dan terjemahan Indonesia"

- PenafsirQuran kini mengenali kata terjemah/terjemahan/translation/arti (dan "bahasa Indonesia", "dan/dengan/beserta/and/with") sebagai isyarat tambahan.
- "putar surah Al Fatihah dan terjemahan Indonesia": bacaan Arab surah penuh, jeda 1,5 detik, lalu audio terjemahan Indonesia surah itu.
- "... terjemahan Indonesia saja" / "putar hanya terjemahan surah An Nas": hanya audio terjemahan.
- Audio terjemahan (Internet Archive "quraninindonesia") hanya ada per surah penuh. Bila perintah menyebut ayat/juz, hanya bacaan Arab yang diputar dan pengguna diberi tahu.
- Daftar nama berkas terjemahan dipindah ke PenafsirQuran.berkasTerjemahanId (dipakai bersama Khatam).
- Belum dikompilasi dan belum diuji di perangkat. Uji statis: tools/uji_fix205_perintah_terjemah.py.
