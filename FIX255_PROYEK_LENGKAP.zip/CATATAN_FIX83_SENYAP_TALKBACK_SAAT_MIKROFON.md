# FIX83 - Suara TalkBack saat mikrofon dipakai
Pengaturan "Suara TalkBack saat pergantian audio" (Pengaturan aksesibilitas) kini berlaku juga untuk fitur mikrofon, dan labelnya menjadi "...saat pergantian audio dan saat mikrofon dipakai".
- Perintah suara untuk memutar: bila dimatikan, TalkBack disenyapkan, ada getaran isyarat, jeda 0,8 detik, lalu layar pengenalan suara dibuka tanpa teks petunjuk (prompt) agar tidak dibacakan.
- Koreksi hafalan dengan suara: sudah selalu menyenyapkan TalkBack sejak sebelumnya (tidak diubah).
- Tidak ada fitur mikrofon lain di aplikasi (hanya Khatam). Belum dikompilasi/diuji.
