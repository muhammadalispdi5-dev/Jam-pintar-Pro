Tahap 14 — Konsistensi sebutan hari Ahad pada ucapan kalender

Perubahan:
- Mengganti nama hari pertama pada rangkaian nama hari berbahasa Sunda dari "Minggu" menjadi "Ahad".
- Mencakup ucapan tanggal Hijriah dan pasaran pada KalenderTanggal.kt, serta rangkaian hari pada HariLibur.kt dan UcapanSholat.kt agar penyebutan hari konsisten di fitur terkait.
- Nama hari lain, bahasa tampilan, dan pilihan bahasa suara tidak diubah.
- Versi aplikasi dipertahankan pada 1.0.68 / versionCode 68.

Pemeriksaan:
- Audit teks sumber memastikan array hari Sunda yang dimaksud kini memakai "Ahad".
- Tidak menjalankan build Android penuh atau uji TTS perangkat; kompilasi belum terverifikasi.
