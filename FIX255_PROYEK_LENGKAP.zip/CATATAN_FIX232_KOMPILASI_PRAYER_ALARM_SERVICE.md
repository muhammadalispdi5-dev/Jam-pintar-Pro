# FIX232 — Perbaikan kompilasi PrayerAlarmService

## Masalah
GitHub Actions Run ID 42601253751 gagal pada `:app:compileDebugKotlin` karena `PrayerAlarmService.kt` baris 450 menggunakan `isDestroyed`, properti yang tidak tersedia pada Android `Service`.

## Perbaikan
- Mengganti pemeriksaan `isDestroyed` dengan flag lifecycle internal `serviceAktif` yang ditandai `@Volatile`.
- Flag bernilai aktif saat instance service dibuat dan diubah menjadi `false` pada awal `onDestroy()`.
- Callback melodi pengingat puasa hanya menjalankan aksi lanjutan selama service masih aktif.
- Tidak mengubah API `Melodi.putar`, urutan melodi sebelum/sesudah pengingat, teks, pengucapan TTS, maupun pengaturan bahasa.
- Nomor versi aplikasi dan version code tidak diubah.

## Validasi
Pemeriksaan statis memastikan tidak ada lagi referensi `isDestroyed` di `PrayerAlarmService.kt` dan perubahan lifecycle berada di dalam kelas service. Kompilasi Gradle penuh perlu diverifikasi melalui GitHub Actions.
