# FIX81 - Perintah suara rentang ayat
Masalah: "putar surah Al Kahfi ayat 1 sampai ayat 3" hanya menyimpan angka terakhir (ayat 3), lalu diulang sesuai pengaturan pengulangan.
Perbaikan: penguraian mengenali penghubung rentang (sampai, hingga, sampai dengan, s/d, to, through, until, ke) dan menyimpan ayat awal serta akhir.
Rentang diputar berurutan ayat awal sampai ayat akhir, masing-masing satu kali (putarRentangAyat, memakai jalur berurutan yang sama dengan juz/halaman).
Contoh: "putar surah 18 ayat 1 sampai 3", "putar Al Kahfi ayat satu sampai tiga", "play surah Yasin verses 1 to 5".
Qari MP3Quran (per surah) tetap memakai dialog "audio ayat tidak tersedia". Belum dikompilasi/diuji.
