# FIX248 — Basmalah dan hamdalah pada cadangkan dan pulihkan pengaturan

Versi tetap 1.0.88 / 88. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.

MainActivity.kt: ucapan lewat Pembicara (suara profil "jam", mengikuti bahasa tampilan).
- Cadangkan: awal "Bismillah. Memulai pencadangan pengaturan."; berhasil "Alhamdulillah, pencadangan pengaturan selesai."; gagal "Pencadangan pengaturan gagal." (tanpa hamdalah).
- Pulihkan: awal "Bismillah. Memulai pemulihan pengaturan dari cadangan."; berhasil "Alhamdulillah, pemulihan pengaturan dari cadangan selesai."; gagal "Pemulihan pengaturan gagal. Berkas cadangan tidak dikenali."
- Setelah pemulihan, beranda dibangun ulang setelah ucapan selesai (paling lama 8 detik) agar suara tidak terpotong.
- Ucapan mengikuti Mode Acara (senyap bila mode itu aktif).
