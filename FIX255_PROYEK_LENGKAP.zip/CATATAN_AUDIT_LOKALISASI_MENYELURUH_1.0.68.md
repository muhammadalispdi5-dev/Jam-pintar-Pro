# Catatan audit konsistensi bahasa — versi 1.0.68

## Perubahan pada pemeriksaan ini
- Memperbaiki penerjemahan teks dinamis yang diawali label seperti jenis suara, sumber suara, berkas audio mandiri, dan pesan pengingat.
- Menambahkan terjemahan untuk penjelasan panduan kompas saat layar mati serta pengingat puasa Senin/Kamis dan Ramadan.
- Memastikan label tombol tes suara azan dan deskripsi aksesibilitasnya memakai bahasa tampilan aktif.
- Menyesuaikan bahasa TTS untuk panduan kompas serta pengingat/tes azan, sahur, berbuka, dan pengingat sebelum salat dengan bahasa utama aplikasi (Indonesia/English).
- Menampilkan nama berkas audio yang ramah pengguna alih-alih URI `content://` mentah pada ringkasan berkas yang tersimpan.
- Menambahkan terjemahan untuk beberapa pesan dinamis jadwal, pengingat, dan lokasi yang dirangkai saat aplikasi berjalan.

## Validasi
- Perubahan sumber telah diperiksa untuk kesalahan sintaks dasar.
- ZIP diuji integritasnya dengan `unzip -t`.
- Build Android Gradle penuh belum dapat dijalankan pada lingkungan pemeriksaan ini karena proyek hasil ekstraksi tidak menyertakan Gradle wrapper dan tidak tersedia instalasi Gradle.

## Audit lanjutan — jadwal puasa dan pilihan pengulangan
- Menambahkan terjemahan lengkap untuk penjelasan tanggal pertama puasa Nabi Dawud dan pola puasa selang-seling.
- Menambahkan label jumlah pengulangan `1 kali`, `2 kali`, `3 kali`, `5 kali`, `10 kali`, dan `20 kali` dalam bahasa Inggris.
- Memperbaiki label dinamis untuk pemilihan berkas suara dan jenis suara pengingat agar bagian tetap diterjemahkan ketika nama waktu salat berubah.
- Melengkapi pilihan audio sahur/berbuka dan tombol penyimpanan tanggal.
- Memeriksa seluruh 19 string-array: semua nama array di `values/arrays.xml` memiliki pasangan di `values-en/arrays.xml` dan jumlah item tiap array cocok.
- Memeriksa pasangan resource string: 378 kunci bahasa Indonesia dan 378 kunci bahasa Inggris; tidak ada kunci yang hilang di salah satu sisi.
- Pemeriksaan statis proyek lulus setelah perubahan. Kompilasi Android penuh dan uji langsung di perangkat tetap perlu dilakukan sebelum rilis.
