# Tahap 17 — Bahasa tampilan pada status sinkronisasi jadwal salat

## Perubahan
- Status jadwal yang belum pernah disinkronkan memakai teks sesuai bahasa tampilan aplikasi.
- Label waktu sinkronisasi terakhir mengikuti bahasa tampilan: `Pembaruan terakhir:` dalam bahasa Indonesia dan `Last update:` dalam bahasa Inggris.
- Nama bulan pada tanggal sinkronisasi terakhir mengikuti locale tampilan, sehingga layar berbahasa Inggris tidak lagi menampilkan singkatan bulan Indonesia.
- Perubahan ini khusus untuk teks antarmuka; tidak mengubah bahasa TTS, perhitungan jadwal, alarm, atau pengaturan lokasi.
- Versi aplikasi tetap 1.0.68 (versionCode 68).

## Pemeriksaan
- Perubahan sumber diperiksa secara statis.
- Belum menjalankan build Android penuh atau pengujian perangkat. Proyek sumber yang tersedia tidak menyertakan Gradle wrapper pada pemeriksaan tahap sebelumnya.
