# FIX120 - Mikrofon perintah suara sulit terbuka setelah beberapa kali dipakai dan audio tidak berhenti sementara

Versi aplikasi tidak diubah. Basis: FIX119. Berkas diubah: `PerintahSuaraActivity.kt`, `KhatamActivity.kt`. Berkas baru: `tools/uji_mikrofon_perintah_suara.py`.

## Gejala
Setelah sekitar 6-7 perintah suara berhasil, mikrofon sulit dibuka, dan audio yang sedang berbunyi tidak berhenti sementara seperti biasanya.

## Dugaan penyebab (dari pembacaan kode; log crash belum ada)
1. Pemutar milik `KhatamActivity` tidak menangani fokus audio, sehingga tidak berhenti sendiri saat mikrofon dibuka (sebelumnya hanya pemutar
   layanan latar belakang yang menanganinya). Suara yang masih berbunyi juga mengganggu pengenalan.
2. `PerintahSuaraActivity` tidak punya batas waktu selama menunggu hasil pengenalan dan tidak membatasi jumlah instance. Bila pengenal
   tidak pernah menjawab, instance itu tertinggal, tetap memegang pengenal suara, dan menumpuk setiap pemicu baru, sehingga layanan pengenal
   suara lama-lama menolak sesi baru. Ini hipotesis; belum terbukti tanpa log.

## Perbaikan
- Saat mikrofon akan dibuka: audio Khatam yang berbunyi dijeda secara senyap, dan layar ini meminta fokus audio sementara agar pemutar latar
  belakang ikut berhenti sebentar. Fokus dilepas begitu pengenalan selesai (sebelum perintah diproses).
- Audio dilanjutkan otomatis HANYA bila perintahnya sekadar informasi (waktu/tanggal/libur/salat/baca teks), tidak terdengar, atau
  tidak dikenali. Perintah berhenti/jeda/lanjut/putar atau yang membuka aplikasi lain tidak melanjutkan otomatis; jeda yang berasal dari
  mikrofon dibatalkan bila pengguna mengatur audio sendiri.
- Hanya satu `PerintahSuaraActivity` aktif: instance lama dilepas (pengenal, fokus, layar pengenal sistem) saat instance baru dibuat.
- Batas waktu 45 detik menunggu pengenalan dan 120 detik untuk memproses perintah; `tutup()` ikut menutup layar pengenal sistem yang masih terbuka.
- `AudioLatarService` tidak lagi menganggap audio selesai selama jeda singkat karena mikrofon.

## Bahasa aktif
Tidak ada teks baru yang terlihat pengguna; pemeriksa bahasa aktif lulus.

## Pemeriksaan
- `verify_project.py`, `periksa_bahasa_aktif.py`, dan tiga uji kontrak (`uji_mikrofon_perintah_suara`, `uji_kendali_audio_suara`, `uji_pemulihan_jendela_khatam`) lulus; kurung Kotlin seimbang.
- BELUM dikompilasi dan BELUM diuji di perangkat. Bila mikrofon masih gagal setelah beberapa percobaan, kirim log (logcat) saat gagal dan catat
  apakah layar pengenal suara sistem muncul, apakah ada getar/nada siap, dan apakah pemicunya goncangan, widget, atau pintasan.
