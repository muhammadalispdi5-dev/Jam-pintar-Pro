# FIX206 – Respons lebih cepat untuk perintah suara pemutaran audio online

Perubahan di PemutarQuranService.kt:
1. Pemanasan DNS (cdn.islamic.network, archive.org, download.mp3quran.net) di utas terpisah saat perintah diterima, paling sering sekali per 2 menit.
2. Penyusunan indeks audio lokal dibatasi ±2,5 detik untuk surah kedua dan seterusnya (perintah juz/seluruh Al-Qur'an) bila ada internet; tanpa internet semua tetap diindeks.
3. Batas tunggu sumber internet: percobaan pertama 12 detik (sebelumnya 30), berikutnya 20 detik; sumber tanpa varian bitrate (mis. audio terjemahan) dicoba 2 kali lalu pindah ke cadangan/berikutnya (sebelumnya 6 kali).
Belum dikompilasi dan belum diuji di perangkat.
