# Perbaikan Call Types and Repetition dan Incoming Messages and Notifications

Versi tetap: 1.0.68 (versionCode 68)

## Perubahan
- Memperjelas struktur kategori Call Types and Repetition dengan heading aksesibilitas untuk jenis panggilan dan pengulangan pengumuman.
- Memperjelas pengelompokan Incoming Messages and Notifications berdasarkan sumber: SMS, WhatsApp Messenger, WhatsApp Business, aplikasi lain, dan pengulangan notifikasi pesan.
- Menambahkan ringkasan status akses notifikasi pada kedua layar pengaturan terkait.
- Status akses ditampilkan secara visual menggunakan latar hijau saat akses aktif dan merah saat akses belum aktif, dengan teks status yang tetap tersedia bagi pembaca layar.
- Status diperbarui saat layar kembali aktif setelah pengguna membuka pengaturan izin Android.
- Menambahkan terjemahan bahasa Inggris untuk teks pengelompokan dan status yang baru sehingga mengikuti bahasa tampilan utama aplikasi.

## Verifikasi
- `tools/verify_final.py` lulus untuk pemeriksaan statis proyek.
- Versi aplikasi tidak dinaikkan.
- Pemeriksaan statis bukan pengganti kompilasi APK dan uji aksesibilitas langsung pada perangkat Android.
