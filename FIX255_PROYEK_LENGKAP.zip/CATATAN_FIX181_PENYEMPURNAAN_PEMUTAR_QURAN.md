# FIX181 — Penyempurnaan kendali dan aksesibilitas pemutar Al-Qur'an

## Dasar
Melanjutkan proyek FIX180 yang telah dilaporkan pengguna berhasil memutar audio Al-Qur'an secara offline.

## Fitur yang diaudit dan dipertahankan
- Pemilihan qari melalui perintah suara dan pengaturan qari Khatam.
- Pemutaran audio satu surah, satu ayat, rentang ayat, juz, dan seluruh Al-Qur'an.
- Perintah jeda, lanjutkan, berhenti, ayat berikutnya, ayat sebelumnya, surah berikutnya/sebelumnya, serta pengulangan.
- Layanan foreground bertipe `mediaPlayback`, audio focus, wake lock, dan notifikasi kendali agar audio dapat berlanjut saat layar mati/terkunci atau pengguna berpindah halaman.
- Pencarian audio lokal asinkron dan cache indeks FIX180.

## Perubahan FIX181
1. Notifikasi pemutar kini menyampaikan status yang lebih jelas: menyiapkan, sedang diputar, dijeda, atau menunggu jeda.
2. Jika daftar audio berupa potongan ayat, notifikasi menyertakan nama surah dan nomor ayat yang sedang diputar. Ini membuat status lebih informatif saat dibaca TalkBack.
3. Jika memakai satu berkas audio utuh, notifikasi tetap menyebutkan nama surah.
4. Layanan pemutar diberi `android:stopWithTask="false"` secara eksplisit agar penghapusan task/halaman aplikasi dari recent apps tidak menjadi instruksi untuk menghentikan layanan.

## Batasan dan verifikasi
- `versionCode=82` dan `versionName=1.0.82` tetap dipertahankan.
- Aturan bahasa aktif Indonesia/Inggris tetap digunakan melalui fungsi `tr()`.
- Tidak mengubah fitur asisten waktu, jadwal salat, atau pengenalan suara umum.
- Struktur perintah dan pemutaran yang telah tersedia pada FIX180 dipertahankan; FIX181 tidak mengklaim menambah sintaks perintah baru yang belum ada.
- Arsip proyek diperiksa integritas ZIP-nya. Kompilasi Gradle dan uji perangkat belum dilakukan di lingkungan ini; APK final harus dibangun melalui GitHub Actions dan diuji pada perangkat.
