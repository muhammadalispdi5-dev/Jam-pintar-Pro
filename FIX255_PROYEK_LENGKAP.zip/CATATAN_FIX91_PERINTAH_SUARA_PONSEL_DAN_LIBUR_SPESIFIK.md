# FIX91 — Perluasan perintah suara ponsel dan informasi libur spesifik

## Perintah suara yang ditambahkan
- Membuka aplikasi Android yang memiliki ikon launcher dengan menyebut nama aplikasinya, misalnya “buka YouTube” atau “buka aplikasi Kamera”. Pencocokan memakai label aplikasi yang terlihat pada launcher perangkat.
- Membuka dialer dengan perintah “buka telepon”.
- Menyiapkan panggilan melalui “telepon/panggil/hubungi [nama kontak]” atau nomor yang diucapkan. Aplikasi hanya membuka layar dialer; pengguna tetap mengonfirmasi panggilan.
- Membuka aplikasi SMS/pesan dengan “buka pesan”, “buka SMS”, atau “buka WhatsApp”.
- “Baca pesan” membuka aplikasi pesan dan menjelaskan syarat pembacaan pesan masuk melalui akses notifikasi. Pembacaan otomatis pesan masuk tetap menggunakan CallerListener dan pengaturan/izin yang telah tersedia. Fitur ini tidak membaca riwayat SMS/WhatsApp secara diam-diam.
- Semua rute perintah suara yang telah ada untuk fitur Jam Pintar Bro tetap dipertahankan.

## Informasi libur yang lebih terarah
- “Libur nasional hari ini/kemarin/yang akan datang”.
- “Cuti bersama hari ini/kemarin/yang akan datang”.
- Kategori nasional dan cuti bersama dibacakan terpisah; satu pertanyaan menghasilkan satu jawaban ringkas, bukan gabungan semua kategori.
- Bahasa jawaban mengikuti bahasa aktif aplikasi (Indonesia, Inggris, Arab, Jawa, atau Sunda).

## Batasan dan privasi Android
- Panggilan menggunakan ACTION_DIAL, bukan ACTION_CALL, sehingga tidak melakukan panggilan tanpa konfirmasi.
- Pencarian kontak memerlukan izin READ_CONTACTS yang telah dideklarasikan aplikasi dan harus diberikan oleh pengguna pada Android.
- Daftar aplikasi yang dapat dibuka dibatasi aplikasi yang menyediakan aktivitas launcher.
- Riwayat pesan tidak diambil dari basis data SMS/WhatsApp. Pembacaan otomatis hanya untuk notifikasi masuk yang disediakan Android dan diizinkan oleh pengguna melalui Notification Listener serta pengaturan aplikasi.
- Ketersediaan data libur di luar data offline bergantung pada sinkronisasi kalender tahunan yang sudah ada.

## Pemeriksaan
- Uji penafsir perintah suara terisolasi: libur nasional hari ini, cuti bersama kemarin, libur nasional yang akan datang, telepon Budi, baca pesan masuk, buka WhatsApp, buka YouTube, buka kiblat, dan jadwal salat berikutnya.
- `tools/verify_project.py` lulus.
- Pemeriksaan ini bukan pengganti kompilasi Android dan pengujian langsung pada perangkat.
