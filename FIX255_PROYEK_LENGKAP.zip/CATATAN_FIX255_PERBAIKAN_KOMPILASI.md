# FIX255 - Perbaikan kegagalan kompilasi dari log GitHub Actions

1. Kesalahan Kotlin (FIX253): `val T = PerintahSuara.TopikPerangkat` memakai enum sebagai ekspresi, sehingga "does not have a companion object" dan semua nilai (SEMUA, RAM, ...) tidak terselesaikan. Diperbaiki dengan impor `PerintahSuara.TopikPerangkat` dan pemakaian langsung `TopikPerangkat.RAM` dan seterusnya.
2. Temuan tambahan dari log: "string too large to encode using UTF-8 ... STRING_TOO_LARGE". Teks `isi_petunjuk_penggunaan` versi Indonesia mencapai 34 KB (batas aapt2 32767 byte), sehingga petunjuk berisiko tampil sebagai STRING_TOO_LARGE. Teks dipecah menjadi `isi_petunjuk_penggunaan` dan `isi_petunjuk_penggunaan_lanjutan` (ID dan EN), digabung di MainActivity. Pemeriksa baru: tools/periksa_ukuran_string.py (batas 30000 byte).
Belum dikompilasi dengan Gradle di sini; kode FIX254 ikut ditinjau ulang terhadap kesalahan serupa.
