# FIX227 - Tombol pemicu asisten suara pilihan pengguna

Menu baru "Tombol Pemicu Asisten Suara" (di bagian pemicu perintah suara pada beranda).

Pilihan: nonaktif, tahan volume atas, tahan volume bawah, volume atas+bawah bersamaan, volume atas dua kali, volume bawah dua kali, tombol aksesibilitas. Lama menahan dapat diatur (0,5 sampai 2 detik).

Cara kerja
- PemicuTombol.kt: logika murni pola tombol (diuji dengan tools/UjiTombol.kt, 17 kasus lulus).
- TombolSuaraAccessibilityService: layanan aksesibilitas khusus (hanya menyaring tombol volume dan menerima tombol aksesibilitas; tidak membaca layar, tidak merekam). Harus dinyalakan pengguna di Pengaturan Aksesibilitas.
- PemicuSuara.buka: membuka layar perintah suara, juga di atas layar kunci (notifikasi layar penuh + peluncuran langsung).
- PemicuTombolActivity: pilihan tombol, status layanan, pintasan ke pengaturan aksesibilitas dan info aplikasi (untuk "izinkan pengaturan terbatas" pada Android 13+ bagi APK), serta uji tombol di layar.

Batasan yang perlu diketahui
- Tombol daya tidak dapat ditangkap aplikasi biasa di Android; gunakan pengaturan asisten digital bawaan HP.
- Pada mode tahan, tekanan pertama mengubah volume satu langkah lalu dikembalikan otomatis saat pola dikenali.
- Pemicu volume dimatikan selama panggilan telepon.
- Perilaku tombol saat layar mati dan tombol aksesibilitas berbeda-beda antarmerek HP; belum diuji di perangkat.
- Versi tidak diubah (tetap 1.0.86).
- Belum dikompilasi dengan Gradle; logika murni sudah dikompilasi dan diuji dengan kotlinc.
