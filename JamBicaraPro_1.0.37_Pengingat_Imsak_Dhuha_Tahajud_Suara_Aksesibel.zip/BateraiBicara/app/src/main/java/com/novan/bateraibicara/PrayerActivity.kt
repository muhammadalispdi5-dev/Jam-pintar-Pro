package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.app.AlertDialog
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Jadwal hari ini, pembaruan lokasi, pengaturan, jadwal 30 hari dan arah kiblat. */
class PrayerActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private lateinit var status: android.widget.TextView
    private lateinit var list: android.widget.TextView
    private val dateFmt = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID"))

    override fun bangun() {
        status = info("")
        list = info("")
        bagian("Lokasi")
        info("Jadwal dihitung langsung di HP berdasarkan koordinat, metode perhitungan, dan mazhab Ashar. Tidak perlu internet. Lokasi tidak dikirim ke server.")
        tombol("Perbarui lokasi (GPS)") { perbaruiLokasiGps() }
        tombol("Atur lokasi manual") { dialogLokasiManual() }
        tombol("Pengaturan Jadwal Sholat dan Pengingat") { startActivity(Intent(this, PrayerSettingsActivity::class.java)) }
        tombol("Bacakan jadwal sholat hari ini") {
            if (!pp.locationSet) toast("Atur lokasi terlebih dahulu.") else {
                val d = LocalDate.now()
                val t = PrayerCalc.calculate(d, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
                tesSuara("jam", "Jadwal sholat hari ini. Subuh ${PrayerCalc.format(t.fajr, pp.use24)}. Terbit ${PrayerCalc.format(t.sunrise, pp.use24)}. Dhuha ${PrayerCalc.format(t.dhuha, pp.use24)}. Tahajud perkiraan ${PrayerCalc.format(PrayerCalc.tahajud(d, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments()), pp.use24)}. Dzuhur ${PrayerCalc.format(t.dhuhr, pp.use24)}. Ashar ${PrayerCalc.format(t.asr, pp.use24)}. Maghrib ${PrayerCalc.format(t.maghrib, pp.use24)}. Isya ${PrayerCalc.format(t.isha, pp.use24)}.")
            }
        }
        tombol("Pilih hari dan jadwal 30 hari") { startActivity(Intent(this, PrayerThirtyActivity::class.java)) }
        tombol("Arah Kiblat") { startActivity(Intent(this, QiblaActivity::class.java)) }
        tombol("Info Jadwal Sholat") {
            AlertDialog.Builder(this).setTitle("Info Jadwal Sholat")
                .setMessage("Jadwal dihitung secara lokal tanpa internet. Untuk Indonesia, metode yang disarankan adalah Kemenag RI. Hasil dapat berbeda beberapa menit dari jadwal masjid setempat karena koordinat, metode, dan penyesuaian menit. Pengingat dan suara azan dalam keadaan nonaktif sampai Anda mengaktifkannya di Pengaturan Jadwal Sholat.")
                .setPositiveButton("Mengerti", null).show()
        }
        segarkan()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) segarkan() }

    private fun segarkan() {
        if (!pp.locationSet) {
            status.text = "Lokasi belum diatur. Ketuk Perbarui lokasi (GPS) atau Atur lokasi manual."
            list.text = "Jadwal belum dapat dihitung sampai lokasi ditentukan."
            return
        }
        val date = LocalDate.now()
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        status.text = "${date.format(dateFmt)}\n${pp.place}\nKoordinat: ${"%.5f".format(pp.lat)}, ${"%.5f".format(pp.lon)}\nMetode: ${PrayerCalc.methodNames[pp.method]}\nPengingat: ${if (pp.enabled) "aktif" else "nonaktif"}"
        list.text = listOf(
            "Imsak: ${PrayerCalc.format(t.imsak, pp.use24)}",
            "Subuh: ${PrayerCalc.format(t.fajr, pp.use24)}",
            "Terbit: ${PrayerCalc.format(t.sunrise, pp.use24)}",
            "Dhuha: ${PrayerCalc.format(t.dhuha, pp.use24)}",
            "Tahajud (perkiraan): ${PrayerCalc.format(PrayerCalc.tahajud(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments()), pp.use24)}",
            "Dzuhur: ${PrayerCalc.format(t.dhuhr, pp.use24)}",
            "Ashar: ${PrayerCalc.format(t.asr, pp.use24)}",
            "Maghrib: ${PrayerCalc.format(t.maghrib, pp.use24)}",
            "Isya: ${PrayerCalc.format(t.isha, pp.use24)}"
        ).joinToString("\n")
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 401 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) perbaruiLokasiGps()
    }

    private fun perbaruiLokasiGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 401)
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            var last: Location? = null
            for (provider in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try { val l = lm.getLastKnownLocation(provider); if (l != null && (last == null || l.time > last!!.time)) last = l } catch (_: Exception) { }
            }
            if (last != null) { simpanLokasi(last!!.latitude, last!!.longitude, "Lokasi GPS") ; return }
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> { AlertDialog.Builder(this).setMessage("Layanan lokasi mati. Nyalakan lokasi di setelan perangkat, atau atur lokasi manual.").setPositiveButton("Setelan lokasi") { _, _ -> startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }.setNegativeButton("Batal", null).show(); return }
            }
            infoDialog("Mencari lokasi, mohon tunggu. Jika gagal, Anda dapat mengatur lokasi manual.")
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    try { lm.removeUpdates(this) } catch (_: Exception) { }
                    simpanLokasi(location.latitude, location.longitude, "Lokasi GPS")
                }
                @Deprecated("Deprecated in Android") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            lm.requestLocationUpdates(provider, 1000L, 0f, listener)
        } catch (e: Exception) { infoDialog("Lokasi belum ditemukan. Coba lagi di tempat terbuka, atau atur lokasi manual.") }
    }

    private fun dialogLokasiManual() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val lat = EditText(this).apply { hint = "Lintang / latitude, contoh -7.797"; inputType = 8194; setText(if (pp.locationSet) pp.lat.toString() else "") }
        val lon = EditText(this).apply { hint = "Bujur / longitude, contoh 110.370"; inputType = 8194; setText(if (pp.locationSet) pp.lon.toString() else "") }
        val place = EditText(this).apply { hint = "Nama kota/lokasi (opsional)"; setText(if (pp.locationSet) pp.place else "") }
        box.addView(lat); box.addView(lon); box.addView(place)
        AlertDialog.Builder(this).setTitle("Atur lokasi manual").setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val a = lat.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val b = lon.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (a == null || b == null || a !in -90.0..90.0 || b !in -180.0..180.0) {
                    infoDialog("Koordinat tidak valid. Lintang harus −90 sampai 90 dan bujur −180 sampai 180.")
                } else simpanLokasi(a, b, place.text.toString().trim().ifEmpty { "Lokasi manual" })
            }.setNegativeButton("Batal", null).show()
    }

    private fun simpanLokasi(lat: Double, lon: Double, nama: String) {
        pp.lat = lat; pp.lon = lon; pp.place = nama; pp.locationSet = true
        PrayerAlarm.scheduleAll(this)
        toast("Lokasi disimpan")
        segarkan()
    }
    private fun infoDialog(msg: String) { runOnUiThread { AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Mengerti", null).show() } }
}
