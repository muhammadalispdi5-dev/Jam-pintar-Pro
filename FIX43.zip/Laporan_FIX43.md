# FIX43 — Perbaikan Equalizer dan Koreksi Hafalan Berbantuan Suara

Basis: FIX42. Versi aplikasi dipertahankan **1.0.69** (`versionCode 69`).

## 1. Equalizer

- Perbaikan penerapan equalizer pada sesi audio `MediaPlayer` setelah audio siap diputar.
- Profil Vokal/Bacaan, Bass, dan Treble sekarang dihitung berdasarkan frekuensi pusat pita equalizer perangkat, bukan asumsi jumlah pita tetap lima.
- Level dibatasi sesuai `bandLevelRange` yang dilaporkan perangkat.
- Status kegagalan tidak lagi ditelan diam-diam: aplikasi memberi tahu jika equalizer belum aktif, tidak memiliki kontrol efek, tidak tersedia, atau akan diterapkan pada pemutaran berikutnya.
- Equalizer hanya dapat benar-benar mengubah suara jika implementasi efek audio pada perangkat mengizinkannya. Hasil tetap perlu diuji pada perangkat pengguna.

## 2. Koreksi hafalan berbantuan pengenalan suara

- Menu baru: **Koreksi otomatis hafalan (pengenalan suara)**. Latihan mandiri tanpa mikrofon tetap tersedia sebagai alternatif.
- Meminta izin mikrofon hanya ketika pengguna memulai fitur.
- Menggunakan layanan SpeechRecognizer Android dengan bahasa Arab Saudi (`ar-SA`), lalu membandingkan urutan kata hasil pengenalan dengan teks ayat yang dipilih.
- Hasil memberi umpan balik melalui TalkBack, TTS bahasa aplikasi bila tersedia, dan getaran singkat. Teks ayat disembunyikan selama latihan dan dapat ditampilkan kembali setelah hasil keluar.
- Perbedaan kata ditandai sebagai kemungkinan kata terlewat, berubah, atau tambahan. Hasil pengenalan terbaik dari kandidat yang tersedia dipakai.
- Jika layanan pengenalan suara atau izin mikrofon tidak tersedia, pengguna mendapat penjelasan dan tetap dapat memakai latihan mandiri.

## Batasan yang wajib dipahami

- Ini adalah **pemeriksaan urutan kata berbantuan ASR**, bukan guru tahsin dan bukan penilai bacaan Al-Qur'an.
- Speech recognition dapat salah mengenali bacaan Arab, dialek, suara, panjang pendek, atau kata yang mirip. Karena itu aplikasi menyebut temuan sebagai “bagian yang perlu diperiksa”, bukan memastikan pengguna salah.
- Fitur ini tidak menilai tajwid, makhraj, sifat huruf, ghunnah, mad, waqaf, atau kualitas suara. Untuk penilaian tersebut tetap perlu guru/ustaz/ustazah yang kompeten.
- Layanan pengenalan suara pada perangkat dapat memerlukan internet dan dapat memproses audio sesuai kebijakan penyedia layanan. Pengguna diberi penjelasan sebelum memulai dan izin mikrofon diminta secara eksplisit.
- Belum ada model pengenalan khusus tilawah Al-Qur'an yang dibundel secara offline.

## Pemeriksaan

- `tools/verify_project.py`: **LULUS**.
- XML manifest dapat dibaca; izin `RECORD_AUDIO` dan deklarasi service recognition ditambahkan.
- Pemeriksaan parser Kotlin tidak menemukan indikator kesalahan sintaks. Pemanggilan `kotlinc` tanpa Android SDK/project classpath tetap menghasilkan unresolved references dan bukan kompilasi aplikasi yang valid.
- **Belum** dilakukan kompilasi Gradle penuh karena proyek tidak menyertakan `gradlew` dan lingkungan ini tidak memiliki instalasi Gradle/Android SDK.
- **Belum** dilakukan pengujian pada HP nyata: equalizer vendor, pengenalan suara Arab, mikrofon, TalkBack, dan getaran perlu diuji langsung.
