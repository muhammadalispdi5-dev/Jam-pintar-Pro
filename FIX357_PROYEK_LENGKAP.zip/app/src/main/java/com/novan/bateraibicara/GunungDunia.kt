package com.novan.bateraibicara

import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * FIX356: cuaca di puncak gunung di seluruh dunia. Koordinat dan tinggi puncak di tabel ini disusun manual (dibulatkan);
 * prakiraan diambil langsung dari Open-Meteo dengan parameter elevation sehingga suhu dan angin disesuaikan ke ketinggian puncak,
 * dengan zona waktu setempat. Ini prakiraan model, bukan pengukuran stasiun di puncak. Gunung di luar tabel dicari lewat
 * pencarian nama tempat Open-Meteo dan hanya diterima bila jenis tempatnya gunung, puncak, atau gunung berapi.
 */
object GunungDunia {
    class Gunung(val namaId: String, val namaEn: String, val negaraId: String, val negaraEn: String,
                 val lat: Double, val lon: Double, val tinggi: Int, val kunci: List<String>)

    private fun tr(id: String, en: String, eng: Boolean) = if (eng) en else id

    private fun g(nama: String, negara: String, lat: Double, lon: Double, tinggi: Int, kunci: String): Gunung {
        val n = nama.split("|"); val c = negara.split("|")
        return Gunung(n[0], n.getOrElse(1) { n[0] }, c[0], c.getOrElse(1) { c[0] }, lat, lon, tinggi, kunci.split(",").map { it.trim() }.filter { it.isNotEmpty() })
    }

    val daftar: List<Gunung> = listOf(
        // Indonesia
        g("Puncak Jaya (Carstensz)", "Indonesia", -4.0794, 137.1583, 4884, "puncak jaya,carstensz,carstensz pyramid,puncak jaya wijaya"),
        g("Puncak Trikora", "Indonesia", -4.2667, 138.7333, 4750, "trikora,puncak trikora,wilhelmina"),
        g("Gunung Rinjani", "Indonesia", -8.4116, 116.4573, 3726, "rinjani,gunung rinjani,mount rinjani"),
        g("Gunung Semeru", "Indonesia", -8.1080, 112.9220, 3676, "semeru,gunung semeru,mahameru"),
        g("Gunung Kerinci", "Indonesia", -1.6970, 101.2640, 3805, "kerinci,gunung kerinci"),
        g("Gunung Bromo", "Indonesia", -7.9425, 112.9530, 2329, "bromo,gunung bromo"),
        g("Gunung Merapi", "Indonesia", -7.5407, 110.4457, 2930, "merapi,gunung merapi"),
        g("Gunung Merbabu", "Indonesia", -7.4550, 110.4400, 3145, "merbabu,gunung merbabu"),
        g("Gunung Sumbing", "Indonesia", -7.3842, 110.0725, 3371, "sumbing,gunung sumbing"),
        g("Gunung Sindoro", "Indonesia", -7.3014, 109.9922, 3153, "sindoro,gunung sindoro,sundoro"),
        g("Gunung Slamet", "Indonesia", -7.2420, 109.2080, 3428, "slamet,gunung slamet"),
        g("Gunung Lawu", "Indonesia", -7.6270, 111.1940, 3265, "gunung lawu,mount lawu"),
        g("Gunung Arjuno", "Indonesia", -7.7650, 112.5800, 3339, "arjuno,gunung arjuno"),
        g("Gunung Welirang", "Indonesia", -7.7320, 112.5880, 3156, "welirang,gunung welirang"),
        g("Gunung Raung", "Indonesia", -8.1250, 114.0420, 3332, "gunung raung,mount raung"),
        g("Gunung Ijen", "Indonesia", -8.0580, 114.2420, 2386, "ijen,gunung ijen,kawah ijen"),
        g("Gunung Gede", "Indonesia", -6.7810, 106.9800, 2958, "gunung gede,mount gede"),
        g("Gunung Pangrango", "Indonesia", -6.7700, 106.9700, 3019, "pangrango,gunung pangrango"),
        g("Gunung Ciremai", "Indonesia", -6.8920, 108.4000, 3078, "ciremai,gunung ciremai,cereme"),
        g("Gunung Salak", "Indonesia", -6.7190, 106.7330, 2211, "gunung salak,mount salak"),
        g("Gunung Papandayan", "Indonesia", -7.3200, 107.7300, 2665, "papandayan,gunung papandayan"),
        g("Gunung Tangkuban Perahu", "Indonesia", -6.7597, 107.6097, 2084, "tangkuban perahu,tangkuban parahu"),
        g("Gunung Sinabung", "Indonesia", 3.1710, 98.3920, 2460, "sinabung,gunung sinabung"),
        g("Gunung Sibayak", "Indonesia", 3.2330, 98.5100, 2212, "sibayak,gunung sibayak"),
        g("Gunung Leuser", "Indonesia", 3.7500, 97.1700, 3404, "gunung leuser,mount leuser"),
        g("Gunung Anak Krakatau", "Indonesia", -6.1020, 105.4230, 305, "anak krakatau,krakatau,krakatoa"),
        g("Gunung Agung", "Indonesia", -8.3430, 115.5080, 3031, "gunung agung,mount agung"),
        g("Gunung Batur", "Indonesia", -8.2420, 115.3750, 1717, "gunung batur,mount batur"),
        g("Gunung Tambora", "Indonesia", -8.2500, 118.0000, 2722, "tambora,gunung tambora"),
        g("Gunung Kelimutu", "Indonesia", -8.7660, 121.8160, 1639, "kelimutu,gunung kelimutu"),
        g("Gunung Latimojong (Rante Mario)", "Indonesia", -3.3830, 120.0170, 3478, "latimojong,rante mario,gunung latimojong"),
        g("Gunung Lokon", "Indonesia", 1.3580, 124.7920, 1580, "gunung lokon,mount lokon"),
        // Asia Tenggara dan Asia Timur
        g("Gunung Kinabalu|Mount Kinabalu", "Malaysia", 6.0750, 116.5583, 4095, "kinabalu,gunung kinabalu,mount kinabalu"),
        g("Gunung Tahan|Mount Tahan", "Malaysia", 4.6333, 102.2333, 2187, "gunung tahan,mount tahan"),
        g("Fansipan", "Vietnam", 22.3033, 103.7750, 3147, "fansipan,phan xi pang"),
        g("Doi Inthanon", "Thailand", 18.5883, 98.4867, 2565, "doi inthanon,inthanon"),
        g("Gunung Apo|Mount Apo", "Filipina|Philippines", 6.9870, 125.2700, 2954, "gunung apo,mount apo"),
        g("Gunung Mayon|Mount Mayon", "Filipina|Philippines", 13.2570, 123.6860, 2462, "mayon,gunung mayon,mount mayon"),
        g("Gunung Fuji|Mount Fuji", "Jepang|Japan", 35.3606, 138.7274, 3776, "fuji,gunung fuji,mount fuji,fujiyama,fuji san"),
        g("Gunung Yari|Mount Yari", "Jepang|Japan", 36.3417, 137.6475, 3180, "gunung yari,mount yari,yarigatake"),
        g("Gunung Ontake|Mount Ontake", "Jepang|Japan", 35.8933, 137.4803, 3067, "ontake,gunung ontake,mount ontake"),
        g("Gunung Halla|Mount Halla", "Korea Selatan|South Korea", 33.3617, 126.5292, 1947, "halla,hallasan,gunung halla,mount halla"),
        g("Gunung Seorak|Mount Seorak", "Korea Selatan|South Korea", 38.1194, 128.4656, 1708, "seorak,seoraksan,gunung seorak"),
        g("Gunung Baekdu|Mount Paektu", "Korea Utara & Tiongkok|North Korea & China", 41.9950, 128.0750, 2744, "baekdu,paektu,changbai,gunung baekdu"),
        g("Gunung Tai|Mount Tai", "Tiongkok|China", 36.2540, 117.1010, 1545, "taishan,gunung tai,mount tai"),
        g("Gunung Huang|Huangshan", "Tiongkok|China", 30.1317, 118.1650, 1864, "huangshan,gunung huang,yellow mountain"),
        g("Gunung Hua|Mount Hua", "Tiongkok|China", 34.4833, 110.0833, 2155, "huashan,gunung hua,mount hua"),
        g("Gunung Emei|Mount Emei", "Tiongkok|China", 29.5167, 103.3333, 3099, "emei,gunung emei,mount emei"),
        // Himalaya, Karakoram, Asia Tengah dan Barat
        g("Gunung Everest|Mount Everest", "Nepal & Tiongkok|Nepal & China", 27.9881, 86.9250, 8849, "everest,gunung everest,mount everest,sagarmatha,chomolungma"),
        g("K2", "Pakistan & Tiongkok|Pakistan & China", 35.8825, 76.5133, 8611, "k2,k 2,godwin austen,gunung k2"),
        g("Kangchenjunga", "Nepal & India|Nepal & India", 27.7025, 88.1475, 8586, "kangchenjunga,kanchenjunga,kangchenjungga"),
        g("Lhotse", "Nepal & Tiongkok|Nepal & China", 27.9617, 86.9333, 8516, "lhotse"),
        g("Makalu", "Nepal & Tiongkok|Nepal & China", 27.8897, 87.0886, 8485, "makalu"),
        g("Cho Oyu", "Nepal & Tiongkok|Nepal & China", 28.0942, 86.6609, 8188, "cho oyu"),
        g("Dhaulagiri", "Nepal", 28.6967, 83.4875, 8167, "dhaulagiri"),
        g("Manaslu", "Nepal", 28.5497, 84.5597, 8163, "manaslu"),
        g("Nanga Parbat", "Pakistan", 35.2372, 74.5894, 8126, "nanga parbat"),
        g("Annapurna", "Nepal", 28.5961, 83.8203, 8091, "annapurna"),
        g("Gasherbrum I", "Pakistan & Tiongkok|Pakistan & China", 35.7244, 76.6967, 8080, "gasherbrum,gasherbrum 1,gasherbrum i"),
        g("Broad Peak", "Pakistan & Tiongkok|Pakistan & China", 35.8128, 76.5653, 8051, "broad peak"),
        g("Shishapangma", "Tiongkok|China", 28.3525, 85.7794, 8027, "shishapangma,shisha pangma"),
        g("Ama Dablam", "Nepal", 27.8617, 86.8614, 6812, "ama dablam"),
        g("Gunung Kailash|Mount Kailash", "Tiongkok (Tibet)|China (Tibet)", 31.0675, 81.3119, 6638, "kailash,gunung kailash,mount kailash"),
        g("Gunung Damavand|Mount Damavand", "Iran", 35.9558, 52.1099, 5610, "damavand,gunung damavand,mount damavand"),
        g("Gunung Ararat|Mount Ararat", "Turki|Turkey", 39.7019, 44.2983, 5137, "ararat,gunung ararat,mount ararat,agri dagi"),
        g("Gunung Elbrus|Mount Elbrus", "Rusia|Russia", 43.3499, 42.4453, 5642, "elbrus,gunung elbrus,mount elbrus"),
        g("Gunung Kazbek|Mount Kazbek", "Georgia", 42.6990, 44.5180, 5054, "kazbek,gunung kazbek,mount kazbek"),
        g("Jabal Sinai (Gunung Musa)|Mount Sinai", "Mesir|Egypt", 28.5392, 33.9750, 2285, "gunung sinai,jabal musa,mount sinai,gunung musa,jabal sinai,thur sina"),
        g("Jabal Rahmah", "Arab Saudi|Saudi Arabia", 21.3550, 39.9840, 372, "jabal rahmah,jabal rahmat,bukit rahmah"),
        g("Jabal Nur", "Arab Saudi|Saudi Arabia", 21.4575, 39.8578, 642, "jabal nur,jabal nuur,gua hira,gunung nur"),
        g("Jabal Uhud", "Arab Saudi|Saudi Arabia", 24.5033, 39.6117, 1077, "jabal uhud,gunung uhud,bukit uhud,uhud"),
        // Eropa
        g("Mont Blanc", "Prancis & Italia|France & Italy", 45.8326, 6.8652, 4806, "mont blanc,montblanc"),
        g("Matterhorn", "Swiss & Italia|Switzerland & Italy", 45.9763, 7.6586, 4478, "matterhorn,cervino"),
        g("Eiger", "Swiss|Switzerland", 46.5775, 8.0053, 3967, "eiger"),
        g("Jungfrau", "Swiss|Switzerland", 46.5367, 7.9625, 4158, "jungfrau"),
        g("Monte Rosa", "Swiss & Italia|Switzerland & Italy", 45.9369, 7.8667, 4634, "monte rosa,dufourspitze"),
        g("Zugspitze", "Jerman & Austria|Germany & Austria", 47.4211, 10.9863, 2962, "zugspitze"),
        g("Grossglockner", "Austria", 47.0742, 12.6939, 3798, "grossglockner,grosglockner"),
        g("Triglav", "Slovenia", 46.3785, 13.8364, 2864, "triglav"),
        g("Gunung Etna|Mount Etna", "Italia|Italy", 37.7510, 14.9934, 3357, "etna,gunung etna,mount etna"),
        g("Gunung Vesuvius|Mount Vesuvius", "Italia|Italy", 40.8224, 14.4289, 1281, "vesuvius,vesuvio,gunung vesuvius"),
        g("Gunung Olympus|Mount Olympus", "Yunani|Greece", 40.0859, 22.3584, 2918, "olympus,gunung olympus,mount olympus,olimpus"),
        g("Ben Nevis", "Inggris Raya (Skotlandia)|United Kingdom (Scotland)", 56.7969, -5.0036, 1345, "ben nevis"),
        g("Gunung Snowdon|Mount Snowdon", "Inggris Raya (Wales)|United Kingdom (Wales)", 53.0685, -4.0763, 1085, "snowdon,yr wyddfa"),
        g("Gunung Teide|Mount Teide", "Spanyol (Kepulauan Canary)|Spain (Canary Islands)", 28.2723, -16.6425, 3715, "teide,gunung teide,mount teide"),
        g("Mulhacén", "Spanyol|Spain", 37.0539, -3.3114, 3479, "mulhacen,mulhacén"),
        g("Musala", "Bulgaria", 42.1789, 23.5854, 2925, "musala"),
        g("Gerlach", "Slowakia|Slovakia", 49.1647, 20.1317, 2655, "gerlach,gerlachovsky stit"),
        g("Galdhøpiggen", "Norwegia|Norway", 61.6364, 8.3125, 2469, "galdhopiggen,galdhøpiggen"),
        g("Gunung Hekla|Mount Hekla", "Islandia|Iceland", 63.9920, -19.6660, 1491, "hekla,gunung hekla"),
        // Afrika
        g("Gunung Kilimanjaro|Mount Kilimanjaro", "Tanzania", -3.0674, 37.3556, 5895, "kilimanjaro,kilimanjaro uhuru,gunung kilimanjaro,mount kilimanjaro,uhuru peak"),
        g("Gunung Kenya|Mount Kenya", "Kenya", -0.1521, 37.3084, 5199, "gunung kenya,mount kenya"),
        g("Gunung Meru|Mount Meru", "Tanzania", -3.2467, 36.7500, 4562, "gunung meru,mount meru"),
        g("Gunung Stanley|Mount Stanley", "Uganda & Kongo|Uganda & Congo", 0.3833, 29.8717, 5109, "mount stanley,gunung stanley,margherita peak,rwenzori"),
        g("Gunung Kamerun|Mount Cameroon", "Kamerun|Cameroon", 4.2030, 9.1700, 4040, "gunung kamerun,mount cameroon,fako"),
        g("Ras Dashen", "Etiopia|Ethiopia", 13.2417, 38.3667, 4550, "ras dashen,ras dejen"),
        g("Jebel Toubkal", "Maroko|Morocco", 31.0592, -7.9156, 4167, "toubkal,jebel toubkal"),
        g("Gunung Table|Table Mountain", "Afrika Selatan|South Africa", -33.9628, 18.4098, 1086, "table mountain,gunung table"),
        // Amerika
        g("Denali", "Amerika Serikat (Alaska)|United States (Alaska)", 63.0695, -151.0074, 6190, "denali,mount mckinley,mckinley"),
        g("Gunung Logan|Mount Logan", "Kanada|Canada", 60.5670, -140.4050, 5959, "mount logan,gunung logan"),
        g("Gunung Rainier|Mount Rainier", "Amerika Serikat|United States", 46.8523, -121.7603, 4392, "rainier,mount rainier,gunung rainier"),
        g("Gunung Whitney|Mount Whitney", "Amerika Serikat|United States", 36.5786, -118.2920, 4421, "whitney,mount whitney,gunung whitney"),
        g("Gunung Washington|Mount Washington", "Amerika Serikat|United States", 44.2706, -71.3036, 1917, "mount washington,gunung washington"),
        g("Gunung St. Helens|Mount St. Helens", "Amerika Serikat|United States", 46.1914, -122.1956, 2549, "st helens,saint helens,mount st helens,gunung st helens"),
        g("Gunung Shasta|Mount Shasta", "Amerika Serikat|United States", 41.4092, -122.1949, 4322, "shasta,mount shasta,gunung shasta"),
        g("Gunung Hood|Mount Hood", "Amerika Serikat|United States", 45.3735, -121.6959, 3429, "mount hood,gunung hood"),
        g("Gunung Baker|Mount Baker", "Amerika Serikat|United States", 48.7767, -121.8144, 3286, "mount baker,gunung baker"),
        g("Pikes Peak", "Amerika Serikat|United States", 38.8409, -105.0423, 4302, "pikes peak"),
        g("Longs Peak", "Amerika Serikat|United States", 40.2549, -105.6159, 4346, "longs peak"),
        g("Grand Teton", "Amerika Serikat|United States", 43.7410, -110.8024, 4199, "grand teton"),
        g("Mauna Kea", "Amerika Serikat (Hawaii)|United States (Hawaii)", 19.8207, -155.4681, 4207, "mauna kea"),
        g("Mauna Loa", "Amerika Serikat (Hawaii)|United States (Hawaii)", 19.4750, -155.6083, 4169, "mauna loa"),
        g("Haleakalā", "Amerika Serikat (Hawaii)|United States (Hawaii)", 20.7097, -156.2533, 3055, "haleakala,haleakalā"),
        g("Pico de Orizaba", "Meksiko|Mexico", 19.0300, -97.2700, 5636, "orizaba,pico de orizaba"),
        g("Popocatépetl", "Meksiko|Mexico", 19.0225, -98.6278, 5426, "popocatepetl,popocatépetl"),
        g("Chimborazo", "Ekuador|Ecuador", -1.4692, -78.8175, 6263, "chimborazo"),
        g("Cotopaxi", "Ekuador|Ecuador", -0.6838, -78.4361, 5897, "cotopaxi"),
        g("Huascarán", "Peru", -9.1217, -77.6044, 6768, "huascaran,huascarán"),
        g("Aconcagua", "Argentina", -32.6532, -70.0109, 6961, "aconcagua"),
        g("Ojos del Salado", "Chili & Argentina|Chile & Argentina", -27.1092, -68.5414, 6893, "ojos del salado"),
        g("Fitz Roy", "Argentina & Chili|Argentina & Chile", -49.2711, -72.9431, 3405, "fitz roy,fitzroy,cerro chalten"),
        // Oseania dan Antartika
        g("Gunung Wilhelm|Mount Wilhelm", "Papua Nugini|Papua New Guinea", -5.7833, 145.0333, 4509, "gunung wilhelm,mount wilhelm"),
        g("Gunung Kosciuszko|Mount Kosciuszko", "Australia", -36.4559, 148.2636, 2228, "kosciuszko,gunung kosciuszko,mount kosciuszko"),
        g("Aoraki (Gunung Cook)|Aoraki / Mount Cook", "Selandia Baru|New Zealand", -43.5950, 170.1418, 3724, "aoraki,mount cook,gunung cook"),
        g("Gunung Taranaki|Mount Taranaki", "Selandia Baru|New Zealand", -39.2964, 174.0634, 2518, "taranaki,mount egmont,gunung taranaki"),
        g("Gunung Ruapehu|Mount Ruapehu", "Selandia Baru|New Zealand", -39.2817, 175.5640, 2797, "ruapehu,gunung ruapehu"),
        g("Gunung Erebus|Mount Erebus", "Antartika|Antarctica", -77.5300, 167.1700, 3794, "erebus,gunung erebus,mount erebus"),
        g("Massif Vinson|Vinson Massif", "Antartika|Antarctica", -78.5254, -85.6171, 4892, "vinson,vinson massif,gunung vinson")
    )

    private fun token(u: String): List<String> =
        u.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private val kataCuaca = setOf("cuaca", "cuacanya", "weather", "forecast", "prakiraan", "prakiraannya", "prediksi", "ramalan", "perkiraan",
        "suhu", "temperature", "angin", "wind", "hujan", "rain", "salju", "snow", "badai", "storm", "dingin", "cold", "kabut", "fog",
        "berawan", "cerah", "sunny", "cloudy")
    private val kataGunung = setOf("gunung", "gn", "mount", "mt", "mountain", "summit", "peak", "puncak")
    private val kataBerhenti = setOf("hari", "ini", "besok", "lusa", "nanti", "pagi", "siang", "sore", "malam", "dini", "sekarang", "saat", "pada", "di",
        "yang", "apakah", "bagaimana", "gimana", "seperti", "cuaca", "weather", "forecast", "today", "tomorrow", "now", "tonight", "this", "morning",
        "afternoon", "evening", "night", "kondisi", "suhu", "angin", "hujan", "berapa", "dan", "atau", "tolong", "bisa", "dong", "ya", "ketika", "pukul", "jam", "at", "in", "on", "is", "how", "what", "the")
    private val kataKecualiKota = setOf("bmkg", "gempa", "earthquake", "sholat", "salat", "shalat", "adzan", "azan", "baterai", "battery")

    /** Gunung dari tabel yang disebut dalam [ucapan] (kunci terpanjang diutamakan). */
    fun cari(ucapan: String): Gunung? {
        val padded = " " + token(ucapan).joinToString(" ") + " "
        var terbaik: Gunung? = null; var panjang = 0
        for (m in daftar) for (k in m.kunci) if (padded.contains(" $k ") && k.length > panjang) { panjang = k.length; terbaik = m }
        if (terbaik != null) return terbaik
        // FIX357: pengenal suara sering salah satu huruf (merapih, semeru -> semeroe); cocokkan kata tunggal panjang dengan selisih satu huruf.
        val kata = token(ucapan)
        for (m in daftar) for (k in m.kunci) {
            if (k.length < 6 || k.contains(' ')) continue
            if (kata.any { it.length in (k.length - 1)..(k.length + 1) && selisihSatu(it, k) }) return m
        }
        return null
    }

    private fun selisihSatu(a: String, b: String): Boolean {
        if (a == b) return true
        if (Math.abs(a.length - b.length) > 1) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        return when {
            a.length == b.length -> a.substring(i + 1) == b.substring(i + 1)
            a.length > b.length -> a.substring(i + 1) == b.substring(i)
            else -> a.substring(i) == b.substring(i + 1)
        }
    }

    /** Nama gunung yang tidak ada di tabel, diambil dari kata sesudah "gunung"/"mount"; null bila tidak ada. */
    fun namaTakDikenal(ucapan: String): String? {
        val t = token(ucapan)
        val i = t.indexOfFirst { it in setOf("gunung", "gn", "mount", "mt", "mountain") }
        if (i < 0) return null
        val nama = t.drop(i + 1).takeWhile { it !in kataBerhenti }.take(3)
        return if (nama.isEmpty() || nama.any { it.toIntOrNull() != null }) null else (t[i].let { if (it == "gunung" || it == "gn") "gunung" else "mount" } + " " + nama.joinToString(" "))
    }

    private val kataCuacaKuat = setOf("cuaca", "cuacanya", "weather", "forecast", "prakiraan", "prediksi", "ramalan", "perkiraan", "suhu", "temperature", "angin", "wind", "hujan", "rain", "salju", "snow", "kabut", "fog")
    private val kataStatus = setOf("status", "aktivitas", "aktifitas", "erupsi", "meletus", "letusan", "guguran", "level", "siaga", "waspada", "awas", "kondisi", "keadaan", "situasi", "terkini", "terbaru", "informasi", "info", "vulkanik", "condition", "conditions", "activity", "eruption", "erupting", "latest", "update", "volcano")
    private val gunungApiId = setOf("Gunung Merapi", "Gunung Semeru", "Gunung Bromo", "Gunung Agung", "Gunung Batur", "Gunung Rinjani", "Gunung Sinabung", "Gunung Sibayak", "Gunung Anak Krakatau", "Gunung Raung", "Gunung Ijen", "Gunung Tambora", "Gunung Kelimutu", "Gunung Lokon", "Gunung Slamet", "Gunung Ciremai", "Gunung Gede", "Gunung Salak", "Gunung Papandayan", "Gunung Tangkuban Perahu", "Gunung Kerinci", "Gunung Arjuno", "Gunung Welirang", "Gunung Lawu", "Gunung Sumbing", "Gunung Sindoro", "Gunung Merbabu")

    /** true bila ucapan menanyakan kondisi/status terkini sebuah gunung dari tabel, tanpa kata cuaca. */
    fun statusPermintaan(ucapan: String): Boolean {
        val t = token(ucapan)
        if (t.isEmpty() || t.size > 24) return false
        if (t.any { it in kataKecualiKota || it in kataCuacaKuat }) return false
        if (t.none { it in kataStatus }) return false
        return cari(ucapan) != null
    }

    /** Kondisi terkini sebuah gunung: cuaca puncak, peringatan dan gempa BMKG bila di Indonesia, serta catatan jujur soal status resmi. Jalankan di thread latar. */
    fun kondisi(ucapanSemua: List<String>, eng: Boolean): String {
        val m = ucapanSemua.firstNotNullOfOrNull { cari(it) } ?: return tr("Gunung yang dimaksud belum jelas.", "It is not clear which mountain you mean.", eng)
        val nama = if (eng) m.namaEn else m.namaId
        val sb = StringBuilder()
        sb.append(tr("Kondisi terkini " + nama + ". ", "Current conditions at " + nama + ". ", eng))
        sb.append(jawab(ucapanSemua, eng, InfoCuaca.Permintaan(InfoCuaca.Fokus.UMUM, 0)))
        val diIndonesia = m.negaraId.startsWith("Indonesia")
        if (diIndonesia) {
            if (m.namaId == "Gunung Merapi" || m.namaId == "Gunung Merbabu") {
                val p = try { InfoBmkg.peringatanSingkat("Yogyakarta", eng) } catch (_: Exception) { null }
                if (p != null) sb.append(' ').append(tr("Untuk Yogyakarta: ", "For Yogyakarta: ", eng)).append(p)
            }
            val gempa = try { InfoBmkg.gempaTerbaru(eng) } catch (_: Exception) { null }
            if (gempa != null) sb.append(' ').append(gempa)
        }
        if (m.namaId in gunungApiId) {
            sb.append(' ')
            if (m.namaId == "Gunung Merapi") sb.append(tr("Status level aktivitas Merapi (Normal, Waspada, Siaga, Awas) ditetapkan resmi oleh BPPTKG dan PVMBG. Saya belum memiliki sumber data resmi yang terverifikasi untuk membacanya otomatis, jadi saya tidak menebaknya. Lihat aplikasi MAGMA Indonesia atau situs BPPTKG Yogyakarta untuk status dan jarak bahaya terbaru.",
                "The official Merapi activity level (Normal, Waspada, Siaga, Awas) is set by BPPTKG and PVMBG. I do not have a verified official data source to read it automatically, so I will not guess it. Check the MAGMA Indonesia app or the BPPTKG Yogyakarta site for the latest level and danger zone.", eng))
            else if (diIndonesia) sb.append(tr("Status level aktivitas gunung api ditetapkan resmi oleh PVMBG. Saya belum memiliki sumber data resmi yang terverifikasi untuk membacanya otomatis, jadi saya tidak menebaknya. Lihat aplikasi MAGMA Indonesia untuk status terbaru.",
                "The official volcano activity level is set by PVMBG. I do not have a verified official data source to read it automatically, so I will not guess it. Check the MAGMA Indonesia app for the latest level.", eng))
        }
        return sb.toString()
    }

    /** true bila ucapan menanyakan cuaca di (puncak) gunung tertentu. */
    fun permintaan(ucapan: String): Boolean {
        val t = token(ucapan)
        if (t.isEmpty() || t.size > 24) return false
        if (t.any { it in kataKecualiKota }) return false
        if (t.none { it in kataCuaca }) return false
        if (cari(ucapan) != null) return true
        return namaTakDikenal(ucapan) != null
    }

    private fun cariDiGeokode(nama: String, eng: Boolean): Gunung? {
        val bersih = nama.replace(Regex("^(gunung|mount)\\s+"), "")
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(bersih, "UTF-8") + "&count=10&language=en&format=json"
        val js = JSONObject(OpenMeteo.ambilTeks(url))
        val arr = js.optJSONArray("results") ?: return null
        val tipe = setOf("MT", "MTS", "PK", "PKS", "VLC", "VLC", "PKSU", "MTU")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("feature_code") !in tipe) continue
            val el = if (o.has("elevation") && !o.isNull("elevation")) Math.round(o.optDouble("elevation", Double.NaN)).toInt() else -1
            val negara = o.optString("country", "")
            return Gunung(o.optString("name", bersih), o.optString("name", bersih), negara, negara, o.getDouble("latitude"), o.getDouble("longitude"), el, emptyList())
        }
        return null
    }

    private fun angka(x: Int) = x.toString()

    /** Jawaban lengkap; berjalan di thread latar. */
    fun jawab(ucapanSemua: List<String>, eng: Boolean, minta: InfoCuaca.Permintaan): String {
        var m: Gunung? = ucapanSemua.firstNotNullOfOrNull { cari(it) }
        var dariPencarian = false
        if (m == null) {
            val nama = ucapanSemua.firstNotNullOfOrNull { namaTakDikenal(it) }
                ?: return tr("Gunung yang dimaksud belum jelas. Sebutkan nama gunungnya.", "It is not clear which mountain you mean. Please say the mountain's name.", eng)
            m = try { cariDiGeokode(nama, eng) } catch (_: Exception) { null }
            if (m == null) return tr("Saya tidak menemukan gunung bernama " + nama + ", atau pencarian gagal karena jaringan. Coba sebutkan nama gunung dengan ejaan lain.",
                "I could not find a mountain named " + nama + ", or the search failed because of the network. Try another spelling.", eng)
            dariPencarian = true
        }
        val nama = if (eng) m.namaEn else m.namaId
        val negara = if (eng) m.negaraEn else m.negaraId
        val label = nama + (if (negara.isNotBlank()) ", " + negara else "") + if (m.tinggi > 0) tr(", ketinggian sekitar " + angka(m.tinggi) + " meter", ", elevation about " + angka(m.tinggi) + " meters", eng) else ""
        var url = OpenMeteo.alamat(m.lat, m.lon)
        if (m.tinggi > 0) url += "&elevation=" + m.tinggi
        val data = try { OpenMeteo.ambilData(url) } catch (_: Exception) { null }
            ?: return tr("Data cuaca untuk " + nama + " belum dapat diambil. Periksa koneksi internet, lalu coba lagi.", "Weather data for " + nama + " could not be fetched. Check your internet connection and try again.", eng)
        val sb = StringBuilder(InfoCuaca.susun(data, label, eng, minta, null))
        if (data.suhu <= 0.0) sb.append(tr(" Suhu di puncak sekarang di bawah titik beku; waspadai es dan hipotermia.", " The summit is currently below freezing; watch for ice and hypothermia.", eng))
        if (data.angin.isFinite() && data.angin >= 50.0) sb.append(tr(" Angin sangat kencang dan berbahaya untuk pendakian.", " The wind is very strong and dangerous for climbing.", eng))
        sb.append(tr(" Waktu mengikuti waktu setempat di gunung itu. ", " Times follow the local time at the mountain. ", eng))
        sb.append(tr("Ini prakiraan model cuaca yang disesuaikan ke ketinggian puncak, bukan hasil pengukuran stasiun di puncak, sehingga bisa meleset. Sebelum mendaki, cek juga peringatan resmi pengelola atau badan cuaca setempat.", "This is a weather-model forecast adjusted to the summit elevation, not a station measurement at the top, so it can be off. Before climbing, also check official warnings from the park or local weather service.", eng))
        if (dariPencarian && m.tinggi <= 0) sb.append(tr(" Tinggi puncak tidak diketahui, jadi suhu dan angin mungkin lebih hangat dari kenyataan di puncak.", " The summit height is unknown, so temperature and wind may be milder than at the top.", eng))
        else if (dariPencarian) sb.append(tr(" Gunung ini ditemukan lewat pencarian nama; pastikan lokasinya benar.", " This mountain was found by name search; please confirm it is the right place.", eng))
        return sb.toString()
    }
}
