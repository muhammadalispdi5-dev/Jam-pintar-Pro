package com.novan.bateraibicara

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Dasar semua halaman: pembangun tampilan sederhana dan blok pengaturan suara. */
abstract class Halaman : Activity() {

    protected lateinit var prefs: Prefs
    protected lateinit var root: LinearLayout
    private var pembicaraTes: Pembicara? = null
    private lateinit var halamanScroll: ScrollView
    private val namaEngine = ArrayList<String>()
    private val paketEngine = ArrayList<String>()

    protected abstract val judulHalaman: Int
    protected abstract fun bangun()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        muatEngine()
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(24))
        halamanScroll = ScrollView(this)
        halamanScroll.clipToPadding = false
        halamanScroll.isFillViewport = false
        halamanScroll.addView(root)
        halamanScroll.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            }
            insets
        }
        setContentView(halamanScroll)
        setTitle(judulHalaman)
        bagian(getString(judulHalaman), 26f)
        bangun()
        val posisiSimpan = savedInstanceState?.getInt("halaman_scroll_y", 0) ?: 0
        halamanScroll.post { halamanScroll.scrollTo(0, posisiSimpan.coerceAtLeast(0)) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::halamanScroll.isInitialized) outState.putInt("halaman_scroll_y", halamanScroll.scrollY)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        pembicaraTes?.matikan()
        pembicaraTes = null
        super.onDestroy()
    }

    // ---------- Pembangun tampilan ----------

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    protected fun larik(id: Int): List<String> = resources.getStringArray(id).toList()

    /** Kode kelompok yang sedang dibuka (null = halaman daftar utama). */
    protected fun kodeKelompok(): String? = intent.getStringExtra("kelompok")

    /** Tombol yang membuka kelompok pengaturan di halaman tersendiri (tombol Kembali kembali ke daftar). */
    protected fun tombolKelompok(label: String, kode: String): Button =
        tombol(label) { startActivity(Intent(this, javaClass).putExtra("kelompok", kode)) }

    /** Judul jendela dan judul utama (heading) sebuah kelompok. */
    protected fun judulGrup(nama: String) {
        title = nama
        bagian(nama, 22f)
    }

    protected fun bagian(teks: String, ukuran: Float = 20f) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(0, dp(24), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    protected fun info(teks: String): TextView {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 16f
        tv.setPadding(0, dp(4), 0, dp(4))
        root.addView(tv)
        return tv
    }

    protected fun saklar(teks: String, nilai: Boolean, onUbah: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = teks
        s.textSize = 16f
        s.isChecked = nilai
        s.setPadding(0, dp(12), 0, dp(12))
        s.setOnCheckedChangeListener { _, c -> onUbah(c) }
        root.addView(s)
        return s
    }

    protected fun tombol(teks: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = teks
        b.isAllCaps = false
        b.setOnClickListener { aksi() }
        root.addView(b)
        return b
    }

    protected fun pilihan(judul: String, items: List<String>, terpilih: Int, onPilih: (Int) -> Unit) {
        val tv = TextView(this)
        tv.text = judul
        tv.textSize = 16f
        tv.setPadding(0, dp(12), 0, 0)
        val sp = Spinner(this)
        sp.id = View.generateViewId()
        tv.labelFor = sp.id
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setSelection(terpilih, false)
        var terakhir = terpilih
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != terakhir) {
                    terakhir = pos
                    onPilih(pos)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(tv)
        root.addView(sp)
    }

    protected fun EditText.ubah(aksi: (String) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { aksi(s?.toString() ?: "") }
        })
    }

    /** Kolom isian dengan label yang terbaca TalkBack. */
    protected fun isian(label: String, nilai: String, tipe: Int, onUbah: (String) -> Unit): EditText {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 16f
        tv.setPadding(0, dp(12), 0, 0)
        val et = EditText(this)
        et.id = View.generateViewId()
        tv.labelFor = et.id
        et.inputType = tipe
        et.hint = label
        et.setText(nilai)
        et.ubah(onUbah)
        root.addView(tv)
        root.addView(et)
        return et
    }

    protected fun tombolJam(formatRes: Int, get: () -> Int, set: (Int) -> Unit) {
        val b = Button(this)
        b.isAllCaps = false
        fun segarkan() { b.text = getString(formatRes, JamWaktu.format(get())) }
        segarkan()
        b.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                set(h * 60 + m)
                segarkan()
            }, get() / 60, get() % 60, true).show()
        }
        root.addView(b)
    }

    protected fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_LONG).show()
    protected fun toast(teks: String) = Toast.makeText(this, teks, Toast.LENGTH_LONG).show()

    /** Simpan perubahan ke layanan yang sedang berjalan (jadwal jam dipasang ulang). */
    protected fun muatUlang() {
        if (prefs.enabled) BatteryTalkService.reload(this)
    }

    // ---------- Blok pengaturan suara ----------

    @Suppress("DEPRECATION")
    private fun muatEngine() {
        paketEngine.add("")
        namaEngine.add(getString(R.string.mesin_bawaan))
        val daftar = packageManager.queryIntentServices(
            Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE), 0
        )
        for (ri in daftar) {
            val si = ri.serviceInfo ?: continue
            if (paketEngine.contains(si.packageName)) continue
            paketEngine.add(si.packageName)
            namaEngine.add(ri.loadLabel(packageManager).toString())
        }
    }

    /** Mesin suara, kecepatan, nada, keluaran volume, dan tombol tes untuk satu profil. */
    protected fun blokSuara(profil: String, contoh: () -> String) {
        val s = prefs.suara(profil)
        bagian(getString(R.string.bagian_suara))
        pilihan(
            getString(R.string.mesin_suara), namaEngine,
            paketEngine.indexOf(s.engine).coerceAtLeast(0)
        ) { s.engine = paketEngine[it] }
        pilihan(getString(R.string.kecepatan), larik(R.array.kecepatan), s.rateIdx) { s.rateIdx = it }
        pilihan(getString(R.string.nada), larik(R.array.nada), s.pitchIdx) { s.pitchIdx = it }
        pilihan(getString(R.string.keluaran), larik(R.array.keluaran), s.streamIdx) { s.streamIdx = it }
        info(getString(R.string.contoh_hasil, contoh()))
        tombol(getString(R.string.tombol_tes)) { tesSuara(profil, contoh()) }
        tombol(getString(R.string.tombol_pengaturan_tts)) { bukaPengaturanTts() }
    }

    protected fun tesSuara(profil: String, teks: String) {
        pembicaraTes?.matikan()
        val p = Pembicara(this, prefs.suara(profil)) { toast(it) }
        pembicaraTes = p
        p.ucapkan(teks, true)
    }

    private fun bukaPengaturanTts() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    protected fun bukaInfoApp() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) { }
    }
}
