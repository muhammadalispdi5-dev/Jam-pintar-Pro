package com.novan.bateraibicara

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.abs

/** Kompas kiblat dengan petunjuk teks, opsional pengucapan otomatis dan getar. */
class QiblaActivity : Halaman(), SensorEventListener, TextToSpeech.OnInitListener {
    override val judulHalaman = R.string.kategori_kiblat
    private val pp by lazy { PrayerPrefs(this) }
    private lateinit var sensorManager: SensorManager
    private var rotationSensor: Sensor? = null
    private lateinit var status: android.widget.TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var heading = 0f
    private var bearing = 0.0
    private var inZone = false
    private var lastVoice = 0L
    private var tone: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    // Nada pendek berulang saat pengguna masih mencari arah kiblat.
    private val searchingToneLoop = object : Runnable {
        override fun run() {
            if (!inZone && pp.locationSet && rotationSensor != null) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }
                handler.postDelayed(this, 650L)
            }
        }
    }
    // Setelah arah kiblat ditemukan dan diumumkan, nada panjang berulang sebagai konfirmasi.
    private val alignmentToneLoop = object : Runnable {
        override fun run() {
            if (inZone) {
                try { tone?.startTone(ToneGenerator.TONE_DTMF_5, 2200) } catch (_: Exception) { }
                handler.postDelayed(this, 2450L)
            }
        }
    }
    private val voiceLoop = object : Runnable {
        override fun run() {
            if (pp.voiceQibla && ttsReady && pp.locationSet && rotationSensor != null) {
                val diff = selisih(bearing, heading.toDouble())
                // Jangan menimpa pengumuman konfirmasi ketika arah kiblat sudah ditemukan.
                if (abs(diff) >= 5.0) {
                    val text = "Arah perangkat ${arahMataAngin(heading.toDouble())}. Putar ke ${if (diff > 0) "kanan" else "kiri"} ${abs(diff).toInt()} derajat menuju kiblat"
                    tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "qibla-direction")
                    lastVoice = System.currentTimeMillis()
                }
            }
            handler.postDelayed(this, 1500L)
        }
    }

    override fun bangun() {
        bagian("Arah Kiblat")
        status = info("")
        info("Arah kiblat dihitung dari koordinat lokasi ke Ka'bah. Nada panjang di tengah dan getar berarti Anda menghadap kiblat dengan selisih kurang dari 5 derajat. Ucapan otomatis dan getar dimatikan secara bawaan.")
        tombol("Atur lokasi pada Jadwal Sholat") { startActivity(android.content.Intent(this, PrayerActivity::class.java)) }
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        tts = TextToSpeech(this, this)
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        if (!pp.locationSet) status.text = "Lokasi belum diatur. Buka Jadwal Sholat lalu atur lokasi GPS atau manual."
        else bearing = PrayerCalc.qiblaBearing(pp.lat, pp.lon)
        if (rotationSensor == null) status.text = "Perangkat ini tidak punya sensor kompas. Gunakan arah kiblat di atas bersama kompas lain."
        else status.text = "Arah kiblat ${"%.0f".format(bearing)}° (${arahMataAngin(bearing)}) dari utara. Kompas mendukung 8 arah mata angin. Gerakkan perangkat perlahan."
    }

    override fun onResume() {
        super.onResume()
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        handler.removeCallbacks(voiceLoop); handler.postDelayed(voiceLoop, 1500L)
        handler.removeCallbacks(searchingToneLoop)
        if (pp.locationSet && rotationSensor != null && !inZone) handler.post(searchingToneLoop)
    }
    override fun onPause() {
        sensorManager.unregisterListener(this)
        handler.removeCallbacks(voiceLoop)
        handler.removeCallbacks(alignmentToneLoop)
        handler.removeCallbacks(searchingToneLoop)
        try { tone?.stopTone() } catch (_: Exception) { }
        inZone = false
        super.onPause()
    }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; handler.removeCallbacks(alignmentToneLoop); try { tone?.stopTone(); tone?.release() } catch (_: Exception) { }; tone = null; super.onDestroy() }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) { tts.language = Locale("id", "ID"); ttsReady = true } }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR || !pp.locationSet) return
        val matrix = FloatArray(9); SensorManager.getRotationMatrixFromVector(matrix, event.values)
        val orientation = FloatArray(3); SensorManager.getOrientation(matrix, orientation)
        heading = ((Math.toDegrees(orientation[0].toDouble()).toFloat() + 360f) % 360f)
        bearing = PrayerCalc.qiblaBearing(pp.lat, pp.lon)
        val diff = selisih(bearing, heading.toDouble())
        val aligned = abs(diff) < 5.0
        val direction = if (aligned) {
            "Anda menghadap kiblat"
        } else {
            "Putar ke ${if (diff > 0) "kanan" else "kiri"} ${abs(diff).toInt()} derajat"
        }
        status.text = "Arah kiblat: ${"%.0f".format(bearing)}° (${arahMataAngin(bearing)}) dari utara" +
            "\nArah perangkat: ${"%.0f".format(heading)}° (${arahMataAngin(heading.toDouble())})" +
            "\nSelisih: ${"%.1f".format(abs(diff))}°\n$direction"
        if (aligned && !inZone) {
            handler.removeCallbacks(searchingToneLoop)
            handler.removeCallbacks(alignmentToneLoop)
            try { tone?.stopTone() } catch (_: Exception) { }
            if (ttsReady) {
                tts.speak("Anda tepat di arah kiblat.", TextToSpeech.QUEUE_FLUSH, null, "qibla-aligned")
                // Beri waktu agar pengumuman selesai sebelum nada panjang dimulai.
                handler.postDelayed(alignmentToneLoop, 1400L)
            } else {
                handler.post(alignmentToneLoop)
            }
        } else if (!aligned && inZone) {
            handler.removeCallbacks(alignmentToneLoop)
            try { tone?.stopTone() } catch (_: Exception) { }
            handler.removeCallbacks(searchingToneLoop)
            handler.post(searchingToneLoop)
        }
        if (aligned && !inZone && pp.qiblaHaptic) {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE)) else v.vibrate(800)
            } catch (_: Exception) { }
        }
        inZone = aligned
    }
    /** Membagi kompas menjadi 8 arah mata angin, masing-masing 45 derajat. */
    private fun arahMataAngin(derajat: Double): String {
        val arah = arrayOf(
            "Utara", "Timur Laut", "Timur", "Tenggara",
            "Selatan", "Barat Daya", "Barat", "Barat Laut"
        )
        val normal = ((derajat % 360.0) + 360.0) % 360.0
        val indeks = (kotlin.math.floor((normal + 22.5) / 45.0).toInt()) % 8
        return arah[indeks]
    }

    private fun selisih(target: Double, current: Double): Double = ((target - current + 540.0) % 360.0) - 180.0
}
