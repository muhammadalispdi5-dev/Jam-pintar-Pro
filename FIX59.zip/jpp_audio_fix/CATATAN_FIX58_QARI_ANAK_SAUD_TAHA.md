# FIX58 — Ahmad Saud bisa diputar, Muhammad Taha Al-Junayd selalu tampil di Qari anak

Versi tetap **1.0.69**. Basis: FIX57. Berkas diubah: `KhatamActivity.kt`, `AndroidManifest.xml`, `res/xml/network_security_config.xml` (baru).

## Penyebab yang ditemukan
1. FIX57 mengubah semua alamat server MP3Quran `http://` menjadi `https://` dan hanya mencoba satu alamat itu. Percobaan ulang untuk qari MP3Quran juga 0 bila tidak ada server cadangan. Server yang tidak melayani https (kemungkinan terjadi pada Ahmad Saud) langsung gagal tanpa percobaan lain, sedangkan Junaid Adam memakai server yang melayani https sehingga bisa diputar. Penyebab ini disimpulkan dari kode; API MP3Quran tidak dapat dijangkau dari lingkungan kerja, jadi belum diverifikasi langsung.
2. Muhammad Taha Al-Junayd hanya tampil bila katalog MP3Quran memuatnya dengan nama yang cocok. Bila tidak ada atau katalog gagal dimuat, daftar Qari anak tidak memuatnya.

## Perbaikan
- Urutan percobaan audio qari MP3Quran: https utama, lalu varian http server mp3quran.net yang sama, lalu server cadangan (https lalu http). Batas percobaan naik menjadi maksimum 6.
- `network_security_config.xml` mengizinkan http hanya untuk `mp3quran.net` dan subdomainnya; domain lain tetap wajib https. Didaftarkan di manifest.
- Muhammad Taha Al-Junayd selalu tampil di urutan pertama daftar Qari anak. Bila katalog MP3Quran memuatnya, entri katalog dipakai; bila tidak, dipakai sumber cadangan Internet Archive `https://archive.org/download/Muhammad-Taha-Al-Junaid/NNN.mp3`.
- Pengenalan nama diperluas: Taha dengan Junaid/Junayd/Junayd/Jineid atau Muhammad/Mohamed, nama Arab (termasuk huruf ya Persia), Ahmad/Ahmed (bin) Saud/Saoud/Suud.

## Batasan (belum diverifikasi)
- BELUM dikompilasi dan BELUM diuji di perangkat. Tanda kurung `{}` dan `[]` seimbang; selisih tanda kurung `()` sama seperti sebelum perubahan (berasal dari teks string).
- Sumber cadangan Taha hanya terkonfirmasi dari satu berkas contoh (`111.mp3`) pada halaman surahquran.com. Apakah ke-114 surah ada di arsip itu belum dapat diperiksa. Surah yang tidak ada akan gagal dengan pesan audio gagal.
- Penyebab Ahmad Saud di atas adalah dugaan terkuat dari kode. Bila setelah perbaikan ini masih gagal, status pemutaran akan menampilkan pesan gagal; kirim nama persis yang tampil dan pesannya agar bisa dilacak.
- `tools/verify_final.py` gagal pada "Kontrol streaming murattal dan jeda/lanjutkan tidak ditemukan"; kegagalan ini sudah ada pada berkas FIX57 asli dan tidak terkait perubahan ini.

## Uji
Buka Pilih suara qari > Qari anak: Muhammad Taha Al-Junayd harus urutan pertama (juga saat mode pesawat). Pilih Ahmad Saud, tekan Putar: surah penuh harus mulai. Coba beberapa surah untuk Taha.

## Tambahan (FIX59) — surah tidak tersedia pada qari anak
Dugaan lain untuk Ahmad Saud: qari anak sering hanya punya sebagian surah. Bila surah yang sedang dibuka tidak ada pada qari itu, kode lama hanya memunculkan toast singkat lalu berhenti, sehingga terkesan tidak bisa diputar. Sekarang muncul dialog (dan pengumuman status) yang menyebut surah yang tersedia, dengan tombol "Putar surah <terdekat>", "Pilih qari lain", "Batal". Daftar qari anak juga menampilkan "· hanya N surah" bila qari tidak lengkap. Dugaan ini juga belum diverifikasi ke data API.
