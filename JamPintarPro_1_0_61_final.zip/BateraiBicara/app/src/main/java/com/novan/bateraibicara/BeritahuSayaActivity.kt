package com.novan.bateraibicara

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.util.Calendar

/**
 * Aktivitas transparan yang menjadi pemicu suara dari widget layar utama.
 * Berjalan di task sendiri (lihat manifest) sehingga tidak membuka jendela aplikasi
 * yang masih ada di latar belakang.
 */
class BeritahuSayaActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutup() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mulai()
    }

    /** Pemicu diklik lagi saat pembacaan sebelumnya masih berjalan: ulang dari awal. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        hentikanSuara()
        selesai = false
        mulai()
    }

    private fun mulai() {
        try {
            val prefs = Prefs(applicationContext)
            if (!prefs.beritahuSayaOn) {
                android.widget.Toast.makeText(
                    this,
                    getString(R.string.beritahu_saya_nonaktif_petunjuk),
                    android.widget.Toast.LENGTH_LONG
                ).show()
                selesai = true
                finish()
                return
            }
            // Waktu dibacakan oleh suara jam; tanggal, libur, dan info sholat oleh suara pembaca tanggal.
            val c = Calendar.getInstance()
            val waktu = JamWaktu.ucapan(prefs, c)
            val tanggal = JamWaktu.segmenTanggal(prefs, c)
            val p = Pembicara(applicationContext, prefs.suara("jam"))
            pembicara = p
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val bacaTanggal = {
                if (tanggal.isEmpty()) tutup() else {
                    val pt = Pembicara(applicationContext, prefs.suara("tgl"))
                    pembicaraTanggal = pt
                    pt.ucapkanRangkaian(tanggal, 300L) { tutup() }
                }
            }
            if (waktu.isBlank()) bacaTanggal() else p.ucapkan(waktu, true) { bacaTanggal() }
        } catch (_: Exception) {
            tutup()
        }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        hentikanSuara()
        finish()
    }

    override fun onDestroy() {
        hentikanSuara()
        super.onDestroy()
    }
}
