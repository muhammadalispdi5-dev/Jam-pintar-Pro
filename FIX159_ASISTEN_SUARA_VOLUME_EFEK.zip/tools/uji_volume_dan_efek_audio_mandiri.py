from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
base = ROOT / 'app/src/main/java/com/novan/bateraibicara'
prefs = (base / 'Prefs.kt').read_text(encoding='utf-8')
page = (base / 'Halaman.kt').read_text(encoding='utf-8')
speaker = (base / 'Pembicara.kt').read_text(encoding='utf-8')
melody = (base / 'Melodi.kt').read_text(encoding='utf-8')
clock = (base / 'JamActivity.kt').read_text(encoding='utf-8')
battery = (base / 'BateraiActivity.kt').read_text(encoding='utf-8')
alarm = (base / 'AlarmJamService.kt').read_text(encoding='utf-8')
khatam = (base / 'KhatamActivity.kt').read_text(encoding='utf-8')
player = (base / 'PemutarQuranService.kt').read_text(encoding='utf-8')
assert 'var volumePersen: Int' in prefs and 'var efekPengumuman: Int' in prefs
assert '⚙ Volume mandiri dan efek pengumuman' in page
assert 'KEY_PARAM_VOLUME, suara.volumePersen / 100f' in speaker
assert 'ToneGenerator.TONE_PROP_BEEP' in speaker
assert 'volume: Float = 1.0f' in melody and 'player.setVolume(volume.coerceIn' in melody
assert 'volume = prefs.suara("jam").volumePersen / 100f' in clock
assert 'volume_persen' in battery and 'efek_pengumuman' in battery
assert 'volumeMandiri' in alarm and 'volume = Prefs(this).suara("jam").volumePersen / 100f' in alarm
assert 'pengaturanVolumeAudio()' in khatam and 'volume_audio_persen' in khatam
assert 'volume_audio_persen' in player
assert 'versi' not in ''
print('UJI VOLUME DAN EFEK AUDIO MANDIRI: LULUS (profil Jam, Baterai, Khatam; kontrol volume dan efek pengumuman)')
