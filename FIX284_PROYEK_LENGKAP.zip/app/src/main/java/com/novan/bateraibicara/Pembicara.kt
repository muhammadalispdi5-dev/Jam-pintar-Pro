package com.novan.bateraibicara

import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Pembungkus TextToSpeech untuk satu kategori (baterai / jam / pemanggil).
 * Memakai mesin suara pilihan pengguna, menahan CPU saat bicara (layar mati),
 * dan meminta fokus audio agar suara lain mengecil sebentar.
 */
class Pembicara(
    context: Context,
    private val suara: Prefs.Suara,
    private val peringatan: ((Int) -> Unit)? = null
) : TextToSpeech.OnInitListener {

    private class Item(val teks: String, val flush: Boolean, val selesai: (() -> Unit)?)

    private val app = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    val tanda: String = suara.tanda()
    /** FIX74: true untuk pengumuman otomatis (notifikasi); suara dapat dihentikan dengan menelungkupkan HP. */
    var bisaDibungkam = false
    /** FIX264: volume mandiri khusus (0..100) yang menggantikan volume profil suara; -1 = pakai volume profil. */
    var volumeKhusus = -1
    /** FIX279: bila 0..100, hanya pengali suara aplikasi (gain); volume saluran HP tidak diubah. */
    var volumeSaluran = -1
    /**
     * FIX154: true untuk pengumuman otomatis di latar belakang (jam bicara, baterai, pemberitahuan masuk). Pengumuman seperti ini hanya
     * meminta fokus audio "boleh diturunkan" (ducking): audio aplikasi lain, mis. voice note, mengecil sebentar lalu kembali normal.
     * Dengan fokus sementara penuh (perilaku sejak FIX146), aplikasi seperti WhatsApp menjeda voice note dan tidak melanjutkannya sendiri.
     * Ucapan asisten yang diminta pengguna tetap memakai fokus sementara penuh.
     */
    var hanyaKecilkanAudioLain = false
    /** FIX284: false = pengumuman tidak meminta fokus audio sama sekali (audio lain tidak diturunkan). */
    var pakaiFokus = true
    /** Paksa bahasa TTS mengikuti bahasa tampilan aplikasi untuk dialog asisten suara. */
    var paksaBahasaTampilan = false
    private val kunciBungkam = "tts:" + System.identityHashCode(this)
    private var tts: TextToSpeech? = null
    private var siap = false
    private var sudahCobaBawaan = false
    private var gagalInit = false
    private var terakhirCoba = 0L
    private val tunda = ArrayList<Item>()
    private val callbacks = HashMap<String, () -> Unit>()
    /** FIX277: ucapan yang sedang diproses mesin (id -> isi), dipakai untuk mengulang ucapan yang terputus pihak lain. */
    private val dalamProses = HashMap<String, Item>()
    private val jumlahUlang = HashMap<String, Int>()
    private val mulaiTerputus = HashMap<String, Long>()
    private val tugasUlang = HashMap<String, Runnable>()
    private var aktif = 0
    /** FIX282: pengali suara pengumuman 0..1 (kurva persepsi) dari volume saluran/sumber/profil. */
    /** FIX282: jam dan baterai memakai efek gema; diterapkan pada pemutar berkas karena sesi audio mesin suara tidak dapat diandalkan. */
    private fun gemaAktif(): Boolean = (suara.profil == "jam" || suara.profil == "bat") && suara.efekRuang in 1..10
    private val gemaRender by lazy { GemaAudio(app) }
    private fun kunciGema(i: Int): String = when (i) {
        1 -> "kamar"; 2 -> "ruang_sedang"; 3 -> "ruang_besar"; 4 -> "aula"; 5 -> "aula_besar"
        6 -> "plate"; 7 -> "echo_lembut"; 8 -> "studio"; 9 -> "karaoke"; 10 -> "panggung"; else -> "normal"
    }
    private fun gainSaatIni(): Float = VolumeSaluran.gain(if (volumeSaluran in 0..100) volumeSaluran else if (volumeKhusus in 0..100) volumeKhusus else suara.volumePersen)

    // FIX282: bila volume < 100%, ucapan dirender ke berkas lalu diputar dengan pengali volume sendiri, karena banyak mesin suara
    // mengabaikan KEY_PARAM_VOLUME. Volume saluran HP tidak disentuh.
    private val renderTeks = HashMap<String, String>()
    private val renderFile = HashMap<String, java.io.File>()
    private val antreanPutar = java.util.ArrayDeque<String>()
    private var pemutarRender: android.media.MediaPlayer? = null
    private var idDiputar: String? = null
    private var fokus: AudioFocusRequest? = null
    private var reverb: android.media.audiofx.PresetReverb? = null
    private var sesiReverb = -1
    private val wakeLock: PowerManager.WakeLock =
        (app.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bateraibicara:bicara")
            .apply { setReferenceCounted(false) }
    private val bersihkan = Runnable {
        // FIX283: batas waktu habis tanpa kabar dari mesin suara; anggap mesin macet. Callback yang tertunda tetap dipanggil agar
        // antrean pengumuman (notifikasi/panggilan) tidak ikut macet, lalu mesin dibuat ulang.
        val tertunda = ArrayList(callbacks.values)
        callbacks.clear()
        batalkanUlang()
        hentikanRender()
        aktif = 0
        rangkaianBerjalan = false
        selesaiBicara()
        if (tertunda.isNotEmpty()) pulihkanMesin()
        for (c in tertunda) try { c() } catch (_: Exception) { }
    }

    private var memulihkan = false
    private var pulihBeruntun = 0

    /** FIX283: mesin suara dibuat ulang bila speak() gagal atau mesin tidak merespons (mis. setelah pembaca layar memakainya berulang kali). */
    private fun pulihkanMesin() {
        if (memulihkan) return
        memulihkan = true
        siap = false
        handler.post {
            try { tts?.stop() } catch (_: Exception) { }
            try { tts?.shutdown() } catch (_: Exception) { }
            val engine = suara.engine
            tts = try { if (engine.isEmpty()) TextToSpeech(app, this) else TextToSpeech(app, this, engine) } catch (_: Exception) { null }
            if (tts == null) memulihkan = false
        }
    }

    init {
        val engine = suara.engine
        tts = if (engine.isEmpty()) TextToSpeech(app, this) else TextToSpeech(app, this, engine)
    }

    override fun onInit(status: Int) {
        memulihkan = false
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            if (suara.engine.isNotEmpty() && !sudahCobaBawaan) {
                sudahCobaBawaan = true
                handler.post {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = TextToSpeech(app, this)
                }
            } else {
                gagalInit = true
                peringatan?.invoke(R.string.tts_gagal)
            }
            return
        }
        // Bahasa pengucapan adalah pilihan global, bukan hanya untuk jam dan kalender.
        // Fitur lokasi dan pemandu jalan mengikuti bahasa tampilan aplikasi agar petunjuknya
        // tidak bercampur bahasa. Profil lain tetap mengikuti pilihan bahasa ucapan global.
        val bahasaUcapan = if (paksaBahasaTampilan || suara.profil == "pemandu" || suara.profil == "lokasi") {
            BahasaAplikasi.tampilan(app)
        } else Prefs(app).bahasaAktif
        val locale = when (bahasaUcapan) {
            1 -> Locale.forLanguageTag("en-US")
            2 -> Locale.forLanguageTag("ar")
            3 -> Locale.forLanguageTag("jv-ID")
            4 -> Locale.forLanguageTag("su-ID")
            else -> Locale.forLanguageTag("id-ID")
        }
        val r = t.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            peringatan?.invoke(R.string.bahasa_tidak_ada)
            val bahasaCadangan = Locale.forLanguageTag("id-ID")
            val r2 = t.setLanguage(bahasaCadangan)
            // FIX68: bila suara Indonesia pun belum terpasang, pakai bahasa bawaan HP agar pengumuman tidak senyap.
            if (r2 == TextToSpeech.LANG_MISSING_DATA || r2 == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.getDefault())
            }
        }
        t.setSpeechRate(suara.rate)
        t.setPitch(suara.pitch)
        t.setAudioAttributes(suara.audioAttributes())
        terapkanEfekRuangTts(t)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { pulihBeruntun = 0; if (utteranceId?.startsWith("rn") == true) renderSiap(utteranceId) else selesaiSatu(utteranceId, true) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (utteranceId?.startsWith("rn") == true) renderGagal(utteranceId) else terputus(utteranceId, true) }
            override fun onError(utteranceId: String?, errorCode: Int) { if (utteranceId?.startsWith("rn") == true) renderGagal(utteranceId) else terputus(utteranceId, true) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                // FIX277: bila ucapan terputus oleh pihak lain (mis. pembaca layar yang memakai mesin suara yang sama saat layar disentuh),
                // ucapan diulang dari awal kalimat setelah jeda singkat, bukan dibuang bersama pengumumannya.
                if (utteranceId?.startsWith("rn") == true) { if (interrupted) renderGagal(utteranceId) else selesaiSatu(utteranceId, false) }
                else if (interrupted) terputus(utteranceId, false) else selesaiSatu(utteranceId, false)
            }
        })
        siap = true
        val antrean = ArrayList(tunda)
        tunda.clear()
        for (i in antrean) ucapkan(i.teks, i.flush, i.selesai)
    }

    /** Terapkan efek ruang nyata pada sesi audio TTS (Android 8+); perangkat yang tidak mendukung tetap memakai suara normal. */
    /** TextToSpeech tidak punya audioSessionId publik: sesi dibuat sendiri dan dikirim lewat KEY_PARAM_SESSION_ID saat berbicara. */
    private var sesiTts = 0

    private fun sesiAudioTts(): Int {
        if (sesiTts > 0) return sesiTts
        sesiTts = try { (app.getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId().takeIf { it > 0 } ?: 0 } catch (_: Exception) { 0 }
        return sesiTts
    }

    private fun terapkanEfekRuangTts(@Suppress("UNUSED_PARAMETER") mesin: TextToSpeech) {
        if (suara.profil != "jam" && suara.profil != "bat") return
        if (Build.VERSION.SDK_INT < 26) return
        val pilihan = suara.efekRuang
        if (pilihan <= 0) { lepasEfekRuang(); return }
        try {
            val sesi = sesiAudioTts()
            if (sesi <= 0) return
            if (reverb != null && sesiReverb != sesi) lepasEfekRuang()
            if (reverb == null) {
                reverb = android.media.audiofx.PresetReverb(0, sesi)
                sesiReverb = sesi
            }
            val preset = when (pilihan) {
                1 -> android.media.audiofx.PresetReverb.PRESET_SMALLROOM
                2 -> android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM
                3 -> android.media.audiofx.PresetReverb.PRESET_LARGEROOM
                4 -> android.media.audiofx.PresetReverb.PRESET_MEDIUMHALL
                5 -> android.media.audiofx.PresetReverb.PRESET_LARGEHALL
                6 -> android.media.audiofx.PresetReverb.PRESET_PLATE
                // Android tidak menyediakan efek echo/delay universal untuk sesi TTS.
                // Pilihan berikut memakai preset reverb terdekat dan dijelaskan di UI.
                7 -> android.media.audiofx.PresetReverb.PRESET_PLATE       // Echo-like
                8 -> android.media.audiofx.PresetReverb.PRESET_PLATE       // Vocal studio
                9 -> android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM  // Karaoke
                else -> android.media.audiofx.PresetReverb.PRESET_LARGEHALL // Concert stage
            }
            reverb?.let { if (it.hasControl()) { it.preset = preset; it.enabled = true } }
        } catch (_: Exception) {
            lepasEfekRuang()
        }
    }

    private fun lepasEfekRuang() {
        try { reverb?.enabled = false } catch (_: Exception) { }
        try { reverb?.release() } catch (_: Exception) { }
        reverb = null
        sesiReverb = -1
    }

    /** [selesai] dipanggil setelah kalimat selesai diucapkan (tidak dipanggil bila dihentikan paksa). */
    fun ucapkan(teks: String, flush: Boolean = false, selesai: (() -> Unit)? = null) {
        if (ModeAcara.aktif(app)) { selesai?.invoke(); return }
        val t = tts
        if (t == null || !siap) {
            // FIX68: mesin suara gagal aktif (mis. layanan suara baru dipasang atau sempat dimatikan sistem);
            // coba nyalakan ulang paling cepat tiap 5 detik, dan batasi antrean agar tidak menumpuk.
            if (gagalInit && System.currentTimeMillis() - terakhirCoba > 5000L) {
                gagalInit = false
                terakhirCoba = System.currentTimeMillis()
                handler.post {
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = TextToSpeech(app, this)
                }
            }
            if (tunda.size >= 5) tunda.removeAt(0)
            tunda.add(Item(teks, flush, selesai))
            return
        }
        ucapkanLangsung(teks, flush, selesai)
    }

    /** Simbol templat/dolar yang tersisa tidak dibacakan oleh mesin suara sebagai kata dolar. */
    private fun bersihkanSimbolUcapan(teks: String): String {
        val dolar = 36.toChar().toString() // kode karakter dipakai agar simbol tidak tertulis langsung di sumber
        return teks.replace(Regex(Regex.escape(dolar) + "\\{[^}]*\\}"), " ").replace(dolar, "").replace("{", " ").replace("}", " ")
    }

    private fun ucapkanLangsung(teks: String, flush: Boolean, selesai: (() -> Unit)?) {
        val t = tts
        if (t == null || !siap) {
            if (tunda.size >= 5) tunda.removeAt(0)
            tunda.add(Item(teks, flush, selesai))
            return
        }
        aktif++
        // FIX270: batas waktu mengikuti panjang teks agar pembacaan panjang (mis. cuaca lengkap) tidak terpotong di tengah.
        val perkiraanMs = (teks.length * 150L + 20_000L).coerceAtMost(900_000L)
        wakeLock.acquire(maxOf(60_000L, perkiraanMs + 10_000L))
        if (bisaDibungkam) PembungkamTelungkup.mulai(app, kunciBungkam, maxOf(90_000L, perkiraanMs + 30_000L)) { berhenti() }
        mintaFokus()
        handler.removeCallbacks(bersihkan)
        handler.postDelayed(bersihkan, maxOf(45_000L, perkiraanMs))
        val gain = gainSaatIni()
        val lewatBerkas = (gain < 0.97f || gemaAktif()) && Build.VERSION.SDK_INT >= 21
        val id = (if (lewatBerkas) "rn" else "bb") + System.nanoTime()
        if (selesai != null) callbacks[id] = selesai
        // Parameter stream lama juga dipasang karena sebagian mesin suara mengabaikan AudioAttributes.
        try { terapkanEfekRuangTts(t) } catch (_: Exception) { }
        val parameter = android.os.Bundle()
        parameter.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, suara.streamType())
        if (Build.VERSION.SDK_INT >= 26 && (suara.profil == "jam" || suara.profil == "bat") && suara.efekRuang > 0 && sesiTts > 0) {
            parameter.putInt(TextToSpeech.Engine.KEY_PARAM_SESSION_ID, sesiTts)
        }
        // Pastikan level keluaran TTS tidak tereduksi oleh parameter volume per-utterance.
        // Nilai 1.0 adalah level digital penuh; volume fisik tetap mengikuti kontrol Android.
        parameter.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, if (lewatBerkas) 1f else gain)
        if (flush) { batalkanUlang(); hentikanRender() } // ucapan baru menggantikan yang lama dengan sengaja: yang lama tidak boleh diulang
        dalamProses[id] = Item(teks, flush, selesai)
        if (lewatBerkas) {
            if (flush) { try { t.stop() } catch (_: Exception) { } }
            val berkas = java.io.File(app.cacheDir, "pem_" + id + ".wav")
            renderTeks[id] = teks
            renderFile[id] = berkas
            val r = try { t.synthesizeToFile(bersihkanSimbolUcapan(teks), android.os.Bundle(), berkas, id) } catch (_: Exception) { TextToSpeech.ERROR }
            if (r != TextToSpeech.SUCCESS) renderGagal(id)
            return
        }
        val hasil = t.speak(
            bersihkanSimbolUcapan(teks),
            if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            parameter,
            id
        )
        if (hasil != TextToSpeech.SUCCESS) {
            // FIX283: speak() ditolak (mesin mati atau terputus): antrekan ulang dan buat mesin baru, jangan buang pengumuman.
            dalamProses.remove(id); callbacks.remove(id)
            if (aktif > 0) aktif--
            if (pulihBeruntun < 3) { pulihBeruntun++; if (tunda.size >= 5) tunda.removeAt(0); tunda.add(Item(teks, flush, selesai)); pulihkanMesin() }
            else { pulihBeruntun = 0; if (aktif == 0) selesaiBicara(); selesai?.invoke() }
        }
    }

    /** Membacakan segmen satu per satu dengan jeda standar acuan main.lua (300 ms). */
    fun ucapkanRangkaian(segmen: List<String>, jedaMs: Long = 300L, selesai: (() -> Unit)? = null) {
        if (ModeAcara.aktif(app)) { selesai?.invoke(); return }
        val bersih = segmen.map { it.trim() }.filter { it.isNotEmpty() }
        if (bersih.isEmpty()) { selesai?.invoke(); return }
        var indeks = 0
        // FIX134: selama rangkaian berjalan, pendaftaran ke pembungkam (tombol volume dan telungkup) dipertahankan di sela kalimat.
        // Dahulu pendaftaran dilepas tiap kalimat selesai dan dipasang lagi di kalimat berikut, sehingga tombol volume tidak dikenali
        // pada jeda antarkalimat dan pada 1,2 detik pertama tiap kalimat (masa tenang pemantau volume).
        val id = ++idRangkaian
        rangkaianBerjalan = true
        fun akhiri() {
            if (id == idRangkaian) {
                rangkaianBerjalan = false
                if (bisaDibungkam) PembungkamTelungkup.selesai(kunciBungkam)
            }
            selesai?.invoke()
        }
        fun lanjut() {
            if (id != idRangkaian) return // dihentikan (tombol volume, telungkup, atau rangkaian baru)
            if (indeks >= bersih.size) { akhiri(); return }
            val teks = bersih[indeks++]
            ucapkan(teks, indeks == 1) {
                if (id != idRangkaian) return@ucapkan
                if (indeks >= bersih.size) akhiri()
                else handler.postDelayed({ lanjut() }, jedaMs.coerceAtLeast(0L))
            }
        }
        lanjut()
    }

    private var rangkaianBerjalan = false
    private var idRangkaian = 0

    /** FIX282: berkas ucapan [id] selesai dirender; masukkan ke antrean putar. */
    private fun renderSiap(id: String) {
        handler.post {
            val f = renderFile[id]
            if (f == null || dalamProses[id] == null) { selesaiTanpaPost(id, false); f?.delete(); renderFile.remove(id); renderTeks.remove(id); return@post }
            if (!f.exists() || f.length() < 200L) { renderGagal(id); return@post }
            antreanPutar.add(id)
            putarBerikutnya()
        }
    }

    private fun putarBerikutnya() {
        if (pemutarRender != null) return
        val id = antreanPutar.pollFirst() ?: return
        val f = renderFile[id]
        if (f == null) { selesaiTanpaPost(id, true); putarBerikutnya(); return }
        try {
            val mp = android.media.MediaPlayer()
            mp.setAudioAttributes(suara.audioAttributes())
            mp.setDataSource(f.path)
            mp.prepare()
            val g = gainSaatIni()
            mp.setVolume(g, g)
            val gema = gemaAktif()
            if (gema) { try { gemaRender.terapkanKunci(mp.audioSessionId, kunciGema(suara.efekRuang), 80) } catch (_: Exception) { } }
            mp.setOnCompletionListener { if (gema) handler.postDelayed({ selesaiRender(id) }, 1800L) else selesaiRender(id) }
            mp.setOnErrorListener { _, _, _ -> selesaiRender(id); true }
            pemutarRender = mp
            idDiputar = id
            mp.start()
        } catch (_: Exception) {
            try { pemutarRender?.release() } catch (_: Exception) { }
            pemutarRender = null; idDiputar = null
            selesaiRender(id)
        }
    }

    private fun selesaiRender(id: String) {
        if (idDiputar == id) {
            try { pemutarRender?.setOnCompletionListener(null); pemutarRender?.setOnErrorListener(null); pemutarRender?.release() } catch (_: Exception) { }
            pemutarRender = null; idDiputar = null
        }
        renderFile.remove(id)?.delete(); renderTeks.remove(id)
        if (antreanPutar.isEmpty()) { try { gemaRender.lepas() } catch (_: Exception) { } }
        selesaiTanpaPost(id, true)
        putarBerikutnya()
    }

    /** Render gagal atau terputus: ucapkan lewat jalur biasa dengan parameter volume mesin agar pengumuman tidak senyap. */
    private fun renderGagal(id: String) {
        handler.post {
            val teks = renderTeks.remove(id)
            renderFile.remove(id)?.delete()
            val t = tts
            if (teks == null || dalamProses[id] == null) { selesaiTanpaPost(id, false); return@post }
            if (t == null || !siap) { selesaiTanpaPost(id, true); return@post }
            val baru = "bb" + System.nanoTime()
            callbacks.remove(id)?.let { callbacks[baru] = it }
            dalamProses.remove(id)?.let { dalamProses[baru] = it }
            val p = android.os.Bundle()
            p.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, suara.streamType())
            p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, gainSaatIni())
            val h = try { t.speak(bersihkanSimbolUcapan(teks), TextToSpeech.QUEUE_ADD, p, baru) } catch (_: Exception) { TextToSpeech.ERROR }
            if (h != TextToSpeech.SUCCESS) { pulihkanMesin(); selesaiTanpaPost(baru, true) }
        }
    }

    /** Hentikan putaran berkas ucapan dan buang antreannya (flush, berhenti, atau pembersihan). */
    private fun hentikanRender() {
        val ikut = ArrayList<String>(antreanPutar)
        idDiputar?.let { ikut.add(it) }
        antreanPutar.clear()
        try { pemutarRender?.setOnCompletionListener(null); pemutarRender?.setOnErrorListener(null); pemutarRender?.stop() } catch (_: Exception) { }
        try { pemutarRender?.release() } catch (_: Exception) { }
        pemutarRender = null; idDiputar = null
        try { gemaRender.lepas() } catch (_: Exception) { }
        for (i in ikut) { renderFile.remove(i)?.delete(); renderTeks.remove(i); selesaiTanpaPost(i, false) }
        for (f in renderFile.values) try { f.delete() } catch (_: Exception) { }
        renderFile.clear(); renderTeks.clear()
    }

    private fun batalkanUlang() {
        for (r in tugasUlang.values) handler.removeCallbacks(r)
        tugasUlang.clear(); jumlahUlang.clear(); mulaiTerputus.clear(); dalamProses.clear()
    }

    /**
     * FIX277: ucapan [id] terputus. Bila bukan kita sendiri yang menghentikannya (ucapan masih tercatat), ucapan diulang tiap 1,5 detik
     * (maksimal 40 kali) sampai selesai, sehingga pengumuman panggilan/pesan dilanjutkan begitu pembaca layar berhenti memakai mesin suara.
     * Dahulu pengumuman itu mati selamanya bila layar disentuh saat pengumuman berbunyi.
     */
    private fun terputus(id: String?, panggil: Boolean) {
        handler.post {
            val item = if (id != null) dalamProses[id] else null
            val n = if (id != null) (jumlahUlang[id] ?: 0) else 0
            if (id != null && item != null && n < 20 && System.currentTimeMillis() - (mulaiTerputus[id] ?: System.currentTimeMillis().also { mulaiTerputus[id] = it }) < 45_000L && tts != null && siap && aktif > 0) {
                jumlahUlang[id] = n + 1
                val r = Runnable {
                    tugasUlang.remove(id)
                    val mesin = tts
                    if (dalamProses[id] == null || mesin == null || !siap) return@Runnable
                    if (ModeAcara.aktif(app)) { selesaiTanpaPost(id, false); return@Runnable }
                    val perkiraanMs = (item.teks.length * 150L + 20_000L).coerceAtMost(900_000L)
                    handler.removeCallbacks(bersihkan)
                    handler.postDelayed(bersihkan, maxOf(45_000L, perkiraanMs))
                    try { wakeLock.acquire(maxOf(60_000L, perkiraanMs + 10_000L)) } catch (_: Exception) { }
                    val param = android.os.Bundle()
                    param.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, suara.streamType())
                    param.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, gainSaatIni())
                    val hasil = try { mesin.speak(bersihkanSimbolUcapan(item.teks), TextToSpeech.QUEUE_ADD, param, id) } catch (_: Exception) { TextToSpeech.ERROR }
                    if (hasil != TextToSpeech.SUCCESS) { pulihkanMesin(); terputus(id, true) }
                }
                tugasUlang[id] = r
                handler.postDelayed(r, 1500L)
            } else {
                // FIX283: menyerah setelah batas ulang: tetap panggil callback agar antrean pengumuman berlanjut.
                selesaiTanpaPost(id, panggil || item != null)
            }
        }
    }

    fun berhenti() {
        batalkanUlang()
        hentikanRender()
        tunda.clear()
        callbacks.clear()
        aktif = 0
        idRangkaian++ // membatalkan kalimat rangkaian yang tertunda di sela jeda
        rangkaianBerjalan = false
        try { tts?.stop() } catch (e: Exception) { }
        selesaiBicara()
    }

    fun matikan() {
        berhenti()
        lepasEfekRuang()
        try { tts?.shutdown() } catch (e: Exception) { }
        tts = null
        siap = false
    }

    private fun selesaiSatu(id: String?, panggil: Boolean) {
        handler.post { selesaiTanpaPost(id, panggil) }
    }

    private fun selesaiTanpaPost(id: String?, panggil: Boolean) {
        if (id != null) {
            dalamProses.remove(id); jumlahUlang.remove(id); mulaiTerputus.remove(id)
            tugasUlang.remove(id)?.let { handler.removeCallbacks(it) }
        }
        val cb = if (id != null) callbacks.remove(id) else null
        if (aktif > 0) aktif--
        if (aktif == 0) selesaiBicara()
        if (panggil) cb?.invoke()
    }

    private fun selesaiBicara() {
        handler.removeCallbacks(bersihkan)
        lepasFokus()
        if (wakeLock.isHeld) wakeLock.release()
        if (bisaDibungkam && !rangkaianBerjalan) PembungkamTelungkup.selesai(kunciBungkam)
    }

    private fun mintaFokus() {
        if (!pakaiFokus) return
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val jenisFokus = if (hanyaKecilkanAudioLain) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        if (Build.VERSION.SDK_INT >= 26) {
            val req = AudioFocusRequest.Builder(jenisFokus)
                .setAudioAttributes(suara.audioAttributes())
                // Pemutar lain boleh menurunkan volumenya sendiri, bukan menjeda, saat pengumuman berbunyi.
                .setWillPauseWhenDucked(false)
                .build()
            fokus = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, suara.streamType(), jenisFokus)
        }
    }

    private fun lepasFokus() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= 26) {
            fokus?.let { am.abandonAudioFocusRequest(it) }
            fokus = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }
}
