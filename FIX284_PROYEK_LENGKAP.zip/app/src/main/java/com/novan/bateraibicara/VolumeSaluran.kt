package com.novan.bateraibicara

import android.content.Context

/**
 * FIX279: volume pengumuman (Nama Panggilan dan Pembacaan Notifikasi) TIDAK lagi mengubah volume saluran suara HP
 * (dering, notifikasi, alarm, media, dan lainnya). Volume HP sepenuhnya milik sistem; volume pengumuman hanya
 * menjadi pengali (gain) pada suara aplikasi sendiri: ucapan memakai parameter volume mesin suara dan melodi memakai
 * volume pemutar. Objek ini dipertahankan hanya agar pemanggil lama tetap kompatibel dan tidak menyentuh volume sistem.
 */
object VolumeSaluran {
    /** FIX282: kurva persepsi; 50% terdengar sekitar setengah keras (kuadrat), bukan hanya turun 6 dB seperti kurva linear. */
    fun gain(persen: Int): Float { val x = persen.coerceIn(0, 100) / 100f; return x * x }

    @Suppress("UNUSED_PARAMETER")
    fun pinjam(ctx: Context, streamType: Int, persen: Int) { }

    @Suppress("UNUSED_PARAMETER")
    fun lepas(ctx: Context) { }
}
