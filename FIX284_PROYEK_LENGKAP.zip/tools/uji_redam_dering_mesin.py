from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
c=t("CallerListener.kt"); p=t("Pembicara.kt")
if (R/"RedamDering.kt").exists(): g.append("GAGAL RedamDering.kt masih ada")
if "RedamDering." in c: g.append("GAGAL CallerListener masih memakai RedamDering")
if "hanyaKecilkanAudioLain = true" not in c or "pakaiFokus = prefs.pemRedamDering" not in c: g.append("GAGAL fokus duck tidak dipasang")
if "var pakaiFokus" not in p or "if (!pakaiFokus) return" not in p: g.append("GAGAL pakaiFokus")
for k in ("fun pulihkanMesin","pulihBeruntun","val tertunda = ArrayList(callbacks.values)","panggil || item != null"):
    if k not in p: g.append("GAGAL Pembicara: "+k)
import subprocess,re
for f in R.glob("*.kt"):
    if f.name=="PembungkamTelungkup.kt": continue
    if "setStreamVolume" in f.read_text(encoding="utf-8"): g.append("GAGAL setStreamVolume di "+f.name)
print("\n".join(g) if g else "UJI VOLUME MILIK APLIKASI: LULUS")
