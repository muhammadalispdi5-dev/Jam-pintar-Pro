# FIX284 (versi tetap 1.0.89)
- RedamDering.kt (FIX283) dihapus: aplikasi tidak lagi mengubah volume STREAM_RING atau saluran lain. Satu-satunya sentuhan volume sistem tinggal PembungkamTelungkup yang membatalkan tekanan tombol volume saat menghentikan suara aplikasi.
- Penurunan audio lain (nada dering, pemutar lain) kini hanya lewat fokus audio Android AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK untuk pengumuman panggilan dan semua notifikasi pesan; pulih sendiri saat fokus dilepas. Sakelar "Turunkan audio lain sementara saat pengumuman berbunyi" (Prefs.pemRedamDering); Pembicara.pakaiFokus.
- Halaman Pengaturan volume pengumuman menegaskan bahwa semua pengaturan hanya berlaku untuk aplikasi ini. Petunjuk ID 61 / EN 58.
- Batas: ducking lewat fokus adalah keputusan sistem/aplikasi lain; sebagian HP atau panggilan telepon mungkin tidak menurunkan dering. Belum dikompilasi dengan Gradle, belum diuji di perangkat.
