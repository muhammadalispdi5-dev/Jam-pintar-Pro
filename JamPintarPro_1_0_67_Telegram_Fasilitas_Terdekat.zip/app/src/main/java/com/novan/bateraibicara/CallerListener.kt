package com.novan.bateraibicara

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Membaca notifikasi panggilan MASUK (WhatsApp, WhatsApp Bisnis, & aplikasi telepon) lalu mengucapkan
 * nama pemanggil berulang-ulang sampai panggilan dijawab, ditolak, atau berhenti berdering.
 * Panggilan KELUAR (yang kita lakukan sendiri), panggilan yang sedang berlangsung, dan panggilan tak
 * terjawab tidak pernah diumumkan.
 * Dijalankan sistem secara otomatis (termasuk setelah HP dihidupkan ulang) selama
 * "Akses notifikasi" diizinkan.
 */
class CallerListener : NotificationListenerService() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var pembicara: Pembicara? = null

    private var berdering = false
    private var sumber = SUMBER_WA
    private var teks = ""
    private var ulang = 0
    private val kunciAktif = HashSet<String>()
    private var namaAktif = ""
    private val notifikasiDibaca = HashMap<String, Pair<String, Long>>()

    private var telCallback: Any? = null
    private var telListener: PhoneStateListener? = null

    private val ulangRunnable = Runnable { ucapUlang() }
    private val modeAcaraReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
            if (ModeAcara.aktif(this@CallerListener)) { hentikan(); hentikanUlangNotif() }
        }
    }
    private var notifTeksAktif = ""
    private var notifSudahDiucap = 0
    private var notifGenerasi = 0
    private var ulangNotifRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        val filter = android.content.IntentFilter("com.novan.jambicarapro.MODE_ACARA_DIAKTIFKAN")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(modeAcaraReceiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(modeAcaraReceiver, filter)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (prefs.enabled && prefs.pemOn) siapkanPembicara()
        daftarTelepon()
        // Tangani panggilan yang notifikasinya sudah tampil sebelum listener tersambung.
        try { activeNotifications?.forEach { sbn -> proses(sbn) } } catch (_: Exception) { }
    }

    override fun onListenerDisconnected() {
        hentikan()
        lepasTelepon()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        try { unregisterReceiver(modeAcaraReceiver) } catch (_: Exception) { }
        hentikan()
        lepasTelepon()
        pembicara?.matikan()
        pembicara = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try { proses(sbn) } catch (e: Exception) { }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null || !berdering) return
        if (kunciAktif.remove(sbn.key) && kunciAktif.isEmpty()) hentikan()
    }

    // ---------- Deteksi status bisu percakapan ----------

    /**
     * Memeriksa kanal percakapan yang dikelola Android, bukan menebak dari isi pesan.
     * Pada Android 11+, kanal percakapan dapat mewakili chat pribadi atau grup tertentu.
     * Kanal yang bisu (prioritas rendah dan tanpa suara) tidak diumumkan.
     * Jika sistem/aplikasi tidak menyediakan kanal percakapan khusus, hasilnya false.
     */
    private fun percakapanDibisukan(sbn: StatusBarNotification): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        return try {
            val ranking = NotificationListenerService.Ranking()
            if (!currentRanking.getRanking(sbn.key, ranking)) return false
            val kanal = ranking.channel ?: return false
            val idPercakapan = kanal.conversationId
            if (idPercakapan.isNullOrBlank()) return false
            val prioritasRendah = kanal.importance == NotificationManager.IMPORTANCE_LOW ||
                kanal.importance == NotificationManager.IMPORTANCE_MIN ||
                kanal.importance == NotificationManager.IMPORTANCE_NONE
            val tanpaSuara = kanal.sound == null
            prioritasRendah && tanpaSuara
        } catch (_: Exception) {
            false
        }
    }

    // ---------- Deteksi panggilan ----------

    // ---------- Deteksi panggilan dan pembacaan pesan ----------

    private fun proses(sbn: StatusBarNotification) {
        if (ModeAcara.aktif(this)) { if (berdering) hentikan(); hentikanUlangNotif(); return }
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val bisnis = pkg == "com.whatsapp.w4b"
        val wa = pkg == "com.whatsapp" || bisnis
        val telegram = pkg == "org.telegram.messenger" || pkg == "org.telegram.messenger.web"
        val paketTelepon = PAKET_TELEPON.containsMatchIn(pkg)
        // Hormati status bisu pada kanal percakapan Android (chat pribadi/grup) bila
        // sistem mengeksposnya. Ini mencakup teks dan pesan suara, serta notifikasi
        // panggilan WhatsApp yang terkait kanal percakapan tersebut.
        if ((wa || telegram || PAKET_PESAN_SELULER.containsMatchIn(pkg)) && percakapanDibisukan(sbn)) return
        val tipe = if (extras.containsKey("android.callType")) extras.getInt("android.callType") else -1

        // Panggilan diproses dengan logika lama agar panggilan keluar/tak terjawab tidak diumumkan.
        val panggilanTelegram = telegram && KATA_PANGGILAN_TELEGRAM.containsMatchIn(gabungTeks(n, extras))
        if (n.category == Notification.CATEGORY_CALL || tipe > 0 || panggilanTelegram) {
            if (!wa && !telegram && !paketTelepon) return
            val aktifSaja = prefs.enabled && prefs.pemOn && (if (telegram) prefs.pemTelegram else if (bisnis) prefs.pemWb else if (wa) prefs.pemWa else prefs.pemTelp)
            val masuk = aktifSaja && apakahMasuk(n, extras, tipe)
            if (!masuk) {
                if (berdering && kunciAktif.contains(sbn.key)) hentikan()
                return
            }
            // Panggilan mendapat prioritas: hentikan pengulangan notifikasi pesan yang tertunda.
            hentikanUlangNotif()
            val nama = namaPemanggil(extras)
            if (berdering) {
                val sumberBaru = if (telegram) SUMBER_TELEGRAM else if (bisnis) SUMBER_WB else if (wa) SUMBER_WA else SUMBER_TELP
                if (sumber == sumberBaru && nama == namaAktif) {
                    kunciAktif.add(sbn.key)
                    return
                }
                hentikan()
            }
            val judul = (extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "").lowercase()
            val video = (wa || telegram) && (KATA_VIDEO.containsMatchIn(gabungTeks(n, extras)) || KATA_VIDEO_JUDUL.containsMatchIn(judul))
            mulai(sbn.key, if (telegram) SUMBER_TELEGRAM else if (bisnis) SUMBER_WB else if (wa) SUMBER_WA else SUMBER_TELP, video, nama)
            return
        }

        // Hanya baca notifikasi pesan yang benar-benar masuk. Notifikasi aktivitas
        // pengiriman/pesan buatan pengguna sendiri tidak boleh diumumkan.
        if (berdering || !prefs.enabled || !prefs.pemOn || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (bukanNotifikasiMasuk(sbn, n, extras)) return
        val judul = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val teks = listOf(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        ).mapNotNull { it?.trim()?.takeIf { value -> value.isNotBlank() } }.distinct().joinToString(". ")
        if (judul.isBlank() && teks.isBlank()) return

        val gabungan = (judul + " " + teks).lowercase()
        val suaraMasuk = KATA_PESAN_SUARA.containsMatchIn(gabungan)
        val pesanSeluler = !wa && !telegram && PAKET_PESAN_SELULER.containsMatchIn(pkg)
        val namaPercakapan = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()?.trim().orEmpty()
        val grup = extras.getBoolean("android.isGroupConversation", false) ||
            (namaPercakapan.isNotBlank() && !namaPercakapan.equals(judul, true))
        val diizinkan = when {
            pesanSeluler -> prefs.bacaPesanSeluler
            telegram && suaraMasuk && grup -> prefs.bacaSuaraTelegramGrup
            telegram && suaraMasuk -> prefs.bacaSuaraTelegramPribadi
            telegram && grup -> prefs.bacaChatTelegramGrup
            telegram -> prefs.bacaChatTelegramPribadi
            wa && bisnis && suaraMasuk && grup -> prefs.bacaSuaraWbGrup
            wa && bisnis && suaraMasuk -> prefs.bacaSuaraWbPribadi
            wa && !bisnis && suaraMasuk && grup -> prefs.bacaSuaraWaGrup
            wa && !bisnis && suaraMasuk -> prefs.bacaSuaraWaPribadi
            wa && bisnis && grup -> prefs.bacaChatWbGrup
            wa && bisnis -> prefs.bacaChatWbPribadi
            wa && grup -> prefs.bacaChatWaGrup
            wa -> prefs.bacaChatWaPribadi
            else -> false
        }
        if (!diizinkan) return
        val pengirimAsli = judul.ifBlank { "Pengirim tidak diketahui" }.trim()
        val pengirim = if (pengirimAsli.any { it.isDigit() } && pengirimAsli.count { it.isDigit() } >= 5) {
            KontakHelper.namaDariNomor(this, pengirimAsli, prefs.pemNamaPanggilan) ?: pengirimAsli
        } else pengirimAsli
        val grupNama = when {
            namaPercakapan.isNotBlank() -> namaPercakapan
            grup && judul.isNotBlank() -> judul
            else -> "grup tidak diketahui"
        }
        val modeIsi = when {
            pesanSeluler -> prefs.modePesanSeluler
            telegram -> prefs.modePesanTelegram
            wa && bisnis -> prefs.modePesanWb
            wa -> prefs.modePesanWa
            else -> 1
        }
        val isiPesan = if (modeIsi == 0) {
            teks.takeIf { it.isNotBlank() && !it.equals(judul, true) }.orEmpty()
        } else ""
        val pola = when {
            pesanSeluler -> prefs.pesanSebelumNamaSms to prefs.pesanSesudahNamaSms
            telegram -> "" to ""
            wa && bisnis && suaraMasuk && grup -> prefs.pesanSebelumSuaraWbGrup to prefs.pesanSesudahSuaraWbGrup
            wa && bisnis && suaraMasuk -> prefs.pesanSebelumSuaraWbPribadi to prefs.pesanSesudahSuaraWbPribadi
            wa && !bisnis && suaraMasuk && grup -> prefs.pesanSebelumSuaraWaGrup to prefs.pesanSesudahSuaraWaGrup
            wa && !bisnis && suaraMasuk -> prefs.pesanSebelumSuaraWaPribadi to prefs.pesanSesudahSuaraWaPribadi
            wa && bisnis && grup -> prefs.pesanSebelumChatWbGrup to prefs.pesanSesudahChatWbGrup
            wa && bisnis -> prefs.pesanSebelumChatWbPribadi to prefs.pesanSesudahChatWbPribadi
            wa && grup -> prefs.pesanSebelumChatWaGrup to prefs.pesanSesudahChatWaGrup
            else -> prefs.pesanSebelumChatWaPribadi to prefs.pesanSesudahChatWaPribadi
        }
        val adaPolaKhusus = pola.first.isNotBlank() || pola.second.isNotBlank()
        val pengumuman = if (adaPolaKhusus) {
            listOf(pola.first, pengirim, pola.second,
                if (grup) "di grup $grupNama" else "",
                if (suaraMasuk) "" else isiPesan)
                .filter { it.isNotBlank() }.joinToString(" ")
        } else {
            val awalanStandar = when {
                pesanSeluler -> "Pesan masuk dari"
                suaraMasuk && telegram -> "Pemberitahuan pesan suara Telegram dari"
                telegram -> "Pesan Telegram dari"
                suaraMasuk && wa && bisnis -> "Pesan suara WhatsApp Business dari"
                suaraMasuk && wa -> "Pesan suara WhatsApp dari"
                wa && bisnis -> "Pesan WhatsApp Business dari"
                wa -> "Pesan WhatsApp dari"
                else -> "Pesan masuk dari"
            }
            listOf(awalanStandar, pengirim, if (grup) "di grup $grupNama" else "",
                if (suaraMasuk) "pemberitahuan pesan suara" else isiPesan)
                .filter { it.isNotBlank() }.joinToString(" ")
        }.replace(Regex("\\s{2,}"), " ").trim().trimEnd('.', ' ')
        if (pengumuman.isBlank()) return
        val now = System.currentTimeMillis()
        val fingerprint = (sbn.key + "|" + pengumuman).lowercase()
        val prior = notifikasiDibaca[sbn.key]
        if (prior != null && prior.first == fingerprint && now - prior.second < 12_000L) return
        notifikasiDibaca[sbn.key] = fingerprint to now
        notifikasiDibaca.entries.removeAll { now - it.value.second > 60_000L }
        mulaiUlangNotif(pengumuman)
    }

    /**
     * Menolak notifikasi yang berasal dari pesan terkirim oleh pengguna sendiri.
     * Android/WhatsApp tidak selalu memberi penanda yang sama pada semua versi,
     * sehingga pemeriksaan memakai metadata MessagingStyle dan teks status pengiriman.
     * Jika metadata pengirim tidak tersedia, pemeriksaan teks tetap digunakan.
     */
    private fun bukanNotifikasiMasuk(
        sbn: StatusBarNotification,
        n: Notification,
        extras: Bundle
    ): Boolean {
        // Riwayat balasan langsung (RemoteInput) adalah teks yang dikirim pengguna.
        if (Build.VERSION.SDK_INT >= 24) {
            val riwayatBalasan = !extras.getCharSequenceArray(Notification.EXTRA_REMOTE_INPUT_HISTORY).isNullOrEmpty()

            // Pada MessagingStyle, pesan terbaru tanpa pengirim biasanya merupakan
            // pesan yang dikirim dari perangkat ini. Jangan menolak pesan masuk
            // hanya karena notifikasi juga menyimpan riwayat balasan sebelumnya.
            try {
                val raw = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                val terakhir = raw?.lastOrNull() as? Bundle
                if (terakhir == null && riwayatBalasan) return true
                if (terakhir != null) {
                    val pengirim = terakhir.getCharSequence("sender")?.toString()?.trim().orEmpty()
                    val orang = if (Build.VERSION.SDK_INT >= 28) {
                        try {
                            if (Build.VERSION.SDK_INT >= 33) {
                                terakhir.getParcelable("sender_person", android.app.Person::class.java)
                            } else {
                                @Suppress("DEPRECATION")
                                terakhir.getParcelable<android.app.Person>("sender_person")
                            }
                        } catch (_: Exception) { null }
                    } else null
                    val namaOrang = orang?.name?.toString()?.trim().orEmpty()
                    if (pengirim.isBlank() && namaOrang.isBlank()) return true
                    if (KATA_PENGIRIM_SENDIRI.matches(pengirim) || KATA_PENGIRIM_SENDIRI.matches(namaOrang)) return true
                }
            } catch (_: Exception) { }
        }

        val judul = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val isi = listOf(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString()
        ).filterNotNull().joinToString(" ")
        val status = "$judul $isi".lowercase().replace(Regex("\\s+"), " ").trim()
        if (KATA_STATUS_PENGIRIMAN.containsMatchIn(status)) return true
        if (KATA_AWAL_PENGIRIM_SENDIRI.containsMatchIn(isi.trim())) return true

        // Notifikasi SMS yang menyatakan pesan sudah terkirim bukan pesan masuk.
        if (PAKET_PESAN_SELULER.containsMatchIn(sbn.packageName ?: "") &&
            KATA_STATUS_SMS_TERKIRIM.containsMatchIn(status)) return true
        return false
    }

    private fun mulaiUlangNotif(pengumuman: String) {
        ulangNotifRunnable?.let { handler.removeCallbacks(it) }
        notifGenerasi++
        val generasi = notifGenerasi
        notifTeksAktif = pengumuman
        notifSudahDiucap = 0
        // Gunakan pengaturan melodi yang sama dengan pengumuman panggilan, juga untuk
        // SMS, chat pribadi/grup, dan notifikasi pesan suara.
        if (prefs.melodiAwalOn) {
            Melodi.putar(this, prefs.melodiAwalIdx, prefs.suara("pem").audioAttributes()) {
                if (generasi == notifGenerasi && !berdering) {
                    handler.postDelayed({ ucapUlangNotif(generasi) }, prefs.jedaMelodiAwal.toLong())
                }
            }
        } else {
            ucapUlangNotif(generasi)
        }
    }

    private fun ucapUlangNotif(generasi: Int) {
        if (ModeAcara.aktif(this)) { hentikanUlangNotif(); return }
        if (generasi != notifGenerasi || berdering || notifTeksAktif.isBlank()) return
        if (notifSudahDiucap >= prefs.notifUlangJumlah) {
            selesaiPengumumanNotif(generasi)
            return
        }
        notifSudahDiucap++
        siapkanPembicara().ucapkan(notifTeksAktif, notifSudahDiucap == 1) {
            if (generasi == notifGenerasi && !berdering && notifSudahDiucap < prefs.notifUlangJumlah) {
                val berikutnya = Runnable { ucapUlangNotif(generasi) }
                ulangNotifRunnable = berikutnya
                handler.postDelayed(berikutnya, (prefs.notifJeda * 1000).toLong())
            } else if (generasi == notifGenerasi) {
                selesaiPengumumanNotif(generasi)
            }
        }
    }

    private fun selesaiPengumumanNotif(generasi: Int) {
        if (generasi != notifGenerasi) return
        notifTeksAktif = ""
        ulangNotifRunnable = null
        if (prefs.melodiAkhirOn) {
            handler.postDelayed({
                if (generasi == notifGenerasi && !berdering && !ModeAcara.aktif(this)) {
                    Melodi.putar(this, prefs.melodiAkhirIdx, prefs.suara("pem").audioAttributes())
                }
            }, prefs.jedaMelodiAkhir.toLong())
        }
    }

    private fun hentikanUlangNotif() {
        ulangNotifRunnable?.let { handler.removeCallbacks(it) }
        ulangNotifRunnable = null
        notifGenerasi++
        notifTeksAktif = ""
        notifSudahDiucap = 0
    }

    /**
     * True hanya untuk panggilan MASUK yang sedang berdering. Urutan pemeriksaan:
     * 1. Jenis panggilan dari sistem (CallStyle): 1 = masuk, 2 = berlangsung/keluar, 3 = disaring.
     * 2. Stopwatch tampil, atau teks berlangsung/tak terjawab/selesai: bukan panggilan berdering.
     * 3. Ada tombol Jawab/Tolak: panggilan masuk. Panggilan keluar hanya punya tombol Akhiri.
     * 4. Teks bernada panggilan keluar (Memanggil, Calling, Berdering, Dialing, ...): bukan masuk.
     * 5. Teks bernada panggilan masuk, atau notifikasi layar penuh tanpa tanda keluar: masuk.
     */
    private fun apakahMasuk(n: Notification, e: Bundle, tipe: Int): Boolean {
        if (tipe > 0) return tipe == 1
        if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) return false
        val t = gabungTeks(n, e)
        if (KATA_SELESAI.containsMatchIn(t)) return false
        if (adaTombolJawab(n)) return true
        if (KATA_KELUAR.containsMatchIn(t)) return false
        if (KATA_MASUK.containsMatchIn(t)) return true
        return n.fullScreenIntent != null
    }

    private fun adaTombolJawab(n: Notification): Boolean {
        val daftar = n.actions ?: return false
        return daftar.any { a ->
            val judulTombol = a.title?.toString()?.lowercase() ?: return@any false
            KATA_TOMBOL_JAWAB.containsMatchIn(judulTombol)
        }
    }

    private fun gabungTeks(n: Notification, e: Bundle): String {
        val daftar = listOf(
            Notification.EXTRA_TEXT, Notification.EXTRA_SUB_TEXT,
            Notification.EXTRA_BIG_TEXT, Notification.EXTRA_INFO_TEXT
        ).mapNotNull { e.getCharSequence(it)?.toString() }
        return (daftar + listOfNotNull(n.tickerText?.toString())).joinToString(" ").lowercase()
    }

    @Suppress("DEPRECATION")
    private fun namaPemanggil(e: Bundle): String {
        var nama = ""
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val p = if (Build.VERSION.SDK_INT >= 33) {
                    e.getParcelable("android.callPerson", android.app.Person::class.java)
                } else {
                    e.getParcelable<android.app.Person>("android.callPerson")
                }
                nama = p?.name?.toString().orEmpty()
            } catch (ex: Exception) { }
        }
        if (nama.isBlank()) nama = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        nama = nama.trim()
        if (nama.any { it.isDigit() } && nama.count { it.isDigit() } >= 5) {
            nama = KontakHelper.namaDariNomor(this, nama, prefs.pemNamaPanggilan) ?: nama
        }
        return nama
    }

    // ---------- Pengumuman berulang ----------

    private fun siapkanPembicara(): Pembicara {
        val s = prefs.suara("pem")
        val ada = pembicara
        if (ada != null && ada.tanda == s.tanda()) return ada
        ada?.matikan()
        val baru = Pembicara(this, s)
        pembicara = baru
        return baru
    }

    private fun mulai(kunci: String, jenisSumber: Int, video: Boolean, nama: String) {
        berdering = true
        sumber = jenisSumber
        namaAktif = nama
        kunciAktif.clear()
        kunciAktif.add(kunci)
        ulang = 0
        teks = if (jenisSumber == SUMBER_TELEGRAM) {
            "Panggilan ${if (video) "video" else "suara"} Telegram dari ${nama.ifBlank { getString(R.string.nama_tidak_dikenal) }}"
        } else susun(this, prefs, jenisSumber == SUMBER_WA || jenisSumber == SUMBER_WB, video, nama, jenisSumber == SUMBER_WB)
        if (prefs.melodiAwalOn) {
            Melodi.putar(this, prefs.melodiAwalIdx, prefs.suara("pem").audioAttributes()) {
                handler.postDelayed({ if (berdering) ucapUlang() }, prefs.jedaMelodiAwal.toLong())
            }
        } else {
            ucapUlang()
        }
    }

    private fun ucapUlang() {
        if (ModeAcara.aktif(this)) { hentikan(); return }
        if (!berdering) return
        val batas = prefs.pemBatas
        if (batas > 0 && ulang >= batas) {
            hentikan()
            return
        }
        ulang++
        siapkanPembicara().ucapkan(teks, ulang == 1) {
            if (berdering) {
                handler.postDelayed(ulangRunnable, (prefs.pemJeda * 1000).toLong())
            }
        }
    }

    private fun hentikan() {
        // Jangan biarkan pengulangan pesan bersaing dengan pengumuman panggilan.
        hentikanUlangNotif()
        // Jangan mengulang melodi akhir bila beberapa notifikasi pembaruan datang berurutan.
        val memangAktif = berdering
        berdering = false
        handler.removeCallbacks(ulangRunnable)
        kunciAktif.clear()
        pembicara?.berhenti()
        if (memangAktif && prefs.melodiAkhirOn) {
            handler.postDelayed({
                if (!berdering && !ModeAcara.aktif(this)) Melodi.putar(this, prefs.melodiAkhirIdx, prefs.suara("pem").audioAttributes())
            }, prefs.jedaMelodiAkhir.toLong())
        }
    }

    // ---------- Status telepon seluler (untuk berhenti saat diangkat/ditolak) ----------

    private fun statusTelepon(state: Int) {
        if (berdering && sumber == SUMBER_TELP && state != TelephonyManager.CALL_STATE_RINGING) {
            hentikan()
        }
    }

    private fun daftarTelepon() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        lepasTelepon()
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handler.post { statusTelepon(state) }
                    }
                }
                tm.registerTelephonyCallback(mainExecutor, cb)
                telCallback = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        statusTelepon(state)
                    }
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                telListener = l
            }
        } catch (e: Exception) { }
    }

    private fun lepasTelepon() {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val cb = telCallback
            if (Build.VERSION.SDK_INT >= 31 && cb is TelephonyCallback) {
                tm.unregisterTelephonyCallback(cb)
            }
            telListener?.let {
                @Suppress("DEPRECATION")
                tm.listen(it, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) { }
        telCallback = null
        telListener = null
    }

    companion object {
        private const val SUMBER_WA = 1
        private const val SUMBER_TELP = 2
        private const val SUMBER_WB = 3
        private const val SUMBER_TELEGRAM = 4

        private val PAKET_TELEPON =
            Regex("dialer|incall|telecom|phone|oplus|coloros|oppo|miui|contacts")
        // Nada panggilan MASUK. Kata "ringing/berdering/calling/memanggil" sengaja TIDAK di sini:
        // WhatsApp dan aplikasi telepon memakainya juga untuk panggilan keluar.
        private val KATA_MASUK = Regex("incoming|panggilan masuk|masuk")
        // Nada panggilan KELUAR (kita yang menelepon).
        private val KATA_KELUAR = Regex(
            "outgoing|keluar|dialing|dialling|calling|memanggil|menelepon|menelpon|menghubungi|" +
                "connecting|reconnecting|menyambung|ringing|berdering"
        )
        // Tombol pada notifikasi panggilan masuk; panggilan keluar hanya punya tombol Akhiri.
        private val KATA_TOMBOL_JAWAB = Regex("answer|jawab|angkat|accept|terima|decline|reject|tolak")
        private val PAKET_PESAN_SELULER = Regex("messaging|mms|sms")
        private val KATA_PESAN_SUARA = Regex("pesan suara|voice message|voice note|pesan audio|audio message|voice-message")
        private val KATA_PENGIRIM_SENDIRI = Regex("(?i)\\s*(you|anda|me|saya|aku|diri sendiri)\\s*")
        private val KATA_AWAL_PENGIRIM_SENDIRI = Regex("(?i)^\\s*(you|anda|saya|aku)\\s*:")
        private val KATA_STATUS_PENGIRIMAN = Regex(
            "(?i)\\b(pesan terkirim|message sent|you sent|anda mengirim|anda telah mengirim|" +
                "pesan berhasil dikirim|berhasil dikirim|sent a message|sending message|mengirim pesan)\\b"
        )
        private val KATA_STATUS_SMS_TERKIRIM = Regex("(?i)pesan terkirim|message sent|berhasil dikirim|sent")
        private val KATA_PANGGILAN_TELEGRAM = Regex("incoming (voice |video )?call|incoming call|panggilan (suara|video) masuk|panggilan masuk")
        private val KATA_VIDEO = Regex("video")
        private val KATA_VIDEO_JUDUL = Regex("video call|videocall|panggilan video")
        private val KATA_SELESAI = Regex(
            "ongoing|berlangsung|connected|tersambung|in call|dalam panggilan|missed|" +
                "tak terjawab|tidak terjawab|terlewat|ended|berakhir|declin|ditolak|" +
                "return to call|kembali ke panggilan"
        )

        /** Nomor tanpa nama dibaca angka per angka. */
        private fun bacaNama(nama: String): String {
            if (nama.isBlank()) return ""
            if (nama.none { it.isLetter() } && nama.count { it.isDigit() } >= 5) {
                return nama.filter { it.isDigit() }.toCharArray().joinToString(" ")
            }
            return nama
        }

        /** Kalimat yang diucapkan untuk satu panggilan. Dipakai juga oleh tombol tes. */
        fun susun(ctx: Context, p: Prefs, wa: Boolean, video: Boolean, nama: String, bisnis: Boolean = false): String {
            val n = bacaNama(nama).ifEmpty { ctx.getString(R.string.nama_tidak_dikenal) }
            val sebelum: String
            val sesudah: String
            when {
                bisnis && video -> { sebelum = p.pesanSebelumWbVideo; sesudah = p.pesanSesudahWbVideo }
                bisnis -> { sebelum = p.pesanSebelumWbSuara; sesudah = p.pesanSesudahWbSuara }
                wa && video -> { sebelum = p.pesanSebelumWaVideo; sesudah = p.pesanSesudahWaVideo }
                wa -> { sebelum = p.pesanSebelumWaSuara; sesudah = p.pesanSesudahWaSuara }
                else -> { sebelum = p.pesanSebelumTelp; sesudah = p.pesanSesudahTelp }
            }
            if (sebelum.isNotBlank() || sesudah.isNotBlank()) {
                return listOf(sebelum, n, sesudah).filter { it.isNotBlank() }
                    .joinToString(" ").replace(Regex("\\s+"), " ").trim()
            }
            val jenis = when {
                bisnis && video -> "Panggilan video WhatsApp Business dari"
                bisnis -> "Panggilan suara WhatsApp Business dari"
                wa && video -> "Panggilan video WhatsApp Messenger dari"
                wa -> "Panggilan suara WhatsApp Messenger dari"
                else -> "Panggilan telepon seluler dari"
            }
            return "$jenis $n".replace(Regex("\\s+"), " ").trim()

        }
    }
}
