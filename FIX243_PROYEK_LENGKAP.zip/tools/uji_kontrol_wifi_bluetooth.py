#!/usr/bin/env python3
"""Uji regresi pemilihan sakelar dan jalur klik native/gestur (FIX141).
Port logika pemilih untuk tata letak AOSP/OEM; bukan pengganti uji APK/perangkat nyata.
"""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

WORDS = {
    "wifi": ["wi-fi", "wifi", "wi fi", "wlan", "wireless lan", "wireless network"],
    "bluetooth": ["bluetooth", "bluetooth radio", "bluetooth device"],
    "lokasi": ["location services", "use location", "location", "lokasi", "gps"],
    "hotspot": ["mobile hotspot", "wi-fi hotspot", "wifi hotspot", "hotspot", "hot spot"],
    "data_seluler": ["mobile data", "cellular data", "mobile network data", "data seluler", "data selular", "mobile_data", "mobiledata", "cellular_data"],
    "pesawat": ["airplane mode", "airplane_mode", "flight mode", "mode pesawat", "airplane", "pesawat"],
    "nfc": ["nfc", "near field communication"],
}
OTHER = {
    "wifi": ["bluetooth", "airplane", "pesawat", "mobile data", "cellular data", "data seluler", "hotspot", "nfc", "location", "lokasi", "scanning", "pemindaian", "tethering"],
    "bluetooth": ["wi-fi", "wifi", "wlan", "airplane", "pesawat", "mobile data", "cellular data", "data seluler", "hotspot", "nfc", "location", "lokasi", "scanning", "pemindaian", "tethering", "usb", "ethernet"],
    "lokasi": ["airplane", "pesawat", "mobile data", "cellular data", "data seluler", "hotspot", "nfc", "wi-fi", "wifi", "bluetooth", "scanning", "pemindaian"],
    "hotspot": ["airplane", "pesawat", "mobile data", "data seluler", "nfc", "location", "lokasi", "bluetooth", "usb", "ethernet"],
    "data_seluler": ["airplane", "pesawat", "nfc", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan"],
    "pesawat": ["mobile data", "data seluler", "data selular", "nfc", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan"],
    "nfc": ["airplane", "pesawat", "mobile data", "data seluler", "data selular", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan"],
}

def phrase(text, word):
    import re
    norm = lambda x: re.sub(r"\s+", " ", re.sub(r"[^\w-]+", " ", x.lower())).strip()
    return f" {norm(word)} " in f" {norm(text)} "

def choose(rows, kind):
    candidates = [i for i, d in enumerate(rows) if d["toggle"] and d["visible"] and d["enabled"]]
    matches = [i for i in candidates if any(phrase(rows[i]["context"], w) or w.replace("-", "").replace(" ", "") in rows[i].get("id", "") for w in WORDS[kind])]
    exact = [i for i in matches if not any(phrase(rows[i]["context"], w) for w in OTHER.get(kind, []))]
    if len(exact) == 1: return exact[0]
    if len(exact) > 1: return None
    return candidates[0] if kind in ("wifi", "bluetooth", "lokasi") and len(candidates) == 1 else None

def sw(context, *, visible=True, enabled=True, id="", toggle=True):
    return dict(context=context, visible=visible, enabled=enabled, id=id, toggle=toggle)

failed = []
def check(name, ok):
    if not ok: failed.append(name)

# Halaman khusus dan panel gabungan
check("Wi-Fi AOSP", choose([sw("Use Wi-Fi"), sw("Bluetooth")], "wifi") == 0)
check("Bluetooth AOSP", choose([sw("Use Bluetooth")], "bluetooth") == 0)
check("Wi-Fi panel gabungan", choose([sw("Mobile data"), sw("Wi-Fi, On"), sw("Airplane mode")], "wifi") == 1)
check("Bluetooth tidak salah memilih sakelar lain", choose([sw("Wi-Fi"), sw("Mobile data")], "bluetooth") is None)
check("Lokasi mengabaikan pemindaian", choose([sw("Wi-Fi scanning"), sw("Bluetooth scanning"), sw("Use location")], "lokasi") == 2)
check("Hotspot menolak tethering lain", choose([sw("Mobile hotspot"), sw("Bluetooth tethering"), sw("USB tethering")], "hotspot") == 0)
check("Data seluler", choose([sw("Wi-Fi"), sw("Mobile data"), sw("Airplane mode")], "data_seluler") == 1)
check("Mode pesawat", choose([sw("Mobile data"), sw("Airplane mode")], "pesawat") == 1)
check("NFC", choose([sw("NFC"), sw("Bluetooth")], "nfc") == 0)
check("ID sumber daya Wi-Fi", choose([sw("", id="com.android.settings:id/wifi_toggle"), sw("Bluetooth")], "wifi") == 0)
check("Kontrol System UI bertipe tombol dengan status", choose([sw("Wi-Fi On", toggle=True)], "wifi") == 0)
check("Kontrol tanpa label tidak ditebak untuk data", choose([sw("")], "data_seluler") is None)
check("Dua kontrol dengan label sama ambigu", choose([sw("Wi-Fi"), sw("Wi-Fi")], "wifi") is None)
check("Sakelar tersembunyi diabaikan", choose([sw("Wi-Fi", visible=False)], "wifi") is None)
check("Sakelar nonaktif diabaikan", choose([sw("Wi-Fi", enabled=False)], "wifi") is None)

root = Path(__file__).resolve().parents[1]
base = root / "app/src/main/java/com/novan/bateraibicara"
service = (base / "PanggilanWhatsAppAccessibilityService.kt").read_text(encoding="utf-8")
activity = (base / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
picker = (base / "PemilihSakelar.kt").read_text(encoding="utf-8")
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
xml = ET.parse(root / "app/src/main/res/xml/panggilan_whatsapp_accessibility.xml").getroot()
check("layanan menerima event konten dan klik", "typeViewClicked" in xml.attrib.get("{http://schemas.android.com/apk/res/android}accessibilityEventTypes", "") and "typeWindowContentChanged" in xml.attrib.get("{http://schemas.android.com/apk/res/android}accessibilityEventTypes", ""))
check("layanan mengambil jendela interaktif", "flagRetrieveInteractiveWindows" in xml.attrib.get("{http://schemas.android.com/apk/res/android}accessibilityFlags", ""))
check("status tak terbaca tidak dianggap OFF", "private fun statusSakelar(node: AccessibilityNodeInfo): Boolean?" in service and "return null" in service)
check("status tak terbaca tetap diverifikasi setelah aksi native", "if (sekarang == null)" in service and "KEY_PERANGKAT_MENUNGGU_VERIFIKASI" in service)
check("status diverifikasi sesudah klik", "sekarang == mau" in service and "jadwalkanPerangkat(1200L)" in service)
check("cadangan ketukan koordinat sakelar tersedia", "private fun ketukDenganGestur" in service and "dispatchGesture(gesture" in service)
check("layanan diizinkan melakukan gestur", xml.attrib.get("{http://schemas.android.com/apk/res/android}canPerformGestures") == "true")
check("gestur cadangan hanya dicoba sekali", "KEY_PERANGKAT_GESTUR_DICOBA" in service and "gesturSudahDicoba" in service)
check("aksi klik AccessibilityNodeInfo diperiksa", "current.actionList.any" in service)
check("konteks label saudara dikumpulkan", "saudara.childCount" in service)
check("semua tujuh jenis perangkat didukung", all(x in picker for x in ["wifi", "bluetooth", "lokasi", "hotspot", "data_seluler", "pesawat", "nfc"]))
check("parser bahasa Indonesia/Inggris/Arab/Jawa/Sunda", all(x in activity for x in ["matikan", "turn", "أوقف", "uripna", "hurungkeun"]))
check("pesan status memakai bahasa aktif", "BahasaAplikasi.bungkus(this)" in service)
check("versi 1.0.87 / 87", 'versionCode = 87' in gradle and 'versionName = "1.0.87"' in gradle)
for folder in ("values", "values-en"):
    strings = (root / f"app/src/main/res/{folder}/strings.xml").read_text(encoding="utf-8")
    for key in ("perintah_perangkat_otomatis", "perintah_perangkat_berhasil", "perintah_perangkat_gagal_otomatis", "perintah_perangkat_aksesibilitas"):
        check(f"{folder}: {key}", f'name="{key}"' in strings)

if failed:
    print("UJI KONTROL PERANGKAT FIX141: GAGAL")
    for item in failed: print("-", item)
    sys.exit(1)
print("UJI KONTROL PERANGKAT FIX141: LULUS")
print("Cakupan: Wi-Fi, Bluetooth, lokasi, hotspot, data seluler, mode pesawat, NFC; pemeriksaan bahasa dan versi.")
print("Catatan: uji sumber/port logika, bukan kompilasi APK atau uji fisik OEM.")
