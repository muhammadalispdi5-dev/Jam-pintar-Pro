import sys
g=open("app/src/main/java/com/novan/bateraibicara/GempaDunia.kt").read()
a=open("app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt").read()
ok=True
for n,c in [("usgs",'earthquake.usgs.gov' in g),("tanpa const",'    const val' not in g),("hook",'GempaDunia.laporan' in a)]:
    if not c: ok=False; print("GAGAL:",n)
if ok: print("OK")
