import sys
b="app/src/main/java/com/novan/bateraibicara/"
n=open(b+"NegaraLokasi.kt").read(); h=open(b+"HariLibur.kt").read(); z=open(b+"KalkulatorZakatActivity.kt").read(); p=open(b+"Prefs.kt").read()
ok=True
for k,c in [("negara",'fun kode(' in n and 'fun mataUang(' in n),("libur",'sinkronAsing' in h and 'negaraAsing' in h),("zakat",z.count('mu()')>=10),("hijri",'kriteriaHijriBawaan' in p)]:
    if not c: ok=False; print("GAGAL:",k)
if ok: print("OK")
