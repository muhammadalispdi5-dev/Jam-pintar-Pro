from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt').read_text()
id_text = (root / 'app/src/main/res/values/strings.xml').read_text()
en_text = (root / 'app/src/main/res/values-en/strings.xml').read_text()
checks = {
    'perintah suara cuaca tetap terhubung': 'PerintahSuara.Jenis.CUACA -> bacakanCuaca(' in source,
    'lokasi langsung perangkat dicari': 'ambilLokasiUntukCuaca' in source and 'requestLocationUpdates' in source,
    'GPS dan jaringan digunakan': 'LocationManager.GPS_PROVIDER' in source and 'LocationManager.NETWORK_PROVIDER' in source,
    'lokasi jadwal sholat menjadi cadangan': 'if (lokasiTersimpanValid) pp.lat' in source and 'if (lokasiTersimpanValid) pp.lon' in source,
    'permintaan cuaca HTTPS Open-Meteo': 'https://api.open-meteo.com/v1/forecast?' in source,
    'timeout layanan dibedakan': 'weather request timed out' in source and 'Permintaan data cuaca utama melewati batas waktu' in source and 'cobaCuacaCadanganWttr' in source,
    'status HTTP server dibedakan': 'HTTP_STATUS:' in source and 'status in 500..599' in source and 'status == 429' in source,
    'gangguan DNS dibedakan': 'UnknownHostException' in source and 'Nama server cuaca tidak dapat ditemukan' in source,
    'gangguan TLS dibedakan': 'SSLException' in source and 'Sambungan aman ke layanan cuaca gagal' in source,
    'gangguan soket dibedakan': 'SocketException' in source and 'Sambungan ke server cuaca terputus' in source,
    'format respons tidak disamakan dengan gangguan jaringan': 'JSONException("Missing current data")' in source and 'JSONException("Invalid temperature")' in source,
    'bahasa Indonesia petunjuk cuaca diperbarui': 'Aplikasi mencoba memakai lokasi perangkat terkini melalui GPS atau jaringan' in id_text,
    'English help updated': 'The app first tries the device current location through GPS or network' in en_text,
    'versi aplikasi 1.0.95': 'versionName = "1.0.95"' in (root / 'app/build.gradle.kts').read_text(),
}
for name, ok in checks.items(): print(('LULUS' if ok else 'GAGAL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
