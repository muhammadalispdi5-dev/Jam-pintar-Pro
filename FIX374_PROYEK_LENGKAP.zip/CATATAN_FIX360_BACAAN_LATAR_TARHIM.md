FIX360 (belum dikompilasi dengan Gradle / belum diuji di perangkat)
- BacaanLatarService (foreground mediaPlayback, ringan): bacaan Pustaka Ilmu tetap hidup saat layar mati; onPause tidak lagi menghentikan; berhenti saat selesai/halaman ditutup/maks 3 jam.
- Tafsir: hasil terakhir + kunci (kitab:surah:ayat) disimpan, dipulihkan saat halaman dibuat ulang; Hadits tidak recreate() saat layar mati (PowerManager.isInteractive).
- bisaDibungkam=false untuk semua bacaan Pustaka Ilmu dan semua Pembicara asisten (tombol volume/telungkup hanya untuk azan, pengingat, pengumuman).
- Azan terlambat dengan Tarhim: penyebab pasti BELUM terbukti. Pertahanan: (1) setAlarmClock saat izin alarm tepat waktu belum ada (Android 12-13), (2) Tarhim terlambat dilewati bila azan <20 dtk, (3) penjaga azan di layanan Tarhim memulai azan tepat waktu bila alarm sistem terlambat.
- Petunjuk dipindah ke isi_petunjuk_penggunaan_lanjutan_4 (ID 131 / EN 128) karena batas 30000 byte.
