# FIX364
Jam, menit, selisih, dan tanggal pada jawaban jam dunia ditulis dengan huruf (mis. pukul sembilan lewat tiga puluh menit malam); WIB/WITA/WIT diuraikan menjadi nama lengkap. Rekaman pengguna tidak dapat didengar/ditranskripsi di sini, jadi penyebab sebenarnya tidak terbukti. Belum dikompilasi / belum diuji di perangkat.
