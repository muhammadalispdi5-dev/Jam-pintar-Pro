#!/usr/bin/env python3
"""Cerminan Python rentangSurahDariToken (PemutarQuranService.kt) memakai pencocok nama dari uji_penafsir_quran.py."""
import sys
src=open("tools/uji_penafsir_quran.py").read().split("\nif __name__")[0]
ns={}; exec(compile(src,"u","exec"),ns)
PENGHUBUNG={"sampai","hingga","sampe","sd","to","until","through","till"}
BUANG={"putar","putarkan","mainkan","bacakan","baca","play","tolong","dong","surah","surat","sura","dari","mulai","the","of","ke","alquran","quran"}
def nomor(bag):
    sk=[t for t in bag if t not in BUANG]
    if not sk: return None
    if len(sk)==1 and sk[0].isdigit(): n=int(sk[0]); return n if 1<=n<=114 else None
    nama=[t for t in sk if not t.isdigit()]
    return ns["cocokkan_nama"](nama) if nama else None
def rentang(u):
    d=ns["Dir"](); t=ns["ekstrak_direktif"](ns["token_ucapan"](u),d)
    idx=next((i for i,x in enumerate(t) if x in PENGHUBUNG),-1)
    if idx<=0 or idx>=len(t)-1: return None
    if any(x in ("ayat","ayah","verse","aya","juz","jus","juzz") for x in t): return None
    a=nomor(t[:idx]); b=nomor(t[idx+1:])
    return (a,b) if a and b and a<b else None
kasus={"putar surah al baqarah sampai surah al an'am":(2,6),"putar surah al kafirun sampai surah al lahab":(109,111),"putar surat yasin hingga surat ash shaffat":(36,37),
 "putar surah 2 sampai surah 6":(2,6),"putar surah al fatihah sampai an nas":(1,114),"putar surah ali imran sampai an nisa":(3,4),"putar surah yasin":None,
 "putar surah al baqarah ayat 1 sampai 5":None,"putar juz 1 sampai juz 5":None,"putar surah an nas sampai al fatihah":None}
gagal=0
for u,e in kasus.items():
    r=rentang(u)
    if r!=e: gagal+=1; print("GAGAL:",u,r,e)
print("GAGAL total" if gagal else "OK")
sys.exit(1 if gagal else 0)
