import sys
w=open("app/src/main/java/com/novan/bateraibicara/WaktuDunia.kt").read()
ok=True
for n,c in [("selisih",'fun tanyaSelisih(' in w),("nama disebut",'fun namaDisebut(' in w),("tanpa kurung",'Sebagai pembanding' not in w),("batas zona",'take(4)' in w)]:
    if not c: ok=False; print("GAGAL:",n)
if ok: print("OK")
