import sys
a=open("app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt").read()
ok=True
for n,c in [("fungsi",'fun surahBerbedaDalamUcapan(' in a),("dipakai",'banyakSurah.size >= 2' in a)]:
    if not c: ok=False; print("GAGAL:",n)
if ok: print("OK")
