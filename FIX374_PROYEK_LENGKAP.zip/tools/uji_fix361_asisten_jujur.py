from pathlib import Path
j=Path(__file__).resolve().parent.parent/"app/src/main/java/com/novan/bateraibicara"
def cek(n,c): print(("OK   " if c else "GAGAL ")+n)
w=(j/"WaktuDunia.kt").read_text(); a=(j/"PerintahSuaraActivity.kt").read_text(); t=(j/"TanyaJawab.kt").read_text()
cek("varian Mekah", "makkah" in w and "mekah" in w and "meka," in w)
cek("pencocokan mirip", "selisihSatu" in w)
cek("tempat tak dikenal", "fun tempatTakDikenal" in w and "tempatTakDikenal(ucapan) != null" in a)
cek("tidakPaham", "private fun tidakPaham" in a and "tidakPaham(" in a)
cek("bantuan lebih ketat", "tanyaCara" in t)
