# FIX366
Seluruh templat dolar di WaktuDunia.kt diganti penyambungan teks, karena transkrip pengguna memuat nama variabel (nama, pembanding, kode) yang menandakan templat terbaca apa adanya; Pembicara juga sudah memiliki pembersih simbol dolar karena kasus serupa sebelumnya. Penyebab pastinya tidak terbukti. Belum dikompilasi / belum diuji di perangkat.
