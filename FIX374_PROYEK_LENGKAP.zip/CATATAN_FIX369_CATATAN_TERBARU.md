# FIX369
Pop-up ringkasan kini mengambil deskripsi singkat perbaikan terakhir dari updates/catatan_terbaru_<id|en>.txt di repositori bila rilis GitHub/JSON tidak punya catatan. Berkas itu perlu diperbarui pada tiap perbaikan (sudah diisi untuk FIX368/369). Belum dikompilasi dengan Gradle / belum diuji di perangkat.
