package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * FIX360: layanan foreground ringan agar pembacaan tafsir, hadis, dan bacaan Pustaka Ilmu tetap berjalan ketika layar mati
 * atau aplikasi ke latar. Layanan hanya menjaga proses tetap hidup; suaranya tetap dari Pembicara. Berhenti sendiri saat
 * pembacaan selesai/dihentikan, saat halaman ditutup, atau paling lama 3 jam sebagai pengaman.
 */
class BacaanLatarService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val batas = Runnable { stopSelf() }

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        buatSaluran()
        val buka = PendingIntent.getActivity(this, 9620, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, SALURAN) else Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(tr("Sedang membacakan", "Reading aloud"))
            .setContentText(tr("Pembacaan tetap berjalan saat layar mati.", "Reading continues while the screen is off."))
            .setContentIntent(buka)
            .setOngoing(true)
            .setShowWhen(false)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, b.build())
        } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        handler.removeCallbacks(batas)
        handler.postDelayed(batas, 3L * 60L * 60L * 1000L)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(batas)
        super.onDestroy()
    }

    private fun buatSaluran() {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(SALURAN, tr("Pembacaan di latar", "Background reading"), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    companion object {
        private const val SALURAN = "bacaan_latar"
        private const val NOTIF_ID = 9620

        /** Dipanggil dari halaman yang sedang tampil saat pembacaan dimulai. Gagal diam-diam bila dilarang sistem. */
        fun mulai(context: Context) {
            try {
                val i = Intent(context.applicationContext, BacaanLatarService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.applicationContext.startForegroundService(i) else context.applicationContext.startService(i)
            } catch (_: Exception) { }
        }

        fun selesai(context: Context) {
            try { context.applicationContext.stopService(Intent(context.applicationContext, BacaanLatarService::class.java)) } catch (_: Exception) { }
        }
    }
}
