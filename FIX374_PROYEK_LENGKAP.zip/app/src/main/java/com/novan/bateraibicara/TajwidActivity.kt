package com.novan.bateraibicara

import android.graphics.Typeface
import android.os.Build
import android.widget.TextView

/**
 * FIX338: Pelajaran Huruf Hijaiyah dan Tajwid, dari pemula sampai lanjutan. Dapat dibaca, dibacakan suara, dan dibuka asisten
 * dengan extra tingkat atau pelajaran.
 */
class TajwidActivity : Halaman() {
    override val judulHalaman = R.string.judul_tajwid

    private val simpan by lazy { getSharedPreferences("tajwid", MODE_PRIVATE) }
    private var pembicara: Pembicara? = null
    private var tetap = 0

    private val inggris: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun ukuran(): Float = simpan.getFloat("ukuran", 20f)

    // FIX360: bacaan tidak dihentikan saat layar mati.
    override fun onDestroy() { hentikanSuara(); super.onDestroy() }

    override fun bangun() {
        tetap = root.childCount
        val pel = intent.getIntExtra("pelajaran", -1)
        val tingkat = intent.getIntExtra("tingkat", -1)
        when {
            pel in TajwidData.daftar.indices -> halamanPelajaran(pel, intent.getBooleanExtra("baca", false))
            tingkat in 0..2 -> halamanTingkat(tingkat)
            else -> beranda()
        }
    }

    private fun bersihkan() { while (root.childCount > tetap) root.removeViewAt(tetap) }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 18f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(20), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun paragraf(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(2), 0, dp(6))
        tv.setTextIsSelectable(true)
        root.addView(tv)
    }

    private fun beranda() {
        bersihkan()
        hentikanSuara()
        info(tr("Belajar membaca Al-Qur'an dari huruf hijaiyah sampai tajwid lanjutan. Pelajaran dibagi tiga tingkat dan dapat dibacakan suara. Ini pendamping belajar; untuk bacaan yang benar tetap belajarlah langsung kepada guru (talaqqi). Anda juga dapat berkata kepada asisten: buka pelajaran tajwid, pelajaran hijaiyah pemula, atau tajwid idgham.",
            "Learn to recite the Qur'an from the hijaiyah letters to advanced tajwid. The lessons have three levels and can be read aloud. This is a study companion; for correct recitation, still learn directly from a teacher (talaqqi). You can also tell the assistant: open tajwid lessons, beginner hijaiyah lesson, or tajwid idgham."))
        for (t in 0..2) {
            val jumlah = TajwidData.daftar.count { it.tingkat == t }
            val nama = if (inggris) TajwidData.namaTingkat[t].en else TajwidData.namaTingkat[t].id
            tombol(nama + " (" + jumlah + tr(" pelajaran)", " lessons)")) { halamanTingkat(t) }
        }
        val terakhir = simpan.getInt("terakhir", -1)
        if (terakhir in TajwidData.daftar.indices) {
            val p = TajwidData.daftar[terakhir]
            tombol(tr("Lanjutkan pelajaran terakhir: ", "Continue last lesson: ") + (if (inggris) p.judul.en else p.judul.id)) { halamanPelajaran(terakhir, false) }
        }
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(36f)).apply(); toast(tr("Huruf diperbesar.", "Text enlarged.")) }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); toast(tr("Huruf diperkecil.", "Text reduced.")) }
        blokSuara("tajwid") { tr("Bismillahirrahmanirrahim. Ini contoh suara pembaca pelajaran tajwid.", "Bismillahirrahmanirrahim. This is a sample of the tajwid lesson reading voice.") }
    }

    private fun halamanTingkat(t: Int) {
        bersihkan()
        hentikanSuara()
        subjudul(if (inggris) TajwidData.namaTingkat[t].en else TajwidData.namaTingkat[t].id)
        for ((i, p) in TajwidData.daftar.withIndex()) {
            if (p.tingkat != t) continue
            val nomor = TajwidData.daftar.take(i).count { it.tingkat == t } + 1
            tombol(nomor.toString() + ". " + (if (inggris) p.judul.en else p.judul.id)) { halamanPelajaran(i, false) }
        }
        tombol(tr("Kembali ke daftar tingkat", "Back to the level list")) { beranda() }
    }

    private fun halamanPelajaran(i: Int, baca: Boolean) {
        bersihkan()
        hentikanSuara()
        val p = TajwidData.daftar[i]
        simpan.edit().putInt("terakhir", i).apply()
        val judul = if (inggris) p.judul.en else p.judul.id
        val isi = if (inggris) p.isi.en else p.isi.id
        val urut = TajwidData.daftar.take(i).count { it.tingkat == p.tingkat } + 1
        val total = TajwidData.daftar.count { it.tingkat == p.tingkat }
        subjudul(judul)
        info(tr("Pelajaran " + urut + " dari " + total + ", tingkat ", "Lesson " + urut + " of " + total + ", level ") + (p.tingkat + 1))
        paragraf(isi)
        tombol(tr("Bacakan pelajaran ini", "Read this lesson aloud")) { bacakan(judul + ". " + isi) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara(); toast(tr("Suara dihentikan.", "Audio stopped.")) }
        if (i + 1 < TajwidData.daftar.size) tombol(tr("Pelajaran berikutnya", "Next lesson")) { halamanPelajaran(i + 1, false) }
        if (i > 0) tombol(tr("Pelajaran sebelumnya", "Previous lesson")) { halamanPelajaran(i - 1, false) }
        tombol(tr("Daftar pelajaran tingkat ini", "Lesson list of this level")) { halamanTingkat(p.tingkat) }
        tombol(tr("Kembali ke daftar tingkat", "Back to the level list")) { beranda() }
        if (baca) bacakan(judul + ". " + isi)
    }

    private fun bacakan(teks: String) {
        hentikanSuara(false)
        try {
            val sp = Pembicara(applicationContext, Prefs(this).suara("tajwid"))
            sp.paksaBahasaTampilan = true
            sp.bisaDibungkam = false
            BacaanLatarService.mulai(this)
            pembicara = sp
            // Teks Arab berharakat tidak dibacakan mesin Indonesia dengan baik; hanya bagian bahasa aplikasi yang dibacakan.
            val bersih = teks.replace(Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\u08A0-\\u08FF\\uFB50-\\uFDFF\\uFE70-\\uFEFF]+"), " ").replace(Regex("\\s+"), " ")
            val potongan = bersih.split(Regex("(?<=[.!?;])\\s+")).map { it.trim() }.filter { it.isNotBlank() }
            sp.ucapkanRangkaian(potongan, 250L) { if (pembicara === sp) BacaanLatarService.selesai(applicationContext) }
        } catch (_: Exception) { toast(tr("Suara tidak dapat dimulai.", "Speech could not be started.")) }
    }

    private fun hentikanSuara(lepasLayanan: Boolean = true) {
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
        if (lepasLayanan) BacaanLatarService.selesai(this)
    }
}
