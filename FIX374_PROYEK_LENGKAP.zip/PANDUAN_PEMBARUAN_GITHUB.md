# Panduan menerbitkan pembaruan otomatis lewat GitHub (FIX291)

Pola sama dengan Apktool M: aplikasi mengambil `updates/update_<bahasa>.json?t=<waktu>` dari repositori publik, membandingkan `versionCode`, lalu mengunduh APK dan memasangnya.

## Sekali saja
1. Pastikan repositori PUBLIK dan namanya sama dengan `githubRepo` di app/build.gradle.kts (sekarang: muhammadalispdi5-dev/Jam-pintar-Bro), atau bangun dengan -PGITHUB_REPO=pemilik/repo. Cabang bernama `main`.
2. Salin folder CONTOH_REPOSITORI_PEMBARUAN (updates/ dan files/) ke akar repositori.
3. Bangun dan pasang dulu versi aplikasi yang sudah memuat fitur ini (FIX290/291). Pembaruan hanya bisa diterima oleh versi ini ke atas.
4. Tanda tangani setiap APK dengan KUNCI YANG SAMA (keystore yang sama) selamanya; bila berbeda, Android menolak pembaruan.

## Setiap rilis
1. Naikkan versionCode dan versionName di app/build.gradle.kts, bangun APK rilis bertanda tangan.
2. Ganti files/JamPintarPro.apk dengan APK baru (commit dan push).
3. Ubah updates/update_id.json dan update_en.json: versionCode (sama dengan APK), versionName, date, size, changes. Push SETELAH APK terunggah.
4. Pengguna: saklar "Periksa pembaruan otomatis" memeriksa setiap 12 jam, atau ketuk "Periksa pembaruan". Mereka mengetuk Unduh dan pasang, lalu Pasang pada konfirmasi Android.

Opsional: "apkUrl" di JSON (boleh per arsitektur, mis. {"arm64-v8a":"https://...","default":"https://..."}) bila APK ada di tempat lain, mis. GitHub Releases. Bila repositori tidak punya updates/, aplikasi memakai rilis terbaru (Releases): beri tag 1.0.90 dan lampirkan APK.

## Penomoran versi dan tag rilis (FIX304)
- Aplikasi membandingkan NOMOR BUILD (versionCode). Di GitHub Actions versionCode kini otomatis = GITHUB_RUN_NUMBER (bila lebih tinggi dari 89), sehingga sama dengan angka pada tag rilis, mis. tag V819 -> APK bernomor 819.
- Tag rilis berupa angka saja (V819) dibandingkan dengan nomor build terpasang; tag bertitik (1.0.90) dibandingkan sebagai nama versi.
- Bila memakai updates/update_id.json, isi versionCode dengan nomor yang sama dengan nomor build APK di apkUrl. APK yang nomornya tidak lebih tinggi dari yang terpasang ditolak dengan pesan "Nomor versi tidak cocok".
- APK harus ditandatangani dengan kunci yang sama dengan aplikasi terpasang (secrets keystore tetap), kalau tidak sistem menolak dan aplikasi menampilkan pesan tanda tangan.
- Pembaruan pertama dari build lama (versionCode 89) ke build ini tetap berhasil karena nomor barunya lebih tinggi.

## Catatan pembaruan otomatis (FIX369)
Pop-up ringkasan memakai deskripsi rilis GitHub atau `changes` di `updates/update_<bahasa>.json`. Bila keduanya kosong, aplikasi mengambil
`updates/catatan_terbaru_id.txt` (atau `_en.txt`) dari cabang main. Perbarui dua berkas itu (butir diawali "- ") pada setiap perbaikan baru.
