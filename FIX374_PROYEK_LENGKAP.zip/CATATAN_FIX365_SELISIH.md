# FIX365
Penyebab jawaban selisih salah: cari() memilih kata kunci terpanjang sehingga 'Indonesia' mengalahkan 'Mekkah' (jawaban memuat 3 zona Indonesia). Kini tempat non-Indonesia diutamakan; jawaban selisih diawali selisih dan arah. Belum dikompilasi / belum diuji di perangkat.
