FIX361: Mekah+varian+fuzzy, tempat tak dikenal tidak dijawab jam lokal, tidakPaham (minta ulang maks 2x), bantuanAplikasi diperketat. Belum dikompilasi/diuji.
