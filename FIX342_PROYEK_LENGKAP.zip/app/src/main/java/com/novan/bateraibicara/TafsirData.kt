package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX338: kitab tafsir. Teks diunduh per surah dari proyek terbuka spa5k/tafsir_api (lewat jsDelivr atau GitHub mentah) lalu disimpan
 * di penyimpanan aplikasi sehingga surah yang pernah dibuka dapat dibaca tanpa internet. Penguraian JSON dibuat longgar
 * (beberapa bentuk kunci) karena bentuk berkas tiap edisi belum diuji di perangkat.
 */
object TafsirData {
    class Dua(val id: String, val en: String)
    private fun tr(id: String, en: String) = Dua(id, en)

    class Kitab(val slug: String, val nama: Dua, val bahasa: String, val kunci: List<String>)

    val daftar: List<Kitab> = listOf(
        Kitab("in-tafsir-jalalayn", tr("Tafsir Jalalayn (Indonesia)", "Tafsir Jalalayn (Indonesian)"), "id", listOf("jalalayn", "jalalain", "jalalen", "jalalan")),
        Kitab("id-tafsir-as-saadi", tr("Tafsir As-Sa'di (Indonesia)", "Tafsir As-Sa'di (Indonesian)"), "id", listOf("saadi", "sa'di", "sadi", "as sa di")),
        Kitab("indonesian-mokhtasar", tr("Tafsir Al-Mukhtashar (Indonesia)", "Tafsir Al-Mukhtasar (Indonesian)"), "id", listOf("mukhtashar", "mukhtasar", "mokhtasar", "muhtasar")),
        Kitab("ar-tafsir-muyassar", tr("Tafsir Al-Muyassar (Arab)", "Tafsir Al-Muyassar (Arabic)"), "ar", listOf("muyassar", "muyasar", "muaisar")),
        Kitab("ar-tafsir-ibn-kathir", tr("Tafsir Ibnu Katsir (Arab)", "Tafsir Ibn Kathir (Arabic)"), "ar", listOf("katsir", "kathir", "katir", "kasir", "ibnu katsir", "ibn kathir")),
        Kitab("ar-tafsir-al-jalalayn", tr("Tafsir Jalalayn (Arab)", "Tafsir Jalalayn (Arabic)"), "ar", listOf("jalalayn arab")),
        Kitab("en-tafisr-ibn-kathir", tr("Tafsir Ibn Kathir (Inggris)", "Tafsir Ibn Kathir (English)"), "en", listOf("kathir inggris", "ibn kathir english")),
        Kitab("en-al-jalalayn", tr("Tafsir Jalalayn (Inggris)", "Tafsir Jalalayn (English)"), "en", listOf("jalalayn inggris", "jalalayn english"))
    )

    private val kunciAyat = listOf("ayah", "verse", "aya", "ayat", "number", "id", "ayah_number", "verse_number")
    private val kunciTeks = listOf("text", "content", "tafsir", "body", "tafseer")
    private val kunciDaftar = listOf("ayahs", "verses", "tafsir", "data", "result", "results", "ayat")

    private fun berkas(c: Context, slug: String, surah: Int): File {
        val dir = File(c.applicationContext.filesDir, "tafsir/" + slug)
        dir.mkdirs()
        return File(dir, "$surah.json")
    }

    fun tersimpan(c: Context, slug: String, surah: Int): Boolean = berkas(c, slug, surah).let { it.exists() && it.length() > 2 }

    @Volatile var galatTerakhir = ""

    private fun ambil(alamat: String): String? {
        return try {
            var u = alamat
            for (loncat in 0..4) {
                val k = URL(u).openConnection() as HttpURLConnection
                k.connectTimeout = 15000; k.readTimeout = 40000
                k.instanceFollowRedirects = true
                k.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JamPintarPro")
                k.setRequestProperty("Accept", "application/json,*/*")
                try {
                    val kode = k.responseCode
                    if (kode in 300..399) { val l = k.getHeaderField("Location"); if (l.isNullOrBlank()) { galatTerakhir = "HTTP $kode"; return null }; u = URL(URL(u), l).toString(); continue }
                    if (kode != 200) { galatTerakhir = "HTTP $kode"; return null }
                    return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } finally { k.disconnect() }
            }
            galatTerakhir = "terlalu banyak pengalihan"; null
        } catch (e: Exception) { galatTerakhir = (e.javaClass.simpleName + " " + (e.message ?: "")).take(120); null }
    }

    /** Memuat tafsir satu surah: nomor ayat ke teks. Panggil di thread latar. Null bila tidak tersimpan dan tidak dapat diunduh. */
    @Synchronized
    fun muat(c: Context, slug: String, surah: Int): Map<Int, String>? {
        val f = berkas(c, slug, surah)
        if (f.exists() && f.length() > 2) {
            val lokal = try { urai(f.readText(Charsets.UTF_8)) } catch (_: Exception) { null }
            if (lokal != null && lokal.isNotEmpty()) return lokal
            try { f.delete() } catch (_: Exception) { }
        }
        val alamat = listOf(
            "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/$slug/$surah.json",
            "https://raw.githubusercontent.com/spa5k/tafsir_api/main/tafsir/$slug/$surah.json"
        )
        for (a in alamat) {
            val teks = ambil(a) ?: continue
            val hasil = try { urai(teks) } catch (_: Exception) { null }
            if (hasil == null || hasil.isEmpty()) galatTerakhir = tr("format data tidak dikenali: ", "unrecognized data format: ").id + teks.take(80).replace("\n", " ")
            if (hasil != null && hasil.isNotEmpty()) {
                try { f.writeText(teks, Charsets.UTF_8) } catch (_: Exception) { }
                return hasil
            }
        }
        return null
    }

    private fun cariDaftar(o: Any?, kedalaman: Int): JSONArray? {
        if (o is JSONArray) return o
        if (o !is JSONObject || kedalaman > 2) return null
        for (k in kunciDaftar) { val v = o.opt(k); if (v is JSONArray) return v }
        for (k in kunciDaftar) { val v = o.opt(k); if (v is JSONObject) cariDaftar(v, kedalaman + 1)?.let { return it } }
        return null
    }

    private fun urai(teks: String): Map<Int, String>? {
        val akar: Any = try { JSONObject(teks) } catch (_: Exception) { try { JSONArray(teks) } catch (_: Exception) { return null } }
        val arr = cariDaftar(akar, 0) ?: return null
        val hasil = LinkedHashMap<Int, String>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            var nomor = 0
            for (k in kunciAyat) { val n = e.optInt(k, 0); if (n > 0) { nomor = n; break } }
            if (nomor == 0) nomor = i + 1
            var isi = ""
            for (k in kunciTeks) { val s = e.optString(k, ""); if (s.isNotBlank()) { isi = s; break } }
            if (isi.isBlank()) { val it2 = e.keys(); while (it2.hasNext()) { val kk = it2.next(); val v = e.opt(kk); if (v is String && v.length > isi.length && kk !in listOf("name", "slug", "source", "author", "language")) isi = v } }
            hasil[nomor] = isi.replace(Regex("<[^>]+>"), " ").replace(Regex("[ \\t]+"), " ").trim()
        }
        return hasil
    }

    // ---------------- FIX341: unduh seluruh kitab, hapus, dan pencarian tema ----------------
    @Volatile var batalUnduh = false

    fun sumber(slug: String): String = "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/$slug/"

    fun jumlahTersimpan(c: Context, slug: String): Int = (1..114).count { tersimpan(c, slug, it) }

    fun hapus(c: Context, slug: String) {
        try { File(c.applicationContext.filesDir, "tafsir/" + slug).deleteRecursively() } catch (_: Exception) { }
    }

    /** Mengunduh semua surah kitab (yang belum tersimpan); panggil di thread latar. Mengembalikan jumlah surah tersimpan setelahnya. */
    fun unduhSemua(c: Context, slug: String, lapor: (selesai: Int, total: Int) -> Unit): Int {
        batalUnduh = false
        galatTerakhir = ""
        var gagalBeruntun = 0
        for (putaran in 0..1) {
            for (sr in 1..114) {
                if (batalUnduh) return jumlahTersimpan(c, slug)
                if (!tersimpan(c, slug, sr)) {
                    if (muat(c, slug, sr) == null) gagalBeruntun++ else gagalBeruntun = 0
                    if (gagalBeruntun >= 4 && jumlahTersimpan(c, slug) == 0) return 0
                }
                lapor(jumlahTersimpan(c, slug), 114)
            }
            if (jumlahTersimpan(c, slug) >= 114) break
        }
        return jumlahTersimpan(c, slug)
    }

    private val kataSambung = setOf("yang", "dan", "dengan", "untuk", "dari", "pada", "dalam", "atau", "itu", "ini", "ada", "adalah", "kepada", "tentang", "mengenai", "the", "and", "of", "for", "with", "about")

    fun kataKunci(kueri: String): List<String> =
        kueri.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").split(Regex("\\s+")).filter { it.length >= 3 && it !in kataSambung }.distinct()

    /** Mencari kata kunci di tafsir yang sudah diunduh. Hasil: surah, ayat, cuplikan; semua kata lebih dulu, lalu minimal setengah kata. Thread latar. */
    fun cariTeks(c: Context, slug: String, kueri: String, batas: Int): List<Triple<Int, Int, String>> {
        val kata = kataKunci(kueri)
        if (kata.isEmpty()) return emptyList()
        val perlu = (kata.size + 1) / 2
        val semua = ArrayList<Pair<Int, Triple<Int, Int, String>>>()
        for (sr in 1..114) {
            if (!tersimpan(c, slug, sr)) continue
            val peta = try { urai(berkas(c, slug, sr).readText(Charsets.UTF_8)) } catch (_: Exception) { null } ?: continue
            for ((ay, tk) in peta) {
                if (tk.isBlank()) continue
                val rendah = tk.lowercase()
                val skor = kata.count { rendah.contains(it) }
                if (skor >= perlu) {
                    val pos = kata.map { rendah.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: 0
                    val mulai = (pos - 40).coerceAtLeast(0)
                    semua.add(skor to Triple(sr, ay, tk.substring(mulai, (mulai + 160).coerceAtMost(tk.length)).replace("\n", " ").trim()))
                }
            }
        }
        return semua.sortedWith(compareByDescending<Pair<Int, Triple<Int, Int, String>>> { it.first }.thenBy { it.second.first * 1000 + it.second.second }).take(batas).map { it.second }
    }

    /** Teks tafsir ayat [ayat]; bila kosong (tafsir menggabung beberapa ayat) dikembalikan teks ayat sebelumnya yang tidak kosong beserta nomornya. */
    fun untukAyat(peta: Map<Int, String>, ayat: Int): Pair<Int, String>? {
        val langsung = peta[ayat]
        if (!langsung.isNullOrBlank()) return ayat to langsung
        var k = ayat - 1
        while (k >= 1) { val t = peta[k]; if (!t.isNullOrBlank()) return k to t; k-- }
        return null
    }

    /** Kitab yang disebut dalam ucapan (dicocokkan dari kata kunci); null bila tidak disebut. */
    fun cariKitab(kandidat: List<String>): Int? {
        for (u in kandidat) {
            val s = u.lowercase().replace(Regex("[^a-z' ]"), " ").replace(Regex("\\s+"), " ")
            val arab = s.contains("arab")
            val inggris = s.contains("inggris") || s.contains("english")
            var terbaik: Int? = null
            for ((i, k) in daftar.withIndex()) {
                if (k.kunci.any { s.contains(it) }) {
                    if (arab && k.bahasa == "ar") return i
                    if (inggris && k.bahasa == "en") return i
                    if (terbaik == null) terbaik = i
                }
            }
            // "jalalayn" tanpa bahasa: Indonesia; Katsir tanpa bahasa: Arab sudah dipilih urutan daftar.
            if (terbaik != null) return terbaik
        }
        return null
    }
}
