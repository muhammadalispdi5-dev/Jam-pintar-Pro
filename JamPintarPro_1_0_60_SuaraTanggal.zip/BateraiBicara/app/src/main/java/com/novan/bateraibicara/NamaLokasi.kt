package com.novan.bateraibicara

import android.content.Context
import android.location.Geocoder
import java.util.Locale

/**
 * Nama lokasi yang spesifik (kelurahan/desa, kecamatan atau kota, provinsi) dari koordinat tersimpan,
 * dipakai pada info sholat berikutnya. Membutuhkan layanan geocoder perangkat dan internet; bila tidak
 * tersedia, nama lama tetap dipakai dan pencarian diulang pada kesempatan berikutnya.
 */
object NamaLokasi {
    private val umum = setOf("Lokasi GPS", "Lokasi manual")

    /** Nama bawaan seperti "Lokasi GPS" belum menyebut tempat yang sebenarnya. */
    fun belumSpesifik(nama: String): Boolean = nama.isBlank() || nama.trim() in umum

    /** Blokir: panggil dari thread latar. Null bila tidak ditemukan. */
    fun cari(context: Context, lat: Double, lon: Double): String? {
        return try {
            if (!Geocoder.isPresent()) return null
            val g = Geocoder(context.applicationContext, Locale("id", "ID"))
            @Suppress("DEPRECATION")
            val alamat = g.getFromLocation(lat, lon, 1)?.firstOrNull() ?: return null
            val bagian = listOfNotNull(alamat.subLocality, alamat.locality, alamat.subAdminArea, alamat.adminArea)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
            if (bagian.isEmpty()) null else bagian.take(4).joinToString(", ")
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Cari nama lokasi di latar belakang dan simpan bila nama sekarang masih bawaan
     * (nama yang diketik pengguna tidak pernah ditimpa). [selesai] dipanggil di thread latar.
     */
    fun perbaruiAsinkron(context: Context, pp: PrayerPrefs, selesai: ((String?) -> Unit)? = null) {
        val app = context.applicationContext
        val lat = pp.lat
        val lon = pp.lon
        Thread {
            val nama = cari(app, lat, lon)
            if (nama != null && pp.lat == lat && pp.lon == lon && belumSpesifik(pp.place)) pp.place = nama
            selesai?.invoke(nama)
        }.start()
    }

    /** Coba lagi paling sering sekali per jam, tanpa menahan pengucapan. */
    fun cobaBilaBelumSpesifik(context: Context, pp: PrayerPrefs) {
        if (!pp.locationSet || !belumSpesifik(pp.place)) return
        val sp = context.applicationContext.getSharedPreferences("nama_lokasi", Context.MODE_PRIVATE)
        val sekarang = System.currentTimeMillis()
        if (sekarang - sp.getLong("coba_terakhir", 0L) < 3_600_000L) return
        sp.edit().putLong("coba_terakhir", sekarang).apply()
        perbaruiAsinkron(context, pp)
    }
}
