package com.novan.bateraibicara

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.media.ToneGenerator
import android.media.AudioManager
import android.widget.EditText
import android.widget.TextView

/** Pengaturan kategori Nama Pemanggil. */
class PemanggilActivity : Halaman() {

    override val judulHalaman = R.string.kategori_pemanggil

    private lateinit var teksAkses: TextView
    private lateinit var teksTelepon: TextView

    override fun bangun() {
        when (kodeKelompok()) {
            "izin" -> grupIzin()
            "jenis" -> grupJenis()
            "kalimat" -> grupKalimat()
            "melodi" -> grupMelodi()
            "suara" -> grupSuara()
            "pesan" -> grupPembacaanPesan()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        saklar(getString(R.string.sw_pem_on), prefs.pemOn) { prefs.pemOn = it }
        info(getString(R.string.info_pemanggil))

        tombolKelompok("Izin dan akses notifikasi", "izin")
        tombolKelompok("Jenis panggilan dan pengulangan", "jenis")
        tombolKelompok("Pembacaan pesan dan notifikasi masuk", "pesan")
        tombolKelompok("Kalimat yang diucapkan", "kalimat")
        tombolKelompok("Melodi sebelum dan sesudah pengumuman", "melodi")
        tombolKelompok("Suara pengumuman", "suara")
    }

    private fun grupIzin() {
        judulGrup("Izin dan akses notifikasi")
        // ----- Izin -----
        bagian(getString(R.string.bagian_izin))
        teksAkses = info("")
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
        info(getString(R.string.info_setelan_terbatas))
        teksTelepon = info("")
        tombol(getString(R.string.tombol_izin_telepon)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 2)
        }
        tombol(getString(R.string.tombol_izin_kontak)) {
            // Hanya izin kontak yang dipakai (mencocokkan nomor dengan nama). Izin daftar panggilan tidak
            // pernah dipakai dan tidak dideklarasikan di manifest, jadi tidak diminta.
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 3)
        }
        saklar(getString(R.string.sw_nama_panggilan), prefs.pemNamaPanggilan) { prefs.pemNamaPanggilan = it }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

    }

    private fun grupJenis() {
        judulGrup("Jenis panggilan dan pengulangan")
        // ----- Jenis panggilan -----
        bagian(getString(R.string.bagian_jenis))
        saklar(getString(R.string.sw_pem_wa), prefs.pemWa) { prefs.pemWa = it }
        saklar(getString(R.string.sw_pem_wb), prefs.pemWb) { prefs.pemWb = it }
        saklar(getString(R.string.sw_pem_telp), prefs.pemTelp) { prefs.pemTelp = it }
        saklar(getString(R.string.sw_pem_jenis), prefs.pemJenis) { prefs.pemJenis = it }

        // ----- Pengulangan -----
        bagian(getString(R.string.bagian_ulang))
        isian(
            getString(R.string.pem_jeda), formatDetik(prefs.pemJeda),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        ) { s ->
            val v = s.replace(',', '.').toFloatOrNull()
            if (v != null && v >= 0.3f) prefs.pemJeda = v.coerceAtMost(60f)
        }
        pilihan(getString(R.string.pem_batas), larik(R.array.pem_batas), prefs.pemBatasIdx) {
            prefs.pemBatasIdx = it
        }

    }


    private fun grupPembacaanPesan() {
        judulGrup("Pembacaan pesan dan notifikasi masuk")
        info("Aktifkan hanya jenis notifikasi yang ingin dibacakan. Pilih apakah isi teks pesan ikut dibacakan atau cukup pemberitahuannya saja. Fitur ini membaca informasi yang tersedia pada notifikasi, bukan membuka percakapan. Untuk pesan suara WhatsApp, aplikasi hanya membacakan pemberitahuan pesan suara beserta nama pengirim jika tersedia; audio pesan tidak ditranskripsikan.")
        bagian("Cara membaca pesan seluler atau SMS", 17f)
        pilihan("Mode pembacaan SMS", listOf("Bacakan notifikasi beserta teks pesan", "Bacakan pemberitahuan saja tanpa isi pesan"), prefs.modePesanSeluler) { prefs.modePesanSeluler = it }
        saklar("Bacakan notifikasi pesan seluler atau SMS", prefs.bacaPesanSeluler) { prefs.bacaPesanSeluler = it }
        bagian("Pesan sebelum dan sesudah nama pengirim SMS", 17f)
        info("Tulis pesan yang akan diucapkan sebelum dan sesudah nama pengirim SMS, mengikuti pola SMS Alert Settings. Jika salah satu kolom diisi, pengumuman SMS menggunakan pola pesan ini lalu membaca isi SMS jika mode pembacaan isi pesan aktif; jika kedua kolom kosong, kalimat notifikasi SMS lama tetap digunakan. Pengaturan ini tidak mengubah pesan WhatsApp.")
        val sebelumSms = isian("Message to play before Sender Name — pesan sebelum nama pengirim SMS", prefs.pesanSebelumNamaSms, InputType.TYPE_CLASS_TEXT) { prefs.pesanSebelumNamaSms = it }
        val sesudahSms = isian("Message to play after Sender Name — pesan sesudah nama pengirim SMS", prefs.pesanSesudahNamaSms, InputType.TYPE_CLASS_TEXT) { prefs.pesanSesudahNamaSms = it }
        tombol("Tes pesan sebelum dan sesudah nama pengirim SMS") {
            prefs.pesanSebelumNamaSms = sebelumSms.text?.toString().orEmpty()
            prefs.pesanSesudahNamaSms = sesudahSms.text?.toString().orEmpty()
            val contoh = listOf(prefs.pesanSebelumNamaSms, "Ali Bima", prefs.pesanSesudahNamaSms, if (prefs.modePesanSeluler == 0) "Contoh isi pesan" else "").filter { it.isNotBlank() }.joinToString(" ")
            tesSuara("pem", contoh)
        }
        bagian("WhatsApp Messenger", 17f)
        pilihan("Mode pembacaan WhatsApp Messenger", listOf("Bacakan notifikasi beserta teks pesan", "Bacakan pemberitahuan saja tanpa isi pesan"), prefs.modePesanWa) { prefs.modePesanWa = it }
        saklar("Bacakan chat pribadi WhatsApp Messenger", prefs.bacaChatWaPribadi) { prefs.bacaChatWaPribadi = it }
        saklar("Bacakan chat grup WhatsApp Messenger", prefs.bacaChatWaGrup) { prefs.bacaChatWaGrup = it }
        saklar("Bacakan pemberitahuan pesan suara pribadi WhatsApp Messenger", prefs.bacaSuaraWaPribadi) { prefs.bacaSuaraWaPribadi = it }
        saklar("Bacakan pemberitahuan pesan suara grup WhatsApp Messenger", prefs.bacaSuaraWaGrup) { prefs.bacaSuaraWaGrup = it }
        bagian("WhatsApp Business", 17f)
        pilihan("Mode pembacaan WhatsApp Business", listOf("Bacakan notifikasi beserta teks pesan", "Bacakan pemberitahuan saja tanpa isi pesan"), prefs.modePesanWb) { prefs.modePesanWb = it }
        saklar("Bacakan chat pribadi WhatsApp Business", prefs.bacaChatWbPribadi) { prefs.bacaChatWbPribadi = it }
        saklar("Bacakan chat grup WhatsApp Business", prefs.bacaChatWbGrup) { prefs.bacaChatWbGrup = it }
        saklar("Bacakan pemberitahuan pesan suara pribadi WhatsApp Business", prefs.bacaSuaraWbPribadi) { prefs.bacaSuaraWbPribadi = it }
        saklar("Bacakan pemberitahuan pesan suara grup WhatsApp Business", prefs.bacaSuaraWbGrup) { prefs.bacaSuaraWbGrup = it }
        bagian("Pengulangan notifikasi pesan", 17f)
        info("Pengaturan pengulangan ini hanya berlaku untuk notifikasi pesan, chat, dan pemberitahuan pesan suara. Pengulangan panggilan masuk diatur terpisah pada menu Jenis panggilan dan pengulangan.")
        pilihan("Jumlah pembacaan setiap notifikasi", listOf("1 kali", "2 kali", "3 kali", "5 kali"), prefs.notifUlangIdx) { prefs.notifUlangIdx = it }
        isian("Jeda antar pembacaan notifikasi dalam detik", formatDetik(prefs.notifJeda), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL) { v ->
            v.replace(',', '.').toFloatOrNull()?.let { if (it >= 1f) prefs.notifJeda = it.coerceAtMost(60f) }
        }
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
    }

    private fun grupKalimat() {
        judulGrup("Kalimat yang diucapkan")
        // ----- Kalimat yang diucapkan -----
        bagian(getString(R.string.bagian_kalimat))
        info(getString(R.string.info_kalimat))
        bagian("Pesan sebelum dan sesudah nama pemanggil", 17f)
        info("Tulis pesan opsional yang ingin diucapkan tepat sebelum dan sesudah nama pemanggil, mengikuti pola Call Alert Settings. Jika salah satu kolom diisi, pola pesan ini dipakai untuk pengumuman nama pemanggil; jika kedua kolom kosong, kalimat panggilan yang sudah ada tetap digunakan. Pengaturan ini berlaku untuk jenis panggilan yang dibacakan dan terpisah dari SMS.")
        val sebelumPemanggil = isian("Message to play before Caller Name — pesan sebelum nama pemanggil", prefs.pesanSebelumNamaPemanggil, InputType.TYPE_CLASS_TEXT) { prefs.pesanSebelumNamaPemanggil = it }
        val sesudahPemanggil = isian("Message to play after Caller Name — pesan sesudah nama pemanggil", prefs.pesanSesudahNamaPemanggil, InputType.TYPE_CLASS_TEXT) { prefs.pesanSesudahNamaPemanggil = it }
        tombol("Tes pesan sebelum dan sesudah nama pemanggil") {
            prefs.pesanSebelumNamaPemanggil = sebelumPemanggil.text?.toString().orEmpty()
            prefs.pesanSesudahNamaPemanggil = sesudahPemanggil.text?.toString().orEmpty()
            val contoh = listOf(prefs.pesanSebelumNamaPemanggil, getString(R.string.nama_contoh), prefs.pesanSesudahNamaPemanggil).filter { it.isNotBlank() }.joinToString(" ")
            tesSuara("pem", contoh.ifBlank { "Ali Bima" })
        }

        bagian("Kalimat panggilan masuk", 17f)
        info("Kalimat di bagian ini khusus untuk panggilan masuk. Pengulangan panggilan diatur pada menu Jenis panggilan dan pengulangan, terpisah dari pengulangan notifikasi pesan.")
        val fWaSuara = isian(getString(R.string.kalimat_wa_suara), prefs.pemKalimatWaSuara, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWaSuara = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wa_suara))) { sisipkanNama(fWaSuara) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wa_suara))) { sisipkanToken(fWaSuara, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wa_suara))) { tesSuara("pem", CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh))) }
        val fWaVideo = isian(getString(R.string.kalimat_wa_video), prefs.pemKalimatWaVideo, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWaVideo = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wa_video))) { sisipkanNama(fWaVideo) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wa_video))) { sisipkanToken(fWaVideo, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wa_video))) { tesSuara("pem", CallerListener.susun(this, prefs, true, true, getString(R.string.nama_contoh))) }
        val fTelp = isian(getString(R.string.kalimat_telp), prefs.pemKalimatTelp, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatTelp = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_telp))) { sisipkanNama(fTelp) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_telp))) { sisipkanToken(fTelp, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_telp))) { tesSuara("pem", CallerListener.susun(this, prefs, false, false, getString(R.string.nama_contoh))) }
        val fWbSuara = isian(getString(R.string.kalimat_wb_suara), prefs.pemKalimatWbSuara, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWbSuara = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wb_suara))) { sisipkanNama(fWbSuara) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wb_suara))) { sisipkanToken(fWbSuara, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wb_suara))) { tesSuara("pem", CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh), true)) }
        val fWbVideo = isian(getString(R.string.kalimat_wb_video), prefs.pemKalimatWbVideo, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWbVideo = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wb_video))) { sisipkanNama(fWbVideo) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wb_video))) { sisipkanToken(fWbVideo, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wb_video))) { tesSuara("pem", CallerListener.susun(this, prefs, true, true, getString(R.string.nama_contoh), true)) }

        bagian("Kalimat notifikasi pesan masuk", 17f)
        info("Pengaturan kalimat notifikasi ini berdiri sendiri dan tidak mengubah kalimat panggilan masuk. Setiap tombol tes akan mengucapkan contoh dengan pola notifikasi yang sedang diedit, menggunakan nama contoh Ali Bima.")
        info("Token yang tersedia: {nama} untuk nama atau nomor pengirim, {grup} untuk nama grup, {pesan} untuk isi teks yang tersedia, dan {jenis} untuk jenis pesan. Jika nomor belum tersimpan, nomor tetap dibacakan. Untuk pemberitahuan pesan suara, aplikasi hanya membaca notifikasi, bukan mentranskripsikan audio.")
        aturKalimatPesan("Pesan seluler atau SMS", prefs.kalPesanSeluler) { prefs.kalPesanSeluler = it }
        aturKalimatPesan("Chat pribadi WhatsApp Messenger", prefs.kalChatWaPribadi) { prefs.kalChatWaPribadi = it }
        aturKalimatPesan("Chat grup WhatsApp Messenger", prefs.kalChatWaGrup) { prefs.kalChatWaGrup = it }
        aturKalimatPesan("Pesan suara pribadi WhatsApp Messenger", prefs.kalSuaraWaPribadi) { prefs.kalSuaraWaPribadi = it }
        aturKalimatPesan("Pesan suara grup WhatsApp Messenger", prefs.kalSuaraWaGrup) { prefs.kalSuaraWaGrup = it }
        aturKalimatPesan("Chat pribadi WhatsApp Business", prefs.kalChatWbPribadi) { prefs.kalChatWbPribadi = it }
        aturKalimatPesan("Chat grup WhatsApp Business", prefs.kalChatWbGrup) { prefs.kalChatWbGrup = it }
        aturKalimatPesan("Pesan suara pribadi WhatsApp Business", prefs.kalSuaraWbPribadi) { prefs.kalSuaraWbPribadi = it }
        aturKalimatPesan("Pesan suara grup WhatsApp Business", prefs.kalSuaraWbGrup) { prefs.kalSuaraWbGrup = it }

    }

    private fun aturKalimatPesan(label: String, nilai: String, simpan: (String) -> Unit) {
        val field = isian(label, nilai, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) { simpan(it) }
        tombol("Sisipkan token nama pada $label") { sisipkanToken(field, "{nama}") }
        tombol("Sisipkan token nama grup pada $label") { sisipkanToken(field, "{grup}") }
        tombol("Sisipkan token isi pesan pada $label") { sisipkanToken(field, "{pesan}") }
        tombol("Tes kalimat $label") {
            val labelNormal = label.lowercase()
            val jenisContoh = when {
                labelNormal.contains("suara") -> "pesan suara"
                labelNormal.contains("sms") || labelNormal.contains("seluler") -> "pesan seluler"
                else -> "chat"
            }
            val sample = field.text?.toString().orEmpty()
                .replace("{nama}", "Ali Bima")
                .replace("{grup}", "Keluarga")
                .replace("{pesan}", "Contoh isi pesan")
                .replace("{jenis}", jenisContoh)
            simpan(field.text?.toString().orEmpty())
            // Ucapkan kalimat yang diedit apa adanya setelah token diisi, tanpa awalan "Contoh kalimat untuk".
            tesSuara("pem", sample)
        }
    }

    private fun grupMelodi() {
        judulGrup("Melodi sebelum dan sesudah pengumuman")
        // ----- Melodi sebelum/sesudah pengumuman -----
        bagian(getString(R.string.bagian_melodi))
        info(getString(R.string.info_melodi))
        saklar(getString(R.string.sw_melodi_awal), prefs.melodiAwalOn) { prefs.melodiAwalOn = it }
        isian(getString(R.string.jeda_melodi_awal), prefs.jedaMelodiAwal.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAwal = v }
        }
        saklar(getString(R.string.sw_melodi_akhir), prefs.melodiAkhirOn) { prefs.melodiAkhirOn = it }
        isian(getString(R.string.jeda_melodi_akhir), prefs.jedaMelodiAkhir.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAkhir = v }
        }
        pilihan(getString(R.string.melodi_awal_pilih), larik(R.array.jam_melodi), prefs.melodiAwalIdx) {
            prefs.melodiAwalIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_awal)) { Melodi.putar(this, prefs.melodiAwalIdx, prefs.suara("pem").audioAttributes()) }
        pilihan(getString(R.string.melodi_akhir_pilih), larik(R.array.jam_melodi), prefs.melodiAkhirIdx) {
            prefs.melodiAkhirIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_akhir)) { Melodi.putar(this, prefs.melodiAkhirIdx, prefs.suara("pem").audioAttributes()) }
        tombol("Tes nada singkat") { Melodi.bunyikan(this, 180) }

    }

    private fun grupSuara() {
        judulGrup("Suara pengumuman")
        // ----- Suara -----
        // Tombol tes tiap kalimat diletakkan langsung di bawah kolom kalimat terkait.
        blokSuara("pem") {
            CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::teksAkses.isInitialized) teksAkses.text = getString(
            if (aksesNotifikasiAktif()) R.string.akses_notif_aktif else R.string.akses_notif_mati
        )
        if (::teksTelepon.isInitialized) teksTelepon.text = getString(
            if (izinTelepon()) R.string.izin_telepon_aktif else R.string.izin_telepon_mati
        )
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, hasil: IntArray) {
        super.onRequestPermissionsResult(code, perms, hasil)
        if (code == 2 && izinTelepon()) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, CallerListener::class.java))
            } catch (e: Exception) { }
        }
        onResume()
    }

    private fun izinTelepon() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun aksesNotifikasiAktif(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun bukaAksesNotifikasi() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            bukaInfoApp()
        }
    }

    private fun sisipkanNama(field: EditText) = sisipkanToken(field, "{nama}")

    private fun sisipkanToken(field: EditText, token: String) {
        val posisi = field.selectionStart.coerceAtLeast(0).coerceAtMost(field.text.length)
        field.text.insert(posisi, token)
        field.requestFocus()
    }

    private fun formatDetik(v: Float) = if (v % 1f == 0f) v.toInt().toString() else v.toString()
}
