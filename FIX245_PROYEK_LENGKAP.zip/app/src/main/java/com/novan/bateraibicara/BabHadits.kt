package com.novan.bateraibicara

/**
 * FIX244: pencarian bab (bagian/kitab) hadits berdasarkan tema, misalnya shalat, thaharah, zakat, puasa, atau jual beli.
 * Nama bab pada data hadits bisa berbahasa Indonesia, Inggris, atau Arab dengan ejaan yang bervariasi, sehingga setiap tema
 * dipetakan ke kata-kata padanannya (alias untuk kata yang diketik pengguna, istilah untuk kata yang dicari pada nama bab).
 * Murni logika Kotlin (tanpa Android) agar dapat diuji dengan kotlinc.
 */
object BabHadits {

    class Tema(val id: String, val en: String, val alias: List<String>, val istilah: List<String>)

    private fun tema(id: String, en: String, alias: String, istilah: String) =
        Tema(id, en, alias.split(",").map { normal(it) }.filter { it.isNotEmpty() }, istilah.split(" ").map { normal(it) }.filter { it.isNotEmpty() })

    private val kataBantu = setOf("bab", "kitab", "tentang", "hadits", "hadis", "hadith", "book", "of", "the", "chapter", "dan", "and", "yang", "tentangnya", "about", "on", "for", "mengenai", "seputar")

    /** Huruf Arab disederhanakan, tanda baca dan harakat dibuang, "al-" Arab dilepas agar kata bab bisa cocok. */
    fun normal(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val c = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ة' -> 'ه'
                'ى' -> 'ي'
                '\'', '’', '‘', '`', 'ʿ', 'ʾ', 'ʼ' -> continue
                else -> ch
            }
            if (c in 'ً'..'ٟ' || c == 'ٰ' || c == 'ـ') continue
            sb.append(if (c.isLetterOrDigit()) c else ' ')
        }
        return sb.toString().split(" ").filter { it.isNotEmpty() }
            .joinToString(" ") { if (it.length > 3 && it.startsWith("ال")) it.substring(2) else it }
    }

    val daftar: List<Tema> = listOf(
        tema("Thaharah (Bersuci)", "Purification (Taharah)", "thaharah,thoharoh,taharah,toharoh,thaharoh,bersuci,kesucian,purification,purity,tharah",
            "thaharah thoharoh taharah toharoh thaharoh bersuci wudhu wudu mandi haid tayammum ghusl istinja ablution ablutions bathing menstrual menstruation purification purity najis nifas الطهاره الوضوء الغسل الحيض التيمم"),
        tema("Wudhu", "Ablution (Wudu)", "wudhu,wudu,ablution,ablutions,berwudhu", "wudhu wudu ablution ablutions الوضوء"),
        tema("Shalat", "Prayer (Salat)", "shalat,sholat,salat,solat,salah,sembahyang,prayer,prayers,sholah,shalah",
            "shalat sholat salat solat salah prayer prayers adzan azan iqamah masjid mosque mosques jumat jumah friday witir tahajud tahajjud gerhana eclipse istisqa sujud rukuk ruku imam jamaah congregation khauf sahwi tarawih qiyam الصلاه الاذان الجمعه الوتر التهجد المساجد الكسوف الاستسقاء"),
        tema("Jenazah", "Funerals (Janazah)", "jenazah,janazah,janaiz,funeral,funerals,kematian,kubur,kafan,burial",
            "jenazah janazah janaiz janaaiz funeral funerals kematian mati death kafan kubur burial الجنائز"),
        tema("Zakat dan Sedekah", "Zakat and Charity", "zakat,zakah,zakaat,sedekah,shadaqah,sadaqah,infak,infaq,charity",
            "zakat zakah zakaat sedekah shadaqah sadaqah infak infaq charity almsgiving الزكاه الصدقه"),
        tema("Puasa dan Ramadhan", "Fasting and Ramadan", "puasa,shaum,shiyam,siyam,saum,sawm,fasting,ramadhan,ramadan,itikaf",
            "puasa shaum shiyam siyam saum sawm fasting ramadhan ramadan itikaf seclusion qadar tarawih qiyam الصوم الصيام اعتكاف"),
        tema("Haji dan Umrah", "Hajj and Umrah", "haji,hajj,umrah,umroh,manasik,pilgrimage",
            "haji hajj umrah umroh manasik pilgrimage الحج العمره"),
        tema("Jual Beli dan Muamalah", "Trade and Transactions", "jual beli,jual,perdagangan,dagang,muamalah,muamalat,buyu,sales,trade,riba,utang,hutang,sewa",
            "jual perdagangan dagang muamalah muamalat buyu sales trade trading transaction riba sewa menyewa ijarah utang hutang debt debts gadai mortgage pinjam lending syirkah partnership hibah gift wakalah agency hawalah pertanian muzaraah البيوع الاجاره"),
        tema("Nikah dan Talak", "Marriage and Divorce", "nikah,pernikahan,menikah,kawin,perkawinan,marriage,wedlock,talak,thalaq,cerai,perceraian,divorce",
            "nikah pernikahan menikah kawin perkawinan marriage wedlock talak thalaq cerai perceraian divorce iddah nafkah maintenance mahar dower lian khulu النكاح الطلاق"),
        tema("Iman dan Tauhid", "Faith and Tawhid", "iman,imaan,akidah,aqidah,tauhid,belief,faith,takdir,qadar,islam",
            "iman imaan akidah aqidah tauhid belief faith monotheism qadar takdir fate destiny ihsan islam الايمان التوحيد القدر"),
        tema("Ilmu", "Knowledge", "ilmu,pengetahuan,knowledge,belajar,learning,ulama",
            "ilmu pengetahuan knowledge belajar learning ulama العلم"),
        tema("Adab dan Akhlak", "Manners and Character", "adab,akhlak,akhlaq,etika,manners,etiquette,character,silaturahmi,silaturrahim,birr",
            "adab akhlak akhlaq etika manners etiquette character kebajikan birr berbakti silaturahmi silaturrahim izin permission salam greeting الادب البر"),
        tema("Doa dan Dzikir", "Supplication and Remembrance", "doa,dzikir,zikir,dhikr,invocation,invocations,supplication,supplications,dua,istighfar,taubat,tobat",
            "doa dua dzikir zikir dhikr invocation invocations supplication supplications wirid istighfar tobat taubat repentance remembrance الدعوات الدعاء الذكر التوبه"),
        tema("Al-Qur'an dan Tafsir", "Qur'an and Interpretation", "alquran,quran,al quran,tafsir,qurani,interpretation",
            "quran alquran tafsir interpretation recitation qiraah virtues القران التفسير"),
        tema("Makanan dan Minuman", "Food and Drink", "makanan,minuman,makan,minum,food,foods,drink,drinks,eating",
            "makanan minuman makan minum food foods drink drinks eating hunting buruan sembelihan slaughtering الاطعمه الاشربه الصيد"),
        tema("Kurban dan Aqiqah", "Sacrifice and Aqiqah", "kurban,qurban,aqiqah,udhiyah,adhahi,sacrifice,sacrifices",
            "kurban qurban aqiqah aqiqa udhiyah adhahi sacrifice sacrifices sacrificial الاضاحي العقيقه"),
        tema("Pakaian dan Perhiasan", "Clothing and Adornment", "pakaian,busana,perhiasan,dress,clothing,clothes,adornment,jewelry",
            "pakaian busana perhiasan dress clothing clothes adornment jewelry libas اللباس"),
        tema("Jihad dan Peperangan", "Jihad and Expeditions", "jihad,perang,peperangan,maghazi,expeditions,battles,ghazwah",
            "jihad perang peperangan maghazi expeditions battles ghazwah ghazwat siyar الجهاد المغازي"),
        tema("Sahabat dan Para Nabi", "Companions and Prophets", "sahabat,manaqib,keutamaan sahabat,para nabi,nabi,sirah,prophets,companions",
            "sahabat manaqib keutamaan nabi prophets companions virtues sirah kenabian المناقب الانبياء الصحابه"),
        tema("Kepemimpinan dan Hukum", "Leadership and Judgments", "kepemimpinan,pemimpin,pemerintahan,hukum,hudud,hakim,peradilan,judgments,government,rulers,leadership,qisas,diyat",
            "kepemimpinan pemimpin pemerintahan hukum hudud hakim peradilan judgments government rulers leadership qisas diyat qadha ahkam imarah khilafah الامارة الاحكام الحدود"),
        tema("Fitnah dan Akhirat", "Tribulations and the Hereafter", "fitnah,kiamat,akhir zaman,akhirat,surga,neraka,jannah,paradise,hell,zuhud,riqaq,tribulations,resurrection",
            "fitnah kiamat akhirat surga neraka jannah paradise hell fire zuhud riqaq tribulations resurrection hour hearts melunakkan الفتن الجنه الرقاق"),
        tema("Wasiat dan Waris", "Wills and Inheritance", "wasiat,waris,warisan,faraid,faraidh,inheritance,wills,bequests",
            "wasiat waris warisan faraid faraidh inheritance wills will bequests الوصايا الفرائض"),
        tema("Sumpah dan Nazar", "Oaths and Vows", "sumpah,nazar,nadzar,kaffarah,oaths,vows,expiation",
            "sumpah nazar nadzar kaffarah kafarat oaths vows expiation الايمان النذور"),
        tema("Pengobatan dan Kesehatan", "Medicine and Health", "pengobatan,obat,kesehatan,sakit,medicine,patients,thibb,tibb,ruqyah,health",
            "pengobatan obat kesehatan sakit penyakit medicine patients illness thibb tibb ruqyah الطب المرضي"),
        tema("Sunnah dan Bid'ah", "Sunnah and Innovation", "sunnah,sunah,bidah,bid ah,itisham,adherence",
            "sunnah sunah bidah itisham berpegang adherence innovation الاعتصام السنه"),
    )

    /** Temukan tema yang cocok dengan frasa pencarian utuh (judul tema atau salah satu alias). */
    fun temaDariKueri(kueri: String): Tema? {
        val q = normal(kueri)
        if (q.isEmpty()) return null
        return daftar.firstOrNull { normal(it.id) == q || normal(it.en) == q || q in it.alias }
    }

    private fun alternatif(token: String): List<String> {
        val cocok = daftar.filter { token in it.alias || token == normal(it.id) }
        return if (cocok.isEmpty()) listOf(token) else (cocok.flatMap { it.istilah } + token).distinct()
    }

    /** Kata (awalan kata) pada nama bab yang diawali dengan salah satu istilah. */
    private fun adaAwalanKata(namaNormal: String, istilah: String): Boolean = (" " + namaNormal).contains(" " + istilah)

    /**
     * Saring nama bab menurut pencarian. Frasa yang sama dengan tema memakai seluruh istilah tema itu.
     * Selain itu setiap kata harus cocok (DAN); bila tidak ada hasil, cukup salah satu kata (ATAU).
     * Mengembalikan nomor bab sesuai urutan semula.
     */
    fun saring(nama: Map<Int, String>, kueri: String): List<Int> {
        val q = normal(kueri)
        if (q.isEmpty()) return nama.keys.toList()
        val namaNormal = nama.mapValues { normal(it.value) }
        val frasa = temaDariKueri(kueri)
        if (frasa != null) {
            val hasil = namaNormal.filter { (_, n) -> frasa.istilah.any { adaAwalanKata(n, it) } }.keys.toList()
            if (hasil.isNotEmpty()) return hasil
        }
        val token = q.split(" ").filter { it !in kataBantu }.ifEmpty { q.split(" ") }
        val kelompok = token.map { alternatif(it) }
        fun cocokToken(n: String, alt: List<String>) = alt.any { adaAwalanKata(n, it) }
        val semua = namaNormal.filter { (_, n) -> kelompok.all { cocokToken(n, it) } }.keys.toList()
        if (semua.isNotEmpty()) return semua
        return namaNormal.filter { (_, n) -> kelompok.any { cocokToken(n, it) } }.keys.toList()
    }
}
