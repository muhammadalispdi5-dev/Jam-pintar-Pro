#!/usr/bin/env python3
"""Pemeriksaan statis untuk sumber Khatam dan XML sebelum kompilasi Android."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
def require(ok, message):
    if not ok:
        errors.append(message)

src = ROOT / 'app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt'
if not src.is_file():
    errors.append('KhatamActivity.kt tidak ditemukan')
else:
    code = src.read_text(encoding='utf-8')
    for name in ('bukaAyatTersimpan', 'tandaiPosisi', 'pengaturanTarget', 'tampilkanStatistik', 'pengaturanPengingat', 'pengaturanAksesibilitas', 'tampilkanRiwayat', 'dialogBelumAdaTeks'):
        require(re.search(r'\bfun\s+' + re.escape(name) + r'\s*\(', code) is not None,
                f'Fungsi {name} tidak ditemukan di KhatamActivity.kt')
    for suspicious in ('lyuFWGJIhtbNFyIjf8tlw', 'FlcaQsM5DqPsX4EWzY1oslp2xmHnVzyKShCg', 'nm03PnLsspsBvx8djMuWkWT22MwVbUkgxEbcCyP4vx8mR7Xl1G98IcKqKA'):
        require(suspicious not in code, f'Teks acak mencurigakan ditemukan: {suspicious}')
    require('"$number. $englishName — $arabicName ($verseCount $verseLabel)"' in code,
            'Pembentukan label daftar surah tidak sesuai dengan versi perbaikan')

for rel in ('app/src/main/res/values/strings.xml', 'app/src/main/res/values-en/strings.xml'):
    path = ROOT / rel
    try:
        tree = ET.parse(path)
        keys = {el.get('name'): (el.text or '') for el in tree.getroot().findall('string')}
        for key in ('khatam_menu', 'khatam_judul'):
            require(key in keys, f'{key} tidak ada pada {rel}')
        raw = path.read_text(encoding='utf-8')
        require(re.search(r'\\u(?![0-9a-fA-F]{4})', raw) is None,
                f'Urutan escape Unicode tidak lengkap ditemukan di {rel}')
    except (ET.ParseError, OSError) as exc:
        errors.append(f'XML tidak dapat dibaca ({rel}): {exc}')

gradle = (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8')
require('versionCode = 69' in gradle and 'versionName = "1.0.69"' in gradle,
        'Versi harus tetap 1.0.69 / versionCode 69')

if errors:
    print('PEMERIKSAAN KHATAM FIX25: GAGAL')
    for err in errors:
        print('- ' + err)
    sys.exit(1)
print('PEMERIKSAAN KHATAM FIX25: LULUS')
print('- Fungsi menu yang dilaporkan ada di sumber')
print('- XML bahasa valid dan escape Unicode tidak lengkap tidak ditemukan')
print('- Versi tetap 1.0.69 / versionCode 69')
print('- Pemeriksaan ini statis, bukan kompilasi Gradle penuh')
