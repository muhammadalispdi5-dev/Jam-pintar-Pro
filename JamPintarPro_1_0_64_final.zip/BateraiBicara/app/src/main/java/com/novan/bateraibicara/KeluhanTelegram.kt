package com.novan.bateraibicara

import android.content.Context
import android.os.Build
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/**
 * Mengirim keluhan/saran pengguna ke pengembang lewat bot Telegram (satu arah: pengguna ke pengembang).
 * Token bot dan ID obrolan diisi saat build (rahasia GitHub Actions); kosong berarti fitur belum aktif.
 */
object KeluhanTelegram {
    @Volatile private var terakhirKirim = 0L

    fun terkonfigurasi(): Boolean =
        BuildConfig.TELEGRAM_BOT_TOKEN.isNotEmpty() && BuildConfig.TELEGRAM_CHAT_ID.isNotEmpty()

    /** Selang waktu minimum antar pengiriman agar tidak terkirim berulang tanpa sengaja. */
    fun sisaJedaDetik(): Int {
        val sisa = 30_000L - (System.currentTimeMillis() - terakhirKirim)
        return if (sisa <= 0) 0 else ((sisa + 999) / 1000).toInt()
    }

    /** Penanda acak per pemasangan agar pesan dari pengguna yang sama bisa dikenali tanpa data pribadi. */
    private fun idPengguna(c: Context): String {
        val sp = c.applicationContext.getSharedPreferences("panduan_aplikasi", Context.MODE_PRIVATE)
        var id = sp.getString("id_pengguna", null)
        if (id == null) {
            id = UUID.randomUUID().toString().take(8)
            sp.edit().putString("id_pengguna", id).apply()
        }
        return id
    }

    fun susun(c: Context, kategori: String, nama: String, kontak: String, pesan: String, sertakanInfo: Boolean): String {
        val sb = StringBuilder()
        sb.append("[").append(kategori).append("] Jam Pintar Pro ")
            .append(UpdateManager.namaVersi(c)).append('\n')
        if (nama.isNotEmpty()) sb.append("Nama: ").append(nama).append('\n')
        if (kontak.isNotEmpty()) sb.append("Kontak balasan: ").append(kontak).append('\n')
        if (sertakanInfo) {
            sb.append("Perangkat: ").append(PerangkatIzin.namaPerangkat())
                .append(", Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        }
        sb.append("ID pengguna: ").append(idPengguna(c)).append("\n\n").append(pesan.trim())
        return sb.toString().take(4000)
    }

    /** Mengirim pesan. Memblokir: panggil dari thread latar. True bila Telegram menerimanya. */
    fun kirim(teks: String): Boolean {
        if (!terkonfigurasi()) return false
        return try {
            val conn = URL("https://api.telegram.org/bot" + BuildConfig.TELEGRAM_BOT_TOKEN + "/sendMessage")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            val badan = "chat_id=" + URLEncoder.encode(BuildConfig.TELEGRAM_CHAT_ID, "UTF-8") +
                "&text=" + URLEncoder.encode(teks, "UTF-8") + "&disable_web_page_preview=true"
            conn.outputStream.use { it.write(badan.toByteArray(Charsets.UTF_8)) }
            val ok = conn.responseCode == 200
            conn.disconnect()
            if (ok) terakhirKirim = System.currentTimeMillis()
            ok
        } catch (_: Exception) {
            false
        }
    }
}
