package com.novan.bateraibicara

/**
 * Pengaturan milik pengembang. Isi nilai di bawah ini lalu bangun ulang aplikasi.
 * Nilai yang dibiarkan kosong membuat fitur terkait otomatis tidak tampil/nonaktif.
 * Lihat PANDUAN_PEMBARUAN_DAN_KELUHAN.txt di folder proyek untuk contoh dan langkah lengkap.
 */
object AppKonfigurasi {
    /**
     * Alamat HTTPS berkas JSON info versi terbaru, mis.
     * "https://raw.githubusercontent.com/AKUN/REPO/main/version.json".
     * Kosong = pemeriksaan pembaruan nonaktif.
     */
    val URL_INFO_UPDATE: String = ""

    /** Nomor WhatsApp pengembang format internasional tanpa tanda plus, mis. "6281234567890". */
    val NOMOR_WHATSAPP: String = ""

    /** Alamat email penerima keluhan, mis. "pengembang@contoh.com". */
    val EMAIL_PENGEMBANG: String = ""

    /** Tautan Telegram pengembang atau grup, mis. "https://t.me/namapengguna". */
    val LINK_TELEGRAM: String = ""
}
