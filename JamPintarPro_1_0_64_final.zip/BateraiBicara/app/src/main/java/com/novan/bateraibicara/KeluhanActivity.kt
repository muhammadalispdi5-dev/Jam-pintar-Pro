package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText

/**
 * Layar hubungi pengembang. Pesan dapat dikirim:
 *  - langsung lewat bot Telegram pengembang (tanpa membuka aplikasi lain), bila token bot diatur saat build;
 *  - lewat WhatsApp, Telegram (tautan), atau email, bila nilainya diisi di AppKonfigurasi.
 * Tombol kanal yang belum diatur tidak ditampilkan.
 */
class KeluhanActivity : Halaman() {

    override val judulHalaman = R.string.kategori_keluhan

    private var kategori = 0
    private var kontak = ""
    private var pesan = ""
    private var sertakanInfo = true
    private var tombolLangsung: Button? = null
    private var kolomPesan: EditText? = null

    private fun daftarKategori() = listOf(
        getString(R.string.keluhan_kat_keluhan), getString(R.string.keluhan_kat_saran), getString(R.string.keluhan_kat_masalah)
    )

    override fun bangun() {
        val adaBot = KeluhanTelegram.terkonfigurasi()
        val adaWa = AppKonfigurasi.NOMOR_WHATSAPP.isNotBlank()
        val adaEmail = AppKonfigurasi.EMAIL_PENGEMBANG.isNotBlank()
        val adaTelegram = AppKonfigurasi.LINK_TELEGRAM.startsWith("https://")

        info(getString(R.string.info_keluhan))
        if (!adaBot && !adaWa && !adaEmail && !adaTelegram) {
            info(getString(R.string.keluhan_belum_dikonfigurasi))
            return
        }
        pilihan(getString(R.string.label_jenis_pesan), daftarKategori(), 0) { kategori = it }
        if (adaBot) {
            isian(getString(R.string.keluhan_kontak), "", InputType.TYPE_CLASS_TEXT) { kontak = it.trim() }
        }
        kolomPesan = isian(
            getString(R.string.label_isi_pesan), "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        ) { pesan = it }.also {
            it.minLines = 5
            it.gravity = Gravity.TOP
        }
        saklar(getString(R.string.sw_sertakan_info), true) { sertakanInfo = it }
        info(getString(R.string.info_sertakan_info))
        if (adaBot) info(getString(R.string.keluhan_info_bot))

        if (adaBot) tombolLangsung = tombol(getString(R.string.tombol_kirim_langsung)) { kirimLangsung() }
        if (adaWa) tombol(getString(R.string.tombol_kirim_wa)) { kirimWhatsApp() }
        if (adaTelegram) tombol(getString(R.string.tombol_kirim_telegram)) { kirimTelegramLink() }
        if (adaEmail) tombol(getString(R.string.tombol_kirim_email)) { kirimEmail() }
    }

    private fun labelKategori(): String = daftarKategori()[kategori.coerceIn(0, 2)]

    /** Memeriksa isi pesan; true bila boleh dikirim. */
    private fun pesanValid(): Boolean {
        if (pesan.trim().length < 10) {
            toast(R.string.keluhan_terlalu_pendek)
            return false
        }
        return true
    }

    private fun teksPesan(): String = KeluhanTelegram.susun(this, labelKategori(), "", kontak, pesan, sertakanInfo)

    private fun kirimLangsung() {
        if (!pesanValid()) return
        val jeda = KeluhanTelegram.sisaJedaDetik()
        if (jeda > 0) {
            toast(getString(R.string.keluhan_tunggu, jeda))
            return
        }
        val teks = teksPesan()
        tombolLangsung?.isEnabled = false
        Thread {
            val ok = KeluhanTelegram.kirim(teks)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                tombolLangsung?.isEnabled = true
                if (ok) {
                    kolomPesan?.setText("")
                    toast(R.string.keluhan_terkirim)
                } else {
                    toast(R.string.keluhan_gagal)
                }
            }
        }.start()
    }

    private fun kirimWhatsApp() {
        if (!pesanValid()) return
        val nomor = AppKonfigurasi.NOMOR_WHATSAPP.filter { it.isDigit() }
        val uri = Uri.parse("https://wa.me/" + nomor + "?text=" + Uri.encode(teksPesan()))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { toast(R.string.keluhan_aplikasi_tidak_ada) }
    }

    private fun kirimTelegramLink() {
        if (!pesanValid()) return
        // Tautan Telegram tidak dapat membawa isi pesan, jadi pesan disalin lebih dulu untuk ditempel.
        try {
            val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cb.setPrimaryClip(ClipData.newPlainText("keluhan", teksPesan()))
            toast(R.string.keluhan_disalin)
        } catch (_: Exception) { }
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppKonfigurasi.LINK_TELEGRAM))) } catch (_: Exception) { toast(R.string.keluhan_aplikasi_tidak_ada) }
    }

    private fun kirimEmail() {
        if (!pesanValid()) return
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(AppKonfigurasi.EMAIL_PENGEMBANG))
            .putExtra(Intent.EXTRA_SUBJECT, getString(R.string.keluhan_subjek_email, labelKategori()))
            .putExtra(Intent.EXTRA_TEXT, teksPesan())
        try { startActivity(i) } catch (_: Exception) { toast(R.string.keluhan_aplikasi_tidak_ada) }
    }
}
