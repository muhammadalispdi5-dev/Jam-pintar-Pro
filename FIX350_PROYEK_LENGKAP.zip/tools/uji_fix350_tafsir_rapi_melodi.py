B="app/src/main/java/com/novan/bateraibicara/"
a=open(B+"TafsirActivity.kt").read(); m=open(B+"Melodi.kt").read(); b=open(B+"BatteryTalkService.kt").read(); g=open("app/build.gradle.kts").read()
def cek(n,k): print(("ok " if k else "GAGAL ")+n)
cek("urutan tafsir",a.index("1. Cari berdasarkan")<a.index("2. Cari berdasarkan tema")<a.index("Hasil tafsir")<a.index("3. Unduhan kitab"))
cek("melodi DND",m.count("patuhDnd")>=6 and b.count("patuhDnd = 1")>=5)
cek("versi",'versionCode = 92' in g and '1.0.92' in g)
