package com.novan.bateraibicara

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Membaca notifikasi panggilan MASUK (WhatsApp, WhatsApp Bisnis, & aplikasi telepon) lalu mengucapkan
 * nama pemanggil berulang-ulang sampai panggilan dijawab, ditolak, atau berhenti berdering.
 * Panggilan KELUAR (yang kita lakukan sendiri), panggilan yang sedang berlangsung, dan panggilan tak
 * terjawab tidak pernah diumumkan.
 * Dijalankan sistem secara otomatis (termasuk setelah HP dihidupkan ulang) selama
 * "Akses notifikasi" diizinkan.
 */
class CallerListener : NotificationListenerService() {


    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var pembicara: Pembicara? = null

    private var berdering = false
    private var sumber = SUMBER_WA
    private var teks = ""
    private var ulang = 0
    private val kunciAktif = HashSet<String>()
    private var namaAktif = ""
    private val notifikasiDibaca = HashMap<String, Pair<String, Long>>()

    private var telCallback: Any? = null
    private var telListener: PhoneStateListener? = null

    private val ulangRunnable = Runnable { ucapUlang() }
    /** FIX279: pengaman; pengumuman panggilan tidak pernah berlanjut lebih dari 150 detik meski akhir dering tidak terdeteksi. */
    private val batasDeringRunnable = Runnable { if (berdering) hentikan() }
    private val modeAcaraReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
            if (ModeAcara.aktif(this@CallerListener)) { hentikan(); hentikanUlangNotif() }
        }
    }
    private var notifTeksAktif = ""
    private var notifSudahDiucap = 0
    private var notifGenerasi = 0
    // FIX74: true setelah pengumuman panggilan dibungkam dengan menelungkupkan HP (tanpa melodi akhir, tanpa ulang).
    private var dibungkam = false
    private var ulangNotifRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        val filter = android.content.IntentFilter("com.novan.jambicarapro.MODE_ACARA_DIAKTIFKAN")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(modeAcaraReceiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(modeAcaraReceiver, filter)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (prefs.enabled && prefs.pemOn) siapkanPembicara()
        daftarTelepon()
        // Pulihkan hanya panggilan yang masih aktif saat listener tersambung kembali.
        // Jangan membacakan ulang pesan lama yang kebetulan masih berada di panel notifikasi.
        try {
            activeNotifications?.forEach { sbn ->
                val n = sbn.notification ?: return@forEach
                val e = n.extras ?: return@forEach
                val pkg = sbn.packageName.orEmpty()
                val tipe = if (e.containsKey("android.callType")) e.getInt("android.callType") else -1
                val wa = pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
                val paketTelepon = PAKET_TELEPON.containsMatchIn(pkg)
                if (n.category == Notification.CATEGORY_CALL || tipe > 0 ||
                    ((wa || paketTelepon) && (adaTombolJawab(n) || n.fullScreenIntent != null))) {
                    proses(sbn)
                }
            }
        } catch (_: Exception) { }
    }

    override fun onListenerDisconnected() {
        hentikan()
        lepasTelepon()
        // FIX68: sebagian HP (Xiaomi, OPPO, Vivo, Samsung, dan lain-lain) memutus listener notifikasi saat aplikasi
        // dimatikan sistem atau setelah pembaruan. Minta sistem menyambungkannya kembali agar pengumuman tidak berhenti.
        try { NotificationListenerService.requestRebind(android.content.ComponentName(this, CallerListener::class.java)) } catch (_: Exception) { }
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        try { unregisterReceiver(modeAcaraReceiver) } catch (_: Exception) { }
        hentikan()
        lepasTelepon()
        pembicara?.matikan()
        pembicara = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Izin status telepon mungkin baru diberikan ketika listener notifikasi sudah
        // tersambung. Coba daftarkan callback saat notifikasi berikutnya tiba.
        if (telCallback == null && telListener == null &&
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            daftarTelepon()
        }
        try { proses(sbn) } catch (e: Exception) { }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null || !berdering) return
        if (kunciAktif.remove(sbn.key) && kunciAktif.isEmpty()) hentikan()
    }

    // ---------- Deteksi status bisu percakapan ----------

    /**
     * Memeriksa kanal percakapan yang dikelola Android, bukan menebak dari isi pesan.
     * Pada Android 11+, kanal percakapan dapat mewakili chat pribadi atau grup tertentu.
     * Kanal yang bisu (prioritas rendah dan tanpa suara) tidak diumumkan.
     * Jika sistem/aplikasi tidak menyediakan kanal percakapan khusus, hasilnya false.
     */
    private fun percakapanDibisukan(sbn: StatusBarNotification): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        return try {
            val ranking = NotificationListenerService.Ranking()
            if (!currentRanking.getRanking(sbn.key, ranking)) return false
            val kanal = ranking.channel ?: return false
            val idPercakapan = kanal.conversationId
            if (idPercakapan.isNullOrBlank()) return false
            val prioritasRendah = kanal.importance == NotificationManager.IMPORTANCE_LOW ||
                kanal.importance == NotificationManager.IMPORTANCE_MIN ||
                kanal.importance == NotificationManager.IMPORTANCE_NONE
            val tanpaSuara = kanal.sound == null
            prioritasRendah && tanpaSuara
        } catch (_: Exception) {
            false
        }
    }

    // ---------- Deteksi panggilan ----------

    // ---------- Deteksi panggilan dan pembacaan pesan ----------

    private fun proses(sbn: StatusBarNotification) {
        if (ModeAcara.aktif(this)) { if (berdering) hentikan(); hentikanUlangNotif(); return }
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val bisnis = pkg == "com.whatsapp.w4b"
        val wa = pkg == "com.whatsapp" || bisnis
        val paketTelepon = PAKET_TELEPON.containsMatchIn(pkg)
        val kategoriLain = kategoriNotifikasiAplikasi(pkg)
        val aplikasiKhususDipilih = kategoriLain == null && prefs.aplikasiNotifKhusus.contains(pkg)
        // Beberapa aplikasi mengganti kategori notifikasi ketika panggilan dijawab/berakhir.
        // Periksa juga pembaruan teks dari kunci panggilan aktif agar pengulangan segera berhenti.
        if (berdering && kunciAktif.contains(sbn.key) &&
            KATA_SELESAI.containsMatchIn(gabungTeks(n, extras))) {
            hentikan()
            return
        }
        // Hormati status bisu pada kanal percakapan Android (chat pribadi/grup) bila
        // sistem mengeksposnya. Ini mencakup teks dan pesan suara, serta notifikasi
        // panggilan WhatsApp yang terkait kanal percakapan tersebut.
        if ((wa || PAKET_PESAN_SELULER.containsMatchIn(pkg)) && percakapanDibisukan(sbn)) return
        val tipe = if (extras.containsKey("android.callType")) extras.getInt("android.callType") else -1

        // Jangan hanya mengandalkan CATEGORY_CALL / android.callType: sejumlah aplikasi
        // telepon OEM tidak mengisi keduanya secara konsisten. Gunakan juga aksi Jawab/Tolak
        // atau full-screen intent dengan teks panggilan sebagai penanda cadangan.
        val aksiPanggilan = adaTombolJawab(n)
        val teksPanggilan = KATA_TANDA_PANGGILAN.containsMatchIn(gabungTeks(n, extras)) ||
            KATA_VIDEO_JUDUL.containsMatchIn(extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty())
        val gayaPanggilan = n.category == Notification.CATEGORY_CALL || tipe > 0
        val panggilanCadangan = (wa || paketTelepon) &&
            (aksiPanggilan || (n.fullScreenIntent != null && teksPanggilan))
        val notifikasiPanggilan = gayaPanggilan || panggilanCadangan
        if (notifikasiPanggilan) {
            // CallStyle Android boleh berasal dari aplikasi telepon OEM yang nama paketnya
            // tidak dikenal. Untuk paket lain, izinkan hanya notifikasi CallStyle yang jelas.
            val sumberTidakDikenalDenganCallStyle = !wa && !paketTelepon && gayaPanggilan &&
                (aksiPanggilan || n.fullScreenIntent != null)
            if (!wa && !paketTelepon && !sumberTidakDikenalDenganCallStyle) return
            val aktifSaja = prefs.enabled && prefs.pemOn && (if (bisnis) prefs.pemWb else if (wa) prefs.pemWa else prefs.pemTelp)
            val masuk = aktifSaja && apakahMasuk(n, extras, tipe)
            if (!masuk) {
                if (berdering && kunciAktif.contains(sbn.key)) hentikan()
                return
            }
            // Panggilan mendapat prioritas: hentikan pengulangan notifikasi pesan yang tertunda.
            hentikanUlangNotif()
            val nama = namaPemanggil(extras)
            if (berdering) {
                val sumberBaru = if (bisnis) SUMBER_WB else if (wa) SUMBER_WA else SUMBER_TELP
                if (sumber == sumberBaru && nama == namaAktif) {
                    kunciAktif.add(sbn.key)
                    return
                }
                hentikan()
            }
            val judul = (extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "").lowercase()
            val video = wa && (KATA_VIDEO.containsMatchIn(gabungTeks(n, extras)) || KATA_VIDEO_JUDUL.containsMatchIn(judul))
            mulai(sbn.key, if (bisnis) SUMBER_WB else if (wa) SUMBER_WA else SUMBER_TELP, video, nama)
            return
        }

        // Hanya baca notifikasi pesan yang benar-benar masuk. Notifikasi aktivitas
        // pengiriman/pesan buatan pengguna sendiri tidak boleh diumumkan.
        if (berdering || !prefs.enabled || !prefs.pemOn || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        // Filter pesan keluar hanya untuk kanal pesan yang formatnya memang dipahami.
        // Notifikasi layanan/email lain tidak boleh dibuang hanya karena teksnya kebetulan
        // memuat kata seperti "sent" atau "terkirim".
        // FIX90: notifikasi WhatsApp yang bukan pesan (progres kirim media, cadangan, layanan latar) tidak pernah diumumkan.
        if (wa && bukanNotifikasiPesan(n, extras)) return
        // FIX90: hanya pesan MASUK yang diumumkan. Pesan buatan sendiri, balasan lewat notifikasi, dan pesan ke diri
        // sendiri tidak dibacakan, baik untuk WhatsApp Messenger, WhatsApp Business, maupun aplikasi SMS.
        if ((wa || PAKET_PESAN_SELULER.containsMatchIn(pkg)) && bukanNotifikasiMasuk(sbn, extras)) return
        val judul = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val teks = isiPesanNotifikasi(extras)
        if (judul.isBlank() && teks.isBlank()) return

        val gabungan = (judul + " " + teks).lowercase()
        val suaraMasuk = KATA_PESAN_SUARA.containsMatchIn(gabungan)
        val pesanSeluler = !wa && PAKET_PESAN_SELULER.containsMatchIn(pkg)
        val namaPercakapan = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()?.trim().orEmpty()
        val grup = extras.getBoolean("android.isGroupConversation", false) ||
            (namaPercakapan.isNotBlank() && !namaPercakapan.equals(judul, true))
        val diizinkan = when {
            pesanSeluler -> prefs.bacaPesanSeluler
            wa && bisnis && suaraMasuk && grup -> prefs.bacaSuaraWbGrup
            wa && bisnis && suaraMasuk -> prefs.bacaSuaraWbPribadi
            wa && !bisnis && suaraMasuk && grup -> prefs.bacaSuaraWaGrup
            wa && !bisnis && suaraMasuk -> prefs.bacaSuaraWaPribadi
            wa && bisnis && grup -> prefs.bacaChatWbGrup
            wa && bisnis -> prefs.bacaChatWbPribadi
            wa && grup -> prefs.bacaChatWaGrup
            wa -> prefs.bacaChatWaPribadi
            kategoriLain == KATEGORI_EMAIL -> prefs.bacaNotifEmail
            kategoriLain == KATEGORI_GOJEK -> prefs.bacaNotifGojek
            kategoriLain == KATEGORI_GRAB -> prefs.bacaNotifGrab
            kategoriLain == KATEGORI_INDRIVE -> prefs.bacaNotifInDrive
            kategoriLain == KATEGORI_MAXIM -> prefs.bacaNotifMaxim
            aplikasiKhususDipilih -> true
            else -> false
        }
        if (!diizinkan) return

        // Notifikasi aplikasi lain diumumkan dengan nama aplikasi dan isi yang tersedia.
        // Tidak mengasumsikan format khusus dari penyedia aplikasi; judul/teks hanya dibaca
        // sejauh yang disediakan oleh Android pada notifikasi tersebut.
        if (kategoriLain != null || aplikasiKhususDipilih) {
            val judulLain = bersihkanSimbolNotif(judul).takeIf { it.isNotBlank() }
            val isiLain = bersihkanSimbolNotif(teks).takeIf { it.isNotBlank() && !it.equals(judulLain ?: "", true) }
            val namaAplikasi = if (kategoriLain != null) namaKategoriAplikasi(kategoriLain, prefs.bahasaPemanggil) else namaAplikasiTerpasang(pkg)
            val labelNotifikasi = if (prefs.bahasaPemanggil == 1) ("" + (namaAplikasi) + " notification") else ("Notifikasi " + (namaAplikasi))
            val pengumumanLain = listOf(labelNotifikasi, judulLain, isiLain)
                .filter { !it.isNullOrBlank() }.joinToString(". ")
                .replace(Regex("\\s{2,}"), " ").trim().trimEnd('.', ' ')
            if (pengumumanLain.isBlank() || prefs.notifUlangJumlah <= 0) return
            val nowLain = System.currentTimeMillis()
            val fingerprintLain = (sbn.key + "|app|" + pengumumanLain).lowercase()
            val priorLain = notifikasiDibaca[sbn.key]
            if (priorLain != null && priorLain.first == fingerprintLain && nowLain - priorLain.second < 24 * 60 * 60_000L) return
            notifikasiDibaca[sbn.key] = fingerprintLain to nowLain
            notifikasiDibaca.entries.removeAll { nowLain - it.value.second > 24 * 60 * 60_000L }
            mulaiUlangNotif(pengumumanLain, "lain")
            return
        }
        // Pada notifikasi grup, judul biasanya nama grup, bukan pengirim pesan terakhir.
        // Ambil nama pengirim dari MessagingStyle bila tersedia agar kalimat tidak keliru.
        val judulPengirim = if (grup) namaPengirimPesan(extras).ifBlank { judul } else judul
        val pengirimAsli = judulPengirim.ifBlank { namaPengirimTidakDikenal(prefs.bahasaPemanggil) }.trim()
        val pengirimMentah = if (pengirimAsli.any { it.isDigit() } && pengirimAsli.count { it.isDigit() } >= 5) {
            KontakHelper.namaDariNomor(this, pengirimAsli, prefs.pemNamaPanggilan) ?: pengirimAsli
        } else pengirimAsli
        val pengirim = bersihkanSimbolNotif(pengirimMentah).ifBlank { namaPengirimTidakDikenal(prefs.bahasaPemanggil) }
        // Simpan cuplikan pesan masuk secara lokal agar perintah suara dapat mencari pesan terbaru
        // dari kontak tertentu (misalnya Ali Bima). Cache dibatasi 50 pesan dan 7 hari.
        if (!suaraMasuk) {
            val isiUntukRiwayat = bersihkanSimbolNotif(teks).takeIf { it.isNotBlank() && !it.equals(judul, true) }.orEmpty()
            if (isiUntukRiwayat.isNotBlank()) RiwayatPesanSuara.simpan(this, pengirim, isiUntukRiwayat, pkg)
        }
        val grupNama = bersihkanSimbolNotif(when {
            namaPercakapan.isNotBlank() -> namaPercakapan
            grup && judul.isNotBlank() -> judul
            else -> namaGrupTidakDikenal(prefs.bahasaPemanggil)
        }).ifBlank { namaGrupTidakDikenal(prefs.bahasaPemanggil) }
        val modeIsi = when {
            pesanSeluler -> prefs.modePesanSeluler
            wa && bisnis -> prefs.modePesanWb
            wa -> prefs.modePesanWa
            else -> 1
        }
        val isiPesan = if (modeIsi == 0) {
            bersihkanSimbolNotif(teks).takeIf { it.isNotBlank() && !it.equals(judul, true) }.orEmpty()
        } else ""
        val pola = when {
            pesanSeluler -> prefs.pesanSebelumNamaSms to prefs.pesanSesudahNamaSms
            wa && bisnis && suaraMasuk && grup -> prefs.pesanSebelumSuaraWbGrup to prefs.pesanSesudahSuaraWbGrup
            wa && bisnis && suaraMasuk -> prefs.pesanSebelumSuaraWbPribadi to prefs.pesanSesudahSuaraWbPribadi
            wa && !bisnis && suaraMasuk && grup -> prefs.pesanSebelumSuaraWaGrup to prefs.pesanSesudahSuaraWaGrup
            wa && !bisnis && suaraMasuk -> prefs.pesanSebelumSuaraWaPribadi to prefs.pesanSesudahSuaraWaPribadi
            wa && bisnis && grup -> prefs.pesanSebelumChatWbGrup to prefs.pesanSesudahChatWbGrup
            wa && bisnis -> prefs.pesanSebelumChatWbPribadi to prefs.pesanSesudahChatWbPribadi
            wa && grup -> prefs.pesanSebelumChatWaGrup to prefs.pesanSesudahChatWaGrup
            else -> prefs.pesanSebelumChatWaPribadi to prefs.pesanSesudahChatWaPribadi
        }
        val adaPolaKhusus = pola.first.isNotBlank() || pola.second.isNotBlank()
        val pengumuman = if (adaPolaKhusus) {
            listOf(pola.first, pengirim, pola.second,
                if (grup) keteranganGrupPesan(prefs.bahasaPemanggil, grupNama) else "",
                if (suaraMasuk) "" else isiPesan)
                .filter { it.isNotBlank() }.joinToString(" ")
        } else {
            // Gunakan template notifikasi yang tersimpan di Prefs. Sebelumnya properti
            // kalPesanSeluler/kalChat*/kalSuara* tersedia, tetapi tidak pernah dipakai oleh
            // listener; akibatnya susunan pesan bisa berbeda dari pengaturan tersimpan.
            val template = when {
                pesanSeluler -> prefs.kalPesanSeluler
                wa && bisnis && suaraMasuk && grup -> prefs.kalSuaraWbGrup
                wa && bisnis && suaraMasuk -> prefs.kalSuaraWbPribadi
                wa && !bisnis && suaraMasuk && grup -> prefs.kalSuaraWaGrup
                wa && !bisnis && suaraMasuk -> prefs.kalSuaraWaPribadi
                wa && bisnis && grup -> prefs.kalChatWbGrup
                wa && bisnis -> prefs.kalChatWbPribadi
                wa && grup -> prefs.kalChatWaGrup
                else -> prefs.kalChatWaPribadi
            }
            val jenis = when {
                pesanSeluler -> when (prefs.bahasaPemanggil) { 1 -> "text message"; 2 -> "رسالة نصية"; 3 -> "pesen teks"; 4 -> "pesen téks"; else -> "pesan teks" }
                suaraMasuk -> when (prefs.bahasaPemanggil) { 1 -> "voice message"; 2 -> "رسالة صوتية"; 3 -> "pesen swara"; 4 -> "pesen sora"; else -> "pesan suara" }
                else -> when (prefs.bahasaPemanggil) { 1 -> "message"; 2 -> "رسالة"; 3 -> "pesen"; 4 -> "pesen"; else -> "pesan" }
            }
            renderTemplatePesan(template, pengirim, if (grup) grupNama else "", if (suaraMasuk) "" else isiPesan, jenis)
        }.replace(Regex("\\s{2,}"), " ").replace(Regex("\\s+([,.!?])")) { m -> m.groupValues[1] }.trim().trimEnd('.', ' ')
        if (pengumuman.isBlank()) return
        if (prefs.notifUlangJumlah <= 0) return
        val now = System.currentTimeMillis()
        // Ambil waktu pesan terbaru dari MessagingStyle jika WhatsApp menyediakannya.
        // Dengan demikian, dua pesan identik yang benar-benar baru tetap dapat dibaca,
        // sementara pembaruan ulang atas notifikasi pesan yang sama tidak dibacakan lagi.
        val waktuPesan = try {
            if (Build.VERSION.SDK_INT >= 24) {
                val daftarPesan = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                val pesanTerakhir = daftarPesan?.lastOrNull() as? Bundle
                pesanTerakhir?.getLong("time", 0L)?.takeIf { it > 0L } ?: 0L
            } else 0L
        } catch (_: Exception) { 0L }
        // Jika WhatsApp menyediakan waktu pesan MessagingStyle, jadikan waktu pesan
        // sebagai identitas utama. Judul/teks notifikasi dapat berubah berkali-kali
        // saat masih belum dibuka; perubahan itu bukan pesan baru dan tidak boleh
        // memulai ulang hitungan pembacaan. Jika waktu tidak tersedia, gunakan teks.
        val fingerprint = if (waktuPesan > 0L) {
            (sbn.key + "|pesan|" + waktuPesan).lowercase()
        } else {
            (sbn.key + "|teks|" + pengumuman).lowercase()
        }
        val prior = notifikasiDibaca[sbn.key]
        // Cegah pembaruan notifikasi yang sama mengulang pengumuman. Pesan baru dengan
        // waktu pesan berbeda tetap diumumkan sesuai jumlah dan jeda pilihan pengguna.
        if (prior != null && prior.first == fingerprint && now - prior.second < 24 * 60 * 60_000L) return
        notifikasiDibaca[sbn.key] = fingerprint to now
        notifikasiDibaca.entries.removeAll { now - it.value.second > 24 * 60 * 60_000L }
        mulaiUlangNotif(pengumuman, if (pesanSeluler) "pesan_seluler" else if (bisnis) "pesan_wb" else "pesan_wa")
    }

    @Suppress("DEPRECATION")
    private fun namaAplikasiTerpasang(pkg: String): String {
        return try {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getApplicationInfo(pkg, android.content.pm.PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                packageManager.getApplicationInfo(pkg, 0)
            }
            packageManager.getApplicationLabel(info).toString().trim().ifBlank { pkg }
        } catch (_: Exception) { pkg.substringAfterLast('.') }
    }

    private fun kategoriNotifikasiAplikasi(pkg: String): String? = KategoriNotifApp.kategori(pkg)

    private fun namaKategoriAplikasi(kategori: String, bahasa: Int): String = when (kategori) {
        KATEGORI_EMAIL -> if (bahasa == 1) "email" else "email"
        KATEGORI_GOJEK -> "Gojek"
        KATEGORI_GRAB -> "Grab"
        KATEGORI_INDRIVE -> "inDrive"
        KATEGORI_MAXIM -> "Maxim"
        else -> if (bahasa == 1) "app" else "aplikasi"
    }

    private fun isiPesanNotifikasi(extras: Bundle): String {
        // MessagingStyle memberi teks pesan terbaru secara terstruktur. Utamakan ini
        // agar ringkasan beberapa pesan tidak dibacakan sebagai satu pesan yang panjang.
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                val daftar = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                val terakhir = daftar?.lastOrNull() as? Bundle
                val teksTerakhir = terakhir?.getCharSequence("text")?.toString()?.trim().orEmpty()
                if (teksTerakhir.isNotBlank()) return teksTerakhir
            } catch (_: Exception) { }
        }
        // Pada notifikasi biasa, pilih satu sumber teks saja; jangan menggabungkan
        // EXTRA_TEXT dan EXTRA_BIG_TEXT karena keduanya kerap berisi teks yang sama
        // atau ringkasan percakapan yang berulang.
        return listOf(
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        ).firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()
    }

    private fun namaPengirimPesan(extras: Bundle): String {
        if (Build.VERSION.SDK_INT < 24) return ""
        return try {
            val daftar = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
            val terakhir = daftar?.lastOrNull() as? Bundle ?: return ""
            val nama = if (Build.VERSION.SDK_INT >= 28) {
                val orang = if (Build.VERSION.SDK_INT >= 33) {
                    terakhir.getParcelable("sender_person", android.app.Person::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    terakhir.getParcelable<android.app.Person>("sender_person")
                }
                orang?.name?.toString().orEmpty()
            } else ""
            nama.ifBlank { terakhir.getCharSequence("sender")?.toString().orEmpty() }.trim()
        } catch (_: Exception) { "" }
    }

    // ---------- Arah pesan: masuk atau keluar (FIX90) ----------

    /** Arah sebuah notifikasi pesan. TIDAK_PASTI hanya muncul bila aplikasi tidak memberi metadata pengirim sama sekali. */
    private enum class ArahPesan { MASUK, KELUAR, TIDAK_PASTI }

    /** Membaca objek Person (Android 9+) dari Bundle; null bila tidak ada atau versi Android terlalu lama. */
    private fun ambilOrang(bundle: Bundle?, kunci: String): android.app.Person? {
        if (bundle == null || Build.VERSION.SDK_INT < 28) return null
        return try {
            if (Build.VERSION.SDK_INT >= 33) {
                bundle.getParcelable(kunci, android.app.Person::class.java)
            } else {
                @Suppress("DEPRECATION")
                bundle.getParcelable<android.app.Person>(kunci)
            }
        } catch (_: Exception) { null }
    }

    /** Dua Person dianggap sama bila kuncinya sama; bila kunci tidak ada, bandingkan nama. */
    private fun samaOrang(a: android.app.Person?, b: android.app.Person?): Boolean {
        if (a == null || b == null) return false
        val kunciA = a.key.orEmpty()
        val kunciB = b.key.orEmpty()
        if (kunciA.isNotBlank() && kunciB.isNotBlank()) return kunciA == kunciB
        val namaA = a.name?.toString()?.trim().orEmpty()
        val namaB = b.name?.toString()?.trim().orEmpty()
        return namaA.isNotBlank() && namaA.equals(namaB, true)
    }

    private fun adaPengirim(pesan: Bundle): Boolean =
        !pesan.getCharSequence("sender").isNullOrBlank() || ambilOrang(pesan, "sender_person") != null

    /**
     * Menilai arah pesan dari metadata MessagingStyle pesan TERBARU, yaitu pesan yang akan dibacakan.
     * Bukti yang dipakai: (1) pesan tanpa pengirim berarti dikirim pemilik perangkat, (2) pengirim sama dengan
     * pemilik perangkat (android.messagingUser, nama tampilan diri sendiri, atau kata "Anda/You"), (3) pengirim lain
     * berarti pesan masuk. Pesan terbaru tanpa pengirim dinilai keluar bila ada bukti pendukung: pesan lain pada
     * notifikasi itu punya pengirim (jadi aplikasi memang mencatat pengirim, termasuk WhatsApp dan WhatsApp Business)
     * atau ada riwayat balasan langsung. Tanpa bukti itu hasilnya TIDAK_PASTI, agar aplikasi yang tidak pernah
     * mengisi pengirim tidak menjadi senyap total.
     */
    private fun arahDariMessagingStyle(extras: Bundle): ArahPesan {
        if (Build.VERSION.SDK_INT < 24) return ArahPesan.TIDAK_PASTI
        val daftar = try { extras.getParcelableArray(Notification.EXTRA_MESSAGES) } catch (_: Exception) { null }
        if (daftar == null || daftar.isEmpty()) return ArahPesan.TIDAK_PASTI
        val terakhir = daftar.lastOrNull() as? Bundle ?: return ArahPesan.TIDAK_PASTI

        if (!adaPengirim(terakhir)) {
            val adaPengirimLain = daftar.any { p -> (p as? Bundle)?.let { adaPengirim(it) } == true }
            val riwayat = !extras.getCharSequenceArray(Notification.EXTRA_REMOTE_INPUT_HISTORY).isNullOrEmpty()
            return if (adaPengirimLain || riwayat) ArahPesan.KELUAR else ArahPesan.TIDAK_PASTI
        }

        val orangPengirim = ambilOrang(terakhir, "sender_person")
        val pemilik = ambilOrang(extras, "android.messagingUser")
        if (samaOrang(orangPengirim, pemilik)) return ArahPesan.KELUAR

        val namaPengirim = (orangPengirim?.name?.toString().orEmpty().ifBlank { terakhir.getCharSequence("sender")?.toString().orEmpty() }).trim()
        val namaDiri = (pemilik?.name?.toString().orEmpty().ifBlank { extras.getCharSequence("android.selfDisplayName")?.toString().orEmpty() }).trim()
        if (namaPengirim.isNotBlank() && namaDiri.isNotBlank() && namaPengirim.equals(namaDiri, true)) return ArahPesan.KELUAR
        if (KATA_PENGIRIM_SENDIRI.matches(namaPengirim)) return ArahPesan.KELUAR
        return ArahPesan.MASUK
    }

    /**
     * Notifikasi WhatsApp yang bukan pesan: pengiriman media/cadangan berjalan (ada progres), layanan latar
     * ("WhatsApp Web aktif", "memeriksa pesan baru"), dan notifikasi tetap. Ini tidak pernah diumumkan sebagai chat.
     */
    private fun bukanNotifikasiPesan(n: Notification, extras: Bundle): Boolean {
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0 || (n.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0) return true
        if (extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0 || extras.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) return true
        val kategori = n.category ?: return false
        return kategori == Notification.CATEGORY_PROGRESS || kategori == Notification.CATEGORY_SERVICE ||
            kategori == Notification.CATEGORY_STATUS || kategori == Notification.CATEGORY_SYSTEM ||
            kategori == Notification.CATEGORY_ERROR || kategori == Notification.CATEGORY_TRANSPORT
    }

    /**
     * Menolak notifikasi yang bukan pesan MASUK: pesan yang kita kirim sendiri, balasan lewat notifikasi, pesan
     * ke diri sendiri, dan status pengiriman. Metadata terstruktur (MessagingStyle) selalu didahulukan karena paling
     * tepat; teks isi pesan TIDAK dipakai untuk menilai pesan yang metadatanya jelas, sehingga pesan masuk yang
     * isinya kebetulan memuat kata "terkirim" atau "sent" tetap dibacakan. Petunjuk teks hanya dipakai bila
     * aplikasi tidak memberi metadata pengirim sama sekali. Mengembalikan true bila notifikasi TIDAK boleh diumumkan.
     */
    private fun bukanNotifikasiMasuk(
        sbn: StatusBarNotification,
        extras: Bundle
    ): Boolean {
        val riwayatBalasan = Build.VERSION.SDK_INT >= 24 &&
            !extras.getCharSequenceArray(Notification.EXTRA_REMOTE_INPUT_HISTORY).isNullOrEmpty()

        when (arahDariMessagingStyle(extras)) {
            ArahPesan.KELUAR -> return true
            ArahPesan.MASUK -> {
                // Setelah kita membalas lewat notifikasi, aplikasi dapat memasang ulang notifikasi dengan pesan masuk
                // lama sebagai pesan terbaru. Pesan yang sudah lama dan disertai riwayat balasan bukan pesan baru.
                if (riwayatBalasan && Build.VERSION.SDK_INT >= 24) {
                    try {
                        val terakhir = extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
                        val waktu = terakhir?.getLong("time", 0L) ?: 0L
                        if (waktu > 0L && System.currentTimeMillis() - waktu > 2 * 60_000L) return true
                    } catch (_: Exception) { }
                }
                return false
            }
            ArahPesan.TIDAK_PASTI -> { }
        }

        // Tanpa metadata pengirim: pakai petunjuk lain.
        if (riwayatBalasan) return true
        val judul = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val isi = listOf(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString()
        ).filterNotNull().joinToString(" ")
        val status = ("" + (judul) + " " + (isi)).lowercase().replace(Regex("\\s+"), " ").trim()
        if (KATA_STATUS_PENGIRIMAN.containsMatchIn(status)) return true
        if (KATA_AWAL_PENGIRIM_SENDIRI.containsMatchIn(isi.trim())) return true
        // Notifikasi SMS yang menyatakan pesan sudah terkirim bukan pesan masuk.
        if (PAKET_PESAN_SELULER.containsMatchIn(sbn.packageName ?: "") && KATA_STATUS_SMS_TERKIRIM.containsMatchIn(status)) return true
        return false
    }

    // FIX268: antrian pengumuman notifikasi. Notifikasi yang masuk saat pengumuman lain sedang berjalan (atau saat panggilan berdering)
    // menunggu giliran dan diumumkan berurutan menurut waktu masuk, sehingga tidak ada yang tertimpa.
    private val antrianNotif = java.util.ArrayDeque<Pair<String, String>>()
    private var notifSibuk = false
    private var notifSibukSejak = 0L

    private fun mulaiUlangNotif(pengumuman: String, kelompok: String) {
        val sibuk = (notifSibuk && System.currentTimeMillis() - notifSibukSejak < 240_000L) || berdering
        if (!prefs.antrianNotifOn || !sibuk) { jalankanNotif(pengumuman, kelompok); return }
        if (antrianNotif.any { it.first == pengumuman && it.second == kelompok }) return
        if (antrianNotif.size >= 30) antrianNotif.pollFirst()
        antrianNotif.addLast(pengumuman to kelompok)
    }

    /** Mengambil pengumuman berikutnya dari antrian bila tidak ada yang sedang berjalan. */
    private fun jalankanNotifBerikutnya() {
        if (berdering || antrianNotif.isEmpty()) return
        if ((ModeAcara.aktif(this) || DndSistem.senyap(this, true)) || !prefs.enabled || !prefs.pemOn) { antrianNotif.clear(); return }
        val berikut = antrianNotif.pollFirst() ?: return
        notifSibuk = true; notifSibukSejak = System.currentTimeMillis()
        handler.postDelayed({
            if (berdering) { antrianNotif.addFirst(berikut); notifSibuk = false }
            else jalankanNotif(berikut.first, berikut.second)
        }, 700L)
    }

    private fun akhiriAntrianNotif(generasi: Int) {
        if (generasi != notifGenerasi) return
        notifSibuk = false
        jalankanNotifBerikutnya()
    }

    private fun jalankanNotif(pengumuman: String, kelompok: String) {
        ulangNotifRunnable?.let { handler.removeCallbacks(it) }
        notifGenerasi++
        val generasi = notifGenerasi
        kelompokVolume = kelompok
        notifSibuk = true; notifSibukSejak = System.currentTimeMillis()
        notifTeksAktif = pengumuman
        notifSudahDiucap = 0
        PembungkamTelungkup.mulai(this, "pemanggil_notif", 90_000L) { bungkamTotal() }
        // Gunakan pengaturan melodi yang sama dengan pengumuman panggilan, juga untuk
        // SMS, chat pribadi/grup, dan notifikasi pesan suara.
        if (prefs.melodiAwalOn && prefs.melodiAwalIdx > 0) {
            putarMelodiSaluran(prefs.melodiAwalIdx) {
                if (generasi == notifGenerasi && !berdering) {
                    handler.postDelayed({ ucapUlangNotif(generasi) }, prefs.jedaMelodiAwal.toLong())
                }
            }
        } else {
            ucapUlangNotif(generasi)
        }
    }

    private fun ucapUlangNotif(generasi: Int) {
        if ((ModeAcara.aktif(this) || DndSistem.senyap(this, true)) || !prefs.enabled || !prefs.pemOn || prefs.notifUlangJumlah <= 0) {
            hentikanUlangNotif(true); return
        }
        if (generasi != notifGenerasi || berdering || notifTeksAktif.isBlank()) return
        // FIX262: perbarui pendaftaran pembungkam di tiap pengulangan agar pengumuman panjang/berulang tetap dapat dihentikan.
        PembungkamTelungkup.mulai(this, "pemanggil_notif", 120_000L) { bungkamTotal() }
        if (notifSudahDiucap >= prefs.notifUlangJumlah) {
            selesaiPengumumanNotif(generasi)
            return
        }
        notifSudahDiucap++
        siapkanPembicara().ucapkan(notifTeksAktif, notifSudahDiucap == 1) {
            if (generasi == notifGenerasi && !berdering && notifSudahDiucap < prefs.notifUlangJumlah) {
                val berikutnya = Runnable { ucapUlangNotif(generasi) }
                ulangNotifRunnable = berikutnya
                handler.postDelayed(berikutnya, (prefs.notifJeda * 1000).toLong())
            } else if (generasi == notifGenerasi) {
                selesaiPengumumanNotif(generasi)
            }
        }
    }

    private fun selesaiPengumumanNotif(generasi: Int) {
        if (generasi != notifGenerasi) return
        notifTeksAktif = ""
        ulangNotifRunnable = null
        if (prefs.melodiAkhirOn && prefs.melodiAkhirIdx > 0) {
            handler.postDelayed({
                if (generasi == notifGenerasi && !berdering && !ModeAcara.aktif(this)) {
                    putarMelodiSaluran(prefs.melodiAkhirIdx) { akhiriAntrianNotif(generasi) }
                } else akhiriAntrianNotif(generasi)
            }, prefs.jedaMelodiAkhir.toLong())
        } else akhiriAntrianNotif(generasi)
        // Lepas pendeteksi telungkup setelah pengumuman (dan melodi akhirnya) selesai.
        handler.postDelayed({
            if (generasi == notifGenerasi) PembungkamTelungkup.selesai("pemanggil_notif")
        }, (if (prefs.melodiAkhirOn && prefs.melodiAkhirIdx > 0) prefs.jedaMelodiAkhir.toLong() else 0L) + 5000L)
    }

    private fun hentikanUlangNotif(kosongkanAntrian: Boolean = false) {
        if (kosongkanAntrian) antrianNotif.clear()
        notifSibuk = false
        ulangNotifRunnable?.let { handler.removeCallbacks(it) }
        ulangNotifRunnable = null
        notifGenerasi++
        notifTeksAktif = ""
        notifSudahDiucap = 0
    }

    /**
     * True hanya untuk panggilan MASUK yang sedang berdering. Urutan pemeriksaan:
     * 1. Jenis panggilan dari sistem (CallStyle): 1 = masuk, 2 = berlangsung/keluar, 3 = disaring.
     * 2. Stopwatch tampil, atau teks berlangsung/tak terjawab/selesai: bukan panggilan berdering.
     * 3. Ada tombol Jawab/Tolak: panggilan masuk. Panggilan keluar hanya punya tombol Akhiri.
     * 4. Teks bernada panggilan keluar (Memanggil, Calling, Berdering, Dialing, ...): bukan masuk.
     * 5. Teks bernada panggilan masuk, atau notifikasi layar penuh tanpa tanda keluar: masuk.
     */
    private fun apakahMasuk(n: Notification, e: Bundle, tipe: Int): Boolean {
        if (tipe > 0) return tipe == 1
        if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) return false
        val t = gabungTeks(n, e)
        if (KATA_SELESAI.containsMatchIn(t)) return false
        if (adaTombolJawab(n)) return true
        if (KATA_KELUAR.containsMatchIn(t)) return false
        if (KATA_MASUK.containsMatchIn(t)) return true
        return n.fullScreenIntent != null
    }

    private fun adaTombolJawab(n: Notification): Boolean {
        val daftar = n.actions ?: return false
        return daftar.any { a ->
            val judulTombol = a.title?.toString()?.lowercase() ?: return@any false
            KATA_TOMBOL_JAWAB.containsMatchIn(judulTombol)
        }
    }

    private fun gabungTeks(n: Notification, e: Bundle): String {
        val daftar = listOf(
            Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_SUB_TEXT,
            Notification.EXTRA_BIG_TEXT, Notification.EXTRA_INFO_TEXT,
            Notification.EXTRA_CONVERSATION_TITLE
        ).mapNotNull { e.getCharSequence(it)?.toString() }
        return (daftar + listOfNotNull(n.tickerText?.toString())).joinToString(" ").lowercase()
    }

    @Suppress("DEPRECATION")
    private fun namaPemanggil(e: Bundle): String {
        var nama = ""
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val p = if (Build.VERSION.SDK_INT >= 33) {
                    e.getParcelable("android.callPerson", android.app.Person::class.java)
                } else {
                    e.getParcelable<android.app.Person>("android.callPerson")
                }
                nama = p?.name?.toString().orEmpty()
            } catch (ex: Exception) { }
        }
        if (nama.isBlank()) nama = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        nama = nama.trim()
        if (nama.any { it.isDigit() } && nama.count { it.isDigit() } >= 5) {
            nama = KontakHelper.namaDariNomor(this, nama, prefs.pemNamaPanggilan) ?: nama
        }
        return bersihkanSimbolNotif(nama)
    }

    // ---------- Pengumuman berulang ----------

    /** FIX264: kelompok volume pengumuman yang sedang berjalan: panggilan_seluler/wa/wb, pesan_seluler/wa/wb, atau lain. */
    private var kelompokVolume = "panggilan_seluler"
    private fun volPem(): Float = prefs.volumeSumberPem(kelompokVolume) / 100f

    /** FIX279: melodi diputar dengan pengali volume aplikasi; volume saluran HP tidak diubah. */
    private fun putarMelodiSaluran(idx: Int, selesai: (() -> Unit)? = null) {
        val v = prefs.volumeSaluranPem(kelompokVolume)
        Melodi.putar(this, idx, prefs.suara("pem").audioAttributes(), volume = if (v >= 0) v / 100f else volPem(), patuhDnd = 2) {
            selesai?.invoke()
        }
    }

    private fun siapkanPembicara(): Pembicara {
        val s = prefs.suara("pem")
        val ada = pembicara
        if (ada != null && ada.tanda == s.tanda()) { ada.volumeKhusus = prefs.volumeSumberPem(kelompokVolume); ada.volumeSaluran = prefs.volumeSaluranPem(kelompokVolume); return ada }
        ada?.matikan()
        val baru = Pembicara(this, s)
        baru.bisaDibungkam = true
        baru.patuhDnd = 2
        baru.hanyaKecilkanAudioLain = true
        baru.volumeKhusus = prefs.volumeSumberPem(kelompokVolume)
        baru.volumeSaluran = prefs.volumeSaluranPem(kelompokVolume)
        pembicara = baru
        return baru
    }

    private fun mulai(kunci: String, jenisSumber: Int, video: Boolean, nama: String) {
        berdering = true
        dibungkam = false
        handler.removeCallbacks(batasDeringRunnable); handler.postDelayed(batasDeringRunnable, 150_000L)
        PembungkamTelungkup.mulai(this, "pemanggil_panggilan", 180_000L) { bungkamTotal() }
        sumber = jenisSumber
        kelompokVolume = if (jenisSumber == SUMBER_WB) "panggilan_wb" else if (jenisSumber == SUMBER_WA) "panggilan_wa" else "panggilan_seluler"
        namaAktif = nama
        kunciAktif.clear()
        kunciAktif.add(kunci)
        ulang = 0
        teks = susun(this, prefs, jenisSumber == SUMBER_WA || jenisSumber == SUMBER_WB, video, nama, jenisSumber == SUMBER_WB)
        if (prefs.melodiAwalOn && prefs.melodiAwalIdx > 0) {
            putarMelodiSaluran(prefs.melodiAwalIdx) {
                handler.postDelayed({ if (berdering) ucapUlang() }, prefs.jedaMelodiAwal.toLong())
            }
        } else {
            ucapUlang()
        }
    }

    private fun ucapUlang() {
        if ((ModeAcara.aktif(this) || DndSistem.senyap(this, true)) || !prefs.enabled || !prefs.pemOn) { hentikan(); return }
        if (!berdering || dibungkam) return
        PembungkamTelungkup.mulai(this, "pemanggil_panggilan", 180_000L) { bungkamTotal() }
        val batas = prefs.pemBatas
        if (batas > 0 && ulang >= batas) {
            hentikan()
            return
        }
        ulang++
        siapkanPembicara().ucapkan(teks, ulang == 1) {
            if (berdering) {
                handler.postDelayed(ulangRunnable, (prefs.pemJeda * 1000).toLong())
            }
        }
    }

    /** FIX74: HP ditelungkupkan; diamkan ucapan, ulangan, dan melodi tanpa memutar melodi akhir. */
    private fun bungkamTotal() {
        dibungkam = berdering
        hentikanUlangNotif(true)
        handler.removeCallbacks(ulangRunnable)
        pembicara?.berhenti()
        PembungkamTelungkup.selesai("pemanggil_panggilan")
        PembungkamTelungkup.selesai("pemanggil_notif")
    }

    private fun hentikan() {
        // Jangan biarkan pengulangan pesan bersaing dengan pengumuman panggilan.
        hentikanUlangNotif()
        PembungkamTelungkup.selesai("pemanggil_panggilan")
        PembungkamTelungkup.selesai("pemanggil_notif")
        // Jangan mengulang melodi akhir bila beberapa notifikasi pembaruan datang berurutan
        // atau bila pengumuman sudah dibungkam dengan menelungkupkan HP.
        val memangAktif = berdering && !dibungkam
        berdering = false
        dibungkam = false
        handler.removeCallbacks(batasDeringRunnable)
        handler.removeCallbacks(ulangRunnable)
        kunciAktif.clear()
        pembicara?.berhenti()
        if (memangAktif && prefs.melodiAkhirOn && prefs.melodiAkhirIdx > 0) {
            handler.postDelayed({
                if (!berdering && !ModeAcara.aktif(this)) putarMelodiSaluran(prefs.melodiAkhirIdx)
            }, prefs.jedaMelodiAkhir.toLong())
        }
        // FIX268: notifikasi yang menunggu selama panggilan berdering diumumkan sesudah panggilan selesai.
        if (antrianNotif.isNotEmpty()) {
            handler.postDelayed({ jalankanNotifBerikutnya() }, (if (memangAktif && prefs.melodiAkhirOn && prefs.melodiAkhirIdx > 0) prefs.jedaMelodiAkhir.toLong() else 0L) + 2500L)
        }
    }

    // ---------- Status telepon seluler (untuk berhenti saat diangkat/ditolak) ----------

    private var teleponBerdering = false

    /**
     * FIX68: cadangan bila aplikasi telepon bawaan HP tidak menerbitkan notifikasi yang dapat dikenali.
     * Status telepon dari sistem berdering, tetapi tidak ada pengumuman dalam 2,5 detik, maka panggilan tetap diumumkan
     * (tanpa nama karena nomor tidak tersedia tanpa izin riwayat panggilan). Bila notifikasi dengan nama tiba kemudian,
     * pengumuman diperbarui dengan nama tersebut.
     */
    private val teleponCadangan = Runnable {
        if (teleponBerdering && !berdering && prefs.enabled && prefs.pemOn && prefs.pemTelp && !(ModeAcara.aktif(this) || DndSistem.senyap(this, true))) {
            mulai("telepon-cadangan", SUMBER_TELP, false, "")
        }
    }

    private fun statusTelepon(state: Int) {
        if (state == TelephonyManager.CALL_STATE_RINGING) {
            teleponBerdering = true
            handler.removeCallbacks(teleponCadangan)
            handler.postDelayed(teleponCadangan, 2500L)
            return
        }
        teleponBerdering = false
        handler.removeCallbacks(teleponCadangan)
        if (berdering && sumber == SUMBER_TELP) hentikan()
    }

    private fun daftarTelepon() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        if (telCallback != null || telListener != null) return
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handler.post { statusTelepon(state) }
                    }
                }
                tm.registerTelephonyCallback(mainExecutor, cb)
                telCallback = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        statusTelepon(state)
                    }
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                telListener = l
            }
        } catch (e: Exception) { }
    }

    private fun lepasTelepon() {
        teleponBerdering = false
        handler.removeCallbacks(teleponCadangan)
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val cb = telCallback
            if (Build.VERSION.SDK_INT >= 31 && cb is TelephonyCallback) {
                tm.unregisterTelephonyCallback(cb)
            }
            telListener?.let {
                @Suppress("DEPRECATION")
                tm.listen(it, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) { }
        telCallback = null
        telListener = null
    }

    companion object {
        /**
         * FIX68: minta sistem menyambungkan kembali listener notifikasi bila akses notifikasi sudah diberikan.
         * Aman dipanggil berulang; dipakai saat boot, pembaruan aplikasi, dan saat aplikasi dibuka.
         */
        fun sambungkanUlang(ctx: Context) {
            try {
                val daftar = android.provider.Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return
                val aktif = daftar.split(":").any { android.content.ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
                if (aktif) NotificationListenerService.requestRebind(android.content.ComponentName(ctx, CallerListener::class.java))
            } catch (_: Exception) { }
        }

        /**
         * FIX65: nama pemanggil/pengirim, nama grup, dan isi pesan dari notifikasi sering berisi simbol (emoji, tanda arah
         * teks tak terlihat, "~" pada kontak WhatsApp tak tersimpan, kurung, bintang, garis bawah, dan sebagainya) yang
         * mengganggu saat teks tampil maupun dibacakan. Huruf, angka, dan tanda baca biasa (titik, koma, tanda tanya,
         * seru, titik dua, apostrof, tanda hubung di dalam kata) dipertahankan.
         */
        fun bersihkanSimbolNotif(teks: String): String = teks
            .replace(Regex("[\\p{Cf}\\p{Co}\\p{Cs}\\p{So}\\p{Sk}\\p{Sm}\\uFE00-\\uFE0F]"), "")
            .replace(Regex("\\p{Cc}"), " ")
            .replace(Regex("[~*_#|^`<>=+\\\\/\\[\\]{}()\"\u2022\u00B7\u2014\u2013\u2026&@]"), " ")
            .replace(Regex("([!?.,])\\1+"), "\$1")
            .replace(Regex("(?<=\\s)-+(?=\\s)|^-+|-+$"), " ")
            .replace(Regex("\\s+([,.!?])"), "\$1")
            .replace(Regex("\\s+"), " ")
            .trim()

        private fun renderTemplatePesan(template: String, nama: String, grup: String, pesan: String, jenis: String): String {
            return template
                .replace("{nama}", nama, ignoreCase = true)
                .replace("{grup}", grup, ignoreCase = true)
                .replace("{pesan}", pesan, ignoreCase = true)
                .replace("{jenis}", jenis, ignoreCase = true)
                .replace(Regex("\\s+([,.!?])")) { m -> m.groupValues[1] }
                .replace(Regex("[ \t]+"), " ")
                .replace(Regex("([.!?])(?:\\s*[.!?])+")) { m -> m.groupValues[1] }
                .trim()
        }

        private fun namaPengirimTidakDikenal(bahasa: Int): String = when (bahasa) {
            1 -> "Unknown sender"
            2 -> "مرسل غير معروف"
            3 -> "Pangirim boten dipunmangertosi"
            4 -> "Pangirim teu dipikanyaho"
            else -> "Pengirim tidak diketahui"
        }

        private fun namaGrupTidakDikenal(bahasa: Int): String = when (bahasa) {
            1 -> "unknown group"
            2 -> "مجموعة غير معروفة"
            3 -> "grup ingkang boten dipunmangertosi"
            4 -> "grup teu dipikanyaho"
            else -> "grup tidak diketahui"
        }

        private fun keteranganGrupPesan(bahasa: Int, grup: String): String = when (bahasa) {
            1 -> ("in the group " + (grup))
            2 -> ("في المجموعة " + (grup))
            3 -> ("ing grup " + (grup))
            4 -> ("dina grup " + (grup))
            else -> ("di grup " + (grup))
        }

        private const val SUMBER_WA = 1
        private const val SUMBER_TELP = 2
        private const val SUMBER_WB = 3

        private val PAKET_TELEPON =
            Regex("dialer|incall|telecom|phone|oplus|coloros|oppo|miui|contacts")
        private const val KATEGORI_EMAIL = "email"
        private const val KATEGORI_GOJEK = "gojek"
        private const val KATEGORI_GRAB = "grab"
        private const val KATEGORI_INDRIVE = "indrive"
        private const val KATEGORI_MAXIM = "maxim"
        // Nada panggilan MASUK. Kata "ringing/berdering/calling/memanggil" sengaja TIDAK di sini:
        // WhatsApp dan aplikasi telepon memakainya juga untuk panggilan keluar.
        private val KATA_MASUK = Regex("incoming|panggilan masuk|masuk")
        // Nada panggilan KELUAR (kita yang menelepon).
        private val KATA_KELUAR = Regex(
            "outgoing|keluar|dialing|dialling|calling|memanggil|menelepon|menelpon|menghubungi|" +
                "connecting|reconnecting|menyambung|ringing|berdering"
        )
        // Tombol pada notifikasi panggilan masuk; panggilan keluar hanya punya tombol Akhiri.
        private val KATA_TOMBOL_JAWAB = Regex("answer|jawab|angkat|accept|terima|decline|reject|tolak")
        private val PAKET_PESAN_SELULER = Regex("messaging|mms|sms")
        private val KATA_PESAN_SUARA = Regex("pesan suara|voice message|voice note|pesan audio|audio message|voice-message")
        private val KATA_PENGIRIM_SENDIRI = Regex("(?i)\\s*(you|anda|me|saya|aku|diri sendiri)\\s*")
        private val KATA_AWAL_PENGIRIM_SENDIRI = Regex("(?i)^\\s*(you|anda|saya|aku)\\s*:")
        private val KATA_STATUS_PENGIRIMAN = Regex(
            "(?i)\\b(pesan terkirim|message sent|you sent|anda mengirim|anda telah mengirim|" +
                "pesan berhasil dikirim|berhasil dikirim|sent a message|sending message|mengirim pesan)\\b"
        )
        private val KATA_STATUS_SMS_TERKIRIM = Regex("(?i)pesan terkirim|message sent|berhasil dikirim|sent")
        private val KATA_VIDEO = Regex("video")
        private val KATA_VIDEO_JUDUL = Regex("video call|videocall|panggilan video")
        private val KATA_TANDA_PANGGILAN = Regex(
            "(?i)incoming call|incoming voice call|incoming video call|panggilan masuk|panggilan suara|panggilan video|" +
                "telepon masuk|panggilan|call notification|voice call|video call|calling screen|layar panggilan"
        )
        private val KATA_SELESAI = Regex(
            "ongoing|berlangsung|connected|tersambung|in call|dalam panggilan|missed|" +
                "tak terjawab|tidak terjawab|terlewat|ended|berakhir|declin|ditolak|" +
                "return to call|kembali ke panggilan"
        )

        /** Nomor tanpa nama dibaca angka per angka. */
        private fun bacaNama(nama: String): String {
            val bersih = bersihkanSimbolNotif(nama)
            if (bersih.isBlank()) return ""
            if (bersih.none { it.isLetter() } && bersih.count { it.isDigit() } >= 5) {
                return bersih.filter { it.isDigit() }.toCharArray().joinToString(" ")
            }
            return bersih
        }

        /** Kalimat yang diucapkan untuk satu panggilan. Dipakai juga oleh tombol tes. */
        fun susun(ctx: Context, p: Prefs, wa: Boolean, video: Boolean, nama: String, bisnis: Boolean = false): String {
            val n = bacaNama(nama).ifEmpty { namaPengirimTidakDikenal(p.bahasaPemanggil) }
            val sebelum: String
            val sesudah: String
            when {
                bisnis && video -> { sebelum = p.pesanSebelumWbVideo; sesudah = p.pesanSesudahWbVideo }
                bisnis -> { sebelum = p.pesanSebelumWbSuara; sesudah = p.pesanSesudahWbSuara }
                wa && video -> { sebelum = p.pesanSebelumWaVideo; sesudah = p.pesanSesudahWaVideo }
                wa -> { sebelum = p.pesanSebelumWaSuara; sesudah = p.pesanSesudahWaSuara }
                else -> { sebelum = p.pesanSebelumTelp; sesudah = p.pesanSesudahTelp }
            }
            if (sebelum.isNotBlank() || sesudah.isNotBlank()) {
                return listOf(sebelum, n, sesudah).filter { it.isNotBlank() }
                    .joinToString(" ").replace(Regex("\\s+"), " ").trim()
            }
            val bahasa = p.bahasaPemanggil
            val jenis = when (bahasa) {
                1 -> when {
                    bisnis && video -> "WhatsApp Business video call from"
                    bisnis -> "WhatsApp Business voice call from"
                    wa && video -> "WhatsApp video call from"
                    wa -> "WhatsApp voice call from"
                    else -> "Incoming phone call from"
                }
                2 -> when {
                    video -> "مكالمة فيديو من"
                    wa || bisnis -> "مكالمة واتساب من"
                    else -> "مكالمة هاتفية من"
                }
                3 -> when {
                    video -> "Pangandikan video saking"
                    wa || bisnis -> "Pangandikan WhatsApp saking"
                    else -> "Pangandikan telepon saking"
                }
                4 -> when {
                    video -> "Telepon vidéo ti"
                    wa || bisnis -> "Telepon WhatsApp ti"
                    else -> "Telepon ti"
                }
                else -> when {
                    bisnis && video -> "Panggilan video WhatsApp Business dari"
                    bisnis -> "Panggilan suara WhatsApp Business dari"
                    wa && video -> "Panggilan video WhatsApp Messenger dari"
                    wa -> "Panggilan suara WhatsApp Messenger dari"
                    else -> "Panggilan telepon seluler dari"
                }
            }
            return ("" + (jenis) + " " + (n)).replace(Regex("\\s+"), " ").trim()

        }
    }
}
