package com.novan.bateraibicara

import kotlin.math.max
import kotlin.math.sqrt

/**
 * FIX99: pendeteksi pola "tiga goncangan cepat" untuk membuka perintah suara.
 *
 * Tujuannya membedakan goncangan yang disengaja (perintah) dari gerakan biasa (berjalan, mengangkat HP, meletakkan
 * HP, ketukan, getaran kendaraan). Satu "goncangan" = satu hentakan percepatan (puncak) yang naik cepat.
 * Pola sah bila terjadi TIGA hentakan berturut-turut dengan syarat:
 *  1. Tiap puncak naik cepat (maks. [NAIK_MAKS_MS] dari lembah ke puncak). Gerakan lambat (mengangkat, mengayun) ditolak.
 *  2. Jeda antarpuncak [MIN_JEDA_MS]..jeda maksimum, dan ketiganya selesai dalam [JENDELA_MS].
 *  3. Mode ketat (bawaan): HP harus diam sekitar [TENANG_SEBELUM_MS] sebelum gerakan, dan puncak pertama muncul
 *     segera sesudah HP mulai bergerak ([MULAI_MAKS_MS]); jadi "angkat HP lalu langsung goyang" tidak dihitung.
 *  4. Bila dua atau lebih hentakan sudah terjadi dalam [RIWAYAT_MS] sebelumnya, gerakan dianggap berirama
 *     (berjalan/berlari/kendaraan) dan tidak dihitung.
 *  5. Mode longgar (boleh sambil bergerak): ambang puncak 1,8 kali lebih tinggi dan jumlahnya harus TEPAT tiga
 *     (hentakan keempat dalam jeda maksimum membatalkan pola).
 * Setelah pola dikenali, pemicu berikutnya ditahan selama [cooldownMs].
 *
 * Kelas ini murni logika (tanpa Android) sehingga dipakai bersama oleh layanan latar belakang dan layar uji.
 * Dipanggil dari satu thread (thread utama) dengan cap waktu monoton dalam milidetik.
 */
class DetektorGoncangan {
    enum class Hasil { TIDAK_ADA, PUNCAK, POLA }

    /** 1 = perlu goncangan kuat ... 10 = goncangan ringan sudah terdeteksi. */
    var sensitivitas: Int = 5
    /** false = ketat (HP harus diam dulu); true = longgar (boleh sambil bergerak, hentakan lebih kuat, tepat tiga). */
    var longgar: Boolean = false
    var cooldownMs: Long = COOLDOWN_MS

    /** Jumlah puncak sah pada urutan yang sedang berjalan (0..3), untuk umpan balik pada layar uji. */
    var jumlahPuncak: Int = 0
        private set

    private var siap = false
    private var gx = 0f
    private var gy = 0f
    private var gz = 0f
    private var terakhirMs = 0L
    private var tPertama = 0L
    private var tTerakhir = 0L
    private var tPemicu = -1_000_000_000L
    private var tenangSejak = -1L
    private var tenangSebelum = 0L
    private var aktif = false
    private var tAwalBurst = 0L
    private var fase = 0
    private var maxP = 0f
    private var tMax = 0L
    private var minP = 0f
    private var tLembah = 0L
    private var tRendah = 0L
    private val riwayat = ArrayList<Long>()
    private var menunggu = false
    private var tMenunggu = 0L

    fun reset() {
        siap = false
        jumlahPuncak = 0
        tPemicu = -1_000_000_000L
        tenangSejak = -1L
        tenangSebelum = 0L
        aktif = false
        fase = 0
        maxP = 0f
        riwayat.clear()
        menunggu = false
    }

    private fun jedaMaks(): Long = if (longgar) JEDA_MAKS_LONGGAR_MS else JEDA_MAKS_MS

    /** Ambang puncak (m/s^2). Sensitivitas 1 -> 7,0; 5 -> 5,0; 10 -> 2,5. Mode longgar 1,8 kali lebih tinggi. */
    private fun ambangDasar(): Float {
        val s = sensitivitas.coerceIn(1, 10)
        return 7.0f - (s - 1) * (4.5f / 9f)
    }

    private fun batal() {
        jumlahPuncak = 0
        tenangSebelum = 0L
    }

    /** Satu sampel akselerometer (m/s^2, termasuk gravitasi) pada waktu [t] milidetik. */
    fun proses(x: Float, y: Float, z: Float, t: Long): Hasil {
        if (!siap) {
            gx = x; gy = y; gz = z
            terakhirMs = t
            siap = true
            tenangSejak = t
            tRendah = t
            tLembah = t
            return Hasil.TIDAK_ADA
        }
        val dt = (t - terakhirMs).coerceIn(1L, 200L) / 1000f
        terakhirMs = t
        // Penyaring lolos-tinggi untuk membuang gravitasi; tetapan waktu 0,1 detik tidak bergantung laju sampel.
        val a = TAU_DETIK / (TAU_DETIK + dt)
        gx = a * gx + (1f - a) * x
        gy = a * gy + (1f - a) * y
        gz = a * gz + (1f - a) * z
        val ax = x - gx
        val ay = y - gy
        val az = z - gz
        val p = sqrt(ax * ax + ay * ay + az * az)
        val dasar = ambangDasar()
        val amb = if (longgar) dasar * 1.8f else dasar

        // --- keheningan dan awal gerakan (burst) ---
        if (p < dasar * 0.5f) {
            if (tenangSejak < 0) tenangSejak = t
            if (aktif && t - tenangSejak >= AKHIR_BURST_MS) aktif = false
        } else {
            if (!aktif) {
                aktif = true
                tAwalBurst = t
                tenangSebelum = if (tenangSejak >= 0) t - tenangSejak else 0L
            }
            tenangSejak = -1L
        }
        if (p < amb * 0.45f) tRendah = t

        // --- puncak lokal: naik sampai maksimum, terkonfirmasi saat turun di bawah 60% maksimum ---
        var hasil = Hasil.TIDAK_ADA
        if (fase == 0) {
            if (p > maxP) { maxP = p; tMax = t }
            if (maxP >= amb && p < maxP * 0.6f) {
                val naik = tMax - max(tLembah, tRendah)
                fase = 1
                minP = p
                tLembah = t
                val tPuncak = tMax
                maxP = 0f
                hasil = puncakTerkonfirmasi(tPuncak, naik)
            }
        } else {
            if (p < minP) { minP = p; tLembah = t }
            if (p > minP + 0.25f * amb) {
                fase = 0
                maxP = p
                tMax = t
            }
        }

        // Mode longgar: pola sah setelah tidak ada hentakan keempat dalam jeda maksimum.
        if (menunggu && t - tMenunggu >= jedaMaks()) {
            menunggu = false
            jumlahPuncak = 0
            tPemicu = tMenunggu
            tenangSebelum = 0L
            return Hasil.POLA
        }
        // Urutan kedaluwarsa bila tidak ada puncak baru.
        if (jumlahPuncak > 0 && !menunggu && t - tTerakhir > jedaMaks() + 100L) batal()
        return hasil
    }

    private fun puncakTerkonfirmasi(tp: Long, naik: Long): Hasil {
        if (naik > NAIK_MAKS_MS) {          // hentakan lambat (mengangkat, mengayun) bukan goncangan
            menunggu = false
            batal()
            return Hasil.TIDAK_ADA
        }
        if (menunggu) {                     // mode longgar: hentakan ke-4 membatalkan pola
            menunggu = false
            batal()
            riwayat.add(tp)
            return Hasil.TIDAK_ADA
        }
        riwayat.removeAll { tp - it > RIWAYAT_MS }
        val sebelumnya = riwayat.size
        riwayat.add(tp)
        if (tp - tPemicu < cooldownMs) return Hasil.TIDAK_ADA
        if (jumlahPuncak > 0 && (tp - tTerakhir > jedaMaks() || tp - tPertama > JENDELA_MS)) {
            batal()
            return Hasil.TIDAK_ADA
        }
        if (jumlahPuncak > 0 && tp - tTerakhir < MIN_JEDA_MS) return Hasil.TIDAK_ADA
        if (jumlahPuncak == 0) {
            if (sebelumnya >= 2) return Hasil.TIDAK_ADA          // sudah bergerak berirama
            if (!longgar) {
                if (tenangSebelum < TENANG_SEBELUM_MS) return Hasil.TIDAK_ADA
                if (tp - tAwalBurst > MULAI_MAKS_MS) return Hasil.TIDAK_ADA
            }
            jumlahPuncak = 1
            tPertama = tp
            tTerakhir = tp
            return Hasil.PUNCAK
        }
        jumlahPuncak++
        tTerakhir = tp
        if (jumlahPuncak >= 3) {
            if (longgar) {
                menunggu = true
                tMenunggu = tp
                return Hasil.PUNCAK
            }
            jumlahPuncak = 0
            tPemicu = tp
            tenangSebelum = 0L
            return Hasil.POLA
        }
        return Hasil.PUNCAK
    }

    companion object {
        private const val TAU_DETIK = 0.1f
        private const val MIN_JEDA_MS = 120L
        private const val JEDA_MAKS_MS = 500L
        private const val JEDA_MAKS_LONGGAR_MS = 450L
        private const val JENDELA_MS = 1800L
        private const val TENANG_SEBELUM_MS = 700L
        private const val AKHIR_BURST_MS = 300L
        private const val NAIK_MAKS_MS = 150L
        private const val MULAI_MAKS_MS = 450L
        private const val RIWAYAT_MS = 2000L
        const val COOLDOWN_MS = 7000L
    }
}
