package com.novan.bateraibicara

import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Calendar
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/**
 * FIX84: perintah suara Beritahu Saya.
 * Dibuka dengan ketuk tahan pada ikon Beritahu Saya (pintasan aplikasi) atau ketuk tahan pada saklar
 * pemicu Beritahu Saya di layar utama aplikasi. Layar pengenalan suara sistem dibuka (tanpa izin
 * mikrofon aplikasi), lalu perintah dijalankan: waktu, tanggal, atau memutar Al-Qur'an.
 * Bahasa pengenalan, teks, dan pesan mengikuti bahasa tampilan utama yang aktif.
 */
class PerintahSuaraActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutupDanLanjutAudio() }
    private var permintaanFokusMik: AudioFocusRequest? = null
    private var fokusMikDiminta = false
    // FIX121: status menunggu pengenalan, supaya pemicu baru dapat memulai ulang pengenalan yang macet.
    private var menungguPengenalan = false
    private var waktuMulai = 0L
    private var waktuBukaSistem = 0L
    private var percobaanUlangMic = 0
    private var generasiPengenalan = 0
    // FIX122: tombol volume dan telungkup menghentikan jawaban suara; layar ditutup bila itu terjadi.
    private var volumeDikonsumsi = false
    private var generasiBungkamAwal = 0
    private val pantauBungkam = object : Runnable {
        override fun run() {
            if (selesai || isFinishing) return
            if (PembungkamTelungkup.generasi != generasiBungkamAwal) { tutupDanLanjutAudio(); return }
            handler.postDelayed(this, 400L)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) volumeDikonsumsi = false
                if (volumeDikonsumsi) return true
                if (PembungkamTelungkup.bungkamDariTombolVolume(this)) {
                    volumeDikonsumsi = true
                    tutupDanLanjutAudio()
                    return true
                }
            } else if (event.action == KeyEvent.ACTION_UP && volumeDikonsumsi) {
                volumeDikonsumsi = false
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }
    private var pengenal: SpeechRecognizer? = null
    private var sudahFallback = false
    private var pakaiPengenalUmum = false
    private var pengenalanSistemDaring = false
    private var percobaanSibuk = 0
    private var dipicuGoncanganSaatIni = false
    // Mode dua tahap: "telepon" diikuti nama kontak atau nomor.
    private var menungguNamaKontak = false
    private var ucapanKontakTertunda = ""
    // Saluran panggilan dipilih dari ucapan eksplisit pengguna.
    private enum class SaluranPanggilan { SELULER, WHATSAPP, WHATSAPP_BUSINESS }
    private var saluranPanggilan = SaluranPanggilan.SELULER
    private var nomorPanggilanTertunda = ""
    private var jenisPanggilanWhatsApp: String? = null
    private var menungguJenisPanggilanWhatsApp = false

    private fun tr(id: String, en: String): String = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FIX182: halaman perintah suara juga mengikuti mode hemat daya global.
        PenghematDaya.terapkan(this)
        val prefs = Prefs(applicationContext)
        val dipicuGoncangan = intent.getBooleanExtra(EXTRA_PEMICU_GONCANGAN, false)
        val ujiPaketOffline = intent.getBooleanExtra(EXTRA_UJI_PAKET_OFFLINE, false)
        dipicuGoncanganSaatIni = dipicuGoncangan
        if (dipicuGoncangan) {
            // FIX95: notifikasi "Perintah suara siap" sudah tidak diperlukan setelah layar ini terbuka.
            try { getSystemService(NotificationManager::class.java).cancel(GoncanganSuaraService.NOTIFIKASI_SIAP_ID) } catch (_: Exception) { }
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
            }
        }
        if (!dipicuGoncangan && !ujiPaketOffline && !prefs.beritahuSayaOn) {
            Toast.makeText(this, getString(R.string.beritahu_saya_nonaktif_petunjuk), Toast.LENGTH_LONG).show()
            selesai = true
            finish()
            return
        }
        // FIX123: serialkan kepemilikan mikrofon. Instance lama ditutup dan diberi waktu melepas
        // SpeechRecognizer/audio focus sebelum sesi baru dimulai; jangan mulai dua sesi bersamaan.
        val lama = aktif
        aktif = this
        if (lama != null && lama !== this) {
            lama.tutupPaksa()
            if (savedInstanceState == null) {
                handler.postDelayed({ if (!isFinishing && aktif === this) mulai() }, 650L)
            }
        } else if (savedInstanceState == null) {
            mulai()
        }
    }

    private fun terkunci(): Boolean =
        try { (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked } catch (_: Exception) { false }

    /** Pengenal langsung untuk layar terkunci/goncangan; dukung layanan standar pada HP lama juga. */
    private fun bisaPengenalanDalam(): Boolean {
        if (!(dipicuGoncanganSaatIni || terkunci())) return false
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
    }

    /** Bila "Suara TalkBack saat mikrofon dipakai" dimatikan (Khatam), senyapkan TalkBack, beri getar, lalu buka mikrofon. */
    private fun mulai() {
        // FIX120: audio Khatam tidak menangani fokus audio sendiri, jadi dijeda secara eksplisit selama mikrofon dibuka
        // (dilanjutkan setelah jawaban selesai bila perintahnya tidak mengatur audio). Fokus sementara membuat pemutar latar
        // belakang ikut berhenti sebentar. Batas waktu mencegah layar ini tertahan selamanya bila pengenal tidak menjawab.
        KhatamActivity.jedakanUntukMikrofon()
        menungguPengenalan = true
        waktuMulai = SystemClock.elapsedRealtime()
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 45_000L)
        val senyap = getSharedPreferences("khatam_quran", MODE_PRIVATE).getBoolean("senyap_talkback_pergantian_audio", false)
        pakaiPengenalUmum = false
        pengenalanSistemDaring = false
        val dalam = bisaPengenalanDalam()
        if (senyap || dalam) {
            // Potong ucapan aksesibilitas sebelum mikrofon on-device dibuka.
            hentikanUjaranTalkBack()
            getar(150L)
            handler.postDelayed({
                if (isFinishing) return@postDelayed
                if (senyap || dalam) hentikanUjaranTalkBack()
                if (dalam && bukaPengenalanDalam()) return@postDelayed
                // Lepaskan fokus jika recognizer on-device tidak tersedia.
                lepasFokusMikrofon()
                bukaPengenalan(false)
            }, if (dalam) 700L else 800L)
        } else {
            bukaPengenalan(true)
        }
    }

    private fun tagBahasaPengenalan(): String = when (BahasaAplikasi.tampilan(this)) {
        1 -> "en-US"
        2 -> "ar-SA"
        3 -> "jv-ID"
        4 -> "su-ID"
        else -> "id-ID"
    }

    private fun nadaSiap() {
        getar(90L)
        try {
            val nada = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            nada.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            handler.postDelayed({ try { nada.release() } catch (_: Exception) { } }, 400L)
        } catch (_: Exception) { }
    }

    private fun lepasPengenal() {
        try { pengenal?.cancel() } catch (_: Exception) { }
        try { pengenal?.destroy() } catch (_: Exception) { }
        pengenal = null
    }

    private fun keCadangan() {
        // Dipakai hanya jika pengenal internal dan jalur sistem tidak dapat dijalankan.
        lepasPengenal()
        lepasFokusMikrofon()
        if (isFinishing || selesai) return
        Toast.makeText(this, pesanPengenalOfflineTidakTersedia(), Toast.LENGTH_LONG).show()
        tutupDanLanjutAudio()
    }

    private fun pesanPengenalOfflineTidakTersedia(): String = tr(
        "Layanan pengenalan suara tidak tersedia. Pastikan layanan Google atau layanan pengenalan suara bawaan HP aktif, lalu periksa koneksi internet atau unduh paket bahasa untuk penggunaan offline.",
        "Speech recognition is unavailable. Make sure Google or the phone's speech recognition service is enabled, then check the internet connection or download a language pack for offline use."
    )

    /** Gunakan pengenal on-device bila ada; jika tidak, coba layanan pengenal standar perangkat. */
    private fun bukaPengenalanDalam(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return false
            // Jika pengguna memilih mesin terpasang melalui Pengelola Paket Bahasa,
            // gunakan komponen layanan itu secara eksplisit. Jika tidak, prioritaskan
            // pengenal on-device Android lalu jatuh kembali ke mesin standar sistem.
            val mesinPilihan = PengenalSuaraTerpasang.dipilih(this)
            if (mesinPilihan != null && !PengenalSuaraTerpasang.pilihanMasihTersedia(this)) {
                Toast.makeText(this, tr(
                    "Mesin pengenal suara pilihan sudah tidak terpasang atau dinonaktifkan. Buka Paket Bahasa Pengenal Suara Offline untuk memilih mesin lain.",
                    "The selected speech recognition engine is no longer installed or is disabled. Open Offline Speech Language Packs to choose another engine."
                ), Toast.LENGTH_LONG).show()
                return false
            }
            val onDevice = mesinPilihan == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !pakaiPengenalUmum &&
                try { SpeechRecognizer.isOnDeviceRecognitionAvailable(this) } catch (_: Exception) { false }
            if (!onDevice) pakaiPengenalUmum = true
            val sr = when {
                mesinPilihan != null -> SpeechRecognizer.createSpeechRecognizer(this, mesinPilihan)
                onDevice -> SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                else -> SpeechRecognizer.createSpeechRecognizer(this)
            }
            pengenal = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { nadaSiap() }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
                override fun onResults(results: Bundle?) {
                    val kandidat = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    lepasPengenal()
                    if (kandidat.isEmpty()) { tutupDanLanjutAudio(); return }
                    terimaHasilSuara(kandidat)
                }
                override fun onError(error: Int) {
                    val perluDaring = error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ||
                        error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT || error == SpeechRecognizer.ERROR_SERVER
                    if (!pakaiPengenalUmum && perluDaring) {
                        lepasPengenal(); pakaiPengenalUmum = true
                        handler.postDelayed({ if (!isFinishing && !selesai && !bukaPengenalanDalam()) bukaPengenalanSistem(false) }, 450L)
                        return
                    }
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                            lepasPengenal(); getar(300L)
                            Toast.makeText(this@PerintahSuaraActivity, getString(R.string.perintah_suara_tidak_terdengar), Toast.LENGTH_LONG).show()
                            tutupDanLanjutAudio()
                        }
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            if (percobaanSibuk++ < 1) {
                                lepasPengenal()
                                handler.postDelayed({ if (!isFinishing && !bukaPengenalanDalam()) bukaPengenalanSistem(false) }, 600L)
                            } else keCadangan()
                        }
                        else -> {
                            lepasPengenal()
                            if (!pakaiPengenalUmum) {
                                pakaiPengenalUmum = true
                                handler.postDelayed({ if (!isFinishing && !bukaPengenalanDalam()) bukaPengenalanSistem(false) }, 450L)
                            } else if (!terkunci() && !dipicuGoncanganSaatIni) {
                                bukaPengenalanSistem(false)
                            } else keCadangan()
                        }
                    }
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !pakaiPengenalUmum)
            }
            ambilFokusMikrofon(); sr.startListening(i); true
        } catch (_: Exception) { lepasPengenal(); false }
    }

    /** Jalur sistem untuk HP yang belum memberikan izin mikrofon langsung kepada aplikasi. */
    private fun bukaPengenalanSistem(denganPetunjuk: Boolean, petunjukKhusus: String? = null) {
        if (isFinishing || selesai) return
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !pengenalanSistemDaring)
                if (denganPetunjuk && !petunjukKhusus.isNullOrBlank()) putExtra(RecognizerIntent.EXTRA_PROMPT, petunjukKhusus)
            }
            waktuBukaSistem = SystemClock.elapsedRealtime()
            startActivityForResult(i, kodePengenalan())
        } catch (_: Exception) {
            Toast.makeText(this, pesanPengenalOfflineTidakTersedia(), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
        }
    }

    /** FIX95: perintah yang membuka aplikasi lain, memanggil, atau membacakan pesan pribadi meminta pengguna membuka kunci layar lebih dulu. */
    private fun denganBukaKunci(aksi: () -> Unit) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (km == null || !km.isKeyguardLocked || Build.VERSION.SDK_INT < 26) { aksi(); return }
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { handler.removeCallbacks(batasWaktu); aksi() }
            override fun onDismissCancelled() { tutup() }
            override fun onDismissError() { tutup() }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // FIX123: ketukan widget adalah permintaan pengguna baru dan selalu memulai sesi baru.
        // Pemicu ganda dari layanan goncangan/notifikasi dalam rentang pendek tetap diabaikan.
        val manual = intent.getBooleanExtra(EXTRA_PEMICU_MANUAL, false)
        if (!selesai && manual) {
            // Ketukan widget yang disengaja selalu dapat meminta sesi mikrofon baru,
            // termasuk saat sesi sebelumnya sedang membacakan jawaban.
            hentikanSuara()
            mulaiUlangPengenalan()
        } else if (!selesai && menungguPengenalan &&
            SystemClock.elapsedRealtime() - waktuMulai > 6_000L
        ) {
            mulaiUlangPengenalan()
        }
    }

    private fun mulaiUlangPengenalan() {
        // Hentikan layar pengenal sistem lama sebelum mengubah kode hasilnya, agar sesi lama
        // tidak terus memegang mikrofon dan hasil terlambatnya tidak masuk ke sesi yang baru.
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        generasiPengenalan++
        lepasPengenal()
        lepasFokusMikrofon()
        handler.removeCallbacksAndMessages(null)
        menungguPengenalan = false
        sudahFallback = false
        pakaiPengenalUmum = false
        pengenalanSistemDaring = false
        percobaanSibuk = 0
        percobaanUlangMic = 0
        handler.postDelayed({ if (!isFinishing && !selesai && aktif === this) mulai() }, 350L)
    }

    private fun kodePengenalan(): Int = KODE_PENGENALAN + generasiPengenalan

    private fun pengenalDalamTersedia(): Boolean {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
    }

    /** Percobaan ulang menggunakan mode pengenal yang saat ini tersedia pada perangkat. */
    private fun ulangiPengenalanMikrofon() {
        if (isFinishing || selesai) return
        if (percobaanUlangMic++ < 1) {
            getar(120L)
            handler.postDelayed({
                if (isFinishing || selesai) return@postDelayed
                if (pengenalDalamTersedia() && bukaPengenalanDalam()) return@postDelayed
                keCadangan()
            }, 900L)
        } else {
            getar(300L)
            Toast.makeText(this, getString(R.string.perintah_suara_mikrofon_gagal), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
        }
    }

    private fun bukaPengenalan(denganPetunjuk: Boolean, petunjukKhusus: String? = null) {
        lepasFokusMikrofon()
        if (pengenalDalamTersedia() && bukaPengenalanDalam()) return
        if (terkunci() || dipicuGoncanganSaatIni) { keCadangan(); return }
        bukaPengenalanSistem(denganPetunjuk, petunjukKhusus)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != kodePengenalan()) return
        val kandidat = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty() else emptyList<String>()
        if (kandidat.isEmpty()) {
            val galatMikrofon = resultCode == RecognizerIntent.RESULT_AUDIO_ERROR || resultCode == RecognizerIntent.RESULT_CLIENT_ERROR ||
                resultCode == RecognizerIntent.RESULT_SERVER_ERROR || resultCode == RecognizerIntent.RESULT_NETWORK_ERROR ||
                (resultCode == RESULT_CANCELED && SystemClock.elapsedRealtime() - waktuBukaSistem < 1_500L)
            if (galatMikrofon && !pengenalanSistemDaring) {
                pengenalanSistemDaring = true
                handler.postDelayed({ if (!isFinishing && !selesai) bukaPengenalanSistem(false) }, 350L)
                return
            }
            if (galatMikrofon) { ulangiPengenalanMikrofon(); return }
            tutupDanLanjutAudio(); return
        }
        terimaHasilSuara(kandidat)
    }

    /** Hasil pengenalan pertama bisa berisi "telepon" saja; hasil berikutnya menjadi nama/nomor tujuan. */
    private fun terimaHasilSuara(kandidat: List<String>) {
        if (menungguJenisPanggilanWhatsApp) {
            menungguJenisPanggilanWhatsApp = false
            val ucapanJenis = kandidat.maxByOrNull { it.length }.orEmpty().lowercase()
            jenisPanggilanWhatsApp = when {
                listOf("video", "vidio", "visual").any { ucapanJenis.contains(it) } -> "video"
                listOf("suara", "voice", "audio").any { ucapanJenis.contains(it) } -> "voice"
                else -> null
            }
            if (jenisPanggilanWhatsApp == null) {
                menungguJenisPanggilanWhatsApp = true
                Toast.makeText(this, petunjukJenisPanggilanWhatsApp(), Toast.LENGTH_LONG).show()
                bukaPengenalan(false, petunjukJenisPanggilanWhatsApp())
            } else {
                lepasFokusMikrofon()
                jalankanSaluranPanggilan(nomorPanggilanTertunda)
            }
            return
        }
        if (menungguNamaKontak) {
            menungguNamaKontak = false
            lepasFokusMikrofon()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 90_000L)
            prosesTujuanPanggilan(kandidat)
        } else {
            jalankan(kandidat)
        }
    }

    private fun jalankan(kandidat: List<String>) {
        // FIX120: pengenalan selesai; lepas fokus mikrofon agar pemutar latar belakang lanjut sebelum perintah diproses,
        // dan beri batas waktu longgar untuk perintah apa pun.
        menungguPengenalan = false
        lepasFokusMikrofon()
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 120_000L)
        generasiBungkamAwal = PembungkamTelungkup.generasi
        handler.removeCallbacks(pantauBungkam)
        handler.postDelayed(pantauBungkam, 400L)
        // Sapaan dan ungkapan sosial diproses lebih dahulu agar tidak dianggap sebagai
        // perintah yang tidak dikenal. Respons memakai profil suara jam (mesin suara pilihan
        // pengguna), tetapi bahasa pengucapannya dipaksa mengikuti bahasa tampilan aplikasi.
        if (tanganiUcapanSosial(kandidat)) return

        when (PerintahSuara.tafsir(kandidat)) {
            PerintahSuara.Jenis.KONTROL_PERANGKAT -> bukaPengaturanPerangkat(PerintahSuara.kontrolPerangkat(kandidat))
            PerintahSuara.Jenis.TIMER -> kendaliTimer(kandidat)
            PerintahSuara.Jenis.BATERAI_INFO -> bacakanBaterai()
            PerintahSuara.Jenis.WAKTU -> bacakan(waktu = true, tanggal = false)
            PerintahSuara.Jenis.TANGGAL -> bacakan(waktu = false, tanggal = true)
            PerintahSuara.Jenis.WAKTU_TANGGAL -> bacakan(waktu = true, tanggal = true)
            PerintahSuara.Jenis.SEMUA -> bacakan(waktu = true, tanggal = true, lengkap = true)
            PerintahSuara.Jenis.PASARAN -> bacakanKhusus { p, c -> KalenderTanggal.pasaran(c, p.kalenderPasaranKoreksi, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_MASEHI -> bacakanKhusus { p, c -> KalenderTanggal.masehi(c, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_HIJRIAH -> bacakanKhusus { p, c ->
                KalenderTanggal.hijriah(c,
                    if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null,
                    p.bahasaAktif)
            }
            PerintahSuara.Jenis.LIBUR -> bacakanKhusus { p, _ ->
                val nasional = HariLibur.ringkasan(applicationContext, p, "national").drop(1)
                val cuti = HariLibur.ringkasan(applicationContext, p, "joint").drop(1)
                (nasional + cuti).joinToString(" ").ifBlank { pesanKosong(p, "holiday") }
            }
            PerintahSuara.Jenis.SHOLAT_BERIKUTNYA -> bacakanKhusus { p, c ->
                InfoSholat.segmen(p, c, abaikanSakelar = true).firstOrNull() ?: pesanKosong(p, "prayer")
            }
            PerintahSuara.Jenis.CUACA -> bacakanCuaca()
            PerintahSuara.Jenis.QURAN -> {
                // FIX142: semua perintah putar Quran (termasuk memilih qari) dijalankan layanan latar belakang.
                // Tidak ada layar aplikasi yang dibuka, baik saat terkunci maupun tidak, sehingga TalkBack tidak pernah terganggu.
                putarQuranLatarBelakang(kandidat)
            }
            PerintahSuara.Jenis.BERHENTI_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_BERHENTI)
            PerintahSuara.Jenis.JEDA_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_JEDA)
            PerintahSuara.Jenis.LANJUT_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_LANJUT)
            PerintahSuara.Jenis.BUKA_FITUR -> denganBukaKunci { bukaFitur(PerintahSuara.fitur(kandidat)) }
            PerintahSuara.Jenis.PANGGIL -> denganBukaKunci { panggilKontak(kandidat) }
            PerintahSuara.Jenis.PESAN -> denganBukaKunci { bukaPesan(kandidat, baca = false) }
            PerintahSuara.Jenis.BACA_PESAN -> denganBukaKunci { bacaPesanTersimpan(kandidat) }
            PerintahSuara.Jenis.CARI_PESAN -> denganBukaKunci { cariPesanKontak(kandidat) }
            PerintahSuara.Jenis.BUKA_APLIKASI -> denganBukaKunci { bukaAplikasiDisebut(kandidat) }
            PerintahSuara.Jenis.LIBUR_SPESIFIK -> bacakanKhusus { p, c -> HariLibur.jawabanKhusus(applicationContext, p, PerintahSuara.kategoriLibur(kandidat), PerintahSuara.periodeLibur(kandidat), c) }
            PerintahSuara.Jenis.TIDAK_DIKENAL -> {
                val didengar = kandidat.firstOrNull().orEmpty()
                getar(300L)
                Toast.makeText(
                    this,
                    getString(R.string.perintah_suara_tidak_dikenal) + (if (didengar.isNotBlank()) " (\"" + didengar + "\")" else ""),
                    Toast.LENGTH_LONG
                ).show()
                tutupDanLanjutAudio()
            }
        }
    }

    /** Mengenali salam, sapaan, ucapan terima kasih, dan perpisahan dalam bahasa aktif. */
    private fun tanganiUcapanSosial(kandidat: List<String>): Boolean {
        val teks = kandidat.map { ucapan ->
            ucapan.lowercase(java.util.Locale.ROOT)
                .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
                .replace(Regex("\\s+"), " ").trim()
        }.filter { it.isNotBlank() }
        if (teks.isEmpty()) return false

        val salamIslam = teks.any { u ->
            u.contains("assalamualaikum") || u.contains("assalamu alaikum") ||
                u.contains("asalamualaikum") || u.contains("assalamuallaikum") ||
                u.contains("السلام عليكم") || u.contains("salamualaikum") ||
                u == "salam" || u.startsWith("salam ")
        }
        val sapaanPagi = teks.any { it.contains("selamat pagi") || it.contains("good morning") }
        val sapaanSiang = teks.any { it.contains("selamat siang") || it.contains("good afternoon") }
        val sapaanSore = teks.any { it.contains("selamat sore") || it.contains("good evening") }
        val sapaanMalam = teks.any { it.contains("selamat malam") || it.contains("good night") }
        val sapaanUmum = teks.any { u ->
            u == "halo" || u.startsWith("halo ") || u == "hai" || u.startsWith("hai ") ||
                u == "hello" || u.startsWith("hello ") || u == "hey" || u.startsWith("hey ") ||
                u.contains("jam pintar") || u.contains("apa kabar") || u.contains("how are you")
        }
        val terimaKasih = teks.any { u ->
            u.contains("terima kasih") || u.contains("makasih") || u.contains("thanks") ||
                u.contains("thank you") || u.contains("jazakallah") || u.contains("syukran")
        }
        val perpisahan = teks.any { u ->
            u.contains("selamat tinggal") || u.contains("sampai jumpa") || u.contains("dadah") ||
                u == "bye" || u.startsWith("goodbye") || u.contains("see you")
        }
        if (!salamIslam && !sapaanPagi && !sapaanSiang && !sapaanSore && !sapaanMalam &&
            !sapaanUmum && !terimaKasih && !perpisahan) return false

        val sambutanPertama = (salamIslam || sapaanPagi || sapaanSiang || sapaanSore || sapaanMalam || sapaanUmum) &&
            !getSharedPreferences("asisten_suara", MODE_PRIVATE).getBoolean("perkenalan_sudah_disampaikan", false)
        val kalimat = when {
            terimaKasih -> listOf(tr("Sama-sama.", "You're very welcome."), tr("Dengan senang hati saya membantu Anda.", "I'm happy to help you."))
            perpisahan -> listOf(tr("Selamat beraktivitas.", "Goodbye."), tr("Semoga hari Anda menyenangkan. Sampai jumpa kembali.", "May your day be pleasant. See you again."))
            else -> {
                val hasil = mutableListOf<String>()
                if (salamIslam) {
                    hasil += tr("Wa'alaikumussalam warahmatullahi wabarakatuh.", "Wa alaikum assalam wa rahmatullahi wa barakatuh.")
                } else if (sapaanPagi) {
                    hasil += tr("Selamat pagi. Semoga Anda sehat dan bersemangat hari ini.", "Good morning. I hope you are doing well.")
                } else if (sapaanSiang) {
                    hasil += tr("Selamat siang. Semoga aktivitas Anda berjalan lancar.", "Good afternoon. I hope you are doing well.")
                } else if (sapaanSore) {
                    hasil += tr("Selamat sore. Semoga hari Anda menyenangkan.", "Good afternoon. I hope your day is going well.")
                } else if (sapaanMalam) {
                    hasil += tr("Selamat malam. Semoga malam Anda tenang dan menyenangkan.", "Good evening. I hope you can relax and enjoy your evening.")
                } else {
                    hasil += tr("Halo. Selamat datang.", "Hello. Welcome.")
                }
                if (sambutanPertama) {
                    hasil += tr("Selamat datang di Jam Pintar Pro.", "Welcome to Jam Pintar Pro.")
                    hasil += tr("Perkenalkan, saya adalah asisten suara Jam Pintar Pro yang insya Allah selalu siap membantu Anda.",
                        "Allow me to introduce myself. I am the Jam Pintar Pro voice assistant, and God willing, I am always ready to help you.")
                    hasil += tr("Silakan sampaikan perintah atau pertanyaan Anda. Saya akan berusaha membantu menjalankan berbagai fitur yang tersedia di aplikasi ini.",
                        "Please tell me your commands or questions. I will do my best to help you use the features available in this application.")
                    hasil += tr("Ada yang bisa saya bantu?", "How may I help you today?")
                } else {
                    hasil += tr("Ada yang bisa saya bantu?", "How may I help you?")
                }
                hasil
            }
        }
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        try {
            val prefs = Prefs(applicationContext)
            val suara = Pembicara(applicationContext, prefs.suara("jam"))
                .also { it.bisaDibungkam = true; it.paksaBahasaTampilan = true }
            pembicaraTanggal = suara
            suara.ucapkanRangkaian(kalimat, 420L) {
                if (sambutanPertama) {
                    getSharedPreferences("asisten_suara", MODE_PRIVATE).edit()
                        .putBoolean("perkenalan_sudah_disampaikan", true).apply()
                }
                tutupDanLanjutAudio()
            }
        } catch (_: Exception) {
            tutupDanLanjutAudio()
        }
        return true
    }

    /** Membaca status baterai terkini atas permintaan langsung pengguna. */
    private fun bacakanBaterai() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = (intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        if (level < 0) {
            bacakanBateraiDenganSuara(tr("Status baterai saat ini belum tersedia.", "Battery status is currently unavailable."))
            return
        }
        val persen = (level * 100 / scale).coerceIn(0, 100)
        val mengisi = (intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val bahasa = BahasaAplikasi.tampilan(this)
        val statusBaterai = when (bahasa) {
            1 -> if (mengisi) ", and charging" else ", not charging"
            2 -> if (mengisi) "، وهي قيد الشحن" else "، وليست قيد الشحن"
            3 -> if (mengisi) ", lagi diisi" else ", ora lagi diisi"
            4 -> if (mengisi) ", keur dieusi" else ", henteu keur dieusi"
            else -> if (mengisi) tr(", dan sedang diisi daya", ", and charging") else tr(", tidak sedang diisi daya", ", not charging")
        }
        val teks = when (bahasa) {
            1 -> "Battery is $persen percent$statusBaterai."
            2 -> "مستوى البطارية $persen بالمئة$statusBaterai."
            3 -> "Baterei $persen persen$statusBaterai."
            4 -> "Batré $persen persén$statusBaterai."
            else -> "Baterai tersisa $persen persen$statusBaterai."
        }
        bacakanBateraiDenganSuara(teks)
    }

    private fun bacakanBateraiDenganSuara(teks: String) {
        try {
            val p = Prefs(applicationContext)
            val suara = Pembicara(applicationContext, p.suara("bat")).also {
                it.bisaDibungkam = true
                it.paksaBahasaTampilan = true
            }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    private fun pesanKosong(p: Prefs, jenis: String): String = when (p.bahasaAktif) {
        1 -> if (jenis == "holiday") "No holiday information is available." else "Prayer time information is unavailable. Check your prayer location and schedule."
        2 -> if (jenis == "holiday") "لا تتوفر معلومات عن العطلات." else "معلومات أوقات الصلاة غير متاحة. تحقق من الموقع والجدول."
        3 -> if (jenis == "holiday") "Informasi preinan dereng cumawis." else "Informasi wekdal salat dereng cumawis. Priksa lokasi lan jadwal salat."
        4 -> if (jenis == "holiday") "Inpormasi libur teu sayogi." else "Inpormasi waktos salat teu sayogi. Pariksa lokasi sareng jadwal salat."
        else -> if (jenis == "holiday") getString(R.string.perintah_kosong_libur) else getString(R.string.perintah_kosong_sholat)
    }

    /** Mengambil lokasi perangkat terkini; koordinat Jadwal Sholat menjadi cadangan bila lokasi langsung tidak tersedia. */
    private fun ambilLokasiUntukCuaca(selesaiLokasi: (android.location.Location?) -> Unit) {
        val izinFine = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val izinCoarse = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!izinFine && !izinCoarse) { selesaiLokasi(null); return }

        val manager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (manager == null) { selesaiLokasi(null); return }
        val penyedia = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { manager.isProviderEnabled(it) } catch (_: Exception) { false } }
        val sekarang = System.currentTimeMillis()
        var cache: android.location.Location? = null
        try {
            for (provider in penyedia) {
                val kandidat = try { manager.getLastKnownLocation(provider) } catch (_: Exception) { null }
                if (kandidat != null && kandidat.accuracy > 0f &&
                    sekarang - kandidat.time in 0L..300_000L &&
                    (cache == null || kandidat.accuracy < cache!!.accuracy)) cache = kandidat
            }
        } catch (_: SecurityException) { }
        if (cache != null && cache!!.accuracy <= 2_000f) { selesaiLokasi(cache); return }
        if (penyedia.isEmpty()) { selesaiLokasi(cache); return }

        var terbaik = cache
        var sudahSelesai = false
        lateinit var listener: android.location.LocationListener
        val timeout = Runnable {
            if (sudahSelesai) return@Runnable
            sudahSelesai = true
            try { manager.removeUpdates(listener) } catch (_: Exception) { }
            selesaiLokasi(terbaik)
        }
        listener = object : android.location.LocationListener {
            override fun onLocationChanged(location: android.location.Location) {
                if (sudahSelesai || location.accuracy <= 0f) return
                val lama = terbaik
                if (lama == null || location.accuracy < lama.accuracy ||
                    (location.accuracy <= lama.accuracy + 2f && location.time > lama.time)) terbaik = location
                // Satu pembacaan langsung yang wajar sudah cukup untuk permintaan cuaca.
                if (location.accuracy <= 2_000f) {
                    sudahSelesai = true
                    handler.removeCallbacks(timeout)
                    try { manager.removeUpdates(this) } catch (_: Exception) { }
                    selesaiLokasi(location)
                }
            }
            @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            var diminta = false
            for (provider in penyedia) {
                if (sudahSelesai) break
                try {
                    manager.requestLocationUpdates(provider, 1_000L, 0f, listener, Looper.getMainLooper())
                    diminta = true
                } catch (_: Exception) { }
            }
            if (!diminta) { selesaiLokasi(terbaik); return }
            handler.postDelayed(timeout, 12_000L)
        } catch (_: SecurityException) {
            selesaiLokasi(terbaik)
        }
    }

    /** Sumber cadangan cuaca tanpa kunci API. Dipakai bila host Open-Meteo tidak dapat dijangkau. */
    private fun cobaCuacaCadanganWttr(
        lat: Double,
        lon: Double,
        bahasa: Int,
        namaTempat: String?
    ): String? {
        var koneksi: HttpURLConnection? = null
        return try {
            val alamat = "https://wttr.in/$lat,$lon?format=j1"
            val conn = (URL(alamat).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 10_000
                useCaches = false
                instanceFollowRedirects = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) JamPintarPro/1.0.82")
            }
            koneksi = conn
            val status = conn.responseCode
            if (status !in 200..299) return null
            val json = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val kondisi = json.optJSONArray("current_condition")?.optJSONObject(0) ?: return null
            val suhu = kondisi.optString("temp_C").toDoubleOrNull() ?: return null
            val terasa = kondisi.optString("FeelsLikeC").toDoubleOrNull()
            val lembap = kondisi.optString("humidity").toIntOrNull()
            val angin = kondisi.optString("windspeedKmph").toIntOrNull()
            val deskripsi = kondisi.optJSONArray("weatherDesc")?.optJSONObject(0)?.optString("value")?.trim().orEmpty()
            // Nama daerah sebenarnya (kelurahan/kecamatan/kota); bila belum diperoleh, pakai nama area dari wttr.in.
            val areaWttr = json.optJSONArray("nearest_area")?.optJSONObject(0)?.optJSONArray("areaName")?.optJSONObject(0)?.optString("value")?.trim().orEmpty()
            val namaLokasi = namaTempat?.takeIf { it.isNotBlank() } ?: areaWttr.ifBlank { tr("lokasi Anda saat ini", "your current location") }
            val deskripsiTampil = deskripsi.ifBlank { tr("kondisi cuaca saat ini", "current conditions") }
            buildString {
                // Kalimat disusun dengan penyambungan teks (tanpa templat dolar) agar tidak pernah terbaca sebagai simbol dolar.
                append(tr("Cuaca terkini di " + namaLokasi + ": " + deskripsiTampil + ". Suhu " + suhu.toInt() + " derajat Celsius.",
                    "Current weather for " + namaLokasi + ": " + deskripsiTampil + ". Temperature " + suhu.toInt() + " degrees Celsius."))
                if (terasa != null) append(tr(" Terasa seperti " + terasa.toInt() + " derajat.", " Feels like " + terasa.toInt() + " degrees."))
                if (lembap != null) append(tr(" Kelembapan " + lembap + " persen.", " Humidity " + lembap + " percent."))
                if (angin != null) append(tr(" Kecepatan angin " + angin + " kilometer per jam.", " Wind speed " + angin + " kilometers per hour."))
                append(tr(" Data cadangan dari wttr.in.", " Backup weather data provided by wttr.in."))
            }
        } catch (_: Exception) {
            null
        } finally {
            try { koneksi?.disconnect() } catch (_: Exception) { }
        }
    }

    /**
     * Nama daerah untuk diucapkan pada informasi cuaca (kelurahan/kecamatan, kota, provinsi) menurut bahasa aktif.
     * Blokir: panggil dari thread latar. Urutan: nama tersimpan yang spesifik (untuk lokasi tersimpan), Geocoder perangkat,
     * lalu layanan geokode cadangan BigDataCloud. Null bila semuanya gagal; pemanggil memakai kalimat umum.
     */
    private fun namaTempatCuaca(lat: Double, lon: Double, lokasiLangsung: Boolean, pp: PrayerPrefs, bahasa: Int): String? {
        val kode = if (bahasa == 1) "en" else "id"
        if (!lokasiLangsung && pp.locationSet && !NamaLokasi.belumSpesifik(pp.place)) {
            val tersimpan = NamaLokasi.nama(applicationContext, pp, if (bahasa == 1) 1 else 0)
            if (tersimpan.isNotBlank()) return tersimpan
        }
        NamaLokasi.cari(applicationContext, lat, lon, kode)?.takeIf { it.isNotBlank() }?.let { return it }
        var koneksi: HttpURLConnection? = null
        return try {
            val alamat = "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=" + lat + "&longitude=" + lon + "&localityLanguage=" + kode
            val c = (URL(alamat).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 6_000; readTimeout = 8_000; useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            koneksi = c
            if (c.responseCode !in 200..299) return null
            val o = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            listOf(o.optString("locality"), o.optString("city"), o.optString("principalSubdivision"))
                .map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(3)
                .joinToString(", ").ifBlank { null }
        } catch (_: Exception) {
            null
        } finally {
            try { koneksi?.disconnect() } catch (_: Exception) { }
        }
    }

    /** Membacakan cuaca terkini; Open-Meteo menjadi sumber utama dan wttr.in sumber cadangan. */
    private fun bacakanCuaca() {
        val bahasa = BahasaAplikasi.tampilan(this)
        val pp = PrayerPrefs(applicationContext)
        val lokasiTersimpanValid = pp.locationSet && pp.lat in -90.0..90.0 && pp.lon in -180.0..180.0 && !(pp.lat == 0.0 && pp.lon == 0.0)
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        ambilLokasiUntukCuaca { lokasiLangsung ->
            if (selesai || isFinishing) return@ambilLokasiUntukCuaca
            val lat = lokasiLangsung?.latitude ?: if (lokasiTersimpanValid) pp.lat else Double.NaN
            val lon = lokasiLangsung?.longitude ?: if (lokasiTersimpanValid) pp.lon else Double.NaN
            if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
                val pesan = tr(
                    "Lokasi perangkat belum berhasil diperoleh. Pastikan izin dan layanan lokasi aktif, atau atur lokasi pada Pengaturan Jadwal Sholat, lalu coba lagi.",
                    "The device location could not be obtained. Make sure location permission and location services are enabled, or set a location in Prayer Schedule Settings, then try again."
                )
                bacakanTeksBahasaTampilan(pesan)
                return@ambilLokasiUntukCuaca
            }
            Thread {
                // Nama daerah dicari dari koordinat yang dipakai (lokasi aktif); gagal mencari tidak menggagalkan cuaca.
                val namaTempat: String? = try { namaTempatCuaca(lat, lon, lokasiLangsung != null, pp, bahasa) } catch (_: Exception) { null }
                val hasil = try {
                    val alamat = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto"
                    val koneksi = (URL(alamat).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 15_000
                        readTimeout = 20_000
                        useCaches = false
                        instanceFollowRedirects = true
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("Cache-Control", "no-cache")
                        setRequestProperty("User-Agent", "JamPintarPro/1.0.82 (Android)")
                    }
                    try {
                        val kodeHttp = koneksi.responseCode
                        if (kodeHttp !in 200..299) {
                            // Bedakan penolakan server (mis. 429/5xx) dari gangguan jaringan perangkat.
                            throw java.io.IOException("HTTP_STATUS:$kodeHttp")
                        }
                        val isi = koneksi.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val json = JSONObject(isi)
                        val now = json.optJSONObject("current")
                            ?: throw org.json.JSONException("Missing current data")
                        val suhu = now.optDouble("temperature_2m", Double.NaN)
                        val terasa = now.optDouble("apparent_temperature", Double.NaN)
                        val lembap = now.optInt("relative_humidity_2m", -1)
                        val angin = now.optDouble("wind_speed_10m", Double.NaN)
                        val kode = now.optInt("weather_code", -1)
                        if (!suhu.isFinite()) throw org.json.JSONException("Invalid temperature")
                        val lokasiNama = namaTempat?.takeIf { it.isNotBlank() } ?: tr("lokasi Anda saat ini", "your current location")
                        buildString {
                            val kondisiTeks = kondisiCuaca(kode, bahasa)
                            append(tr("Cuaca terkini di " + lokasiNama + ": " + kondisiTeks + ". Suhu " + suhu.toInt() + " derajat Celsius.",
                                "Current weather for " + lokasiNama + ": " + kondisiTeks + ". Temperature " + suhu.toInt() + " degrees Celsius."))
                            if (terasa.isFinite()) append(tr(" Terasa seperti " + terasa.toInt() + " derajat.", " Feels like " + terasa.toInt() + " degrees."))
                            if (lembap in 0..100) append(tr(" Kelembapan " + lembap + " persen.", " Humidity " + lembap + " percent."))
                            if (angin.isFinite()) append(tr(" Kecepatan angin " + angin.toInt() + " kilometer per jam.", " Wind speed " + angin.toInt() + " kilometers per hour."))
                            append(tr(" Data cuaca dari Open-Meteo.", " Weather data provided by Open-Meteo."))
                        }
                    } finally { koneksi.disconnect() }
                } catch (e: java.net.SocketTimeoutException) {
                    cobaCuacaCadanganWttr(lat, lon, bahasa, namaTempat)
                        ?: tr("Permintaan data cuaca utama melewati batas waktu dan sumber cadangan belum dapat dijangkau. Coba kembali beberapa saat lagi.", "The primary weather request timed out and the backup source could not be reached. Please try again shortly.")
                } catch (e: java.io.IOException) {
                    cobaCuacaCadanganWttr(lat, lon, bahasa, namaTempat) ?: run {
                    val detail = e.message.orEmpty()
                    when {
                        detail.startsWith("HTTP_STATUS:") -> {
                            val status = detail.substringAfter(':').toIntOrNull() ?: -1
                            when {
                                status == 429 -> tr("Layanan cuaca sedang membatasi jumlah permintaan. Tunggu sebentar, lalu coba kembali.", "The weather service is rate-limiting requests. Wait briefly, then try again.")
                                status in 500..599 -> tr("Server penyedia cuaca sedang mengalami gangguan. Koneksi internet ponsel Anda belum tentu bermasalah. Silakan coba kembali nanti.", "The weather provider's server is temporarily unavailable. Your phone's internet connection may be working normally. Please try again later.")
                                status in 400..499 -> tr("Permintaan cuaca ditolak oleh server (kode " + status + "). Periksa versi aplikasi atau coba kembali nanti.", "The weather request was rejected by the server (code " + status + "). Check the app version or try again later.")
                                else -> tr("Server cuaca memberikan respons yang tidak berhasil. Silakan coba kembali nanti.", "The weather server returned an unsuccessful response. Please try again later.")
                            }
                        }
                        e is java.net.UnknownHostException -> tr("Nama server cuaca tidak dapat ditemukan. Ini dapat disebabkan DNS atau pemblokiran alamat layanan, bukan selalu karena koneksi internet terputus.", "The weather server address could not be resolved. This may be caused by DNS or service-address blocking, not necessarily a disconnected internet connection.")
                        e is javax.net.ssl.SSLException -> tr("Sambungan aman ke layanan cuaca gagal dibuat. Periksa tanggal dan waktu perangkat, lalu coba kembali.", "A secure connection to the weather service could not be established. Check the device date and time, then try again.")
                        e is java.net.SocketException -> tr("Sambungan ke server cuaca terputus sebelum data diterima. Internet ponsel mungkin tetap aktif; coba kembali.", "The connection to the weather server was interrupted before data arrived. Your phone's internet may still be active; please try again.")
                        else -> tr("Sumber cuaca utama dan cadangan tidak dapat dijangkau. Koneksi internet ponsel belum tentu bermasalah; layanan cuaca mungkin sedang membatasi atau menolak permintaan.", "Neither the primary nor backup weather source could be reached. Your phone's internet may still be working; the weather services may be limiting or rejecting requests.")
                    }
                    }
                } catch (_: Exception) {
                    cobaCuacaCadanganWttr(lat, lon, bahasa, namaTempat)
                        ?: tr("Data dari sumber cuaca utama tidak dapat dibaca dan sumber cadangan belum tersedia. Silakan coba kembali nanti.", "The primary weather data could not be read and the backup source is unavailable. Please try again later.")
                }
                runOnUiThread { if (!isFinishing && !selesai) bacakanTeksBahasaTampilan(hasil) }
            }.start()
        }
    }

    private fun bacakanTeksBahasaTampilan(teks: String) {
        try {
            val prefs = Prefs(applicationContext)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also {
                it.bisaDibungkam = true
                it.paksaBahasaTampilan = true
            }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    private fun kondisiCuaca(kode: Int, bahasa: Int): String {
        val id = when (kode) {
            0 -> "cerah"; 1 -> "umumnya cerah"; 2 -> "cerah berawan"; 3 -> "berawan"; 45, 48 -> "berkabut"
            51, 53, 55 -> "gerimis"; 56, 57 -> "gerimis membeku"; 61, 63, 65 -> "hujan"; 66, 67 -> "hujan membeku"
            71, 73, 75, 77 -> "salju"; 80, 81, 82 -> "hujan lokal"; 85, 86 -> "hujan salju"; 95, 96, 99 -> "badai petir"
            else -> tr("kondisi cuaca tidak diketahui", "unknown weather conditions")
        }
        if (bahasa != 1) return id
        return when (kode) {
            0 -> "clear sky"; 1 -> "mainly clear"; 2 -> "partly cloudy"; 3 -> "overcast"; 45, 48 -> "foggy"
            51, 53, 55 -> "drizzle"; 56, 57 -> "freezing drizzle"; 61, 63, 65 -> "rain"; 66, 67 -> "freezing rain"
            71, 73, 75, 77 -> "snow"; 80, 81, 82 -> "rain showers"; 85, 86 -> "snow showers"; 95, 96, 99 -> "thunderstorm"
            else -> "unknown weather conditions"
        }
    }

    /** Satu perintah spesifik menghasilkan satu jawaban saja; tidak menambahkan rangkaian tanggal/libur/sholat lain. */
    private fun bacakanKhusus(penyusun: (Prefs, Calendar) -> String) {
        try {
            val prefs = Prefs(applicationContext)
            val teks = penyusun(prefs, Calendar.getInstance()).trim()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true; it.paksaBahasaTampilan = true }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    /** Waktu dibacakan suara jam; tanggal umum mengikuti pengaturan rangkaian pengguna. */
    /** [lengkap] false: hanya waktu dan/atau tanggal kalender yang diminta; true: seluruh rangkaian (termasuk libur dan salat). */
    private fun bacakan(waktu: Boolean, tanggal: Boolean, lengkap: Boolean = false) {
        try {
            val prefs = Prefs(applicationContext)
            val c = Calendar.getInstance()
            val teksWaktu = if (waktu) JamWaktu.ucapan(prefs, c) else ""
            val segmenTanggal = if (!tanggal) emptyList() else if (lengkap) JamWaktu.segmenTanggal(prefs, c) else JamWaktu.segmenKalender(prefs, c)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            fun bacaTanggal() {
                if (segmenTanggal.isEmpty()) { tutupDanLanjutAudio(); return }
                val pt = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
                pembicaraTanggal = pt
                pt.ucapkanRangkaian(segmenTanggal, 300L) { tutupDanLanjutAudio() }
            }
            if (teksWaktu.isBlank()) {
                bacaTanggal()
            } else {
                val p = Pembicara(applicationContext, prefs.suara("jam")).also { it.bisaDibungkam = true }
                pembicara = p
                p.ucapkan(teksWaktu, true) { bacaTanggal() }
            }
        } catch (_: Exception) {
            tutup()
        }
    }

    /**
     * Menjalankan kontrol perangkat yang diminta melalui panel/halaman resmi Android.
     * Jika layanan aksesibilitas aktif, layanan menekan dan memverifikasi sakelar yang
     * cocok dengan perangkat serta status yang diminta. Tanpa layanan, halaman sistem
     * tetap dibuka dan pengguna dapat mengubah sakelar secara manual.
     */
    private fun kendaliTimer(kandidat: List<String>) {
        val teks = kandidat.joinToString(" ").lowercase(java.util.Locale.ROOT)
        val p = Prefs(applicationContext)
        fun jawab(kalimat: String) {
            try {
                val suara = Pembicara(applicationContext, p.suara("jam")).also { it.bisaDibungkam = true }
                pembicaraTanggal = suara
                suara.ucapkan(kalimat, true) { tutupDanLanjutAudio() }
            } catch (_: Exception) { tutupDanLanjutAudio() }
        }
        when {
            teks.contains("jeda") || teks.contains("pause") -> {
                if (TimerJamService.status(this) == TimerJamService.STATE_RUNNING) {
                    TimerJamService.kirim(this, TimerJamService.ACTION_JEDA)
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer paused." else "Timer dijeda.")
                } else jawab(if (BahasaAplikasi.tampilan(this) == 1) "There is no running timer to pause." else "Tidak ada timer yang sedang berjalan untuk dijeda.")
            }
            teks.contains("lanjut") || teks.contains("resume") || teks.contains("continue") -> {
                if (TimerJamService.status(this) == TimerJamService.STATE_PAUSED) {
                    TimerJamService.kirim(this, TimerJamService.ACTION_LANJUT)
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer resumed." else "Timer dilanjutkan.")
                } else jawab(if (BahasaAplikasi.tampilan(this) == 1) "There is no paused timer." else "Tidak ada timer yang sedang dijeda.")
            }
            teks.contains("sisa") || teks.contains("remaining") || teks.contains("berapa") || teks.contains("how much") -> {
                if (TimerJamService.status(this) == TimerJamService.STATE_IDLE) {
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "There is no active timer." else "Tidak ada timer yang sedang aktif.")
                    return
                }
                val s = (TimerJamService.sisa(this) + 999L) / 1000L
                val h = s / 3600L; val m = s % 3600L / 60L; val d = s % 60L
                val durasi = buildList { if (h > 0) add("$h " + if (BahasaAplikasi.tampilan(this@PerintahSuaraActivity) == 1) "hours" else "jam"); if (m > 0) add("$m " + if (BahasaAplikasi.tampilan(this@PerintahSuaraActivity) == 1) "minutes" else "menit"); if (d > 0 || isEmpty()) add("$d " + if (BahasaAplikasi.tampilan(this@PerintahSuaraActivity) == 1) "seconds" else "detik") }.joinToString(" ")
                jawab(if (BahasaAplikasi.tampilan(this) == 1) "Time remaining: $durasi." else "Sisa waktu timer: $durasi.")
            }
            teks.contains("reset") || teks.contains("ulang") || teks.contains("hentikan") || teks.contains("matikan") || teks.contains("stop") -> {
                TimerJamService.kirim(this, if (TimerJamService.status(this) == TimerJamService.STATE_ALARM) TimerJamService.ACTION_STOP_ALARM else TimerJamService.ACTION_RESET)
                jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer stopped and reset." else "Timer dihentikan dan direset.")
            }
            else -> {
                val durasi = PerintahSuara.durasiTimerDetik(kandidat)
                if (durasi <= 0L) {
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Please say a duration, for example: set a timer for five minutes." else "Sebutkan durasinya, misalnya: pasang timer lima menit.")
                } else {
                    val pengaturan = getSharedPreferences("timer_jam", MODE_PRIVATE)
                    TimerJamService.kirim(this, TimerJamService.ACTION_MULAI, durasi * 1000L, pengaturan.getInt("mode", 2), pengaturan.getBoolean("pengumuman", true))
                    val jam = durasi / 3600L; val menit = durasi % 3600L / 60L; val detik = durasi % 60L
                    val inggris = BahasaAplikasi.tampilan(this) == 1
                    val lama = (if (jam > 0) "$jam " + if (inggris) "hours " else "jam " else "") +
                        (if (menit > 0) "$menit " + if (inggris) "minutes " else "menit " else "") +
                        (if (detik > 0) "$detik " + if (inggris) "seconds" else "detik" else "")
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer started for $lama." else "Timer dimulai selama $lama.")
                }
            }
        }
    }

    private fun bukaPengaturanPerangkat(kontrol: PerintahSuara.KontrolPerangkat?) {
        if (kontrol == null) {
            Toast.makeText(this, getString(R.string.perintah_perangkat_tidak_dikenal), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
            return
        }
        val namaRes = when (kontrol.jenis) {
            PerintahSuara.JenisPerangkat.BLUETOOTH -> R.string.perintah_perangkat_bluetooth
            PerintahSuara.JenisPerangkat.WIFI -> R.string.perintah_perangkat_wifi
            PerintahSuara.JenisPerangkat.HOTSPOT -> R.string.perintah_perangkat_hotspot
            PerintahSuara.JenisPerangkat.DATA_SELULER -> R.string.perintah_perangkat_data
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> R.string.perintah_perangkat_pesawat
            PerintahSuara.JenisPerangkat.LOKASI -> R.string.perintah_perangkat_lokasi
            PerintahSuara.JenisPerangkat.NFC -> R.string.perintah_perangkat_nfc
        }
        val aksiRes = if (kontrol.aktif) R.string.perintah_perangkat_aktifkan else R.string.perintah_perangkat_matikan
        // FIX138: semua sakelar yang didukung dioperasikan melalui layanan aksesibilitas
        // setelah pengguna mengucapkan perintah secara eksplisit. Android modern membatasi
        // perubahan langsung melalui API aplikasi biasa; gunakan panel/halaman resmi sistem.
        val dapatOtomatis = layananAksesibilitasPanggilanAktif()
        val intent = when (kontrol.jenis) {
            PerintahSuara.JenisPerangkat.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            PerintahSuara.JenisPerangkat.WIFI -> if (!dapatOtomatis && Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
            PerintahSuara.JenisPerangkat.HOTSPOT -> Intent("android.settings.TETHER_SETTINGS")
            PerintahSuara.JenisPerangkat.DATA_SELULER -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_DATA_USAGE_SETTINGS)
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            PerintahSuara.JenisPerangkat.LOKASI -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            PerintahSuara.JenisPerangkat.NFC -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_NFC) else Intent("android.settings.NFC_SETTINGS")
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (dapatOtomatis) siapkanKontrolOtomatis(kontrol)
            startActivity(intent)
            if (dapatOtomatis) {
                Toast.makeText(this, getString(R.string.perintah_perangkat_otomatis, getString(aksiRes), getString(namaRes)), Toast.LENGTH_LONG).show()
            } else {
                var pesan = getString(R.string.perintah_perangkat_selesai, getString(aksiRes), getString(namaRes))
                pesan += " " + getString(R.string.perintah_perangkat_aksesibilitas)
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS_PERANGKAT, MODE_PRIVATE).edit().clear().apply()
            try {
                val cadangan = if (kontrol.jenis == PerintahSuara.JenisPerangkat.HOTSPOT) Intent(Settings.ACTION_WIRELESS_SETTINGS) else Intent(Settings.ACTION_SETTINGS)
                startActivity(cadangan.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Toast.makeText(this, getString(R.string.perintah_perangkat_pengaturan_umum), Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            }
        }
        tutupDanLanjutAudio()
    }

    /** FIX138: catat permintaan agar layanan aksesibilitas menekan sakelar perangkat yang diminta. */
    private fun siapkanKontrolOtomatis(kontrol: PerintahSuara.KontrolPerangkat) {
        getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS_PERANGKAT, MODE_PRIVATE).edit().clear()
            .putString(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_JENIS, when (kontrol.jenis) {
                PerintahSuara.JenisPerangkat.BLUETOOTH -> "bluetooth"
                PerintahSuara.JenisPerangkat.LOKASI -> "lokasi"
                PerintahSuara.JenisPerangkat.HOTSPOT -> "hotspot"
                PerintahSuara.JenisPerangkat.DATA_SELULER -> "data_seluler"
                PerintahSuara.JenisPerangkat.MODE_PESAWAT -> "pesawat"
                PerintahSuara.JenisPerangkat.NFC -> "nfc"
                PerintahSuara.JenisPerangkat.WIFI -> "wifi"
            })
            .putInt(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_TAHAP, 0)
            .putBoolean(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_AKTIF, kontrol.aktif)
            .putLong(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_DIBUAT, System.currentTimeMillis())
            .putInt(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_PERCOBAAN, 0)
            .putBoolean(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_PENDING, true)
            .apply()
    }

    /** Membuka halaman fitur yang diminta secara langsung, tanpa menebak fitur lain. */
    private fun bukaFitur(fitur: PerintahSuara.Fitur?) {
        val tujuan = when (fitur) {
            PerintahSuara.Fitur.BATERAI -> BateraiActivity::class.java
            PerintahSuara.Fitur.JAM -> JamActivity::class.java
            PerintahSuara.Fitur.KALENDER -> KalenderActivity::class.java
            PerintahSuara.Fitur.PEMANGGIL -> PemanggilActivity::class.java
            PerintahSuara.Fitur.SHOLAT -> PrayerActivity::class.java
            PerintahSuara.Fitur.LOKASI -> LokasiTerkiniActivity::class.java
            PerintahSuara.Fitur.PEMANDU_JALAN -> PemanduJalanActivity::class.java
            PerintahSuara.Fitur.KIBLAT -> QiblaActivity::class.java
            PerintahSuara.Fitur.FASILITAS -> FasilitasTerdekatActivity::class.java
            PerintahSuara.Fitur.DOA -> TaarufDoaActivity::class.java
            PerintahSuara.Fitur.KHATAM -> KhatamActivity::class.java
            PerintahSuara.Fitur.MODE_ACARA -> ModeAcaraActivity::class.java
            PerintahSuara.Fitur.BAHASA -> BahasaActivity::class.java
            null -> null
        }
        if (tujuan == null) {
            val bahasa = Prefs(applicationContext).bahasaAktif
            val pesan = when (bahasa) {
                1 -> "I couldn't identify which app feature you meant. Please say the feature name."
                2 -> "لم أتمكن من تحديد الميزة المطلوبة. يرجى ذكر اسم الميزة."
                3 -> "Fitur ingkang dipun kersakaken dereng saged dipun mangertosi. Sebutaken nami fituripun."
                4 -> "Fitur anu dimaksud teu kahartos. Sebutkeun nami fiturna."
                else -> getString(R.string.perintah_fitur_tidak_dikenal)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            tutup()
            return
        }
        try { startActivity(Intent(this, tujuan)) } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }


    /**
     * Menafsirkan tujuan dan kanal panggilan dari perintah yang diucapkan.
     * Telepon seluler dapat langsung dimulai setelah izin CALL_PHONE diberikan;
     * WhatsApp diarahkan ke chat kontak karena WhatsApp tidak menyediakan API publik
     * untuk memulai panggilan suara/video dari aplikasi pihak ketiga.
     */
    private fun panggilKontak(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty()
        aturSaluranPanggilan(ucapan)
        aturJenisPanggilanWhatsApp(ucapan)
        val tujuan = ekstrakTujuanPanggilan(ucapan)
        if (tujuan.isBlank()) {
            menungguNamaKontak = true
            Toast.makeText(this, petunjukNamaKontak(), Toast.LENGTH_LONG).show()
            handler.postDelayed({
                if (!isFinishing && !selesai && menungguNamaKontak) bukaPengenalan(false, petunjukNamaKontak())
            }, 350L)
            return
        }
        prosesTujuanPanggilan(listOf(tujuan))
    }

    private fun aturSaluranPanggilan(ucapan: String) {
        val t = ucapan.lowercase()
        saluranPanggilan = when {
            t.contains("whatsapp business") || t.contains("wa bisnis") || t.contains("whatsapp bisnis") -> SaluranPanggilan.WHATSAPP_BUSINESS
            t.contains("whatsapp") || Regex("\\bwa\\b").containsMatchIn(t) -> SaluranPanggilan.WHATSAPP
            else -> saluranPanggilan
        }
    }

    private fun aturJenisPanggilanWhatsApp(ucapan: String) {
        val t = ucapan.lowercase()
        jenisPanggilanWhatsApp = when {
            listOf("video", "vidio", "video call", "panggilan video").any { t.contains(it) } -> "video"
            listOf("suara", "voice", "audio", "panggilan suara").any { t.contains(it) } -> "voice"
            else -> jenisPanggilanWhatsApp
        }
    }

    private fun petunjukJenisPanggilanWhatsApp(): String = when (Prefs(applicationContext).bahasaAktif) {
        1 -> "Say 'voice call' or 'video call'."
        2 -> "قل: مكالمة صوتية أو مكالمة فيديو."
        3 -> "Sebutna 'telpon swara' utawa 'telpon video'."
        4 -> "Ucapkeun 'telepon sora' atanapi 'telepon vidéo'."
        else -> getString(R.string.perintah_panggilan_jenis)
    }

    private fun petunjukNamaKontak(): String = when (Prefs(applicationContext).bahasaAktif) {
        1 -> "Say the contact name or phone number."
        2 -> "اذكر اسم جهة الاتصال أو رقم الهاتف."
        3 -> "Sebutna asma kontak utawa nomer telpon."
        4 -> "Sebutkeun nami kontak atanapi nomer telepon."
        else -> getString(R.string.perintah_panggilan_kontak)
    }

    private fun ekstrakTujuanPanggilan(ucapan: String): String {
        return ucapan.trim().replace(
            Regex("(?i)\\b(tolong|silakan|please|call|telepon|telpon|panggil|hubungi|kontak|nomor|nomer|saya|aku|ke|untuk|via|melalui|whatsapp|business|bisnis|wa|suara|video|vidio|voice|audio)\\b"),
            " "
        ).replace(Regex("\\s+"), " ").trim()
    }

    private data class TujuanKontak(val nama: String, val nomor: String)

    private fun cariPilihanKontak(kataKunci: String): List<TujuanKontak> {
        val hasil = mutableListOf<TujuanKontak>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val proyeksi = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        try {
            contentResolver.query(uri, proyeksi, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
                val idxNama = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val idxNomor = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext() && hasil.size < 30) {
                    val nama = if (idxNama >= 0) c.getString(idxNama).orEmpty() else ""
                    val nomor = if (idxNomor >= 0) c.getString(idxNomor).orEmpty() else ""
                    if (nama.contains(kataKunci, ignoreCase = true) && nomor.isNotBlank() && hasil.none { it.nomor == nomor }) hasil += TujuanKontak(nama, nomor)
                }
            }
        } catch (_: SecurityException) { }
        return hasil
    }

    private fun tampilkanPilihanKontak(pilihan: List<TujuanKontak>) {
        val label = pilihan.map { it.nama + ", " + it.nomor }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.perintah_panggilan_pilih_kontak))
            .setItems(label) { _, which -> if (which in pilihan.indices) jalankanSaluranPanggilan(pilihan[which].nomor) }
            .setOnCancelListener { tutup() }
            .show()
    }

    private fun prosesTujuanPanggilan(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty()
        aturSaluranPanggilan(ucapan)
        aturJenisPanggilanWhatsApp(ucapan)
        val tujuan = ekstrakTujuanPanggilan(ucapan)
        val nomorLangsung = tujuan.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
        if (nomorLangsung.count { it.isDigit() } >= 3) {
            jalankanSaluranPanggilan(nomorLangsung)
            return
        }
        if (tujuan.isBlank()) {
            Toast.makeText(this, petunjukNamaKontak(), Toast.LENGTH_LONG).show()
            tutup()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ucapanKontakTertunda = tujuan
            requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), PERMINTAAN_KONTAK)
            return
        }
        val cocok = cariPilihanKontak(tujuan)
        when (cocok.size) {
            0 -> {
                val pesan = when (Prefs(applicationContext).bahasaAktif) {
                    1 -> "Contact not found. Check the name or say the phone number."
                    2 -> "لم يتم العثور على جهة الاتصال. تحقق من الاسم أو اذكر رقم الهاتف."
                    3 -> "Kontak ora ditemokake. Priksa jeneng utawa sebutna nomer telpon."
                    4 -> "Kontak teu kapendak. Pariksa nami atanapi sebutkeun nomor telepon."
                    else -> getString(R.string.perintah_panggilan_kontak_tidak_ditemukan)
                }
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
                tutup()
            }
            1 -> jalankanSaluranPanggilan(cocok.first().nomor)
            else -> tampilkanPilihanKontak(cocok)
        }
    }

    private fun jalankanSaluranPanggilan(nomor: String) {
        when (saluranPanggilan) {
            SaluranPanggilan.SELULER -> mulaiPanggilanSeluler(nomor)
            SaluranPanggilan.WHATSAPP, SaluranPanggilan.WHATSAPP_BUSINESS -> {
                if (jenisPanggilanWhatsApp.isNullOrBlank()) {
                    nomorPanggilanTertunda = nomor
                    menungguJenisPanggilanWhatsApp = true
                    Toast.makeText(this, petunjukJenisPanggilanWhatsApp(), Toast.LENGTH_LONG).show()
                    bukaPengenalan(false, petunjukJenisPanggilanWhatsApp())
                } else {
                    val paket = if (saluranPanggilan == SaluranPanggilan.WHATSAPP_BUSINESS) "com.whatsapp.w4b" else "com.whatsapp"
                    bukaChatWhatsApp(nomor, paket, jenisPanggilanWhatsApp!!)
                }
            }
        }
    }

    private fun layananAksesibilitasPanggilanAktif(): Boolean {
        val komponen = ComponentName(this, PanggilanWhatsAppAccessibilityService::class.java).flattenToString()
        val aktif = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        return aktif.split(':').any { it.equals(komponen, ignoreCase = true) }
    }

    private fun bukaChatWhatsApp(nomor: String, paket: String, jenis: String) {
        if (!layananAksesibilitasPanggilanAktif()) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Enable Jam Pintar Pro call assistance in Android Accessibility settings, then repeat the voice command. This is needed to operate WhatsApp's call controls."
                2 -> "فعّل خدمة مساعدة المكالمات في إعدادات إمكانية الوصول بنظام Android، ثم أعد الأمر الصوتي."
                3 -> "Aktifna layanan pitulungan panggilan Jam Pintar Pro ing setelan Aksesibilitas Android, banjur baleni printah swara."
                4 -> "Aktipkeun jasa bantuan telepon Jam Pintar Pro dina setélan Aksesibilitas Android, teras ucapkeun deui paréntahna."
                else -> getString(R.string.perintah_panggilan_aksesibilitas)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) { }
            tutup()
            return
        }
        var digit = nomor.filter { it.isDigit() }
        if (digit.startsWith("0")) digit = "62" + digit.drop(1)
        else if (digit.startsWith("8")) digit = "62" + digit
        if (digit.isBlank()) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            tutup(); return
        }
        try {
            // Intent eksplisit dibatasi pada aplikasi yang diminta. Layanan aksesibilitas hanya
            // bertindak setelah pengguna menyebutkan jenis panggilan (suara/video).
            getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS, MODE_PRIVATE).edit()
                .putString(PanggilanWhatsAppAccessibilityService.KEY_PACKAGE, paket)
                .putString(PanggilanWhatsAppAccessibilityService.KEY_TYPE, jenis)
                .putLong(PanggilanWhatsAppAccessibilityService.KEY_CREATED, System.currentTimeMillis())
                .putInt(PanggilanWhatsAppAccessibilityService.KEY_STAGE, 0)
                .putBoolean(PanggilanWhatsAppAccessibilityService.KEY_PENDING, true)
                .apply()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digit)).setPackage(paket)
            startActivity(intent)
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Opening the selected WhatsApp chat. Call assistance will select the requested " + jenis + " call if WhatsApp exposes the matching control."
                2 -> "يتم فتح محادثة واتساب المحددة وتنفيذ نوع الاتصال المطلوب إذا أتاح واتساب زر التحكم المطابق."
                3 -> "Chat WhatsApp ingkang dipilih dipunbikak. Bantuan panggilan badhe milih jinis telpon menawi tombolipun kasedhiya."
                4 -> "Obrolan WhatsApp anu dipilih nuju dibuka. Bantuan telepon bakal milih jinis telepon upami tombolna sayogi."
                else -> getString(R.string.perintah_panggilan_whatsapp_dibuka, jenis)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS, MODE_PRIVATE).edit().clear().apply()
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    private fun mulaiPanggilanSeluler(nomor: String) {
        nomorPanggilanTertunda = nomor
        if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.CALL_PHONE), PERMINTAAN_PANGGILAN)
            return
        }
        lakukanPanggilanSeluler(nomor)
    }

    private fun lakukanPanggilanSeluler(nomor: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", nomor, null))
            startActivity(intent)
        } catch (_: SecurityException) {
            // Jika izin ditolak/dicabut oleh sistem, jangan gagal total: tampilkan dialer biasa.
            try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) } catch (_: Exception) { }
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) } catch (_: Exception) { }
        }
        tutup()
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the project's minSdk")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMINTAAN_PANGGILAN) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                lakukanPanggilanSeluler(nomorPanggilanTertunda)
            } else {
                val nomor = nomorPanggilanTertunda
                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) } catch (_: Exception) { }
                tutup()
            }
            return
        }
        if (requestCode != PERMINTAAN_KONTAK) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prosesTujuanPanggilan(listOf(ucapanKontakTertunda))
        } else {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Contact access is needed to find a person by name. You can say the phone number instead."
                2 -> "يلزم إذن جهات الاتصال للبحث بالاسم. يمكنك ذكر رقم الهاتف بدلاً من ذلك."
                3 -> "Idin kontak dibutuhake kanggo nggoleki jeneng. Sampeyan bisa nyebutake nomer telpon."
                4 -> "Idin kontak diperlukeun pikeun milarian nami. Anjeun tiasa nyebatkeun nomer telepon."
                else -> getString(R.string.perintah_kontak_izin)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            tutup()
        }
    }


    /** Membacakan pesan masuk terakhir yang tersimpan dari notifikasi, bukan mengakses chat privat secara diam-diam. */
    private fun bacaPesanTersimpan(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        val isi = if (nama.isNotBlank()) RiwayatPesanSuara.cari(this, nama) else RiwayatPesanSuara.terbaru(this)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> "No recent incoming message is available in the notification history."
            2 -> "لا توجد رسالة واردة حديثة في سجل الإشعارات."
            3 -> "Pesen mlebet enggal dereng wonten ing riwayat notifikasi."
            4 -> "Teu aya talatah asup panganyarna dina riwayat béwara."
            else -> getString(R.string.perintah_pesan_tidak_ada)
        }
        bacakanTeksLokal(teks)
    }

    private fun cariPesanKontak(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        if (nama.isBlank()) { bukaPesan(kandidat, baca = false); return }
        val isi = RiwayatPesanSuara.cari(this, nama)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> ("No recent incoming message from " + (nama) + " was found in notification history.")
            2 -> ("لم يتم العثور على رسالة واردة حديثة من " + (nama) + " في سجل الإشعارات.")
            3 -> ("Pesen mlebet enggal saking " + (nama) + " boten kapanggih ing riwayat notifikasi.")
            4 -> ("Teu kapanggih talatah asup panganyarna ti " + (nama) + " dina riwayat béwara.")
            else -> getString(R.string.perintah_pesan_kontak_tidak_ada, nama)
        }
        bacakanTeksLokal(teks)
    }

    private fun bacakanTeksLokal(teks: String) {
        try {
            val prefs = Prefs(applicationContext)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    /** Membuka aplikasi pesan. Pembacaan otomatis tetap mengikuti izin Notification Listener. */
    private fun bukaPesan(kandidat: List<String>, baca: Boolean) {
        val ucapan = kandidat.joinToString(" ").lowercase()
        try {
            val paket = when {
                ucapan.contains("whatsapp business") -> "com.whatsapp.w4b"
                ucapan.contains("whatsapp") || ucapan.contains("wa ") -> "com.whatsapp"
                else -> null
            }
            val intent = if (paket != null) packageManager.getLaunchIntentForPackage(paket)
                else Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            if (intent != null) startActivity(intent) else startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        if (baca) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Opened your messaging app. Incoming messages can be read aloud when notification access and message announcements are enabled."
                2 -> "تم فتح تطبيق الرسائل. يمكن قراءة الرسائل الواردة عند تفعيل الوصول إلى الإشعارات وإعلان الرسائل."
                3 -> "Aplikasi pesen sampun kabikak. Pesen mlebet saged dipunwaos nalika akses notifikasi lan pawartos pesen sampun aktif."
                4 -> "Aplikasi pesen parantos dibuka. Talatah asup tiasa dibacakeun upami aksés béwara sareng fitur maca talatah diaktipkeun."
                else -> getString(R.string.perintah_pesan_aplikasi_dibuka)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    /** Mencocokkan nama aplikasi dengan label launcher yang terpasang. */
    private fun bukaAplikasiDisebut(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty().lowercase()
            .replace(Regex("(?i)\\b(buka|bukakan|jalankan|open|launch|aplikasi|app|tolong|please)\\b"), " ").trim()
        if (ucapan.isBlank()) { tutup(); return }
        try {
            val daftar = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val cocok = daftar.firstOrNull { it.loadLabel(packageManager).toString().equals(ucapan, true) }
                ?: daftar.firstOrNull { it.loadLabel(packageManager).toString().contains(ucapan, true) }
            val launch = cocok?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) startActivity(launch) else {
                val pesan = when (Prefs(applicationContext).bahasaAktif) {
                    1 -> "App not found. Say its name as shown on the home screen."
                    2 -> "لم يتم العثور على التطبيق. قل اسمه كما يظهر على الشاشة الرئيسية."
                    3 -> "Aplikasi boten kapanggih. Sebataken nami kados ingkang katingal ing layar utama."
                    4 -> "Aplikasi teu kapanggih. Sebutkeun nami sapertos dina layar utama."
                    else -> getString(R.string.perintah_aplikasi_tidak_ditemukan)
                }
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun putarQuranLatarBelakang(kandidat: List<String>) {
        try { PemutarQuranService.kirim(this, PemutarQuranService.ACTION_PUTAR, kandidat) }
        catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun kendaliQuran(aksi: String) {
        // FIX119: audio dari perintah putar bisa berada di pemutar Khatam ATAU di layanan latar belakang. Sebelumnya perintah
        // berhenti/jeda/lanjut hanya dikirim ke layanan, sehingga audio Khatam tetap berbunyi walau ada jawaban "dihentikan".
        val kendaliKhatam = when (aksi) {
            PemutarQuranService.ACTION_BERHENTI -> KhatamActivity.KENDALI_BERHENTI
            PemutarQuranService.ACTION_JEDA -> KhatamActivity.KENDALI_JEDA
            PemutarQuranService.ACTION_LANJUT -> KhatamActivity.KENDALI_LANJUT
            else -> null
        }
        val ditanganiKhatam = kendaliKhatam != null && KhatamActivity.kendaliLatar(kendaliKhatam)
        // Berhenti selalu juga dikirim ke layanan agar pemutar mana pun yang aktif berhenti.
        // Jeda/lanjut hanya diteruskan ke layanan bila Khatam tidak memegang audionya.
        if (aksi == PemutarQuranService.ACTION_BERHENTI || !ditanganiKhatam) {
            try { PemutarQuranService.kirim(this, aksi) }
            catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        }
        tutup()
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        menungguPengenalan = false
        // Tutup layar pengenal sistem bila masih terbuka di atas layar ini.
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        finish()
    }

    /** Perintah hanya memberi informasi atau tidak dipahami: audio Khatam yang kita jeda untuk mikrofon dilanjutkan. */
    private fun tutupDanLanjutAudio() {
        KhatamActivity.lanjutkanSetelahMikrofon()
        tutup()
    }

    /** Dipanggil instance baru: lepaskan mikrofon, pengenal, dan fokus milik instance lama tanpa memicu pelanjutan audio. */
    private fun tutupPaksa() {
        selesai = true
        menungguPengenalan = false
        handler.removeCallbacksAndMessages(null)
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        finish()
    }

    private fun hentikanUjaranTalkBack() {
        try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
    }

    private fun ambilFokusMikrofon() {
        if (fokusMikDiminta) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) {
                val atribut = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(atribut)
                    .setOnAudioFocusChangeListener({ }, handler)
                    .setWillPauseWhenDucked(true)
                    .setAcceptsDelayedFocusGain(false)
                    .build()
                permintaanFokusMik = req
                fokusMikDiminta = am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                fokusMikDiminta = am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (_: Exception) { fokusMikDiminta = false }
    }

    private fun lepasFokusMikrofon() {
        if (!fokusMikDiminta) return
        fokusMikDiminta = false
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) permintaanFokusMik?.let { am.abandonAudioFocusRequest(it) }
            else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) { }
        permintaanFokusMik = null
    }

    override fun onDestroy() {
        if (aktif === this) aktif = null
        selesai = true
        menungguPengenalan = false
        handler.removeCallbacksAndMessages(null)
        // Lepaskan semua resource sesi pada setiap jalur penghancuran Activity.
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PEMICU_GONCANGAN = "pemicu_dari_goncangan"
        const val EXTRA_PEMICU_MANUAL = "pemicu_manual_widget"
        private const val KODE_PENGENALAN = 6911
        private const val PERMINTAAN_KONTAK = 6912
        private const val PERMINTAAN_PANGGILAN = 6913
        @Volatile
        private var aktif: PerintahSuaraActivity? = null
        /** FIX87: diisi true oleh pemanggil di dalam aplikasi agar pengguna tidak dikirim ke layar depan. */
        const val EXTRA_DARI_APLIKASI = "perintah_suara_dari_aplikasi"
        const val EXTRA_UJI_PAKET_OFFLINE = "perintah_suara_uji_paket_offline"
    }
}

/** Penafsir perintah suara: menilai SEMUA alternatif pengenalan, lalu memilih maksud paling spesifik. */
object PerintahSuara {
    enum class Jenis { TIMER, BATERAI_INFO, CUACA, WAKTU, TANGGAL, WAKTU_TANGGAL, SEMUA, PASARAN, TANGGAL_MASEHI, TANGGAL_HIJRIAH, LIBUR, LIBUR_SPESIFIK, SHOLAT_BERIKUTNYA, CARI_PESAN, QURAN, BERHENTI_AUDIO, JEDA_AUDIO, LANJUT_AUDIO, KONTROL_PERANGKAT, BUKA_FITUR, PANGGIL, PESAN, BACA_PESAN, BUKA_APLIKASI, TIDAK_DIKENAL }
    enum class JenisPerangkat { BLUETOOTH, WIFI, HOTSPOT, DATA_SELULER, MODE_PESAWAT, LOKASI, NFC }
    data class KontrolPerangkat(val jenis: JenisPerangkat, val aktif: Boolean)
    enum class Fitur { BATERAI, JAM, KALENDER, PEMANGGIL, SHOLAT, LOKASI, PEMANDU_JALAN, KIBLAT, FASILITAS, DOA, KHATAM, MODE_ACARA, BAHASA }

    private val kataWaktu = setOf("waktu", "jam", "pukul", "time", "clock", "jamnya")
    private val kataTanggal = setOf("tanggal", "hari", "tgl", "date", "today", "day", "kalender", "calendar", "pasaran")
    private val kataSemua = setOf("semua", "lengkap", "semuanya", "everything", "all", "both")
    private val kataKerjaInfo = setOf("informasikan", "informasi", "info", "beritahu", "beritahukan", "sebutkan", "katakan", "bacakan", "baca", "tolong", "tell", "say", "give", "what", "whats", "read", "announce", "saya", "me")
    private val kataQuran = setOf("surah", "surat", "sura", "ayat", "ayah", "aya", "verse", "juz", "jus", "juzz", "murattal", "mushaf", "alquran", "quran", "quranul")
    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori")
    private val kataKerjaQari = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set", "choose", "select", "switch", "change", "use")
    private val kataKerjaBuka = setOf("buka", "bukakan", "tampilkan", "tunjukkan", "lihat", "masuk", "jalankan", "open", "launch", "show", "display", "go", "navigate", "akses")

    fun tafsir(kandidat: List<String>): Jenis {
        // Alternatif pertama dari mesin ASR sering terlalu umum. Prioritas numerik memastikan
        // tanggal Hijriah/shalat/libur dan aksi fitur selalu menang dari kata "tanggal" atau "waktu" umum.
        return kandidat.mapNotNull { tafsirSatu(it) }
            .maxByOrNull { prioritas(it) } ?: Jenis.TIDAK_DIKENAL
    }

    private fun prioritas(j: Jenis): Int = when (j) {
        Jenis.TANGGAL_HIJRIAH, Jenis.TANGGAL_MASEHI, Jenis.PASARAN, Jenis.SHOLAT_BERIKUTNYA, Jenis.LIBUR, Jenis.LIBUR_SPESIFIK, Jenis.PANGGIL, Jenis.PESAN, Jenis.BACA_PESAN, Jenis.CARI_PESAN -> 110
        Jenis.BERHENTI_AUDIO, Jenis.JEDA_AUDIO, Jenis.LANJUT_AUDIO, Jenis.KONTROL_PERANGKAT, Jenis.TIMER -> 130
        Jenis.QURAN -> 95
        Jenis.BUKA_FITUR -> 90
        Jenis.WAKTU_TANGGAL, Jenis.SEMUA -> 40
        Jenis.WAKTU, Jenis.TANGGAL -> 30
        else -> 0
    }

    private fun token(ucapan: String): List<String> = ucapan.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    /** Memahami perintah pengaturan perangkat dalam Indonesia maupun English. */
    fun kontrolPerangkat(kandidat: List<String>): KontrolPerangkat? {
        val t = token(kandidat.joinToString(" "))
        if (t.isEmpty()) return null
        // Kata kerja disediakan untuk seluruh bahasa utama aplikasi: Indonesia, English,
        // Arab, Jawa, dan Sunda. Nama teknologi tetap menerima istilah internasional.
        val aktif = when {
            t.contains("off") || t.contains("disable") || t.containsAll(listOf("turn", "off")) ||
                t.any { it in setOf("matikan", "nonaktifkan", "nonaktif", "putuskan", "mati", "pateni", "mateni", "pareuman", "paehkeun", "أوقف", "اوقف", "عطل", "عطّل", "إيقاف", "اغلق", "أغلق") } -> false
            t.contains("on") || t.contains("enable") || t.containsAll(listOf("turn", "on")) ||
                t.any { it in setOf("aktifkan", "nyalakan", "hidupkan", "sambungkan", "nyala", "hidup", "uripna", "uripke", "uripno", "aktifna", "aktifke", "hurungkeun", "aktipkeun", "شغل", "فعّل", "فعل", "تشغيل", "تفعيل", "افتح") } -> true
            else -> return null
        }
        val jenis = when {
            t.any { it in setOf("bluetooth", "bluetoothnya", "بلوتوث") } -> JenisPerangkat.BLUETOOTH
            t.any { it in setOf("wifi", "wi-fi", "wireless", "wlan") } || t.containsAll(listOf("wi", "fi")) || t.containsAll(listOf("واي", "فاي")) -> JenisPerangkat.WIFI
            t.any { it in setOf("hotspot", "tethering", "penambatan") } || t.containsAll(listOf("نقطة", "اتصال")) -> JenisPerangkat.HOTSPOT
            t.any { it in setOf("seluler", "mobile", "cellular", "internet", "بيانات", "الجوال", "الهاتف") } || (t.contains("data") && t.any { it in setOf("seluler", "mobile", "cellular") }) -> JenisPerangkat.DATA_SELULER
            t.any { it in setOf("pesawat", "airplane", "flight", "الطيران") } || t.containsAll(listOf("وضع", "الطيران")) -> JenisPerangkat.MODE_PESAWAT
            t.any { it in setOf("lokasi", "location", "gps", "الموقع") } -> JenisPerangkat.LOKASI
            t.any { it in setOf("nfc") } -> JenisPerangkat.NFC
            else -> null
        } ?: return null
        return KontrolPerangkat(jenis, aktif)
    }

    private fun tafsirSatu(ucapan: String): Jenis? {
        val t = token(ucapan)
        if (t.isEmpty()) return null
        val frasa = t.joinToString(" ")
        val gabung = t.joinToString("")
        val kerjaBuka = t.any { it in kataKerjaBuka }
        val panggil = t.any { it in setOf("telepon", "telpon", "panggil", "hubungi", "call", "phone", "dial") }
        val pesan = t.any { it in setOf("pesan", "sms", "message", "messages", "whatsapp", "wa", "chat", "inbox", "kotak") }
        val baca = t.any { it in setOf("baca", "bacakan", "read", "listen", "dengarkan") }
        // Perintah perangkat harus diperiksa sebelum kata "matikan" dianggap sebagai stop audio.
        if (kontrolPerangkat(listOf(ucapan)) != null) return Jenis.KONTROL_PERANGKAT
        // Kendali audio hanya dikenali bila pengguna menyebut audio/pemutar/Quran atau perintah stop pendek yang jelas.
        if (t.size <= 4) {
            val konteksAudio = t.any { it in setOf("audio", "suara", "quran", "qur an", "pemutar", "player", "murattal") }
            if (("timer" !in t && "countdown" !in t && t.any { it in setOf("berhenti", "hentikan", "stop", "henti") }) || (konteksAudio && t.any { it in setOf("matikan", "turnoff", "off") })) return Jenis.BERHENTI_AUDIO
            if (t.any { it in setOf("jeda", "pause", "jedakan") }) return Jenis.JEDA_AUDIO
            if (t.any { it in setOf("lanjut", "lanjutkan", "resume", "teruskan", "continue") }) return Jenis.LANJUT_AUDIO
        }
        if (panggil) return Jenis.PANGGIL
        if (t.any { it in setOf("timer", "countdown", "countdown-timer") }) return Jenis.TIMER
        if (t.any { it in setOf("baterai", "battery", "baterei", "batré") } &&
            (t.any { it in setOf("berapa", "persen", "sisa", "status", "cek", "periksa", "informasikan", "bacakan", "how", "much", "level", "remaining", "charge") } || t.size <= 3)) return Jenis.BATERAI_INFO
        if (t.any { it in setOf("cuaca", "weather", "forecast", "prakiraan", "hujan", "الطقس", "طقس", "الجو") }) return Jenis.CUACA
        val cari = t.any { it in setOf("cari", "temukan", "search", "find", "from", "dari") }
        if (pesan && cari && t.any { it in setOf("ali", "bima") }) return Jenis.CARI_PESAN
        if (pesan && baca) return Jenis.BACA_PESAN
        if (pesan && (t.any { it in setOf("buka", "open", "lihat", "tampilkan", "cek", "periksa") } || t.size <= 3)) return Jenis.PESAN
        if (kerjaBuka && fiturDariToken(t) == null && t.any { it !in kataKerjaBuka && it !in setOf("aplikasi", "app", "tolong", "please") }) return Jenis.BUKA_APLIKASI
        // Aksi membuka fitur harus dibedakan dari pertanyaan informasi ("jam berapa", "tanggal apa").
        if (kerjaBuka && (t.any { it in kataQuran } || gabung.contains("quran"))) return Jenis.BUKA_FITUR
        if (kerjaBuka && fiturDariToken(t) != null) return Jenis.BUKA_FITUR
        val quran = t.any { it in kataQuran } || gabung.contains("quran")
        if (quran) return Jenis.QURAN
        // FIX98: "ulangi 3 kali", "putar lagi", dan "putar Yasin 5 kali" (nama surah tanpa kata "surah").
        val kataUlangPendek = t.any { it in setOf("ulangi", "ulang", "diulang", "mengulang", "repeat") } ||
            (t.size <= 4 && t.any { it in setOf("lagi", "again") } && t.any { it in setOf("putar", "play", "mainkan", "baca") })
        if (kataUlangPendek && t.size <= 7 && "tahun" !in t && !pesan && !panggil) return Jenis.QURAN
        if (t.any { it in setOf("putar", "putarkan", "mainkan", "play") } &&
            PenafsirQuran.tafsir(listOf(ucapan))?.let { it.surah != null || it.juz != null || it.relatif != 0 } == true) return Jenis.QURAN
        val qari = t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
        if (qari) return Jenis.QURAN
        // Pasaran Jawa diminta sendiri: jawab pasarannya saja, bukan rangkaian tanggal, libur, dan salat.
        if (t.any { it in setOf("pasaran", "pasarannya", "weton") }) return Jenis.PASARAN
        if (t.any { it in setOf("masehi", "gregorian") } || frasa.contains("tanggal masehi") || frasa.contains("gregorian date")) return Jenis.TANGGAL_MASEHI
        val kataLibur = t.any { it in setOf("libur", "liburan", "holiday", "holidays", "cuti", "vacation") } || frasa.contains("day off")
        if (kataLibur && (t.any { it in setOf("nasional", "national", "bersama", "joint", "today", "hari", "ini", "kemarin", "yesterday", "besok", "berikutnya", "mendatang", "upcoming", "next", "past", "terakhir", "lalu", "akan", "datang") })) return Jenis.LIBUR_SPESIFIK
        if (kataLibur) return Jenis.LIBUR
        if (t.any { it in setOf("hijriah", "hijriyah", "hijri", "islamic") } || frasa.contains("islamic date")) return Jenis.TANGGAL_HIJRIAH
        if (t.any { it in setOf("salat", "shalat", "sholat", "solat", "prayer", "prayers", "fajr", "subuh", "dzuhur", "zuhur", "ashar", "asar", "maghrib", "isya") } || frasa.contains("prayer time")) return Jenis.SHOLAT_BERIKUTNYA
        val waktu = t.any { it in kataWaktu }
        val tanggal = t.any { it in kataTanggal }
        val semua = t.any { it in kataSemua }
        return when {
            waktu && tanggal -> Jenis.WAKTU_TANGGAL
            waktu && semua -> Jenis.SEMUA
            tanggal && semua -> Jenis.SEMUA
            waktu -> Jenis.WAKTU
            tanggal -> Jenis.TANGGAL
            semua -> Jenis.SEMUA
            t.any { it in kataKerjaInfo } && t.size <= 3 -> Jenis.SEMUA
            else -> null
        }
    }

    /** Membaca durasi timer dari angka atau bilangan umum yang sering dipakai secara lisan. */
    fun durasiTimerDetik(kandidat: List<String>): Long {
        val t = token(kandidat.joinToString(" "))
        val angka = mapOf("nol" to 0L, "satu" to 1L, "se" to 1L, "dua" to 2L, "tiga" to 3L, "empat" to 4L, "lima" to 5L, "enam" to 6L, "tujuh" to 7L, "delapan" to 8L, "sembilan" to 9L, "sepuluh" to 10L, "sebelas" to 11L, "dua belas" to 12L, "lima belas" to 15L, "dua puluh" to 20L, "tiga puluh" to 30L, "empat puluh" to 40L, "lima puluh" to 50L, "sixty" to 60L, "thirty" to 30L, "twenty" to 20L, "fifteen" to 15L, "ten" to 10L, "five" to 5L, "four" to 4L, "three" to 3L, "two" to 2L, "one" to 1L, "half" to 30L)
        var total = 0L
        var i = 0
        while (i < t.size) {
            val unit = when (t[i]) { "jam", "hours", "hour", "hrs" -> 3600L; "menit", "minute", "minutes", "mins" -> 60L; "detik", "second", "seconds", "secs" -> 1L; else -> 0L }
            if (unit > 0) {
                var n = 0L
                if (i > 0) {
                    val dua = if (i >= 2) t[i - 2] + " " + t[i - 1] else ""
                    n = angka[dua] ?: angka[t[i - 1]] ?: t[i - 1].toLongOrNull() ?: 0L
                }
                if (n == 0L && t[i].startsWith("menit") && i > 0 && t[i - 1] == "setengah") n = 30L
                total += n * unit
            }
            i++
        }
        if (total == 0L) {
            val num = t.firstOrNull { it.toLongOrNull() != null }?.toLongOrNull()
            if (num != null && t.any { it in setOf("timer", "countdown") }) total = num * 60L
        }
        return total.coerceIn(0L, 359999L)
    }

    /** True bila ucapan memuat klausa memilih qari ("pilih qari ..."); itu hanya dapat ditangani Khatam. */
    fun adaKlausaQari(kandidat: List<String>): Boolean = kandidat.any { u ->
        val t = token(u)
        t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
    }

    fun namaKontakPesan(kandidat: List<String>): String {
        val gabung = kandidat.joinToString(" ").lowercase()
        return if (gabung.contains("ali") && gabung.contains("bima")) "Ali Bima" else ""
    }

    fun kategoriLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return if (t.any { it in setOf("cuti", "bersama", "joint") }) "joint" else "national"
    }
    fun periodeLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return when {
            t.any { it in setOf("kemarin", "kemarinnya", "yesterday", "lampau", "lalu", "past", "terakhir") } -> "past"
            t.any { it in setOf("besok", "mendatang", "berikutnya", "selanjutnya", "upcoming", "next") } || (t.contains("akan") && t.contains("datang")) -> "next"
            else -> "today"
        }
    }

    fun fitur(kandidat: List<String>): Fitur? = kandidat.asSequence().mapNotNull { fiturDariToken(token(it)) }.firstOrNull()

    private fun fiturDariToken(t: List<String>): Fitur? {
        val f = t.joinToString(" ")
        fun ada(vararg kata: String) = kata.any { k -> f.contains(k) || t.contains(k) }
        return when {
            ada("baterai", "battery") -> Fitur.BATERAI
            ada("kalender", "calendar") -> Fitur.KALENDER
            ada("pemanggil", "penelepon", "caller", "penelpon") -> Fitur.PEMANGGIL
            ada("jadwal sholat", "jadwal salat", "pengaturan sholat", "pengaturan salat", "prayer schedule", "waktu salat", "waktu sholat") -> Fitur.SHOLAT
            ada("pemandu jalan", "navigasi", "petunjuk jalan", "route guide", "road guide") -> Fitur.PEMANDU_JALAN
            ada("lokasi terkini", "lokasi saya", "current location", "my location") -> Fitur.LOKASI
            ada("kiblat", "qibla", "arah kiblat") -> Fitur.KIBLAT
            ada("fasilitas terdekat", "nearby facilities", "tempat terdekat") -> Fitur.FASILITAS
            ada("taaruf doa", "doa", "doa harian", "daily prayer", "supplication") -> Fitur.DOA
            ada("khatam", "hafalan", "quran", "alquran", "surah", "surat", "ayat", "juz") -> Fitur.KHATAM
            ada("mode acara", "event mode") -> Fitur.MODE_ACARA
            ada("bahasa", "language settings", "pengaturan bahasa") -> Fitur.BAHASA
            ada("jam", "clock") -> Fitur.JAM
            else -> null
        }
    }
}
