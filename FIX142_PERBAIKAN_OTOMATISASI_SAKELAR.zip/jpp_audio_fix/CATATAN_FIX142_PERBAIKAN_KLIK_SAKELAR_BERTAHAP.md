# FIX142 — Perbaikan tindakan klik sakelar perangkat

## Masalah yang ditangani
FIX141 menganggap `dispatchGesture()` bernilai `true` sebagai tanda bahwa ketukan sudah selesai. Nilai tersebut hanya menunjukkan bahwa Android menerima permintaan gestur. FIX141 juga hanya mencoba satu titik ketukan, lalu berhenti bila status tidak berubah. Akibatnya, pada beberapa tampilan OEM titik tengah kontrol tidak mengenai area sakelar yang sebenarnya.

## Perubahan
- Pemeriksaan apakah layanan aksesibilitas aktif diperkuat: selain membaca daftar layanan pada `Settings.Secure`, aplikasi memeriksa daftar layanan aktif dari `AccessibilityManager`.
- Jika layanan belum aktif, aplikasi sekarang mengarahkan pengguna ke halaman Aksesibilitas terlebih dahulu dan meminta pengguna mengaktifkan layanan, lalu mengulangi perintah suara. Aplikasi tidak lagi hanya membuka halaman fitur dan memberi kesan otomatisasi sedang berjalan.
- Aksi `ACTION_CLICK` tetap dicoba lebih dahulu.
- Bila status masih berlawanan dengan perintah, layanan mencoba titik ketukan yang dihitung dari batas sakelar dan baris klik terdekat.
- Titik ketukan dicoba satu per satu, bukan sekaligus.
- Layanan menunggu callback `onCompleted`/`onCancelled`, lalu membaca ulang status sebelum mencoba titik berikutnya.
- Status yang tidak dapat dibaca tidak diperlakukan sebagai OFF dan tidak memicu ketukan berulang yang berisiko membalikkan sakelar.
- Cakupan perangkat, pengenal perintah suara, bahasa aktif, dan versi aplikasi tetap dipertahankan.

## Batas pengujian
Uji sumber dan skrip regresi tidak dapat membuktikan perilaku antarmuka One UI pada perangkat fisik. Kompilasi APK penuh dan uji langsung ponsel masih diperlukan. Beberapa sakelar sistem dapat dilindungi Android atau memerlukan konfirmasi pengguna.
