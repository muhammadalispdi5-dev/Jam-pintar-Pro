#!/usr/bin/env python3
"""Pemeriksaan statis awal proyek Jam Pintar Pro sebelum build Android."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
GRADLE = ROOT / "app/build.gradle.kts"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
ANDROID = "{http://schemas.android.com/apk/res/android}"
errors = []
notes = []

def fail(message: str) -> None:
    errors.append(message)

if not GRADLE.is_file():
    fail("app/build.gradle.kts tidak ditemukan")
if not MANIFEST.is_file():
    fail("AndroidManifest.xml tidak ditemukan")

if not errors:
    gradle_text = GRADLE.read_text(encoding="utf-8")
    for key, pattern in {
        "versionCode": r"versionCode\s*=\s*(\d+)",
        "versionName": r'versionName\s*=\s*"([^\"]+)"',
        "applicationId": r'applicationId\s*=\s*"([^\"]+)"',
        "compileSdk": r"compileSdk\s*=\s*(\d+)",
        "minSdk": r"minSdk\s*=\s*(\d+)",
        "targetSdk": r"targetSdk\s*=\s*(\d+)",
    }.items():
        if not re.search(pattern, gradle_text):
            fail(f"Konfigurasi {key} tidak ditemukan")

    values = {}
    for key, pattern in {
        "versionCode": r"versionCode\s*=\s*(\d+)",
        "versionName": r'versionName\s*=\s*"([^\"]+)"',
        "applicationId": r'applicationId\s*=\s*"([^\"]+)"',
        "compileSdk": r"compileSdk\s*=\s*(\d+)",
        "minSdk": r"minSdk\s*=\s*(\d+)",
        "targetSdk": r"targetSdk\s*=\s*(\d+)",
    }.items():
        match = re.search(pattern, gradle_text)
        if match:
            values[key] = match.group(1)

    if values.get("versionCode") != "68" or values.get("versionName") != "1.0.68":
        fail("Versi tidak sesuai: diharapkan 1.0.68 / versionCode 68")
    if values.get("minSdk") and int(values["minSdk"]) < 1:
        fail("minSdk tidak valid")
    if values.get("targetSdk") and values.get("compileSdk") and int(values["targetSdk"]) > int(values["compileSdk"]):
        fail("targetSdk lebih tinggi daripada compileSdk")

    try:
        root = ET.parse(MANIFEST).getroot()
        app = root.find("application")
        if app is None:
            fail("Elemen application tidak ditemukan di manifest")
        else:
            components = ("activity", "service", "receiver", "provider")
            source_root = ROOT / "app/src/main/java"
            for tag in components:
                for component in app.findall(tag):
                    name = component.get(ANDROID + "name", "")
                    exported = component.get(ANDROID + "exported")
                    if not name:
                        fail(f"Komponen {tag} tidak memiliki android:name")
                        continue
                    if exported is None:
                        fail(f"Komponen {tag} {name} tidak menyatakan android:exported secara eksplisit")
                    if name.startswith("."):
                        class_name = name[1:]
                    elif "." not in name:
                        class_name = name
                    else:
                        class_name = name.rsplit(".", 1)[-1]
                    matches = list(source_root.rglob(class_name + ".kt")) + list(source_root.rglob(class_name + ".java"))
                    if not matches:
                        fail(f"Sumber kelas untuk komponen manifest {name} tidak ditemukan")
            permissions = {node.get(ANDROID + "name") for node in root.findall("uses-permission")}
            for required in ("android.permission.RECEIVE_BOOT_COMPLETED", "android.permission.SCHEDULE_EXACT_ALARM"):
                if required not in permissions:
                    fail(f"Izin penting tidak ditemukan: {required}")
    except ET.ParseError as exc:
        fail(f"AndroidManifest.xml tidak valid: {exc}")

    if not (ROOT / ".github/workflows/build.yml").is_file():
        fail("Workflow build.yml tidak ditemukan")
    if not (ROOT / ".github/workflows/rilis.yml").is_file():
        notes.append("Workflow rilis.yml tidak ditemukan; alur rilis manual tidak bisa diverifikasi")

if errors:
    print("PEMERIKSAAN PROYEK: GAGAL")
    for item in errors:
        print(f"- {item}")
    for item in notes:
        print(f"CATATAN: {item}")
    sys.exit(1)

print("PEMERIKSAAN PROYEK: LULUS")
print("- Versi aplikasi 1.0.68 (versionCode 68)")
print("- Konfigurasi Gradle dan XML manifest dapat dibaca")
print("- Komponen manifest memiliki deklarasi exported dan sumber kelas ditemukan")
print("- Izin boot dan alarm tepat waktu terdeklarasi")
for item in notes:
    print(f"CATATAN: {item}")
print("Catatan: pemeriksaan ini bersifat statis, bukan pengganti kompilasi atau uji perangkat.")
