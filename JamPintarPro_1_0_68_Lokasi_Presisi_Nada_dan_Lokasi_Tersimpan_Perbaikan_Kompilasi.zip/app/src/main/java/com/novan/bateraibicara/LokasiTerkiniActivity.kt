package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.media.AudioManager
import android.media.ToneGenerator
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Membacakan lokasi GPS terkini dengan kontrol yang dapat dijelajahi pembaca layar. */
class LokasiTerkiniActivity : Halaman() {
    override val judulHalaman = R.string.judul_lokasi_terkini

    private lateinit var status: android.widget.TextView
    private var lokasiTerakhir: Location? = null
    private var namaLokasiTerakhir: String? = null
    private var sedangMencari = false
    private var adaFixLangsung = false
    private var jumlahFixAkurat = 0
    private var waktuFixAkuratPertama = 0L
    private var waktuFixTerakhir = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val timeoutHandler = Handler(Looper.getMainLooper())
    private var tone: ToneGenerator? = null
    private var manager: LocationManager? = null
    private val nadaPencarian = object : Runnable {
        override fun run() {
            if (sedangMencari) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }
                handler.postDelayed(this, 650L)
            }
        }
    }
    private var listener: LocationListener? = null

    override fun bangun() {
        info("Gunakan tombol Perbarui lokasi terkini untuk mengetahui tempat Anda berada. Jam Pintar Pro akan mencoba membaca nama jalan, kawasan, kelurahan atau desa, kota, dan provinsi bila layanan nama tempat tersedia. Koordinat dan perkiraan akurasi juga akan dibacakan. Lokasi tidak dikirim ke pengembang.")
        status = info("Lokasi belum diminta. Tekan Perbarui lokasi terkini.")
        tombol("Perbarui lokasi terkini") { perbaruiLokasi() }
        tombol("Bacakan kembali lokasi terakhir") {
            val l = lokasiTerakhir
            if (l == null) toast("Lokasi belum tersedia. Tekan Perbarui lokasi terkini terlebih dahulu.")
            else bacakanLokasi(l, namaLokasiTerakhir)
        }
        tombol("Buka lokasi terakhir di peta") {
            val l = lokasiTerakhir
            if (l == null) toast("Lokasi belum tersedia. Perbarui lokasi terlebih dahulu.")
            else bukaDiPeta(l.latitude, l.longitude, namaLokasiTerakhir ?: "Lokasi terkini")
        }
        tombol("Simpan lokasi dengan nama pilihan") { dialogSimpanLokasi() }
        tombol("Kelola lokasi tersimpan") { tampilkanLokasiTersimpan() }
        tombol("Buka setelan lokasi perangkat") {
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            catch (_: Exception) { toast("Setelan lokasi tidak dapat dibuka.") }
        }
    }

    override fun onDestroy() {
        berhentiMencari()
        try { tone?.release() } catch (_: Exception) { }
        tone = null
        super.onDestroy()
    }

    private fun perbaruiLokasi() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 715)
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        manager = lm
        val penyedia = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        if (penyedia.isEmpty()) {
            status.text = "Layanan lokasi perangkat sedang mati. Aktifkan lokasi lalu coba lagi."
            toast("Layanan lokasi sedang mati.")
            return
        }
        berhentiMencari()
        sedangMencari = true
        lokasiTerakhir = null
        adaFixLangsung = false
        jumlahFixAkurat = 0
        waktuFixAkuratPertama = 0L
        waktuFixTerakhir = 0L
        status.text = "Sedang mencari posisi satelit dan posisi terbaik. Nada pendek berulang menandakan pencarian masih berlangsung. Mohon tunggu hingga 45 detik. Untuk hasil lebih teliti, usahakan berada di tempat terbuka dan jauh dari dinding atau bangunan tinggi."
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        handler.removeCallbacks(nadaPencarian)
        handler.post(nadaPencarian)
        val callback = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!sedangMencari || location.accuracy <= 0f || location.accuracy > 10_000f) return
                // Utamakan pembacaan langsung, bukan posisi tersimpan dari sesi sebelumnya.
                val old = lokasiTerakhir
                if (!adaFixLangsung || old == null || location.accuracy < old.accuracy ||
                    (location.accuracy <= old.accuracy + 2f && location.time > old.time)) {
                    lokasiTerakhir = location
                }
                adaFixLangsung = true
                if (location.time > waktuFixTerakhir) {
                    waktuFixTerakhir = location.time
                    if (location.accuracy <= 8f) {
                        if (jumlahFixAkurat == 0) waktuFixAkuratPertama = System.currentTimeMillis()
                        jumlahFixAkurat++
                    } else {
                        jumlahFixAkurat = 0
                        waktuFixAkuratPertama = 0L
                    }
                }
                // Jangan selesai pada fix pertama. Tunggu beberapa pembacaan yang akurat dan stabil.
                if (jumlahFixAkurat >= 3 && waktuFixAkuratPertama > 0L &&
                    System.currentTimeMillis() - waktuFixAkuratPertama >= 4_000L) {
                    lokasiTerakhir?.let { selesaiDenganLokasi(it) }
                }
            }
            @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        listener = callback
        try {
            for (p in penyedia) {
                try {
                    @Suppress("MissingPermission")
                    lm.requestLocationUpdates(p, 1_000L, 0f, callback, Looper.getMainLooper())
                } catch (_: Exception) { }
                // Cache hanya digunakan sebagai cadangan bila pembacaan langsung gagal.
                try {
                    @Suppress("MissingPermission")
                    val cached = lm.getLastKnownLocation(p)
                    if (!adaFixLangsung && cached != null &&
                        System.currentTimeMillis() - cached.time in 0L..120_000L &&
                        cached.accuracy > 0f && cached.accuracy <= 10_000f) {
                        val old = lokasiTerakhir
                        if (old == null || cached.accuracy < old.accuracy) lokasiTerakhir = cached
                    }
                } catch (_: Exception) { }
            }
            timeoutHandler.postDelayed({
                if (sedangMencari) {
                    val best = lokasiTerakhir
                    if (best != null) selesaiDenganLokasi(best)
                    else {
                        berhentiMencari()
                        status.text = "Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka."
                        toast("Lokasi belum ditemukan. Silakan coba lagi.")
                    }
                }
            }, 45_000L)
        } catch (_: SecurityException) {
            berhentiMencari()
            status.text = "Izin lokasi belum diberikan."
            toast("Izinkan akses lokasi untuk menggunakan fitur ini.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 715) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) perbaruiLokasi()
            else {
                status.text = "Izin lokasi ditolak. Fitur lokasi terkini memerlukan izin lokasi saat digunakan."
                toast("Izin lokasi diperlukan untuk mengetahui lokasi terkini.")
            }
        }
    }

    private fun selesaiDenganLokasi(location: Location) {
        if (!sedangMencari) return
        // Hentikan pembaruan GPS, tetapi pertahankan nada sampai pencarian alamat selesai.
        hentikanPembaruanGPS()
        timeoutHandler.removeCallbacksAndMessages(null)
        lokasiTerakhir = location
        status.text = "Koordinat ditemukan. Sedang mencari nama tempat; jika layanan nama tempat tidak tersedia, koordinat tetap dapat dibacakan."
        Thread {
            val nama = try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val daftar: List<Address>? = Geocoder(this, Locale("id", "ID")).getFromLocation(location.latitude, location.longitude, 5)
                    daftar?.maxByOrNull { alamat ->
                        (if (!alamat.thoroughfare.isNullOrBlank()) 8 else 0) +
                        (if (!alamat.subThoroughfare.isNullOrBlank()) 5 else 0) +
                        (if (!alamat.premises.isNullOrBlank()) 5 else 0) +
                        (if (!alamat.subLocality.isNullOrBlank()) 3 else 0) +
                        (if (!alamat.locality.isNullOrBlank()) 3 else 0) +
                        (if (!alamat.postalCode.isNullOrBlank()) 1 else 0)
                    }?.let { alamat ->
                        val bagianAlamat = listOfNotNull(
                            alamat.featureName?.trim()?.takeIf { it.isNotEmpty() && !it.all { c -> c.isDigit() || c == '.' || c == '-' } },
                            alamat.premises?.trim()?.takeIf { it.isNotEmpty() },
                            listOfNotNull(
                                alamat.thoroughfare?.trim()?.takeIf { it.isNotEmpty() },
                                alamat.subThoroughfare?.trim()?.takeIf { it.isNotEmpty() }
                            ).joinToString(" ").takeIf { it.isNotBlank() },
                            alamat.subLocality?.trim()?.takeIf { it.isNotEmpty() },
                            (alamat.locality ?: alamat.subAdminArea)?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.adminArea?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.postalCode?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.countryName?.trim()?.takeIf { it.isNotEmpty() }
                        ).distinctBy { it.lowercase(Locale("id", "ID")) }
                        bagianAlamat.joinToString(", ").takeIf { it.isNotBlank() }
                    }?.takeIf { it.isNotBlank() }
                } else null
            } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                berhentiMencari()
                namaLokasiTerakhir = nama
                status.text = susunKalimat(location, nama)
                tesSuara("jam", susunKalimat(location, nama))
            }
        }.start()
    }

    private fun susunKalimat(location: Location, nama: String?): String {
        // Gunakan penggabungan teks secara eksplisit agar tidak ada placeholder
        // seperti $tempat atau $lintang yang ikut dibacakan sebagai teks mentah.
        val tempat = if (!nama.isNullOrBlank()) {
            "Alamat atau wilayah yang terdeteksi: " + nama.trim() + ". "
        } else {
            "Nama jalan dan wilayah belum berhasil didapatkan dari layanan alamat. "
        }
        val lintangArah = if (location.latitude < 0) "selatan" else "utara"
        val bujurArah = if (location.longitude < 0) "barat" else "timur"
        val lintang = formatDerajatMenitDetik(kotlin.math.abs(location.latitude))
        val bujur = formatDerajatMenitDetik(kotlin.math.abs(location.longitude))
        val ketelitian = location.accuracy.toInt().coerceAtLeast(1)
        val mutu = when {
            ketelitian <= 5 -> "Ketelitian posisi sangat baik."
            ketelitian <= 10 -> "Ketelitian posisi baik."
            ketelitian <= 20 -> "Ketelitian posisi sedang. Untuk hasil lebih teliti, tunggu beberapa saat atau coba di tempat terbuka."
            else -> "Posisi masih kurang teliti. Angka ini adalah perkiraan radius kesalahan, bukan jarak pasti. Coba lagi di luar ruangan, jauh dari gedung tinggi atau atap, lalu perbarui lokasi."
        }
        return "Lokasi Anda telah ditemukan. " + tempat +
            "Perkiraan ketelitian posisi sekitar " + ketelitian + " meter. " + mutu + " " +
            "Koordinat lokasi: lintang " + lintangArah + ", " + lintang + "; " +
            "bujur " + bujurArah + ", " + bujur + "."
    }

    /** Menulis koordinat sebagai derajat, menit, dan detik agar lebih mudah dipahami melalui suara. */
    private fun formatDerajatMenitDetik(nilai: Double): String {
        val derajat = nilai.toInt()
        val menitPenuh = (nilai - derajat) * 60.0
        val menit = menitPenuh.toInt()
        val detik = (menitPenuh - menit) * 60.0
        val detikTeks = String.format(Locale("id", "ID"), "%.1f", detik)
            .replace(',', ' ').replace(" ", " koma ")
        return derajat.toString() + " derajat, " + menit + " menit, " + detikTeks + " detik"
    }

    private fun bacakanLokasi(location: Location, nama: String?) {
        val kalimat = susunKalimat(location, nama)
        status.text = kalimat
        tesSuara("jam", kalimat)
    }

    private fun hentikanPembaruanGPS() {
        val lm = manager
        val cb = listener
        if (lm != null && cb != null) try { lm.removeUpdates(cb) } catch (_: Exception) { }
        listener = null
    }

    private fun berhentiMencari() {
        sedangMencari = false
        handler.removeCallbacks(nadaPencarian)
        timeoutHandler.removeCallbacksAndMessages(null)
        hentikanPembaruanGPS()
        try { tone?.stopTone() } catch (_: Exception) { }
        try { tone?.release() } catch (_: Exception) { }
        tone = null
    }

    private fun dialogSimpanLokasi() {
        val l = lokasiTerakhir
        if (l == null) {
            toast("Belum ada lokasi untuk disimpan. Cari lokasi terlebih dahulu.")
            return
        }
        val kolom = EditText(this).apply {
            hint = "Contoh: Rumah, masjid, halte, atau tempat parkir"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            contentDescription = "Nama atau label lokasi yang akan disimpan"
        }
        AlertDialog.Builder(this)
            .setTitle("Simpan lokasi")
            .setMessage("Beri nama yang mudah diingat agar lokasi ini dapat ditemukan kembali nanti.")
            .setView(kolom)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val label = kolom.text.toString().trim()
                        if (label.isBlank()) {
                            kolom.error = "Nama lokasi harus diisi"
                            kolom.requestFocus()
                        } else {
                            simpanLokasi(label, l, namaLokasiTerakhir)
                            dialog.dismiss()
                            toast("Lokasi $label berhasil disimpan.")
                            status.text = "Lokasi tersimpan dengan nama $label. Ketelitian saat disimpan sekitar ${l.accuracy.toInt().coerceAtLeast(1)} meter."
                        }
                    }
                }
                dialog.show()
                kolom.requestFocus()
            }
    }

    private fun simpanLokasi(label: String, location: Location, alamat: String?) {
        val prefsLokasi = getSharedPreferences("lokasi_tersimpan_jam_pintar", Context.MODE_PRIVATE)
        val arrayLama = try { JSONArray(prefsLokasi.getString("daftar", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val arrayBaru = JSONArray()
        for (i in 0 until arrayLama.length()) {
            val item = arrayLama.optJSONObject(i) ?: continue
            if (!item.optString("label").equals(label, ignoreCase = true)) arrayBaru.put(item)
        }
        val item = JSONObject().apply {
            put("label", label)
            put("latitude", location.latitude)
            put("longitude", location.longitude)
            put("accuracy", location.accuracy.toDouble())
            put("alamat", alamat ?: "")
            put("waktu", System.currentTimeMillis())
        }
        arrayBaru.put(item)
        prefsLokasi.edit().putString("daftar", arrayBaru.toString()).apply()
    }

    private fun bacaDaftarLokasi(): JSONArray {
        val prefsLokasi = getSharedPreferences("lokasi_tersimpan_jam_pintar", Context.MODE_PRIVATE)
        return try { JSONArray(prefsLokasi.getString("daftar", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    }

    private fun tampilkanLokasiTersimpan() {
        val daftar = bacaDaftarLokasi()
        if (daftar.length() == 0) {
            AlertDialog.Builder(this)
                .setTitle("Lokasi tersimpan")
                .setMessage("Belum ada lokasi yang disimpan. Cari lokasi, lalu pilih Simpan lokasi dengan nama pilihan.")
                .setPositiveButton("Mengerti", null)
                .show()
            return
        }
        val label = ArrayList<String>()
        for (i in 0 until daftar.length()) {
            val item = daftar.optJSONObject(i) ?: continue
            label.add(item.optString("label", "Lokasi tanpa nama"))
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih lokasi tersimpan")
            .setItems(label.toTypedArray()) { _, posisi ->
                val item = daftar.optJSONObject(posisi) ?: return@setItems
                menuLokasiTersimpan(item)
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun menuLokasiTersimpan(item: JSONObject) {
        val label = item.optString("label", "Lokasi tersimpan")
        val lat = item.optDouble("latitude", Double.NaN)
        val lon = item.optDouble("longitude", Double.NaN)
        val accuracy = item.optDouble("accuracy", 0.0).toFloat()
        val alamat = item.optString("alamat", "").takeIf { it.isNotBlank() }
        if (!lat.isFinite() || !lon.isFinite()) {
            toast("Data lokasi $label tidak valid.")
            return
        }
        val pilihan = arrayOf("Bacakan informasi lokasi", "Buka lokasi di peta", "Hapus lokasi tersimpan", "Kembali")
        AlertDialog.Builder(this)
            .setTitle(label)
            .setItems(pilihan) { _, index ->
                when (index) {
                    0 -> {
                        val tersimpan = Location("lokasi_tersimpan").apply {
                            latitude = lat
                            longitude = lon
                            this.accuracy = accuracy.coerceAtLeast(1f)
                            time = item.optLong("waktu", System.currentTimeMillis())
                        }
                        lokasiTerakhir = tersimpan
                        namaLokasiTerakhir = alamat
                        val kalimat = "Lokasi tersimpan dengan nama $label. " + susunKalimat(tersimpan, alamat)
                        status.text = kalimat
                        tesSuara("jam", kalimat)
                    }
                    1 -> bukaDiPeta(lat, lon, label)
                    2 -> AlertDialog.Builder(this)
                        .setTitle("Hapus lokasi $label?")
                        .setMessage("Lokasi ini akan dihapus dari daftar lokasi tersimpan pada perangkat ini.")
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus") { _, _ ->
                            hapusLokasi(label)
                            toast("Lokasi $label telah dihapus.")
                        }.show()
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun hapusLokasi(label: String) {
        val lama = bacaDaftarLokasi()
        val baru = JSONArray()
        for (i in 0 until lama.length()) {
            val item = lama.optJSONObject(i) ?: continue
            if (!item.optString("label").equals(label, ignoreCase = true)) baru.put(item)
        }
        getSharedPreferences("lokasi_tersimpan_jam_pintar", Context.MODE_PRIVATE)
            .edit().putString("daftar", baru.toString()).apply()
    }

    private fun bukaDiPeta(latitude: Double, longitude: Double, label: String) {
        val uri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude(${Uri.encode(label)})")
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { toast("Aplikasi peta tidak tersedia.") }
    }
}
