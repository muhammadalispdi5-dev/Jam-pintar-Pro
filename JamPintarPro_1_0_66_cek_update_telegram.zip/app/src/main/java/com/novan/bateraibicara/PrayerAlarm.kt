package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.time.ZoneId
import java.util.Calendar

object PrayerAlarm {
    private val names = listOf("imsak", "subuh", "dhuha", "tahajud", "dzuhur", "ashar", "maghrib", "isya", "terbit")
    private val labels = mapOf("imsak" to "Imsak", "subuh" to "Subuh", "terbit" to "Matahari terbit", "dhuha" to "Dhuha", "tahajud" to "Tahajud", "dzuhur" to "Dzuhur", "ashar" to "Ashar", "maghrib" to "Maghrib", "isya" to "Isya")
    fun scheduleAll(context: Context) {
        // Pulihkan DND yang masa berlakunya sudah habis, meskipun alarm pemulihan
        // sebelumnya terlewat atau proses aplikasi sempat dihentikan.
        restoreExpiredDnd(context)
        val pp = PrayerPrefs(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for ((index, key) in names.withIndex()) {
            val pi = pending(context, key, index)
            try { am.cancel(pi) } catch (_: Exception) { }
            if (!pp.enabled || !pp.locationSet || !pp.reminder(key)) continue
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            // Cari kemunculan berikutnya, sambil melewati Dzuhur Jumat bila opsi itu aktif.
            for (dayOffset in 0..8) {
                if (key == "dzuhur" && pp.fridayDhuhrOff && date.dayOfWeek.value == 5) {
                    date = date.plusDays(1)
                    continue
                }
                val time = prayerMinutes(context, pp, date, key)
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1)
                    set(Calendar.DAY_OF_MONTH, date.dayOfMonth); set(Calendar.HOUR_OF_DAY, time / 60)
                    set(Calendar.MINUTE, time % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger <= nowMillis) continue
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                } else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi)
            } catch (_: SecurityException) {
                try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi) } catch (_: Exception) { }
            } catch (_: Exception) { }
        }
        // Alarm pendahuluan: request ID terpisah agar tidak bertabrakan dengan alarm azan utama.
        val advanceKeys = listOf("subuh", "dzuhur", "ashar", "maghrib", "isya")
        for ((index, key) in advanceKeys.withIndex()) {
            val pi = pending(context, key, 100 + index)
            try { am.cancel(pi) } catch (_: Exception) { }
            if (!pp.enabled || !pp.locationSet || !pp.advanceReminder(key)) continue
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            for (dayOffset in 0..8) {
                if (key == "dzuhur" && pp.fridayDhuhrOff && date.dayOfWeek.value == 5) {
                    date = date.plusDays(1)
                    continue
                }
                val time = prayerMinutes(context, pp, date, key)
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1)
                    set(Calendar.DAY_OF_MONTH, date.dayOfMonth); set(Calendar.HOUR_OF_DAY, time / 60)
                    set(Calendar.MINUTE, time % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    add(Calendar.MINUTE, -pp.advanceMinutes(key))
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger <= nowMillis) continue
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi)
            } catch (_: SecurityException) {
                try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi) } catch (_: Exception) { }
            } catch (_: Exception) { }
        }
        // Pengingat sahur terpisah dari pengingat Imsak. Waktu dihitung mundur dari Imsak.
        val sahurPi = pending(context, "sahur", 400)
        try { am.cancel(sahurPi) } catch (_: Exception) { }
        if (pp.enabled && pp.locationSet && pp.sahurReminderEnabled) {
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            for (dayOffset in 0..8) {
                val imsak = prayerMinutes(context, pp, date, "imsak")
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1)
                    set(Calendar.DAY_OF_MONTH, date.dayOfMonth); set(Calendar.HOUR_OF_DAY, imsak / 60)
                    set(Calendar.MINUTE, imsak % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    add(Calendar.MINUTE, -pp.sahurReminderMinutes)
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger > nowMillis) scheduleExact(am, trigger, sahurPi)
        }
        // Pengingat berbuka terpisah dari azan Maghrib; waktu dapat digeser sebelum/sesudah Maghrib.
        val berbukaPi = pending(context, "berbuka", 401)
        try { am.cancel(berbukaPi) } catch (_: Exception) { }
        if (pp.enabled && pp.locationSet && pp.berbukaReminderEnabled) {
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            for (dayOffset in 0..8) {
                val maghrib = prayerMinutes(context, pp, date, "maghrib")
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1)
                    set(Calendar.DAY_OF_MONTH, date.dayOfMonth); set(Calendar.HOUR_OF_DAY, maghrib / 60)
                    set(Calendar.MINUTE, maghrib % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    add(Calendar.MINUTE, pp.berbukaOffsetMinutes)
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger > nowMillis) scheduleExact(am, trigger, berbukaPi)
        }
        // Jadwalkan Mode Jangan Ganggu secara mandiri dari pengingat/azan biasa.
        val dndKeys = listOf("subuh", "dzuhur", "ashar", "maghrib", "isya")
        for ((index, key) in dndKeys.withIndex()) {
            val pi = dndPending(context, key, 200 + index, false)
            try { am.cancel(pi) } catch (_: Exception) { }
            if (!pp.dndEnabled || !pp.locationSet || !pp.dndPrayer(key)) continue
            val nowMillis = System.currentTimeMillis()
            var date = LocalDate.now()
            var trigger = 0L
            for (dayOffset in 0..8) {
                if (key == "dzuhur" && pp.fridayDhuhrOff && date.dayOfWeek.value == 5) {
                    date = date.plusDays(1)
                    continue
                }
                val time = prayerMinutes(context, pp, date, key)
                val candidate = Calendar.getInstance().apply {
                    set(Calendar.YEAR, date.year); set(Calendar.MONTH, date.monthValue - 1); set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
                    set(Calendar.HOUR_OF_DAY, time / 60); set(Calendar.MINUTE, time % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                if (candidate > nowMillis) { trigger = candidate; break }
                date = date.plusDays(1)
            }
            if (trigger > nowMillis) scheduleExact(am, trigger, pi)
        }
        val restorePi = dndPending(context, "", 300, true)
        val prefs = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
        val until = prefs.getLong("prayer_dnd_active_until", 0L)
        val now = System.currentTimeMillis()
        when {
            until > now -> {
                // Perbarui batas waktu aktif tanpa membatalkan alarm retry pemulihan.
                scheduleExact(am, until, restorePi)
            }
            until <= 0L -> {
                // Catatan pemulihan sudah selesai/tidak ada; aman membersihkan alarm lama.
                try { am.cancel(restorePi) } catch (_: Exception) { }
            }
            else -> {
                // Waktu sudah lewat tetapi catatan masih ada: retry mungkin sudah dijadwalkan.
                // Jangan batalkan PendingIntent ini, karena DND dapat tersangkut selamanya.
            }
        }
    }
    fun scheduleDndRestore(context: Context, triggerAtMillis: Long) {
        if (triggerAtMillis <= 0L) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        scheduleExact(am, triggerAtMillis, dndPending(context, "", 300, true))
    }

    /** Pulihkan DND ketika durasi habis dan coba ulang bila Android menolak perubahan. */
    fun restoreExpiredDnd(context: Context) {
        val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
        val until = state.getLong("prayer_dnd_active_until", 0L)
        if (until <= 0L) return
        val now = System.currentTimeMillis()
        if (now < until) {
            scheduleDndRestore(context, until)
            return
        }
        if (Build.VERSION.SDK_INT >= 23) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
            if (nm == null || !nm.isNotificationPolicyAccessGranted) {
                scheduleDndRestore(context, now + 60_000L)
                return
            }
            val previous = state.getInt("prayer_dnd_previous_filter", android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
            try {
                nm.setInterruptionFilter(previous)
                if (nm.currentInterruptionFilter != previous) {
                    scheduleDndRestore(context, now + 60_000L)
                    return
                }
            } catch (_: Exception) {
                scheduleDndRestore(context, now + 60_000L)
                return
            }
        }
        state.edit().remove("prayer_dnd_active_until").remove("prayer_dnd_previous_filter").apply()
    }

    private fun scheduleExact(am: AlarmManager, trigger: Long, pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi)
        } catch (_: SecurityException) { try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi) } catch (_: Exception) { } }
        catch (_: Exception) { }
    }
    private fun dndPending(context: Context, key: String, request: Int, restore: Boolean): PendingIntent {
        val i = Intent(context, PrayerAlarmReceiver::class.java).setAction(if (restore) "com.novan.jambicarapro.RESTORE_PRAYER_DND" else "com.novan.jambicarapro.START_PRAYER_DND")
            .putExtra("prayer_key", key).putExtra("restore_dnd", restore)
        return PendingIntent.getBroadcast(context, 700 + request, i, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    }
    private fun prayerMinutes(context: Context, pp: PrayerPrefs, date: LocalDate, key: String): Int {
        // Waktu khusus adalah jam harian yang dipilih pengguna; jika nonaktif, pakai perhitungan standar.
        if (key == "dhuha" && pp.dhuhaCustomEnabled) return pp.dhuhaCustomMinute
        if (key == "tahajud" && pp.tahajudCustomEnabled) return pp.tahajudCustomMinute
        val zone = ZoneId.systemDefault()
        if (pp.autoOnline) {
            PrayerOnlineTimes.minutes(context = context, date = date, key = key)?.let { onlineMinute ->
                return onlineMinute
            }
        }
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, zone, pp.method, pp.asrFactor, pp.adjustments())
        return PrayerCalc.minutes(when (key) {
            "imsak" -> t.imsak
            "subuh" -> t.fajr
            "terbit" -> t.sunrise
            "dhuha" -> t.dhuha
            "tahajud" -> PrayerCalc.tahajud(date, pp.lat, pp.lon, zone, pp.method, pp.asrFactor, pp.adjustments(), 0)
            "dzuhur" -> t.dhuhr
            "ashar" -> t.asr
            "maghrib" -> t.maghrib
            else -> t.isha
        })
    }
    private fun pending(context: Context, key: String, request: Int): PendingIntent {
        val i = Intent(context, PrayerAlarmReceiver::class.java).putExtra("prayer_key", key)
        if (request in 100..104) i.putExtra("advance_reminder", true)
        if (request == 400) i.putExtra("sahur_reminder", true)
        if (request == 401) i.putExtra("berbuka_reminder", true)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        return PendingIntent.getBroadcast(context, 700 + request, i, flags)
    }
    fun label(key: String) = labels[key] ?: key
}
