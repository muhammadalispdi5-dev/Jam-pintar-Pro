package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("prayer_key") ?: return
        val pp = PrayerPrefs(context)
        if (pp.enabled && pp.reminder(key)) {
            val service = Intent(context, PrayerAlarmService::class.java).putExtra("prayer_key", key)
            try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
        }
        PrayerAlarm.scheduleAll(context)
    }
}
