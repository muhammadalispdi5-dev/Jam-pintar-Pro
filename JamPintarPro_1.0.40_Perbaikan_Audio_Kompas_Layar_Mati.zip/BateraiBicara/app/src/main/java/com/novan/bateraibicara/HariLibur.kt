package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

/** Data libur nasional dan cuti bersama dipisahkan seperti acuan main.lua. */
object HariLibur {
    private val formatIso = DateTimeFormatter.ISO_LOCAL_DATE
    private val sedangSinkron = HashSet<String>()

    private val nasional2026Id = mapOf(
        "2026-01-01" to "Tahun Baru Masehi",
        "2026-01-16" to "Isra Mikraj Nabi Muhammad SAW",
        "2026-02-17" to "Tahun Baru Imlek 2577 Kongzili",
        "2026-03-19" to "Hari Suci Nyepi Tahun Baru Saka 1948",
        "2026-03-21" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-03-22" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-04-03" to "Wafat Yesus Kristus",
        "2026-04-05" to "Kebangkitan Yesus Kristus Paskah",
        "2026-05-01" to "Hari Buruh Internasional",
        "2026-05-14" to "Kenaikan Yesus Kristus",
        "2026-05-27" to "Hari Raya Idul Adha 1447 Hijriah",
        "2026-05-31" to "Hari Raya Waisak 2570 BE",
        "2026-06-01" to "Hari Lahir Pancasila",
        "2026-06-16" to "Tahun Baru Islam 1448 Hijriah",
        "2026-08-17" to "Hari Proklamasi Kemerdekaan Republik Indonesia",
        "2026-08-25" to "Maulid Nabi Muhammad SAW",
        "2026-12-25" to "Hari Raya Natal"
    )
    private val nasional2026En = mapOf(
        "2026-01-01" to "New Year's Day", "2026-01-16" to "Ascension of the Prophet Muhammad",
        "2026-02-17" to "Chinese New Year 2577 Kongzili", "2026-03-19" to "Nyepi Saka 1948",
        "2026-03-21" to "Eid al-Fitr 1447 Hijriah", "2026-03-22" to "Eid al-Fitr 1447 Hijriah",
        "2026-04-03" to "Good Friday", "2026-04-05" to "Easter Sunday",
        "2026-05-01" to "International Labor Day", "2026-05-14" to "Ascension Day of Jesus Christ",
        "2026-05-27" to "Eid al-Adha 1447 Hijriah", "2026-05-31" to "Vesak Day 2570 BE",
        "2026-06-01" to "Pancasila Day", "2026-06-16" to "Islamic New Year 1448 Hijriah",
        "2026-08-17" to "Indonesian Independence Day", "2026-08-25" to "The Prophet's Birthday",
        "2026-12-25" to "Christmas Day"
    )
    private val cuti2026Id = mapOf(
        "2026-02-16" to "Tahun Baru Imlek", "2026-03-18" to "Hari Suci Nyepi",
        "2026-03-20" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-03-23" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-03-24" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-05-15" to "Kenaikan Yesus Kristus",
        "2026-05-28" to "Hari Raya Idul Adha 1447 Hijriah",
        "2026-12-24" to "Hari Raya Natal"
    )
    private val cuti2026En = mapOf(
        "2026-02-16" to "Chinese New Year", "2026-03-18" to "Nyepi Day",
        "2026-03-20" to "Eid al-Fitr 1447 Hijriah", "2026-03-23" to "Eid al-Fitr 1447 Hijriah",
        "2026-03-24" to "Eid al-Fitr 1447 Hijriah", "2026-05-15" to "Ascension Day",
        "2026-05-28" to "Eid al-Adha 1447 Hijriah", "2026-12-24" to "Christmas Day"
    )

    private fun key(date: LocalDate) = date.format(formatIso)
    private fun cacheKey(kind: String, date: LocalDate) = "hol_${kind}_${key(date)}"
    private fun lang(p: Prefs) = p.jamBahasaIdx

    private fun staticName(kind: String, date: LocalDate, language: Int): String? {
        if (date.year != 2026) return null
        val k = key(date)
        return when (kind) {
            "national" -> if (language == 1) nasional2026En[k] else nasional2026Id[k]
            else -> if (language == 1) cuti2026En[k] else cuti2026Id[k]
        }
    }

    private fun name(context: Context, kind: String, date: LocalDate, language: Int): String? {
        val cached = context.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
            .getString(cacheKey(kind, date), null)
        val original = cached?.takeIf { it.isNotBlank() } ?: staticName(kind, date, language) ?: return null
        if (language != 3) return original
        // Padanan ringkes basa Jawa, manut fungsi translateHolidayNameJv ing acuan Lua.
        val padanan = listOf(
            "Hari Raya Idul Fitri" to "Riyaya Idul Fitri",
            "Hari Raya Idul Adha" to "Riyaya Idul Adha",
            "Tahun Baru Islam" to "Taun Anyar Islam",
            "Isra Mikraj Nabi Muhammad SAW" to "Isra Mikraj Kanjeng Nabi Muhammad SAW",
            "Isra Mikraj Nabi Muhammad S.A.W." to "Isra Mikraj Kanjeng Nabi Muhammad SAW",
            "Hari Suci Nyepi" to "Dinten Riyaya Nyepi",
            "Hari Raya Waisak" to "Dinten Riyaya Waisak",
            "Hari Lahir Pancasila" to "Dinten Lairipun Pancasila",
            "Hari Proklamasi Kemerdekaan Republik Indonesia" to "Dinten Kamardikan Republik Indonesia",
            "Kenaikan Yesus Kristus" to "Minggahipun Yesus Kristus",
            "Wafat Yesus Kristus" to "Pasedanipun Yesus Kristus",
            "Kebangkitan Yesus Kristus Paskah" to "Kebangkitan Yesus Kristus Paskah",
            "Hari Raya Natal" to "Dinten Natal",
            "Maulid Nabi Muhammad SAW" to "Maulid Kanjeng Nabi Muhammad SAW"
        )
        return padanan.fold(original) { teks, (asal, ganti) -> teks.replace(asal, ganti) }
    }

    /** Sinkronisasi jaringan dijalankan di thread terpisah; kegagalan tidak menghapus cache/offline. */
    fun syncIfNeeded(context: Context, p: Prefs, year: Int = Calendar.getInstance().get(Calendar.YEAR)) {
        val national = p.liburNasionalAutoSync
        val joint = p.cutiBersamaAutoSync
        if (!national && !joint) return
        val prefs = context.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        val lockKey = "hol_sync_year_${year}_${if (national && joint) "both" else if (national) "national" else "joint"}"
        if (prefs.getInt(lockKey, 0) == year) return
        synchronized(sedangSinkron) {
            if (!sedangSinkron.add(lockKey)) return
        }
        Thread {
            try {
                val conn = (URL("https://dayoffapi.vercel.app/api?year=$year").openConnection() as HttpURLConnection)
                conn.requestMethod = "GET"
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.useCaches = false
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val arr = JSONArray(body)
                    val editor = prefs.edit()
                    var ditemukan = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val rawDate = item.optString("tanggal", "")
                        val name = item.optString("keterangan", "").trim()
                        if (rawDate.isBlank() || name.isBlank()) continue
                        val date = try { LocalDate.parse(rawDate.take(10), formatIso) } catch (_: Exception) { continue }
                        if (date.year != year) continue
                        val isJoint = item.optBoolean("is_cuti", false)
                        if (isJoint && joint) editor.putString(cacheKey("joint", date), name)
                        if (!isJoint && national) editor.putString(cacheKey("national", date), name)
                        if ((isJoint && joint) || (!isJoint && national)) ditemukan++
                    }
                    if (ditemukan > 0) {
                        editor.putInt(lockKey, year).putLong("hol_sync_time_$year", System.currentTimeMillis()).apply()
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
                // Tetap gunakan data offline dan cache sebelumnya.
            } finally {
                synchronized(sedangSinkron) { sedangSinkron.remove(lockKey) }
            }
        }.start()
    }

    private fun nearest(context: Context, p: Prefs, kind: String, start: LocalDate, direction: Long): Pair<LocalDate, String>? {
        // Sama dengan acuan: cari sampai 3660 hari, bukan dibatasi 7 hari.
        for (offset in 1L..3660L) {
            val date = start.plusDays(offset * direction)
            val holiday = name(context, kind, date, lang(p))
            if (holiday != null) return date to holiday
        }
        return null
    }

    private fun tanggal(date: LocalDate, p: Prefs): String {
        val bahasa = lang(p)
        val english = bahasa == 1
        val urutHari = date.dayOfWeek.value % 7 // Ahad/Minggu = indeks 0
        val hariId = arrayOf("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
        val hariJv = arrayOf("Ahad", "Senen", "Selasa", "Rebo", "Kemis", "Jemuah", "Setu")
        val bulanId = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
        val day = if (english) date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)
            else if (bahasa == 3) hariJv[urutHari] else hariId[urutHari]
        val month = if (english) date.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH) else bulanId[date.monthValue - 1]
        return when {
            english -> "$day, $month ${date.dayOfMonth}, ${date.year}"
            bahasa == 3 -> "Dinten $day tanggal ${date.dayOfMonth} $month taun ${date.year}"
            else -> "hari $day tanggal ${date.dayOfMonth} $month ${date.year}"
        }
    }

    private fun addCategory(out: MutableList<String>, context: Context, p: Prefs, kind: String, date: LocalDate, pastOn: Boolean, currentOn: Boolean, upcomingOn: Boolean) {
        if (!pastOn && !currentOn && !upcomingOn) return
        val label = if (kind == "national") "libur nasional" else "cuti bersama"
        val english = lang(p) == 1
        if (pastOn) nearest(context, p, kind, date, -1)?.let { (d, n) ->
            out += if (english) "the most recent past $label was $n on ${tanggal(d, p)}." else "$label terakhir yang sudah lewat yaitu $n pada ${tanggal(d, p)}."
        }
        if (currentOn) {
            val today = name(context, kind, date, lang(p))
            out += if (today != null) {
                if (english) "today's $label is $today on ${tanggal(date, p)}." else "$label hari ini yaitu $today pada ${tanggal(date, p)}."
            } else if (english) "there is no $label today in the available calendar data." else "hari ini tidak ada $label yang tercatat pada data kalender."
        }
        if (upcomingOn) nearest(context, p, kind, date, 1)?.let { (d, n) ->
            out += if (english) "the next upcoming $label is $n on ${tanggal(d, p)}." else "$label terdekat berikutnya yaitu $n pada ${tanggal(d, p)}."
        }
    }

    /** Hanya segmen yang diaktifkan pengguna yang ikut dalam pengumuman tanggal otomatis. */
    fun segmen(p: Prefs, calendar: Calendar): List<String> {
        if (p.liburNasionalAutoSync || p.cutiBersamaAutoSync) syncIfNeeded(p.appContext, p, calendar.get(Calendar.YEAR))
        val date = LocalDate.of(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH))
        val out = ArrayList<String>()
        addCategory(out, p.appContext, p, "national", date, p.liburNasionalLampau, p.liburNasionalTerkini, p.liburNasionalMendatang)
        addCategory(out, p.appContext, p, "joint", date, p.cutiBersamaLampau, p.cutiBersamaTerkini, p.cutiBersamaMendatang)
        return out
    }

    /** Bacakan seluruh ringkasan satu kategori, terlepas dari sakelar info otomatis. */
    fun ringkasan(context: Context, p: Prefs, kind: String): List<String> {
        syncIfNeeded(context, p)
        val today = LocalDate.now()
        val label = if (kind == "national") "libur nasional" else "cuti bersama"
        val current = name(context, kind, today, lang(p))
        val past = nearest(context, p, kind, today, -1)
        val future = nearest(context, p, kind, today, 1)
        val out = mutableListOf("Informasi $label.")
        out += if (current != null) "Hari ini terdapat $label: $current, tanggal ${today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))}." else "Hari ini tidak ada $label yang tercatat pada data kalender."
        if (past != null) out += "Yang terakhir sudah lewat: ${past.second}, tanggal ${past.first.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))}."
        if (future != null) out += "Yang akan datang berikutnya: ${future.second}, tanggal ${future.first.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))}."
        if (past == null && future == null && current == null) out += "Data untuk tahun ini belum tersedia. Periksa pembaruan kalender."
        return out
    }
}
