package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val aksi = intent.action
        if (aksi == Intent.ACTION_BOOT_COMPLETED ||
            aksi == "android.intent.action.QUICKBOOT_POWERON" ||
            aksi == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val prefs = Prefs(context)
            if (prefs.enabled && prefs.bootOn) {
                try { BatteryTalkService.start(context) } catch (e: Exception) { }
            }
            // Jadwal sholat independen dari sakelar layanan baterai/jam.
            try { PrayerAlarm.scheduleAll(context) } catch (e: Exception) { }
        }
    }
}
