from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
a=(R/"AsmaulHusnaActivity.kt").read_text(encoding="utf-8"); d=(R/"AudioAsmaulHusna.kt").read_text(encoding="utf-8")
g=[]
for k in ("putarAudio(","unduhAudio(","dialogSumberAudio","jedaAudio","lepasAudio","audio_asmaul_husna","MediaPlayer"):
    if k not in a: g.append("GAGAL Activity: "+k)
for k in ("fun berkas","fun unduh","fun url","templatSah","{nnn}","https://","fun hapusUnduhan"):
    if k not in d: g.append("GAGAL Audio: "+k)
print("\n".join(g) if g else "UJI AUDIO ASMAUL HUSNA: LULUS")
