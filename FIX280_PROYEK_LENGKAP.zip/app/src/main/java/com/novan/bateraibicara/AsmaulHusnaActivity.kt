package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale
import android.app.AlertDialog
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper

/**
 * FIX272: Asmaul Husna (99 nama Allah). Beranda: cari, bacakan semua berurutan, daftar 99 nama.
 * Halaman nama: Arab, cara baca Latin, arti, dengarkan, sebelumnya/berikutnya, salin, bagikan.
 */
class AsmaulHusnaActivity : Halaman() {
    override val judulHalaman = R.string.judul_asmaul_husna

    private val simpan by lazy { getSharedPreferences("asmaul_husna", MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private var tertunda: (() -> Unit)? = null

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun arti(n: AsmaulHusnaData.Nama) = if (english) n.artiEn else n.artiId

    private var pemutar: MediaPlayer? = null
    private var urutanAudio = false
    private var nomorAudio = -1
    private var dijeda = false
    private val pengelola = Handler(Looper.getMainLooper())

    override fun onPause() {
        hentikanSuara()
        super.onPause()
    }

    override fun onDestroy() {
        hentikanSuara()
        try { tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("nomor", -1)
        val n = AsmaulHusnaData.daftar.getOrNull(nomor)
        if (n != null) halamanNama(nomor, n) else beranda()
    }

    // ---------- Beranda ----------

    private fun beranda() {
        info(tr(
            "Asmaul Husna adalah 99 nama Allah yang terbaik. Rasulullah shallallahu 'alaihi wasallam bersabda bahwa Allah memiliki sembilan puluh sembilan nama, siapa yang menghafal dan memahaminya akan masuk surga (HR. Al-Bukhari dan Muslim). Daftar yang dipakai di sini adalah daftar yang lazim digunakan; sebagian ulama menyusun daftar dengan sedikit perbedaan.",
            "Asmaul Husna are the 99 most beautiful names of Allah. The Messenger of Allah, peace be upon him, said that Allah has ninety-nine names, and whoever memorizes and understands them will enter Paradise (Al-Bukhari and Muslim). The list used here is the commonly used one; some scholars compile it with slight differences."
        ))
        tombol(tr("Pilih mesin suara pembaca", "Choose reading speech engine")) { pilihMesinSuara() }
        bagian(tr("Bacakan berurutan", "Read in order"))
        tombol(tr("Bacakan semua: cara baca Latin dan artinya", "Read all: Latin reading and meaning")) { bacaSemua(0, false) }
        tombol(tr("Bacakan semua: bacaan Arab", "Read all: Arabic")) { bacaSemua(0, true) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara(); toast(tr("Suara dihentikan.", "Audio stopped.")) }
        bagian(tr("Berkas audio", "Audio files"))
        info(statusAudio())
        tombol(tr("Putar audio semua nama berurutan", "Play audio of all names in order")) { putarAudio(0, true) }
        tombol(tr("Jeda atau lanjutkan audio", "Pause or resume audio")) { jedaAudio() }
        tombol(tr("Unduh audio semua nama (99)", "Download audio of all names (99)")) { unduhAudio((0 until 99).toList()) }
        tombol(tr("Atur sumber audio", "Set audio source")) { dialogSumberAudio() }
        var render: (String) -> Unit = { }
        val kolom = isian(tr("Cari nama atau nomor", "Search by name or number"), "", android.text.InputType.TYPE_CLASS_TEXT) { render(it) }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        val mulai = root.childCount
        render = { teksCari ->
            while (root.childCount > mulai) root.removeViewAt(root.childCount - 1)
            val q = teksCari.trim().lowercase(Locale.ROOT)
            bagian(tr("Daftar 99 nama", "List of 99 names"))
            var ada = 0
            AsmaulHusnaData.daftar.forEachIndexed { i, n ->
                if (q.isEmpty() || cocok(i, n, q)) {
                    ada++
                    tombol((i + 1).toString() + ". " + n.latin + ", " + arti(n)) { buka(i) }
                }
            }
            if (ada == 0) info(tr("Tidak ada nama yang cocok.", "No matching name."))
        }
        render("")
    }

    private fun cocok(i: Int, n: AsmaulHusnaData.Nama, q: String): Boolean {
        val gudang = ((i + 1).toString() + " " + n.latin + " " + n.artiId + " " + n.artiEn).lowercase(Locale.ROOT) + " " +
            AsmaulHusnaData.normal(n.latin)
        return q.split(" ").filter { it.isNotEmpty() }.all { gudang.contains(it) || gudang.contains(AsmaulHusnaData.normal(it)) }
    }

    private fun buka(nomor: Int) {
        startActivity(Intent(this, AsmaulHusnaActivity::class.java).putExtra("nomor", nomor))
    }

    // ---------- Halaman satu nama ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 20f)

    private fun halamanNama(nomor: Int, n: AsmaulHusnaData.Nama) {
        bagian((nomor + 1).toString() + ". " + n.latin, 22f)
        info(tr("Nama ke-" + (nomor + 1) + " dari 99", "Name " + (nomor + 1) + " of 99"))
        subjudul(tr("Teks Arab", "Arabic text"))
        val ar = TextView(this)
        ar.text = n.arab
        ar.textSize = ukuran() + 10f
        ar.setTextColor(warnaTeks())
        ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        ar.setPadding(0, dp(8), 0, dp(8))
        root.addView(ar)
        subjudul(tr("Cara baca (Latin)", "Transliteration"))
        paragraf(n.latin)
        subjudul(tr("Artinya", "Meaning"))
        paragraf(arti(n))

        subjudul(tr("Dengarkan", "Listen"))
        tombol(tr("Dengarkan bacaan Arab", "Listen to the Arabic")) { ucapkan(listOf(n.arab), Locale("ar"), true) }
        tombol(tr("Dengarkan cara baca Latin dan artinya", "Listen to the Latin reading and meaning")) {
            ucapkan(listOf(n.latin + ". " + arti(n)), if (english) Locale.US else Locale("id", "ID"), false)
        }
        tombol(tr("Bacakan mulai dari nama ini", "Read starting from this name")) { bacaSemua(nomor, false) }
        subjudul(tr("Berkas audio", "Audio file"))
        info(if (AudioAsmaulHusna.berkas(this, nomor + 1) != null) tr("Audio tersimpan di HP.", "Audio is saved on this phone.") else tr("Audio belum diunduh.", "Audio is not downloaded yet."))
        tombol(tr("Putar audio nama ini", "Play audio of this name")) { putarAudio(nomor, false) }
        tombol(tr("Putar audio mulai dari nama ini berurutan", "Play audio in order from this name")) { putarAudio(nomor, true) }
        tombol(tr("Jeda atau lanjutkan audio", "Pause or resume audio")) { jedaAudio() }
        tombol(tr("Unduh audio nama ini", "Download audio of this name")) { unduhAudio(listOf(nomor)) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara() }

        subjudul(tr("Pengaturan dan bagikan", "Settings and sharing"))
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(36f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }
        val semua = (nomor + 1).toString() + ". " + n.arab + "\n" + n.latin + "\n" + arti(n)
        tombol(tr("Salin nama", "Copy name")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("asmaul husna", semua))
                toast(tr("Nama disalin.", "Name copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan nama", "Share name")) {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua), tr("Bagikan nama", "Share name")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan teks.", "No app is available to share this text."))
            }
        }
        if (nomor > 0) tombol(tr("Nama sebelumnya", "Previous name")) { pindah(nomor - 1) }
        if (nomor < AsmaulHusnaData.daftar.size - 1) tombol(tr("Nama berikutnya", "Next name")) { pindah(nomor + 1) }
    }

    private fun pindah(nomor: Int) {
        startActivity(Intent(this, AsmaulHusnaActivity::class.java).putExtra("nomor", nomor))
        finish()
    }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 18f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(20), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun paragraf(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(2), 0, dp(6))
        root.addView(tv)
    }

    // ---------- Suara (teks-ke-ucapan) ----------

    // ---------- Audio berkas (FIX280) ----------

    private fun statusAudio(): String {
        val n = AudioAsmaulHusna.jumlahTersimpan(this)
        val sumber = if (AudioAsmaulHusna.templatSah(AudioAsmaulHusna.templat(this))) tr("Alamat server audio sudah diatur.", "An audio server address is set.")
            else tr("Alamat server audio belum diatur; atur sumber audio atau salin berkas 001.mp3 sampai 099.mp3 ke folder audio.", "No audio server address is set; set the audio source or copy files 001.mp3 to 099.mp3 into the audio folder.")
        return tr("Audio tersimpan: ", "Audio saved: ") + n + tr(" dari 99. ", " of 99. ") + sumber
    }

    private fun lepasAudio() {
        pengelola.removeCallbacksAndMessages(null)
        try { pemutar?.setOnCompletionListener(null); pemutar?.setOnErrorListener(null); pemutar?.stop() } catch (_: Exception) { }
        try { pemutar?.release() } catch (_: Exception) { }
        pemutar = null
        urutanAudio = false; dijeda = false; nomorAudio = -1
        PembungkamTelungkup.selesai("audio_asmaul_husna")
    }

    /** Memutar audio nama ke-(nomor+1): berkas lokal dulu, lalu server; urutan = lanjut ke nama berikutnya sampai ke-99. */
    private fun putarAudio(nomor: Int, urutan: Boolean) {
        if (nomor !in 0..98) return
        try { tts?.stop() } catch (_: Exception) { }
        lepasAudio()
        val lokal = AudioAsmaulHusna.berkas(this, nomor + 1)
        val sumber = lokal?.absolutePath ?: AudioAsmaulHusna.url(this, nomor + 1)
        if (sumber == null) {
            if (urutan && nomor < 98) { urutanAudio = true; pengelola.post { putarAudio(nomor + 1, true) }; return }
            toast(tr("Belum ada audio untuk nama ini. Unduh audio, salin berkas ke folder audio, atau atur alamat server audio.", "There is no audio for this name yet. Download the audio, copy the file to the audio folder, or set an audio server address."))
            return
        }
        urutanAudio = urutan
        nomorAudio = nomor
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(sumber)
            mp.setOnPreparedListener {
                try { it.start() } catch (_: Exception) { }
                toast(tr("Memutar: ", "Playing: ") + (nomor + 1) + ". " + AsmaulHusnaData.daftar[nomor].latin)
            }
            mp.setOnCompletionListener {
                if (urutanAudio && nomor < 98) { val b = nomor + 1; lepasPemutarSaja(); pengelola.postDelayed({ if (urutanAudio) putarAudio(b, true) }, 700L) }
                else lepasAudio()
            }
            mp.setOnErrorListener { _, _, _ ->
                val lanjut = urutanAudio && nomor < 98
                lepasPemutarSaja()
                if (lanjut) pengelola.post { putarAudio(nomor + 1, true) }
                else { lepasAudio(); toast(tr("Audio tidak dapat diputar. Periksa koneksi atau alamat server audio.", "The audio could not be played. Check the connection or the audio server address.")) }
                true
            }
            pemutar = mp
            PembungkamTelungkup.mulai(this, "audio_asmaul_husna", 3_600_000L) { runOnUiThread { lepasAudio() } }
            mp.prepareAsync()
        } catch (_: Exception) {
            lepasAudio()
            toast(tr("Audio tidak dapat diputar.", "The audio could not be played."))
        }
    }

    private fun lepasPemutarSaja() {
        try { pemutar?.setOnCompletionListener(null); pemutar?.setOnErrorListener(null) } catch (_: Exception) { }
        try { pemutar?.release() } catch (_: Exception) { }
        pemutar = null
    }

    private fun jedaAudio() {
        val p = pemutar
        if (p == null) { toast(tr("Tidak ada audio yang sedang diputar.", "No audio is playing.")); return }
        try {
            if (p.isPlaying) { p.pause(); dijeda = true; toast(tr("Audio dijeda.", "Audio paused.")) }
            else { p.start(); dijeda = false; toast(tr("Audio dilanjutkan.", "Audio resumed.")) }
        } catch (_: Exception) { }
    }

    private fun dialogSumberAudio() {
        val kolom = android.widget.EditText(this)
        kolom.setText(AudioAsmaulHusna.templat(this))
        kolom.hint = "https://example.com/asma/{nnn}.mp3"
        kolom.contentDescription = tr("Alamat server audio dengan {n} atau {nnn} sebagai nomor nama", "Audio server address with {n} or {nnn} as the name number")
        AlertDialog.Builder(this)
            .setTitle(tr("Sumber audio Asmaul Husna", "Asmaul Husna audio source"))
            .setMessage(tr("Isi alamat https yang memuat {n} (nomor 1 sampai 99) atau {nnn} (001 sampai 099). Contoh: https://situs-anda/asma/{nnn}.mp3. Audio yang diunduh disimpan di folder audio aplikasi; Anda juga dapat menyalin berkas 001.mp3 sampai 099.mp3 ke folder Jam Pintar Pro/Asmaul Husna di memori internal.\n\nFolder audio aplikasi: ",
                "Enter an https address containing {n} (number 1 to 99) or {nnn} (001 to 099). Example: https://your-site/asma/{nnn}.mp3. Downloaded audio is saved in the app audio folder; you can also copy files 001.mp3 to 099.mp3 into Jam Pintar Pro/Asmaul Husna in internal storage.\n\nApp audio folder: ") + AudioAsmaulHusna.folderAplikasi(this).absolutePath)
            .setView(kolom)
            .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                val t = kolom.text.toString().trim()
                if (t.isEmpty() || AudioAsmaulHusna.templatSah(t)) { AudioAsmaulHusna.setTemplat(this, t); toast(tr("Sumber audio disimpan.", "Audio source saved.")) }
                else toast(tr("Alamat harus diawali https:// dan memuat {n} atau {nnn}.", "The address must start with https:// and contain {n} or {nnn}."))
            }
            .setNeutralButton(tr("Hapus unduhan", "Delete downloads")) { _, _ -> lepasAudio(); toast(tr("Berkas dihapus: ", "Files deleted: ") + AudioAsmaulHusna.hapusUnduhan(this)) }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun unduhAudio(daftar: List<Int>) {
        if (AudioAsmaulHusna.url(this, 1) == null) {
            toast(tr("Atur alamat server audio dulu.", "Set the audio server address first."))
            dialogSumberAudio(); return
        }
        val dlg = android.app.ProgressDialog(this)
        dlg.setTitle(tr("Mengunduh audio Asmaul Husna", "Downloading Asmaul Husna audio"))
        dlg.setMessage(tr("Menyiapkan unduhan…", "Preparing download…"))
        dlg.setCancelable(true)
        var batal = false
        dlg.setOnCancelListener { batal = true }
        dlg.show()
        val app = applicationContext
        Thread {
            var ok = 0; var gagal = 0
            for ((i, nomor) in daftar.withIndex()) {
                if (batal) break
                runOnUiThread { dlg.setMessage(tr("Mengunduh ", "Downloading ") + (i + 1) + "/" + daftar.size) }
                if (AudioAsmaulHusna.berkas(app, nomor + 1)?.parentFile == AudioAsmaulHusna.folderAplikasi(app)) { ok++; continue }
                try { AudioAsmaulHusna.unduh(app, nomor + 1); ok++ } catch (_: Exception) { gagal++ }
            }
            runOnUiThread {
                try { dlg.dismiss() } catch (_: Exception) { }
                toast(tr("Unduhan selesai: ", "Download finished: ") + ok + tr(" berhasil, ", " succeeded, ") + gagal + tr(" gagal.", " failed."))
            }
        }.start()
    }

    private fun hentikanSuara() {
        lepasAudio()
        BacaanBisaDibungkam.lepas("baca_asmaul_husna")
        try { tts?.stop() } catch (_: Exception) { }
    }

    private fun pilihMesinSuara() {
        MesinSuaraPembaca.tampilkan(this, simpan) {
            try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
            tts = null; ttsSiap = false; tertunda = null
        }
    }

    /** Membacakan semua nama mulai dari [awal] secara berurutan; tiap nama menjadi satu ucapan dalam antrean. */
    private fun bacaSemua(awal: Int, arab: Boolean) {
        val bagian = AsmaulHusnaData.daftar.drop(awal)
        val teks = if (arab) bagian.map { it.arab }
        else bagian.mapIndexed { i, n -> (awal + i + 1).toString() + ". " + n.latin + ". " + arti(n) + "." }
        ucapkan(teks, if (arab) Locale("ar") else if (english) Locale.US else Locale("id", "ID"), arab)
    }

    private fun ucapkan(potongan: List<String>, bahasa: Locale, arab: Boolean) {
        denganTts {
            val m = tts
            if (m != null) {
                val r = m.setLanguage(bahasa)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    toast(
                        if (arab) tr("Suara bahasa Arab belum terpasang di perangkat. Pasang data suara Arab pada pengaturan teks-ke-ucapan Android, atau gunakan cara baca Latin.",
                            "The Arabic voice is not installed on this device. Install Arabic voice data in Android text-to-speech settings, or use the Latin reading.")
                        else tr("Data suara untuk bahasa ini belum terpasang. Pasang pada pengaturan teks-ke-ucapan Android.",
                            "Voice data for this language is not installed. Install it in Android text-to-speech settings.")
                    )
                } else {
                    m.stop()
                    var pertama = true
                    var panjang = 0
                    for (p in potongan) {
                        m.speak(p, if (pertama) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "asma_" + System.nanoTime())
                        pertama = false
                        panjang += p.length
                    }
                    BacaanBisaDibungkam.mulai(this, m, "baca_asmaul_husna", panjang) { try { m.stop() } catch (_: Exception) { } }
                }
            }
        }
    }

    private fun denganTts(aksi: () -> Unit) {
        if (ttsSiap) { aksi(); return }
        tertunda = aksi
        if (tts == null) {
            val mesin = MesinSuaraPembaca.paket(simpan).ifBlank { null }
            tts = TextToSpeech(applicationContext, { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsSiap = true
                    val a = tertunda
                    tertunda = null
                    a?.invoke()
                } else {
                    toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = null
                    tertunda = null
                }
            }, mesin)
        }
    }
}
