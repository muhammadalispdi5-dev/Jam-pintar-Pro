package com.novan.bateraibicara

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Calendar

/**
 * FIX84: perintah suara Beritahu Saya.
 * Dibuka dengan ketuk tahan pada ikon Beritahu Saya (pintasan aplikasi) atau ketuk tahan pada saklar
 * pemicu Beritahu Saya di layar utama aplikasi. Layar pengenalan suara sistem dibuka (tanpa izin
 * mikrofon aplikasi), lalu perintah dijalankan: waktu, tanggal, atau memutar Al-Qur'an.
 * Bahasa pengenalan, teks, dan pesan mengikuti bahasa tampilan utama yang aktif.
 */
class PerintahSuaraActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutup() }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)
        if (!prefs.beritahuSayaOn) {
            Toast.makeText(this, getString(R.string.beritahu_saya_nonaktif_petunjuk), Toast.LENGTH_LONG).show()
            selesai = true
            finish()
            return
        }
        if (savedInstanceState == null) mulai()
    }

    /** Bila "Suara TalkBack saat mikrofon dipakai" dimatikan (Khatam), senyapkan TalkBack, beri getar, lalu buka mikrofon. */
    private fun mulai() {
        val senyap = getSharedPreferences("khatam_quran", MODE_PRIVATE).getBoolean("senyap_talkback_pergantian_audio", false)
        if (senyap) {
            try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
            getar(150L)
            handler.postDelayed({ if (!isFinishing) bukaPengenalan(false) }, 800L)
        } else {
            bukaPengenalan(true)
        }
    }

    private fun bukaPengenalan(denganPetunjuk: Boolean) {
        val bahasaAktif = BahasaAplikasi.tampilan(this)
        val tagBahasa = when (bahasaAktif) {
            1 -> "en-US"
            2 -> "ar-SA"
            3 -> "jv-ID"
            4 -> "su-ID"
            else -> "id-ID"
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasa)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasa)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                if (denganPetunjuk) putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.perintah_suara_petunjuk))
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, KODE_PENGENALAN)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            tutup()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != KODE_PENGENALAN) return
        val kandidat = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty() else emptyList<String>()
        if (kandidat.isEmpty()) { tutup(); return }
        jalankan(kandidat)
    }

    private fun jalankan(kandidat: List<String>) {
        when (PerintahSuara.tafsir(kandidat)) {
            PerintahSuara.Jenis.WAKTU -> bacakan(waktu = true, tanggal = false)
            PerintahSuara.Jenis.TANGGAL -> bacakan(waktu = false, tanggal = true)
            PerintahSuara.Jenis.WAKTU_TANGGAL -> bacakan(waktu = true, tanggal = true)
            PerintahSuara.Jenis.TANGGAL_MASEHI -> bacakanKhusus { p, c -> KalenderTanggal.masehi(c, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_HIJRIAH -> bacakanKhusus { p, c ->
                KalenderTanggal.hijriah(c,
                    if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null,
                    p.bahasaAktif)
            }
            PerintahSuara.Jenis.LIBUR -> bacakanKhusus { p, _ ->
                val nasional = HariLibur.ringkasan(applicationContext, p, "national").drop(1)
                val cuti = HariLibur.ringkasan(applicationContext, p, "joint").drop(1)
                (nasional + cuti).joinToString(" ").ifBlank { pesanKosong(p, "holiday") }
            }
            PerintahSuara.Jenis.SHOLAT_BERIKUTNYA -> bacakanKhusus { p, c ->
                InfoSholat.segmen(p, c, abaikanSakelar = true).firstOrNull() ?: pesanKosong(p, "prayer")
            }
            PerintahSuara.Jenis.QURAN -> bukaKhatam(kandidat)
            PerintahSuara.Jenis.BUKA_FITUR -> bukaFitur(PerintahSuara.fitur(kandidat))
            PerintahSuara.Jenis.PANGGIL -> panggilKontak(kandidat)
            PerintahSuara.Jenis.PESAN -> bukaPesan(kandidat, baca = false)
            PerintahSuara.Jenis.BACA_PESAN -> bacaPesanTersimpan(kandidat)
            PerintahSuara.Jenis.CARI_PESAN -> cariPesanKontak(kandidat)
            PerintahSuara.Jenis.BUKA_APLIKASI -> bukaAplikasiDisebut(kandidat)
            PerintahSuara.Jenis.LIBUR_SPESIFIK -> bacakanKhusus { p, c -> HariLibur.jawabanKhusus(applicationContext, p, PerintahSuara.kategoriLibur(kandidat), PerintahSuara.periodeLibur(kandidat), c) }
            PerintahSuara.Jenis.TIDAK_DIKENAL -> {
                val didengar = kandidat.firstOrNull().orEmpty()
                getar(300L)
                Toast.makeText(
                    this,
                    getString(R.string.perintah_suara_tidak_dikenal) + (if (didengar.isNotBlank()) " (\"" + didengar + "\")" else ""),
                    Toast.LENGTH_LONG
                ).show()
                tutup()
            }
        }
    }

    private fun pesanKosong(p: Prefs, jenis: String): String = when (p.bahasaAktif) {
        1 -> if (jenis == "holiday") "No holiday information is available." else "Prayer time information is unavailable. Check your prayer location and schedule."
        2 -> if (jenis == "holiday") "لا تتوفر معلومات عن العطلات." else "معلومات أوقات الصلاة غير متاحة. تحقق من الموقع والجدول."
        3 -> if (jenis == "holiday") "Informasi preinan dereng cumawis." else "Informasi wekdal salat dereng cumawis. Priksa lokasi lan jadwal salat."
        4 -> if (jenis == "holiday") "Inpormasi libur teu sayogi." else "Inpormasi waktos salat teu sayogi. Pariksa lokasi sareng jadwal salat."
        else -> if (jenis == "holiday") "Informasi hari libur belum tersedia." else "Informasi waktu salat belum tersedia. Periksa lokasi dan jadwal salat."
    }

    /** Satu perintah spesifik menghasilkan satu jawaban saja; tidak menambahkan rangkaian tanggal/libur/sholat lain. */
    private fun bacakanKhusus(penyusun: (Prefs, Calendar) -> String) {
        try {
            val prefs = Prefs(applicationContext)
            val teks = penyusun(prefs, Calendar.getInstance()).trim()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl"))
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutup() }
        } catch (_: Exception) { tutup() }
    }

    /** Waktu dibacakan suara jam; tanggal umum mengikuti pengaturan rangkaian pengguna. */
    private fun bacakan(waktu: Boolean, tanggal: Boolean) {
        try {
            val prefs = Prefs(applicationContext)
            val c = Calendar.getInstance()
            val teksWaktu = if (waktu) JamWaktu.ucapan(prefs, c) else ""
            val segmenTanggal = if (tanggal) JamWaktu.segmenTanggal(prefs, c) else emptyList()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            fun bacaTanggal() {
                if (segmenTanggal.isEmpty()) { tutup(); return }
                val pt = Pembicara(applicationContext, prefs.suara("tgl"))
                pembicaraTanggal = pt
                pt.ucapkanRangkaian(segmenTanggal, 300L) { tutup() }
            }
            if (teksWaktu.isBlank()) {
                bacaTanggal()
            } else {
                val p = Pembicara(applicationContext, prefs.suara("jam"))
                pembicara = p
                p.ucapkan(teksWaktu, true) { bacaTanggal() }
            }
        } catch (_: Exception) {
            tutup()
        }
    }

    /** Membuka halaman fitur yang diminta secara langsung, tanpa menebak fitur lain. */
    private fun bukaFitur(fitur: PerintahSuara.Fitur?) {
        val tujuan = when (fitur) {
            PerintahSuara.Fitur.BATERAI -> BateraiActivity::class.java
            PerintahSuara.Fitur.JAM -> JamActivity::class.java
            PerintahSuara.Fitur.KALENDER -> KalenderActivity::class.java
            PerintahSuara.Fitur.PEMANGGIL -> PemanggilActivity::class.java
            PerintahSuara.Fitur.SHOLAT -> PrayerActivity::class.java
            PerintahSuara.Fitur.LOKASI -> LokasiTerkiniActivity::class.java
            PerintahSuara.Fitur.PEMANDU_JALAN -> PemanduJalanActivity::class.java
            PerintahSuara.Fitur.KIBLAT -> QiblaActivity::class.java
            PerintahSuara.Fitur.FASILITAS -> FasilitasTerdekatActivity::class.java
            PerintahSuara.Fitur.DOA -> TaarufDoaActivity::class.java
            PerintahSuara.Fitur.KHATAM -> KhatamActivity::class.java
            PerintahSuara.Fitur.MODE_ACARA -> ModeAcaraActivity::class.java
            PerintahSuara.Fitur.BAHASA -> BahasaActivity::class.java
            null -> null
        }
        if (tujuan == null) {
            val bahasa = Prefs(applicationContext).bahasaAktif
            val pesan = when (bahasa) {
                1 -> "I couldn't identify which app feature you meant. Please say the feature name."
                2 -> "لم أتمكن من تحديد الميزة المطلوبة. يرجى ذكر اسم الميزة."
                3 -> "Fitur ingkang dipun kersakaken dereng saged dipun mangertosi. Sebutaken nami fituripun."
                4 -> "Fitur anu dimaksud teu kahartos. Sebutkeun nami fiturna."
                else -> "Saya belum mengenali fitur yang dimaksud. Silakan sebutkan nama fiturnya."
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            tutup()
            return
        }
        try { startActivity(Intent(this, tujuan)) } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }


    /** Membuka dialer; panggilan hanya dilakukan setelah pengguna menekan tombol panggil. */
    private fun panggilKontak(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty()
        val angka = ucapan.filter { it.isDigit() || it == '+' }
        if (angka.count { it.isDigit() } < 3 && ucapan.lowercase().split(Regex("\\s+")).any { it in setOf("buka", "bukakan", "open") }) {
            try { startActivity(Intent(Intent.ACTION_DIAL)) } catch (_: Exception) { }
            tutup(); return
        }
        val nomor = if (angka.count { it.isDigit() } >= 3) angka else cariNomorKontak(ucapan)
        if (nomor.isNullOrBlank()) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "I couldn't find that contact. Check contact permission or say the phone number."
                2 -> "تعذر العثور على جهة الاتصال. تحقق من إذن جهات الاتصال أو قل رقم الهاتف."
                3 -> "Kontakipun dereng kapanggih. Priksa idin kontak utawi sebataken nomer telpon."
                4 -> "Kontak teu kapanggih. Pariksa idin kontak atanapi sebutkeun nomer telepon."
                else -> "Kontak tidak ditemukan. Periksa izin kontak atau sebutkan nomor telepon."
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show(); tutup(); return
        }
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) }
        catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun cariNomorKontak(ucapan: String): String? {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val nama = ucapan.lowercase().replace(Regex("(?i)\\b(tolong|silakan|please|call|telepon|telpon|panggil|hubungi|kontak|nomor|nomer|saya|aku)\\b"), " ").trim()
        if (nama.isBlank()) return null
        return try {
            val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
                var hasil: String? = null
                while (c.moveToNext()) {
                    val label = c.getString(1).orEmpty()
                    if (label.equals(nama, true) || label.contains(nama, true)) { hasil = c.getString(0); break }
                }
                hasil
            }
        } catch (_: Exception) { null }
    }


    /** Membacakan pesan masuk terakhir yang tersimpan dari notifikasi, bukan mengakses chat privat secara diam-diam. */
    private fun bacaPesanTersimpan(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        val isi = if (nama.isNotBlank()) RiwayatPesanSuara.cari(this, nama) else RiwayatPesanSuara.terbaru(this)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> "No recent incoming message is available in the notification history."
            2 -> "لا توجد رسالة واردة حديثة في سجل الإشعارات."
            3 -> "Pesen mlebet enggal dereng wonten ing riwayat notifikasi."
            4 -> "Teu aya talatah asup panganyarna dina riwayat béwara."
            else -> "Belum ada pesan masuk terbaru di riwayat notifikasi."
        }
        bacakanTeksLokal(teks)
    }

    private fun cariPesanKontak(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        if (nama.isBlank()) { bukaPesan(kandidat, baca = false); return }
        val isi = RiwayatPesanSuara.cari(this, nama)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> "No recent incoming message from $nama was found in notification history."
            2 -> "لم يتم العثور على رسالة واردة حديثة من $nama في سجل الإشعارات."
            3 -> "Pesen mlebet enggal saking $nama boten kapanggih ing riwayat notifikasi."
            4 -> "Teu kapanggih talatah asup panganyarna ti $nama dina riwayat béwara."
            else -> "Tidak ditemukan pesan masuk terbaru dari $nama di riwayat notifikasi."
        }
        bacakanTeksLokal(teks)
    }

    private fun bacakanTeksLokal(teks: String) {
        try {
            val prefs = Prefs(applicationContext)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl"))
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutup() }
        } catch (_: Exception) { tutup() }
    }

    /** Membuka aplikasi pesan. Pembacaan otomatis tetap mengikuti izin Notification Listener. */
    private fun bukaPesan(kandidat: List<String>, baca: Boolean) {
        val ucapan = kandidat.joinToString(" ").lowercase()
        try {
            val paket = when {
                ucapan.contains("whatsapp business") -> "com.whatsapp.w4b"
                ucapan.contains("whatsapp") || ucapan.contains("wa ") -> "com.whatsapp"
                else -> null
            }
            val intent = if (paket != null) packageManager.getLaunchIntentForPackage(paket)
                else Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            if (intent != null) startActivity(intent) else startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        if (baca) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Opened your messaging app. Incoming messages can be read aloud when notification access and message announcements are enabled."
                2 -> "تم فتح تطبيق الرسائل. يمكن قراءة الرسائل الواردة عند تفعيل الوصول إلى الإشعارات وإعلان الرسائل."
                3 -> "Aplikasi pesen sampun kabikak. Pesen mlebet saged dipunwaos nalika akses notifikasi lan pawartos pesen sampun aktif."
                4 -> "Aplikasi pesen parantos dibuka. Talatah asup tiasa dibacakeun upami aksés béwara sareng fitur maca talatah diaktipkeun."
                else -> "Aplikasi pesan dibuka. Pesan masuk dapat dibacakan jika akses notifikasi dan fitur pembacaan pesan sudah diaktifkan."
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    /** Mencocokkan nama aplikasi dengan label launcher yang terpasang. */
    private fun bukaAplikasiDisebut(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty().lowercase()
            .replace(Regex("(?i)\\b(buka|bukakan|jalankan|open|launch|aplikasi|app|tolong|please)\\b"), " ").trim()
        if (ucapan.isBlank()) { tutup(); return }
        try {
            val daftar = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val cocok = daftar.firstOrNull { it.loadLabel(packageManager).toString().equals(ucapan, true) }
                ?: daftar.firstOrNull { it.loadLabel(packageManager).toString().contains(ucapan, true) }
            val launch = cocok?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) startActivity(launch) else {
                val pesan = when (Prefs(applicationContext).bahasaAktif) {
                    1 -> "App not found. Say its name as shown on the home screen."
                    2 -> "لم يتم العثور على التطبيق. قل اسمه كما يظهر على الشاشة الرئيسية."
                    3 -> "Aplikasi boten kapanggih. Sebataken nami kados ingkang katingal ing layar utama."
                    4 -> "Aplikasi teu kapanggih. Sebutkeun nami sapertos dina layar utama."
                    else -> "Aplikasi tidak ditemukan. Sebutkan nama aplikasi seperti yang tampil di layar utama."
                }
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    /** Perintah putar Al-Qur'an diteruskan ke Khatam; Khatam menafsirkan surah/ayat/juz dan memutar audionya. */
    private fun bukaKhatam(kandidat: List<String>) {
        try {
            // FIX87: dari layar depan/pintasan/widget, Khatam hanya memutar audio lalu mengembalikan pengguna ke layar depan.
            // Bila perintah suara dibuka dari dalam aplikasi sendiri, pengguna tetap berada di Khatam seperti sebelumnya.
            val dariAplikasi = getIntent()?.getBooleanExtra(EXTRA_DARI_APLIKASI, false) ?: false
            val intent = Intent(this, KhatamActivity::class.java).apply {
                putStringArrayListExtra(KhatamActivity.EXTRA_PERINTAH_SUARA, ArrayList(kandidat))
                putExtra(KhatamActivity.EXTRA_KEMBALI_KE_LAYAR_DEPAN, !dariAplikasi)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        hentikanSuara()
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hentikanSuara()
        super.onDestroy()
    }

    companion object {
        private const val KODE_PENGENALAN = 6911
        /** FIX87: diisi true oleh pemanggil di dalam aplikasi agar pengguna tidak dikirim ke layar depan. */
        const val EXTRA_DARI_APLIKASI = "perintah_suara_dari_aplikasi"
    }
}

/** Penafsir perintah suara: menilai SEMUA alternatif pengenalan, lalu memilih maksud paling spesifik. */
object PerintahSuara {
    enum class Jenis { WAKTU, TANGGAL, WAKTU_TANGGAL, TANGGAL_MASEHI, TANGGAL_HIJRIAH, LIBUR, LIBUR_SPESIFIK, SHOLAT_BERIKUTNYA, CARI_PESAN, QURAN, BUKA_FITUR, PANGGIL, PESAN, BACA_PESAN, BUKA_APLIKASI, TIDAK_DIKENAL }
    enum class Fitur { BATERAI, JAM, KALENDER, PEMANGGIL, SHOLAT, LOKASI, PEMANDU_JALAN, KIBLAT, FASILITAS, DOA, KHATAM, MODE_ACARA, BAHASA }

    private val kataWaktu = setOf("waktu", "jam", "pukul", "time", "clock", "jamnya")
    private val kataTanggal = setOf("tanggal", "hari", "tgl", "date", "today", "day", "kalender", "calendar", "pasaran")
    private val kataSemua = setOf("semua", "lengkap", "semuanya", "everything", "all", "both")
    private val kataKerjaInfo = setOf("informasikan", "informasi", "info", "beritahu", "beritahukan", "sebutkan", "katakan", "bacakan", "baca", "tolong", "tell", "say", "give", "what", "whats", "read", "announce", "saya", "me")
    private val kataQuran = setOf("surah", "surat", "sura", "ayat", "ayah", "aya", "verse", "juz", "jus", "juzz", "murattal", "mushaf", "alquran", "quran", "quranul")
    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori")
    private val kataKerjaQari = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set", "choose", "select", "switch", "change", "use")
    private val kataKerjaBuka = setOf("buka", "bukakan", "tampilkan", "tunjukkan", "lihat", "masuk", "jalankan", "open", "launch", "show", "display", "go", "navigate", "akses")

    fun tafsir(kandidat: List<String>): Jenis {
        // Alternatif pertama dari mesin ASR sering terlalu umum. Prioritas numerik memastikan
        // tanggal Hijriah/shalat/libur dan aksi fitur selalu menang dari kata "tanggal" atau "waktu" umum.
        return kandidat.mapNotNull { tafsirSatu(it) }
            .maxByOrNull { prioritas(it) } ?: Jenis.TIDAK_DIKENAL
    }

    private fun prioritas(j: Jenis): Int = when (j) {
        Jenis.TANGGAL_HIJRIAH, Jenis.TANGGAL_MASEHI, Jenis.SHOLAT_BERIKUTNYA, Jenis.LIBUR, Jenis.LIBUR_SPESIFIK, Jenis.PANGGIL, Jenis.PESAN, Jenis.BACA_PESAN, Jenis.CARI_PESAN -> 110
        Jenis.QURAN -> 95
        Jenis.BUKA_FITUR -> 90
        Jenis.WAKTU_TANGGAL -> 40
        Jenis.WAKTU, Jenis.TANGGAL -> 30
        else -> 0
    }

    private fun token(ucapan: String): List<String> = ucapan.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun tafsirSatu(ucapan: String): Jenis? {
        val t = token(ucapan)
        if (t.isEmpty()) return null
        val frasa = t.joinToString(" ")
        val gabung = t.joinToString("")
        val kerjaBuka = t.any { it in kataKerjaBuka }
        val panggil = t.any { it in setOf("telepon", "telpon", "panggil", "hubungi", "call", "phone", "dial") }
        val pesan = t.any { it in setOf("pesan", "sms", "message", "messages", "whatsapp", "wa", "chat", "inbox", "kotak") }
        val baca = t.any { it in setOf("baca", "bacakan", "read", "listen", "dengarkan") }
        if (panggil) return Jenis.PANGGIL
        val cari = t.any { it in setOf("cari", "temukan", "search", "find", "from", "dari") }
        if (pesan && cari && t.any { it in setOf("ali", "bima") }) return Jenis.CARI_PESAN
        if (pesan && baca) return Jenis.BACA_PESAN
        if (pesan && (t.any { it in setOf("buka", "open", "lihat", "tampilkan", "cek", "periksa") } || t.size <= 3)) return Jenis.PESAN
        if (kerjaBuka && fiturDariToken(t) == null && t.any { it !in kataKerjaBuka && it !in setOf("aplikasi", "app", "tolong", "please") }) return Jenis.BUKA_APLIKASI
        // Aksi membuka fitur harus dibedakan dari pertanyaan informasi ("jam berapa", "tanggal apa").
        if (kerjaBuka && (t.any { it in kataQuran } || gabung.contains("quran"))) return Jenis.BUKA_FITUR
        if (kerjaBuka && fiturDariToken(t) != null) return Jenis.BUKA_FITUR
        val quran = t.any { it in kataQuran } || gabung.contains("quran")
        if (quran) return Jenis.QURAN
        val qari = t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
        if (qari) return Jenis.QURAN
        if (t.any { it in setOf("masehi", "gregorian") } || frasa.contains("tanggal masehi") || frasa.contains("gregorian date")) return Jenis.TANGGAL_MASEHI
        val kataLibur = t.any { it in setOf("libur", "liburan", "holiday", "holidays", "cuti", "vacation") } || frasa.contains("day off")
        if (kataLibur && (t.any { it in setOf("nasional", "national", "bersama", "joint", "today", "hari", "ini", "kemarin", "yesterday", "besok", "berikutnya", "mendatang", "upcoming", "next", "past", "terakhir", "lalu", "akan", "datang") })) return Jenis.LIBUR_SPESIFIK
        if (kataLibur) return Jenis.LIBUR
        if (t.any { it in setOf("hijriah", "hijriyah", "hijri", "islamic") } || frasa.contains("islamic date")) return Jenis.TANGGAL_HIJRIAH
        if (t.any { it in setOf("salat", "shalat", "sholat", "solat", "prayer", "prayers", "fajr", "subuh", "dzuhur", "zuhur", "ashar", "asar", "maghrib", "isya") } || frasa.contains("prayer time")) return Jenis.SHOLAT_BERIKUTNYA
        val waktu = t.any { it in kataWaktu }
        val tanggal = t.any { it in kataTanggal }
        val semua = t.any { it in kataSemua }
        return when {
            waktu && tanggal -> Jenis.WAKTU_TANGGAL
            waktu && semua -> Jenis.WAKTU_TANGGAL
            tanggal && semua -> Jenis.WAKTU_TANGGAL
            waktu -> Jenis.WAKTU
            tanggal -> Jenis.TANGGAL
            semua -> Jenis.WAKTU_TANGGAL
            t.any { it in kataKerjaInfo } && t.size <= 3 -> Jenis.WAKTU_TANGGAL
            else -> null
        }
    }

    fun namaKontakPesan(kandidat: List<String>): String {
        val gabung = kandidat.joinToString(" ").lowercase()
        return if (gabung.contains("ali") && gabung.contains("bima")) "Ali Bima" else ""
    }

    fun kategoriLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return if (t.any { it in setOf("cuti", "bersama", "joint") }) "joint" else "national"
    }
    fun periodeLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return when {
            t.any { it in setOf("kemarin", "kemarinnya", "yesterday", "lampau", "lalu", "past", "terakhir") } -> "past"
            t.any { it in setOf("besok", "mendatang", "berikutnya", "selanjutnya", "upcoming", "next") } || (t.contains("akan") && t.contains("datang")) -> "next"
            else -> "today"
        }
    }

    fun fitur(kandidat: List<String>): Fitur? = kandidat.asSequence().mapNotNull { fiturDariToken(token(it)) }.firstOrNull()

    private fun fiturDariToken(t: List<String>): Fitur? {
        val f = t.joinToString(" ")
        fun ada(vararg kata: String) = kata.any { k -> f.contains(k) || t.contains(k) }
        return when {
            ada("baterai", "battery") -> Fitur.BATERAI
            ada("kalender", "calendar") -> Fitur.KALENDER
            ada("pemanggil", "penelepon", "caller", "penelpon") -> Fitur.PEMANGGIL
            ada("jadwal sholat", "jadwal salat", "pengaturan sholat", "pengaturan salat", "prayer schedule", "waktu salat", "waktu sholat") -> Fitur.SHOLAT
            ada("pemandu jalan", "navigasi", "petunjuk jalan", "route guide", "road guide") -> Fitur.PEMANDU_JALAN
            ada("lokasi terkini", "lokasi saya", "current location", "my location") -> Fitur.LOKASI
            ada("kiblat", "qibla", "arah kiblat") -> Fitur.KIBLAT
            ada("fasilitas terdekat", "nearby facilities", "tempat terdekat") -> Fitur.FASILITAS
            ada("taaruf doa", "doa", "doa harian", "daily prayer", "supplication") -> Fitur.DOA
            ada("khatam", "hafalan", "quran", "alquran", "surah", "surat", "ayat", "juz") -> Fitur.KHATAM
            ada("mode acara", "event mode") -> Fitur.MODE_ACARA
            ada("bahasa", "language settings", "pengaturan bahasa") -> Fitur.BAHASA
            ada("jam", "clock") -> Fitur.JAM
            else -> null
        }
    }
}
