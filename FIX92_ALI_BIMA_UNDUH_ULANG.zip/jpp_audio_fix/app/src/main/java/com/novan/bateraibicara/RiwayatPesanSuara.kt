package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Cache privat lokal untuk pesan masuk yang memang ditampilkan oleh notifikasi Android. */
object RiwayatPesanSuara {
    private const val PREF = "riwayat_pesan_perintah_suara"
    private const val KEY = "items"
    private const val BATAS = 50
    private const val UMUR_MAKS = 7L * 24L * 60L * 60L * 1000L

    @Synchronized fun simpan(context: Context, pengirim: String, isi: String, aplikasi: String) {
        val nama = pengirim.trim()
        val pesan = isi.trim()
        if (nama.isBlank() || pesan.isBlank()) return
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val lama = bacaArray(prefs.getString(KEY, null))
        val sekarang = System.currentTimeMillis()
        val baru = JSONArray()
        for (i in 0 until lama.length()) {
            val item = lama.optJSONObject(i) ?: continue
            if (sekarang - item.optLong("waktu") in 0..UMUR_MAKS) baru.put(item)
        }
        baru.put(JSONObject().put("pengirim", nama).put("isi", pesan.take(1500))
            .put("aplikasi", aplikasi).put("waktu", sekarang))
        val ringkas = JSONArray()
        for (i in (baru.length() - BATAS).coerceAtLeast(0) until baru.length()) ringkas.put(baru.getJSONObject(i))
        prefs.edit().putString(KEY, ringkas.toString()).apply()
    }

    @Synchronized fun cari(context: Context, nama: String): String? {
        val target = nama.trim()
        if (target.isBlank()) return null
        val arr = bacaArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null))
        val sekarang = System.currentTimeMillis()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            if (sekarang - o.optLong("waktu") !in 0..UMUR_MAKS) continue
            val pengirim = o.optString("pengirim")
            if (pengirim.equals(target, true) || pengirim.contains(target, true)) {
                val isi = o.optString("isi").takeIf { it.isNotBlank() } ?: continue
                return "$pengirim. $isi"
            }
        }
        return null
    }

    @Synchronized fun terbaru(context: Context): String? {
        val arr = bacaArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null))
        val sekarang = System.currentTimeMillis()
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            if (sekarang - o.optLong("waktu") in 0..UMUR_MAKS) {
                val isi = o.optString("isi").takeIf { it.isNotBlank() } ?: continue
                return "${o.optString("pengirim")}. $isi"
            }
        }
        return null
    }

    private fun bacaArray(raw: String?): JSONArray = try { JSONArray(raw ?: "[]") } catch (_: Exception) { JSONArray() }
}
