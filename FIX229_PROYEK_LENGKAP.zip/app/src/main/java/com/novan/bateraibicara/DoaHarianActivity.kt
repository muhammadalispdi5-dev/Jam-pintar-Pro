package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale

/**
 * FIX226: Doa Sehari-hari Sesuai Sunnah. Beranda (cari + kategori) -> daftar doa per kategori -> halaman doa
 * (Arab, cara baca Latin, arti, kapan dibaca, sumber dan derajat hadits). Setiap doa dapat didengarkan:
 * bacaan Arab (jika suara Arab terpasang), cara baca Latin, dan artinya dalam bahasa aktif aplikasi.
 */
class DoaHarianActivity : Halaman() {
    override val judulHalaman = R.string.judul_doa_harian

    private val simpan by lazy { getSharedPreferences("doa_harian", MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private var tertunda: (() -> Unit)? = null

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun judul(d: DoaHarianData.Doa) = if (english) d.judulEn else d.judulId
    private fun nama(k: Pair<String, String>) = if (english) k.second else k.first

    override fun onPause() {
        try { tts?.stop() } catch (_: Exception) { }
        super.onPause()
    }

    override fun onDestroy() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("doa", -1)
        val kategori = intent.getIntExtra("kategori", -1)
        val d = DoaHarianData.daftar.getOrNull(nomor)
        when {
            d != null -> halamanDoa(nomor, d)
            kategori in DoaHarianData.kategori.indices -> daftarKategori(kategori)
            else -> beranda()
        }
    }

    // ---------- Beranda ----------

    private fun beranda() {
        info(tr(
            "Kumpulan doa sehari-hari yang diamalkan Rasulullah shallallahu 'alaihi wasallam, dikelompokkan menurut keperluannya: tidur, makan, bepergian, shalat, dzikir pagi dan petang, dan lainnya. Setiap doa disertai tulisan Arab, cara baca Latin, arti, waktu membaca, serta sumber dan derajat haditsnya (shahih atau hasan). Setiap doa juga dapat didengarkan. Arti bukan pengganti bacaan Arab; hafalkan lafaz Arabnya, dan pelajari bacaan yang benar dari guru.",
            "A collection of everyday supplications practiced by the Messenger of Allah, peace be upon him, grouped by need: sleeping, eating, travel, prayer, morning and evening remembrance, and more. Each supplication comes with the Arabic text, Latin transliteration, meaning, when to recite it, and its source and hadith grade (sahih or hasan). Each one can also be listened to. The meaning does not replace the Arabic wording; memorize the Arabic and learn correct recitation from a teacher."
        ))
        var render: (String) -> Unit = { }
        val kolom = isian(tr("Cari doa", "Search supplications"), "", android.text.InputType.TYPE_CLASS_TEXT) { render(it) }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        val mulai = root.childCount
        render = { teksCari ->
            while (root.childCount > mulai) root.removeViewAt(root.childCount - 1)
            val q = teksCari.trim().lowercase(Locale.ROOT)
            if (q.isEmpty()) {
                bagian(tr("Kategori doa", "Categories"))
                DoaHarianData.kategori.forEachIndexed { i, k ->
                    val jumlah = DoaHarianData.daftar.count { it.kategori == i }
                    tombol(nama(k) + ", " + jumlah + " " + tr("doa", "supplications")) {
                        startActivity(Intent(this, DoaHarianActivity::class.java).putExtra("kategori", i))
                    }
                }
            } else {
                var ada = 0
                DoaHarianData.daftar.forEachIndexed { i, d ->
                    if (cocok(d, q)) {
                        ada++
                        tombol(judul(d)) { buka(i) }
                    }
                }
                if (ada == 0) info(tr("Tidak ada doa yang cocok.", "No matching supplication."))
            }
        }
        render("")
    }

    private fun cocok(d: DoaHarianData.Doa, q: String): Boolean {
        val kat = DoaHarianData.kategori[d.kategori]
        val gudang = (d.judulId + " " + d.judulEn + " " + d.artiId + " " + d.artiEn + " " + d.latin + " " + kat.first + " " + kat.second)
            .lowercase(Locale.ROOT)
        return q.split(" ").filter { it.isNotEmpty() }.all { gudang.contains(it) }
    }

    private fun buka(nomor: Int) {
        startActivity(Intent(this, DoaHarianActivity::class.java).putExtra("doa", nomor))
    }

    // ---------- Daftar per kategori ----------

    private fun daftarKategori(kategori: Int) {
        bagian(nama(DoaHarianData.kategori[kategori]), 22f)
        var urut = 0
        DoaHarianData.daftar.forEachIndexed { i, d ->
            if (d.kategori == kategori) {
                urut++
                tombol(urut.toString() + ". " + judul(d)) { buka(i) }
            }
        }
    }

    // ---------- Halaman doa ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 20f)

    private fun halamanDoa(nomor: Int, d: DoaHarianData.Doa) {
        bagian(judul(d), 22f)
        info(nama(DoaHarianData.kategori[d.kategori]))

        subjudul(tr("Teks Arab", "Arabic text"))
        val ar = TextView(this)
        ar.text = d.arab
        ar.textSize = ukuran() + 6f
        ar.setTextColor(warnaTeks())
        ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        ar.setLineSpacing(0f, 1.4f)
        ar.setPadding(0, dp(8), 0, dp(8))
        root.addView(ar)

        subjudul(tr("Cara baca (Latin)", "Transliteration"))
        paragraf(d.latin)
        subjudul(tr("Artinya", "Meaning"))
        paragraf(if (english) d.artiEn else d.artiId)
        subjudul(tr("Kapan dibaca", "When to recite"))
        paragraf(if (english) d.kapanEn else d.kapanId)
        subjudul(tr("Sumber", "Source"))
        paragraf(if (english) d.sumberEn else d.sumberId)

        subjudul(tr("Dengarkan", "Listen"))
        tombol(tr("Dengarkan bacaan Arab", "Listen to the Arabic")) { ucapkan(d.arab, Locale("ar"), true) }
        tombol(tr("Dengarkan cara baca Latin", "Listen to the Latin reading")) { ucapkan(d.latin, Locale("id", "ID"), false) }
        tombol(tr("Dengarkan artinya", "Listen to the meaning")) {
            ucapkan(if (english) d.artiEn else d.artiId, if (english) Locale.US else Locale("id", "ID"), false)
        }
        tombol(tr("Hentikan suara", "Stop audio")) { try { tts?.stop() } catch (_: Exception) { } }

        subjudul(tr("Pengaturan dan bagikan", "Settings and sharing"))
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(36f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }
        val semua = teksLengkap(d)
        tombol(tr("Salin doa", "Copy supplication")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("doa", semua))
                toast(tr("Doa disalin.", "Supplication copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan doa", "Share supplication")) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua)
                startActivity(Intent.createChooser(i, tr("Bagikan doa", "Share supplication")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan doa.", "No app is available to share this text."))
            }
        }

        // Navigasi ke doa sebelumnya dan berikutnya dalam kategori yang sama.
        val sekategori = DoaHarianData.daftar.indices.filter { DoaHarianData.daftar[it].kategori == d.kategori }
        val posisi = sekategori.indexOf(nomor)
        if (posisi > 0) tombol(tr("Doa sebelumnya", "Previous supplication")) { pindah(sekategori[posisi - 1]) }
        if (posisi >= 0 && posisi < sekategori.size - 1) tombol(tr("Doa berikutnya", "Next supplication")) { pindah(sekategori[posisi + 1]) }
    }

    private fun pindah(nomor: Int) {
        startActivity(Intent(this, DoaHarianActivity::class.java).putExtra("doa", nomor))
        finish()
    }

    private fun teksLengkap(d: DoaHarianData.Doa): String = buildString {
        append(judul(d)).append("\n\n")
        append(d.arab).append("\n\n")
        append(d.latin).append("\n\n")
        append(if (english) d.artiEn else d.artiId).append("\n\n")
        append(if (english) d.sumberEn else d.sumberId)
    }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 18f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(20), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun paragraf(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(2), 0, dp(6))
        root.addView(tv)
    }

    // ---------- Suara (teks-ke-ucapan) ----------

    private fun ucapkan(teks: String, bahasa: Locale, arab: Boolean) {
        val aksi: () -> Unit = {
            val m = tts
            if (m != null) {
                val r = m.setLanguage(bahasa)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    toast(
                        if (arab) tr("Suara bahasa Arab belum terpasang di perangkat. Pasang data suara Arab pada pengaturan teks-ke-ucapan Android, atau gunakan tombol cara baca Latin.",
                            "The Arabic voice is not installed on this device. Install Arabic voice data in Android text-to-speech settings, or use the Latin reading button.")
                        else tr("Data suara untuk bahasa ini belum terpasang. Pasang pada pengaturan teks-ke-ucapan Android.",
                            "Voice data for this language is not installed. Install it in Android text-to-speech settings.")
                    )
                } else {
                    m.stop()
                    val maks = minOf(3500, TextToSpeech.getMaxSpeechInputLength() - 100)
                    var pertama = true
                    for (potongan in pecah(teks, maks)) {
                        m.speak(potongan, if (pertama) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "doa_" + System.nanoTime())
                        pertama = false
                    }
                }
            }
        }
        if (ttsSiap) { aksi(); return }
        tertunda = aksi
        if (tts == null) {
            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsSiap = true
                    val a = tertunda
                    tertunda = null
                    a?.invoke()
                } else {
                    toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = null
                    tertunda = null
                }
            }
        }
    }

    private fun pecah(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        var sisa = teks.trim()
        while (sisa.length > maks) {
            var potong = sisa.lastIndexOfAny(charArrayOf('.', '\n', ';', ':'), maks)
            if (potong < maks / 2) potong = sisa.lastIndexOf(' ', maks)
            if (potong <= 0) potong = maks - 1
            hasil.add(sisa.substring(0, potong + 1).trim())
            sisa = sisa.substring(potong + 1).trim()
        }
        if (sisa.isNotEmpty()) hasil.add(sisa)
        return hasil
    }
}
