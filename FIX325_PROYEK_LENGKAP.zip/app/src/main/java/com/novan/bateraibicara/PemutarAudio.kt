package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.nio.ByteOrder

/** Antarmuka pemutar murattal agar keluaran Stereo (MediaPlayer) dan Mono (downmix sendiri) dapat dipertukarkan. */
interface PemutarAudio {
    fun setOnPreparedListener(l: ((PemutarAudio) -> Unit)?)
    fun setOnCompletionListener(l: ((PemutarAudio) -> Unit)?)
    fun setOnErrorListener(l: ((PemutarAudio, Int, Int) -> Boolean)?)
    fun setAudioAttributes(a: AudioAttributes)
    fun setAudioSessionId(id: Int)
    val audioSessionId: Int
    fun setDataSource(context: Context, uri: Uri, headers: Map<String, String>)
    fun prepareAsync()
    fun start()
    fun pause()
    fun stop()
    fun release()
    fun reset()
    val isPlaying: Boolean
    var playbackParams: PlaybackParams
    /** FIX143: dipakai pemutar latar untuk menurunkan volume sementara (ducking). */
    fun setVolume(kiri: Float, kanan: Float)
    /** FIX311: durasi total (ms) bila diketahui, selain itu -1; posisi putar (ms). */
    val durasiMs: Int
    val posisiMs: Int
}

/** Keluaran stereo biasa: pembungkus tipis di atas MediaPlayer. */
class PemutarStereo : PemutarAudio {
    private val mp = MediaPlayer()

    override fun setOnPreparedListener(l: ((PemutarAudio) -> Unit)?) {
        if (l == null) mp.setOnPreparedListener(null) else mp.setOnPreparedListener { l(this) }
    }
    override fun setOnCompletionListener(l: ((PemutarAudio) -> Unit)?) {
        if (l == null) mp.setOnCompletionListener(null) else mp.setOnCompletionListener { l(this) }
    }
    override fun setOnErrorListener(l: ((PemutarAudio, Int, Int) -> Boolean)?) {
        if (l == null) mp.setOnErrorListener(null) else mp.setOnErrorListener { _, what, extra -> l(this, what, extra) }
    }
    override fun setAudioAttributes(a: AudioAttributes) { mp.setAudioAttributes(a) }
    override fun setAudioSessionId(id: Int) { mp.setAudioSessionId(id) }
    override val audioSessionId: Int get() = mp.audioSessionId
    override fun setDataSource(context: Context, uri: Uri, headers: Map<String, String>) { mp.setDataSource(context, uri, headers) }
    override fun prepareAsync() { mp.prepareAsync() }
    override fun start() { mp.start() }
    override fun pause() { mp.pause() }
    override fun stop() { mp.stop() }
    override fun release() { mp.release() }
    override fun reset() { mp.reset() }
    override val isPlaying: Boolean get() = try { mp.isPlaying } catch (_: Exception) { false }
    override var playbackParams: PlaybackParams
        get() = mp.playbackParams
        set(v) { mp.playbackParams = v }
    override fun setVolume(kiri: Float, kanan: Float) { mp.setVolume(kiri, kanan) }
    override val durasiMs: Int get() = try { mp.duration } catch (_: Exception) { -1 }
    override val posisiMs: Int get() = try { mp.currentPosition } catch (_: Exception) { 0 }
}

/**
 * Keluaran mono sungguhan: audio didekode dengan MediaCodec, semua kanal dirata-ratakan menjadi satu kanal,
 * lalu diputar lewat AudioTrack mono. Dengan begitu suara kiri dan kanan tergabung di kedua telinga/speaker.
 * FIX246: dengan [stereoPenuh] = true kelas yang sama memutar STEREO sungguhan lewat AudioTrack dua kanal (kiri dan kanan tetap
 * terpisah; sumber mono digandakan ke dua sisi). Dipakai untuk saluran volume selain media/dering/aksesibilitas karena MediaPlayer
 * pada sebagian perangkat menggabungkan kanal saat memakai usage notifikasi, alarm, panggilan suara atau sistem.
 */
class PemutarMono(
    private val stereoPenuh: Boolean = false,
    /** FIX311: gema nyata (DSP) pada audio yang sedang diputar; "normal" atau kekuatan 0 = tanpa gema. Boleh diubah saat memutar. */
    @Volatile var gemaKunci: String = "normal",
    @Volatile var gemaKekuatan: Int = 0
) : PemutarAudio {
    /** FIX320: batas ekor gema (ms) di akhir berkas; dipakai saat masih ada ayat berikutnya agar tanpa jeda panjang. */
    @Volatile var ekorMaksMs: Int = Int.MAX_VALUE
    private val utama = Handler(Looper.getMainLooper())
    private val kunci = Any()
    @Volatile private var dirilis = false
    @Volatile private var dijeda = false
    @Volatile private var mulai = false
    @Volatile private var selesai = false
    @Volatile private var kecepatan = 1f
    @Volatile private var durasiFormat = -1
    @Volatile private var frameKini = 0L
    @Volatile private var onPrepared: ((PemutarAudio) -> Unit)? = null
    @Volatile private var onCompletion: ((PemutarAudio) -> Unit)? = null
    @Volatile private var onError: ((PemutarAudio, Int, Int) -> Boolean)? = null
    private var atribut: AudioAttributes? = null
    private var sesi = 0
    private var ctx: Context? = null
    private var uri: Uri? = null
    private var header: Map<String, String> = emptyMap()
    @Volatile private var extractor: MediaExtractor? = null
    @Volatile private var codec: MediaCodec? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var threadDekode: Thread? = null
    private var rate = 44100
    private var kanal = 2

    override fun setOnPreparedListener(l: ((PemutarAudio) -> Unit)?) { onPrepared = l }
    override fun setOnCompletionListener(l: ((PemutarAudio) -> Unit)?) { onCompletion = l }
    override fun setOnErrorListener(l: ((PemutarAudio, Int, Int) -> Boolean)?) { onError = l }
    override fun setAudioAttributes(a: AudioAttributes) { atribut = a }
    override fun setAudioSessionId(id: Int) { sesi = id }
    override val audioSessionId: Int get() = track?.audioSessionId ?: sesi
    override fun setDataSource(context: Context, uri: Uri, headers: Map<String, String>) {
        this.ctx = context.applicationContext
        this.uri = uri
        this.header = headers
    }
    override fun reset() { }
    override val durasiMs: Int get() = durasiFormat
    override val posisiMs: Int get() = if (rate > 0) (frameKini * 1000L / rate).toInt() else 0
    override fun setVolume(kiri: Float, kanan: Float) { try { track?.setVolume(maxOf(kiri, kanan)) } catch (_: Exception) { } }

    override val isPlaying: Boolean get() = mulai && !dijeda && !selesai && !dirilis

    override var playbackParams: PlaybackParams
        get() = PlaybackParams().setSpeed(kecepatan).setPitch(1f)
        set(v) {
            try { kecepatan = v.speed } catch (_: Exception) { }
            if (mulai) terapkanKecepatan()
        }

    private fun kirim(aksi: () -> Unit) { utama.post { if (!dirilis) aksi() } }
    private fun kirimError() { kirim { onError?.invoke(this, 1, 0) } }

    private fun buatTrack(hz: Int): AudioTrack {
        val mask = if (stereoPenuh) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val minBuf = AudioTrack.getMinBufferSize(hz, mask, AudioFormat.ENCODING_PCM_16BIT)
        val atr = atribut ?: AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        val builder = AudioTrack.Builder()
            .setAudioAttributes(atr)
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(hz).setChannelMask(mask).build())
            .setBufferSizeInBytes(maxOf(minBuf * 2, hz * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (sesi > 0) builder.setSessionId(sesi)
        return builder.build().also { audioTrack ->
            // Mono memakai AudioTrack langsung; tetapkan gain digital normal agar setara Stereo.
            try { audioTrack.setVolume(1.0f) } catch (_: Exception) { }
        }
    }

    override fun prepareAsync() {
        val c = ctx ?: return
        val u = uri ?: return
        Thread {
            try {
                val ex = MediaExtractor()
                ex.setDataSource(c, u, header)
                var indeks = -1
                var fmt: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { indeks = i; fmt = f; break }
                }
                if (indeks < 0 || fmt == null) { try { ex.release() } catch (_: Exception) { }; throw IllegalStateException("tidak ada trek audio") }
                ex.selectTrack(indeks)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: throw IllegalStateException("mime kosong")
                val dc = MediaCodec.createDecoderByType(mime)
                dc.configure(fmt, null, null, 0)
                dc.start()
                rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                durasiFormat = try { (fmt.getLong(MediaFormat.KEY_DURATION) / 1000L).toInt() } catch (_: Exception) { -1 }
                kanal = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val tr = buatTrack(rate)
                var batal = false
                synchronized(kunci) {
                    if (dirilis) batal = true else { extractor = ex; codec = dc; track = tr }
                }
                if (batal) {
                    try { dc.stop() } catch (_: Exception) { }
                    try { dc.release() } catch (_: Exception) { }
                    try { ex.release() } catch (_: Exception) { }
                    try { tr.release() } catch (_: Exception) { }
                    return@Thread
                }
                kirim { onPrepared?.invoke(this) }
            } catch (e: Exception) {
                kirimError()
            }
        }.start()
    }

    private fun terapkanKecepatan() {
        try {
            track?.playbackParams = PlaybackParams().setSpeed(kecepatan).setPitch(1f)
            if (dijeda) track?.pause()
        } catch (_: Exception) { }
    }

    override fun start() {
        synchronized(kunci) {
            if (dirilis || track == null) return
            if (!mulai) {
                mulai = true
                dijeda = false
                terapkanKecepatan()
                try { track?.play() } catch (_: Exception) { }
                val t = Thread { dekode() }
                threadDekode = t
                t.start()
            } else {
                dijeda = false
                terapkanKecepatan()
                try { track?.play() } catch (_: Exception) { }
            }
        }
    }

    override fun pause() {
        dijeda = true
        try { track?.pause() } catch (_: Exception) { }
    }

    override fun stop() { matikan() }
    override fun release() { matikan() }

    private fun matikan() {
        synchronized(kunci) {
            dirilis = true
            // Jeda + flush membebaskan thread yang sedang menunggu write() pada buffer penuh.
            try { track?.pause(); track?.flush() } catch (_: Exception) { }
            if (threadDekode == null) bersihkan()
        }
    }

    private fun bersihkan() {
        val dc = codec
        val ex = extractor
        val tr = track
        codec = null
        extractor = null
        track = null
        try { dc?.stop() } catch (_: Exception) { }
        try { dc?.release() } catch (_: Exception) { }
        try { ex?.release() } catch (_: Exception) { }
        try { tr?.stop() } catch (_: Exception) { }
        try { tr?.release() } catch (_: Exception) { }
    }

    private fun dekode() {
        val ex = extractor ?: return
        val dc = codec ?: return
        var tr = track ?: return
        val info = MediaCodec.BufferInfo()
        var inputEos = false
        var outputEos = false
        var frameDitulis = 0L
        var pemroses: GemaDsp.Pemroses? = null
        var kunciDsp = ""; var kuatDsp = -1; var rateDsp = -1
        try {
            while (!dirilis && !outputEos) {
                if (dijeda) { Thread.sleep(30); continue }
                if (!inputEos) {
                    val i = dc.dequeueInputBuffer(10000L)
                    if (i >= 0) {
                        val buf = dc.getInputBuffer(i)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            dc.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            dc.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = dc.dequeueOutputBuffer(info, 10000L)
                if (o >= 0) {
                    if (info.size > 0) {
                        val out = dc.getOutputBuffer(o)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val total = sb.remaining()
                            val ch = if (kanal < 1) 1 else kanal
                            val frames = total / ch
                            val tmp = ShortArray(total)
                            sb.get(tmp)
                            val lk = if (stereoPenuh) 2 else 1
                            val mono = ShortArray(frames * lk)
                            if (stereoPenuh) {
                                for (f in 0 until frames) {
                                    val kiri = tmp[f * ch]
                                    val kanan = if (ch >= 2) tmp[f * ch + 1] else kiri
                                    mono[f * 2] = kiri
                                    mono[f * 2 + 1] = kanan
                                }
                            } else {
                                for (f in 0 until frames) {
                                    var jumlah = 0
                                    for (c in 0 until ch) jumlah += tmp[f * ch + c].toInt()
                                    mono[f] = (jumlah / ch).toShort()
                                }
                            }
                            val totalPendek = frames * lk
                            // FIX311: gema nyata pada data suara sebelum ditulis ke AudioTrack.
                            val gk = gemaKunci; val gs = gemaKekuatan
                            if (gk != "normal" && gs > 0) {
                                if (pemroses == null || kunciDsp != gk || kuatDsp != gs || rateDsp != rate) {
                                    pemroses = try { GemaDsp.Pemroses(gk, gs, rate, lk) } catch (_: Throwable) { null }
                                    kunciDsp = gk; kuatDsp = gs; rateDsp = rate
                                }
                                try { pemroses?.proses(mono, 0, totalPendek) } catch (_: Throwable) { pemroses = null }
                            } else pemroses = null
                            var ofs = 0
                            while (ofs < totalPendek && !dirilis) {
                                if (dijeda) { Thread.sleep(30); continue }
                                val w = tr.write(mono, ofs, totalPendek - ofs)
                                if (w < 0) throw IllegalStateException("AudioTrack.write=" + w)
                                ofs += w
                            }
                            frameDitulis += frames.toLong()
                            frameKini = frameDitulis
                        }
                    }
                    dc.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputEos = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dc.outputFormat
                    kanal = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    val r = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (r != rate) {
                        rate = r
                        val lama = tr
                        tr = buatTrack(r)
                        track = tr
                        try { lama.stop() } catch (_: Exception) { }
                        try { lama.release() } catch (_: Exception) { }
                        terapkanKecepatan()
                        if (!dijeda) tr.play()
                    }
                }
            }
            // FIX311: ekor gema diumpankan sebagai senyap agar tidak terpotong di akhir audio.
            val pm = pemroses
            if (!dirilis && outputEos && pm != null) {
                try {
                    val lk2 = if (stereoPenuh) 2 else 1
                    val ekorEfektif = minOf(pm.ekorFrame.toLong(), tr.sampleRate.toLong() * ekorMaksMs / 1000L).toInt()
                    var sisa = ekorEfektif
                    // FIX315: ekor gema memudar halus (kurva cosinus) sampai nol agar tidak terdengar dihentikan paksa.
                    val totalEkor = ekorEfektif
                    val frPudar = minOf((totalEkor * 0.8f).toInt(), tr.sampleRate * 1200 / 1000)
                    val mulaiPudar = totalEkor - frPudar
                    val blok = ShortArray(4096 * lk2)
                    while (sisa > 0 && !dirilis) {
                        if (dijeda) { Thread.sleep(30); continue }
                        val f = minOf(sisa, 4096)
                        java.util.Arrays.fill(blok, 0, f * lk2, 0.toShort())
                        pm.proses(blok, 0, f * lk2)
                        if (frPudar > 0) {
                            val selesaiFr = totalEkor - sisa
                            if (selesaiFr + f > mulaiPudar) for (j in 0 until f) {
                                val ps = selesaiFr + j
                                if (ps >= mulaiPudar) {
                                    val g = 0.5f * (1f + Math.cos(Math.PI * (ps - mulaiPudar) / frPudar.toDouble()).toFloat())
                                    for (c in 0 until lk2) blok[j * lk2 + c] = (blok[j * lk2 + c] * g).toInt().toShort()
                                }
                            }
                        }
                        var o2 = 0
                        while (o2 < f * lk2 && !dirilis) {
                            if (dijeda) { Thread.sleep(30); continue }
                            val w = tr.write(blok, o2, f * lk2 - o2)
                            if (w < 0) break
                            o2 += w
                        }
                        frameDitulis += f.toLong(); sisa -= f
                    }
                } catch (_: Throwable) { }
            }
            if (!dirilis && outputEos) {
                try { tr.stop() } catch (_: Exception) { }
                // FIX325: tunggu sisa audio benar-benar habis, tetapi dibatasi oleh perkiraan sisa durasi. Pada sebagian perangkat
                // playbackHeadPosition tidak mencapai jumlah frame setelah stop(), sehingga dulu menunggu sampai 10 detik
                // sebelum ayat berikutnya dimulai.
                val h0 = try { tr.playbackHeadPosition.toLong() and 0xFFFFFFFFL } catch (_: Exception) { 0L }
                val sisaFrame = (frameDitulis - h0).coerceAtLeast(0L)
                val lajuEfektif = (tr.sampleRate * (if (kecepatan > 0.1f) kecepatan else 1f)).coerceAtLeast(8000f)
                val batasMs = (sisaFrame * 1000f / lajuEfektif).toLong() + 250L
                val mulaiTunggu = System.currentTimeMillis()
                while (!dirilis && (tr.playbackHeadPosition.toLong() and 0xFFFFFFFFL) < frameDitulis && System.currentTimeMillis() - mulaiTunggu < batasMs) {
                    Thread.sleep(10)
                }
                selesai = true
                kirim { onCompletion?.invoke(this) }
            }
        } catch (e: Exception) {
            if (!dirilis) kirimError()
        } finally {
            synchronized(kunci) { bersihkan() }
        }
    }
}
