import sys,os
B=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","app/src/main/java/com/novan/bateraibicara/")
r=lambda n:open(B+n).read()
def cek(n,k): print(("LULUS " if k else "GAGAL ")+n)
cek("satu ayat tts",'terjemahTtsPaksa && p.ayat != null' in r('PemutarQuranService.kt'))
cek("sambung dibuang",'val sambung' in r('TerjemahTts.kt') and 'ttsAktif' in r('TerjemahTts.kt'))
cek("sakelar suara",'TERJEMAH_TTS' in r('PerintahSuaraActivity.kt') and 'TerjemahTts.setAktif(applicationContext, nilai)' in r('PerintahSuaraActivity.kt'))
