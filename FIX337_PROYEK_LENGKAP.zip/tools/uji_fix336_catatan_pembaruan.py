import sys,os
R=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
B=R+"/app/src/main/java/com/novan/bateraibicara/"
u=open(B+"UpdateManager.kt").read(); m=open(B+"MainActivity.kt").read()
def cek(n,k): print(("LULUS " if k else "GAGAL ")+n)
cek("catatan bersih",'bersihkanCatatan' in u and 'JSONArray' in u)
cek("catatan disimpan saat unduh",'update_target_catatan' in u and 'yang_baru_catatan' in u)
cek("dialog yang baru",'tampilkanYangBaru()' in m and 'yang_baru_isi' in u)
cek("catatan kosong",'update_catatan_kosong' in m)
