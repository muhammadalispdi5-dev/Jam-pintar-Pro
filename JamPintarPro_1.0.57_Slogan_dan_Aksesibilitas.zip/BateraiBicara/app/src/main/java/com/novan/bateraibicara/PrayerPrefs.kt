package com.novan.bateraibicara

import android.content.Context

/** Preferensi khusus jadwal sholat; seluruh sakelar fitur dimulai nonaktif. */
class PrayerPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
    var enabled: Boolean get() = sp.getBoolean("enabled", false); set(v) = sp.edit().putBoolean("enabled", v).apply()
    var locationSet: Boolean get() = sp.getBoolean("location_set", false); set(v) = sp.edit().putBoolean("location_set", v).apply()
    var lat: Double get() = java.lang.Double.longBitsToDouble(sp.getLong("lat", java.lang.Double.doubleToRawLongBits(0.0))); set(v) = sp.edit().putLong("lat", java.lang.Double.doubleToRawLongBits(v)).apply()
    var lon: Double get() = java.lang.Double.longBitsToDouble(sp.getLong("lon", java.lang.Double.doubleToRawLongBits(0.0))); set(v) = sp.edit().putLong("lon", java.lang.Double.doubleToRawLongBits(v)).apply()
    var place: String get() = sp.getString("place", "Lokasi belum diatur") ?: "Lokasi belum diatur"; set(v) = sp.edit().putString("place", v).apply()
    var method: Int get() = sp.getInt("method", 0).coerceIn(0, PrayerCalc.methodNames.lastIndex); set(v) = sp.edit().putInt("method", v).apply()
    var asrFactor: Int get() = sp.getInt("asr_factor", 1).coerceIn(1, 2); set(v) = sp.edit().putInt("asr_factor", v).apply()
    var use24: Boolean get() = sp.getBoolean("use24", true); set(v) = sp.edit().putBoolean("use24", v).apply()
    var notifyOnly: Boolean get() = sp.getBoolean("notify_only", false); set(v) = sp.edit().putBoolean("notify_only", v).apply()
    var dndEnabled: Boolean get() = sp.getBoolean("prayer_dnd_enabled", false); set(v) = sp.edit().putBoolean("prayer_dnd_enabled", v).apply()
    var dndDuration: Int get() = sp.getInt("prayer_dnd_duration", 10).let { if (it in listOf(5, 10, 15, 30)) it else 10 }; set(v) = sp.edit().putInt("prayer_dnd_duration", if (v in listOf(5, 10, 15, 30)) v else 10).apply()
    fun dndPrayer(name: String): Boolean = sp.getBoolean("prayer_dnd_$name", true)
    fun setDndPrayer(name: String, value: Boolean) { sp.edit().putBoolean("prayer_dnd_$name", value).apply() }
    var stopAzanFaceDown: Boolean get() = sp.getBoolean("stop_azan_face_down", true); set(v) = sp.edit().putBoolean("stop_azan_face_down", v).apply()
    var autoOnline: Boolean get() = sp.getBoolean("auto_online", false); set(v) = sp.edit().putBoolean("auto_online", v).apply()
    var fridayDhuhrOff: Boolean get() = sp.getBoolean("friday_dhuhr_off", false); set(v) = sp.edit().putBoolean("friday_dhuhr_off", v).apply()
    var voiceQibla: Boolean get() = sp.getBoolean("voice_qibla", false); set(v) = sp.edit().putBoolean("voice_qibla", v).apply()
    var qiblaHaptic: Boolean get() = sp.getBoolean("qibla_haptic", false); set(v) = sp.edit().putBoolean("qibla_haptic", v).apply()
    // Waktu standar hasil perhitungan tetap dipakai sampai pengguna mengaktifkan waktu khusus.
    var dhuhaCustomEnabled: Boolean get() = sp.getBoolean("dhuha_custom_enabled", false); set(v) = sp.edit().putBoolean("dhuha_custom_enabled", v).apply()
    var dhuhaCustomMinute: Int get() = sp.getInt("dhuha_custom_minute", 8 * 60).coerceIn(0, 1439); set(v) = sp.edit().putInt("dhuha_custom_minute", v.coerceIn(0, 1439)).apply()
    var tahajudCustomEnabled: Boolean get() = sp.getBoolean("tahajud_custom_enabled", false); set(v) = sp.edit().putBoolean("tahajud_custom_enabled", v).apply()
    var tahajudCustomMinute: Int get() = sp.getInt("tahajud_custom_minute", 3 * 60).coerceIn(0, 1439); set(v) = sp.edit().putInt("tahajud_custom_minute", v.coerceIn(0, 1439)).apply()
    // Preferensi lama tetap dibaca agar data pengguna versi sebelumnya tidak terhapus.
    var dhuhaAfterSunrise: Int get() = sp.getInt("dhuha_after_sunrise", 20).coerceIn(5, 120); set(v) = sp.edit().putInt("dhuha_after_sunrise", v.coerceIn(5, 120)).apply()
    var tahajudOffset: Int get() = sp.getInt("tahajud_offset", 0).coerceIn(-180, 180); set(v) = sp.edit().putInt("tahajud_offset", v.coerceIn(-180, 180)).apply()
    /** Indeks mengikuti pola pilihan keluaran suara fitur Baterai, Jam, dan Nama Pemanggil:
     * 0 Media, 1 Alarm, 2 Notifikasi, 3 Dering, 4 Aksesibilitas, 5 Panggilan suara, 6 Sistem.
     * Nilai lama 0/1/2 dimigrasikan agar pilihan pengguna sebelumnya tetap setara.
     */
    var volumeMode: Int
        get() {
            if (sp.contains("volume_mode_v2")) return sp.getInt("volume_mode_v2", 1).coerceIn(0, 6)
            if (!sp.contains("volume_mode")) return 1 // default lama: Alarm
            val lama = sp.getInt("volume_mode", 0)
            val baru = when (lama) { 0 -> 1; 1 -> 2; 2 -> 0; else -> 1 }
            sp.edit().putInt("volume_mode_v2", baru).apply()
            return baru
        }
        set(v) { sp.edit().putInt("volume_mode_v2", v.coerceIn(0, 6)).apply() }
    var globalSound: String get() = sp.getString("sound_all", "") ?: ""; set(v) = sp.edit().putString("sound_all", v).apply()
    fun reminder(name: String): Boolean = sp.getBoolean("reminder_$name", false)
    fun setReminder(name: String, value: Boolean) { sp.edit().putBoolean("reminder_$name", value).apply() }
    // Pengingat pendahuluan untuk lima salat wajib, terpisah dari pengingat/azan pada waktunya.
    fun advanceReminder(name: String): Boolean = sp.getBoolean("advance_reminder_$name", false)
    fun setAdvanceReminder(name: String, value: Boolean) { sp.edit().putBoolean("advance_reminder_$name", value).apply() }
    fun advanceMinutes(name: String): Int = sp.getInt("advance_minutes_$name", 5).let { if (it in listOf(5, 10, 15, 30)) it else 5 }
    fun setAdvanceMinutes(name: String, value: Int) { sp.edit().putInt("advance_minutes_$name", if (value in listOf(5, 10, 15, 30)) value else 5).apply() }
    // Mode suara pengingat sebelum salat: 0 = suara bicara standar Android,
    // 1 = audio pengingat bawaan aplikasi, 2 = berkas audio pilihan pengguna.
    // Preferensi lama yang sudah menyimpan URI otomatis tetap dianggap pilihan pengguna.
    fun advanceSound(name: String): String = sp.getString("advance_sound_$name", "") ?: ""
    fun setAdvanceSound(name: String, value: String) { sp.edit().putString("advance_sound_$name", value).apply() }
    fun advanceSoundMode(name: String): Int {
        if (!sp.contains("advance_sound_mode_$name")) return if (advanceSound(name).isNotBlank()) 2 else 0
        return sp.getInt("advance_sound_mode_$name", 0).coerceIn(0, 2)
    }
    fun setAdvanceSoundMode(name: String, value: Int) { sp.edit().putInt("advance_sound_mode_$name", value.coerceIn(0, 2)).apply() }
    fun adjustment(name: String): Int = sp.getInt("adjust_$name", 0).coerceIn(-30, 30)
    fun setAdjustment(name: String, value: Int) { sp.edit().putInt("adjust_$name", value.coerceIn(-30, 30)).apply() }
    fun sound(name: String): String = sp.getString("sound_$name", "") ?: ""
    fun setSound(name: String, value: String) { sp.edit().putString("sound_$name", value).apply() }
    // Pilihan sumber suara khusus Imsak dan matahari terbit:
    // 0 = azan bawaan/berkas umum, 1 = audio pengingat yang disematkan, 2 = berkas mandiri pengguna.
    // Pada instalasi lama, URI yang sudah dipilih tetap dianggap sebagai suara mandiri.
    fun reminderSoundMode(name: String): Int {
        if (!sp.contains("reminder_sound_mode_$name")) return if (sound(name).isNotBlank()) 2 else 0
        return sp.getInt("reminder_sound_mode_$name", 0).coerceIn(0, 2)
    }
    fun setReminderSoundMode(name: String, value: Int) {
        sp.edit().putInt("reminder_sound_mode_$name", value.coerceIn(0, 2)).apply()
    }
    fun adjustments() = intArrayOf(adjustment("imsak"), adjustment("subuh"), adjustment("terbit"), 0, adjustment("dzuhur"), adjustment("ashar"), adjustment("maghrib"), adjustment("isya"))
}
