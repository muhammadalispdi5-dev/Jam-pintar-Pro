package com.novan.bateraibicara

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale

/** Sinkronisasi jadwal dari AlAdhan; cache lokal dipakai untuk alarm berikutnya dan fallback offline. */
object PrayerOnlineTimes {
    private const val PREF = "jadwal_sholat_online"

    fun sync(context: Context, finished: (Boolean, String) -> Unit = { _, _ -> }) {
        val app = context.applicationContext
        val pp = PrayerPrefs(app)
        if (!pp.locationSet) { finished(false, "Atur lokasi terlebih dahulu."); return }
        val prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val signature = ("" + (pp.lat) + "," + (pp.lon) + "," + (pp.method) + "," + (pp.asrFactor))
        val lastSync = prefs.getLong("last_sync", 0L)
        if (prefs.getString("signature", "") == signature && lastSync > 0L && System.currentTimeMillis() - lastSync < 6 * 60 * 60 * 1000L) {
            finished(true, ("Jadwal online masih baru. " + (lastSyncLabel(app))))
            return
        }
        Thread {
            var ok = false
            var message = "Internet belum tersedia; jadwal offline tetap digunakan."
            try {
                val today = LocalDate.now()
                val dates = listOf(today, today.plusMonths(1).withDayOfMonth(1)).distinctBy { it.year to it.monthValue }
                for (monthDate in dates) {
                    val methodId = when (pp.method) {
                        1 -> 3 // MWL
                        2 -> 2 // ISNA
                        3 -> 5 // Egypt
                        4 -> 1 // Karachi
                        5 -> 11 // Singapore
                        6 -> 4 // Umm Al-Qura
                        else -> 20 // Kemenag Indonesia
                    }
                    // AlAdhan memakai school=0 untuk Asar bayangan 1x dan school=1 untuk Hanafi 2x.
                    val schoolId = if (pp.asrFactor == 2) 1 else 0
                    val url = URL(("https://api.aladhan.com/v1/calendar/" + (monthDate.year) + "/" + (monthDate.monthValue) + "?latitude=" + (pp.lat) + "&longitude=" + (pp.lon) + "&method=" + (methodId) + "&school=" + (schoolId)))
                    val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 9000; readTimeout = 12000; requestMethod = "GET" }
                    try {
                        if (conn.responseCode !in 200..299) throw IllegalStateException("Server jadwal tidak dapat dijangkau.")
                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val data = JSONObject(body).optJSONArray("data") ?: throw IllegalStateException("Format jadwal online tidak dikenali.")
                        val sp = app.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                        for (i in 0 until data.length()) {
                            val item = data.getJSONObject(i)
                            val dateText = item.getJSONObject("date").getJSONObject("gregorian").getString("date")
                            val date = LocalDate.parse(dateText, java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.US))
                            val timings = item.getJSONObject("timings")
                            fun minute(name: String): Int? = timings.optString(name).takeIf { it.isNotBlank() }?.let { raw ->
                                val match = Regex("(\\d{1,2}):(\\d{2})").find(raw) ?: return@let null
                                match.groupValues[1].toInt() * 60 + match.groupValues[2].toInt()
                            }
                            val fajr = minute("Fajr") ?: continue
                            val sunrise = minute("Sunrise") ?: continue
                            val values = JSONObject()
                            values.put("imsak", minute("Imsak") ?: (fajr - 10 + 1440) % 1440)
                            values.put("subuh", fajr); values.put("terbit", sunrise)
                            values.put("dhuha", (sunrise + 20) % 1440)
                            values.put("dzuhur", minute("Dhuhr") ?: continue)
                            values.put("ashar", minute("Asr") ?: continue)
                            values.put("maghrib", minute("Maghrib") ?: continue)
                            values.put("isya", minute("Isha") ?: continue)
                            sp.putString(("times_" + (date)), values.toString())
                        }
                        sp.putString("signature", ("" + (pp.lat) + "," + (pp.lon) + "," + (pp.method) + "," + (pp.asrFactor)))
                        sp.putLong("last_sync", System.currentTimeMillis())
                        sp.apply()
                    } finally { conn.disconnect() }
                }
                ok = true
                message = "Jadwal diperbarui melalui internet. Koreksi menit yang Anda atur tetap diterapkan."
            } catch (e: Exception) {
                message = "Pembaruan online gagal. Jadwal perhitungan offline tetap digunakan."
            }
            finished(ok, message)
        }.start()
    }

    fun minutes(context: Context, date: LocalDate, key: String, applyAdjustment: Boolean = true): Int? {
        val sp = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val pp = PrayerPrefs(context)
        val signature = ("" + (pp.lat) + "," + (pp.lon) + "," + (pp.method) + "," + (pp.asrFactor))
        if (sp.getString("signature", "") != signature) return null
        val raw = sp.getString(("times_" + (date)), null) ?: return null
        val value = try { JSONObject(raw).optInt(key, -1) } catch (_: Exception) { -1 }
        if (value < 0) return null
        val adjustmentKey = when (key) {
            "imsak" -> "imsak"; "subuh" -> "subuh"; "terbit" -> "terbit"; "dhuha" -> "dhuha"
            "dzuhur" -> "dzuhur"; "ashar" -> "ashar"; "maghrib" -> "maghrib"; "isya" -> "isya"
            else -> return null
        }
        return ((value + if (applyAdjustment) pp.adjustment(adjustmentKey) else 0) % 1440 + 1440) % 1440
    }

    fun lastSyncLabel(context: Context): String {
        val t = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong("last_sync", 0L)
        if (t == 0L) return BahasaAplikasi.teks(context, "Belum pernah diperbarui melalui internet")

        // Ini adalah informasi antarmuka, bukan ucapan jadwal. Karena itu, nama bulan
        // dan labelnya mengikuti bahasa tampilan, terpisah dari bahasa suara/TTS.
        val localeTampilan = if (BahasaAplikasi.tampilan(context) == 1) Locale.ENGLISH else Locale("id", "ID")
        val tanggal = java.text.SimpleDateFormat("d MMM yyyy, HH:mm", localeTampilan).format(java.util.Date(t))
        val awalan = BahasaAplikasi.teks(context, "Pembaruan terakhir:")
        return "$awalan $tanggal"
    }
}
