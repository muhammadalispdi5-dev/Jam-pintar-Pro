package com.novan.bateraibicara

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Calendar

/**
 * FIX84: perintah suara Beritahu Saya.
 * Dibuka dengan ketuk tahan pada ikon Beritahu Saya (pintasan aplikasi) atau ketuk tahan pada saklar
 * pemicu Beritahu Saya di layar utama aplikasi. Layar pengenalan suara sistem dibuka (tanpa izin
 * mikrofon aplikasi), lalu perintah dijalankan: waktu, tanggal, atau memutar Al-Qur'an.
 * Bahasa pengenalan, teks, dan pesan mengikuti bahasa tampilan utama yang aktif.
 */
class PerintahSuaraActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutup() }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)
        if (!prefs.beritahuSayaOn) {
            Toast.makeText(this, getString(R.string.beritahu_saya_nonaktif_petunjuk), Toast.LENGTH_LONG).show()
            selesai = true
            finish()
            return
        }
        if (savedInstanceState == null) mulai()
    }

    /** Bila "Suara TalkBack saat mikrofon dipakai" dimatikan (Khatam), senyapkan TalkBack, beri getar, lalu buka mikrofon. */
    private fun mulai() {
        val senyap = getSharedPreferences("khatam_quran", MODE_PRIVATE).getBoolean("senyap_talkback_pergantian_audio", false)
        if (senyap) {
            try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
            getar(150L)
            handler.postDelayed({ if (!isFinishing) bukaPengenalan(false) }, 800L)
        } else {
            bukaPengenalan(true)
        }
    }

    private fun bukaPengenalan(denganPetunjuk: Boolean) {
        val inggris = BahasaAplikasi.tampilan(this) == 1
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (inggris) "en-US" else "id-ID")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, if (inggris) "en-US" else "id-ID")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                if (denganPetunjuk) putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.perintah_suara_petunjuk))
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, KODE_PENGENALAN)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            tutup()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != KODE_PENGENALAN) return
        val kandidat = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty() else emptyList<String>()
        if (kandidat.isEmpty()) { tutup(); return }
        jalankan(kandidat)
    }

    private fun jalankan(kandidat: List<String>) {
        when (PerintahSuara.tafsir(kandidat)) {
            PerintahSuara.Jenis.WAKTU -> bacakan(waktu = true, tanggal = false)
            PerintahSuara.Jenis.TANGGAL -> bacakan(waktu = false, tanggal = true)
            PerintahSuara.Jenis.WAKTU_TANGGAL -> bacakan(waktu = true, tanggal = true)
            PerintahSuara.Jenis.TANGGAL_MASEHI -> bacakanKhusus { p, c -> KalenderTanggal.masehi(c, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_HIJRIAH -> bacakanKhusus { p, c ->
                KalenderTanggal.hijriah(c,
                    if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null,
                    p.bahasaAktif)
            }
            PerintahSuara.Jenis.LIBUR -> bacakanKhusus { p, _ ->
                val nasional = HariLibur.ringkasan(applicationContext, p, "national").drop(1)
                val cuti = HariLibur.ringkasan(applicationContext, p, "joint").drop(1)
                (nasional + cuti).joinToString(" ").ifBlank { pesanKosong(p, "holiday") }
            }
            PerintahSuara.Jenis.SHOLAT_BERIKUTNYA -> bacakanKhusus { p, c ->
                InfoSholat.segmen(p, c, abaikanSakelar = true).firstOrNull() ?: pesanKosong(p, "prayer")
            }
            PerintahSuara.Jenis.QURAN -> bukaKhatam(kandidat)
            PerintahSuara.Jenis.TIDAK_DIKENAL -> {
                val didengar = kandidat.firstOrNull().orEmpty()
                getar(300L)
                Toast.makeText(
                    this,
                    getString(R.string.perintah_suara_tidak_dikenal) + (if (didengar.isNotBlank()) " (\"" + didengar + "\")" else ""),
                    Toast.LENGTH_LONG
                ).show()
                tutup()
            }
        }
    }

    private fun pesanKosong(p: Prefs, jenis: String): String = when (p.bahasaAktif) {
        1 -> if (jenis == "holiday") "No holiday information is available." else "Prayer time information is unavailable. Check your prayer location and schedule."
        2 -> if (jenis == "holiday") "لا تتوفر معلومات عن العطلات." else "معلومات أوقات الصلاة غير متاحة. تحقق من الموقع والجدول."
        3 -> if (jenis == "holiday") "Informasi preinan dereng cumawis." else "Informasi wekdal salat dereng cumawis. Priksa lokasi lan jadwal salat."
        4 -> if (jenis == "holiday") "Inpormasi libur teu sayogi." else "Inpormasi waktos salat teu sayogi. Pariksa lokasi sareng jadwal salat."
        else -> if (jenis == "holiday") "Informasi hari libur belum tersedia." else "Informasi waktu salat belum tersedia. Periksa lokasi dan jadwal salat."
    }

    /** Satu perintah spesifik menghasilkan satu jawaban saja; tidak menambahkan rangkaian tanggal/libur/sholat lain. */
    private fun bacakanKhusus(penyusun: (Prefs, Calendar) -> String) {
        try {
            val prefs = Prefs(applicationContext)
            val teks = penyusun(prefs, Calendar.getInstance()).trim()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            val suara = Pembicara(applicationContext, prefs.suara("tgl"))
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutup() }
        } catch (_: Exception) { tutup() }
    }

    /** Waktu dibacakan suara jam; tanggal umum mengikuti pengaturan rangkaian pengguna. */
    private fun bacakan(waktu: Boolean, tanggal: Boolean) {
        try {
            val prefs = Prefs(applicationContext)
            val c = Calendar.getInstance()
            val teksWaktu = if (waktu) JamWaktu.ucapan(prefs, c) else ""
            val segmenTanggal = if (tanggal) JamWaktu.segmenTanggal(prefs, c) else emptyList()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            fun bacaTanggal() {
                if (segmenTanggal.isEmpty()) { tutup(); return }
                val pt = Pembicara(applicationContext, prefs.suara("tgl"))
                pembicaraTanggal = pt
                pt.ucapkanRangkaian(segmenTanggal, 300L) { tutup() }
            }
            if (teksWaktu.isBlank()) {
                bacaTanggal()
            } else {
                val p = Pembicara(applicationContext, prefs.suara("jam"))
                pembicara = p
                p.ucapkan(teksWaktu, true) { bacaTanggal() }
            }
        } catch (_: Exception) {
            tutup()
        }
    }

    /** Perintah putar Al-Qur'an diteruskan ke Khatam; Khatam menafsirkan surah/ayat/juz dan memutar audionya. */
    private fun bukaKhatam(kandidat: List<String>) {
        try {
            // FIX87: dari layar depan/pintasan/widget, Khatam hanya memutar audio lalu mengembalikan pengguna ke layar depan.
            // Bila perintah suara dibuka dari dalam aplikasi sendiri, pengguna tetap berada di Khatam seperti sebelumnya.
            val dariAplikasi = getIntent()?.getBooleanExtra(EXTRA_DARI_APLIKASI, false) ?: false
            val intent = Intent(this, KhatamActivity::class.java).apply {
                putStringArrayListExtra(KhatamActivity.EXTRA_PERINTAH_SUARA, ArrayList(kandidat))
                putExtra(KhatamActivity.EXTRA_KEMBALI_KE_LAYAR_DEPAN, !dariAplikasi)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        hentikanSuara()
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hentikanSuara()
        super.onDestroy()
    }

    companion object {
        private const val KODE_PENGENALAN = 6911
        /** FIX87: diisi true oleh pemanggil di dalam aplikasi agar pengguna tidak dikirim ke layar depan. */
        const val EXTRA_DARI_APLIKASI = "perintah_suara_dari_aplikasi"
    }
}

/** Penafsir perintah suara Beritahu Saya (Indonesia dan Inggris); tidak bergantung pada tampilan. */
object PerintahSuara {
    enum class Jenis { WAKTU, TANGGAL, WAKTU_TANGGAL, TANGGAL_MASEHI, TANGGAL_HIJRIAH, LIBUR, SHOLAT_BERIKUTNYA, QURAN, TIDAK_DIKENAL }

    private val kataWaktu = setOf("waktu", "jam", "pukul", "time", "clock", "jamnya")
    private val kataTanggal = setOf("tanggal", "hari", "tgl", "date", "today", "day", "kalender", "calendar", "hijriah", "pasaran")
    private val kataSemua = setOf("semua", "lengkap", "semuanya", "everything", "all", "both")
    private val kataKerjaInfo = setOf(
        "informasikan", "informasi", "info", "beritahu", "beritahukan", "sebutkan", "katakan", "bacakan", "baca",
        "tolong", "tell", "say", "give", "what", "whats", "read", "announce", "saya", "me"
    )
    private val kataQuran = setOf("surah", "surat", "sura", "ayat", "ayah", "aya", "verse", "juz", "jus", "juzz", "murattal", "mushaf", "alquran", "quran", "quranul")
    // FIX88: perintah memilih qari ("pilih qari Alafasy", "choose reciter Sudais") juga diteruskan ke Khatam.
    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori") // sering salah dengar; hanya bila ada kata kerja pilih
    private val kataKerjaQari = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set", "choose", "select", "switch", "change", "use")

    fun tafsir(kandidat: List<String>): Jenis {
        for (ucapan in kandidat) {
            val j = tafsirSatu(ucapan)
            if (j != Jenis.TIDAK_DIKENAL) return j
        }
        return Jenis.TIDAK_DIKENAL
    }

    private fun tafsirSatu(ucapan: String): Jenis {
        val token = ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() }
        if (token.isEmpty()) return Jenis.TIDAK_DIKENAL
        val gabung = token.joinToString("")
        // "Qur'an" menjadi "qur an" setelah tanda baca dibuang; gabungan menangkapnya.
        val quran = token.any { it in kataQuran } || gabung.contains("quran")
        if (quran) return Jenis.QURAN
        val qari = token.any { it in kataQariPasti } || (token.any { it in kataQariMirip } && token.any { it in kataKerjaQari })
        if (qari) return Jenis.QURAN
        // Sasaran spesifik diprioritaskan agar kata "hari" dalam "hari libur" tidak dianggap tanggal.
        val frasa = token.joinToString(" ")
        if (token.any { it in setOf("masehi", "gregorian") } || frasa.contains("tanggal masehi") || frasa.contains("gregorian date")) return Jenis.TANGGAL_MASEHI
        if (token.any { it in setOf("libur", "liburan", "holiday", "holidays", "cuti") } || frasa.contains("day off")) return Jenis.LIBUR
        if (token.any { it in setOf("hijriah", "hijri", "islamic") } || frasa.contains("islamic date")) return Jenis.TANGGAL_HIJRIAH
        if (token.any { it in setOf("salat", "sholat", "solat", "prayer", "prayers") } || frasa.contains("prayer time")) return Jenis.SHOLAT_BERIKUTNYA
        val waktu = token.any { it in kataWaktu }
        val tanggal = token.any { it in kataTanggal }
        val semua = token.any { it in kataSemua }
        return when {
            waktu && tanggal -> Jenis.WAKTU_TANGGAL
            waktu && semua -> Jenis.WAKTU_TANGGAL
            tanggal && semua -> Jenis.WAKTU_TANGGAL
            waktu -> Jenis.WAKTU
            tanggal -> Jenis.TANGGAL
            semua -> Jenis.WAKTU_TANGGAL
            // Perintah umum tanpa sasaran ("beritahu saya", "tell me"): sama dengan mengetuk pemicu biasa.
            token.any { it in kataKerjaInfo } && token.size <= 3 -> Jenis.WAKTU_TANGGAL
            else -> Jenis.TIDAK_DIKENAL
        }
    }
}
