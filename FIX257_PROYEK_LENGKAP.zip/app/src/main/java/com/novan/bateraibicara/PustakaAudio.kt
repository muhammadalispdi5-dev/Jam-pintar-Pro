package com.novan.bateraibicara

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import java.io.File

/**
 * FIX257: pustaka audio buatan pengguna, misalnya folder "Murattal Per ayat Dan Terjemah Bahasa Indonesia, Ayman Suwaid" di
 * Jam Pintar Pro. Satu folder per surah berisi berkas ayat dan berkas terjemahan yang TERPISAH. Nama berkas bebas pola:
 * pembeda terjemahan adalah kata terjemah/translation/indonesia pada nama berkas atau subfolder, nomor ayat dibaca dari nama berkas.
 * Bagian murni logika (di atas penanda AKHIR_LOGIKA_MURNI) diuji dengan kotlinc.
 */
object PustakaAudio {
    class Entri(val nama: String, val folder: String, val uri: String)
    class Hasil(val ayat: Map<Int, String>, val terjemahAyat: Map<Int, String>, val terjemahSurah: String?)

    private val ekstensi = setOf("mp3", "m4a", "ogg", "wav", "aac", "opus", "flac", "wma", "amr")

    fun audio(nama: String): Boolean = nama.substringAfterLast('.', "").lowercase() in ekstensi

    private fun huruf(s: String) = s.lowercase().filter { it.isLetter() }

    /** Folder satu surah: awalan nomor ("002 - Al-Baqarah", "Surah 2", "2"), atau memuat nama surah. */
    fun cocokFolderSurah(nama: String, surah: Int, namaSurah: String): Boolean {
        val t = nama.trim()
        if (Regex("(?i)^(?:surah|surat|sura|s)?[\\s_.-]*0*" + surah + "(?!\\d)").containsMatchIn(t)) return true
        val m = huruf(namaSurah)
        return m.length >= 5 && huruf(t).contains(m)
    }

    /** Berkas terjemahan: nama berkas atau subfolder langsungnya menyebut terjemah/translation/Indonesia. */
    fun terjemah(nama: String, folder: String): Boolean {
        val s = (nama.substringBeforeLast('.') + " " + folder).lowercase()
        if (Regex("terjemah|tarjamah|tarjemah|translat|indonesia|bahasa|arti|\\bindo\\b").containsMatchIn(s)) return true
        return Regex("(^|[^a-z])(id|idn|ind|trans|terj)([^a-z]|$)").containsMatchIn(s)
    }

    /** Nomor ayat dari nama berkas bebas pola; null bila tidak terbaca. */
    fun nomorAyat(nama: String, surah: Int): Int? {
        var inti = nama.substringBeforeLast('.')
        inti = Regex("(?i)\\b\\d{2,3}\\s*kbps").replace(inti, " ")
        fun sah(x: String?): Int? = x?.toIntOrNull()?.takeIf { it in 1..286 }
        Regex("(?<!\\d)" + String.format("%03d", surah) + "(\\d{3})(?!\\d)").find(inti)?.let { m -> sah(m.groupValues[1])?.let { return it } }
        Regex("(?i)(?:ayat|ayah|aya|verse|ay|v)[ _.-]*0*(\\d{1,3})(?!\\d)").find(inti)?.let { m -> sah(m.groupValues[1])?.let { return it } }
        Regex("(?i)(?<![a-z0-9])a0*(\\d{1,3})(?!\\d)").find(inti)?.let { m -> sah(m.groupValues[1])?.let { return it } }
        val angka = Regex("\\d+").findAll(inti).map { it.value }.toList()
        if (angka.isEmpty()) return null
        val akhir = angka.last()
        return sah(if (akhir.length > 3) akhir.takeLast(3) else akhir)
    }

    /** Menyusun hasil dari isi satu folder surah; null bila tidak ada terjemahan sama sekali. */
    fun susun(entri: List<Entri>, surah: Int, total: Int): Hasil? {
        val ayat = HashMap<Int, Entri>()
        val terj = HashMap<Int, Entri>()
        var terjSurah: Entri? = null
        val terjBernomor = ArrayList<Pair<Int, Entri>>()
        for (e in entri) {
            if (!audio(e.nama)) continue
            val a = nomorAyat(e.nama, surah)?.takeIf { it <= total }
            if (terjemah(e.nama, e.folder)) {
                if (a != null) terjBernomor.add(a to e)
                else if (terjSurah == null || e.nama.length < terjSurah.nama.length) terjSurah = e
            } else if (a != null) {
                val lama = ayat[a]
                if (lama == null || e.nama.length < lama.nama.length) ayat[a] = e
            }
        }
        // Satu berkas terjemahan saja pada surah panjang (atau bernomor sama dengan nomor surah) berarti terjemahan satu surah penuh.
        if (terjBernomor.size == 1 && total > 1 && (terjBernomor[0].first == surah || total > 5)) {
            terjSurah = terjSurah ?: terjBernomor[0].second
            terjBernomor.clear()
        }
        for ((a, e) in terjBernomor) {
            val lama = terj[a]
            if (lama == null || e.nama.length < lama.nama.length) terj[a] = e
        }
        if (terj.isEmpty() && terjSurah == null) return null
        return Hasil(ayat.mapValues { it.value.uri }, terj.mapValues { it.value.uri }, terjSurah?.uri)
    }
    // AKHIR_LOGIKA_MURNI

    interface Simpul {
        val nama: String
        val folder: Boolean
        val uri: String
        fun anak(): List<Simpul>
    }

    class SimpulFile(private val f: File) : Simpul {
        override val nama: String get() = f.name
        override val folder: Boolean get() = f.isDirectory
        override val uri: String get() = Uri.fromFile(f).toString()
        override fun anak(): List<Simpul> = try { f.listFiles()?.filter { it.canRead() }?.map { SimpulFile(it) }.orEmpty() } catch (_: Exception) { emptyList() }
    }

    class SimpulSaf(private val ctx: Context, private val pohon: Uri, private val id: String, override val nama: String, override val folder: Boolean) : Simpul {
        override val uri: String get() = DocumentsContract.buildDocumentUriUsingTree(pohon, id).toString()
        override fun anak(): List<Simpul> {
            val hasil = ArrayList<Simpul>()
            try {
                val anakUri = DocumentsContract.buildChildDocumentsUriUsingTree(pohon, id)
                ctx.contentResolver.query(anakUri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val i = c.getString(0) ?: continue
                        hasil.add(SimpulSaf(ctx, pohon, i, c.getString(1).orEmpty(), c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR))
                    }
                }
            } catch (_: Exception) { }
            return hasil
        }
    }

    /** Menelusuri akar (kedalaman maksimal 6) mencari folder satu surah yang berisi berkas terjemahan terpisah. */
    fun pindai(akar: List<Simpul>, surah: Int, namaSurah: String, total: Int): Hasil? {
        var terbaik: Hasil? = null
        var skorTerbaik = -1
        val antre = java.util.ArrayDeque<Pair<Simpul, Int>>()
        for (a in akar) antre.add(a to 0)
        var jumlah = 0
        while (antre.isNotEmpty() && jumlah++ < 4000) {
            val (d, kedalaman) = antre.removeFirst()
            val isi = d.anak()
            if (kedalaman > 0 && cocokFolderSurah(d.nama, surah, namaSurah)) {
                val entri = ArrayList<Entri>()
                for (n in isi) {
                    if (!n.folder) entri.add(Entri(n.nama, "", n.uri))
                    else if (kedalaman < 7) for (g in n.anak()) if (!g.folder) entri.add(Entri(g.nama, n.nama, g.uri))
                }
                val h = susun(entri, surah, total)
                if (h != null) {
                    val skor = h.terjemahAyat.size * 2 + h.ayat.size + (if (h.terjemahSurah != null) 1 else 0)
                    if (skor > skorTerbaik) { terbaik = h; skorTerbaik = skor }
                }
                continue
            }
            if (kedalaman < 6) for (n in isi) if (n.folder) antre.add(n to (kedalaman + 1))
        }
        return terbaik
    }

    /** Titik masuk dari PemutarQuranService (jalankan di thread latar). */
    fun cari(context: Context, surah: Int, namaSurah: String, total: Int, treeUri: String?): Hasil? {
        val akar = ArrayList<Simpul>()
        fun tambah(f: File) { try { if (f.isDirectory && f.canRead()) akar.add(SimpulFile(f)) } catch (_: Exception) { } }
        val sdcard = Environment.getExternalStorageDirectory()
        tambah(File(sdcard, "Jam Pintar Pro"))
        tambah(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Jam Pintar Pro"))
        tambah(File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir, "Jam Pintar Pro"))
        try {
            sdcard.listFiles()?.filter { it.isDirectory && Regex("(?i)murattal|terjemah|translation|quran|ayman|suwaid|sowaid").containsMatchIn(it.name) }?.forEach { tambah(it) }
        } catch (_: Exception) { }
        pindai(akar, surah, namaSurah, total)?.let { return it }
        try {
            if (!treeUri.isNullOrBlank()) {
                val pohon = Uri.parse(treeUri)
                val idAkar = DocumentsContract.getTreeDocumentId(pohon)
                return pindai(listOf(SimpulSaf(context, pohon, idAkar, "", true)), surah, namaSurah, total)
            }
        } catch (_: Exception) { }
        return null
    }
}
