package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import kotlin.math.sqrt

/** Memantau goncangan ketika diaktifkan pengguna; tidak merekam audio di latar belakang. */
class GoncanganSuaraService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var sensor: Sensor? = null
    private var firstPeakAt = 0L
    private var lastTriggerAt = 0L
    private var gravityX = 0f
    private var gravityY = 0f
    private var gravityZ = 0f
    private var sensorTerdaftar = false
    private var menungguTurun = false
    private var gravityInitialized = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buatKanalNotifikasi()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, false).apply()
            hentikanLayanan()
            return START_NOT_STICKY
        }
        if (!getSharedPreferences("pengaturan", MODE_PRIVATE).getBoolean(KEY_AKTIF, false)) {
            hentikanLayanan()
            return START_NOT_STICKY
        }
        mulaiForeground()
        if (!sensorTerdaftar) {
            // Utamakan sensor wake-up agar peristiwa tetap membangunkan CPU saat layar mati.
            sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
                ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val tersedia = sensor
            if (tersedia == null) {
                getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, false).apply()
                hentikanLayanan()
                return START_NOT_STICKY
            }
            sensorTerdaftar = sensorManager.registerListener(this, tersedia, SensorManager.SENSOR_DELAY_GAME)
            // Sebagian perangkat tidak menyediakan akselerometer wake-up. Pada perangkat itu,
            // tahan CPU hanya selama fitur ini sengaja diaktifkan agar sensor tetap terbaca saat layar mati.
            if (sensorTerdaftar && Build.VERSION.SDK_INT >= 21 && !tersedia.isWakeUpSensor) {
                try {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:ShakeVoiceSensor").apply {
                        setReferenceCounted(false)
                        acquire()
                    }
                } catch (_: Exception) { }
            }
            if (!sensorTerdaftar) {
                getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, false).apply()
                hentikanLayanan()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun mulaiForeground() {
        val english = BahasaAplikasi.tampilan(this) == 1
        val buka = PendingIntent.getActivity(
            this, 9401, Intent(this, PengaturanGoncanganActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 9402, Intent(this, GoncanganSuaraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle(if (english) "Shake voice trigger is active" else "Pemicu suara dengan goncangan aktif")
            .setContentText(if (english) "Shake twice to open voice commands" else "Goyangkan HP dua kali untuk membuka perintah suara")
            .setContentIntent(buka)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, if (english) "Turn off" else "Nonaktifkan", stop)
        val notification = builder.build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER || event.values.size < 3) return
        if (!gravityInitialized) {
            gravityX = event.values[0]
            gravityY = event.values[1]
            gravityZ = event.values[2]
            gravityInitialized = true
            return
        }
        val alpha = 0.8f
        gravityX = alpha * gravityX + (1f - alpha) * event.values[0]
        gravityY = alpha * gravityY + (1f - alpha) * event.values[1]
        gravityZ = alpha * gravityZ + (1f - alpha) * event.values[2]
        val ax = event.values[0] - gravityX
        val ay = event.values[1] - gravityY
        val az = event.values[2] - gravityZ
        val percepatan = sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
        val sensitivitas = getSharedPreferences("pengaturan", MODE_PRIVATE)
            .getInt(KEY_SENSITIVITAS, 5).coerceIn(1, 10)
        // Sensitivitas 1: ambang tinggi (goncangan kuat); 10: ambang rendah (goncangan ringan).
        val ambang = 7.0f - (sensitivitas - 1) * (4.5f / 9f)
        if (percepatan < ambang * 0.45f) menungguTurun = false
        if (percepatan < ambang || menungguTurun) return
        menungguTurun = true
        val now = SystemClock.elapsedRealtime()
        if (now - lastTriggerAt < COOLDOWN_MS) return
        if (firstPeakAt == 0L || now - firstPeakAt > DOUBLE_SHAKE_WINDOW_MS) {
            firstPeakAt = now
            return
        }
        firstPeakAt = 0L
        lastTriggerAt = now
        bukaPerintahSuara()
    }

    private fun bukaPerintahSuara() {
        try {
            val i = Intent(this, PerintahSuaraActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(PerintahSuaraActivity.EXTRA_PEMICU_GONCANGAN, true)
            }
            startActivity(i)
        } catch (_: Exception) {
            // Bila Android/OEM menahan peluncuran Activity dari latar belakang, notifikasi tetap
            // menyediakan jalur manual yang jelas; tidak mencoba mengakali kebijakan sistem.
            val english = BahasaAplikasi.tampilan(this) == 1
            val launch = PendingIntent.getActivity(
                this, 9403, Intent(this, PerintahSuaraActivity::class.java)
                    .putExtra(PerintahSuaraActivity.EXTRA_PEMICU_GONCANGAN, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val manager = getSystemService(NotificationManager::class.java)
            val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
            val n = builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(if (english) "Voice command is ready" else "Perintah suara siap")
                .setContentText(if (english) "Tap to speak" else "Ketuk untuk mulai berbicara")
                .setContentIntent(launch).setAutoCancel(true).build()
            manager.notify(NOTIFICATION_ID + 1, n)
        }
    }

    private fun buatKanalNotifikasi() {
        if (Build.VERSION.SDK_INT < 26) return
        val english = BahasaAplikasi.tampilan(this) == 1
        val channel = NotificationChannel(
            CHANNEL_ID,
            if (english) "Shake voice trigger" else "Pemicu suara dengan goncangan",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = if (english) "Ongoing notification while shake activation is enabled" else "Notifikasi tetap selama aktivasi goncangan dinyalakan"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun hentikanLayanan() {
        if (sensorTerdaftar) {
            try { sensorManager.unregisterListener(this) } catch (_: Exception) { }
            sensorTerdaftar = false
        }
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (sensorTerdaftar) try { sensorManager.unregisterListener(this) } catch (_: Exception) { }
        sensorTerdaftar = false
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val KEY_AKTIF = "pemicu_goncangan_suara_aktif"
        const val KEY_SENSITIVITAS = "pemicu_goncangan_suara_sensitivitas"
        private const val ACTION_STOP = "com.novan.bateraibicara.action.STOP_SHAKE_VOICE"
        private const val CHANNEL_ID = "pemicu_goncangan_suara"
        private const val NOTIFICATION_ID = 9400
        private const val DOUBLE_SHAKE_WINDOW_MS = 1500L
        private const val COOLDOWN_MS = 7000L

        fun mulai(context: Context) {
            val i = Intent(context, GoncanganSuaraService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun hentikan(context: Context) {
            try { context.stopService(Intent(context, GoncanganSuaraService::class.java)) } catch (_: Exception) { }
        }
    }
}
