# FIX58 — Ahmad Saud bisa diputar, Muhammad Taha Al-Junayd selalu tampil di Qari anak

Versi tetap **1.0.69**. Basis: FIX57. Berkas diubah: `KhatamActivity.kt`, `AndroidManifest.xml`, `res/xml/network_security_config.xml` (baru).

## Penyebab yang ditemukan
1. FIX57 mengubah semua alamat server MP3Quran `http://` menjadi `https://` dan hanya mencoba satu alamat itu. Percobaan ulang untuk qari MP3Quran juga 0 bila tidak ada server cadangan. Server yang tidak melayani https (kemungkinan terjadi pada Ahmad Saud) langsung gagal tanpa percobaan lain, sedangkan Junaid Adam memakai server yang melayani https sehingga bisa diputar. Penyebab ini disimpulkan dari kode; API MP3Quran tidak dapat dijangkau dari lingkungan kerja, jadi belum diverifikasi langsung.
2. Muhammad Taha Al-Junayd hanya tampil bila katalog MP3Quran memuatnya dengan nama yang cocok. Bila tidak ada atau katalog gagal dimuat, daftar Qari anak tidak memuatnya.

## Perbaikan
- Urutan percobaan audio qari MP3Quran: https utama, lalu varian http server mp3quran.net yang sama, lalu server cadangan (https lalu http). Batas percobaan naik menjadi maksimum 6.
- `network_security_config.xml` mengizinkan http hanya untuk `mp3quran.net` dan subdomainnya; domain lain tetap wajib https. Didaftarkan di manifest.
- Muhammad Taha Al-Junayd selalu tampil di urutan pertama daftar Qari anak. Bila katalog MP3Quran memuatnya, entri katalog dipakai; bila tidak, dipakai sumber cadangan Internet Archive `https://archive.org/download/Muhammad-Taha-Al-Junaid/NNN.mp3`.
- Pengenalan nama diperluas: Taha dengan Junaid/Junayd/Junayd/Jineid atau Muhammad/Mohamed, nama Arab (termasuk huruf ya Persia), Ahmad/Ahmed (bin) Saud/Saoud/Suud.

## Batasan (belum diverifikasi)
- BELUM dikompilasi dan BELUM diuji di perangkat. Tanda kurung `{}` dan `[]` seimbang; selisih tanda kurung `()` sama seperti sebelum perubahan (berasal dari teks string).
- Sumber cadangan Taha hanya terkonfirmasi dari satu berkas contoh (`111.mp3`) pada halaman surahquran.com. Apakah ke-114 surah ada di arsip itu belum dapat diperiksa. Surah yang tidak ada akan gagal dengan pesan audio gagal.
- Penyebab Ahmad Saud di atas adalah dugaan terkuat dari kode. Bila setelah perbaikan ini masih gagal, status pemutaran akan menampilkan pesan gagal; kirim nama persis yang tampil dan pesannya agar bisa dilacak.
- `tools/verify_final.py` gagal pada "Kontrol streaming murattal dan jeda/lanjutkan tidak ditemukan"; kegagalan ini sudah ada pada berkas FIX57 asli dan tidak terkait perubahan ini.

## Uji
Buka Pilih suara qari > Qari anak: Muhammad Taha Al-Junayd harus urutan pertama (juga saat mode pesawat). Pilih Ahmad Saud, tekan Putar: surah penuh harus mulai. Coba beberapa surah untuk Taha.

## Tambahan (FIX59) — surah tidak tersedia pada qari anak
Dugaan lain untuk Ahmad Saud: qari anak sering hanya punya sebagian surah. Bila surah yang sedang dibuka tidak ada pada qari itu, kode lama hanya memunculkan toast singkat lalu berhenti, sehingga terkesan tidak bisa diputar. Sekarang muncul dialog (dan pengumuman status) yang menyebut surah yang tersedia, dengan tombol "Putar surah <terdekat>", "Pilih qari lain", "Batal". Daftar qari anak juga menampilkan "· hanya N surah" bila qari tidak lengkap. Dugaan ini juga belum diverifikasi ke data API.

## FIX60 — data Ahmad Saud memang tidak lengkap
Terkonfirmasi: MP3Quran hanya memuat surah 85–114 untuk Ahmad Saud. Sumber lain (assabile.com: 30 surah; way2quran.com: 33 surah penuh, tidak termasuk surah 1) juga tidak lengkap, jadi tidak ada sumber yang bisa melengkapi. Sebagai gantinya, dialog "surah tidak tersedia" kini punya tombol "Putar surah ini dengan qari anak lain" yang otomatis beralih ke qari anak berikutnya yang punya surah tersebut.

## FIX61 — qari dengan audio tidak lengkap dihapus dari daftar
Hanya qari MP3Quran yang punya seluruh 114 surah yang ditampilkan (Qari anak dan Qari audio per surah), termasuk saat daftar dibaca dari cache lama. Ahmad Saud (hanya surah 85–114) dan qari sejenis tidak lagi muncul. Qari yang sudah terlanjur dipilih sebelumnya tetap berfungsi sampai pengguna menggantinya. Qari anak yang tersisa hanya yang lengkap; bila katalog tidak memuat Muhammad Taha, sumber cadangannya tetap tampil (kelengkapannya belum terverifikasi).

## FIX62 — qari terbaik diperkaya
- Katalog per ayat/juz: ditambah Husary mujawwad, Minshawi mujawwad, Muhammad Jibreel, Abdullah Basfar, Ibrahim Al-Akhdar, Ayman Sowaid, Abdul Basit mujawwad, Parhizgar; ID Hani Ar-Rifai diperbaiki menjadi `ar.hanirifai`. ID ini berasal dari ingatan atas daftar edisi alquran.cloud dan belum diuji; ID yang tidak valid akan gagal diputar (pemuat katalog daring tetap menambahkan edisi resmi yang terdeteksi). `ar.yasseraldosari` dan `ar.nasserqatami` yang sudah ada sebelumnya juga belum terverifikasi.
- Menu baru "Qari terbaik per surah (pilihan)": qari dewasa terkenal (Alafasy, Sudais, Shuraim, Husary, Minshawi, Abdul Basit, Maher Al-Muaiqly, Al-Ghamdi, Al-Ajmi, Al-Hudhaify, Ash-Shatri, Ad-Dosari, Al-Qatami, Ar-Rifai, Ayyub, Basfar, dll.) dari katalog MP3Quran yang lengkap 114 surah, berurutan dari yang paling dikenal. Daftar "Qari audio per surah" juga mengurutkan mereka di atas.
- Belum dikompilasi/diuji di perangkat.

## FIX63 — simbol tidak perlu pada fitur jadwal salat
- `PrayerThirtyActivity.kt` (jadwal tanggal terpilih dan 30 hari): pemisah " · " antarwaktu diganti baris baru, sehingga setiap waktu salat tampil dan dibacakan pembaca layar pada barisnya sendiri.
- `PrayerSettingsActivity.kt`: tanda " — " pada pilihan puasa diganti koma; kunci terjemahannya di `BahasaAplikasi.kt` disesuaikan.
- Halaman utama Jadwal Sholat sudah tanpa simbol dekoratif (satu waktu per baris, hanya titik dua). Belum dikompilasi/diuji di perangkat.

## FIX64 — simbol tidak perlu pada Lokasi Terkini dan Pemandu Jalan
- Pilihan mesin suara (kedua fitur): label sebelumnya "Nama (com.paket.aplikasi)" dengan kurung dan titik nama paket; kini hanya nama mesin suara.
- Lokasi Terkini: teks alamat dari layanan peta dibersihkan dari simbol (garis miring, kurung, bintang, pagar, garis bawah, tanda sama dengan, plus, kurung siku, tanda kutip, titik tengah, tanda pisah panjang, emoji, dan sejenisnya); "&" menjadi "dan". Titik, koma, dan tanda hubung di dalam kata/angka tetap. Berlaku untuk teks yang tampil dan yang dibacakan, bahasa Indonesia maupun Inggris.
- Teks tetap lain pada kedua fitur sudah tanpa simbol dekoratif. Belum dikompilasi/diuji di perangkat; bila ada simbol lain yang masih tampil, kirim teks persisnya.

## FIX65 — simbol pada fitur sebut nama pemanggil
- `CallerListener.kt`: fungsi baru `bersihkanSimbolNotif` membuang emoji, tanda arah teks tak terlihat, "~" (kontak WhatsApp tak tersimpan), kurung, bintang, garis bawah, pagar, garis miring, tanda kutip, "&", "@", dan simbol sejenis; tanda baca biasa dan angka dipertahankan. Dipakai pada nama pemanggil, nama pengirim pesan, nama grup, isi pesan, serta judul/isi notifikasi aplikasi lain, sehingga teks yang tampil dan yang dibacakan sama-sama bersih. Nomor tanpa nama tetap dibaca angka demi angka. Bila nama hanya berisi simbol, dipakai "Pengirim tidak diketahui" / "grup tidak diketahui".
- `PemanggilActivity.kt`: "app(s)" menjadi "apps"; keterangan "(tidak terpasang)" pada daftar aplikasi menjadi ", tidak terpasang".
- Belum dikompilasi/diuji di perangkat. Sumber simbol yang saya duga adalah isi notifikasi (nama, grup, pesan); bila simbol yang mengganggu ada di tempat lain, kirim contoh teks persisnya.

## FIX66 — simbol pada fitur jam dan baterai
- Tampilan Baterai: "Baterai 85% — Mengisi / Suhu 30 °C · Tegangan 4000 mV" menjadi tiga baris tanpa simbol: "Baterai 85%, Mengisi", "Suhu 30,0 derajat Celsius", "Tegangan 4000 milivolt" (juga versi Inggris).
- Teks notifikasi baterai: tanda " — " diganti koma (Indonesia dan Inggris).
- Tombol tes melodi pada Jam: " — " diganti koma.
- Label: tanda kurung pada kalimat baterai penuh diganti koma; " / " pada pengisi daya dan USB menjadi "atau"; garis miring pada daftar keterangan waktu dan jenis panggilan menjadi koma.
- Belum dikompilasi/diuji di perangkat. Judul petunjuk penggunaan ("Jam Pintar Pro — ...") tidak diubah karena di luar fitur ini.

## FIX67 — fitur Khatam Al-Qur'an mengikuti bahasa utama aplikasi
Audit seluruh teks `KhatamActivity.kt` menemukan teks yang masih tetap berbahasa Indonesia walau bahasa aplikasi Inggris:
- Tombol pemutar: "Sebelumnya", "Putar", "Berikutnya", "Lambat", "Cepat" kini mengikuti bahasa (Previous, Play, Next, Slower, Faster). Simbol dekoratif pada tombol pemutar dan jeda/lanjutkan (⏮ ▶ ⏭ ⏸ ⏹ + −) dihapus.
- Status Equalizer (mis. "gagal membuat sesi audio", "tidak didukung") kini dua bahasa.
- Label qari ("Anak", "merdu dan jelas", "tartil dan tajwid", "audio per ayat", "Qari MP3Quran") ditampilkan sesuai bahasa, baik di daftar maupun di status; data tersimpan tetap sama sehingga pilihan lama tidak rusak.
- Pesan galat unduhan/penyimpanan ("Tidak dapat menyimpan cache", validasi jumlah surah/ayat, pembuatan folder/berkas) kini dua bahasa.
- Pemisah " — " pada riwayat Khatam diganti koma.
Teks lain sudah memakai pasangan Indonesia–Inggris; notifikasi pengingat Khatam dan resource string sudah lengkap dua bahasa. Belum dikompilasi/diuji di perangkat. Nama qari (Latin) dan nama berkas unduhan tidak diterjemahkan.
