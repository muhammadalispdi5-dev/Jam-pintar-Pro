package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.RatingBar
import android.widget.TextView

/**
 * Layar hubungi pengembang. Telegram membuka kanal/chat pengembang; WhatsApp tetap menggunakan
 * nomor yang dikonfigurasi. Tidak ada pemantauan panggilan atau notifikasi Telegram di fitur ini.
 */
class KeluhanActivity : Halaman() {

    override val judulHalaman = R.string.kategori_keluhan

    private var kategori = 0
    private var pesan = ""
    private var sertakanInfo = true
    private var penilaianDukungan = 0
    private var doaPengembang = ""

    private companion object {
        const val PAKET_WA = "com.whatsapp"
        const val PAKET_WA_BISNIS = "com.whatsapp.w4b"
        val URL_TELEGRAM_PENGEMBANG = "https://t.me/JamPintarPro"
    }

    private fun daftarKategori() = listOf(
        getString(R.string.keluhan_kat_keluhan), getString(R.string.keluhan_kat_saran), getString(R.string.keluhan_kat_masalah)
    )

    private fun terpasang(paket: String): Boolean =
        try { packageManager.getPackageInfo(paket, 0); true } catch (_: Exception) { false }

    override fun bangun() {
        info(getString(R.string.info_keluhan))
        // Tombol Telegram selalu tersedia, termasuk jika nomor WhatsApp belum dikonfigurasi.
        tombol(getString(R.string.tombol_kirim_telegram)) { bukaTelegram() }
        bagian("Dukungan dan doa untuk pengembang", 20f)
        info("Berikan penilaian bintang 1 sampai 5 dan tuliskan doa atau harapan terbaik untuk pengembang Jam Pintar Pro. Isi ini disimpan di perangkat sampai Anda memilih untuk membagikannya; aplikasi tidak mengirimkannya diam-diam.")
        val penyimpananDukungan = getSharedPreferences("dukungan_pengembang", MODE_PRIVATE)
        penilaianDukungan = penyimpananDukungan.getInt("penilaian_bintang", 0).coerceIn(0, 5)
        doaPengembang = penyimpananDukungan.getString("doa_pengembang", "").orEmpty()
        val labelPenilaian = TextView(this).apply {
            text = ui("Penilaian untuk Jam Pintar Pro, pilih 1 sampai 5 bintang")
            textSize = 16f
            setPadding(0, dp(12), 0, dp(4))
        }
        val ratingBar = RatingBar(this).apply {
            id = View.generateViewId()
            numStars = 5
            stepSize = 1f
            isIndicator = false
            rating = penilaianDukungan.toFloat()
            contentDescription = if (penilaianDukungan == 0) ui("Belum memberi penilaian") else "$penilaianDukungan ${ui("bintang dari 5")}" 
        }
        labelPenilaian.labelFor = ratingBar.id
        root.addView(labelPenilaian)
        root.addView(ratingBar)
        info("Sentuh bintang atau gunakan kontrol aksesibilitas untuk memilih penilaian.")
        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            penilaianDukungan = rating.toInt().coerceIn(0, 5)
            ratingBar.contentDescription = if (penilaianDukungan == 0) ui("Belum memberi penilaian") else "$penilaianDukungan ${ui("bintang dari 5")}" 
        }
        val kolomDoa = isian(
            "Tuliskan doa dan harapan terbaik untuk pengembang",
            doaPengembang,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        ) { doaPengembang = it }.also {
            it.minLines = 4
            it.gravity = Gravity.TOP
            it.contentDescription = ui("Tuliskan doa dan harapan terbaik untuk pengembang Jam Pintar Pro")
        }
        tombol("Simpan dukungan dan doa") {
            doaPengembang = kolomDoa.text?.toString().orEmpty().trim()
            penyimpananDukungan.edit().putInt("penilaian_bintang", penilaianDukungan).putString("doa_pengembang", doaPengembang).apply()
            android.widget.Toast.makeText(this, ui("Dukungan dan doa disimpan di perangkat ini."), android.widget.Toast.LENGTH_LONG).show()
        }
        tombol("Bagikan dukungan dan doa") {
            doaPengembang = kolomDoa.text?.toString().orEmpty().trim()
            if (penilaianDukungan == 0 && doaPengembang.isBlank()) {
                toast("Pilih penilaian bintang atau tuliskan doa terlebih dahulu.")
                return@tombol
            }
            penyimpananDukungan.edit().putInt("penilaian_bintang", penilaianDukungan).putString("doa_pengembang", doaPengembang).apply()
            val rating = if (penilaianDukungan == 0) ui("Belum memberi penilaian") else "$penilaianDukungan ${ui("bintang dari 5")}" 
            val isi = buildString {
                append(ui("Dukungan untuk Jam Pintar Pro")); append("\n")
                append(ui("Penilaian")); append(": "); append(rating)
                if (doaPengembang.isNotBlank()) { append("\n\n"); append(ui("Doa dan harapan untuk pengembang")); append(":\n"); append(doaPengembang) }
            }
            val kirim = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, isi) }
            try { startActivity(Intent.createChooser(kirim, ui("Bagikan dukungan dan doa"))) }
            catch (_: Exception) { toast("Tidak ada aplikasi yang dapat digunakan untuk membagikan pesan.") }
        }
        if (!KeluhanPesan.terkonfigurasi()) {
            info(getString(R.string.keluhan_belum_dikonfigurasi))
            return
        }
        pilihan(getString(R.string.label_jenis_pesan), daftarKategori(), 0) { kategori = it }
        isian(
            getString(R.string.label_isi_pesan), "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        ) { pesan = it }.also {
            it.minLines = 5
            it.gravity = Gravity.TOP
        }
        saklar(getString(R.string.sw_sertakan_info), true) { sertakanInfo = it }
        info(getString(R.string.info_sertakan_info))

        val messenger = terpasang(PAKET_WA)
        val bisnis = terpasang(PAKET_WA_BISNIS)
        if (messenger) tombol(getString(R.string.tombol_kirim_wa_messenger)) { kirim(PAKET_WA) }
        if (bisnis) tombol(getString(R.string.tombol_kirim_wa_bisnis)) { kirim(PAKET_WA_BISNIS) }
        // Tidak terdeteksi: tetap beri satu tombol; sistem memilihkan aplikasi atau membuka halaman WhatsApp.
        if (!messenger && !bisnis) tombol(getString(R.string.tombol_kirim_wa)) { kirim(null) }
    }

    private fun bukaTelegram() {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(URL_TELEGRAM_PENGEMBANG))
        try {
            startActivity(i)
        } catch (_: Exception) {
            toast(R.string.telegram_tidak_dapat_dibuka)
        }
    }

    private fun kirim(paket: String?) {
        if (pesan.trim().length < 10) {
            toast(R.string.keluhan_terlalu_pendek)
            return
        }
        val label = daftarKategori()[kategori.coerceIn(0, 2)]
        val teks = KeluhanPesan.susun(this, label, pesan, sertakanInfo)
        val uri = Uri.parse("https://wa.me/" + KeluhanPesan.nomor() + "?text=" + Uri.encode(teks))
        val i = Intent(Intent.ACTION_VIEW, uri)
        if (paket != null) i.setPackage(paket)
        try {
            startActivity(i)
        } catch (_: Exception) {
            toast(R.string.keluhan_wa_tidak_ada)
        }
    }
}
