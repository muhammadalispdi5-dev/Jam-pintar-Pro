from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt').read_text()
id_text = (root / 'app/src/main/res/values/strings.xml').read_text()
en_text = (root / 'app/src/main/res/values-en/strings.xml').read_text()
checks = {
    'perintah suara cuaca tetap terhubung': 'PerintahSuara.Jenis.CUACA -> bacakanCuaca()' in source,
    'lokasi langsung perangkat dicari': 'ambilLokasiUntukCuaca' in source and 'requestLocationUpdates' in source,
    'GPS dan jaringan digunakan': 'LocationManager.GPS_PROVIDER' in source and 'LocationManager.NETWORK_PROVIDER' in source,
    'lokasi jadwal sholat menjadi cadangan': 'if (lokasiTersimpanValid) pp.lat' in source and 'if (lokasiTersimpanValid) pp.lon' in source,
    'permintaan cuaca HTTPS Open-Meteo': 'https://api.open-meteo.com/v1/forecast?' in source,
    'timeout layanan dibedakan': 'weather service took too long' in source and 'Layanan cuaca terlalu lama merespons' in source,
    'gangguan layanan dibedakan': 'weather data service cannot be reached' in source and 'Layanan data cuaca tidak dapat dihubungi' in source,
    'bahasa Indonesia petunjuk cuaca diperbarui': 'Aplikasi mencoba memakai lokasi perangkat terkini melalui GPS atau jaringan' in id_text,
    'English help updated': 'The app first tries the device current location through GPS or network' in en_text,
    'versi aplikasi tetap 1.0.82': 'versionName = "1.0.82"' in (root / 'app/build.gradle.kts').read_text(),
}
for name, ok in checks.items(): print(('LULUS' if ok else 'GAGAL') + ' - ' + name)
if not all(checks.values()): raise SystemExit(1)
