package com.novan.bateraibicara

import android.content.Context
import java.util.Locale

/**
 * FIX355: tanya jawab tanpa internet. Asisten menjawab pertanyaan dari sumber yang ada di dalam aplikasi: pengetahuan dasar Islam yang
 * baku (rukun, jumlah rakaat, bulan Hijriah), jumlah ayat dan nomor surah, arti Asmaul Husna, penjelasan istilah tajwid, serta isi
 * petunjuk penggunaan aplikasi. Pertanyaan di luar itu dijawab jujur bahwa belum ada jawabannya; asisten tidak mengarang.
 */
object TanyaJawab {
    private val kataTanya = setOf("apa", "apakah", "siapa", "berapa", "bagaimana", "gimana", "mengapa", "kenapa", "jelaskan", "sebutkan", "artinya", "arti", "maksud",
        "what", "who", "how", "why", "explain", "tell", "list", "name", "meaning", "which", "mana", "ada")
    private val kataSelesai = setOf("tidak", "nggak", "gak", "cukup", "selesai", "sudah", "udah", "stop", "no", "enough", "done", "finished", "thanks", "terima", "kasih", "makasih", "tutup", "keluar", "bye")
    private val kataHenti = setOf("tidak", "nggak", "gak", "cukup", "selesai", "sudah", "udah", "stop", "no", "enough", "done", "makasih", "tutup", "keluar", "bye", "thanks", "finished")

    private fun token(u: String): List<String> =
        u.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun normal(s: String): String = s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "")

    /** true bila ucapan hanya berisi penutup percakapan ("sudah", "cukup", "tidak ada", "terima kasih"). */
    fun akhiriSesi(ucapan: String): Boolean {
        val t = token(ucapan)
        return t.isNotEmpty() && t.size <= 5 && t.any { it in kataHenti } && t.none { it in kataTanya }
    }

    /** Memulai sesi tanya jawab: "saya ingin bertanya", "tanya jawab", "ayo ngobrol". */
    fun mulaiSesi(ucapan: String): Boolean {
        val t = token(ucapan)
        if (t.isEmpty() || t.size > 9) return false
        val tanya = t.any { it in setOf("bertanya", "tanya", "ngobrol", "mengobrol", "obrolan", "ask", "chat", "talk", "conversation") }
        val ajakan = t.any { it in setOf("ingin", "mau", "boleh", "bisa", "saya", "aku", "mari", "ayo", "dong", "sesuatu", "jawab", "something", "question", "can", "let", "lets", "have", "want", "ada") }
        val frasa = t.joinToString(" ")
        return (tanya && ajakan) || frasa.contains("tanya jawab") || frasa.contains("ada pertanyaan") || frasa.contains("i have a question") || frasa.contains("lets talk") || frasa.contains("let s talk")
    }

    /** Pertanyaan faktual yang dapat dijawab langsung dari sumber dalam aplikasi; null bila tidak ada jawabannya. */
    fun jawab(c: Context, ucapan: String, denganBantuan: Boolean = true): String? {
        val en = BahasaAplikasi.tampilan(c) == 1
        fun tr(id: String, e: String) = if (en) e else id
        val t = token(ucapan)
        if (t.isEmpty()) return null
        val f = " " + t.joinToString(" ") + " "
        fun ada_contains(vararg k: String) = k.any { f.contains(" $it ") }
        val tanya = t.any { it in kataTanya }

        // ---- Perkenalan dan kemampuan ----
        if (ada_contains("siapa kamu", "kamu siapa", "siapa namamu", "nama kamu", "siapa anda", "who are you", "your name")) {
            return tr("Saya asisten suara Jam Pintar Pro. Saya membantu membacakan jam dan tanggal, membuka fitur, memutar Al-Qur'an, dan menjawab pertanyaan dasar.",
                "I am the Jam Pintar Pro voice assistant. I help with the time and date, opening features, playing the Qur'an, and answering basic questions.")
        }
        if (ada_contains("kamu bisa apa", "bisa apa saja", "apa yang bisa kamu lakukan", "apa yang bisa anda lakukan", "what can you do")) {
            return tr("Saya dapat membacakan jam dan tanggal, termasuk jam di negara lain; memutar Al-Qur'an dan terjemahannya; membacakan hadis dan tafsir sesuai tema; membuka fitur aplikasi; mengatur timer; dan menjawab pertanyaan dasar tentang Islam, Asmaul Husna, tajwid, serta cara memakai aplikasi. Katakan, misalnya, jam berapa di Arab Saudi, atau saya ingin bertanya.",
                "I can read the time and date, including the time in other countries; play the Qur'an and its translation; read hadith and tafsir by theme; open app features; set timers; and answer basic questions about Islam, Asmaul Husna, tajwid, and how to use the app. Say, for example, what time is it in Saudi Arabia, or I have a question.")
        }
        if (!tanya && !ada_contains("rukun", "rakaat", "rakat", "tajwid", "asmaul husna")) {
            return if (denganBantuan) bantuanAplikasi(c, t, en) else null
        }

        // ---- Pengetahuan dasar ----
        if (ada_contains("rukun islam")) return tr("Rukun Islam ada lima: syahadat, salat lima waktu, puasa Ramadan, zakat, dan haji bagi yang mampu.",
            "The five pillars of Islam are: the declaration of faith, the five daily prayers, fasting in Ramadan, zakat, and hajj for those who are able.")
        if (ada_contains("rukun iman")) return tr("Rukun iman ada enam: iman kepada Allah, malaikat-malaikat-Nya, kitab-kitab-Nya, rasul-rasul-Nya, hari akhir, dan qada serta qadar.",
            "The six articles of faith are: belief in Allah, His angels, His books, His messengers, the Last Day, and divine decree.")
        if (ada_contains("rakaat", "rakat", "raka at", "rakaah", "rak at", "rakah")) {
            val semua = listOf("subuh" to 2, "zuhur" to 4, "asar" to 4, "magrib" to 3, "isya" to 4)
            val alias = mapOf("subuh" to listOf("subuh", "shubuh", "fajr"), "zuhur" to listOf("zuhur", "dzuhur", "duhur", "dhuhr", "zhuhur"),
                "asar" to listOf("asar", "ashar", "asr"), "magrib" to listOf("magrib", "maghrib"), "isya" to listOf("isya", "isyak", "isha"))
            val satu = semua.firstOrNull { (n, _) -> alias[n].orEmpty().any { ada_contains(it) } }
            return if (satu != null) tr("Salat " + satu.first.replaceFirstChar { it.uppercase() } + " terdiri dari " + satu.second + " rakaat.", "The " + satu.first + " prayer has " + satu.second + " rakaat.")
            else tr("Jumlah rakaat salat fardu: Subuh 2, Zuhur 4, Asar 4, Magrib 3, dan Isya 4 rakaat.", "The obligatory prayers have: Fajr 2, Dhuhr 4, Asr 4, Maghrib 3, and Isha 4 rakaat.")
        }
        if (ada_contains("salat fardu", "sholat fardhu", "sholat wajib", "salat wajib", "shalat wajib", "shalat lima waktu", "sholat lima waktu", "salat lima waktu", "waktu salat ada berapa", "five daily prayers")) {
            return tr("Salat fardu ada lima: Subuh, Zuhur, Asar, Magrib, dan Isya.", "There are five obligatory prayers: Fajr, Dhuhr, Asr, Maghrib, and Isha.")
        }
        if (ada_contains("bulan hijriah", "bulan hijriyah", "bulan islam", "bulan qamariyah", "islamic months", "hijri months")) {
            return tr("Bulan Hijriah ada dua belas: Muharram, Safar, Rabiul Awal, Rabiul Akhir, Jumadil Awal, Jumadil Akhir, Rajab, Syaban, Ramadan, Syawal, Zulkaidah, dan Zulhijah.",
                "The twelve Hijri months are: Muharram, Safar, Rabi al-Awwal, Rabi al-Thani, Jumada al-Awwal, Jumada al-Thani, Rajab, Shaban, Ramadan, Shawwal, Dhul Qadah, and Dhul Hijjah.")
        }
        if (ada_contains("malaikat") && ada_contains("sepuluh", "10", "wajib", "nama", "sebutkan")) {
            return tr("Sepuluh malaikat yang wajib diketahui: Jibril, Mikail, Israfil, Izrail, Munkar, Nakir, Raqib, Atid, Malik, dan Ridwan.",
                "The ten angels commonly taught: Jibril, Mikail, Israfil, Izrail, Munkar, Nakir, Raqib, Atid, Malik, and Ridwan.")
        }
        if (ada_contains("kitab") && ada_contains("empat", "4", "wajib", "diturunkan", "nama kitab")) {
            return tr("Empat kitab Allah yang disebutkan: Taurat kepada Nabi Musa, Zabur kepada Nabi Daud, Injil kepada Nabi Isa, dan Al-Qur'an kepada Nabi Muhammad shallallahu alaihi wa sallam.",
                "The four revealed books: the Torah to Musa, the Psalms to Dawud, the Gospel to Isa, and the Qur'an to Muhammad, peace be upon him.")
        }
        if (ada_contains("nabi", "rasul") && ada_contains("dua puluh lima", "25", "wajib diketahui")) {
            return tr("Ada dua puluh lima nabi dan rasul yang wajib diketahui: Adam, Idris, Nuh, Hud, Saleh, Ibrahim, Luth, Ismail, Ishaq, Yakub, Yusuf, Ayyub, Syuaib, Musa, Harun, Zulkifli, Daud, Sulaiman, Ilyas, Ilyasa, Yunus, Zakaria, Yahya, Isa, dan Muhammad shallallahu alaihi wa sallam.",
                "Twenty-five prophets and messengers are named in the Qur'an: Adam, Idris, Nuh, Hud, Salih, Ibrahim, Lut, Ismail, Ishaq, Yaqub, Yusuf, Ayyub, Shuaib, Musa, Harun, Dhul-Kifl, Dawud, Sulaiman, Ilyas, Alyasa, Yunus, Zakariya, Yahya, Isa, and Muhammad, peace be upon him.")
        }
        // ---- Al-Qur'an: jumlah dan nomor surah ----
        if (ada_contains("jumlah surah", "berapa surah", "surah ada berapa", "how many surahs", "number of surahs")) return tr("Al-Qur'an terdiri dari 114 surah.", "The Qur'an has 114 surahs.")
        if (ada_contains("jumlah juz", "berapa juz", "juz ada berapa", "how many juz")) return tr("Al-Qur'an terdiri dari 30 juz.", "The Qur'an has 30 juz.")
        if ((ada_contains("jumlah ayat", "berapa ayat", "ayat ada berapa", "how many verses", "how many ayat", "number of verses")) && surahDisebut(t) == null) {
            return tr("Jumlah ayat Al-Qur'an adalah 6.236 menurut hitungan yang lazim dipakai pada mushaf standar.", "The Qur'an has 6,236 verses by the count commonly used in the standard mushaf.")
        }
        val nomor = surahDisebut(t)
        if (nomor != null && (ada_contains("jumlah ayat", "berapa ayat", "ayat ada berapa", "how many verses", "how many ayat", "banyak ayat"))) {
            return tr(PenafsirQuran.namaTampil(nomor) + " terdiri dari " + PenafsirQuran.jumlahAyat(nomor) + " ayat.", PenafsirQuran.namaTampil(nomor) + " has " + PenafsirQuran.jumlahAyat(nomor) + " verses.")
        }
        if (nomor != null && (ada_contains("surah ke berapa", "surat ke berapa", "nomor berapa", "urutan ke berapa", "which number", "what number"))) {
            return tr(PenafsirQuran.namaTampil(nomor) + " adalah surah ke-" + nomor + " dalam Al-Qur'an.", PenafsirQuran.namaTampil(nomor) + " is surah number " + nomor + " in the Qur'an.")
        }
        val ke = Regex("(?:surah|surat)\\s+(?:ke\\s+)?(\\d{1,3})").find(t.joinToString(" "))?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("(\\d{1,3})\\s+(?:surah|surat)").find(t.joinToString(" "))?.groupValues?.get(1)?.toIntOrNull()
        if (ke != null && ke in 1..114 && tanya && ada_contains("apa", "siapa", "nama", "what", "which")) {
            return tr("Surah ke-" + ke + " adalah " + PenafsirQuran.namaTampil(ke) + ", terdiri dari " + PenafsirQuran.jumlahAyat(ke) + " ayat.", "Surah number " + ke + " is " + PenafsirQuran.namaTampil(ke) + ", with " + PenafsirQuran.jumlahAyat(ke) + " verses.")
        }
        // ---- Asmaul Husna ----
        val ke99 = Regex("nama\\s+(?:allah\\s+)?(?:ke\\s+)?(\\d{1,2})").find(t.joinToString(" "))?.groupValues?.get(1)?.toIntOrNull()
        if (ke99 != null && ke99 in 1..99 && (ada_contains("asmaul husna", "nama allah", "asma ul husna"))) {
            val n = AsmaulHusnaData.daftar.getOrNull(ke99 - 1)
            if (n != null) return tr("Nama Allah ke-" + ke99 + " adalah " + n.latin + ", artinya " + n.artiId + ".", "The " + ke99 + "th name of Allah is " + n.latin + ", meaning " + n.artiEn + ".")
        }
        if (ada_contains("asmaul husna", "nama allah", "arti nama", "artinya", "arti", "meaning", "maksud") || tanya) {
            val kata = t.map { normal(it) }
            val gabung = mutableSetOf<String>()
            for (i in kata.indices) { gabung.add(kata[i]); if (i + 1 < kata.size) gabung.add(kata[i] + kata[i + 1]); if (i + 2 < kata.size) gabung.add(kata[i] + kata[i + 1] + kata[i + 2]) }
            val cocok = AsmaulHusnaData.daftar.withIndex().filter { (_, n) ->
                val ln = normal(n.latin)
                ln.length >= 5 && (ln in gabung || (ln.startsWith("al") || ln.startsWith("ar") || ln.startsWith("as") || ln.startsWith("an") || ln.startsWith("ad") || ln.startsWith("at") || ln.startsWith("az")) && ln.drop(2).let { it.length >= 5 && it in gabung })
            }
            if (cocok.size == 1) {
                val (i, n) = cocok[0]
                return tr(n.latin + " adalah nama Allah ke-" + (i + 1) + ", artinya " + n.artiId + ".", n.latin + " is the " + (i + 1) + "th name of Allah, meaning " + n.artiEn + ".")
            }
        }
        // ---- Tajwid ----
        if (ada_contains("tajwid", "hukum", "idgham", "idghom", "ikhfa", "iqlab", "izhar", "qalqalah", "ghunnah", "mad", "waqaf", "waqf", "nun sukun", "mim sukun", "tanwin", "hijaiyah") && tanya) {
            val idx = TajwidData.cari(listOf(ucapan))
            val p = idx?.let { TajwidData.daftar.getOrNull(it) }
            if (p != null) {
                val isi = if (en) p.isi.en else p.isi.id
                val judul = if (en) p.judul.en else p.judul.id
                return judul + ". " + ringkas(isi, 420) + tr(" Selengkapnya ada di Belajar Tajwid.", " More is in Learn Tajwid.")
            }
        }
        return if (denganBantuan) bantuanAplikasi(c, t, en) else null
    }

    private fun ringkas(s: String, maks: Int): String {
        val bersih = s.replace(Regex("\\s+"), " ").trim()
        if (bersih.length <= maks) return bersih
        val potong = bersih.lastIndexOf(". ", maks)
        return if (potong > maks / 3) bersih.substring(0, potong + 1) else bersih.substring(0, maks).trimEnd() + "."
    }

    /** Nomor surah (1..114) yang disebut dalam ucapan, atau null. Nama diperiksa sebagai satu kata, dua, atau tiga kata yang digabung. */
    fun surahDisebut(t: List<String>): Int? {
        val kata = t.map { normal(it) }.filter { it.isNotEmpty() }
        val gabung = mutableSetOf<String>()
        for (i in kata.indices) { gabung.add(kata[i]); if (i + 1 < kata.size) gabung.add(kata[i] + kata[i + 1]); if (i + 2 < kata.size) gabung.add(kata[i] + kata[i + 1] + kata[i + 2]) }
        var terbaik: Int? = null; var panjang = 0
        for (n in 1..114) {
            val nama = normal(HafalanSrs.namaSurah(n))
            val tanpaArtikel = if (nama.length > 6 && Regex("^(al|an|ar|as|ad|at|az|ash|adh|ath|azh)").containsMatchIn(nama)) nama.replaceFirst(Regex("^(ash|adh|ath|azh|al|an|ar|as|ad|at|az)"), "") else nama
            for (k in listOf(nama, tanpaArtikel)) {
                if (k.length >= 4 && k in gabung && k.length > panjang) { panjang = k.length; terbaik = n }
            }
        }
        return terbaik
    }

    /** Mencari jawaban di petunjuk penggunaan aplikasi; null bila tidak ada butir yang cukup cocok. */
    fun bantuanAplikasi(c: Context, t: List<String>, en: Boolean): String? {
        val stop = setOf("bagaimana", "gimana", "caranya", "cara", "apa", "yang", "untuk", "dengan", "dari", "pada", "dalam", "atau", "saya", "aku", "kamu", "anda", "agar", "bisa", "dapat", "tolong", "tentang", "mengenai",
            "how", "what", "the", "does", "can", "for", "with", "from", "about", "this", "that", "use", "using", "please", "fitur", "aplikasi", "app", "feature")
        val kunci = t.filter { it.length >= 4 && it !in stop }.distinct()
        if (kunci.isEmpty()) return null
        val sumber = try {
            listOf(c.getString(R.string.isi_petunjuk_penggunaan), c.getString(R.string.isi_petunjuk_penggunaan_lanjutan), c.getString(R.string.isi_petunjuk_penggunaan_lanjutan_3))
        } catch (_: Exception) { return null }
        var terbaik = ""; var skorTerbaik = 0
        for (s in sumber) {
            for (butir in s.split(Regex("(?m)^\\s*(?=\\d{1,3}\\.\\s)"))) {
                val rendah = butir.lowercase(Locale.ROOT)
                if (rendah.length < 40) continue
                val skor = kunci.count { rendah.contains(it) }
                if (skor > skorTerbaik) { skorTerbaik = skor; terbaik = butir }
            }
        }
        val perlu = if (kunci.size <= 2) 1 else (kunci.size + 1) / 2
        if (skorTerbaik < perlu || skorTerbaik == 0) return null
        fun tr(id: String, e: String) = if (en) e else id
        val awal = tr("Dari petunjuk penggunaan aplikasi: ", "From the app instructions: ")
        return awal + ringkas(terbaik.replace(Regex("^\\s*\\d{1,3}\\.\\s*"), ""), 520)
    }

    fun tidakAda(c: Context): String {
        val en = BahasaAplikasi.tampilan(c) == 1
        return if (en) "Sorry, I do not have an answer to that yet. I can answer basic questions about Islam, the Qur'an, Asmaul Husna, tajwid, time around the world, and how to use this app."
        else "Maaf, saya belum memiliki jawaban untuk itu. Saya dapat menjawab pertanyaan dasar tentang Islam, Al-Qur'an, Asmaul Husna, tajwid, jam di berbagai negara, dan cara memakai aplikasi ini."
    }
}
