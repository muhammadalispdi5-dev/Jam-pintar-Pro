package com.novan.bateraibicara

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/**
 * Mengoperasikan kontrol panggilan WhatsApp hanya untuk permintaan yang baru saja
 * dikonfirmasi pengguna dengan ucapan "telepon suara" atau "telepon video".
 * Tidak membaca isi chat dan tidak mengirim pesan.
 *
 * FIX138: layanan yang sama juga menekan sakelar Wi-Fi, Bluetooth, lokasi, hotspot, data seluler,
 * mode pesawat, atau NFC di layar Pengaturan Android, hanya untuk
 * permintaan yang baru saja diucapkan pengguna ("hidupkan/matikan ..."). Android tidak mengizinkan aplikasi biasa mengubahnya
 * secara langsung, sehingga sakelar di layar pengaturan resmi yang ditekan. Satu layanan, satu izin aksesibilitas.
 */
class PanggilanWhatsAppAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var perangkatTerjadwal = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (tanganiKontrolPerangkat(event)) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_PENDING, false)) return
        val dibuat = prefs.getLong(KEY_CREATED, 0L)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > 45_000L) {
            prefs.edit().clear().apply(); return
        }
        val paket = prefs.getString(KEY_PACKAGE, "") ?: ""
        if (event.packageName?.toString() != paket) return
        val root = rootInActiveWindow ?: return
        val jenis = prefs.getString(KEY_TYPE, "voice") ?: "voice"
        val target = if (jenis == "video") VIDEO_LABELS else VOICE_LABELS
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        kumpulkan(root, nodes, 0)

        // Utamakan kontrol yang menyebut jenis panggilan secara spesifik. Bila WhatsApp
        // menampilkan menu konfirmasi, item spesifik akan ditemukan pada event berikutnya.
        val stage = prefs.getInt(KEY_STAGE, 0)
        if (stage == 2) {
            // Hanya tekan tombol konfirmasi bila dialog benar-benar menyebut jenis panggilan
            // yang baru saja dipilih pengguna. Jangan menekan tombol umum di layar chat.
            val teksLayar = nodes.joinToString(" ") { label(it) }
            val judulKonfirmasi = if (jenis == "video")
                listOf("start video call", "mulai panggilan video", "mulai panggilan vidio", "memulai panggilan video").any { teksLayar.contains(it) }
            else listOf("start voice call", "mulai panggilan suara", "memulai panggilan suara").any { teksLayar.contains(it) }
            if (judulKonfirmasi) {
                val tombol = nodes.firstOrNull { node ->
                    val l = label(node)
                    node.isEnabled && (l == "call" || l == "panggil" || l == "start" || l == "mulai") && punyaIndukKlik(node)
                }
                if (tombol != null && klik(tombol)) prefs.edit().putBoolean(KEY_PENDING, false).apply()
            }
            return
        }

        val spesifik = nodes.firstOrNull { node ->
            val l = label(node)
            target.any { l.contains(it) } && node.isEnabled && punyaIndukKlik(node)
        }
        if (spesifik != null && klik(spesifik)) {
            prefs.edit().putInt(KEY_STAGE, 2).apply()
            return
        }

        // Beberapa versi WhatsApp hanya menampilkan tombol umum "Call" yang membuka
        // pilihan suara/video. Klik tombol umum satu kali, lalu tunggu item spesifik.
        if (stage == 0) {
            val umum = nodes.firstOrNull { node ->
                val label = label(node)
                node.isEnabled && (label == "call" || label == "panggilan" || label == "telepon" || label == "voice/video call")
            }
            if (umum != null && klik(umum)) {
                prefs.edit().putInt(KEY_STAGE, 1).apply()
                return
            }
        }
    }

    // ===== FIX138: kontrol sakelar perangkat melalui antarmuka sistem =====

    private fun paketPengaturan(paket: String): Boolean {
        val p = paket.lowercase()
        // Android AOSP, Samsung, Xiaomi, OPPO/realme, vivo, dan panel System UI.
        return p == "com.android.settings" || p == "com.android.systemui" ||
            p.contains("settings") || p.endsWith(".setting") || p.contains("wireless")
    }

    /** true bila ada permintaan kontrol perangkat yang masih berlaku (logika WhatsApp tidak dijalankan pada event ini). */
    private fun tanganiKontrolPerangkat(event: AccessibilityEvent): Boolean {
        val p = getSharedPreferences(PREFS_PERANGKAT, MODE_PRIVATE)
        if (!p.getBoolean(KEY_PERANGKAT_PENDING, false)) return false
        val dibuat = p.getLong(KEY_PERANGKAT_DIBUAT, 0L)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > BATAS_PERANGKAT_MS) { p.edit().clear().apply(); return false }
        if (paketPengaturan(event.packageName?.toString().orEmpty())) jadwalkanPerangkat(350L)
        return true
    }

    private fun jadwalkanPerangkat(tunda: Long) {
        if (perangkatTerjadwal) return
        perangkatTerjadwal = true
        handler.postDelayed({ perangkatTerjadwal = false; cobaKontrolPerangkat() }, tunda)
    }

    private fun cobaKontrolPerangkat() {
        val p = getSharedPreferences(PREFS_PERANGKAT, MODE_PRIVATE)
        if (!p.getBoolean(KEY_PERANGKAT_PENDING, false)) return
        val dibuat = p.getLong(KEY_PERANGKAT_DIBUAT, 0L)
        val jenis = p.getString(KEY_PERANGKAT_JENIS, "") ?: ""
        val mau = p.getBoolean(KEY_PERANGKAT_AKTIF, true)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > BATAS_PERANGKAT_MS) {
            p.edit().clear().apply()
            umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
            return
        }
        val root = rootInActiveWindow
        if (root == null || !paketPengaturan(root.packageName?.toString().orEmpty())) { jadwalkanPerangkat(700L); return }
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        kumpulkan(root, nodes, 0)
        val sakelar = PemilihSakelar.pilih(nodes.map { node -> infoSakelar(node) }, jenis)
        val tahap = p.getInt(KEY_PERANGKAT_TAHAP, 0)
        if (sakelar == null) {
            // FIX137: hotspot di banyak ponsel dua langkah: halaman tethering hanya berisi baris "Wi-Fi hotspot" yang membuka sakelarnya.
            if (jenis == "hotspot" && tahap == 0) {
                val daftarBaris = nodes.map { node -> infoBaris(node) }
                val baris = PemilihSakelar.pilihBarisHotspot(daftarBaris)
                if (baris != null && klik(nodes[baris])) {
                    p.edit().putInt(KEY_PERANGKAT_TAHAP, 1).apply()
                    jadwalkanPerangkat(1000L)
                    return
                }
            }
            jadwalkanPerangkat(700L); return
        }
        val node = nodes[sakelar]
        val sekarang = statusSakelar(node)
        val percobaan = p.getInt(KEY_PERANGKAT_PERCOBAAN, 0)
        if (sekarang == mau) {
            p.edit().clear().apply()
            umumkan(if (percobaan == 0) R.string.perintah_perangkat_sudah else R.string.perintah_perangkat_berhasil, namaPerangkat(jenis), statusPerangkat(mau, percobaan == 0))
            // Tutup layar Pengaturan; hotspot dua langkah perlu dua kali kembali.
            val kali = if (tahap >= 1) 2 else 1
            for (k in 0 until kali) handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 900L + k * 700L)
            return
        }
        if (percobaan >= 3) {
            p.edit().clear().apply()
            umumkan(R.string.perintah_perangkat_gagal_otomatis, namaPerangkat(jenis))
            return
        }
        p.edit().putInt(KEY_PERANGKAT_PERCOBAAN, percobaan + 1).apply()
        klik(node)
        jadwalkanPerangkat(900L) // verifikasi hasil klik
    }

    /** Membaca status sakelar dari checked dan stateDescription pada Android/OEM yang mengekspos status sebagai teks. */
    private fun statusSakelar(node: AccessibilityNodeInfo): Boolean {
        if (node.isChecked) return true
        val status = try { node.stateDescription?.toString().orEmpty().lowercase() } catch (_: Exception) { "" }
        val deskripsi = label(node)
        if (status in listOf("on", "enabled", "aktif", "nyala", "diaktifkan") ||
            status.contains("turned on") || status.contains("dihidupkan")) return true
        if (status in listOf("off", "disabled", "nonaktif", "mati", "dinonaktifkan") ||
            status.contains("turned off") || status.contains("dimatikan")) return false
        // Jangan menyimpulkan status dari label seperti "Turn on Wi-Fi" karena itu justru
        // dapat muncul ketika sakelar sedang mati. isChecked menjadi sumber utama status.
        return false
    }

    private fun infoSakelar(node: AccessibilityNodeInfo): PemilihSakelar.Info {
        val nama = node.className?.toString().orEmpty()
        val id = node.viewIdResourceName.orEmpty().lowercase()
        val bisaDicentang = node.isCheckable || nama.contains("Switch", true) || nama.contains("ToggleButton", true) ||
            nama.contains("CompoundButton", true) || id.contains("switch_widget") || id.contains("switchbar") || id.contains("toggle")
        if (!bisaDicentang) return PemilihSakelar.Info(false, false, false, "", "")
        // Konteks sempit: teks sakelar itu sendiri, induk langsung beserta saudaranya (judul di sebelah sakelar), dan label kakek.
        // Konteks yang lebih luas membuat semua sakelar pada panel gabungan tampak menyebut Wi-Fi sekaligus.
        val konteks = StringBuilder(label(node))
        val induk = node.parent
        if (induk != null) {
            konteks.append(' ').append(label(induk))
            for (i in 0 until induk.childCount) induk.getChild(i)?.let { if (it != node) konteks.append(' ').append(label(it)) }
            induk.parent?.let { konteks.append(' ').append(label(it)) }
        }
        return PemilihSakelar.Info(true, node.isVisibleToUser, node.isEnabled, konteks.toString().lowercase(), node.viewIdResourceName.orEmpty().lowercase())
    }

    private fun infoBaris(node: AccessibilityNodeInfo): PemilihSakelar.InfoBaris {
        val nama = node.className?.toString().orEmpty()
        val id = node.viewIdResourceName.orEmpty().lowercase()
        val bisaDicentang = node.isCheckable || nama.contains("Switch", true) || nama.contains("ToggleButton", true) ||
            nama.contains("CompoundButton", true) || id.contains("switch_widget") || id.contains("switchbar") || id.contains("toggle")
        val teks = label(node)
        if (teks.isBlank() || bisaDicentang) return PemilihSakelar.InfoBaris(teks, false, false, bisaDicentang)
        // Baris harus berada di dalam daftar; judul halaman (di luar daftar) tidak boleh diketuk.
        var dalamDaftar = false
        var induk = node.parent
        var tingkat = 0
        while (induk != null && tingkat++ < 10) {
            val n = induk.className?.toString().orEmpty()
            if (n.contains("RecyclerView") || n.contains("ListView") || n.contains("ScrollView")) { dalamDaftar = true; break }
            induk = induk.parent
        }
        return PemilihSakelar.InfoBaris(teks, punyaIndukKlik(node), dalamDaftar, false)
    }

    private fun namaPerangkat(jenis: String): String =
        BahasaAplikasi.bungkus(this).getString(
            when (jenis) {
                "bluetooth" -> R.string.perintah_perangkat_bluetooth
                "lokasi" -> R.string.perintah_perangkat_lokasi
                "hotspot" -> R.string.perintah_perangkat_hotspot
                "data_seluler" -> R.string.perintah_perangkat_data
                "pesawat" -> R.string.perintah_perangkat_pesawat
                "nfc" -> R.string.perintah_perangkat_nfc
                else -> R.string.perintah_perangkat_wifi
            }
        )

    private fun statusPerangkat(aktif: Boolean, sudahDariAwal: Boolean): String {
        val c = BahasaAplikasi.bungkus(this)
        return c.getString(
            if (sudahDariAwal) (if (aktif) R.string.perintah_perangkat_status_aktif else R.string.perintah_perangkat_status_mati)
            else (if (aktif) R.string.perintah_perangkat_status_diaktifkan else R.string.perintah_perangkat_status_dimatikan)
        )
    }

    private fun umumkan(res: Int, vararg arg: Any) {
        val teks = try { BahasaAplikasi.bungkus(this).getString(res, *arg) } catch (_: Exception) { return }
        try { Toast.makeText(applicationContext, teks, Toast.LENGTH_LONG).show() } catch (_: Exception) { }
        try {
            val suara = Pembicara(applicationContext, Prefs(applicationContext).suara("jam"))
            suara.bisaDibungkam = true
            suara.ucapkan(teks, true) { try { suara.matikan() } catch (_: Exception) { } }
        } catch (_: Exception) { }
    }

    private fun label(node: AccessibilityNodeInfo): String =
        ((node.text?.toString().orEmpty()) + " " + (node.contentDescription?.toString().orEmpty()))
            .lowercase().replace(Regex("\\s+"), " ").trim()

    private fun kumpulkan(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 500) return
        out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { kumpulkan(it, out, depth + 1) }
    }

    private fun punyaIndukKlik(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 6) {
            if (current.isClickable && current.isEnabled) return true
            current = current.parent
        }
        return false
    }

    private fun klik(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 6) {
            if (current.isClickable && current.isEnabled) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            current = current.parent
        }
        return false
    }

    override fun onInterrupt() = Unit

    companion object {
        const val PREFS = "wa_auto_call"
        const val KEY_PENDING = "pending"
        const val KEY_PACKAGE = "package"
        const val KEY_TYPE = "type"
        const val KEY_CREATED = "created"
        const val KEY_STAGE = "stage"
        // FIX138: permintaan kontrol perangkat (ditulis PerintahSuaraActivity, dibaca layanan ini)
        const val PREFS_PERANGKAT = "kontrol_perangkat_auto"
        const val KEY_PERANGKAT_PENDING = "pending"
        const val KEY_PERANGKAT_JENIS = "jenis"
        const val KEY_PERANGKAT_AKTIF = "aktif"
        const val KEY_PERANGKAT_DIBUAT = "dibuat"
        const val KEY_PERANGKAT_PERCOBAAN = "percobaan"
        /** 0 = belum membuka halaman hotspot terpisah, 1 = baris hotspot sudah diketuk. */
        const val KEY_PERANGKAT_TAHAP = "tahap"
        const val BATAS_PERANGKAT_MS = 25_000L
        private val VOICE_LABELS = listOf("voice call", "panggilan suara", "telepon suara", "panggilan audio", "audio call", "call by voice")
        private val VIDEO_LABELS = listOf("video call", "panggilan video", "telepon video", "panggilan vidio")
    }
}
