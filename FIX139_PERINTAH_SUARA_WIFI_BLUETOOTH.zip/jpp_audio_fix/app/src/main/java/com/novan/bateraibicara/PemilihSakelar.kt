package com.novan.bateraibicara

/**
 * FIX136/137: memilih sakelar (Wi-Fi, Bluetooth, lokasi, hotspot) yang benar dari pohon tampilan layar Pengaturan, tanpa memakai
 * Android API, agar logikanya dapat diuji terpisah. Aturan: hanya sakelar yang tampil dan aktif; utamakan yang konteks teks atau id-nya
 * menyebut perangkat yang diminta. Bila tidak ada yang cocok, sakelar tunggal di layar dipakai; bila ada beberapa yang tidak
 * cocok, tidak ada yang dipilih (lebih baik gagal daripada menekan sakelar yang salah).
 */
object PemilihSakelar {
    data class Info(
        val bisaDicentang: Boolean,
        val terlihat: Boolean,
        val aktif: Boolean,
        /** Teks node, induk, saudaranya, dan kakek, huruf kecil. */
        val konteks: String,
        val idSumber: String
    )

    /** Baris daftar yang dapat diketuk (bukan sakelar), dipakai untuk membuka halaman hotspot pada ponsel yang memisahkannya. */
    data class InfoBaris(val label: String, val bisaDiklik: Boolean, val dalamDaftar: Boolean, val bisaDicentang: Boolean)

    private val kataWifi = listOf("wi-fi", "wifi", "wi fi", "wlan", "wireless lan", "wireless network")
    private val kataBluetooth = listOf("bluetooth", "bluetooth radio", "bluetooth device")
    private val kataLokasi = listOf("location", "lokasi", "gps")
    private val kataHotspot = listOf("hotspot", "hot spot")
    private val kataDataSeluler = listOf("mobile data", "cellular data", "data seluler", "data selular", "mobile_data", "mobiledata", "cellular_data")
    private val kataPesawat = listOf("airplane mode", "airplane_mode", "flight mode", "mode pesawat", "airplane", "pesawat")
    private val kataNfc = listOf("nfc")

    // Sakelar yang sering bersanding di panel/pengaturan dan tidak boleh ditekan untuk perangkat yang diminta.
    private val kataLainDasar = listOf("airplane", "pesawat", "mobile data", "data seluler", "hotspot", "nfc", "location", "lokasi")

    private fun kata(jenis: String): List<String> = when (jenis) {
        "bluetooth" -> kataBluetooth
        "lokasi" -> kataLokasi
        "hotspot" -> kataHotspot
        "data_seluler" -> kataDataSeluler
        "pesawat" -> kataPesawat
        "nfc" -> kataNfc
        else -> kataWifi
    }

    private fun kataLain(jenis: String): List<String> = when (jenis) {
        // Hindari memilih sakelar perangkat lain pada halaman gabungan/pengaturan OEM.
        "wifi" -> listOf("bluetooth", "airplane", "pesawat", "mobile data", "data seluler", "hotspot", "nfc", "location", "lokasi", "scanning", "pemindaian")
        "bluetooth" -> listOf("wi-fi", "wifi", "wlan", "airplane", "pesawat", "mobile data", "data seluler", "hotspot", "nfc", "location", "lokasi", "scanning", "pemindaian", "tethering", "usb")
        // Halaman lokasi memuat sakelar "pemindaian Wi-Fi/Bluetooth" yang bukan sakelar lokasi utama.
        "lokasi" -> listOf("airplane", "pesawat", "mobile data", "data seluler", "hotspot", "nfc", "wi-fi", "wifi", "bluetooth", "scanning", "pemindaian")
        // Halaman tethering memuat Bluetooth/USB/Ethernet tethering; "Wi-Fi hotspot" tetap sah.
        "hotspot" -> listOf("airplane", "pesawat", "mobile data", "data seluler", "nfc", "location", "lokasi", "bluetooth", "usb", "ethernet")
        "data_seluler" -> listOf("airplane", "pesawat", "nfc", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan")
        "pesawat" -> listOf("mobile data", "data seluler", "data selular", "nfc", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan")
        "nfc" -> listOf("airplane", "pesawat", "mobile data", "data seluler", "data selular", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan")
        else -> kataLainDasar
    }

    fun pilih(daftar: List<Info>, jenis: String): Int? {
        val kata = kata(jenis)
        val lain = kataLain(jenis)
        val calon = daftar.indices.filter { daftar[it].bisaDicentang && daftar[it].terlihat && daftar[it].aktif }
        if (calon.isEmpty()) return null
        val cocok = calon.filter { i ->
            val d = daftar[i]
            kata.any { d.konteks.contains(it) || d.idSumber.contains(it.replace("-", "").replace(" ", "")) }
        }
        if (cocok.isNotEmpty()) {
            // Pilih hanya kecocokan yang konteksnya tidak menyebut sakelar perangkat lain.
            // Jika seluruh kecocokan ambigu, jangan menekan sakelar secara spekulatif.
            val tepat = cocok.filter { i -> lain.none { daftar[i].konteks.contains(it) } }
            return tepat.singleOrNull() ?: tepat.firstOrNull()?.takeIf { tepat.size == 1 }
        }
        // Wi-Fi/Bluetooth pada halaman khusus biasanya hanya memiliki satu sakelar.
        // Fallback satu-sakelar tetap dibatasi untuk halaman yang tidak ambigu.
        val perluKecocokanEksplisit = jenis == "data_seluler" || jenis == "pesawat" || jenis == "nfc"
        return if (!perluKecocokanEksplisit && calon.size == 1 && jenis != "hotspot") calon.first() else null
    }

    /**
     * Hotspot: pada banyak ponsel halaman tethering hanya berisi baris "Wi-Fi hotspot" yang membuka halaman lain berisi sakelarnya.
     * Memilih baris itu (di dalam daftar, dapat diketuk, bukan sakelar, bukan Bluetooth/USB/Ethernet tethering).
     */
    fun pilihBarisHotspot(daftar: List<InfoBaris>): Int? {
        val tolak = listOf("bluetooth", "usb", "ethernet")
        val calon = daftar.indices.filter { i ->
            val d = daftar[i]
            !d.bisaDicentang && d.bisaDiklik && d.dalamDaftar && kataHotspot.any { d.label.contains(it) } && tolak.none { d.label.contains(it) }
        }
        if (calon.isEmpty()) return null
        return calon.firstOrNull { daftar[it].label.contains("wi-fi") || daftar[it].label.contains("wifi") } ?: calon.first()
    }
}
