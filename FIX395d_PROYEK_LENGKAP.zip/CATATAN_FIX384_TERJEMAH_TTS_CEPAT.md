# FIX384
Dugaan penyebab (belum terbukti di perangkat): (1) Pembicara terjemahan baru dibuat setelah ayat selesai sehingga inisialisasi TTS memakan waktu; (2) ekor gema ayat terakhir ditunggu penuh (ekorMaksMs MAX).
Perbaikan: Pembicara dibuat saat pemutaran dimulai; ekor 0 bila terjemahan TTS akan dibacakan.
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
