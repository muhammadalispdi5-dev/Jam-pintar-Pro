package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** FIX395: layanan latar (foreground) agar radio dan TV Islami tetap berbunyi saat layar padam atau terkunci. */
class SaluranService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == AKSI_HENTI) {
            PemutarSaluran.berhenti()
            stopForeground(true); stopSelf()
            return START_NOT_STICKY
        }
        val nama = intent?.getStringExtra("nama").orEmpty()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(SALURAN, BahasaAplikasi.teks(this, "Radio dan TV Islami"), NotificationManager.IMPORTANCE_LOW))
        val bukaIntent = PendingIntent.getActivity(this, 0, Intent(this, RadioTvActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val henti = PendingIntent.getService(this, 1, Intent(this, SaluranService::class.java).setAction(AKSI_HENTI), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, SALURAN) else @Suppress("DEPRECATION") Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(BahasaAplikasi.teks(this, "Radio dan TV Islami"))
            .setContentText(nama)
            .setContentIntent(bukaIntent).setOngoing(true)
            .addAction(Notification.Action.Builder(null, BahasaAplikasi.teks(this, "Hentikan"), henti).build())
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NOTIF_ID, b.build())
        return START_NOT_STICKY
    }

    companion object {
        private const val SALURAN = "saluran_radio_tv"
        private const val NOTIF_ID = 7392
        private const val AKSI_HENTI = "com.novan.bateraibicara.SALURAN_HENTI"

        fun mulai(c: Context, nama: String) {
            val i = Intent(c, SaluranService::class.java).putExtra("nama", nama)
            try { if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (_: Exception) { }
        }

        fun henti(c: Context) { try { c.stopService(Intent(c, SaluranService::class.java)) } catch (_: Exception) { } }
    }
}
