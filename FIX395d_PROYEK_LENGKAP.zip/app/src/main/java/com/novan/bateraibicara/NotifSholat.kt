package com.novan.bateraibicara

import android.content.Context
import java.time.LocalDate
import java.util.Locale

/**
 * FIX391: isi notifikasi waktu sholat: judul seperti "Dzuhur di 11.30 di (Kecamatan Tempel) bendera" dan teks berupa hadits
 * sahih yang relevan dengan waktu sholat itu. Hadits dipilih bergantian menurut hari. Terjemahan ringkas, bukan teks Arab.
 */
object NotifSholat {
    private class Hadits(val id: String, val en: String, val sumberId: String, val sumberEn: String)

    private val kumpulan: Map<String, List<Hadits>> = mapOf(
        "subuh" to listOf(
            Hadits("Barangsiapa shalat Subuh, maka ia berada dalam jaminan Allah.", "Whoever prays the Fajr prayer is under Allah's protection.", "HR. Muslim", "Narrated by Muslim"), // contains(
            Hadits("Dua rakaat sebelum Subuh lebih baik daripada dunia dan seisinya.", "The two rak'ahs before Fajr are better than the world and all it contains.", "HR. Muslim", "Narrated by Muslim"), // contains(
            Hadits("Barangsiapa shalat dua shalat dingin, yaitu Subuh dan Ashar, ia masuk surga.", "Whoever prays the two cool prayers, Fajr and Asr, will enter Paradise.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim")), // contains(
        "dzuhur" to listOf(
            Hadits("Amal apa yang paling dicintai Allah? Beliau menjawab: shalat pada waktunya.", "Which deed is most beloved to Allah? He said: the prayer at its proper time.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim"), // contains(
            Hadits("Apabila panas sangat terik, tundalah shalat hingga agak dingin, karena teriknya panas berasal dari hembusan neraka Jahanam.", "When the heat is severe, delay the prayer until it cools, for severe heat comes from the breath of Hell.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim")), // contains(
        "ashar" to listOf(
            Hadits("Barangsiapa meninggalkan shalat Ashar, maka terhapuslah amalnya.", "Whoever leaves the Asr prayer, his deeds are nullified.", "HR. Bukhari", "Narrated by Bukhari"), // contains(
            Hadits("Orang yang terlewat shalat Ashar seakan-akan kehilangan keluarga dan hartanya.", "The one who misses the Asr prayer is as if he lost his family and his wealth.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim"), // contains(
            Hadits("Barangsiapa shalat dua shalat dingin, yaitu Subuh dan Ashar, ia masuk surga.", "Whoever prays the two cool prayers, Fajr and Asr, will enter Paradise.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim")), // contains(
        "maghrib" to listOf(
            Hadits("Kami shalat Maghrib bersama Rasulullah saat matahari telah terbenam di balik tabir.", "We used to pray Maghrib with the Messenger of Allah once the sun had set behind the veil.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim"), // contains(
            Hadits("Umatku akan senantiasa dalam kebaikan selama mereka tidak menunda Maghrib sampai bintang-bintang bermunculan.", "My nation will remain upon good as long as they do not delay Maghrib until the stars appear.", "HR. Abu Dawud, dinilai sahih oleh Al-Albani", "Narrated by Abu Dawud, graded sahih by Al-Albani")), // contains(
        "isya" to listOf(
            Hadits("Shalat yang paling berat bagi orang munafik adalah Isya dan Subuh. Seandainya mereka tahu pahalanya, mereka akan mendatanginya walau dengan merangkak.", "The heaviest prayers for the hypocrites are Isha and Fajr. If they knew their reward, they would come even crawling.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim"), // contains(
            Hadits("Barangsiapa shalat Isya berjamaah, seakan-akan ia shalat setengah malam; barangsiapa shalat Subuh berjamaah, seakan-akan ia shalat semalam penuh.", "Whoever prays Isha in congregation is as if he prayed half the night; whoever prays Fajr in congregation is as if he prayed the whole night.", "HR. Muslim", "Narrated by Muslim")), // contains(
        "terbit" to listOf(
            Hadits("Janganlah kalian sengaja melakukan shalat ketika matahari terbit dan ketika matahari terbenam.", "Do not purposely pray at the time of sunrise or sunset.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim")), // contains(
        "dhuha" to listOf(
            Hadits("Setiap pagi setiap ruas tulang kalian wajib bersedekah, dan semua itu dapat dicukupi dengan dua rakaat shalat Dhuha.", "Every morning charity is due for every joint of your bodies, and two rak'ahs of Duha suffice for all of that.", "HR. Muslim", "Narrated by Muslim")), // contains(
        "tahajud" to listOf(
            Hadits("Shalat yang paling utama setelah shalat wajib adalah shalat malam.", "The best prayer after the obligatory prayers is the night prayer.", "HR. Muslim", "Narrated by Muslim")), // contains(
        "imsak" to listOf(
            Hadits("Makan sahurlah kalian, karena dalam sahur terdapat keberkahan.", "Eat suhoor, for in suhoor there is blessing.", "HR. Bukhari dan Muslim", "Narrated by Bukhari and Muslim")) // contains(
    )

    /** Hadits sahih untuk [key] pada [hari]; bergantian menurut nomor hari dalam tahun. Kosong bila tidak ada. */
    fun hadits(key: String, bahasaInggris: Boolean, hari: Int): String {
        val daftar = kumpulan[key] ?: return ""
        val h = daftar[Math.floorMod(hari, daftar.size)]
        return if (bahasaInggris) "“" + h.en + "” (" + h.sumberEn + ")" else "“" + h.id + "” (" + h.sumberId + ")"
    }

    /** Emoji bendera dari kode negara dua huruf (misalnya ID); kosong bila kode tidak valid. */
    fun bendera(kode: String?): String {
        val k = kode?.trim()?.uppercase(Locale.ROOT) ?: return ""
        if (k.length != 2 || k.any { it !in 'A'..'Z' }) return ""
        val sb = StringBuilder()
        for (c in k) sb.appendCodePoint(0x1F1E6 + (c - 'A'))
        return sb.toString()
    }

    private fun jamTitik(menit: Int): String = String.format(Locale.ROOT, "%02d.%02d", Math.floorMod(menit, 1440) / 60, Math.floorMod(menit, 1440) % 60)

    /** Contoh: "Dzuhur di 11.30 di (Kecamatan Tempel) bendera". Bagian lokasi dan bendera dihilangkan bila belum diketahui. */
    fun judul(c: Context, key: String, namaSholat: String, bahasaInggris: Boolean): String {
        val pp = PrayerPrefs(c.applicationContext)
        val menit = try { PrayerAlarm.prayerMinutes(c.applicationContext, pp, LocalDate.now(), key) } catch (_: Exception) { -1 }
        val sb = StringBuilder(namaSholat)
        if (menit >= 0) sb.append(if (bahasaInggris) " at " else " di ").append(jamTitik(menit))
        val tempat = if (pp.namaTempatTersimpan) pp.place.trim() else ""
        if (tempat.isNotBlank()) sb.append(if (bahasaInggris) " in (" else " di (").append(tempat).append(")")
        val flag = bendera(try { NegaraLokasi.tersimpanCepat(c) } catch (_: Exception) { null })
        if (flag.isNotEmpty()) sb.append(' ').append(flag)
        return sb.toString()
    }
}
