package com.novan.bateraibicara

/** FIX390: penafsir perintah suara untuk koleksi Qari MTQ dan Muammar ZA dari Google Drive (lihat MtqDriveActivity). */
object KoleksiMtq {
    private val kataKerja = setOf("putar", "putarkan", "putarin", "mainkan", "dengar", "dengarkan", "play", "listen", "bacakan", "perdengarkan")
    private val kataBuang = setOf("putar", "putarkan", "putarin", "mainkan", "dengar", "dengarkan", "play", "listen", "bacakan", "perdengarkan", "tolong", "dong",
        "qari", "qori", "bacaan", "tilawah", "tilawatil", "quran", "qur", "an", "dari", "oleh", "dengan", "yang", "the", "by", "of", "from", "koleksi", "mtq", "musabaqah",
        "muammar", "muamar", "za", "z", "a", "surah", "surat", "sura", "ayat", "saya", "aku", "untuk", "buka", "bukakan")

    private fun token(u: String) = u.lowercase().replace("\u2019", "").replace("'", "").replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    /** 0 = bukan perintah koleksi, 1 = MTQ, 2 = Muammar ZA. */
    fun jenis(ucapan: String): Int {
        val t = token(ucapan)
        if (t.isEmpty()) return 0
        val muammar = t.any { it == "muammar" || it == "muamar" } || t.joinToString("").contains("muammarza") || t.joinToString("").contains("muamarza")
        val mtq = t.any { it == "mtq" || it == "mtqnya" } || (t.contains("musabaqah") && t.contains("tilawatil"))
        if (!muammar && !mtq) return 0
        if (t.none { it in kataKerja || it == "koleksi" || it == "buka" || it == "bukakan" }) return 0
        // Sebutan fitur MTQ biasa (buka latihan MTQ) tetap dibuka sebagai fitur; hanya perintah memutar atau koleksi yang dimasuki di sini.
        if (mtq && !muammar && t.none { it in kataKerja || it == "koleksi" }) return 0
        return if (muammar) 2 else 1
    }

    /** Kata kunci judul berkas yang disebut pengguna (misalnya nama surah), tanpa kata perintah. */
    fun kataCari(ucapan: String): String = token(ucapan).filter { it !in kataBuang }.joinToString(" ")
}
