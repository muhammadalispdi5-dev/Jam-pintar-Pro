package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.PowerManager
import android.view.SurfaceHolder

/**
 * FIX395: pemutar tunggal untuk radio dan TV daring. Pemain hidup di objek ini (bukan di layar) dan ditopang SaluranService
 * sehingga siaran tetap berjalan saat layar padam atau terkunci. Gambar TV hanya dilepas dari pemain ketika layar dibuat ulang.
 */
object PemutarSaluran {
    private var mp: MediaPlayer? = null
    private var app: Context? = null
    private var holder: SurfaceHolder? = null
    var nama: String = ""
        private set
    var tv: Boolean = false
        private set
    var lebarVideo = 0
        private set
    var tinggiVideo = 0
        private set
    var saatUkuranBerubah: (() -> Unit)? = null

    fun sedangMain(): Boolean = try { mp?.isPlaying == true } catch (_: Exception) { false }
    fun adaPemain(): Boolean = mp != null

    fun putar(c: Context, s: RadioTvData.Saluran, status: (String) -> Unit) {
        berhenti()
        app = c.applicationContext
        nama = s.nama; tv = s.tv; lebarVideo = 0; tinggiVideo = 0
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(AudioAttributes.Builder().setContentType(if (s.tv) AudioAttributes.CONTENT_TYPE_MOVIE else AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setWakeMode(c.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            if (s.tv && holder != null) p.setDisplay(holder)
            p.setDataSource(s.url)
            p.setOnVideoSizeChangedListener { _, w, h -> if (mp === p) { lebarVideo = w; tinggiVideo = h; saatUkuranBerubah?.invoke() } }
            p.setOnPreparedListener { if (mp === p) { it.start(); try { NadaAudio.muat(c.applicationContext); NadaAudio.pasang(it.audioSessionId) } catch (_: Throwable) { }; status("start") } }
            p.setOnInfoListener { _, what, _ ->
                if (mp === p) { if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) status("memuat") else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) status("lanjut") }
                false
            }
            p.setOnErrorListener { _, _, _ -> if (mp === p) { berhenti(); status("gagal") }; true }
            p.setOnCompletionListener { if (mp === p) status("selesai") }
            p.prepareAsync()
            SaluranService.mulai(c.applicationContext, s.nama)
        } catch (_: Exception) { berhenti(); status("gagal") }
    }

    /** Dipanggil layar TV: pasang atau lepas permukaan gambar tanpa menghentikan suara. */
    fun aturLayar(h: SurfaceHolder?) {
        holder = h
        try { mp?.setDisplay(h) } catch (_: Exception) { }
    }

    fun jedaLanjut(): Boolean? {
        val p = mp ?: return null
        return try { if (p.isPlaying) { p.pause(); false } else { p.start(); true } } catch (_: Exception) { null }
    }

    fun senyap(b: Boolean) { try { mp?.setVolume(if (b) 0f else 1f, if (b) 0f else 1f) } catch (_: Exception) { } }

    fun berhenti() {
        val p = mp; mp = null
        try { p?.stop() } catch (_: Exception) { }
        try { NadaAudio.lepas() } catch (_: Throwable) { }
        try { p?.release() } catch (_: Exception) { }
        lebarVideo = 0; tinggiVideo = 0
        try { app?.let { SaluranService.henti(it) } } catch (_: Exception) { }
    }
}
