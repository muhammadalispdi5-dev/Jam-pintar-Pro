package com.novan.bateraibicara

import android.content.Context
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.io.StringReader
import java.util.Locale

/**
 * FIX395: berita seputar Islam dari sumber terpercaya. Sumber lokal dipilih menurut negara pengguna, sumber global berlaku
 * di semua negara. Sumber yang umum (bukan khusus Islam) disaring dengan kata kunci Islami. Daftar sumber dapat diganti
 * lewat berkas updates/sumber_berita.txt di repositori (format: KODE|Nama|URL|saring; KODE * = global; saring = ya atau tidak)
 * dan pengguna boleh menambah sumber sendiri. Alamat umpan RSS tidak diuji dari sini; sumber yang gagal dilewati.
 */
object BeritaData {
    class Sumber(val kode: String, val nama: String, val url: String, val saring: Boolean)
    class Berita(val judul: String, val tautan: String, val ringkas: String, val tanggal: Long, val sumber: String)

    private val bawaan = listOf(
        Sumber("ID", "Muhammadiyah", "https://muhammadiyah.or.id/feed/", false),
        Sumber("ID", "Antara", "https://www.antaranews.com/rss/terkini.xml", true),
        Sumber("ID", "Republika Khazanah", "https://www.republika.co.id/rss/khazanah", false),
        Sumber("SA", "Arab News", "https://www.arabnews.com/rss.xml", true),
        Sumber("*", "Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml", true),
        Sumber("*", "About Islam", "https://aboutislam.net/feed/", false),
        Sumber("*", "Anadolu Agency", "https://www.aa.com.tr/en/rss/default?cat=world", true)
    )

    private val kata = listOf("islam", "muslim", "quran", "qur'an", "koran", "hajj", "haji", "umrah", "umroh", "ramadan", "ramadhan", "zakat", "masjid", "mosque",
        "al-aqsa", "aqsa", "makkah", "mecca", "madinah", "medina", "kemenag", "ulama", "fatwa", "halal", "syariah", "sharia", "imam", "eid", "idul", "azan", "adhan", "hijri", "hijriah", "palestin", "gaza")

    fun adalahIslami(t: String): Boolean { val x = t.lowercase(Locale.ROOT); return kata.any { x.contains(it) } }

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("berita_islam", Context.MODE_PRIVATE)

    private fun ambil(alamat: String): String {
        val k = java.net.URL(alamat).openConnection() as java.net.HttpURLConnection
        k.connectTimeout = 10000; k.readTimeout = 12000
        k.setRequestProperty("User-Agent", "JamPintarPro")
        try { return k.inputStream.bufferedReader().use { it.readText() } } finally { k.disconnect() }
    }

    fun uraiDaftar(teks: String): List<Sumber> = teks.lines().mapNotNull { b ->
        val p = b.trim().split('|')
        if (b.startsWith("#") || p.size < 3 || !p[2].trim().startsWith("http")) null
        else Sumber(p[0].trim().uppercase(Locale.ROOT).ifEmpty { "*" }, p[1].trim(), p[2].trim(), p.getOrNull(3)?.trim()?.lowercase(Locale.ROOT) == "ya")
    }

    fun milikSendiri(c: Context): List<Sumber> = uraiDaftar(sp(c).getString("sendiri", "") ?: "")

    fun tambahSendiri(c: Context, nama: String, url: String): Boolean {
        val u = url.trim()
        if (nama.isBlank() || !(u.startsWith("http://") || u.startsWith("https://"))) return false
        val sisa = sp(c).getString("sendiri", "") ?: ""
        sp(c).edit().putString("sendiri", sisa + "*|" + nama.trim().replace("|", " ") + "|" + u + "|tidak\n").apply()
        return true
    }

    fun hapusSendiri(c: Context, s: Sumber) {
        val sisa = milikSendiri(c).filter { it.url != s.url }
        sp(c).edit().putString("sendiri", sisa.joinToString("") { "*|" + it.nama + "|" + it.url + "|" + (if (it.saring) "ya" else "tidak") + "\n" }).apply()
    }

    /** Sumber yang berlaku untuk [negara]: lokal negara itu dan global (daftar repositori bila ada, bila tidak bawaan), plus milik sendiri. */
    fun sumberUntuk(c: Context, negara: String): List<Sumber> {
        var dasar = bawaan
        try {
            val d = uraiDaftar(ambil("https://raw.githubusercontent.com/muhammadalispdi5-dev/Jam-pintar-Pro/main/updates/sumber_berita.txt"))
            if (d.isNotEmpty()) { dasar = d; sp(c).edit().putString("daftar_repo", d.joinToString("\n") { it.kode + "|" + it.nama + "|" + it.url + "|" + (if (it.saring) "ya" else "tidak") }).apply() }
        } catch (_: Exception) {
            val tersimpan = uraiDaftar(sp(c).getString("daftar_repo", "") ?: "")
            if (tersimpan.isNotEmpty()) dasar = tersimpan
        }
        val k = negara.uppercase(Locale.ROOT)
        return dasar.filter { it.kode == k || it.kode == "*" } + milikSendiri(c)
    }

    private fun tanggal(t: String): Long {
        if (t.isBlank()) return 0L
        for (f in listOf("EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz", "yyyy-MM-dd'T'HH:mm:ssX")) {
            try { return java.text.SimpleDateFormat(f, Locale.ENGLISH).parse(t.trim())?.time ?: 0L } catch (_: Exception) { }
        }
        return 0L
    }

    private fun bersih(h: String): String = android.text.Html.fromHtml(h, android.text.Html.FROM_HTML_MODE_LEGACY).toString().replace('￼', ' ').replace(Regex("\\s+"), " ").trim()

    fun uraiRss(xml: String, sumber: Sumber): List<Berita> {
        val hasil = ArrayList<Berita>()
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        var judul = ""; var link = ""; var isi = ""; var tgl = ""; var dalam = false
        var e = p.eventType
        while (e != XmlPullParser.END_DOCUMENT) {
            if (e == XmlPullParser.START_TAG) {
                val n = p.name.lowercase(Locale.ROOT)
                if (n == "item" || n == "entry") { dalam = true; judul = ""; link = ""; isi = ""; tgl = "" }
                else if (dalam) when (n) {
                    "title" -> judul = p.nextText()
                    "link" -> { val h = p.getAttributeValue(null, "href"); link = if (h != null) h else p.nextText() }
                    "description", "summary", "content" -> if (isi.isEmpty()) isi = p.nextText()
                    "pubdate", "published", "updated" -> if (tgl.isEmpty()) tgl = p.nextText()
                }
            } else if (e == XmlPullParser.END_TAG && dalam && (p.name.equals("item", true) || p.name.equals("entry", true))) {
                dalam = false
                val j = bersih(judul); val r = bersih(isi)
                if (j.isNotEmpty() && link.isNotBlank() && (!sumber.saring || adalahIslami(j + " " + r))) hasil.add(Berita(j, link.trim(), r.take(600), tanggal(tgl), sumber.nama))
            }
            e = p.next()
        }
        return hasil
    }

    /** Memblokir (jaringan): dari thread latar. Sumber yang gagal dilewati; melempar bila semuanya gagal. */
    fun muat(c: Context, negara: String): List<Berita> {
        val semua = ArrayList<Berita>()
        var ok = false
        for (s in sumberUntuk(c, negara)) {
            try { semua.addAll(uraiRss(ambil(s.url), s).take(25)); ok = true } catch (_: Exception) { }
        }
        if (!ok) throw java.io.IOException("berita")
        val hasil = semua.distinctBy { it.tautan }.sortedByDescending { it.tanggal }.take(120)
        sp(c).edit().putString("cache", hasil.joinToString("\n") { listOf(it.judul, it.tautan, it.ringkas, it.tanggal.toString(), it.sumber).joinToString("\t") { x -> x.replace("\t", " ").replace("\n", " ") } }).apply()
        return hasil
    }

    fun cadangan(c: Context): List<Berita> = (sp(c).getString("cache", "") ?: "").split('\n').mapNotNull {
        val p = it.split('\t'); if (p.size < 5) null else Berita(p[0], p[1], p[2], p[3].toLongOrNull() ?: 0L, p[4])
    }
}
