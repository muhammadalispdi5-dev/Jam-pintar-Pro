package com.novan.bateraibicara

import android.content.Context
import android.location.Geocoder
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * FIX378: kode negara (ISO 3166-1 alpha-2) dari lokasi sholat tersimpan, dipakai untuk hari libur, mata uang zakat, dan fitur lain
 * yang bergantung negara. Hasil disimpan per koordinat yang dibulatkan agar pencarian jaringan tidak berulang.
 */
object NegaraLokasi {
    private const val PREF = "negara_lokasi"

    private fun kunci(lat: Double, lon: Double) = "k_" + Math.round(lat * 10) + "_" + Math.round(lon * 10)

    /** Tanpa jaringan: hasil tersimpan, atau "ID" bila metode lokasi menunjuk Indonesia (perkiraan sampai pencarian selesai); null bila belum tahu. */
    fun tersimpanCepat(c: Context): String? {
        val pp = PrayerPrefs(c.applicationContext)
        if (!pp.locationSet) return null
        val simpan = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(kunci(pp.lat, pp.lon), null)
        if (!simpan.isNullOrBlank()) return simpan
        return if (PrayerCalc.rekomendasiMetode(pp.lat, pp.lon) == 0) "ID" else null
    }

    /** Memblokir (jaringan): panggil dari thread latar. */
    fun kode(c: Context): String? {
        val app = c.applicationContext
        val pp = PrayerPrefs(app)
        if (!pp.locationSet) return null
        val sp = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val k = kunci(pp.lat, pp.lon)
        sp.getString(k, null)?.takeIf { it.isNotBlank() }?.let { return it }
        var hasil: String? = null
        try {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION")
                hasil = Geocoder(app, Locale.US).getFromLocation(pp.lat, pp.lon, 1)?.firstOrNull()?.countryCode
            }
        } catch (_: Exception) { }
        if (hasil.isNullOrBlank()) {
            var con: HttpURLConnection? = null
            try {
                val u = "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=" + pp.lat + "&longitude=" + pp.lon + "&localityLanguage=en"
                con = (URL(u).openConnection() as HttpURLConnection).apply { connectTimeout = 6000; readTimeout = 8000; useCaches = false }
                if (con.responseCode in 200..299) hasil = JSONObject(con.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }).optString("countryCode")
            } catch (_: Exception) { } finally { try { con?.disconnect() } catch (_: Exception) { } }
        }
        val bersih = hasil?.trim()?.uppercase(Locale.ROOT)?.takeIf { it.length == 2 }
        if (bersih != null) sp.edit().putString(k, bersih).apply()
        return bersih ?: (if (PrayerCalc.rekomendasiMetode(pp.lat, pp.lon) == 0) "ID" else null)
    }

    /** Nama mata uang untuk diucapkan setelah angka; "mata uang setempat" bila negara belum diketahui. */
    fun mataUang(kode: String?, en: Boolean): String {
        val p = when (kode) {
            "ID" -> "rupiah" to "rupiah"; "MY" -> "ringgit" to "ringgit"; "SG" -> "dolar Singapura" to "Singapore dollars"
            "BN" -> "dolar Brunei" to "Brunei dollars"; "SA" -> "riyal Saudi" to "Saudi riyals"; "AE" -> "dirham" to "dirhams"
            "QA" -> "riyal Qatar" to "Qatari riyals"; "KW" -> "dinar Kuwait" to "Kuwaiti dinars"; "BH" -> "dinar Bahrain" to "Bahraini dinars"
            "OM" -> "riyal Oman" to "Omani rials"; "EG" -> "pound Mesir" to "Egyptian pounds"; "TR" -> "lira" to "lira"
            "PK" -> "rupee Pakistan" to "Pakistani rupees"; "IN" -> "rupee India" to "Indian rupees"; "BD" -> "taka" to "taka"
            "US" -> "dolar Amerika" to "US dollars"; "CA" -> "dolar Kanada" to "Canadian dollars"; "AU" -> "dolar Australia" to "Australian dollars"
            "GB" -> "pound sterling" to "pounds sterling"; "JP" -> "yen" to "yen"; "TH" -> "baht" to "baht"; "PH" -> "peso" to "pesos"
            "NL", "DE", "FR", "IT", "ES", "BE", "AT", "IE", "PT", "FI", "GR" -> "euro" to "euros"
            else -> "mata uang setempat" to "local currency"
        }
        return if (en) p.second else p.first
    }
}
