package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.Intent
import android.text.InputType

/**
 * FIX376: Latihan Musabaqah Tilawatil Qur'an (MTQ): pengenalan lagu/maqam, kriteria penilaian, cabang lomba, dan pemutaran
 * contoh bacaan mujawwad lewat perintah putar yang sudah ada. Isinya edukasi umum; aplikasi tidak menilai suara pengguna
 * dan tidak menandai maqam yang dipakai pada tiap rekaman.
 */
class MtqActivity : Halaman() {
    override val judulHalaman = R.string.judul_mtq
    private var surah = "Al Fatihah"
    private var ulang = "1"

    private class Maqam(val nama: String, val ciri: String)

    private fun daftarMaqam() = listOf(
        Maqam("Bayati", tr("Lagu dasar yang lembut dan tenang; biasa dipakai membuka bacaan.", "The basic, gentle and calm mode; commonly used to open a recitation.")),
        Maqam("Shoba", tr("Bernuansa haru dan syahdu; sering dipakai untuk ayat tentang kesedihan atau peringatan.", "Moving and tender in feeling; often used for verses of sorrow or warning.")),
        Maqam("Hijaz", tr("Bernuansa dramatis dan mendalam; sering dipakai pada bagian puncak bacaan.", "Dramatic and deep in feeling; often used at the climax of a recitation.")),
        Maqam("Nahawand", tr("Lembut dan mengalir, terasa teduh; cocok untuk ayat yang menenangkan.", "Soft and flowing, calming; suited to reassuring verses.")),
        Maqam("Rast", tr("Tegas, cerah, dan berwibawa; sering dipakai untuk ayat tentang kebesaran Allah.", "Firm, bright and dignified; often used for verses on God\'s greatness.")),
        Maqam("Jiharkah", tr("Ringan dan cerah; sering dipakai sebagai lagu penutup yang tenang.", "Light and bright; often used as a calm closing mode.")),
        Maqam("Sika", tr("Khusyuk dan lembut dengan nada yang khas; dipakai untuk variasi dan penutup.", "Devout and tender with a distinctive tone; used for variation and closing."))
    )

    private var tetap = 0
    private val surahPopuler = listOf("Al Fatihah" to 1, "Al Baqarah" to 2, "Ali Imran" to 3, "An Nisa" to 4, "Yusuf" to 12, "Al Isra" to 17, "Al Kahfi" to 18,
        "Maryam" to 19, "Thaha" to 20, "Al Anbiya" to 21, "Al Ahzab" to 33, "Yasin" to 36, "Ar Rahman" to 55, "Al Waqiah" to 56, "Al Mulk" to 67,
        "Al Insan" to 76, "An Naba" to 78, "Ad Dhuha" to 93)

    override fun bangun() {
        tetap = root.childCount
        render()
    }

    private fun render() {
        while (root.childCount > tetap) root.removeViewAt(tetap)
        info(tr("Latihan Musabaqah Tilawatil Qur\'an (MTQ). Aplikasi ini hanya memberi pengenalan dan contoh bacaan; aplikasi tidak menilai suara Anda. Cara terbaik berlatih adalah bersama guru atau pelatih MTQ.",
            "Qur\'an recitation competition (MTQ) practice. This app only gives an introduction and sample recitations; it does not score your voice. The best way to practise is with an MTQ teacher or coach."))
        bagian(tr("Contoh bacaan mujawwad", "Mujawwad sample recitations"))
        info(tr("Mujawwad adalah gaya bacaan yang lebih panjang dan berlagu, sering dijadikan contoh dalam latihan MTQ. Tentukan surah, lalu pilih qari. Aplikasi memutar rekamannya bila qari itu tersedia; pemutarannya memerlukan internet.",
            "Mujawwad is a slower, more melodic recitation style often used as a model in MTQ practice. Choose a surah, then a reciter. The app plays the recording if that reciter is available; playback needs the internet."))
        isian(tr("Surah (misalnya Al Fatihah)", "Surah (for example Al Fatihah)"), surah, InputType.TYPE_CLASS_TEXT) { surah = it }
        isian(tr("Jumlah pengulangan (1 sampai 20)", "Repeat count (1 to 20)"), ulang, InputType.TYPE_CLASS_NUMBER) { ulang = it }
        // FIX379: qari dipilih langsung lewat id (bukan pencarian nama) agar yang diputar pasti rekaman mujawwad.
        for ((nama, id) in listOf("Abdul Basit Abdus Samad" to "ar.abdulsamad", "Mahmoud Khalil Al-Husary" to "ar.husarymujawwad", "Mohamed Siddiq Al-Minshawi" to "ar.minshawimujawwad")) {
            tombol(tr("Putar mujawwad: ", "Play mujawwad: ") + nama) { putarDenganQari(id, nama + " · mujawwad") }
        }
        tombol(tr("Putar qari Muammar ZA", "Play reciter Muammar ZA")) { putarMuammar() }
        tombol(tr("Koleksi Qari MTQ dan Muammar ZA dari Google Drive", "MTQ reciters and Muammar ZA collections from Google Drive")) { startActivity(Intent(this, MtqDriveActivity::class.java)) }
        pilihan(tr("Surah populer dalam tilawah MTQ", "Popular surahs in MTQ tilawah"), surahPopuler.map { it.second.toString() + ". " + it.first }, surahPopuler.indexOfFirst { it.first.equals(surah, ignoreCase = true) }) {
            surah = surahPopuler[it].first; render()
        }
        val ada = QariTambahan.semua(this)
        if (ada.isNotEmpty()) {
            bagian(tr("Qari MTQ Anda", "Your MTQ reciters"))
            info(tr("Qari tambahan yang Anda masukkan. Qari MTQ tidak harus memuat 30 juz; cukup surah yang tersedia.", "Additional reciters you added. MTQ reciters do not need all 30 juz; the available surahs are enough."))
            for (q in ada) tombol(tr("Putar ", "Play ") + q.nama + tr(" · surah ", " · surahs ") + (if (q.surah.isBlank()) tr("lengkap", "all") else q.surah)) { putarQariTambahan(q) }
        }
        tombol(tr("Tambah qari MTQ (sumber audio sendiri)", "Add an MTQ reciter (own audio source)")) { startActivity(Intent(this, QariTambahanActivity::class.java)) }
        bagian(tr("Maqam atau lagu dalam MTQ", "Maqamat (tunes) in MTQ"))
        info(tr("Tujuh lagu yang lazim dipelajari dalam tilawah MTQ. Penjelasan ini bersifat umum dan dapat berbeda antar guru.",
            "Seven tunes commonly studied in MTQ tilawah. These notes are general and may differ between teachers."))
        for (m in daftarMaqam()) info(m.nama + ": " + m.ciri)
        bagian(tr("Kriteria penilaian yang lazim", "Common judging criteria"))
        info(tr("1. Tajwid dan makharijul huruf: ketepatan hukum bacaan dan pengucapan huruf. 2. Fashahah: kelancaran, ketepatan waqaf dan ibtida. 3. Suara: volume, kejernihan, napas, dan jangkauan nada. 4. Lagu: ketepatan maqam, variasi, dan perpindahan antar lagu. 5. Adab: sikap dan kekhusyukan. Bobot dan aturan berbeda menurut penyelenggara.",
            "1. Tajwid and articulation points: correct rules and letter pronunciation. 2. Fluency: smoothness and correct stops and starts. 3. Voice: volume, clarity, breath and range. 4. Tune: correct maqam, variation and transitions. 5. Manners: bearing and devotion. Weights and rules differ by organizer."))
        bagian(tr("Cabang lomba yang umum", "Common competition branches"))
        info(tr("Tilawah (anak-anak, remaja, dewasa), tahfizh (hafalan, dari 1 juz sampai 30 juz), tafsir, fahmil dan syarhil Qur\'an, khattil Qur\'an (kaligrafi), dan karya tulis ilmiah. Nama cabang dan golongan dapat berbeda antara penyelenggara.",
            "Tilawah (children, youth, adults), tahfizh (memorization, from 1 to 30 juz), tafsir, quiz and speech branches, calligraphy, and scientific writing. Branch and category names can differ between organizers."))
        bagian(tr("Tips latihan", "Practice tips"))
        info(tr("Mulailah dari tajwid dan makharij yang benar sebelum lagu. Dengarkan satu ayat berulang, tirukan pelan, lalu rekam diri sendiri dengan perekam di ponsel untuk dibandingkan. Perluas lagu satu per satu, dan jaga napas serta kesehatan suara.",
            "Start with correct tajwid and articulation before the tune. Listen to one verse repeatedly, imitate it slowly, then record yourself with your phone to compare. Add tunes one at a time and look after your breath and voice."))
    }

    /** Memutar surah yang dipilih dengan qari tambahan; bila surah itu tidak ada pada qari, tampilkan surah yang tersedia. */
    private fun putarQariTambahan(q: QariTambahan.Item) {
        val nomor = surahPopuler.firstOrNull { it.first.equals(surah.trim(), ignoreCase = true) }?.second
            ?: surah.trim().toIntOrNull()
            ?: try { PenafsirQuran.nomorSurahDariNama(surah.lowercase(java.util.Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.isNotBlank() }) } catch (_: Exception) { null }
        if (nomor == null) { toast(tr("Nama surah tidak dikenali.", "The surah name was not recognized.")); return }
        val tersedia = q.daftarSurah()
        if (nomor !in tersedia) {
            toast(tr("Surah itu belum ada pada qari ini. Surah yang tersedia: ", "That surah is not available for this reciter. Available surahs: ") + tersedia.joinToString(", "))
            return
        }
        val id = "mp3quran|" + q.server + "|" + tersedia.joinToString(",")
        getSharedPreferences("khatam_quran", MODE_PRIVATE).edit().putString("qari_audio_id", id).putString("qari_audio_nama", "Tambahan · " + q.nama).commit()
        val n = (ulang.trim().toIntOrNull() ?: 1).coerceIn(1, 20)
        val perintah = "putar surah " + nomor + (if (n > 1) " " + n + " kali" else "") // contains(
        try { PemutarQuranService.kirim(this, PemutarQuranService.ACTION_PUTAR, listOf(perintah)) } catch (_: Exception) { toast(tr("Pemutar tidak dapat dimulai.", "The player could not start.")) }
        toast(tr("Memutar dengan qari ", "Playing with reciter ") + q.nama)
    }

    private fun putarDenganQari(id: String, nama: String) {
        val n = (ulang.trim().toIntOrNull() ?: 1).coerceIn(1, 20)
        getSharedPreferences("khatam_quran", MODE_PRIVATE).edit().putString("qari_audio_id", id).putString("qari_audio_nama", nama).commit()
        val perintah = "putar surah " + surah.trim().ifBlank { "Al Fatihah" } + (if (n > 1) " " + n + " kali" else "") // contains(
        try { PemutarQuranService.kirim(this, PemutarQuranService.ACTION_PUTAR, listOf(perintah)) } catch (_: Exception) { toast(tr("Pemutar tidak dapat dimulai.", "The player could not start.")) }
        toast(tr("Memutar dengan qari ", "Playing with reciter ") + nama)
    }

    private val polaMuammar = Regex("m[uo]['\u2019]?a?mm?[ae]r", RegexOption.IGNORE_CASE)

    /** Muammar ZA: dari qari tambahan buatan pengguna, bila tidak ada dicari di katalog online; bila tetap tidak ada, pengguna diarahkan menambahkan sumbernya. */
    private fun putarMuammar() {
        val sendiri = QariTambahan.daftar(this).firstOrNull { polaMuammar.containsMatchIn(it.second) }
        if (sendiri != null) { putarQariTambahan(QariTambahan.semua(this).first { polaMuammar.containsMatchIn(it.nama) }); return }
        toast(tr("Mencari Muammar ZA di katalog online.", "Searching for Muammar ZA in the online catalogue."))
        val aktif = getSharedPreferences("khatam_quran", MODE_PRIVATE).getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        Thread {
            val hasil = try { QariSuara.cariOnline(this, "muammar", aktif) } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (hasil != null && polaMuammar.containsMatchIn(hasil.second)) putarDenganQari(hasil.first, hasil.second)
                else AlertDialog.Builder(this)
                    .setTitle(tr("Muammar ZA belum tersedia", "Muammar ZA is not available yet"))
                    .setMessage(tr("Muammar ZA tidak ditemukan di katalog online atau internet belum tersedia. Anda dapat menambahkan sumber audio Anda sendiri (folder HTTPS berisi 001.mp3 sampai 114.mp3) di Qari tambahan; setelah itu tombol ini akan memutarnya.",
                        "Muammar ZA was not found in the online catalogue, or the internet is unavailable. You can add your own audio source (an HTTPS folder with 001.mp3 to 114.mp3) under Additional reciters; after that this button will play it."))
                    .setPositiveButton(tr("Buka Qari tambahan", "Open Additional reciters")) { _, _ -> startActivity(Intent(this, QariTambahanActivity::class.java)) }
                    .setNegativeButton(tr("Tutup", "Close"), null).show()
            }
        }.start()
    }
}
