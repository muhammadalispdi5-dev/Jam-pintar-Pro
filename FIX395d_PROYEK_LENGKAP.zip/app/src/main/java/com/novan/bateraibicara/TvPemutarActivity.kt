package com.novan.bateraibicara

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * FIX394: pemutar TV Islami dengan tampilan layar penuh dan kontrol yang ramah TalkBack.
 * Tanpa TalkBack, siaran langsung dibuka mendatar layar penuh. Dengan TalkBack aktif, siaran dibuka tegak 16:9 agar layar tidak
 * berputar tiba-tiba, dan pengguna dapat masuk layar penuh lewat tombol. Status siaran diumumkan lewat wilayah langsung (live region).
 */
class TvPemutarActivity : Halaman() {
    override val judulHalaman = R.string.judul_radio_tv
    private var permukaan: SurfaceView? = null
    private var status: TextView? = null
    private var bingkai: FrameLayout? = null
    private var tombolPenuh: Button? = null
    private var judulView: View? = null
    private var penuh = false
    private var senyap = false
    private var fokusAudio: AudioManager.OnAudioFocusChangeListener? = null

    private fun talkBackAktif(): Boolean = try {
        (getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager).isTouchExplorationEnabled
    } catch (_: Exception) { false }

    override fun bangun() {
        val nama = intent.getStringExtra("nama").orEmpty()
        val url = intent.getStringExtra("url").orEmpty()
        val idx = root.childCount
        bagian(nama)
        judulView = root.getChildAt(idx)
        status = info(tr("Memuat siaran…", "Loading the broadcast…")).also { it.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        bingkai = frame
        val sv = SurfaceView(this)
        permukaan = sv
        sv.contentDescription = tr("Layar siaran TV: ", "TV broadcast screen: ") + nama
        sv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        frame.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        frame.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> sesuaikanUkuran() }
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { PemutarSaluran.aturLayar(h) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { }
            override fun surfaceDestroyed(h: SurfaceHolder) { PemutarSaluran.aturLayar(null) }
        })
        PemutarSaluran.saatUkuranBerubah = { runOnUiThread { sesuaikanUkuran() } }
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, tinggiVideo()))

        val baris = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun kontrol(teks: String, deskripsi: String, aksi: () -> Unit): Button = Button(this).apply {
            text = teks; contentDescription = deskripsi; textSize = 14f; minHeight = dp(56); minimumHeight = dp(56)
            setOnClickListener { aksi() }
            baris.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        kontrol(tr("Jeda", "Pause"), tr("Jeda atau lanjutkan siaran", "Pause or resume the broadcast")) {
            val r = PemutarSaluran.jedaLanjut()
            setStatus(if (r == null) tr("Belum ada siaran yang diputar.", "No broadcast is playing.") else if (r) tr("Dilanjutkan.", "Resumed.") else tr("Dijeda.", "Paused."))
        }
        kontrol(tr("Vol -", "Vol -"), tr("Turunkan volume", "Volume down")) { ubahVolume(-1) }
        kontrol(tr("Vol +", "Vol +"), tr("Naikkan volume", "Volume up")) { ubahVolume(1) }
        kontrol(tr("Senyap", "Mute"), tr("Senyapkan atau bunyikan suara", "Mute or unmute the sound")) { senyap = !senyap; terapkanSenyap(); setStatus(if (senyap) tr("Suara disenyapkan.", "Sound muted.") else tr("Suara dibunyikan.", "Sound on.")) }
        root.addView(baris, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        tombolPenuh = tombol(tr("Layar penuh", "Full screen")) { aturPenuh(!penuh) }
        saklar(tr("Tetap aktifkan layar saat menonton TV", "Keep the screen on while watching TV"), prefs.tvLayarNyala) {
            prefs.tvLayarNyala = it; terapkanLayarNyala()
            setStatus(if (it) tr("Layar akan terus menyala selama menonton.", "The screen will stay on while watching.") else tr("Layar boleh padam atau terkunci; siaran tetap berjalan.", "The screen may turn off or lock; the broadcast keeps playing."))
        }
        bagianNadaAudio()
        tombol(tr("Berhenti dan kembali", "Stop and go back")) { PemutarSaluran.berhenti(); finish() }

        mintaFokusAudio()
        terapkanLayarNyala()
        val saluran = RadioTvData.Saluran(nama, url, "", true)
        if (PemutarSaluran.adaPemain() && PemutarSaluran.nama == nama && PemutarSaluran.tv) {
            setStatus(tr("Siaran sedang berjalan: ", "The broadcast is playing: ") + nama)
        } else {
            PemutarSaluran.putar(this, saluran) { h ->
                setStatus(when (h) {
                    "start" -> tr("Memutar: ", "Playing: ") + nama
                    "memuat" -> tr("Memuat, mohon tunggu…", "Buffering, please wait…")
                    "lanjut" -> tr("Siaran berlanjut.", "The broadcast continues.")
                    "gagal" -> tr("Siaran tidak dapat diputar. Saluran mungkin sedang tidak tersedia. Coba saluran lain.", "The broadcast could not be played. The channel may be unavailable. Try another channel.")
                    else -> tr("Siaran berakhir.", "The broadcast ended.")
                })
            }
        }
        // Tanpa TalkBack: langsung layar penuh mendatar. Dengan TalkBack: tegak, masuk layar penuh lewat tombol.
        if (!talkBackAktif()) aturPenuh(true)
    }

    private fun tinggiVideo(): Int {
        val dm = resources.displayMetrics
        return if (penuh) (dm.heightPixels - dp(150)).coerceAtLeast(dp(200)) else (dm.widthPixels * 9 / 16).coerceAtLeast(dp(180))
    }

    @Suppress("DEPRECATION")
    private fun aturPenuh(p: Boolean) {
        penuh = p
        requestedOrientation = if (p) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.decorView.systemUiVisibility = if (p) (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else View.SYSTEM_UI_FLAG_VISIBLE
        judulView?.visibility = if (p) View.GONE else View.VISIBLE
        tombolPenuh?.text = if (p) tr("Keluar layar penuh", "Exit full screen") else tr("Layar penuh", "Full screen")
        bingkai?.layoutParams = (bingkai?.layoutParams as LinearLayout.LayoutParams).also { it.height = tinggiVideo() }
        setStatus(if (p) tr("Layar penuh. Tombol kontrol ada di bawah layar.", "Full screen. The control buttons are below the screen.") else tr("Keluar dari layar penuh.", "Left full screen."))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bingkai?.layoutParams = (bingkai?.layoutParams as? LinearLayout.LayoutParams)?.also { it.height = tinggiVideo() }
    }

    private fun ubahVolume(arah: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (arah > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        val maks = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        setStatus(tr("Volume ", "Volume ") + (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maks) + tr(" persen", " percent"))
    }

    private fun terapkanSenyap() { PemutarSaluran.senyap(senyap) }

    /** Saklar: layar tetap menyala selama menonton; bila mati, layar boleh padam dan siaran tetap berjalan lewat layanan latar. */
    private fun terapkanLayarNyala() {
        if (prefs.tvLayarNyala) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        bingkai?.keepScreenOn = prefs.tvLayarNyala
    }

    /** Ukuran gambar menurut rasio video, dipusatkan di bingkai hitam. */
    private fun sesuaikanUkuran() {
        val f = bingkai ?: return; val sv = permukaan ?: return
        val w = PemutarSaluran.lebarVideo; val h = PemutarSaluran.tinggiVideo
        if (w <= 0 || h <= 0 || f.width <= 0 || f.height <= 0) return
        val skala = minOf(f.width.toFloat() / w, f.height.toFloat() / h)
        val lp = FrameLayout.LayoutParams((w * skala).toInt(), (h * skala).toInt(), Gravity.CENTER)
        sv.layoutParams = lp
    }

    private fun mintaFokusAudio() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val l = AudioManager.OnAudioFocusChangeListener { }
        fokusAudio = l
        @Suppress("DEPRECATION") am.requestAudioFocus(l, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
    }

    private fun setStatus(t: String) { runOnUiThread { status?.text = t } }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        // Hanya bila pengguna benar-benar keluar dari halaman; layar padam atau terkunci tidak menghancurkan halaman.
        if (isFinishing) PemutarSaluran.berhenti()
        PemutarSaluran.saatUkuranBerubah = null
        PemutarSaluran.aturLayar(null)
        try { fokusAudio?.let { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocus(it) } } catch (_: Exception) { }
        super.onDestroy()
    }
}
