package com.novan.bateraibicara

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX389: koleksi bacaan Qari MTQ dan Muammar ZA yang disimpan di folder Google Drive pengguna.
 * Berkas TIDAK dimasukkan ke aplikasi (ukuran 5 MB atau lebih per berkas). Daftar berkas dibaca dari tampilan folder umum
 * Drive, lalu audio diputar langsung (streaming) atau, bila gagal, diunduh ke cache dahulu. Folder harus dibagikan
 * "Siapa saja yang memiliki link". Format halaman Drive belum terbukti di perangkat; bila daftar kosong, aplikasi menjelaskannya.
 */
class MtqDriveActivity : Halaman() {
    override val judulHalaman = R.string.judul_mtq

    private class Butir(val id: String, val judul: String, val folder: Boolean)

    private var status: TextView? = null
    private var pemutar: MediaPlayer? = null
    private var sedangDijeda = false
    private var idFolder = ""
    private var namaFolder = ""
    private var ambilDaftarKe = 0
    private var cariOtomatis = ""
    private var ambilDaftarSelesai = false
    private var sudahOtomatis = false

    override fun bangun() {
        idFolder = intent.getStringExtra("folder").orEmpty()
        namaFolder = intent.getStringExtra("nama").orEmpty()
        cariOtomatis = intent.getStringExtra("cari").orEmpty()
        if (idFolder.isBlank()) { menuAwal(); return }
        bagian(namaFolder)
        status = info(tr("Memuat daftar…", "Loading the list…"))
        tombol(tr("Jeda atau lanjutkan", "Pause or resume")) { jedaLanjut() }
        tombol(tr("Berhenti", "Stop")) { berhenti(); setStatus(tr("Dihentikan.", "Stopped.")) }
        tombol(tr("Muat ulang daftar", "Reload the list")) { ambilDaftar(idFolder) }
        val simpanan = daftarTersimpan(idFolder)
        if (simpanan.isNotEmpty()) tampilkan(simpanan)
        ambilDaftar(idFolder)
    }

    private fun menuAwal() {
        info(tr("Koleksi bacaan Qari MTQ dan Muammar ZA dari Google Drive. Berkas tidak disimpan di dalam aplikasi sehingga ukuran aplikasi tetap kecil; audio diputar lewat internet. Pemutaran pertama dapat membutuhkan beberapa detik.",
            "Collections of MTQ reciters and Muammar ZA from Google Drive. The files are not stored inside the app, so the app stays small; the audio is played over the internet. The first playback may take a few seconds."))
        tombol(tr("Koleksi Qari MTQ", "MTQ reciters collection")) { bukaFolder(ID_MTQ, "Qari MTQ") }
        tombol(tr("Koleksi Muammar ZA", "Muammar ZA collection")) { bukaFolder(ID_MUAMMAR, "Muammar ZA") }
    }

    private fun bukaFolder(id: String, nama: String) {
        startActivity(android.content.Intent(this, MtqDriveActivity::class.java).putExtra("folder", id).putExtra("nama", nama))
    }

    private fun setStatus(t: String) { runOnUiThread { status?.text = t; status?.announceForAccessibility(t) } }

    // ---------- Daftar ----------
    private fun prefsDaftar() = getSharedPreferences("mtq_drive", MODE_PRIVATE)

    private fun daftarTersimpan(id: String): List<Butir> =
        (prefsDaftar().getString("daftar_" + id, "") ?: "").split('\n').mapNotNull {
            val p = it.split('\t'); if (p.size == 3) Butir(p[0], p[1], p[2] == "d") else null
        }

    private fun ambilDaftar(id: String) {
        val nomor = ++ambilDaftarKe
        Thread {
            val hasil = try { urai(unduhTeks("https://drive.google.com/embeddedfolderview?id=" + id)) } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || nomor != ambilDaftarKe) return@runOnUiThread
                if (hasil == null) setStatus(tr("Daftar tidak dapat dimuat. Periksa internet. Daftar tersimpan terakhir ditampilkan bila ada.", "The list could not be loaded. Check the internet. The last saved list is shown if there is one."))
                else if (hasil.isEmpty()) setStatus(tr("Folder tampak kosong atau belum dibagikan ke \"Siapa saja yang memiliki link\".", "The folder looks empty or is not shared with \"Anyone with the link\"."))
                else {
                    prefsDaftar().edit().putString("daftar_" + id, hasil.joinToString("\n") { it.id + "\t" + it.judul.replace('\t', ' ').replace('\n', ' ') + "\t" + (if (it.folder) "d" else "f") }).apply()
                    setStatus(tr("Daftar dimuat: ", "List loaded: ") + hasil.size)
                    ambilDaftarSelesai = true
                    tampilkan(hasil)
                }
            }
        }.start()
    }

    private var tetapDaftar = -1
    private fun tampilkan(daftar: List<Butir>) {
        if (!sudahOtomatis && cariOtomatis.isNotBlank()) {
            // FIX390: perintah suara menyebut judul (misalnya nama surah): putar berkas dengan kata kunci terbanyak yang cocok.
            val kata = cariOtomatis.lowercase().split(' ').filter { it.isNotBlank() }
            val terbaik = daftar.filter { !it.folder }.map { b -> b to kata.count { k -> b.judul.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").contains(k) } }.filter { it.second > 0 }.maxByOrNull { it.second }
            if (terbaik != null) { sudahOtomatis = true; putar(terbaik.first) }
            else if (ambilDaftarSelesai) { sudahOtomatis = true; setStatus(tr("Tidak ada berkas yang cocok dengan: ", "No file matches: ") + cariOtomatis) }
        }
        if (tetapDaftar < 0) tetapDaftar = root.childCount
        while (root.childCount > tetapDaftar) root.removeViewAt(tetapDaftar)
        for (b in daftar) {
            if (b.folder) tombol(tr("Folder: ", "Folder: ") + ui(b.judul)) { bukaFolder(b.id, b.judul) }
            else tombol(tr("Putar: ", "Play: ") + ui(b.judul)) { putar(b) }
        }
    }

    private fun unduhTeks(alamat: String): String {
        val k = URL(alamat).openConnection() as HttpURLConnection
        k.connectTimeout = 15000; k.readTimeout = 20000
        k.setRequestProperty("User-Agent", "Mozilla/5.0")
        return k.inputStream.bufferedReader().use { it.readText() }
    }

    private fun urai(html: String): List<Butir> {
        val idRe = Regex("id=\"entry-([A-Za-z0-9_-]{10,})\"")
        val ms = idRe.findAll(html).toList()
        val hasil = ArrayList<Butir>()
        for ((i, m) in ms.withIndex()) {
            val akhir = if (i + 1 < ms.size) ms[i + 1].range.first else html.length
            val seg = html.substring(m.range.first, akhir)
            val judul = Regex("flip-entry-title\">([^<]*)<").find(seg)?.groupValues?.get(1)?.let { dekode(it) }?.trim().orEmpty()
            if (judul.isBlank()) continue
            hasil.add(Butir(m.groupValues[1], judul, seg.contains("/folders/")))
        }
        return hasil.distinctBy { it.id }
    }

    private fun dekode(s: String) = s.replace("&amp;", "&").replace("&#39;", "'").replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">")

    // ---------- Pemutaran ----------
    private fun alamatUnduh(id: String) = "https://drive.usercontent.google.com/download?id=" + id + "&export=download&confirm=t"

    private fun putar(b: Butir) {
        berhenti()
        setStatus(tr("Memuat: ", "Loading: ") + b.judul)
        val berkas = File(cacheDir, "mtq_drive_" + b.id + ".audio")
        if (berkas.exists() && berkas.length() > 10_000) { mulaiLokal(berkas, b); return }
        val mp = MediaPlayer()
        pemutar = mp
        try {
            mp.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            mp.setDataSource(alamatUnduh(b.id))
            mp.setOnPreparedListener { if (pemutar === mp) { it.start(); setStatus(tr("Diputar: ", "Playing: ") + b.judul) } }
            mp.setOnCompletionListener { if (pemutar === mp) setStatus(tr("Selesai: ", "Finished: ") + b.judul) }
            mp.setOnErrorListener { _, _, _ ->
                if (pemutar === mp) { try { mp.release() } catch (_: Exception) { }; pemutar = null; unduhLalu(b, berkas) }
                true
            }
            mp.prepareAsync()
        } catch (_: Exception) { try { mp.release() } catch (_: Exception) { }; pemutar = null; unduhLalu(b, berkas) }
    }

    private fun unduhLalu(b: Butir, berkas: File) {
        setStatus(tr("Streaming gagal, mengunduh dahulu: ", "Streaming failed, downloading first: ") + b.judul)
        Thread {
            var ok = false
            try {
                var alamat = alamatUnduh(b.id)
                var k: HttpURLConnection
                var lompat = 0
                while (true) {
                    k = URL(alamat).openConnection() as HttpURLConnection
                    k.instanceFollowRedirects = false; k.connectTimeout = 15000; k.readTimeout = 30000
                    k.setRequestProperty("User-Agent", "Mozilla/5.0")
                    val kode = k.responseCode
                    if (kode in 300..399 && lompat++ < 5) { alamat = k.getHeaderField("Location") ?: break; k.disconnect(); continue }
                    break
                }
                if (k.responseCode == 200 && !(k.contentType ?: "").startsWith("text/")) {
                    val tmp = File(cacheDir, "mtq_drive_" + b.id + ".tmp")
                    k.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    ok = tmp.length() > 10_000 && tmp.renameTo(berkas)
                }
            } catch (_: Exception) { }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (ok) mulaiLokal(berkas, b)
                else setStatus(tr("Berkas tidak dapat diputar. Pastikan berkas dibagikan ke \"Siapa saja yang memiliki link\" dan internet tersedia.", "The file could not be played. Make sure it is shared with \"Anyone with the link\" and the internet is available."))
            }
        }.start()
    }

    private fun mulaiLokal(berkas: File, b: Butir) {
        berhenti()
        val mp = MediaPlayer()
        pemutar = mp
        try {
            mp.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            mp.setDataSource(berkas.absolutePath)
            mp.setOnCompletionListener { if (pemutar === mp) setStatus(tr("Selesai: ", "Finished: ") + b.judul) }
            mp.setOnErrorListener { _, _, _ -> berkas.delete(); setStatus(tr("Berkas rusak atau bukan audio.", "The file is damaged or not audio.")); true }
            mp.prepare(); mp.start()
            setStatus(tr("Diputar: ", "Playing: ") + b.judul)
        } catch (_: Exception) { berkas.delete(); setStatus(tr("Berkas rusak atau bukan audio.", "The file is damaged or not audio.")) }
    }

    private fun jedaLanjut() {
        val p = pemutar ?: return
        try { if (p.isPlaying) { p.pause(); sedangDijeda = true; setStatus(tr("Dijeda.", "Paused.")) } else { p.start(); sedangDijeda = false; setStatus(tr("Dilanjutkan.", "Resumed.")) } } catch (_: Exception) { }
    }

    private fun berhenti() {
        val p = pemutar; pemutar = null
        try { p?.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
    }

    override fun onDestroy() { berhenti(); super.onDestroy() }

    companion object {
        const val ID_MTQ = "196jTYIKkoxhw1Ya8vh4ghVriObZiFt1i"
        const val ID_MUAMMAR = "1TTyDmIm2EtnyIe7Itjxmiz8TbGhGQvVP"
    }
}
