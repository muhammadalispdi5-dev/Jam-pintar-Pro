package com.novan.bateraibicara

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * FIX377: gempa terbaru di luar Indonesia dari katalog USGS (FDSN event, GeoJSON). BMKG hanya meliputi Indonesia, jadi bila lokasi
 * tersimpan berada di luar Indonesia, perintah "gempa terbaru" dijawab dari sini. Data diambil langsung saat diminta.
 */
object GempaDunia {
    // Sengaja val biasa (bukan const): kompiler CI menolak const val berisi alamat https://.
    val URL_DASAR = "https://earthquake.usgs.gov/fdsnws/event/1/query"

    fun diIndonesia(lat: Double, lon: Double): Boolean = lat in -11.2..6.2 && lon in 95.0..141.1

    private fun tr(id: String, en: String, eng: Boolean) = if (eng) en else id

    private fun ambil(alamat: String): String {
        val k = URL(alamat).openConnection() as HttpURLConnection
        k.connectTimeout = 9000; k.readTimeout = 12000
        k.setRequestProperty("User-Agent", "JamPintarPro")
        try {
            if (k.responseCode !in 200..299) throw IllegalStateException("HTTP " + k.responseCode)
            return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { try { k.disconnect() } catch (_: Exception) { } }
    }

    private fun angka(x: Double, eng: Boolean): String = String.format(if (eng) Locale.US else Locale("id", "ID"), "%.1f", x)

    /** Gempa terbaru dalam radius [radiusKm] dari titik; bila tidak ada, gempa terbaru M5 ke atas di seluruh dunia. */
    fun laporan(lat: Double, lon: Double, eng: Boolean, radiusKm: Int = 1000): String {
        return try {
            val dekat = ambil(URL_DASAR + "?format=geojson&orderby=time&limit=3&minmagnitude=3.5&latitude=" + lat + "&longitude=" + lon + "&maxradiuskm=" + radiusKm)
            val daftar = JSONObject(dekat).optJSONArray("features")
            if (daftar != null && daftar.length() > 0) {
                tr("Gempa terbaru dalam " + radiusKm + " kilometer dari lokasi Anda menurut USGS. ", "Latest earthquakes within " + radiusKm + " kilometers of your location according to USGS. ", eng) +
                    (0 until daftar.length()).joinToString(" ") { ucap(daftar.getJSONObject(it), eng) } + sumber(eng)
            } else {
                val dunia = JSONObject(ambil(URL_DASAR + "?format=geojson&orderby=time&limit=1&minmagnitude=5")).optJSONArray("features")
                val awal = tr("Tidak ada gempa berkekuatan 3,5 atau lebih dalam " + radiusKm + " kilometer dari lokasi Anda dalam data terbaru USGS. ",
                    "No earthquake of magnitude 3.5 or more within " + radiusKm + " kilometers of your location in the latest USGS data. ", eng)
                if (dunia != null && dunia.length() > 0) awal + tr("Gempa dunia terbaru berkekuatan 5 atau lebih. ", "Latest worldwide earthquake of magnitude 5 or more. ", eng) + ucap(dunia.getJSONObject(0), eng) + sumber(eng)
                else awal + sumber(eng)
            }
        } catch (_: Exception) {
            tr("Data gempa dari USGS belum dapat diambil. Periksa koneksi internet lalu coba lagi.", "Earthquake data from USGS could not be fetched. Check your internet connection and try again.", eng)
        }
    }

    private fun ucap(f: JSONObject, eng: Boolean): String {
        val p = f.optJSONObject("properties") ?: return ""
        val mag = p.optDouble("mag", Double.NaN)
        val tempat = p.optString("place", "").trim()
        val waktu = ZonedDateTime.ofInstant(Instant.ofEpochMilli(p.optLong("time", 0L)), ZoneId.systemDefault())
        val pola = DateTimeFormatter.ofPattern(if (eng) "EEEE, MMMM d 'at' h:mm a" else "EEEE, d MMMM 'pukul' HH.mm", if (eng) Locale.US else Locale("id", "ID"))
        val dalam = f.optJSONObject("geometry")?.optJSONArray("coordinates")?.optDouble(2, Double.NaN) ?: Double.NaN
        return tr("Magnitudo ", "Magnitude ", eng) + (if (mag.isNaN()) "?" else angka(mag, eng)) +
            (if (dalam.isNaN()) "" else tr(", kedalaman " + Math.round(dalam) + " kilometer", ", depth " + Math.round(dalam) + " kilometers", eng)) +
            (if (tempat.isBlank()) "" else ", " + tempat) + ", " + waktu.format(pola) + "."
    }

    private fun sumber(eng: Boolean) = tr(" Sumber: USGS. Ini informasi umum, bukan peringatan resmi; ikuti arahan otoritas setempat.", " Source: USGS. This is general information, not an official warning; follow your local authorities.", eng)
}
