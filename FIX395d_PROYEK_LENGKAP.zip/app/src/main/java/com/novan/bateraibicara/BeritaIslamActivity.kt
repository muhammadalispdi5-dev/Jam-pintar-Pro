package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.widget.EditText
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

/** FIX395: Berita Islam dari sumber terpercaya menurut negara pengguna. Ketuk judul untuk ringkasan, lalu buka di peramban bila perlu. */
class BeritaIslamActivity : Halaman() {
    override val judulHalaman = R.string.judul_berita_islam

    private var status: TextView? = null
    private var tampilAwal = -1
    private var nomor = 0

    override fun bangun() {
        RadioTvData.aturNegara(this)
        val negara = RadioTvData.negaraUtama
        bagian(tr("Berita Islam", "Islamic news"))
        status = info(tr("Memuat berita untuk negara ", "Loading news for country ") + negara + "…").also { it.accessibilityLiveRegion = android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE }
        tombol(tr("Muat ulang berita", "Reload the news")) { recreate() }
        tombol(tr("Tambah sumber berita sendiri", "Add your own news source")) { dialogTambah() }
        for (s in BeritaData.milikSendiri(this)) tombol(tr("Hapus sumber sendiri: ", "Remove your source: ") + ui(s.nama)) { BeritaData.hapusSendiri(this, s); recreate() }
        tampilAwal = root.childCount
        isi(BeritaData.cadangan(this))
        val n = ++nomor
        Thread {
            val hasil = try { BeritaData.muat(this, negara) } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || n != nomor) return@runOnUiThread
                if (hasil == null) setStatus(tr("Berita tidak dapat dimuat dari internet. Berita tersimpan terakhir ditampilkan bila ada.", "The news could not be loaded from the internet. The last saved news is shown if available."))
                else if (hasil.isEmpty()) setStatus(tr("Belum ada berita Islam yang ditemukan.", "No Islamic news was found yet."))
                else { setStatus(tr("Berita dimuat: ", "News loaded: ") + hasil.size); isi(hasil) }
            }
        }.start()
    }

    private fun setStatus(t: String) { runOnUiThread { status?.text = t; status?.announceForAccessibility(t) } }

    private fun isi(daftar: List<BeritaData.Berita>) {
        if (tampilAwal < 0) return
        while (root.childCount > tampilAwal) root.removeViewAt(tampilAwal)
        for (b in daftar) {
            val tgl = if (b.tanggal > 0) ", " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(b.tanggal)) else ""
            tombol(b.judul + ". " + b.sumber + tgl) { detail(b) }
        }
    }

    private fun detail(b: BeritaData.Berita) {
        AlertDialog.Builder(this).setTitle(b.judul)
            .setMessage(b.sumber + "\n\n" + (if (b.ringkas.isBlank()) tr("Tidak ada ringkasan.", "No summary.") else b.ringkas))
            .setPositiveButton(tr("Buka di peramban", "Open in browser")) { _, _ -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(b.tautan))) } catch (_: Exception) { } }
            .setNegativeButton(tr("Tutup", "Close"), null).show()
    }

    private fun dialogTambah() {
        val nama = EditText(this).apply { hint = tr("Nama sumber", "Source name") }
        val url = EditText(this).apply { hint = tr("Alamat umpan RSS (https://…)", "RSS feed address (https://…)"); inputType = InputType.TYPE_TEXT_VARIATION_URI }
        val kotak = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); addView(nama); addView(url) }
        AlertDialog.Builder(this).setTitle(tr("Tambah sumber berita", "Add a news source")).setView(kotak)
            .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                if (BeritaData.tambahSendiri(this, nama.text.toString(), url.text.toString())) recreate()
                else android.widget.Toast.makeText(this, tr("Nama dan alamat https tidak valid.", "Invalid name or https address."), android.widget.Toast.LENGTH_LONG).show()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }
}
