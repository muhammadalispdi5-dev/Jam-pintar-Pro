package com.novan.bateraibicara

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer

/**
 * FIX395: pengaturan nada Bass dan Treble (tingkat 0 sampai 5, 0 = datar) serta pilihan Stereo/Mono.
 * Radio dan TV memakai efek bawaan Android (Equalizer dan BassBoost) pada sesi audio pemutar.
 * Murattal Khatam memakai penyaring digital sendiri pada data suara ([TonDsp]) di PemutarMono.
 * Mono/Stereo memakai kunci yang sama dengan layar Khatam ("keluaran_suara_audio" pada "khatam_quran").
 */
object NadaAudio {
    const val MAKS = 5
    @Volatile var bass = 0
    @Volatile var treble = 0
    private var efekEq: Equalizer? = null
    private var efekBass: BassBoost? = null

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("nada_audio", Context.MODE_PRIVATE)

    fun muat(c: Context) { bass = sp(c).getInt("bass", 0).coerceIn(0, MAKS); treble = sp(c).getInt("treble", 0).coerceIn(0, MAKS) }

    fun simpan(c: Context, b: Int, t: Int) {
        bass = b.coerceIn(0, MAKS); treble = t.coerceIn(0, MAKS)
        sp(c).edit().putInt("bass", bass).putInt("treble", treble).apply()
        terapkanEfek()
    }

    fun mono(c: Context): Boolean = c.applicationContext.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).getString("keluaran_suara_audio", "stereo") == "mono"
    fun simpanMono(c: Context, m: Boolean) { c.applicationContext.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).edit().putString("keluaran_suara_audio", if (m) "mono" else "stereo").apply() }

    /** Pasang efek pada sesi audio pemutar radio/TV; gagal dengan tenang bila perangkat tidak mendukung. */
    fun pasang(sesi: Int) {
        lepas()
        if (sesi == 0 || (bass == 0 && treble == 0)) { if (sesi != 0) siapSesi = sesi; return }
        siapSesi = sesi
        terapkanEfek()
    }
    private var siapSesi = 0

    fun lepas() {
        try { efekEq?.release() } catch (_: Throwable) { }
        try { efekBass?.release() } catch (_: Throwable) { }
        efekEq = null; efekBass = null; siapSesi = 0
    }

    private fun terapkanEfek() {
        val sesi = siapSesi
        if (sesi == 0) return
        try {
            if (efekEq == null) efekEq = Equalizer(0, sesi).also { it.enabled = true }
            val eq = efekEq!!
            val rentang = eq.bandLevelRange
            val n = eq.numberOfBands.toInt()
            for (i in 0 until n) {
                val tengah = eq.getCenterFreq(i.toShort()) / 1000
                val tingkat = if (tengah < 250) bass else if (tengah > 3500) treble else 0
                val mb = (tingkat * 300).coerceIn(rentang[0].toInt(), rentang[1].toInt())
                eq.setBandLevel(i.toShort(), mb.toShort())
            }
        } catch (_: Throwable) { efekEq = null }
        try {
            if (efekBass == null) efekBass = BassBoost(0, sesi)
            val bb = efekBass!!
            if (bb.strengthSupported) { bb.setStrength((bass * 200).coerceIn(0, 1000).toShort()); bb.enabled = bass > 0 }
        } catch (_: Throwable) { efekBass = null }
    }

    fun namaTingkat(t: Int, inggris: Boolean): String = if (t == 0) (if (inggris) "flat" else "datar") else (if (inggris) "level " else "tingkat ") + t

    /** Penyaring shelf (bass 120 Hz, treble 6 kHz) untuk data PCM 16-bit bergantian per kanal. */
    class TonDsp(private val laju: Int, private val kanal: Int, bassTingkat: Int, trebleTingkat: Int) {
        private class Bq(val b0: Double, val b1: Double, val b2: Double, val a1: Double, val a2: Double) {
            var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
            fun p(x: Double): Double { val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2; x2 = x1; x1 = x; y2 = y1; y1 = y; return y }
        }
        private fun shelf(rendah: Boolean, f0: Double, dB: Double): Bq {
            val a = Math.pow(10.0, dB / 40.0); val w = 2 * Math.PI * f0 / laju
            val cw = Math.cos(w); val al = Math.sin(w) / 2 * Math.sqrt(2.0); val k = 2 * Math.sqrt(a) * al
            val b0: Double; val b1: Double; val b2: Double; val a0: Double; val a1: Double; val a2: Double
            if (rendah) {
                b0 = a * ((a + 1) - (a - 1) * cw + k); b1 = 2 * a * ((a - 1) - (a + 1) * cw); b2 = a * ((a + 1) - (a - 1) * cw - k)
                a0 = (a + 1) + (a - 1) * cw + k; a1 = -2 * ((a - 1) + (a + 1) * cw); a2 = (a + 1) + (a - 1) * cw - k
            } else {
                b0 = a * ((a + 1) + (a - 1) * cw + k); b1 = -2 * a * ((a - 1) + (a + 1) * cw); b2 = a * ((a + 1) + (a - 1) * cw - k)
                a0 = (a + 1) - (a - 1) * cw + k; a1 = 2 * ((a - 1) - (a + 1) * cw); a2 = (a + 1) - (a - 1) * cw - k
            }
            return Bq(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
        }
        private val rendahF = Array(kanal) { shelf(true, 120.0, bassTingkat * 2.5) }
        private val tinggiF = Array(kanal) { shelf(false, 6000.0, trebleTingkat * 2.5) }
        private val aktifB = bassTingkat > 0
        private val aktifT = trebleTingkat > 0

        fun proses(d: ShortArray, dari: Int, jumlah: Int) {
            if (!aktifB && !aktifT) return
            var i = dari
            val akhir = dari + jumlah
            while (i < akhir) {
                val c = (i - dari) % kanal
                var x = d[i].toDouble()
                if (aktifB) x = rendahF[c].p(x)
                if (aktifT) x = tinggiF[c].p(x)
                d[i] = x.coerceIn(-32768.0, 32767.0).toInt().toShort()
                i++
            }
        }
    }
}
