package com.novan.bateraibicara

import android.content.Context

/**
 * FIX387: pilihan kontak (nama atau nomor) yang boleh atau tidak boleh diumumkan.
 * Dua daftar terpisah: "panggilan" (Nama Panggilan) dan "pesan" (Pembacaan notifikasi pesan).
 * Mode: 0 = semua kontak, 1 = hanya kontak dalam daftar, 2 = semua kecuali kontak dalam daftar.
 * Satu butir daftar disimpan sebagai satu baris "nama TAB nomor;nomor" (salah satu boleh kosong).
 * Murni logika Kotlin agar dapat diuji.
 */
object KontakFilter {
    const val SEMUA = 0
    const val HANYA = 1
    const val KECUALI = 2

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)

    fun mode(c: Context, jenis: String): Int = sp(c).getInt("pem_filter_" + jenis + "_mode", SEMUA).coerceIn(0, 2)
    fun setMode(c: Context, jenis: String, m: Int) { sp(c).edit().putInt("pem_filter_" + jenis + "_mode", m.coerceIn(0, 2)).apply() }

    fun daftar(c: Context, jenis: String): List<String> =
        (sp(c).getString("pem_filter_" + jenis + "_daftar", "") ?: "").split('\n').filter { it.isNotBlank() }

    private fun simpan(c: Context, jenis: String, d: List<String>) {
        sp(c).edit().putString("pem_filter_" + jenis + "_daftar", d.joinToString("\n")).apply()
    }

    fun nomorSaja(s: String): String = s.filter { it.isDigit() }

    private fun nama(butir: String) = butir.substringBefore('\t')
    private fun nomor(butir: String) = if (butir.contains('\t')) butir.substringAfter('\t').split(';').filter { it.isNotBlank() } else emptyList()

    /** Teks butir yang dibacakan atau ditampilkan. */
    fun label(butir: String): String = nama(butir).ifBlank { nomor(butir).firstOrNull().orEmpty() }

    fun buatButir(namaKontak: String, nomorKontak: String): String =
        namaKontak.trim().replace('\t', ' ').replace('\n', ' ') + "\t" + nomorSaja(nomorKontak)

    /** Teks ketikan pengguna: bila hampir semuanya angka dianggap nomor, selain itu nama. */
    fun dariKetikan(s: String): String? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val angka = nomorSaja(t)
        return if (angka.length >= 5 && angka.length >= t.count { !it.isWhitespace() && it != '+' && it != '-' && it != '(' && it != ')' }) buatButir("", angka)
        else buatButir(t, "")
    }

    fun tambah(c: Context, jenis: String, butir: String): Boolean {
        val d = daftar(c, jenis).toMutableList()
        if (d.any { sama(it, butir) }) return false
        d.add(butir); simpan(c, jenis, d); return true
    }

    fun hapus(c: Context, jenis: String, butir: String) {
        simpan(c, jenis, daftar(c, jenis).filter { it != butir })
    }

    private fun norm(s: String): String =
        " " + s.lowercase().map { if (it.isLetterOrDigit()) it else ' ' }.joinToString("").trim().replace(Regex("\\s+"), " ") + " "

    private fun akhirNomor(s: String): String { val n = nomorSaja(s); return if (n.length > 9) n.takeLast(9) else n }

    private fun sama(a: String, b: String): Boolean {
        val na = nama(a).let { norm(it) }.trim(); val nb = nama(b).let { norm(it) }.trim()
        if (na.isNotEmpty() && na == nb) return true
        val ta = nomor(a).map { akhirNomor(it) }.filter { it.length >= 5 }
        val tb = nomor(b).map { akhirNomor(it) }.filter { it.length >= 5 }
        return ta.any { it in tb }
    }

    /** Apakah salah satu calon teks (nama kontak, judul notifikasi, nomor) cocok dengan butir daftar. */
    fun cocok(butir: String, calon: List<String>): Boolean {
        val n = nama(butir).trim()
        val nn = if (n.isNotEmpty()) norm(n) else ""
        val nomorButir = nomor(butir).map { akhirNomor(it) }.filter { it.length >= 5 }
        for (k in calon) {
            if (k.isBlank()) continue
            if (nn.isNotEmpty() && norm(k).contains(nn)) return true
            val ak = akhirNomor(k)
            if (nomorSaja(k).length >= 5 && nomorButir.any { it == ak }) return true
        }
        return false
    }

    /** Hasil akhir: true bila pengumuman boleh dibacakan. */
    fun diizinkan(mode: Int, daftar: List<String>, calon: List<String>): Boolean = when (mode) {
        HANYA -> daftar.any { cocok(it, calon) }
        KECUALI -> daftar.none { cocok(it, calon) }
        else -> true
    }

    fun diizinkan(c: Context, jenis: String, calon: List<String>): Boolean {
        val m = mode(c, jenis)
        return if (m == SEMUA) true else diizinkan(m, daftar(c, jenis), calon)
    }
}
