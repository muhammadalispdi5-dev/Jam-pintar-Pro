package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * FIX392: daftar saluran radio dan TV bernuansa Islami. Daftar diambil saat dibuka dari dua sumber terbuka
 * (playlist kategori religius iptv-org untuk TV, dan direktori Radio Browser untuk radio), disaring dengan kata kunci Islami,
 * lalu disimpan sebagai cadangan luring. Pengguna juga dapat menambah saluran sendiri. Alamat siaran tidak ditulis tetap
 * di dalam aplikasi karena sering berubah; ketersediaannya bergantung pada sumber tersebut.
 */
object RadioTvData {
    class Saluran(val nama: String, val url: String, val negara: String, val tv: Boolean)

    private val kataIslami = listOf("quran", "qur'an", "kuran", "koran", "islam", "islami", "makkah", "makka", "mecca", "mekah", "madinah", "medina", "madina",
        "sunnah", "sunna", "rodja", "iqra", "iqraa", "majd", "huda", "resalah", "risalah", "hidayah", "dakwah", "muslim", "ummah", "murottal", "murattal",
        "kajian", "ngaji", "tilawah", "azan", "adhan", "sholawat", "shalawat", "nasyid", "nasheed", "mtq", "ruqyah", "haramain", "al-quran", "alquran")

    fun adalahIslami(teks: String): Boolean {
        val t = teks.lowercase(Locale.ROOT)
        return kataIslami.any { t.contains(it) }
    }

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("radio_tv", Context.MODE_PRIVATE)

    private fun ambilTeks(alamat: String): String {
        val k = URL(alamat).openConnection() as HttpURLConnection
        k.connectTimeout = 15000; k.readTimeout = 25000
        k.setRequestProperty("User-Agent", "JamPintarPro/1.0")
        return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    /** Urai playlist M3U menjadi daftar saluran TV; hanya yang bernuansa Islami. Murni logika agar dapat diuji. */
    fun uraiM3u(teks: String): List<Saluran> {
        val hasil = ArrayList<Saluran>()
        var nama = ""; var id = ""
        for (baris in teks.lines()) {
            val b = baris.trim()
            if (b.startsWith("#EXTINF")) {
                nama = b.substringAfterLast(',').trim()
                id = Regex("tvg-id=\"([^\"]*)\"").find(b)?.groupValues?.get(1).orEmpty()
            } else if (b.isNotEmpty() && !b.startsWith("#") && nama.isNotEmpty()) {
                if (adalahIslami(nama + " " + id)) {
                    val negara = id.substringAfterLast('.', "").uppercase(Locale.ROOT).takeIf { it.length == 2 }.orEmpty()
                    hasil.add(Saluran(nama, b, negara, true))
                }
                nama = ""; id = ""
            }
        }
        return hasil
    }

    fun uraiRadio(json: String): List<Saluran> {
        val hasil = ArrayList<Saluran>()
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val url = o.optString("url_resolved", "").ifBlank { o.optString("url", "") }
            val nama = o.optString("name", "").trim()
            if (url.isBlank() || nama.isBlank() || url == "null") continue
            hasil.add(Saluran(nama, url, o.optString("countrycode", "").uppercase(Locale.ROOT), false))
        }
        return hasil
    }

    /** FIX395: negara pengguna (dua huruf) untuk mengurutkan dan memuat saluran lokal; bawaan ID bila belum diketahui. */
    @Volatile var negaraUtama: String = "ID"

    fun aturNegara(c: Context) {
        val k = try { NegaraLokasi.tersimpanCepat(c) } catch (_: Exception) { null }
        negaraUtama = k?.trim()?.uppercase(Locale.ROOT)?.takeIf { it.length == 2 } ?: "ID"
    }

    private val kataHaramain = listOf("makkah", "makka", "mecca", "mekah", "madinah", "medina", "madina", "haramain", "kaaba", "kabah", "saudi quran", "sunnah", "sunna")
    private val kataQuran = listOf("quran", "qur'an", "kuran", "koran", "murottal", "murattal", "tilawah", "al-quran", "alquran")
    private val kataKajian = listOf("kajian", "dakwah", "rodja", "huda", "majd", "ceramah", "sheikh", "syekh", "ustadz", "lecture", "sunnah")

    /** Kategori daftar: 0 semua, 1 negara saya, 2 Makkah dan Madinah, 3 Al-Qur'an, 4 kajian dan dakwah. */
    fun cocok(s: Saluran, kategori: Int): Boolean {
        val t = s.nama.lowercase(Locale.ROOT)
        return when (kategori) {
            1 -> s.negara == negaraUtama
            2 -> kataHaramain.any { t.contains(it) } && (s.negara == "SA" || s.negara.isEmpty() || t.contains("makk") || t.contains("madin") || t.contains("haramain") || t.contains("mecca") || t.contains("medina"))
            3 -> kataQuran.any { t.contains(it) }
            4 -> kataKajian.any { t.contains(it) }
            else -> true
        }
    }

    /** Negara pengguna lebih dahulu, lalu Arab Saudi (Makkah, Madinah), lalu lainnya menurut nama; nama dan alamat ganda dibuang. */
    fun urutkan(daftar: List<Saluran>): List<Saluran> =
        daftar.distinctBy { it.url }.distinctBy { it.nama.lowercase(Locale.ROOT) }
            .sortedWith(compareBy<Saluran>({ if (it.negara == negaraUtama) 0 else if (it.negara == "SA") 1 else 2 }, { it.nama.lowercase(Locale.ROOT) }))

    private val serverRadio = listOf("de1.api.radio-browser.info", "de2.api.radio-browser.info", "fi1.api.radio-browser.info", "at1.api.radio-browser.info")

    /** Memblokir (jaringan): panggil dari thread latar. Melempar bila semua sumber gagal. */
    fun muatTv(c: Context): List<Saluran> {
        aturNegara(c)
        val semuaTv = ArrayList<Saluran>()
        var okTv = false
        // Kategori religi dunia, lalu daftar negara pengguna dan Arab Saudi (Makkah, Madinah).
        for (u in listOf("categories/religious", "countries/" + negaraUtama.lowercase(Locale.ROOT), "countries/sa")) {
            try { semuaTv.addAll(uraiM3u(ambilTeks("https://iptv-org.github.io/iptv/" + u + ".m3u"))); okTv = true } catch (_: Exception) { }
        }
        if (!okTv) throw java.io.IOException("tv")
        val hasil = urutkan(semuaTv)
        sp(c).edit().putString("cache_tv", simpanBaris(hasil)).apply()
        return hasil
    }

    fun muatRadio(c: Context): List<Saluran> {
        aturNegara(c)
        val semua = ArrayList<Saluran>()
        var berhasil = false
        val tag = listOf("quran", "islam", "islamic", "dakwah", "murottal", "makkah", "madinah")
        for (t in tag) {
            var json: String? = null
            for (s in serverRadio) {
                try { json = ambilTeks("https://" + s + "/json/stations/search?tag=" + t + "&limit=40&hidebroken=true&order=clickcount&reverse=true"); break } catch (_: Exception) { }
            }
            if (json != null) { berhasil = true; try { semua.addAll(uraiRadio(json)) } catch (_: Exception) { } }
        }
        // Negara pengguna dan Arab Saudi: kata kunci Islami pada nama stasiun.
        val kodeNegara = negaraUtama
        for (kunci in listOf("rodja", "dakwah", "muslim", "islam", "quran")) {
            for (s in serverRadio) {
                try { semua.addAll(uraiRadio(ambilTeks("https://" + s + "/json/stations/search?name=" + kunci + "&countrycode=" + kodeNegara + "&limit=30&hidebroken=true&order=clickcount&reverse=true"))); berhasil = true; break } catch (_: Exception) { }
            }
        }
        if (!berhasil) throw java.io.IOException("radio")
        val hasil = urutkan(semua.filter { adalahIslami(it.nama) || it.negara == kodeNegara && adalahIslami(it.nama + " islam") })
        sp(c).edit().putString("cache_radio", simpanBaris(hasil)).apply()
        return hasil
    }

    private fun simpanBaris(d: List<Saluran>): String =
        d.joinToString("\n") { listOf(it.nama, it.url, it.negara, if (it.tv) "t" else "r").joinToString("\t") { s -> s.replace('\t', ' ').replace('\n', ' ') } }

    private fun bacaBaris(s: String?): List<Saluran> = (s ?: "").split('\n').mapNotNull {
        val p = it.split('\t'); if (p.size == 4 && p[1].isNotBlank()) Saluran(p[0], p[1], p[2], p[3] == "t") else null
    }

    fun cadangan(c: Context, tv: Boolean): List<Saluran> = bacaBaris(sp(c).getString(if (tv) "cache_tv" else "cache_radio", ""))


    // ---------- Pemindaian otomatis (FIX393) ----------
    private val negaraPindai = listOf("id", "my", "sa", "eg", "ae", "tr", "pk", "bd", "ma", "dz", "kw", "qa", "sg", "bn", "jo")
    private val tagRadioPindai = listOf("quran", "islam", "islamic", "dakwah", "murottal", "tilawah", "kajian", "sholawat", "nasheed", "adhan", "quran recitation", "holy quran")

    /** Kumpulkan calon saluran dari sumber terbuka; tiap sumber yang gagal dilewati. Memblokir: panggil dari thread latar. */
    fun kandidat(tv: Boolean, batal: () -> Boolean): List<Saluran> {
        val semua = ArrayList<Saluran>()
        if (tv) {
            val sumber = listOf("categories/religious") + negaraPindai.map { "countries/" + it }
            for (u in sumber) {
                if (batal()) break
                try { semua.addAll(uraiM3u(ambilTeks("https://iptv-org.github.io/iptv/" + u + ".m3u"))) } catch (_: Exception) { }
            }
        } else {
            val kueri = ArrayList<String>()
            for (t in tagRadioPindai) kueri.add("tag=" + t.replace(" ", "%20") + "&limit=80")
            for (n in negaraPindai) kueri.add("tag=islam&countrycode=" + n.uppercase(Locale.ROOT) + "&limit=60")
            kueri.add("name=rodja&countrycode=ID&limit=30")
            for (q in kueri) {
                if (batal()) break
                for (sv in serverRadio) {
                    try { semua.addAll(uraiRadio(ambilTeks("https://" + sv + "/json/stations/search?" + q + "&hidebroken=true&order=clickcount&reverse=true"))); break } catch (_: Exception) { }
                }
            }
        }
        return urutkan(semua.filter { adalahIslami(it.nama) || (!tv) })
    }

    /** Apakah alamat siaran benar-benar menjawab dan isinya tampak seperti siaran (bukan halaman web). */
    fun layak(s: Saluran): Boolean {
        var alamat = s.url
        try {
            var lompat = 0
            while (lompat < 5) {
                val k = URL(alamat).openConnection() as HttpURLConnection
                k.instanceFollowRedirects = false; k.connectTimeout = 5000; k.readTimeout = 6000
                k.setRequestProperty("User-Agent", "JamPintarPro/1.0")
                val kode = k.responseCode
                if (kode in 300..399) { val l = k.getHeaderField("Location"); k.disconnect(); if (l.isNullOrBlank()) return false; alamat = URL(URL(alamat), l).toString(); lompat++; continue }
                if (kode !in 200..206) { k.disconnect(); return false }
                val jenis = (k.contentType ?: "").lowercase(Locale.ROOT)
                var ok = false
                try {
                    val buf = ByteArray(2048)
                    val n = k.inputStream.read(buf)
                    val awal = if (n > 0) String(buf, 0, n, Charsets.ISO_8859_1) else ""
                    ok = if (s.tv) (awal.trimStart().startsWith("#EXTM3U") || jenis.contains("mpegurl") || jenis.startsWith("video/") || jenis.contains("mp2t") || jenis.contains("octet-stream")) && n > 0
                         else (jenis.startsWith("audio/") || jenis.contains("ogg") || jenis.contains("mpegurl") || jenis.contains("aac") || jenis.contains("octet-stream")) && n > 0 && !awal.trimStart().startsWith("<")
                } catch (_: Exception) { ok = false }
                k.disconnect()
                return ok
            }
        } catch (_: Exception) { }
        return false
    }

    fun hasilPindai(c: Context, tv: Boolean): List<Saluran> = bacaBaris(sp(c).getString(if (tv) "pindai_tv" else "pindai_radio", ""))

    /**
     * Pindai: kumpulkan calon, periksa paralel (8 utas), simpan yang layak ke daftar tetap (digabung dengan hasil pindai sebelumnya).
     * progres(diperiksa, total, ditemukan). Mengembalikan jumlah saluran layak pada pemindaian ini; -1 bila tidak ada calon.
     */
    fun pindai(c: Context, tv: Boolean, batal: () -> Boolean, progres: (Int, Int, Int) -> Unit): Int {
        val calon = kandidat(tv, batal)
        if (calon.isEmpty()) return -1
        val total = calon.size
        val lolos = java.util.Collections.synchronizedList(ArrayList<Saluran>())
        val diperiksa = java.util.concurrent.atomic.AtomicInteger(0)
        val kolam = java.util.concurrent.Executors.newFixedThreadPool(8)
        for (s in calon) {
            kolam.execute {
                if (!batal()) { if (layak(s)) lolos.add(s) }
                val d = diperiksa.incrementAndGet()
                if (d % 5 == 0 || d == total) progres(d, total, lolos.size)
            }
        }
        kolam.shutdown()
        try { kolam.awaitTermination(15, java.util.concurrent.TimeUnit.MINUTES) } catch (_: Exception) { }
        val gabung = urutkan(lolos.toList() + hasilPindai(c, tv))
        sp(c).edit().putString(if (tv) "pindai_tv" else "pindai_radio", simpanBaris(gabung)).apply()
        progres(total, total, lolos.size)
        return lolos.size
    }

    // Saluran buatan pengguna
    fun milikSendiri(c: Context, tv: Boolean): List<Saluran> = bacaBaris(sp(c).getString(if (tv) "sendiri_tv" else "sendiri_radio", ""))

    fun tambahSendiri(c: Context, tv: Boolean, nama: String, url: String): Boolean {
        val u = url.trim()
        if (nama.isBlank() || !(u.startsWith("http://") || u.startsWith("https://"))) return false
        val d = milikSendiri(c, tv).toMutableList()
        if (d.any { it.url == u }) return false
        d.add(Saluran(nama.trim(), u, "", tv))
        sp(c).edit().putString(if (tv) "sendiri_tv" else "sendiri_radio", simpanBaris(d)).apply()
        return true
    }

    fun hapusSendiri(c: Context, tv: Boolean, s: Saluran) {
        sp(c).edit().putString(if (tv) "sendiri_tv" else "sendiri_radio", simpanBaris(milikSendiri(c, tv).filter { it.url != s.url })).apply()
    }
}
