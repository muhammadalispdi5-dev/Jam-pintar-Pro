package com.novan.bateraibicara

import android.content.Context

/** Preferensi khusus jadwal sholat. FIX246: jadwal sholat dan fitur pendukungnya aktif secara bawaan (pemilihan jenis puasa, Jangan Ganggu, dan waktu khusus tetap pilihan pengguna). */
class PrayerPrefs(context: Context) {
    private val konteksAplikasi = context.applicationContext
    private val sp = context.applicationContext.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
    var enabled: Boolean get() = sp.getBoolean("enabled", true); set(v) = sp.edit().putBoolean("enabled", v).apply()
    var locationSet: Boolean get() = sp.getBoolean("location_set", false); set(v) = sp.edit().putBoolean("location_set", v).apply()
    var lat: Double get() = java.lang.Double.longBitsToDouble(sp.getLong("lat", java.lang.Double.doubleToRawLongBits(0.0))); set(v) = sp.edit().putLong("lat", java.lang.Double.doubleToRawLongBits(v)).apply()
    var lon: Double get() = java.lang.Double.longBitsToDouble(sp.getLong("lon", java.lang.Double.doubleToRawLongBits(0.0))); set(v) = sp.edit().putLong("lon", java.lang.Double.doubleToRawLongBits(v)).apply()
    /** true bila nama tempat pernah disimpan (bukan nilai bawaan "belum diatur"). */
    val namaTempatTersimpan: Boolean get() = !sp.getString("place", null).isNullOrBlank()
    var place: String
        get() {
            val tersimpan = sp.getString("place", "Lokasi belum diatur") ?: "Lokasi belum diatur"
            // Migrasikan teks rusak dari versi lama yang menyimpan template Kotlin mentah.
            if (tersimpan.contains("\u0024sumber") || tersimpan.contains("\u0024{lokasi.accuracy") || tersimpan.contains("akurasi ±")) {
                sp.edit().putString("place", "Lokasi tersimpan").apply()
                return "Lokasi tersimpan"
            }
            return tersimpan
        }
        set(v) = sp.edit().putString("place", v).apply()
    var method: Int get() = sp.getInt("method", 0).coerceIn(0, PrayerCalc.methodNames.lastIndex); set(v) = sp.edit().putInt("method", v).apply()
    /** FIX375: true = metode dipilih otomatis menurut lokasi. Pengguna lama yang sudah memilih metode tetap manual. */
    var metodeOtomatis: Boolean get() = sp.getBoolean("metode_otomatis", !sp.contains("method")); set(v) = sp.edit().putBoolean("metode_otomatis", v).apply()
    /** Metode yang benar-benar dipakai menghitung jadwal. */
    val methodEfektif: Int get() = if (metodeOtomatis && locationSet) PrayerCalc.rekomendasiMetode(lat, lon).coerceIn(0, PrayerCalc.methodNames.lastIndex) else method
    var asrFactor: Int get() = sp.getInt("asr_factor", 1).coerceIn(1, 2); set(v) = sp.edit().putInt("asr_factor", v).apply()
    var use24: Boolean get() = sp.getBoolean("use24", true); set(v) = sp.edit().putBoolean("use24", v).apply()
    var notifyOnly: Boolean get() = sp.getBoolean("notify_only", false); set(v) = sp.edit().putBoolean("notify_only", v).apply()
    var sahurReminderEnabled: Boolean get() = sp.getBoolean("sahur_reminder_enabled", true); set(v) = sp.edit().putBoolean("sahur_reminder_enabled", v).apply()
    // Satu jenis puasa aktif pada satu waktu. "none" menjaga seluruh fitur puasa nonaktif pada pemasangan baru.
    var fastingType: String
        get() = sp.getString("fasting_type", FastingSchedule.NONE) ?: FastingSchedule.NONE
        set(v) { sp.edit().putString("fasting_type", if (v in listOf(FastingSchedule.RAMADAN, FastingSchedule.MON_THU, FastingSchedule.DAWUD, FastingSchedule.SHAWWAL)) v else FastingSchedule.NONE).apply() }
    var dawudStartDate: String get() = sp.getString("dawud_start_date", "") ?: ""; set(v) = sp.edit().putString("dawud_start_date", v).apply()
    var shawwalSelectedDates: Set<String>
        get() = (sp.getString("shawwal_selected_dates", "") ?: "").split(',').filter { it.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.toSet()
        set(v) = sp.edit().putString("shawwal_selected_dates", v.sorted().joinToString(",")).apply()
    var sahurReminderMinutes: Int get() = sp.getInt("sahur_reminder_minutes", 30).let { if (it in PILIHAN_SAHUR_MENIT) it else 30 }; set(v) = sp.edit().putInt("sahur_reminder_minutes", if (v in PILIHAN_SAHUR_MENIT) v else 30).apply()
    // Pengingat berbuka dihitung dari Maghrib; nilai negatif = sebelum, positif = sesudah.
    var berbukaReminderEnabled: Boolean get() = sp.getBoolean("berbuka_reminder_enabled", true); set(v) = sp.edit().putBoolean("berbuka_reminder_enabled", v).apply()
    var berbukaOffsetMinutes: Int get() = sp.getInt("berbuka_offset_minutes", 0).let { if (it in listOf(-30, -15, -10, -5, 0, 5, 10)) it else 0 }; set(v) = sp.edit().putInt("berbuka_offset_minutes", if (v in listOf(-30, -15, -10, -5, 0, 5, 10)) v else 0).apply()
    // Melodi pengingat puasa: indeks 0 = tanpa melodi, 1..18 mengikuti daftar melodi global.
    var sahurMelodiAwal: Int get() = sp.getInt("sahur_melodi_awal", 0).coerceIn(0, 17); set(v) = sp.edit().putInt("sahur_melodi_awal", v.coerceIn(0, 17)).apply()
    var sahurMelodiAkhir: Int get() = sp.getInt("sahur_melodi_akhir", 0).coerceIn(0, 17); set(v) = sp.edit().putInt("sahur_melodi_akhir", v.coerceIn(0, 17)).apply()
    var berbukaMelodiAwal: Int get() = sp.getInt("berbuka_melodi_awal", 0).coerceIn(0, 17); set(v) = sp.edit().putInt("berbuka_melodi_awal", v.coerceIn(0, 17)).apply()
    var berbukaMelodiAkhir: Int get() = sp.getInt("berbuka_melodi_akhir", 0).coerceIn(0, 17); set(v) = sp.edit().putInt("berbuka_melodi_akhir", v.coerceIn(0, 17)).apply()
    var jadwalNotif: Boolean get() = sp.getBoolean("jadwal_notif_aktif", true); set(v) = sp.edit().putBoolean("jadwal_notif_aktif", v).apply()
    var dndEnabled: Boolean get() = sp.getBoolean("prayer_dnd_enabled", false); set(v) = sp.edit().putBoolean("prayer_dnd_enabled", v).apply()
    var dndDuration: Int get() = sp.getInt("prayer_dnd_duration", 10).let { if (it in DURASI_DND_MENIT) it else 10 }; set(v) = sp.edit().putInt("prayer_dnd_duration", if (v in DURASI_DND_MENIT) v else 10).apply()
    // FIX358: Mode Jangan Ganggu khusus salat Jumat, dengan durasi sendiri yang terpisah dari salat lima waktu.
    var dndJumat: Boolean get() = sp.getBoolean("prayer_dnd_jumat", true); set(v) = sp.edit().putBoolean("prayer_dnd_jumat", v).apply()
    var dndJumatDuration: Int get() = sp.getInt("prayer_dnd_jumat_duration", 45).let { if (it in DURASI_DND_JUMAT_MENIT) it else 45 }; set(v) = sp.edit().putInt("prayer_dnd_jumat_duration", if (v in DURASI_DND_JUMAT_MENIT) v else 45).apply()
    fun dndPrayer(name: String): Boolean = sp.getBoolean(("prayer_dnd_" + (name)), name != "tahajud" && name != "dhuha")
    fun setDndPrayer(name: String, value: Boolean) { sp.edit().putBoolean(("prayer_dnd_" + (name)), value).apply() }
    /** FIX76: tombol volume atas/bawah menghentikan suara notifikasi yang sedang berbunyi. Bawaan aktif. */
    var stopDenganVolume: Boolean get() = sp.getBoolean("stop_dengan_volume", true); set(v) = sp.edit().putBoolean("stop_dengan_volume", v).apply()
    var stopAzanFaceDown: Boolean get() = sp.getBoolean("stop_azan_face_down", true); set(v) = sp.edit().putBoolean("stop_azan_face_down", v).apply()
    /** FIX293: lokasi jadwal salat mengikuti perpindahan pengguna (bawaan aktif; dimatikan bila lokasi diatur manual). */
    var ikutiLokasi: Boolean get() = sp.getBoolean("ikuti_lokasi", true); set(v) = sp.edit().putBoolean("ikuti_lokasi", v).apply()
    var autoOnline: Boolean get() = sp.getBoolean("auto_online", true); set(v) = sp.edit().putBoolean("auto_online", v).apply()
    var fridayDhuhrOff: Boolean get() = sp.getBoolean("friday_dhuhr_off", false); set(v) = sp.edit().putBoolean("friday_dhuhr_off", v).apply()
    var voiceQibla: Boolean get() = sp.getBoolean("voice_qibla", true); set(v) = sp.edit().putBoolean("voice_qibla", v).apply()
    var qiblaHaptic: Boolean get() = sp.getBoolean("qibla_haptic", false); set(v) = sp.edit().putBoolean("qibla_haptic", v).apply()
    // Waktu standar hasil perhitungan tetap dipakai sampai pengguna mengaktifkan waktu khusus.
    var dhuhaCustomEnabled: Boolean get() = sp.getBoolean("dhuha_custom_enabled", false); set(v) = sp.edit().putBoolean("dhuha_custom_enabled", v).apply()
    var dhuhaCustomMinute: Int get() = sp.getInt("dhuha_custom_minute", 8 * 60).coerceIn(0, 1439); set(v) = sp.edit().putInt("dhuha_custom_minute", v.coerceIn(0, 1439)).apply()
    var tahajudCustomEnabled: Boolean get() = sp.getBoolean("tahajud_custom_enabled", false); set(v) = sp.edit().putBoolean("tahajud_custom_enabled", v).apply()
    var tahajudCustomMinute: Int get() = sp.getInt("tahajud_custom_minute", 3 * 60).coerceIn(0, 1439); set(v) = sp.edit().putInt("tahajud_custom_minute", v.coerceIn(0, 1439)).apply()
    // Preferensi lama tetap dibaca agar data pengguna versi sebelumnya tidak terhapus.
    var dhuhaAfterSunrise: Int get() = sp.getInt("dhuha_after_sunrise", 20).coerceIn(5, 120); set(v) = sp.edit().putInt("dhuha_after_sunrise", v.coerceIn(5, 120)).apply()
    var tahajudOffset: Int get() = sp.getInt("tahajud_offset", 0).coerceIn(-180, 180); set(v) = sp.edit().putInt("tahajud_offset", v.coerceIn(-180, 180)).apply()
    /** Indeks mengikuti pola pilihan keluaran suara fitur Baterai, Jam, dan Nama Pemanggil:
     * 0 Media, 1 Alarm, 2 Notifikasi, 3 Dering, 4 Aksesibilitas, 5 Panggilan suara, 6 Sistem.
     * Nilai lama 0/1/2 dimigrasikan agar pilihan pengguna sebelumnya tetap setara.
     */
    /** FIX329: pilihan suara azan bawaan: 0 = azan Muamar ZA (versi baru), 1 = azan versi lama. */
    var azanBawaan: Int
        get() = sp.getInt("azan_bawaan_versi", 0).coerceIn(0, 1)
        set(v) = sp.edit().putInt("azan_bawaan_versi", v.coerceIn(0, 1)).apply()

    var volumeMode: Int
        get() {
            if (sp.contains("volume_mode_v2")) return sp.getInt("volume_mode_v2", 1).coerceIn(0, 6)
            if (!sp.contains("volume_mode")) return 1 // default lama: Alarm
            val lama = sp.getInt("volume_mode", 0)
            val baru = when (lama) { 0 -> 1; 1 -> 2; 2 -> 0; else -> 1 }
            sp.edit().putInt("volume_mode_v2", baru).apply()
            return baru
        }
        set(v) { sp.edit().putInt("volume_mode_v2", v.coerceIn(0, 6)).apply() }
    var globalSound: String get() = sp.getString("sound_all", "") ?: ""; set(v) = sp.edit().putString("sound_all", v).apply()
    fun reminder(name: String): Boolean = sp.getBoolean(("reminder_" + (name)), true)
    fun setReminder(name: String, value: Boolean) { sp.edit().putBoolean(("reminder_" + (name)), value).apply() }
    // Pengingat pendahuluan untuk lima salat wajib, terpisah dari pengingat/azan pada waktunya.
    // FIX277: Iqomah setelah azan; nonaktif secara bawaan. Menit dihitung dari waktu masuk sholat (waktu azan), bukan dari akhir azan.
    fun iqomahAktif(name: String): Boolean = sp.getBoolean("iqomah_aktif_" + name, false)
    fun setIqomahAktif(name: String, value: Boolean) { sp.edit().putBoolean("iqomah_aktif_" + name, value).apply() }
    fun iqomahMenitBawaan(name: String): Int = when (name) { "subuh" -> 15; "maghrib" -> 7; else -> 10 }
    fun iqomahMenit(name: String): Int = sp.getInt("iqomah_menit_" + name, iqomahMenitBawaan(name)).let { if (it in PILIHAN_IQOMAH) it else iqomahMenitBawaan(name) }
    fun setIqomahMenit(name: String, value: Int) { sp.edit().putInt("iqomah_menit_" + name, if (value in PILIHAN_IQOMAH) value else iqomahMenitBawaan(name)).apply() }

    // FIX264: Tarhim sebelum salat; nonaktif secara bawaan, menit = berapa menit sebelum waktu salat Tarhim mulai diputar.
    fun tarhimAktif(name: String): Boolean = sp.getBoolean("tarhim_aktif_" + name, false)
    fun setTarhimAktif(name: String, value: Boolean) { sp.edit().putBoolean("tarhim_aktif_" + name, value).apply() }
    /** FIX315: berkas audio Tarhim buatan pengguna per waktu salat (URI teks); kosong = Tarhim bawaan aplikasi. */
    fun tarhimBerkas(name: String): String = sp.getString("tarhim_berkas_" + name, "") ?: ""
    fun setTarhimBerkas(name: String, value: String) { sp.edit().putString("tarhim_berkas_" + name, value).apply() }
    /** FIX330: 0 = otomatis (Tarhim diputar penuh dan selesai sekitar 45 detik sebelum azan, mengikuti durasi berkas); bawaan 0. */
    fun tarhimMenit(name: String): Int = sp.getInt("tarhim_menit_" + name, 0).let { if (it in listOf(0, 10, 15, 20, 30, 45, 60)) it else 0 }
    fun setTarhimMenit(name: String, value: Int) { sp.edit().putInt("tarhim_menit_" + name, if (value in listOf(0, 10, 15, 20, 30, 45, 60)) value else 0).apply() }

    fun advanceReminder(name: String): Boolean = sp.getBoolean(("advance_reminder_" + (name)), true)
    fun setAdvanceReminder(name: String, value: Boolean) { sp.edit().putBoolean(("advance_reminder_" + (name)), value).apply() }
    fun advanceMinutes(name: String): Int = sp.getInt(("advance_minutes_" + (name)), 5).let { if (it in listOf(5, 10, 15, 30)) it else 5 }
    fun setAdvanceMinutes(name: String, value: Int) { sp.edit().putInt(("advance_minutes_" + (name)), if (value in listOf(5, 10, 15, 30)) value else 5).apply() }
    // Melodi pengingat pendahuluan salat; indeks 0 = tanpa melodi, 1..17 mengikuti katalog global.
    fun advanceMelodyBefore(name: String): Int = sp.getInt(("advance_melody_before_" + name), 0).coerceIn(0, 17)
    fun setAdvanceMelodyBefore(name: String, value: Int) { sp.edit().putInt(("advance_melody_before_" + name), value.coerceIn(0, 17)).apply() }
    fun advanceMelodyAfter(name: String): Int = sp.getInt(("advance_melody_after_" + name), 0).coerceIn(0, 17)
    fun setAdvanceMelodyAfter(name: String, value: Int) { sp.edit().putInt(("advance_melody_after_" + name), value.coerceIn(0, 17)).apply() }
    // Melodi sebelum/sesudah pengingat waktu khusus: Imsak, terbit, Dhuha, dan Tahajud.
    // Indeks 0 = tanpa melodi; indeks 1..17 mengikuti katalog R.array.jam_melodi.
    fun reminderMelodyBefore(name: String): Int = sp.getInt(("reminder_melody_before_" + name), 0).coerceIn(0, 17)
    fun setReminderMelodyBefore(name: String, value: Int) { sp.edit().putInt(("reminder_melody_before_" + name), value.coerceIn(0, 17)).apply() }
    fun reminderMelodyAfter(name: String): Int = sp.getInt(("reminder_melody_after_" + name), 0).coerceIn(0, 17)
    fun setReminderMelodyAfter(name: String, value: Int) { sp.edit().putInt(("reminder_melody_after_" + name), value.coerceIn(0, 17)).apply() }
    // Mode suara pengingat sebelum salat: 0 = suara bicara standar Android,
    // 1 = audio pengingat bawaan aplikasi, 2 = berkas audio pilihan pengguna.
    // Preferensi lama yang sudah menyimpan URI otomatis tetap dianggap pilihan pengguna.
    fun advanceSound(name: String): String = sp.getString(("advance_sound_" + (name)), "") ?: ""
    fun setAdvanceSound(name: String, value: String) { sp.edit().putString(("advance_sound_" + (name)), value).apply() }
    fun advanceSoundMode(name: String): Int {
        if (!sp.contains(("advance_sound_mode_" + (name)))) return if (advanceSound(name).isNotBlank()) 2 else 0
        return sp.getInt(("advance_sound_mode_" + (name)), 0).coerceIn(0, 2)
    }
    fun setAdvanceSoundMode(name: String, value: Int) { sp.edit().putInt(("advance_sound_mode_" + (name)), value.coerceIn(0, 2)).apply() }
    fun adjustment(name: String): Int = sp.getInt(("adjust_" + (name)), 0).coerceIn(-30, 30)
    fun setAdjustment(name: String, value: Int) { sp.edit().putInt(("adjust_" + (name)), value.coerceIn(-30, 30)).apply() }
    fun sound(name: String): String = sp.getString(("sound_" + (name)), "") ?: ""
    fun setSound(name: String, value: String) { sp.edit().putString(("sound_" + (name)), value).apply() }
    // Pilihan sumber suara khusus Imsak dan matahari terbit:
    // 0 = azan bawaan/berkas umum, 1 = audio pengingat yang disematkan, 2 = berkas mandiri pengguna.
    // Pada instalasi lama, URI yang sudah dipilih tetap dianggap sebagai suara mandiri.
    fun reminderSoundMode(name: String): Int {
        // Mode bawaan untuk instalasi baru: audio Imsak, terbit, Dhuha, sahur, dan berbuka yang disematkan.
        // Pilihan yang sudah tersimpan oleh pengguna tetap dihormati.
        if (!sp.contains(("reminder_sound_mode_" + (name)))) {
            if (sound(name).isNotBlank()) return 2
            return when (name) {
                "imsak", "terbit", "dhuha" -> 1 // audio pengingat bawaan aplikasi
                "tahajud" -> if (AudioBawaanPengingat.id(konteksAplikasi, "tahajud") > 0) 1 else 0 // FIX238
                "sahur", "berbuka" -> 3 // audio pemberitahuan khusus bawaan aplikasi
                else -> 0
            }
        }
        return sp.getInt(("reminder_sound_mode_" + (name)), 0).coerceIn(0, 3)
    }
    fun setReminderSoundMode(name: String, value: Int) {
        sp.edit().putInt(("reminder_sound_mode_" + (name)), value.coerceIn(0, 3)).apply()
    }
    // FIX300: volume mandiri (pengali 0..100 persen pada pemutar) dan efek gema per fitur bersuara.
    // Kunci: azan_<waktu> (subuh, dzuhur, ashar, maghrib, isya, imsak, terbit, dhuha, tahajud), advance_<waktu>, tarhim_<waktu>, iqomah_<waktu>, sahur, berbuka.
    fun volumeMandiri(k: String): Int = sp.getInt("vm_" + k, 100).coerceIn(0, 100)
    fun setVolumeMandiri(k: String, v: Int) { sp.edit().putInt("vm_" + k, v.coerceIn(0, 100)).apply() }
    fun gemaMandiri(k: String): String = sp.getString("gm_" + k, "normal")?.takeIf { GemaAudio.sah(it) } ?: "normal"
    fun setGemaMandiri(k: String, v: String) { sp.edit().putString("gm_" + k, if (GemaAudio.sah(v)) v else "normal").apply() }
    fun gemaKekuatan(k: String): Int = sp.getInt("gk_" + k, 60).coerceIn(0, 100)
    fun setGemaKekuatan(k: String, v: Int) { sp.edit().putInt("gk_" + k, v.coerceIn(0, 100)).apply() }
    fun adjustments() = intArrayOf(adjustment("imsak"), adjustment("subuh"), adjustment("terbit"), 0, adjustment("dzuhur"), adjustment("ashar"), adjustment("maghrib"), adjustment("isya"))
    companion object {
        /** FIX126: pilihan durasi Mode Jangan Ganggu otomatis saat salat (menit). Satu sumber untuk penyimpanan dan layar pengaturan. */
        val DURASI_DND_MENIT: List<Int> = listOf(5, 10, 15, 30, 45, 60)
        val DURASI_DND_JUMAT_MENIT: List<Int> = listOf(15, 20, 30, 45, 60, 75, 90, 120)
        val PILIHAN_SAHUR_MENIT: List<Int> = listOf(15, 30, 45, 60, 75, 90, 105, 120)
        /** FIX277: pilihan jarak iqomah dari waktu azan (menit); minimal 5 karena azan bawaan berdurasi sekitar 4 menit. */
        val PILIHAN_IQOMAH: List<Int> = listOf(3, 5, 7, 8, 10, 12, 15, 20, 25, 30, 35, 40, 45, 60)
    }
}
