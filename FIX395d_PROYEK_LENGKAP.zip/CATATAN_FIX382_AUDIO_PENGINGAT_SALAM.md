# FIX382
Audio res/raw diganti (nama resource tetap; m4a lama dihapus). Sahur: pemberitahuan_sahur (Ramadan) dan pemberitahuan_sahur_sunnah dipilih menurut fastingType. Salam buka/tutup via Prefs.salamBukaTutup, Pembicara terpisah saat ditutup.
Belum dikompilasi dengan Gradle / belum diuji di perangkat. Ucapan Arab tergantung mesin TTS.
