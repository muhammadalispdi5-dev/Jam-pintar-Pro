# FIX390
KoleksiMtq.jenis/kataCari; PerintahSuara.Jenis.MTQ_DRIVE (prioritas 96, setelah WAKTU_DUNIA di tafsirSatu); PerintahSuaraActivity.bukaKoleksiMtq -> MtqDriveActivity extra folder/nama/cari; MtqDriveActivity memutar berkas yang kata kuncinya paling cocok setelah daftar tersedia. Berhenti/jeda lewat tombol halaman (belum lewat perintah suara).
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
