# FIX391
NotifSholat.kt (judul 'Nama di HH.mm di (tempat) bendera', hadits sahih terkurasi per waktu, bergantian per hari); PrayerAlarmService notifikasi azan memakai judul dan BigTextStyle. Hadits ditulis dari pengetahuan umum dan BELUM diverifikasi ulang terhadap kitabnya; periksa sebelum rilis.
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
