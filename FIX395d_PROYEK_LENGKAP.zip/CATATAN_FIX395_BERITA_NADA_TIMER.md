# FIX395
- Timer: jawaban tegas tanpa templat "$" ("Timer 5 menit dimulai. Timer akan berbunyi pukul ...").
- Pengingat sebelum salat: BigText berisi hadits sahih (NotifSholat).
- Nada suara: NadaAudio (Equalizer/BassBoost untuk radio/TV, TonDsp untuk murattal), saklar Mono murattal.
- Radio/TV: urutan negara pengguna, Arab Saudi, lainnya; kategori; saklar layar TV tetap menyala.
- Berita Islam: BeritaData/BeritaIslamActivity, updates/sumber_berita.txt.
- Catatan pembaruan: terbaru di atas (aturan tetap).
- Belum dikompilasi dengan Gradle / belum diuji di perangkat; alamat RSS belum diverifikasi.
