# FIX377
Gempa luar Indonesia lewat USGS (GempaDunia.kt) bila lokasi sholat tersimpan di luar kotak Indonesia; Indonesia tetap BMKG. Alamat USGS FDSN event ditulis dari pengetahuan umum dan tidak dapat diperiksa dari sini. Belum dikompilasi / belum diuji di perangkat.
