# FIX393
RadioTvData.kandidat/layak/pindai/hasilPindai; RadioTvActivity tombol Pindai dan Batalkan; hasil disimpan di prefs radio_tv (pindai_tv, pindai_radio) dan digabung dengan daftar daring. Pemeriksaan: HTTP 200-206, jenis isi dan 2 KB awal (TV: #EXTM3U/video; radio: audio/*), 8 utas paralel, redirect manual.
BELUM terbukti: aliran Shoutcast berformat ICY bisa gagal diperiksa oleh HttpURLConnection; durasi dan jumlah hasil nyata; sumber kandidat sama dengan FIX392 (iptv-org, Radio Browser).
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
