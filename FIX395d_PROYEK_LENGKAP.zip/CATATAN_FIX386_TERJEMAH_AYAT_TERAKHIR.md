# FIX386
Penyebab belum terbukti: ekor gema/penuntasan pemutar pada ayat terakhir. FIX384 sudah membuat ekor 0; FIX386 menambah pemicu terjemahan ~150 ms sebelum audio habis (pemantauSerahTerima) dengan penjaga terjemahSudahMulaiIndeks agar tidak terbaca dua kali.
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
