# FIX394
Versi 1.0.96 (kode 96). TvPemutarActivity ditulis ulang: bingkai hitam dengan VideoView, layar penuh mendatar (tanpa TalkBack otomatis; dengan TalkBack lewat tombol), baris kontrol (Jeda, Vol-, Vol+, Senyap), live region untuk status, info buffering, fokus audio, layar tetap menyala, configChanges di manifest agar putaran tidak memulai ulang siaran. Radio: tombol volume dan 'Radio yang sedang diputar', status live region.
Belum dikompilasi dengan Gradle / belum diuji di perangkat. Dugaan 'ceramah' = 'ramah' (ramah TalkBack).
