#!/usr/bin/env python3
"""Validasi sumber Khatam sebelum Gradle; bukan pengganti kompilasi penuh."""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
errors=[]
def need(ok, msg):
    if not ok: errors.append(msg)
p=root/"app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt"
if not p.is_file(): errors.append("KhatamActivity.kt tidak ditemukan pada app/src/main/java/...")
else:
    code=p.read_text(encoding="utf-8")
    for n in ("bukaAyatTersimpan","tandaiPosisi","pengaturanTarget","tampilkanStatistik","pengaturanPengingat","pengaturanAksesibilitas","tampilkanRiwayat","dialogBelumAdaTeks","tampilkanPembaca"):
        need(re.search(r"\bfun\s+"+re.escape(n)+r"\s*\(",code) is not None, "Fungsi "+n+" tidak ditemukan")
    for token in ("SSrl4i7kMxObpgmjUH","rrqdmzFtNspt","okcCA9","rEUrQgA","oJ7hR1Pmal1KQ8tRt","KECrdq4VXdW1eabhQaLzg1wiPxlw","lyuFWGJIhtbNFyIjf8tlw","FlcaQsM5DqPsX4EWzY1oslp2xmHnVzyKShCg"):
        need(token not in code, "Kode acak mencurigakan ditemukan: "+token)
for rel in ("app/src/main/res/values/strings.xml","app/src/main/res/values-en/strings.xml"):
    p=root/rel
    try:
        ET.parse(p); raw=p.read_text(encoding="utf-8")
        need(re.search(r"\\u(?![0-9a-fA-F]{4})",raw) is None, "Escape Unicode tidak valid di "+rel)
        vals={e.get("name") for e in ET.parse(p).getroot().findall("string")}
        for key in ("khatam_menu","khatam_judul"): need(key in vals,key+" hilang di "+rel)
    except Exception as exc: errors.append("XML tidak valid di "+rel+": "+str(exc))
if errors:
    print("PEMERIKSAAN KHATAM: GAGAL")
    for e in errors: print("- "+e)
    sys.exit(1)
print("PEMERIKSAAN KHATAM: LULUS — fungsi ada, tidak ditemukan token acak yang dikenal, XML valid.")
