# Perbaikan kompilasi Khatam Al-Qur'an — FIX25

Versi aplikasi tetap 1.0.69 (`versionCode 69`).

Perbaikan:
- Menyederhanakan pembentukan label daftar surah agar tidak menggunakan ekspresi interpolasi bertingkat yang rentan rusak saat penyalinan.
- Memastikan seluruh fungsi menu Khatam yang dipanggil tersedia sebagai fungsi privat di `KhatamActivity`.
- Mengganti apostrof pada dua string sumber daya Khatam menjadi entitas XML `&apos;` untuk menghindari salah penulisan escape.
- Memperbaiki pembentukan kunci riwayat harian agar tanggal dimasukkan sebagai hasil pemanggilan fungsi, tanpa tanda kurung yang tertinggal.
- Memvalidasi XML sumber daya, versi, daftar fungsi, dan tidak adanya pola escape Unicode yang tidak lengkap.

Pemeriksaan statis proyek dan audit akhir lulus. Kompilasi Gradle penuh belum dapat dijalankan di lingkungan pembuatan arsip ini; hasil build GitHub Actions tetap harus diperiksa.
