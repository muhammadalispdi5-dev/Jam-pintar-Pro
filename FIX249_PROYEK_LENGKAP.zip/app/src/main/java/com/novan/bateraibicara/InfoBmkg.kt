package com.novan.bateraibicara

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * FIX217: informasi BMKG langsung dari data terbuka resmi BMKG, tanpa cache (selalu diunduh saat diminta):
 *  - gempa terbaru (autogempa.json), gempa M5.0+ (gempaterkini.json), gempa dirasakan (gempadirasakan.json), potensi tsunami (kolom Potensi);
 *  - peringatan dini cuaca (RSS nowcast per provinsi + berkas CAP).
 * Isi kolom BMKG diucapkan apa adanya (tidak ditafsirkan ulang). Sumber wajib disebut: BMKG.
 */
object InfoBmkg {
    enum class Jenis { GEMPA_TERBARU, GEMPA_M5, GEMPA_DIRASAKAN, TSUNAMI, PERINGATAN_DINI, RINGKASAN }

    // Sengaja val biasa (bukan const): kompiler CI menolak const val berisi alamat https:// (lihat tools/periksa_const_val.py).
    val URL_AUTOGEMPA = "https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json"
    val URL_GEMPA_M5 = "https://data.bmkg.go.id/DataMKG/TEWS/gempaterkini.json"
    val URL_GEMPA_DIRASAKAN = "https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json"
    val URL_NOWCAST = "https://www.bmkg.go.id/alerts/nowcast/id"

    fun token(ucapan: String): List<String> =
        ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(' ').filter { it.isNotEmpty() }

    private val kataGempa = setOf("gempa", "gempabumi", "gempaan", "earthquake", "earthquakes", "quake", "quakes", "lindu")

    /** Null bila ucapan bukan permintaan informasi BMKG (mis. "cuaca hari ini" tetap ditangani fitur cuaca). */
    fun jenisDari(t: List<String>): Jenis? {
        val teks = " " + t.joinToString(" ") + " "
        val gempa = t.any { it in kataGempa } || teks.contains(" gempa bumi ") || teks.contains(" earth quake ")
        if (t.any { it == "tsunami" || it == "tsunamis" }) return Jenis.TSUNAMI
        if (gempa) {
            if (t.any { it in setOf("dirasakan", "dirasa", "terasa", "dirasakannya", "felt") }) return Jenis.GEMPA_DIRASAKAN
            // "gempa terkini/terbaru/terakhir" = satu gempa paling baru; daftar M5.0+ hanya bila diminta jelas.
            val sebutLima = (t.contains("5") || t.contains("lima")) && t.any { it in setOf("lebih", "atas", "above", "plus", "mulai") }
            val minta = t.any { it in setOf("daftar", "list", "beberapa", "semua", "m5", "magnitudo5") }
            return if (sebutLima || minta) Jenis.GEMPA_M5 else Jenis.GEMPA_TERBARU
        }
        val peringatan = (t.contains("peringatan") && t.contains("dini")) || teks.contains(" cuaca ekstrem ") || teks.contains(" cuaca ekstream ") ||
            t.contains("nowcast") || (t.contains("early") && t.contains("warning")) || (t.contains("severe") && t.contains("weather")) ||
            (t.contains("waspada") && t.any { it in setOf("hujan", "petir", "angin", "cuaca", "banjir", "puting") })
        if (peringatan) return Jenis.PERINGATAN_DINI
        if (t.contains("bmkg") && t.none { it in setOf("cuaca", "weather", "prakiraan", "forecast", "suhu", "hujan") }) return Jenis.RINGKASAN
        return null
    }

    /** Nama wilayah yang disebut pengguna ("peringatan dini di Jawa Barat"); null bila tidak disebut. */
    fun wilayahDariUcapan(t: List<String>): String? {
        val penanda = setOf("di", "untuk", "wilayah", "provinsi", "kota", "kabupaten", "in", "for")
        val henti = setOf("saat", "ini", "sekarang", "hari", "terkini", "terbaru", "bmkg", "dong", "ya", "tolong", "please", "now", "today", "yang", "aktif", "ada")
        val i = t.indexOfFirst { it in penanda }
        if (i < 0) return null
        val sisa = t.drop(i + 1).filter { it !in penanda }.takeWhile { it !in henti }
        return sisa.joinToString(" ").ifBlank { null }
    }

    // ---------- jaringan ----------

    private fun ambil(alamat: String): String {
        var k: HttpURLConnection? = null
        try {
            val sambung = if (alamat.contains('?')) "&" else "?"
            k = (URL(alamat + sambung + "_=" + System.currentTimeMillis()).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 10_000; readTimeout = 15_000; useCaches = false
                setRequestProperty("Cache-Control", "no-cache"); setRequestProperty("Pragma", "no-cache")
                setRequestProperty("Accept", "application/json, application/xml, text/xml, */*")
                setRequestProperty("User-Agent", "JamPintarPro/1.0.88 (Android)")
            }
            val kode = k.responseCode
            if (kode !in 200..299) throw java.io.IOException("HTTP_STATUS:$kode")
            return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            try { k?.disconnect() } catch (_: Exception) { }
        }
    }

    // ---------- gempa ----------

    data class Gempa(
        val tanggal: String, val jam: String, val dateTime: String, val magnitude: String, val kedalaman: String,
        val wilayah: String, val potensi: String, val dirasakan: String
    )

    fun parseGempa(json: String): List<Gempa> {
        val g = JSONObject(json).optJSONObject("Infogempa")?.opt("gempa")
        val daftar = when (g) {
            is JSONArray -> (0 until g.length()).mapNotNull { g.optJSONObject(it) }
            is JSONObject -> listOf(g)
            else -> emptyList()
        }
        return daftar.map {
            Gempa(
                it.optString("Tanggal").trim(), it.optString("Jam").trim(), it.optString("DateTime").trim(),
                it.optString("Magnitude").trim(), it.optString("Kedalaman").trim(), it.optString("Wilayah").trim(),
                it.optString("Potensi").trim(), it.optString("Dirasakan").trim()
            )
        }.filter { it.magnitude.isNotEmpty() || it.wilayah.isNotEmpty() }
    }

    private fun desimal(angka: String, english: Boolean) = if (english) angka else angka.replace('.', ',')

    /** "BaratDaya" -> "Barat Daya", "10 km" -> "10 kilometer" supaya terbaca jelas oleh pembaca layar dan suara. */
    private fun rapikanWilayah(s: String) = s.replace(Regex("(?<=[a-z])(?=[A-Z])"), " ").replace(Regex("\\s+"), " ").trim()

    private fun kedalamanUcap(s: String, english: Boolean): String =
        s.replace(Regex("(?i)\\s*km\\b"), if (english) " kilometers" else " kilometer").let { desimal(it, english) }

    private fun jamUcap(s: String) = s.replace(':', '.')

    fun umur(dateTime: String, sekarang: OffsetDateTime = OffsetDateTime.now(), english: Boolean): String? {
        val waktu = try { OffsetDateTime.parse(dateTime) } catch (_: Exception) { return null }
        val menit = Duration.between(waktu, sekarang).toMinutes()
        if (menit < 0) return null
        return when {
            menit < 1 -> if (english) "less than a minute ago" else "kurang dari satu menit lalu"
            menit < 60 -> if (english) "$menit minutes ago" else "$menit menit lalu"
            menit < 48 * 60 -> if (english) "${menit / 60} hours ago" else "${menit / 60} jam lalu"
            else -> if (english) "${menit / 1440} days ago" else "${menit / 1440} hari lalu"
        }
    }

    fun ucapGempa(g: Gempa, english: Boolean, sekarang: OffsetDateTime = OffsetDateTime.now(), lengkap: Boolean = true): String {
        val umur = umur(g.dateTime, sekarang, english)
        val b = StringBuilder()
        if (english) {
            b.append("Date ").append(g.tanggal).append(", time ").append(jamUcap(g.jam))
            if (umur != null) b.append(", ").append(umur)
            b.append(". Magnitude ").append(desimal(g.magnitude, true)).append(". Depth ").append(kedalamanUcap(g.kedalaman, true)).append(". ")
            b.append("Location per BMKG, in Indonesian: ").append(rapikanWilayah(g.wilayah)).append('.')
            if (lengkap && g.potensi.isNotEmpty()) b.append(" Potential per BMKG: ").append(g.potensi).append('.')
            if (lengkap && g.dirasakan.isNotEmpty()) b.append(" Felt (MMI scale): ").append(g.dirasakan).append('.')
        } else {
            b.append("Tanggal ").append(g.tanggal).append(", pukul ").append(jamUcap(g.jam))
            if (umur != null) b.append(", ").append(umur)
            b.append(". Magnitudo ").append(desimal(g.magnitude, false)).append(". Kedalaman ").append(kedalamanUcap(g.kedalaman, false)).append(". ")
            b.append(rapikanWilayah(g.wilayah)).append('.')
            if (lengkap && g.potensi.isNotEmpty()) b.append(" Potensi: ").append(g.potensi).append('.')
            if (lengkap && g.dirasakan.isNotEmpty()) b.append(" Dirasakan menurut skala MMI: ").append(g.dirasakan).append('.')
        }
        return b.toString()
    }

    private fun tr(english: Boolean, id: String, en: String) = if (english) en else id

    private fun sumber(english: Boolean) = if (english) " Source: BMKG." else " Sumber: BMKG."

    fun gempaTerbaru(english: Boolean): String {
        val g = parseGempa(ambil(URL_AUTOGEMPA)).firstOrNull()
            ?: return if (english) "BMKG did not return earthquake data right now." + sumber(true) else "BMKG belum mengirim data gempa saat ini." + sumber(false)
        return (if (english) "Latest earthquake from BMKG. " else "Gempa terbaru menurut BMKG. ") + ucapGempa(g, english) + sumber(english)
    }

    fun tsunami(english: Boolean): String {
        val g = parseGempa(ambil(URL_AUTOGEMPA)).firstOrNull()
            ?: return if (english) "BMKG did not return earthquake data right now." + sumber(true) else "BMKG belum mengirim data gempa saat ini." + sumber(false)
        val potensi = g.potensi.ifBlank { if (english) "not stated" else "tidak dinyatakan" }
        val kalimat = tr(english,
            "Pada gempa terbaru, magnitudo " + desimal(g.magnitude, false) + ", " + rapikanWilayah(g.wilayah) + ", BMKG menyatakan potensinya: " + potensi +
                ". Untuk peringatan tsunami resmi, selalu ikuti arahan BMKG dan pihak berwenang setempat.",
            "On the latest earthquake, magnitude " + desimal(g.magnitude, true) + ", " + rapikanWilayah(g.wilayah) + ", BMKG states the potential as: " + potensi +
                ". For official tsunami warnings always follow BMKG instructions and local authorities.")
        return kalimat + sumber(english)
    }

    private fun daftarGempa(url: String, english: Boolean, judulId: String, judulEn: String, kosongId: String, kosongEn: String): String {
        val daftar = parseGempa(ambil(url)).take(3)
        if (daftar.isEmpty()) return (if (english) kosongEn else kosongId) + sumber(english)
        val b = StringBuilder(if (english) judulEn else judulId).append(' ')
        daftar.forEachIndexed { i, g -> b.append(if (english) "Number " else "Nomor ").append(i + 1).append(". ").append(ucapGempa(g, english, lengkap = false)).append(' ') }
        return b.toString().trim() + sumber(english)
    }

    fun gempaM5(english: Boolean) = daftarGempa(URL_GEMPA_M5, english,
        "Tiga gempa terbaru bermagnitudo 5,0 atau lebih menurut BMKG.", "The three latest earthquakes of magnitude 5.0 or more per BMKG.",
        "BMKG belum mengirim daftar gempa bermagnitudo 5,0 atau lebih.", "BMKG did not return a list of magnitude 5.0 or more earthquakes.")

    fun gempaDirasakan(english: Boolean): String {
        val daftar = parseGempa(ambil(URL_GEMPA_DIRASAKAN)).take(3)
        if (daftar.isEmpty()) return (if (english) "BMKG did not return felt-earthquake data." else "BMKG belum mengirim data gempa dirasakan.") + sumber(english)
        val b = StringBuilder(if (english) "Three latest felt earthquakes per BMKG. " else "Tiga gempa dirasakan terbaru menurut BMKG. ")
        daftar.forEachIndexed { i, g ->
            b.append(if (english) "Number " else "Nomor ").append(i + 1).append(". ").append(ucapGempa(g, english, lengkap = false))
            if (g.dirasakan.isNotEmpty()) b.append(if (english) " Felt (MMI scale): " else " Dirasakan menurut skala MMI: ").append(g.dirasakan).append('.')
            b.append(' ')
        }
        return b.toString().trim() + sumber(english)
    }

    // ---------- peringatan dini cuaca ----------

    data class ItemPeringatan(val judul: String, val tautan: String, val deskripsi: String, val terbit: String)

    private fun isiTag(xml: String, nama: String): String? {
        val m = Regex("<" + nama + "(?:\\s[^>]*)?>(.*?)</" + nama + ">", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(xml) ?: return null
        return m.groupValues[1].replace(Regex("^\\s*<!\\[CDATA\\[|]]>\\s*$"), "").replace(Regex("<[^>]+>"), " ")
            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
            .replace(Regex("\\s+"), " ").trim().ifEmpty { null }
    }

    fun parseNowcast(rss: String): Pair<List<ItemPeringatan>, String?> {
        val item = Regex("<item>(.*?)</item>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).findAll(rss).map { it.groupValues[1] }
            .map { ItemPeringatan(isiTag(it, "title").orEmpty(), isiTag(it, "link").orEmpty(), isiTag(it, "description").orEmpty(), isiTag(it, "pubDate").orEmpty()) }
            .filter { it.judul.isNotEmpty() || it.deskripsi.isNotEmpty() }.toList()
        return item to isiTag(rss.substringBefore("<item>"), "lastBuildDate")
    }

    private val kataUmumWilayah = setOf("kota", "kabupaten", "kab", "provinsi", "prov", "kecamatan", "kelurahan", "desa", "daerah", "kec", "kel")

    /** Bagian-bagian nama wilayah untuk dicocokkan ("Cibeunying, Kota Bandung, Jawa Barat" -> cibeunying, bandung, jawa barat). */
    fun bagianWilayah(wilayah: String): List<String> =
        wilayah.lowercase().split(',').map { bagian -> bagian.split(' ').filter { it.isNotBlank() && it !in kataUmumWilayah }.joinToString(" ").trim() }
            .filter { it.length >= 4 }.distinct()

    fun cocok(item: ItemPeringatan, bagian: List<String>): Boolean {
        val teks = (item.judul + " " + item.deskripsi).lowercase()
        return bagian.any { teks.contains(it) }
    }

    private fun waktuLokal(iso: String?, english: Boolean): String? {
        if (iso.isNullOrBlank()) return null
        return try {
            val w = OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault())
            w.format(DateTimeFormatter.ofPattern(if (english) "d MMM yyyy 'at' HH.mm" else "d MMM yyyy 'pukul' HH.mm", if (english) Locale.US else Locale("id", "ID")))
        } catch (_: Exception) { null }
    }

    private fun potong(s: String, maks: Int) = if (s.length <= maks) s else s.substring(0, maks).substringBeforeLast(' ') + "..."

    fun peringatanDini(wilayah: String?, english: Boolean): String {
        val (semua, pembaruan) = parseNowcast(ambil(URL_NOWCAST))
        val pembaruanTeks = pembaruan?.let { (if (english) " BMKG feed updated " else " Data BMKG diperbarui ") + it + "." }.orEmpty()
        if (semua.isEmpty()) {
            return (if (english) "BMKG currently lists no active weather early warnings." else "Saat ini BMKG tidak mencantumkan peringatan dini cuaca yang aktif.") + pembaruanTeks + sumber(english)
        }
        val bagian = wilayah?.let { bagianWilayah(it) }.orEmpty()
        if (bagian.isEmpty()) {
            val judul = semua.take(3).joinToString("; ") { it.judul.ifBlank { potong(it.deskripsi, 80) } }
            return (if (english) "BMKG lists " + semua.size + " active weather early warnings nationwide. Examples: "
                else "BMKG mencantumkan " + semua.size + " peringatan dini cuaca aktif di Indonesia. Contoh: ") + judul + "." + pembaruanTeks +
                (if (english) " Say early warning for your province to hear the details." else " Ucapkan peringatan dini untuk nama provinsi Anda untuk rinciannya.") + sumber(english)
        }
        val terpilih = semua.filter { cocok(it, bagian) }
        val nama = wilayah!!.split(',').map { it.trim() }.filter { it.isNotEmpty() }.takeLast(2).joinToString(", ")
        if (terpilih.isEmpty()) {
            return (if (english) "No active BMKG weather early warning mentions $nama. The match is by area name; check bmkg.go.id for certainty. There are " + semua.size + " active warnings elsewhere in Indonesia."
                else "Tidak ditemukan peringatan dini cuaca BMKG aktif yang menyebut $nama. Pencocokan berdasarkan nama wilayah; periksa bmkg.go.id untuk kepastian. Ada " + semua.size + " peringatan aktif di wilayah lain Indonesia.") +
                pembaruanTeks + sumber(english)
        }
        val b = StringBuilder(if (english) "BMKG weather early warning for $nama. " else "Peringatan dini cuaca BMKG untuk $nama. ")
        terpilih.take(3).forEachIndexed { i, item ->
            var cap: String? = null
            if (item.tautan.startsWith("https://")) cap = try { ambil(item.tautan) } catch (_: Exception) { null }
            val judul = (cap?.let { isiTag(it, "headline") } ?: item.judul).trim()
            val uraian = (cap?.let { isiTag(it, "description") } ?: item.deskripsi).trim()
            val mulai = waktuLokal(cap?.let { isiTag(it, "effective") }, english)
            val berakhir = waktuLokal(cap?.let { isiTag(it, "expires") }, english)
            b.append(if (english) "Warning " else "Peringatan ").append(i + 1).append(". ").append(judul).append(". ").append(potong(uraian, 400)).append(". ")
            if (mulai != null) b.append(if (english) "Valid from " else "Berlaku mulai ").append(mulai).append(". ")
            if (berakhir != null) b.append(if (english) "Until " else "Sampai ").append(berakhir).append(". ")
        }
        if (terpilih.size > 3) b.append(if (english) "And " else "Dan ").append(terpilih.size - 3).append(if (english) " more warnings." else " peringatan lain.")
        return b.toString().trim() + pembaruanTeks + sumber(english)
    }

    /** FIX225: satu kalimat bila BMKG mencantumkan peringatan dini aktif yang menyebut wilayah ini; null bila tidak ada atau gagal. */
    fun peringatanSingkat(wilayah: String?, english: Boolean): String? = try {
        val bagian = wilayah?.let { bagianWilayah(it) }.orEmpty()
        if (bagian.isEmpty()) null else {
            val cocokan = parseNowcast(ambil(URL_NOWCAST)).first.filter { cocok(it, bagian) }
            if (cocokan.isEmpty()) null else tr(english,
                "Perhatian: BMKG mencantumkan " + cocokan.size + " peringatan dini cuaca aktif yang menyebut wilayah ini. Ucapkan peringatan dini untuk mendengar rinciannya.",
                "Attention: BMKG lists " + cocokan.size + " active weather early warnings mentioning this area. Say early warning to hear the details.")
        }
    } catch (_: Exception) { null }

    /** Teks lengkap untuk satu permintaan. Blokir: panggil dari thread latar. */
    fun laporan(jenis: Jenis, wilayah: String?, english: Boolean): String = try {
        when (jenis) {
            Jenis.GEMPA_TERBARU -> gempaTerbaru(english)
            Jenis.GEMPA_M5 -> gempaM5(english)
            Jenis.GEMPA_DIRASAKAN -> gempaDirasakan(english)
            Jenis.TSUNAMI -> tsunami(english)
            Jenis.PERINGATAN_DINI -> peringatanDini(wilayah, english)
            Jenis.RINGKASAN -> {
                val gempa = try { gempaTerbaru(english) } catch (_: Exception) { "" }
                val peringatan = try { peringatanDini(wilayah, english) } catch (_: Exception) { "" }
                (gempa + " " + peringatan).trim().ifEmpty { throw java.io.IOException("kosong") }
            }
        }
    } catch (e: Exception) {
        val status = e.message?.removePrefix("HTTP_STATUS:")?.toIntOrNull()
        when {
            status == 429 -> if (english) "BMKG is limiting requests right now. Please wait a moment and try again." else "BMKG sedang membatasi jumlah permintaan. Tunggu sebentar, lalu coba lagi."
            status != null -> if (english) "The BMKG server answered with an error (code $status). Try again later." else "Server BMKG menjawab dengan kesalahan (kode $status). Coba lagi nanti."
            e is org.json.JSONException -> if (english) "BMKG returned data in a format the app could not read. Try again later." else "BMKG mengirim data dengan format yang tidak dapat dibaca aplikasi. Coba lagi nanti."
            else -> if (english) "BMKG data could not be reached. Check your internet connection and try again." else "Data BMKG tidak dapat dijangkau. Periksa koneksi internet, lalu coba lagi."
        }
    }
}
