import sys,os
B=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","app/src/main/java/com/novan/bateraibicara/")
r=lambda n:open(B+n).read()
def cek(n,k): print(("LULUS " if k else "GAGAL ")+n)
cek("cadangan volume",'hentikanDariVolume' in r('PrayerAlarmService.kt') and 'PrayerAlarmService.hentikanDariVolume' in r('PembungkamTelungkup.kt'))
cek("instansi dikelola",'instansi = this' in r('PrayerAlarmService.kt') and 'instansi === this' in r('PrayerAlarmService.kt'))
sys.exit(0)
