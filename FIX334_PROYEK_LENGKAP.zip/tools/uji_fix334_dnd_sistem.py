import sys,os
R=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
B=R+"/app/src/main/java/com/novan/bateraibicara/"
r=lambda n:open(B+n).read()
def cek(n,k): print(("LULUS " if k else "GAGAL ")+n)
cek("DndSistem ada",'object DndSistem' in r('DndSistem.kt'))
cek("pembicara patuh dnd",'senyapDnd()' in r('Pembicara.kt') and 'patuhDnd = 1' in r('BatteryTalkService.kt') and 'patuhDnd = 2' in r('CallerListener.kt'))
cek("khatam hafalan",'DndSistem.senyap' in r('KhatamReminderReceiver.kt') and 'DndSistem.senyap' in r('HafalanSrsReceiver.kt'))
g=open(R+"/app/build.gradle.kts").read()
cek("versi 1.0.91",'versionCode = 91' in g and 'versionName = "1.0.91"' in g)
