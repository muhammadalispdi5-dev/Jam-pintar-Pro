# FIX265 - Perbaikan kompilasi dari log GitHub Actions (run 43298826240)
Galat: PrayerAlarmService.kt:357 dan :368 "Argument type mismatch: Function0<Unit> but Long expected".
Penyebab: FIX264 menambah parameter batasMs sesudah afterCompletion di playRawSound, sehingga lambda akhir (trailing lambda) di playEmbeddedBerbukaSound/playEmbeddedSahurSound terikat ke batasMs.
Perbaikan: batasMs dipindah sebelum afterCompletion (lambda akhir kembali ke afterCompletion); pemanggil Tarhim memakai batasMs = 480_000L bernama.
Belum dikompilasi dengan Gradle di sini; versi tetap 1.0.88.
