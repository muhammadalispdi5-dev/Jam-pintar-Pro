package com.novan.bateraibicara

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Bahasa tampilan utama dan penerjemahan label buatan kode agar konsisten. */
object BahasaAplikasi {
    fun tampilan(context: Context): Int = context.applicationContext
        .getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        .getInt("bahasa_tampilan", 0).coerceIn(0, 1)

    fun simpanTampilan(context: Context, index: Int) {
        context.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
            .edit().putInt("bahasa_tampilan", index.coerceIn(0, 1)).apply()
    }

    fun bungkus(context: Context): Context {
        val locale = if (tampilan(context) == 1) Locale.ENGLISH else Locale("id", "ID")
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return context.createConfigurationContext(config)
    }

    fun teks(context: Context, source: String): String {
        if (tampilan(context) == 0 || source.isBlank()) return source
        val exact = map[source.trim()]
        if (exact != null) return exact
        // Terjemahkan awalan label dan istilah yang lazim, sambil mempertahankan nama pengguna,
        // waktu, angka, nama lokasi, serta nilai dinamis yang tidak boleh diubah.
        val prefixes = listOf(
            "Jadwal berikutnya:" to "Next schedule:", "Jam mulai:" to "Start time:",
            "Jam selesai:" to "End time:", "Hari aktif:" to "Active days:",
            "Nama lokasi:" to "Location name:", "Lokasi:" to "Location:",
            "Status izin" to "Permission status", "Perkiraan ketelitian" to "Estimated accuracy",
            "Waktu sholat" to "Prayer time", "Waktu salat" to "Prayer time",
            "Tanggal Masehi" to "Gregorian date", "Tanggal Hijriyah" to "Hijri date",
            "Berikutnya" to "Next", "Aktif" to "Enabled", "Tidak aktif" to "Disabled"
        )
        for ((id, en) in prefixes) if (source.startsWith(id)) return en + source.removePrefix(id)
        return source
    }

    private val map = mapOf(
        "Satu Sahabat Suara untuk Waktu, Ibadah, dan Aktivitas Sehari-hari. Dirancang dengan perhatian khusus pada kemudahan penggunaan bagi pengguna tunanetra dan pembaca layar." to "One voice companion for time, worship, and everyday activities. Designed with special care for blind users and screen-reader accessibility.",
        "Pengaturan Bahasa" to "Language Settings", "Bahasa Tampilan Utama" to "Main Display Language",
        "Bahasa Pengucapan" to "Speech Language", "Bahasa Indonesia" to "Indonesian",
        "English" to "English", "Simpan dan terapkan bahasa" to "Save and apply language settings",
        "Bahasa tampilan mengubah bahasa antarmuka aplikasi. Bahasa pengucapan mengatur bahasa suara untuk fitur yang mendukungnya." to "The display language changes the app interface. The speech language sets the spoken language for supported features.",
        "Baterai" to "Battery", "Jam" to "Clock", "Kalender" to "Calendar", "Nama Pemanggil" to "Caller Name",
        "Jadwal Sholat" to "Prayer Schedule", "Arah Kiblat" to "Qibla Direction",
        "Ketahui lokasi terkini" to "Current Location", "Cari fasilitas umum terdekat" to "Find Nearby Public Facilities",
        "Mode Acara dan Pertemuan" to "Events and Meetings Mode", "Petunjuk penggunaan" to "User Guide",
        "Cadangkan pengaturan" to "Back Up Settings", "Pulihkan pengaturan" to "Restore Settings",
        "Reset semua pengaturan ke awal" to "Reset All Settings", "Pembaruan dan bantuan" to "Updates and Help",
        "Izin dan kompatibilitas perangkat" to "Device Permissions and Compatibility", "Buka info aplikasi" to "Open App Info",
        "Hubungi pengembang" to "Contact Developer", "Periksa pembaruan" to "Check for Updates",
        "Aktifkan" to "Enable", "Aktif" to "Enabled", "Mati" to "Off", "Status aktif" to "Enabled",
        "Status mati" to "Disabled", "Jadwal" to "Schedule", "Ucapan" to "Speech",
        "Yang disebutkan saat jam bicara" to "What the clock announces", "Ucapkan jam" to "Speak the hour",
        "Sebutkan menit" to "Speak the minutes", "Bacakan detik" to "Speak the seconds",
        "Format waktu" to "Time Format", "Setiap beberapa menit: selang waktu" to "Interval in minutes",
        "Bacakan info waktu sholat berikutnya sekarang" to "Announce the next prayer time now",
        "Atur lokasi jadwal sholat" to "Set prayer schedule location", "Perbarui nama lokasi (kelurahan, kota, provinsi)" to "Update location name (district, city, province)",
        "Nama lokasi yang Anda isi sendiri dipakai apa adanya:" to "Your manually entered location name is used as entered:",
        "Mencari nama lokasi, mohon tunggu." to "Looking up the location name. Please wait.",
        "Nama lokasi belum ditemukan. Pastikan internet aktif, atau isi nama lokasi secara manual di halaman Jadwal Sholat." to "Location name not found. Check your internet connection or enter the location manually on the Prayer Schedule page.",
        "Lokasi jadwal sholat belum diatur. Atur lokasi di halaman Jadwal Sholat." to "The prayer schedule location has not been set. Set it on the Prayer Schedule page.",
        "Mesin suara" to "Speech Engine", "Kecepatan" to "Speed", "Nada" to "Pitch", "Keluaran volume" to "Audio Output",
        "Tes" to "Test", "Tes pengucapan" to "Speech Test", "Pengaturan suara" to "Speech Settings",
        "Pengaturan jam" to "Clock Settings", "Pengaturan kalender" to "Calendar Settings",
        "Pilih hari aktif" to "Select active days", "Minggu" to "Sunday", "Senin" to "Monday",
        "Selasa" to "Tuesday", "Rabu" to "Wednesday", "Kamis" to "Thursday", "Jumat" to "Friday", "Sabtu" to "Saturday",
        "Lokasi GPS" to "GPS location", "Lokasi jaringan" to "Network location", "Lokasi perangkat" to "Device location",
        "Perkiraan ketelitian" to "Estimated accuracy", "meter" to "meters", "Tidak ditemukan" to "Not found",
        "Kembali" to "Back", "Batal" to "Cancel", "Ya" to "Yes", "Tidak" to "No", "Simpan" to "Save",
        "Mati / tanpa melodi" to "Off / no melody", "Pagi" to "Morning", "Siang" to "Afternoon", "Sore" to "Late afternoon", "Malam" to "Night",
        "Setiap 5 menit" to "Every 5 minutes", "Setiap 10 menit" to "Every 10 minutes", "Setiap 15 menit" to "Every 15 minutes", "Setiap 20 menit" to "Every 20 minutes", "Setiap 30 menit" to "Every 30 minutes", "Setiap 1 jam" to "Every hour",
        "Format 24 jam" to "24-hour format", "Format 12 jam" to "12-hour format", "Mati" to "Off", "Hidup" to "On", "Otomatis" to "Automatic", "Manual" to "Manual",
        "Gregorian" to "Gregorian", "Hijriah" to "Hijri", "Masehi" to "Gregorian", "Pasaran Jawa" to "Javanese pasaran",
        "Aktifkan jam bicara" to "Enable talking clock", "Bacakan tanggal Masehi" to "Announce Gregorian date", "Bacakan tanggal Hijriah" to "Announce Hijri date", "Bacakan pasaran Jawa" to "Announce Javanese pasaran",
        "Bacakan info libur nasional" to "Announce national holidays", "Bacakan info cuti bersama" to "Announce collective leave information",
        "Sebutkan lokasi pada info sholat berikutnya" to "Include the location in the next prayer announcement", "Bacakan info waktu sholat berikutnya bersama pembacaan waktu" to "Announce the next prayer time with the clock",
        "Izinkan alarm tepat waktu untuk pemulihan otomatis" to "Allow exact alarms for automatic recovery", "Pengaturan waktu" to "Time Settings", "Pengaturan suara" to "Speech Settings",
        "Buka halaman arah kiblat dan jarum kompas" to "Open the Qibla direction and compass needle page", "Panduan kompas saat layar mati" to "Compass guidance while the screen is off",
        "Lokasi tersimpan" to "Saved location", "Lokasi belum diatur" to "Location has not been set", "Mencari lokasi, mohon tunggu." to "Finding location. Please wait.",
        "Izin diperlukan" to "Permission required", "Buka pengaturan" to "Open settings", "Pengaturan perangkat" to "Device settings", "Tes pengucapan" to "Speech test"
    )
}
