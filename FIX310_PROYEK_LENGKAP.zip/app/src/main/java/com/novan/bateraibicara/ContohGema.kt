package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale

/**
 * FIX310: "Putar contoh gema" untuk semua pengaturan gema. Contoh memakai suara TTS saja (bukan azan, ayat, atau berkas lain),
 * dirender ke berkas, diberi efek lewat [GemaDsp], lalu diputar di dalam aplikasi. Seluruh langkah dibungkus penangkap kesalahan
 * dan berjalan lewat context aplikasi sehingga tidak menutup layar pengaturan atau membuat aplikasi keluar.
 */
object ContohGema {
    private val utama = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var pemutar: MediaPlayer? = null
    private var berkas: File? = null
    private var generasi = 0
    @Volatile private var inggris = false
    private fun tr(id: String, en: String): String = if (inggris) en else id

    fun berhenti() {
        generasi++
        try { pemutar?.setOnCompletionListener(null); pemutar?.stop() } catch (_: Throwable) { }
        try { pemutar?.release() } catch (_: Throwable) { }
        pemutar = null
        try { tts?.stop() } catch (_: Throwable) { }
        try { tts?.shutdown() } catch (_: Throwable) { }
        tts = null
        try { berkas?.delete() } catch (_: Throwable) { }
        berkas = null
    }

    /** [kunci] salah satu GemaAudio.daftarKunci; [kekuatan] 0..100. [lapor] menerima pesan singkat (boleh null). */
    fun putar(context: Context, kunci: String, kekuatan: Int, lapor: ((String) -> Unit)? = null) {
        val app = context.applicationContext
        val en = try { BahasaAplikasi.tampilan(app) == 1 } catch (_: Throwable) { false }
        inggris = en
        fun kabar(teks: String) { try { utama.post { lapor?.invoke(teks) } } catch (_: Throwable) { } }
        try {
            berhenti()
            val gen = generasi
            val f = File(app.cacheDir, "contoh_gema_" + System.nanoTime() + ".wav")
            berkas = f
            var siap = false
            val mesin = TextToSpeech(app) { status ->
                utama.post {
                    try {
                        if (gen != generasi) return@post
                        val t = tts
                        if (status != TextToSpeech.SUCCESS || t == null) { kabar(tr("Mesin suara belum siap, coba lagi.", "The speech engine is not ready, try again.")); berhenti(); return@post }
                        if (siap) return@post
                        siap = true
                        val bahasa = if (en) Locale.ENGLISH else Locale.forLanguageTag("id-ID")
                        val r = t.setLanguage(bahasa)
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
                        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) { }
                            override fun onDone(utteranceId: String?) {
                                Thread {
                                    try {
                                        if (gen != generasi) return@Thread
                                        if (!f.exists() || f.length() < 200L) { kabar(tr("Contoh suara gagal dibuat.", "The sample could not be created.")); return@Thread }
                                        val ok = GemaDsp.proses(f, kunci, kekuatan)
                                        utama.post { if (gen == generasi) mainkan(app, f, gen, ok, kunci, en, lapor) }
                                    } catch (_: Throwable) { kabar(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) }
                                }.start()
                            }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) { kabar(tr("Contoh suara gagal dibuat.", "The sample could not be created.")) }
                        })
                        val teks = tr("Ini contoh suara dengan efek gema.", "This is a sample voice with an echo effect.")
                        val h = t.synthesizeToFile(teks, android.os.Bundle(), f, "contoh_gema")
                        if (h != TextToSpeech.SUCCESS) kabar(tr("Contoh suara gagal dibuat.", "The sample could not be created."))
                    } catch (_: Throwable) { kabar(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) }
                }
            }
            tts = mesin
        } catch (_: Throwable) { kabar(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) }
    }

    private fun mainkan(app: Context, f: File, gen: Int, dspOk: Boolean, kunci: String, en: Boolean, lapor: ((String) -> Unit)?) {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(f.path)
            mp.prepare()
            mp.setOnCompletionListener { if (gen == generasi) berhenti() }
            mp.setOnErrorListener { _, _, _ -> if (gen == generasi) berhenti(); true }
            pemutar = mp
            if (!dspOk && kunci != "normal") lapor?.invoke(tr("Gema tidak dapat diterapkan; diputar tanpa gema.", "The echo could not be applied; playing without echo."))
            mp.start()
        } catch (_: Throwable) {
            try { lapor?.invoke(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) } catch (_: Throwable) { }
            berhenti()
        }
    }
}
