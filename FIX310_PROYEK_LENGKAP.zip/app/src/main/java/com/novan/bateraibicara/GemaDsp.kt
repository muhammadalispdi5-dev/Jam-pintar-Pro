package com.novan.bateraibicara

import java.io.File

/**
 * FIX310: efek gema nyata pada data suara (DSP), meniru cara kerja aplikasi Gema TTS: ucapan dirender ke berkas WAV,
 * gema (pengulangan tertunda) dan ruang (reverb Schroeder/Freeverb: filter sisir paralel + all-pass) dihitung langsung pada sampel PCM,
 * lalu hasilnya diputar biasa. Tidak bergantung pada AudioEffect/EnvironmentalReverb milik HP sehingga terdengar sama di semua HP.
 * Ekor gema ditambahkan ke akhir berkas agar tidak terpotong.
 */
object GemaDsp {
    private class Param(
        val echoMs: Int, val echoFb: Float, val echoMix: Float, val echoRep: Int,
        val rvFb: Float, val rvWet: Float, val preMs: Int, val damp: Float, val tailMs: Int
    )

    private fun param(k: String): Param? = when (k) {
        "kamar" -> Param(0, 0f, 0f, 0, 0.72f, 0.22f, 0, 0.40f, 700)
        "aula" -> Param(0, 0f, 0f, 0, 0.82f, 0.30f, 15, 0.35f, 1600)
        "aula_besar" -> Param(0, 0f, 0f, 0, 0.88f, 0.34f, 25, 0.30f, 2400)
        "echo_lembut" -> Param(180, 0.35f, 0.40f, 4, 0f, 0f, 0, 0f, 1100)
        "echo" -> Param(320, 0.50f, 0.55f, 5, 0f, 0f, 0, 0f, 2200)
        "lembah" -> Param(700, 0.55f, 0.60f, 4, 0.70f, 0.12f, 0, 0.40f, 3200)
        "studio" -> Param(0, 0f, 0f, 0, 0.70f, 0.16f, 8, 0.50f, 900)
        "karaoke" -> Param(120, 0.42f, 0.40f, 4, 0.75f, 0.22f, 0, 0.40f, 1500)
        "panggung" -> Param(90, 0.40f, 0.30f, 3, 0.86f, 0.34f, 20, 0.35f, 2200)
        "gua" -> Param(420, 0.50f, 0.45f, 4, 0.93f, 0.35f, 30, 0.25f, 4000)
        else -> null
    }

    /** Panjang ekor (ms) yang ditambahkan; 0 untuk mode normal. */
    fun ekorMs(k: String): Int = param(k)?.tailMs ?: 0

    private class Wav(val kanal: Int, val laju: Int, val sampel: Array<FloatArray>)

    private fun le16(d: ByteArray, o: Int) = (d[o].toInt() and 255) or ((d[o + 1].toInt() and 255) shl 8)
    private fun le32(d: ByteArray, o: Int) = le16(d, o) or (le16(d, o + 2) shl 16)

    private fun baca(f: File): Wav? {
        val d = f.readBytes()
        if (d.size < 44 || String(d, 0, 4) != "RIFF" || String(d, 8, 4) != "WAVE") return null
        var p = 12; var kanal = 0; var laju = 0; var bit = 0; var fmt = 0; var awal = -1; var panjang = 0
        while (p + 8 <= d.size) {
            val id = String(d, p, 4); val n = le32(d, p + 4)
            if (id == "fmt ") { fmt = le16(d, p + 8); kanal = le16(d, p + 10); laju = le32(d, p + 12); bit = le16(d, p + 22) }
            if (id == "data") { awal = p + 8; panjang = if (n <= 0 || awal + n > d.size) d.size - awal else n; break }
            if (n < 0) return null
            p += 8 + n + (n and 1)
        }
        if (awal < 0 || kanal !in 1..2 || laju < 8000 || bit != 16 || (fmt != 1 && fmt != 0xFFFE)) return null
        val jumlah = panjang / (2 * kanal)
        if (jumlah <= 0) return null
        val s = Array(kanal) { FloatArray(jumlah) }
        for (i in 0 until jumlah) for (c in 0 until kanal) {
            val o = awal + (i * kanal + c) * 2
            s[c][i] = ((d[o].toInt() and 255) or (d[o + 1].toInt() shl 8)).toShort().toFloat() / 32768f
        }
        return Wav(kanal, laju, s)
    }

    private fun tulis(f: File, w: Wav) {
        val n = w.sampel[0].size
        val ukuran = n * w.kanal * 2
        val b = ByteArray(44 + ukuran)
        fun t32(o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte(); b[o + 2] = (v shr 16).toByte(); b[o + 3] = (v shr 24).toByte() }
        fun t16(o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() }
        "RIFF".toByteArray().copyInto(b, 0); t32(4, 36 + ukuran); "WAVE".toByteArray().copyInto(b, 8)
        "fmt ".toByteArray().copyInto(b, 12); t32(16, 16); t16(20, 1); t16(22, w.kanal); t32(24, w.laju)
        t32(28, w.laju * w.kanal * 2); t16(32, w.kanal * 2); t16(34, 16)
        "data".toByteArray().copyInto(b, 36); t32(40, ukuran)
        for (i in 0 until n) for (c in 0 until w.kanal) {
            val v = (w.sampel[c][i] * 32767f).coerceIn(-32768f, 32767f).toInt()
            val o = 44 + (i * w.kanal + c) * 2
            b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte()
        }
        f.writeBytes(b)
    }

    private val sisir = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491)
    private val semua = intArrayOf(556, 441, 341, 225)

    /** Reverb Freeverb sederhana; mengembalikan sinyal basah (belum dikalikan wet). */
    private fun reverb(masuk: FloatArray, laju: Int, p: Param, pre: Int): FloatArray {
        val skala = laju / 44100f
        val n = masuk.size
        val keluar = FloatArray(n)
        val bufS = Array(sisir.size) { FloatArray(maxOf(1, (sisir[it] * skala).toInt())) }
        val posS = IntArray(sisir.size); val simpanS = FloatArray(sisir.size)
        val bufA = Array(semua.size) { FloatArray(maxOf(1, (semua[it] * skala).toInt())) }
        val posA = IntArray(semua.size)
        for (i in 0 until n) {
            val x = (if (i - pre >= 0) masuk[i - pre] else 0f) * 0.12f
            var jumlah = 0f
            for (c in sisir.indices) {
                val b = bufS[c]; val y = b[posS[c]]
                simpanS[c] = y * (1f - p.damp) + simpanS[c] * p.damp
                b[posS[c]] = x + simpanS[c] * p.rvFb
                if (++posS[c] >= b.size) posS[c] = 0
                jumlah += y
            }
            for (a in semua.indices) {
                val b = bufA[a]; val y = b[posA[a]]
                val z = jumlah + 0f
                b[posA[a]] = z + y * 0.5f
                jumlah = y - z
                if (++posA[a] >= b.size) posA[a] = 0
            }
            keluar[i] = jumlah
        }
        return keluar
    }

    /**
     * Terapkan gema [kunci] dengan [kekuatan] (0..100; 60 = bawaan) pada berkas WAV 16-bit hasil render TTS (ditimpa).
     * Mengembalikan false bila format tidak dikenal atau terjadi kesalahan; berkas asli tidak rusak dalam kasus itu.
     */
    fun proses(f: File, kunci: String, kekuatan: Int): Boolean {
        val p = param(kunci) ?: return kekuatan >= 0 && kunci == "normal"
        if (kekuatan <= 0) return true
        return try {
            val w = baca(f) ?: return false
            val skala = (kekuatan / 60f).coerceIn(0f, 1.67f)
            val mix = (p.echoMix * skala).coerceAtMost(0.95f)
            val wet = (p.rvWet * skala).coerceAtMost(0.9f)
            val ekor = (w.laju.toLong() * p.tailMs / 1000L).toInt()
            val baru = Array(w.kanal) { FloatArray(w.sampel[it].size + ekor) }
            var puncak = 0f
            for (c in 0 until w.kanal) {
                val kering = baru[c]
                System.arraycopy(w.sampel[c], 0, kering, 0, w.sampel[c].size)
                val hasil = kering.copyOf()
                if (p.echoRep > 0 && p.echoMs > 0) {
                    val d = (w.laju * p.echoMs / 1000)
                    var gain = mix
                    for (k in 1..p.echoRep) {
                        val geser = d * k
                        for (i in geser until hasil.size) hasil[i] += kering[i - geser] * gain
                        gain *= p.echoFb
                    }
                }
                if (p.rvFb > 0f) {
                    val pre = w.laju * p.preMs / 1000
                    val basah = reverb(hasil, w.laju, p, pre)
                    for (i in hasil.indices) hasil[i] += basah[i] * wet * 1.2f
                }
                for (i in hasil.indices) { val a = Math.abs(hasil[i]); if (a > puncak) puncak = a }
                baru[c] = hasil
            }
            // Cegah pecah: turunkan bila melewati 0,95; gema yang lebih keras dari ucapan asli tidak dikecilkan di bawah itu.
            val faktor = if (puncak > 0.95f) 0.95f / puncak else 1f
            if (faktor < 1f) for (c in baru) for (i in c.indices) c[i] *= faktor
            tulis(f, Wav(w.kanal, w.laju, baru))
            true
        } catch (_: Throwable) { false }
    }
}
