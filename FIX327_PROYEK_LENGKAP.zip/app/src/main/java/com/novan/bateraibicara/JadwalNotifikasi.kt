package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.util.Calendar

/**
 * FIX307: notifikasi jadwal salat di layar pemberitahuan (seperti aplikasi azan populer).
 * Hanya waktu salat terdekat yang tampil: mulai sejumlah menit sebelum salat (sesuai pengaturan Pengingat sebelum sholat:
 * 5/10/15/30 menit) dengan hitung mundur, lalu setelah waktu tiba tampil hitung maju sampai 30 menit sesudahnya.
 */
object JadwalNotifikasi {
    private const val KANAL = "jadwal_sholat_harian"
    private const val ID_NOTIF = 8120
    const val AKSI_PERBARUI = "com.novan.jambicarapro.REFRESH_PRAYER_NOTIF"
    private val kunci = listOf("subuh", "terbit", "dzuhur", "ashar", "maghrib", "isya")

    private fun milis(tanggal: LocalDate, menit: Int): Long = Calendar.getInstance().apply {
        set(Calendar.YEAR, tanggal.year); set(Calendar.MONTH, tanggal.monthValue - 1); set(Calendar.DAY_OF_MONTH, tanggal.dayOfMonth)
        set(Calendar.HOUR_OF_DAY, menit / 60); set(Calendar.MINUTE, menit % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun jam(menit: Int) = String.format(java.util.Locale.US, "%02d:%02d", menit / 60, menit % 60)

    private fun pendingPerbarui(c: Context): PendingIntent {
        val i = Intent(c, PrayerAlarmReceiver::class.java).setAction(AKSI_PERBARUI).putExtra("prayer_key", "notif")
        return PendingIntent.getBroadcast(c, 7990, i, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    }

    private const val PASCA_MENIT = 30
    private const val PASCA_TERBIT_MENIT = 15

    private class Waktu(val kunci: String, val menit: Int, val tepat: Long, val awal: Long, val akhir: Long)

    fun perbarui(context: Context) {
        val c = context.applicationContext
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val pp = PrayerPrefs(c)
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!pp.jadwalNotif || !pp.locationSet) {
                nm.cancel(ID_NOTIF)
                try { am.cancel(pendingPerbarui(c)) } catch (_: Exception) { }
                return
            }
            val en = BahasaAplikasi.tampilan(c) == 1
            fun tr(id: String, e: String) = if (en) e else id
            val sekarang = System.currentTimeMillis()
            val hariIni = LocalDate.now()
            // Waktu kemarin, hari ini, dan besok; jendela tampil = sesuai menit pengingat sebelum salat pilihan pengguna
            // sampai 30 menit sesudah waktu salat (pola aplikasi azan populer).
            val daftar = ArrayList<Waktu>()
            for (d in -1..1) {
                val tgl = hariIni.plusDays(d.toLong())
                for (k in kunci) {
                    val m = PrayerAlarm.prayerMinutes(c, pp, tgl, k)
                    val t = milis(tgl, m)
                    if (k == "terbit") daftar.add(Waktu(k, m, t, t, t + PASCA_TERBIT_MENIT * 60_000L))
                    else daftar.add(Waktu(k, m, t, t - pp.advanceMinutes(k) * 60_000L, t + PASCA_MENIT * 60_000L))
                }
            }
            daftar.sortBy { it.tepat }
            // FIX327: notifikasi "sudah berlalu" selalu tampil penuh 30 menit sesudah waktu salat (15 menit untuk terbit) dan tidak
            // terpotong oleh hitung mundur salat berikutnya; hitung mundur (notifikasi awal) baru tampil sesuai menit pengingat sebelum salat.
            val berlalu = daftar.lastOrNull { sekarang >= it.tepat && sekarang < it.akhir }
            val menjelang = daftar.firstOrNull { sekarang >= it.awal && sekarang < it.tepat }
            val aktif = berlalu ?: menjelang
            if (aktif == null) {
                nm.cancel(ID_NOTIF)
            } else {
                if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(KANAL) == null) {
                    val ch = NotificationChannel(KANAL, tr("Jadwal salat terdekat", "Nearest prayer time"), NotificationManager.IMPORTANCE_LOW)
                    ch.setSound(null, null); ch.enableVibration(false)
                    nm.createNotificationChannel(ch)
                }
                val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, KANAL) else Notification.Builder(c)
                val buka = PendingIntent.getActivity(c, 7991, Intent(c, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
                val nama = PrayerAlarm.label(aktif.kunci)
                val jamTeks = jam(aktif.menit)
                val sebelum = sekarang < aktif.tepat
                val judul = if (aktif.kunci == "terbit") tr("Matahari terbit pukul " + jamTeks, "Sunrise at " + jamTeks)
                    else if (sebelum) tr("Menjelang " + nama + " pukul " + jamTeks, "Approaching " + nama + " at " + jamTeks)
                    else tr("Waktu " + nama + " pukul " + jamTeks + " sudah tiba", nama + " time (" + jamTeks + ") has arrived")
                val berikut = daftar.firstOrNull { it.tepat > maxOf(sekarang, aktif.tepat) && it.kunci != aktif.kunci }
                val isi = if (aktif.kunci == "terbit") tr("Waktu Subuh telah berakhir; sudah berlalu sejak matahari terbit", "Fajr time has ended; elapsed since sunrise")
                    else if (sebelum) tr("Dalam hitungan mundur menuju waktu " + nama, "Counting down to " + nama + " time")
                    else tr("Sudah berlalu sejak waktu " + nama, "Elapsed since " + nama + " time")
                b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(judul).setContentText(isi)
                    .setContentIntent(buka).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(true).setWhen(aktif.tepat)
                if (Build.VERSION.SDK_INT >= 24) { b.setUsesChronometer(true); b.setChronometerCountDown(sebelum) }
                // FIX327: sistem sendiri menghapus notifikasi tepat saat jendelanya habis, walau alarm penyegar tertunda oleh penghemat baterai.
                if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter((aktif.akhir - sekarang).coerceAtLeast(1_000L))
                if (berikut != null) b.setStyle(Notification.BigTextStyle().bigText(isi + "\n" + tr("Berikutnya: ", "Next: ") + PrayerAlarm.label(berikut.kunci) + " " + jam(berikut.menit)))
                nm.notify(ID_NOTIF, b.build())
            }
            // Perbarui tepat pada batas jendela berikutnya (mulai tampil, waktu tiba, atau selesai).
            val batas = daftar.flatMap { listOf(it.awal, it.tepat, it.akhir) }.filter { it > sekarang }.minOrNull() ?: (sekarang + 3_600_000L)
            val pi = pendingPerbarui(c)
            val picu = batas + 1_000L
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, picu, pi)
                else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, picu, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, picu, pi)
            } catch (_: Exception) { try { am.set(AlarmManager.RTC_WAKEUP, picu, pi) } catch (_: Exception) { } }
        } catch (_: Exception) { }
    }
}
