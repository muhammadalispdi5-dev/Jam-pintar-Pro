package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.view.Gravity

/**
 * Layar hubungi pengembang. Telegram membuka kanal/chat pengembang; WhatsApp tetap menggunakan
 * nomor yang dikonfigurasi. Tidak ada pemantauan panggilan atau notifikasi Telegram di fitur ini.
 */
class KeluhanActivity : Halaman() {

    override val judulHalaman = R.string.kategori_keluhan

    private var kategori = 0
    private var pesan = ""
    private var sertakanInfo = true

    private companion object {
        const val PAKET_WA = "com.whatsapp"
        const val PAKET_WA_BISNIS = "com.whatsapp.w4b"
        val URL_TELEGRAM_PENGEMBANG = "https://t.me/JamPintarPro"
    }

    private fun daftarKategori() = listOf(
        getString(R.string.keluhan_kat_keluhan), getString(R.string.keluhan_kat_saran), getString(R.string.keluhan_kat_masalah)
    )

    private fun terpasang(paket: String): Boolean =
        try { packageManager.getPackageInfo(paket, 0); true } catch (_: Exception) { false }

    override fun bangun() {
        info(getString(R.string.info_keluhan))
        // Tombol Telegram selalu tersedia, termasuk jika nomor WhatsApp belum dikonfigurasi.
        tombol(getString(R.string.tombol_kirim_telegram)) { bukaTelegram() }
        if (!KeluhanPesan.terkonfigurasi()) {
            info(getString(R.string.keluhan_belum_dikonfigurasi))
            return
        }
        pilihan(getString(R.string.label_jenis_pesan), daftarKategori(), 0) { kategori = it }
        isian(
            getString(R.string.label_isi_pesan), "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        ) { pesan = it }.also {
            it.minLines = 5
            it.gravity = Gravity.TOP
        }
        saklar(getString(R.string.sw_sertakan_info), true) { sertakanInfo = it }
        info(getString(R.string.info_sertakan_info))

        val messenger = terpasang(PAKET_WA)
        val bisnis = terpasang(PAKET_WA_BISNIS)
        if (messenger) tombol(getString(R.string.tombol_kirim_wa_messenger)) { kirim(PAKET_WA) }
        if (bisnis) tombol(getString(R.string.tombol_kirim_wa_bisnis)) { kirim(PAKET_WA_BISNIS) }
        // Tidak terdeteksi: tetap beri satu tombol; sistem memilihkan aplikasi atau membuka halaman WhatsApp.
        if (!messenger && !bisnis) tombol(getString(R.string.tombol_kirim_wa)) { kirim(null) }
    }

    private fun bukaTelegram() {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(URL_TELEGRAM_PENGEMBANG))
        try {
            startActivity(i)
        } catch (_: Exception) {
            toast(R.string.telegram_tidak_dapat_dibuka)
        }
    }

    private fun kirim(paket: String?) {
        if (pesan.trim().length < 10) {
            toast(R.string.keluhan_terlalu_pendek)
            return
        }
        val label = daftarKategori()[kategori.coerceIn(0, 2)]
        val teks = KeluhanPesan.susun(this, label, pesan, sertakanInfo)
        val uri = Uri.parse("https://wa.me/" + KeluhanPesan.nomor() + "?text=" + Uri.encode(teks))
        val i = Intent(Intent.ACTION_VIEW, uri)
        if (paket != null) i.setPackage(paket)
        try {
            startActivity(i)
        } catch (_: Exception) {
            toast(R.string.keluhan_wa_tidak_ada)
        }
    }
}
