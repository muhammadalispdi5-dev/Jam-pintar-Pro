package com.novan.bateraibicara

import java.util.Locale

/**
 * Kalimat ucapan jadwal dan pengingat sholat mengikuti bahasa pengucapan aktif
 * (0 Indonesia, 1 English, 2 Arab, 3 Jawa krama) agar tidak bercampur bahasa.
 */
object UcapanSholat {

    fun locale(bahasa: Int): Locale = when (bahasa) {
        1 -> Locale.forLanguageTag("en-US")
        2 -> Locale.forLanguageTag("ar")
        3 -> Locale.forLanguageTag("jv-ID")
        else -> Locale.forLanguageTag("id-ID")
    }

    fun nama(key: String, bahasa: Int): String {
        val tabel: Map<String, String> = when (bahasa) {
            1 -> mapOf("imsak" to "Imsak", "subuh" to "Fajr", "terbit" to "Sunrise", "dhuha" to "Duha",
                "tahajud" to "Tahajjud", "dzuhur" to "Dhuhr", "ashar" to "Asr", "maghrib" to "Maghrib", "isya" to "Isha")
            2 -> mapOf("imsak" to "الإمساك", "subuh" to "الفجر", "terbit" to "الشروق", "dhuha" to "الضحى",
                "tahajud" to "التهجد", "dzuhur" to "الظهر", "ashar" to "العصر", "maghrib" to "المغرب", "isya" to "العشاء")
            3 -> mapOf("imsak" to "Imsak", "subuh" to "Subuh", "terbit" to "Srengenge medal", "dhuha" to "Dhuha",
                "tahajud" to "Tahajud", "dzuhur" to "Luhur", "ashar" to "Ngasar", "maghrib" to "Magrib", "isya" to "Ngisa")
            else -> return PrayerAlarm.label(key)
        }
        return tabel[key] ?: PrayerAlarm.label(key)
    }

    /** Jawa dibaca dengan kata ("tabuh sekawan langkung tigang dasa menit"); bahasa lain memakai format jam biasa. */
    fun waktu(jam: Double, bahasa: Int, use24: Boolean): String {
        if (bahasa != 3) return PrayerCalc.format(jam, use24)
        val total = PrayerCalc.minutes(jam)
        val h = total / 60
        val m = total % 60
        // Format 12 jam: sebut tabuh 1-12 lalu bagian hari Jawa; format 24 jam: sebut tabuh 0-23 apa adanya.
        val jamSebut = if (use24) h else (if (h % 12 == 0) 12 else h % 12)
        val bagianHari = if (use24) "" else " " + when (h) {
            in 0..3 -> "tengah dalu"
            in 4..10 -> "enjing"
            in 11..14 -> "siyang"
            in 15..18 -> "sonten"
            else -> "dalu"
        }
        return "tabuh " + JamBahasa.jawaKata(jamSebut) + (if (m == 0) " pas" else " langkung " + JamBahasa.jawaKata(m) + " menit") + bagianHari
    }

    private val hariId = arrayOf("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
    private val hariJv = arrayOf("Ahad", "Senen", "Selasa", "Rebo", "Kemis", "Jumuwah", "Setu")
    private val hariEn = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    private val hariAr = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
    private val bulanId = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
    private val bulanEn = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    private val bulanAr = arrayOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")

    /** Tanggal untuk diucapkan, dalam bahasa aktif (nama hari Ahad, bukan Minggu). */
    fun tanggal(d: java.time.LocalDate, bahasa: Int): String {
        val i = d.dayOfWeek.value % 7
        val m = d.monthValue - 1
        return when (bahasa) {
            1 -> ("" + (hariEn[i]) + ", " + (bulanEn[m]) + " " + (d.dayOfMonth) + ", " + (d.year))
            2 -> ("" + (hariAr[i]) + "، " + (d.dayOfMonth) + " " + (bulanAr[m]) + " " + (d.year))
            3 -> ("dinten " + (hariJv[i]) + " tanggal " + (JamBahasa.jawaAngka(d.dayOfMonth)) + " wulan " + (bulanId[m]) + " taun " + (JamBahasa.jawaTaun(d.year)))
            else -> ("" + (hariId[i]) + ", " + (d.dayOfMonth) + " " + (bulanId[m]) + " " + (d.year))
        }
    }

    fun jadwalHariIni(daftar: List<Pair<String, Double>>, bahasa: Int, use24: Boolean, pembukaKhusus: String? = null): String {
        val pembuka = pembukaKhusus ?: when (bahasa) {
            1 -> "Today's prayer times."
            2 -> "مواقيت الصلاة اليوم."
            3 -> "Jadwal salat dinten menika."
            else -> "Jadwal sholat hari ini."
        }
        return pembuka + " " + daftar.joinToString(" ") { (k, j) -> nama(k, bahasa) + " " + waktu(j, bahasa, use24) + "." }
    }

    fun pengingatAwal(key: String, menit: Int, bahasa: Int): String = when (bahasa) {
        1 -> ("" + (nama(key, 1)) + " prayer is in " + (menit) + " minutes.")
        2 -> ("بقي " + (if (menit in 0..59) JamBahasa.kata(menit, 2) else menit.toString()) + " دقيقة على صلاة " + (nama(key, 2)) + ".")
        3 -> ("Wekdal salat " + (nama(key, 3)) + " kantun " + (JamBahasa.jawaKata(menit)) + " menit malih.")
        else -> ("Waktu salat " + (PrayerAlarm.label(key)) + " tinggal " + (menit) + " menit lagi.")
    }
}
