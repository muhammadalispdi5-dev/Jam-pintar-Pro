package com.novan.bateraibicara

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.RemoteViews

class BatteryWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val skala = (i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).let { if (it <= 0) 100 else it }
        val mengisi = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        if (level >= 0) {
            val views = bangun(context, level * 100 / skala, mengisi)
            manager.updateAppWidget(ids, views)
        }
    }

    companion object {
        fun refresh(context: Context, persen: Int, mengisi: Boolean) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, BatteryWidgetProvider::class.java))
            if (ids.isEmpty()) return
            manager.updateAppWidget(ids, bangun(context, persen, mengisi))
        }

        private fun bangun(context: Context, persen: Int, mengisi: Boolean): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_baterai)
            v.setTextViewText(R.id.widget_persen, context.getString(R.string.widget_persen, persen))
            v.setTextViewText(
                R.id.widget_status,
                context.getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
            )
            val buka = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val statusTeks = context.getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
            // Satu deskripsi gabungan agar pembaca layar tidak membacakan dua potongan teks terpisah.
            v.setContentDescription(R.id.widget_root, ("Baterai " + (persen) + " persen, " + (statusTeks) + ". Ketuk untuk membuka Jam Pintar Pro."))
            v.setOnClickPendingIntent(R.id.widget_root, buka)
            return v
        }
    }
}
