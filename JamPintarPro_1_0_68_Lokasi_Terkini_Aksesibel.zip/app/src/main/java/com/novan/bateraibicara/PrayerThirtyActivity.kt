package com.novan.bateraibicara

import android.app.DatePickerDialog
import android.os.Bundle
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Pemilih tanggal dan daftar jadwal 30 hari ke depan. */
class PrayerThirtyActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private val fmt = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID"))
    private var selectedDate = LocalDate.now()
    private lateinit var selectedInfo: android.widget.TextView

    override fun bangun() {
        bagian("Pilih hari dan jadwal 30 hari")
        if (!pp.locationSet) { info("Lokasi belum diatur. Buka Jadwal Sholat, lalu perbarui lokasi (GPS) atau atur lokasi manual."); return }
        info(("Lokasi: " + (pp.place) + "\nMetode: " + (PrayerCalc.methodNames[pp.method])))
        selectedInfo = info("")
        tombol("Pilih tanggal") {
            DatePickerDialog(this, { _, year, month, day ->
                selectedDate = LocalDate.of(year, month + 1, day)
                tampilkanTanggalTerpilih()
            }, selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth).show()
        }
        tombol("Bacakan jadwal tanggal terpilih") { tesSuara("jam", ucapan(selectedDate)) }
        tampilkanTanggalTerpilih()
        bagian("Jadwal 30 hari ke depan")
        for (i in 0 until 30) {
            val date = LocalDate.now().plusDays(i.toLong())
            val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
            bagian(date.format(fmt), 17f)
            info(("Imsak " + (PrayerCalc.format(waktuDaring(date, "imsak", t.imsak), pp.use24)) + " · Subuh " + (PrayerCalc.format(waktuDaring(date, "subuh", t.fajr), pp.use24)) + " · Terbit " + (PrayerCalc.format(waktuDaring(date, "terbit", t.sunrise), pp.use24)) + "\nDhuha " + (PrayerCalc.format(waktuDhuha(waktuDaring(date, "dhuha", t.dhuha)), pp.use24)) + " · Tahajud " + (PrayerCalc.format(waktuTahajud(date), pp.use24)) + "\nDzuhur " + (PrayerCalc.format(waktuDaring(date, "dzuhur", t.dhuhr), pp.use24)) + " · Ashar " + (PrayerCalc.format(waktuDaring(date, "ashar", t.asr), pp.use24)) + " · Maghrib " + (PrayerCalc.format(waktuDaring(date, "maghrib", t.maghrib), pp.use24)) + " · Isya " + (PrayerCalc.format(waktuDaring(date, "isya", t.isha), pp.use24))))
        }
    }

    /** Waktu mengikuti jadwal daring bila diaktifkan, sama seperti halaman Jadwal Sholat. */
    private fun waktuDaring(date: LocalDate, key: String, hitung: Double): Double {
        val menit = if (pp.autoOnline) PrayerOnlineTimes.minutes(this, date, key) else null
        return if (menit != null) menit / 60.0 else hitung
    }

    /** Kalimat untuk dibacakan: bahasa aktif, tanpa tanda titik tengah yang mengganggu mesin suara. */
    private fun ucapan(date: LocalDate): String {
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        val bahasa = prefs.jamBahasaIdx
        val daftar = listOf(
            "imsak" to waktuDaring(date, "imsak", t.imsak), "subuh" to waktuDaring(date, "subuh", t.fajr),
            "terbit" to waktuDaring(date, "terbit", t.sunrise), "dhuha" to waktuDhuha(waktuDaring(date, "dhuha", t.dhuha)),
            "tahajud" to waktuTahajud(date), "dzuhur" to waktuDaring(date, "dzuhur", t.dhuhr),
            "ashar" to waktuDaring(date, "ashar", t.asr), "maghrib" to waktuDaring(date, "maghrib", t.maghrib),
            "isya" to waktuDaring(date, "isya", t.isha)
        )
        return UcapanSholat.jadwalHariIni(daftar, bahasa, pp.use24, UcapanSholat.tanggal(date, bahasa) + ".")
    }

    private fun waktuDhuha(standar: Double): Double = if (pp.dhuhaCustomEnabled) pp.dhuhaCustomMinute / 60.0 else standar
    private fun waktuTahajud(date: LocalDate): Double = if (pp.tahajudCustomEnabled) pp.tahajudCustomMinute / 60.0 else PrayerCalc.tahajud(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments(), 0)

    private fun tampilkanTanggalTerpilih() {
        selectedInfo.text = kalimat(selectedDate)
    }
    private fun kalimat(date: LocalDate): String {
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        return ("" + (date.format(fmt)) + "\nImsak " + (PrayerCalc.format(waktuDaring(date, "imsak", t.imsak), pp.use24)) + " · Subuh " + (PrayerCalc.format(waktuDaring(date, "subuh", t.fajr), pp.use24)) + " · Terbit " + (PrayerCalc.format(waktuDaring(date, "terbit", t.sunrise), pp.use24)) + " · Dhuha " + (PrayerCalc.format(waktuDhuha(waktuDaring(date, "dhuha", t.dhuha)), pp.use24)) + "\nTahajud " + (PrayerCalc.format(waktuTahajud(date), pp.use24)) + "\nDzuhur " + (PrayerCalc.format(waktuDaring(date, "dzuhur", t.dhuhr), pp.use24)) + " · Ashar " + (PrayerCalc.format(waktuDaring(date, "ashar", t.asr), pp.use24)) + " · Maghrib " + (PrayerCalc.format(waktuDaring(date, "maghrib", t.maghrib), pp.use24)) + " · Isya " + (PrayerCalc.format(waktuDaring(date, "isya", t.isha), pp.use24)))
    }
}
