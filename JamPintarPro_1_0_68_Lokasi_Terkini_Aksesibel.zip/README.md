# Jam Pintar Pro

Aplikasi Android dengan antarmuka berbahasa Indonesia. Sinkronisasi hari libur dapat memakai internet jika diaktifkan; kalender libur 2026 tersedia secara offline. Semua suara memakai mesin
Text-to-Speech yang terpasang di HP; tiap kategori bisa memilih mesin suaranya sendiri.

## Kategori di halaman utama
- **Baterai** – tampilan baterai (persen, bar, suhu, tegangan); persen disebut setiap 5/10/20/25%,
  dapat dipilih *hanya saat mengisi daya* atau *selalu*; peringatan lemah/kritis/penuh; ucapan charger & USB.
- **Jam** – jam bicara tepat waktu: setiap jam atau setiap 5–30 menit, jam mulai–selesai, hari aktif,
  format 24 jam atau 12 jam, bahasa pengucapan Indonesia/English/Arab/Jawa krama, pilihan komponen jam-menit-detik, kalender Masehi/Hijriah/pasaran dan info hari libur yang dapat digabung dalam satu rangkaian, serta mesin suara sendiri.
- **Nama pemanggil** – mengumumkan panggilan WhatsApp (suara & video) dan telepon seluler beserta nama
  penelepon, diulang selama berdering (jeda bawaan 1,5 detik, bisa diubah; batas ulang opsional), berhenti
  otomatis saat dijawab/ditolak. Mesin suara, kecepatan, nada, dan keluaran volume sendiri; nada penanda singkat sebelum/sesudah pengumuman dapat diaktifkan.

## Berjalan terus di latar belakang
Layanan foreground + alarm tepat waktu + wake lock, aktif otomatis setelah HP dihidupkan ulang.
Nama pemanggil memakai *Akses notifikasi* (dijalankan sistem sendiri setelah restart).

## Versi proyek
Versi **1.0.48**. Package ID khusus Jam Pintar Pro adalah `com.novan.jambicarapro`, berbeda dari aplikasi lama `com.novan.bateraibicara`, sehingga keduanya dapat dipasang berdampingan.

## Cara membangun lewat GitHub Actions
1. Buat repositori GitHub, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Tab **Actions** → **Bangun APK** → **Run workflow** (atau push ke `main`).
3. Unduh artefak **JamPintarPro-APK** (`app-release.apk`). Nama artefak pada workflow disamakan dengan nama aplikasi.

APK ditandatangani otomatis dengan kunci yang dibuat saat build. Untuk kunci tetap isi secret repo:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

## Izin yang perlu diberikan di HP
1. Notifikasi (Android 13+), 2. Akses notifikasi (untuk nama pemanggil), 3. Status telepon (opsional),
4. Izinkan berjalan di latar belakang + Mulai otomatis (OPPO/ColorOS). Semua ada tombolnya di aplikasi.


## Pelengkapan jam bicara dan baterai (versi 1.0.18)

- Jam bicara kini memiliki pilihan Bahasa Indonesia, English, dan Arab (hasil pengucapan Arab bergantung pada ketersediaan suara Arab di mesin TTS HP).
- Ditambahkan 16 berkas audio melodi yang diekstrak dari APK sumber ke `app/src/main/res/raw/`, pilihan melodi awal/akhir, jeda sebelum/sesudah pengucapan, tombol dengarkan melodi, tes jam lengkap, dan pintasan izin alarm tepat waktu.
- Baterai kini memiliki pilihan batas penuh 80–100%, pengulangan ucapan penuh dengan jumlah dan jeda yang dapat diatur, serta pembaruan pengaturan yang diterapkan ke layanan berjalan.
- Pengumuman baterai tetap membutuhkan layanan latar belakang aktif. Pada beberapa merek HP, pengguna perlu mengizinkan aktivitas latar belakang/mulai otomatis.

## Verifikasi sebelum rilis

Jalankan workflow GitHub Actions untuk membangun APK. Setelah terpasang, uji jam dengan layar mati dan layar menyala, jam melewati tengah malam, setiap interval, semua pilihan bahasa yang didukung TTS, melodi awal/akhir, serta baterai lemah/penuh dan pencabutan kabel pengisi daya. Audio melodi dipertahankan dari APK sumber, tetapi urutan nama melodi di proyek hasil disusun sebagai pilihan 1–15 dan perlu dicocokkan pendengaran di perangkat.

- Ditambahkan pilihan cara penyebutan baterai berdasarkan persentase atau interval waktu (1, 2, 5, 10, 15, 30, atau 60 menit).
- Ditambahkan kolom kalimat baterai yang dapat disesuaikan untuk persentase, peringatan lemah/kritis/penuh, dan status charger/USB. Token `{persen}` diisi dengan nilai aktual.


## Fitur penyebutan panggilan

Halaman **Penyebutan Nama Pemanggil** menyediakan pengaktifan utama, pilihan panggilan WhatsApp, WhatsApp Bisnis, dan telepon seluler, kalimat terpisah untuk WhatsApp suara/video, WhatsApp Bisnis suara/video, dan telepon biasa (placeholder `{nama}`), jeda dan batas pengulangan, melodi awal/akhir beserta jeda, pengaturan mesin TTS/kecepatan/nada/keluaran, serta tombol tes untuk masing-masing pola kalimat.

Agar deteksi berfungsi, pengguna harus memberi **Akses notifikasi** kepada aplikasi. Izin **Status telepon** disarankan untuk menghentikan pengumuman telepon seluler saat panggilan dijawab/berakhir; izin Kontak membantu mengubah nomor menjadi nama. Deteksi panggilan WhatsApp bergantung pada format notifikasi yang disediakan versi WhatsApp dan Android pada perangkat. Perilaku latar belakang tetap perlu diuji pada perangkat sasaran dan tidak dapat dijamin hanya dengan pemeriksaan berkas.


## Kelengkapan pengujian dan kalimat

- Halaman baterai menyediakan tombol tes untuk setiap kalimat: persentase, lemah, kritis, baterai penuh di bawah 100%, baterai 100%, pengisi daya dipasang/dicabut, dan USB dipasang/dicabut. Kalimat persentase mendukung token `{persen}` dan dapat dipulihkan ke bawaan.
- Halaman jam menyediakan tes ucapan saja dan tes lengkap bersama melodi.
- Halaman nama pemanggil menyediakan pengaturan dan tes kalimat WhatsApp suara/video, WhatsApp Bisnis suara/video, dan telepon biasa; token `{nama}` bisa disisipkan melalui tombol. Melodi awal/akhir dapat dipilih dari audio yang tersedia dan diuji masing-masing.
- Pencocokan kontak dapat menggunakan nama panggilan (nickname) bila tersedia.
- Pilihan keluaran suara mencakup media, alarm, notifikasi, dering, aksesibilitas, dan panggilan suara.

Catatan audit: perubahan ini diperiksa secara statis dan berkas XML divalidasi. Lingkungan ini tidak memiliki Android SDK/Gradle untuk menghasilkan APK atau menjalankan pengujian panggilan di perangkat; hasil build GitHub Actions tetap harus diperiksa.


## Audit tambahan fitur baterai dan bahasa
- Batas baterai kritis sekarang dapat dipilih: 1%, 2%, 3%, 5%, 7%, 10%, 15%, atau 20%.
- Tombol uji kalimat baterai diletakkan tepat setelah kolom kalimat terkait, termasuk level, lemah, kritis, penuh, charger, dan USB.
- Contoh nama pemanggil untuk pengujian adalah Ali Bima. Tombol uji kalimat tetap berada di bagian masing-masing jenis panggilan.
- Pengucapan waktu memiliki pilihan bahasa Jawa krama dengan susunan kalimat Jawa dan permintaan locale TTS `jv-ID`. Dukungan bahasa Jawa bergantung pada mesin TTS dan data suara yang terpasang di perangkat; jika mesin tidak mendukungnya, Android dapat memakai bahasa cadangan. Istilah kebahasaan pada sumber diperiksa terhadap rujukan bilangan Jawa krama, tetapi kewajaran seluruh tuturan tetap sebaiknya ditinjau penutur Jawa krama.

## Pemicu waktu dari luar aplikasi

Aplikasi menyediakan ikon peluncur terpisah bernama **Beritahu Saya** yang bisa dicari di daftar aplikasi Android dan diketuk untuk membacakan waktu tanpa perlu menambahkan widget. Widget layar utama tetap tersedia sebagai pilihan tambahan. Aktifkan atau nonaktifkan pemicu dari halaman utama aplikasi, bagian **Pemicu waktu di luar aplikasi**, sakelar **Aktifkan pemicu Beritahu Saya**. Saat dinonaktifkan, pemicu eksternal tidak membacakan waktu; jadwal jam bicara otomatis tidak terpengaruh.

Versi 1.0.23 menggunakan application ID `com.novan.jambicarapro`, sehingga instalasinya terpisah dari versi lama `com.novan.bateraibicara`. Keduanya dapat berada di HP yang sama.


## Kalender Masehi, Hijriah, dan pasaran Jawa (1.0.23)

Pada kategori **Jam**, bagian **Kalender yang dibacakan bersama waktu** menyediakan saklar terpisah untuk tanggal Masehi, tanggal Hijriah, dan pasaran Jawa. Setiap bagian yang aktif akan digabungkan dalam satu rangkaian ucapan, termasuk melalui pemicu **Beritahu Saya**. Koreksi manual Hijriah dan pasaran tersedia dari -30 sampai +30 hari. Mengaktifkan **Koreksi otomatis tanggal Hijriah** mengunci kolom koreksi manual.

Catatan penting: mode otomatis saat ini memakai perhitungan Hijriah yang tersedia pada Android; tombol kalender resmi membuka publikasi kalender tahunan Kementerian Agama sebagai rujukan. Kemenag menerbitkan kalender tahunan (misalnya PDF), dan tidak ditemukan API publik stabil yang dapat digunakan aplikasi ini untuk sinkronisasi tanggal resmi langsung. Karena itu, versi ini belum mengklaim sinkronisasi otomatis langsung ke basis data Kemenag.


## Perbaikan 1.0.23

Memperbaiki pemakaian zona waktu ICU pada `IslamicCalendar` agar sesuai dengan tipe `android.icu.util.TimeZone` dan menggunakan metode kalender eksplisit untuk menetapkan waktu.


## Jam Pintar Pro 1.0.24 — Kalender dan detik

- Menu **Kalender Masehi, Hijriah, dan Pasaran Jawa** tersedia terpisah di beranda, sejajar dengan kategori Jam dan Baterai.
- Urutan pengucapan gabungan: waktu, pasaran Jawa, tanggal Masehi, lalu tanggal Hijriah.
- Pasaran Jawa dan tanggal Hijriah berganti pada pukul 18.00; nama hari untuk kedua bagian tersebut memakai **Ahad**, bukan Minggu.
- Pengaturan Jam menyediakan saklar **Bacakan detik**.
- Koreksi otomatis Hijriah tetap memakai perhitungan kalender pada Android dan bukan sinkronisasi langsung ke API resmi pemerintah.


## Perbaikan versi 1.0.26 (acuan main.lua)
- Pengumuman dipecah menjadi segmen berurutan: waktu; hari/pasaran Jawa bersama tanggal Masehi; tanggal Hijriah.
- Jeda standar antarsegmen kalender mengikuti berkas acuan, yaitu 300 milidetik; tidak ada jeda 6 detik yang dipaksakan. Pengaturan jeda khusus antara jam dan menit tetap dipertahankan.
- Tanggal Hijriah otomatis masih memakai kalender ICU Android pada versi ini; tombol kalender Kemenag membuka sumber resmi tahunan. Ini belum berarti aplikasi tersinkron langsung ke server pemerintah.


## Versi 1.0.27
- Jeda jam-ke-menit default diperhalus menjadi 650 ms (pengaturan tetap dapat diubah).
- Tombol tes di menu Kalender membacakan bagian kalender/pasaran saja.
- Setelah pukul 18.00, pasaran disebut dengan awalan “Malam”, misalnya “Malam Ahad Legi”.
- Koreksi Hijriah otomatis mencoba sinkronisasi daring harian melalui AlAdhan; jika gagal, cache dan kalender perangkat tetap menjadi cadangan. Ini bukan API resmi Kemenag.


## Versi 1.0.28 — Perbaikan kalender Hijriah
- Nama hari pada ucapan Hijriah dihitung dari tanggal lokal sasaran (setelah pergantian pukul 18.00), tidak ikut bergeser karena offset koreksi Hijriah.
- Saat sinkronisasi daring berhasil, hari/bulan/tahun Hijriah persis dari respons API disimpan untuk tanggal sasaran tersebut dan dipakai langsung.
- Jika cache tidak cocok dengan tanggal sasaran, aplikasi memakai kalender ICU sebagai cadangan.


## Perbaikan 1.0.29

- Pengucapan jam dan menit memakai pemisah internal, bukan koma yang mengubah intonasi TTS. Jeda antarucapan jam-menit dikembalikan ke standar 300 milidetik, termasuk migrasi dari nilai 650 milidetik versi sebelumnya.
- Pengaturan Kalender kini memisahkan **Info Libur Nasional** dan **Info Libur Cuti Bersama**. Tiap kategori memiliki sakelar pembaruan otomatis, info lampau, terkini, dan mendatang, serta tombol pembacaan langsung.
- Pencarian libur terdekat menelusuri hingga 10 tahun, bukan hanya 7 hari. Sinkronisasi memakai endpoint `dayoffapi.vercel.app` seperti acuan `main.lua`; kegagalan jaringan tidak menghapus data offline/cache. Data statis offline pada paket ini mencakup tahun 2026.
- Sinkronisasi dijalankan asinkron saat layanan berjalan dan diperiksa berkala. Kompilasi APK penuh dan uji perangkat tetap perlu dilakukan melalui GitHub Actions.


## Versi 1.0.30
- Menambahkan petunjuk penggunaan yang tampil saat pertama kali aplikasi dibuka, memuat nama pengembang Muhammad Ali, dan dapat dibuka kembali dari halaman utama.
- Mengubah label tombol kalender menjadi “Tes pengucapan”.


## Versi 1.0.31
- Semua fitur utama dan saklar fitur menggunakan status nonaktif sebagai pengaturan bawaan untuk instalasi baru, agar pengguna memilih sendiri fitur yang diperlukan.
- Urutan opsi pengucapan waktu dirapikan menjadi Bacakan jam, Bacakan menit, lalu Bacakan detik.
- Versi aplikasi dinaikkan menjadi 1.0.31 (versionCode 31).


## Versi 1.0.32 — Jadwal Sholat dan Arah Kiblat

- Menambahkan kategori **Jadwal Sholat** pada beranda, dengan perhitungan lokal tanpa internet, lokasi GPS atau koordinat manual, jadwal hari ini, tombol bacakan jadwal, dan daftar 30 hari ke depan.
- Metode perhitungan: Kemenag RI, Muslim World League, ISNA, Mesir, Karachi, Singapura, dan Umm Al-Qura. Pilihan mazhab Ashar: bayangan 1x atau 2x.
- Menambahkan penyesuaian menit −30 sampai +30 untuk Imsak, Subuh, Terbit, Dhuha, Dzuhur, Ashar, Maghrib, dan Isya; pilihan format 12/24 jam; serta opsi melewati pengingat Dzuhur pada hari Jumat.
- Menambahkan pengingat per waktu sholat (semuanya nonaktif secara bawaan), izin notifikasi dan alarm tepat waktu, opsi notifikasi tanpa suara, kontrol suara, dan tindakan **Hentikan suara azan** pada notifikasi. Alarm dijadwalkan ulang ketika waktu/lokasi berubah dan setelah perangkat menyala kembali.
- Menambahkan sumber suara azan bawaan yang berbeda untuk Subuh dan waktu lain, pemilihan berkas audio untuk semua waktu atau tiap waktu, uji suara, dan hapus/pulihkan pilihan. Audio azan dibawa dari APK referensi yang diberikan pengguna; metadata audio mencantumkan azan Subuh (Misyari Rasyid) dan azan umum.
- Menambahkan arah kiblat berbasis sensor kompas, arah derajat dari utara, petunjuk kiri/kanan, nada saat menghadap kiblat, opsi pengucapan otomatis tiap 1,5 detik dan getar panjang saat selisih kurang dari 5 derajat. Pengucapan dan getar nonaktif secara bawaan.
- Lokasi diproses di perangkat dan tidak dikirim ke server. Untuk pengingat yang tepat waktu, pengguna perlu mengaktifkan pengingat yang dikehendaki, mengizinkan notifikasi/alarm tepat waktu bila diminta, dan mengecualikan aplikasi dari pembatasan baterai pada perangkat yang agresif.
- Versi aplikasi dinaikkan menjadi 1.0.32 (versionCode 32). XML divalidasi dan algoritme perhitungan diuji secara terpisah, tetapi APK belum dikompilasi atau diuji di perangkat karena lingkungan ini tidak menyediakan Android SDK/Gradle. Jalankan GitHub Actions dan uji lokasi, perhitungan, alarm, pemilihan audio, penghentian suara, serta sensor kiblat pada perangkat sasaran.


## Versi 1.0.33
- Kompas arah kiblat menampilkan 8 arah mata angin: Utara, Timur Laut, Timur, Tenggara, Selatan, Barat Daya, Barat, dan Barat Laut.
- Pengucapan otomatis arah perangkat menyebutkan arah mata angin selain petunjuk koreksi menuju kiblat.


## Versi 1.0.34
- Perbaikan kompilasi PrayerAlarmService: menghapus deklarasi dan pemanggilan Ringtone yang tidak digunakan; pemutaran azan tetap memakai MediaPlayer.


## Versi 1.0.37
- Menambahkan pengingat terpisah untuk Imsak, Dhuha, dan Tahajud.
- Menambahkan estimasi Tahajud pada dua pertiga malam antara Isya hari sebelumnya dan Subuh hari berjalan. Waktu ini perkiraan dan sebaiknya dicocokkan dengan jadwal masjid setempat.
- Menambahkan pemilihan audio per pengingat termasuk Imsak, Dhuha, dan Tahajud; tombol tes suara tersedia di pengaturan.
- Menambahkan tindakan notifikasi untuk menjeda/melanjutkan serta menghentikan suara saat pemutaran berlangsung.


## Jam Pintar Pro 1.0.38
- Nama yang terlihat di peluncur dan judul aplikasi diubah menjadi Jam Pintar Pro; application ID `com.novan.jambicarapro` tetap sama agar jalur instalasi tidak berubah.
- Kontrol tes azan khusus di pengaturan: Jeda, Lanjutkan, dan Hentikan tes; tersedia sebagai tombol yang jelas serta tindakan notifikasi berlabel. Kontrol ini terpisah dari pemutaran azan normal.
- Opsi pembaruan jadwal melalui internet memakai cache untuk jadwal bulan berjalan dan berikutnya; jika offline, penghitungan lokal tetap menjadi cadangan. Koreksi menit tiap waktu salat tetap dapat disetel.
- Pembaruan online belum diuji dengan kompilasi penuh atau perangkat nyata; verifikasi dengan GitHub Actions dan perangkat target diperlukan.


## Versi 1.0.39
- Kontrol tes azan disederhanakan menjadi satu tombol putar/jeda/lanjutkan.
- Jarum kompas kiblat visual untuk pengguna low vision.
- Layanan foreground kompas opsional menjaga nada dan ucapan tetap berjalan saat layar mati; dapat dimatikan dari sakelar atau notifikasi.


## Versi 1.0.40
- Tes suara azan kini menyimpan pilihan waktu sholat yang sedang dites. Mengetuk tes untuk waktu/berkas berbeda akan mengganti pemutaran ke berkas yang dipilih, bukan menjeda audio lama. Mengganti atau menghapus sumber audio saat tes aktif akan memulai ulang tes memakai sumber terbaru.
- Pengaturan panduan kompas layar mati ditampilkan langsung di Pengaturan Jadwal Sholat dan juga tetap tersedia pada halaman Arah Kiblat.
- Layanan kompas mengutamakan sensor rotasi tipe wake-up bila tersedia dan terus memberikan petunjuk arah saat layanan latar belakang aktif, tanpa bergantung pada sakelar ucapan kompas halaman depan.


## Perubahan versi 1.0.41
- Sakelar panduan kompas saat layar mati hanya menyimpan preferensi; layanan kompas baru dijalankan ketika halaman arah kiblat dan jarum kompas dibuka.
- Pengucapan arah otomatis dan getar saat tepat menghadap kiblat tetap dikendalikan oleh sakelar masing-masing.
- Menambahkan pengingat matahari terbit.
- Menambahkan pengaturan menit Dhuha setelah matahari terbit (5–120 menit) dan penyesuaian waktu Tahajud (−180 hingga +180 menit).


## Perubahan versi 1.0.42
- Tombol Kembali dari halaman arah kiblat menghentikan layanan kompas latar belakang yang sedang berjalan; preferensi izin layar mati tetap tersimpan sehingga layanan bisa dimulai lagi saat halaman kompas dibuka kembali.
- Waktu Dhuha dan Tahajud tetap memakai perhitungan standar secara bawaan. Pengguna dapat mengaktifkan waktu khusus masing-masing dan memilih jam dengan pemilih waktu Android; jadwal dan alarm pengingat mengikuti jam khusus ketika diaktifkan.


## Versi 1.0.43
- Menambahkan pengingat suara sebelum salat Subuh, Dzuhur, Ashar, Maghrib, dan Isya.
- Setiap pengingat dapat diaktifkan sendiri dan waktu pendahuluannya dipilih 5, 10, 15, atau 30 menit.
- Pengingat pendahuluan terpisah dari alarm/azan pada waktu salat; pengingat awal membacakan nama salat dan sisa menit melalui Text-to-Speech.


## Versi 1.0.45
- Menghilangkan kata penghubung antara menit dan detik pada pengucapan waktu dalam bahasa Indonesia, Inggris, Arab, dan Jawa.
- Menata ulang kalimat waktu bahasa Jawa agar memakai awalan Jawa dan bilangan Jawa, serta tidak menggunakan awalan khusus yang dapat berbahasa Indonesia.
- Menyesuaikan kata periode waktu Jawa dan bilangan 11–99 untuk rangkaian pengucapan jam, menit, dan detik.
- Sumber diperbarui; kompilasi Android dan pengujian suara langsung tetap perlu dijalankan melalui GitHub Actions dan perangkat.


## Audit dan penyempurnaan versi 1.0.48

- Mode Jangan Ganggu menyimpan filter sebelumnya dan batas waktu pemulihan secara atomik; catatan pemulihan tidak dihapus bila izin dicabut atau perintah Android gagal. Alarm pemulihan tetap dijadwalkan secara mandiri.
- Jadwal salat dijadwalkan ulang setelah perangkat menyala ulang, aplikasi diperbarui, atau tanggal/zona waktu/jam perangkat berubah. Perubahan izin akses Jangan Ganggu juga memicu pemeriksaan ulang.
- Opsi menonaktifkan Dzuhur hari Jumat kini diterapkan pula pada jadwal Jangan Ganggu otomatis.
- Rangkaian tanggal Masehi, Hijriah, pasaran Jawa, dan info libur mengikuti bahasa pengucapan yang dipilih (Indonesia, English, Arab, atau Jawa krama), bukan menyisipkan kalimat Indonesia pada rangkaian Jawa. Nama hari libur yang tidak dikenal diterjemahkan ke sebutan umum agar tidak menyisipkan judul Indonesia.
- Bilangan Jawa diperbaiki, khususnya bentuk 11–29 dan 60, serta cara membaca tahun agar tidak memakai bentuk bilangan khusus seperti *likur* pada tahun.
- Pemeriksaan statis dilakukan terhadap sumber Kotlin, konfigurasi Gradle, manifest, dan berkas XML. Pengujian helper bilangan Jawa berhasil. APK belum dikompilasi di lingkungan ini karena Android SDK/Gradle tidak tersedia; GitHub Actions dan uji perangkat tetap wajib sebelum distribusi.

- Pada Android 12 ke atas, berikan izin **Alarm tepat waktu** jika diminta. Izin ini membantu memastikan pemulihan Mode Jangan Ganggu tidak tertunda oleh alarm yang tidak tepat waktu.


## Perbaikan akses alarm tepat waktu Android 16 (versi 1.0.48)

Pada versi ini aplikasi memakai deklarasi `SCHEDULE_EXACT_ALARM` saja (tanpa `USE_EXACT_ALARM`) agar pengguna dapat mengelola akses melalui halaman **Alarm dan pengingat** Android. Setelah akses diberikan, penerima siaran sistem menjadwalkan ulang alarm, termasuk alarm pemulihan Mode Jangan Ganggu. Jika akses belum diberikan, jadwal dapat memakai alarm perkiraan dan pemulihan pada menit yang tepat tidak dijamin.

Catatan: sumber telah diperiksa secara statis, tetapi belum dibangun penuh dengan Gradle atau diuji langsung pada perangkat Android 16.

## Petunjuk jam dan volume (versi 1.0.60)
- Cara jam diucapkan: Bacakan tepat di awal / tepat di akhir (saling meniadakan); detik tidak dibacakan saat jam pas. Berlaku untuk bahasa Indonesia, English, Arab, dan Jawa krama, format 12 maupun 24 jam.
- Pengingat sebelum sholat, imsak, matahari terbit, melodi, dan ucapan jam/nama pemanggil mengikuti saluran volume pilihan pengguna pada profil suara masing-masing.
- Info sholat berikutnya (Kalender > Info sholat berikutnya): waktu sholat wajib berikutnya beserta lokasi dibacakan dalam satu rangkaian setelah waktu, kalender, dan info libur; bisa diaktifkan/dinonaktifkan, lokasi bisa disebut atau tidak. Mengikuti bahasa pengucapan aktif (Indonesia, English, Arab, Jawa krama). Setelah Isya, yang disebut adalah Subuh besok.
- Nama lokasi pada info sholat berikutnya dicari otomatis dari koordinat (Geocoder perangkat: kelurahan/desa, kota, provinsi) saat lokasi GPS disimpan, dan diulang paling sering sekali per jam bila masih bernama "Lokasi GPS". Nama yang diketik pengguna tidak ditimpa. Tombol "Perbarui nama lokasi" tersedia di Kalender > Info sholat berikutnya. Lokasi baru berubah bila pengguna memperbarui GPS.
- Suara pembaca tanggal (profil "tgl", Kalender > Suara pembaca tanggal): mesin suara, kecepatan, nada, dan keluaran volume terpisah untuk tanggal Masehi, pasaran, Hijriah, info libur, dan info sholat berikutnya, seperti profil jam dan baterai. Selama belum diubah, mewarisi pengaturan suara jam. Bahasa pengucapan mengikuti bahasa jam yang aktif (Indonesia, English, Arab, Jawa krama). Berlaku pada jam bicara terjadwal, tes jam lengkap, tes ucapan, tes kalender, dan pemicu Beritahu Saya.
- Versi 1.0.61: nama lokasi otomatis disimpan dalam Indonesia, English, dan Arab dan diucapkan sesuai bahasa pengucapan aktif (Jawa memakai nama Indonesia); nama yang diketik pengguna dipakai apa adanya.

- Versi 1.0.62: rekaman pengantar awal diputar utuh pada penggunaan pertama sebelum informasi pengembang dan petunjuk penggunaan ditampilkan; pemicu Beritahu Saya berjalan di task sendiri sehingga tetap membacakan waktu dan rangkaiannya tanpa membuka aplikasi walau jendela aplikasi masih terbuka; info sholat berikutnya menyebut sisa menit/jam menuju waktu sholat.
- Versi 1.0.63: fitur cadangkan dan pulihkan pengaturan (berkas JSON lewat pemilih berkas Android, divalidasi sebelum diterapkan) serta reset semua pengaturan ke keadaan awal; pengumuman nama pemanggil diperbaiki agar hanya panggilan masuk (bukan keluar) yang diumumkan layar Izin dan kompatibilitas perangkat untuk HP selain Samsung: tampil di atas aplikasi lain, mulai otomatis, dan pengaturan baterai khusus merek (versi tetap 1.0.63).
- Versi 1.0.64: pembaruan aplikasi lewat GitHub Releases (workflow rilis.yml) dan chat dengan pengguna lewat WhatsApp Messenger atau WhatsApp Business; lihat PANDUAN_PEMBARUAN_DAN_KELUHAN.txt.
