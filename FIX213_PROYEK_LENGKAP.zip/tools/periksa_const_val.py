#!/usr/bin/env python3
"""Pemeriksa 'const val' Kotlin: inisialisasi harus konstanta kompilasi.

Gagal bila sebuah `const val` diinisialisasi dengan templat string ($nama atau ${..}), pemanggilan fungsi, atau ekspresi lain yang
bukan literal, penggabungan literal, aritmetika literal, atau rujukan ke konstanta bernama HURUF_BESAR. Menangkap kesalahan
"Const 'val' initializer must be a constant value" sebelum build di GitHub Actions. Pemakaian: python3 tools/periksa_const_val.py
"""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java"
masalah = []
literal = r'"(?:[^"\\$]|\\.)*"'
angka = r'-?(?:0x[0-9A-Fa-f_]+|\d[\d_]*(?:\.\d+)?)[LlFfUu]*'
token = r'(?:%s|%s|true|false|[A-Z][A-Z0-9_]*|\'(?:[^\'\\]|\\.)\')' % (literal, angka)
ekspresi = re.compile(r'\(*\s*%s\s*\)*(?:\s*[-+*/%%]\s*\(*\s*%s\s*\)*)*' % (token, token))

def potong_komentar(teks):
    """Buang komentar // di akhir baris, tetapi hanya yang berada di luar tanda kutip (agar https:// utuh)."""
    dalam = False
    i = 0
    while i < len(teks):
        c = teks[i]
        if dalam:
            if c == "\\":
                i += 2
                continue
            if c == '"':
                dalam = False
        else:
            if c == '"':
                dalam = True
            elif teks.startswith("//", i):
                return teks[:i]
        i += 1
    return teks


for berkas in sorted(SRC.rglob("*.kt")):
    for no, baris in enumerate(berkas.read_text(encoding="utf-8").split("\n"), 1):
        m = re.search(r'\bconst\s+val\s+\w+\s*(?::\s*[\w.<>?]+)?\s*=\s*(.+)$', baris)
        if not m:
            continue
        nilai = potong_komentar(m.group(1)).strip().rstrip(";").strip()
        if "companion" in baris and ";" in nilai:
            nilai = nilai.split(";")[0].strip()
        if not ekspresi.fullmatch(nilai):
            masalah.append("%s:%d: const val bukan konstanta: %s" % (berkas.relative_to(ROOT), no, nilai[:90]))

if masalah:
    print("PEMERIKSAAN CONST VAL: GAGAL")
    for x in masalah:
        print("- " + x)
    sys.exit(1)
print("PEMERIKSAAN CONST VAL: LULUS")
