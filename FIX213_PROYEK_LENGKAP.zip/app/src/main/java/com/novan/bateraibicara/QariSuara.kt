package com.novan.bateraibicara

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * FIX142: pemilihan qari lewat perintah suara tanpa membuka layar Khatam.
 * Logikanya sama dengan yang ada di KhatamActivity (FIX88): "pilih qari Alafasy", "ganti qari ke Sudais",
 * "putar surah Yasin dengan qari Husary", "pilih qari anak". Nama dicocokkan secara fonetik longgar terhadap
 * katalog qari per ayat dan katalog qari per surah yang sudah tersimpan di cache Khatam.
 */
object QariSuara {
    private val daftarQari = listOf(
        "ar.alafasy" to "Mishary Rashid Alafasy",
        "ar.husary" to "Mahmoud Khalil Al-Husary",
        "ar.minshawi" to "Mohamed Siddiq Al-Minshawi · tartil",
        "ar.abdurrahmaansudais" to "Abdurrahman As-Sudais",
        "ar.saoodshuraym" to "Saud Al-Shuraim",
        "ar.abdulbasitmurattal" to "Abdul Basit Abdus Samad · murattal",
        "ar.ahmedajamy" to "Ahmed ibn Ali Al-Ajamy",
        "ar.muhammadayyoub" to "Muhammad Ayyoub",
        "ar.hudhaify" to "Ali Al-Hudhaify",
        "ar.shaatree" to "Abu Bakr Ash-Shaatree",
        "ar.mahermuaiqly" to "Maher Al-Muaiqly",
        "ar.yasseraldosari" to "Yasser Al-Dosari",
        "ar.nasserqatami" to "Nasser Al-Qatami",
        "ar.hanirifai" to "Hani Ar-Rifai",
        "ar.husarymujawwad" to "Mahmoud Khalil Al-Husary · mujawwad",
        "ar.minshawimujawwad" to "Mohamed Siddiq Al-Minshawi · mujawwad",
        "ar.muhammadjibreel" to "Muhammad Jibreel",
        "ar.abdullahbasfar" to "Abdullah Basfar",
        "ar.ibrahimakhbar" to "Ibrahim Al-Akhdar",
        "ar.aymanswoaid" to "Ayman Sowaid",
        "ar.abdulsamad" to "Abdul Basit Abdus Samad · mujawwad",
        "ar.parhizgar" to "Shahriar Parhizgar"
    )

    private val qariTahaCadangan: Pair<String, String> =
        ("mp3quran|https://archive.org/download/Muhammad-Taha-Al-Junaid/|" + (1..114).joinToString(",")) to "Anak · Muhammad Taha Al-Junayd"

    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori")
    private val kataKerjaPilih = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set",
        "choose", "select", "switch", "change", "use", "with", "dengan", "oleh", "by", "using")
    private val kataHentiNamaQari = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "lalu", "kemudian", "then", "and", "dan",
        "surah", "surat", "sura", "ayat", "ayah", "verse", "juz", "jus", "juzz", "untuk", "for")
    private val kataAbaikanAwalNama = setOf("ke", "menjadi", "jadi", "to", "as", "the", "a", "bernama", "nama", "named", "yang", "adalah")
    private val kataPengisiPerintah = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "lalu", "kemudian", "then", "and", "dan",
        "tolong", "please", "dengan", "dari", "untuk", "for", "ke", "to", "with", "by", "oleh", "saja", "now", "sekarang")
    private val kataAnakQari = setOf("anak", "anakanak", "kid", "kids", "child", "children", "cilik", "kecil")

    fun sisaHanyaPengisi(sisa: String): Boolean =
        sisa.split(" ").filter { it.isNotBlank() }.all { it in kataPengisiPerintah }

    /**
     * Pisahkan ucapan menjadi (nama qari yang disebut, sisa ucapan tanpa klausa qari); null bila bukan perintah qari.
     * Contoh: "putar surah yasin dengan qari alafasy" menjadi ("alafasy", "putar surah yasin").
     */
    fun pisah(ucapan: String): Pair<String, String>? {
        val tokens = ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() }
        val idx = tokens.indexOfFirst { it in kataQariPasti || it in kataQariMirip }
        if (idx < 0) return null
        if (tokens[idx] in kataQariMirip && tokens.none { it in kataKerjaPilih }) return null
        val nama = mutableListOf<String>()
        var akhir = idx + 1
        while (akhir < tokens.size && tokens[akhir] !in kataHentiNamaQari) { nama.add(tokens[akhir]); akhir++ }
        while (nama.isNotEmpty() && nama.first() in kataAbaikanAwalNama) nama.removeAt(0)
        var awal = idx
        while (awal > 0 && tokens[awal - 1] in kataKerjaPilih) awal--
        val sisa = tokens.subList(0, awal) + tokens.subList(akhir, tokens.size)
        return nama.joinToString(" ") to sisa.joinToString(" ")
    }

    private fun jumlahSurahQari(id: String): Int =
        id.split("|").getOrNull(2)?.split(",")?.mapNotNull { it.trim().toIntOrNull() }?.filter { it in 1..114 }?.toSet()?.size ?: 0

    private fun qariLengkap(id: String): Boolean = !id.startsWith("mp3quran|") || jumlahSurahQari(id) >= 114

    @Volatile private var cacheBerkasKatalog: Pair<Long, List<Pair<String, String>>>? = null

    /**
     * FIX191: katalog LENGKAP qari per surah (bukan hanya qari anak) yang disimpan Khatam di penyimpanan aplikasi. Dibaca tanpa jaringan
     * dan di-cache di memori selama berkas tidak berubah.
     */
    private fun katalogDariBerkas(context: Context): List<Pair<String, String>> {
        return try {
            val berkas = File(context.filesDir, "katalog_qari_mp3quran.json")
            if (!berkas.exists()) return emptyList()
            val stempel = berkas.lastModified()
            cacheBerkasKatalog?.let { if (it.first == stempel) return it.second }
            val arsip = org.json.JSONArray(berkas.readText(Charsets.UTF_8))
            val hasil = ArrayList<Pair<String, String>>()
            for (i in 0 until arsip.length()) {
                val baris = arsip.optJSONArray(i) ?: continue
                val id = baris.optString(0)
                val label = baris.optString(1)
                if (id.startsWith("mp3quran|") && qariLengkap(id) && label.isNotBlank() && !label.startsWith("Perempuan · ") && hasil.none { it.first == id }) hasil.add(id to label)
            }
            cacheBerkasKatalog = stempel to hasil
            hasil
        } catch (_: Exception) { emptyList() }
    }

    /** Katalog qari per surah yang sudah tersimpan di cache Khatam (tanpa jaringan). */
    private fun katalogPerSurah(context: Context): List<Pair<String, String>> {
        val hasil = ArrayList<Pair<String, String>>()
        katalogDariBerkas(context).forEach { q -> if (hasil.none { it.first == q.first }) hasil.add(q) }
        try {
            val teks = context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).getString("katalog_qari_anak_cache", null) ?: return hasil
            val anak = org.json.JSONArray(teks)
            for (i in 0 until anak.length()) {
                val baris = anak.optJSONArray(i) ?: continue
                val id = baris.optString(0)
                val label = baris.optString(1)
                if (id.startsWith("mp3quran|") && qariLengkap(id) && label.isNotBlank() && !label.startsWith("Perempuan · ") && hasil.none { it.first == id }) hasil.add(id to label)
            }
        } catch (_: Exception) { }
        return hasil
    }

    private fun fonetik(s: String): String {
        var t = s.lowercase(Locale.ROOT).filter { it in 'a'..'z' }
        for ((a, b) in listOf("sy" to "sh", "kh" to "h", "dh" to "d", "dz" to "d", "th" to "t", "gh" to "g", "ph" to "f",
            "ou" to "u", "oo" to "u", "ee" to "i", "ei" to "i", "ai" to "i", "ay" to "i")) t = t.replace(a, b)
        t = t.replace('y', 'i').replace('e', 'i').replace('o', 'u').replace('w', 'u').replace('q', 'k').replace('c', 'k')
        val sb = StringBuilder()
        for (ch in t) if (sb.isEmpty() || sb[sb.length - 1] != ch) sb.append(ch)
        return sb.toString()
    }

    private fun jarakEdit(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var sebelum = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val kini = IntArray(b.length + 1)
            kini[0] = i
            for (j in 1..b.length) {
                val biaya = if (a[i - 1] == b[j - 1]) 0 else 1
                kini[j] = minOf(kini[j - 1] + 1, sebelum[j] + 1, sebelum[j - 1] + biaya)
            }
            sebelum = kini
        }
        return sebelum[b.length]
    }

    private fun namaInti(label: String): String =
        label.removePrefix("Anak · ").removePrefix("Perempuan · ").removePrefix("MP3Quran · ").substringBefore(" ·").trim()

    private fun normalisasi(nama: String): String =
        nama.replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9\\u0600-\\u06FF]"), "")

    private fun peringkatAnak(nama: String): Int {
        val n = normalisasi(nama)
        if (n.isEmpty()) return -1
        val junaid = Regex("j[uoi]n[aeiyu]{1,3}d")
        val muhammad = Regex("m[uo]h?[ao]mm?[ae]d")
        return when {
            (n.contains("taha") && (junaid.containsMatchIn(n) || muhammad.containsMatchIn(n))) ||
                (n.contains("طه") && (n.contains("جنيد") || n.contains("جنید"))) -> 0
            Regex("ah?m[ae]d(bin|ibn)?(saud|saaud|saoud|saood|sa3ud|suud)").containsMatchIn(n) || n.contains("احمدسعود") -> 1
            Regex("j[uoi]n[aeiyu]{1,3}dadam").containsMatchIn(n) || (n.contains("جنيد") && n.contains("ادم")) -> 2
            else -> -1
        }
    }

    private fun daftarAnakTerurut(perSurah: List<Pair<String, String>>): List<Pair<String, String>> {
        val dariKatalog = perSurah.filter { it.second.startsWith("Anak · ") && qariLengkap(it.first) }
        val lengkap = if (dariKatalog.any { peringkatAnak(it.second) == 0 }) dariKatalog else dariKatalog + qariTahaCadangan
        return lengkap.sortedBy { peringkatAnak(it.second).let { r -> if (r < 0) 99 else r } }
    }

    /** Cari qari dari nama yang diucapkan. Mengembalikan pasangan (id, label) atau null bila tidak ada yang cocok. */
    fun cari(context: Context, nama: String, qariSaatIni: String, tambahan: List<Pair<String, String>> = emptyList()): Pair<String, String>? {
        val perSurah = ArrayList(katalogPerSurah(context))
        tambahan.forEach { q -> if (perSurah.none { it.first == q.first }) perSurah.add(q) }
        val kataAbaikan = setOf("al", "el", "as", "ash", "ad", "an", "ar", "az", "at", "bin", "ibn")
        val tokenUcapan = nama.lowercase().replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.isNotBlank() }
        val mintaAnak = tokenUcapan.any { it in kataAnakQari }
        val mintaMujawwad = tokenUcapan.any { it.startsWith("mujaw") }
        val bersih = tokenUcapan.filter { it !in kataAnakQari && !it.startsWith("mujaw") && it !in kataAbaikan && it != "murattal" && it != "tartil" }
        if (mintaAnak && bersih.isEmpty()) return daftarAnakTerurut(perSurah).firstOrNull()
        if (bersih.isEmpty()) return null

        val kumpulan = mutableListOf<Pair<String, String>>()
        kumpulan.addAll(daftarQari)
        perSurah.forEach { q -> if (kumpulan.none { it.first == q.first }) kumpulan.add(q) }
        if (kumpulan.none { it.second.startsWith("Anak · ") && peringkatAnak(it.second) == 0 }) kumpulan.add(qariTahaCadangan)
        val kolam = if (mintaAnak) kumpulan.filter { it.second.startsWith("Anak · ") } else kumpulan

        var terbaik: Pair<String, String>? = null
        var skorTerbaik = Double.NEGATIVE_INFINITY
        for (c in kolam) {
            val tokenC = namaInti(c.second).lowercase().replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.isNotBlank() && it !in kataAbaikan }
            val varian = tokenC.flatMap { t -> listOfNotNull(fonetik(t), if (t.startsWith("al") && t.length >= 5) fonetik(t.substring(2)) else null) }
            val gabung = fonetik(tokenC.joinToString(""))
            var cocok = 0; var panjang = 0; var jarakTotal = 0
            for (q in bersih) {
                val fq = fonetik(q)
                if (fq.length < 2) continue
                val batas = when { fq.length <= 3 -> 0; fq.length <= 6 -> 1; else -> 2 }
                val jarak = if (fq.length >= 6 && gabung.contains(fq)) 0 else (varian.minOfOrNull { jarakEdit(fq, it) } ?: 99)
                if (jarak <= batas) { cocok++; panjang += q.length; jarakTotal += jarak }
            }
            if (cocok == 0 || panjang < 4 || cocok * 2 < bersih.size) continue
            var skor = cocok * 100.0 + panjang - (bersih.size - cocok) * 30.0 - jarakTotal * 10.0
            val mujawwadLabel = c.second.contains("mujawwad", ignoreCase = true)
            skor += if (mujawwadLabel == mintaMujawwad) 15.0 else -15.0
            if (!c.first.startsWith("mp3quran|")) skor += 5.0
            if (c.first == qariSaatIni) skor += 1.0
            if (skor > skorTerbaik) { skorTerbaik = skor; terbaik = c }
        }
        return terbaik
    }

    // ===== FIX191: qari yang belum ada di daftar offline dicari secara online =====

    /** Label qari dari identifier (mis. "ar.alafasy"), dipakai untuk mencocokkan berkas audio yang tersimpan di HP. */
    fun labelDariId(context: Context, id: String): String? =
        daftarQari.firstOrNull { it.first == id }?.second ?: katalogPerSurah(context).firstOrNull { it.first == id }?.second

    /**
     * Cari qari yang diminta pada katalog MP3Quran ONLINE bila tidak ada di daftar offline. Blokir: panggil dari thread latar.
     * Katalog hasil unduhan juga disimpan ke berkas katalog Khatam bila berkas itu belum ada, sehingga pencarian berikutnya tanpa jaringan.
     */
    fun cariOnline(context: Context, nama: String, qariSaatIni: String): Pair<String, String>? {
        val katalog = unduhKatalogOnline(context) ?: return null
        return cari(context, nama, qariSaatIni, katalog)
    }

    private fun ambilTeks(alamat: String): String {
        val k = URL(alamat).openConnection() as HttpURLConnection
        k.connectTimeout = 8_000
        k.readTimeout = 12_000
        k.setRequestProperty("User-Agent", "JamPintarPro/1.0.85")
        try {
            if (k.responseCode !in 200..299) throw IllegalStateException("HTTP " + k.responseCode)
            return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { try { k.disconnect() } catch (_: Exception) { } }
    }

    private fun unduhKatalogOnline(context: Context): List<Pair<String, String>>? {
        return try {
            val reciters = JSONObject(ambilTeks("https://mp3quran.net/api/v3/reciters?language=eng")).optJSONArray("reciters") ?: return null
            val hasil = ArrayList<Pair<String, String>>()
            for (i in 0 until reciters.length()) {
                val r = reciters.optJSONObject(i) ?: continue
                val nama = r.optString("name").trim()
                if (nama.isBlank()) continue
                val sumber = sumberMoshaf(r)
                if (sumber.isEmpty()) continue
                val id = "mp3quran|" + sumber.first().first + "|" + sumber.first().second
                if (jumlahSurahQari(id) < 114) continue
                hasil.add(id to ((if (peringkatAnak(nama) >= 0) "Anak · " else "MP3Quran · ") + namaLatin(nama)))
            }
            if (hasil.isNotEmpty()) {
                try {
                    val berkas = File(context.filesDir, "katalog_qari_mp3quran.json")
                    if (!berkas.exists()) {
                        val arsip = org.json.JSONArray()
                        hasil.forEach { arsip.put(org.json.JSONArray().put(it.first).put(it.second)) }
                        berkas.writeText(arsip.toString(), Charsets.UTF_8)
                    }
                } catch (_: Exception) { }
            }
            hasil
        } catch (_: Exception) { null }
    }

    /**
     * Semua rekaman https milik satu qari MP3Quran yang punya daftar surah, diurutkan dari yang paling lengkap.
     * Pasangan: (alamat server berakhiran "/", daftar nomor surah dipisah koma). Server http:// dinaikkan ke https://.
     * Dipakai bersama oleh Khatam dan perintah suara.
     */
    fun sumberMoshaf(r: JSONObject): List<Pair<String, String>> {
        val moshaf = r.optJSONArray("moshaf") ?: return emptyList()
        val hasil = mutableListOf<Triple<String, String, Int>>()
        for (k in 0 until moshaf.length()) {
            val m = moshaf.optJSONObject(k) ?: continue
            var server = m.optString("server").trim()
            if (server.startsWith("http://")) server = "https://" + server.removePrefix("http://")
            val surahList = m.optString("surah_list").trim()
            if (!server.startsWith("https://") || surahList.isBlank()) continue
            val jumlah = surahList.split(",").count { it.trim().toIntOrNull() != null }
            if (jumlah == 0) continue
            hasil.add(Triple(server.trimEnd('/') + "/", surahList, jumlah))
        }
        return hasil.sortedByDescending { it.third }.map { it.first to it.second }
    }

    /** Nama qari dalam huruf Latin; nama Arab dipetakan bila dikenal, selain itu aksara Arab dibuang. */
    fun namaLatin(nama: String): String {
        if (nama.none { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.ARABIC }) return nama
        val peta = mapOf(
            "مشاري العفاسي" to "Mishary Rashid Alafasy",
            "محمود خليل الحصري" to "Mahmoud Khalil Al-Husary",
            "محمد صديق المنشاوي" to "Mohamed Siddiq Al-Minshawi",
            "عبدالرحمن السديس" to "Abdurrahman As-Sudais",
            "سعود الشريم" to "Saud Al-Shuraim",
            "عبدالباسط عبدالصمد" to "Abdul Basit Abdus Samad",
            "ماهر المعيقلي" to "Maher Al-Muaiqly",
            "ياسر الدوسري" to "Yasser Al-Dosari"
        )
        return peta[nama.trim()] ?: nama.filter { Character.UnicodeBlock.of(it) != Character.UnicodeBlock.ARABIC }
            .replace(Regex("\\s+"), " ").trim().ifBlank { "Qari (nama Latin tidak tersedia)" }
    }
}
