import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val keystorePath: String? = System.getenv("KEYSTORE_PATH")

// Nilai konfigurasi rilis dibaca dari variabel lingkungan (GitHub Actions) atau gradle.properties lokal,
// tidak ditulis di kode. Kosong = fitur terkait tampil sebagai "belum dikonfigurasi".
fun konfig(nama: String): String =
    (System.getenv(nama) ?: (project.findProperty(nama) as? String) ?: "").trim().replace("\"", "")
val githubRepo = konfig("GITHUB_REPOSITORY").ifEmpty { konfig("GITHUB_REPO") }.ifEmpty { "muhammadalispdi5-dev/Jam-pintar-Bro" }
val nomorWhatsapp = konfig("WHATSAPP_NUMBER")

android {
    namespace = "com.novan.bateraibicara"

    // Pertahankan M4A tanpa kompresi agar MediaPlayer dapat memakai openRawResourceFd().
    androidResources {
        noCompress += "m4a"
    }
    compileSdk = 36

    defaultConfig {
        applicationId = "com.novan.jambicarapro"
        minSdk = 24
        targetSdk = 36
        versionCode = 85
        versionName = "1.0.85"
        buildConfigField("String", "GITHUB_REPO", "\"$githubRepo\"")
        buildConfigField("String", "WHATSAPP_NUMBER", "\"$nomorWhatsapp\"")
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        if (keystorePath != null) {
            create("rilis") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (keystorePath != null) {
                signingConfigs.getByName("rilis")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    lint {
        checkReleaseBuilds = false
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
}
