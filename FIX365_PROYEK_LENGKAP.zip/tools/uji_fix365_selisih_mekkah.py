import sys
w=open("app/src/main/java/com/novan/bateraibicara/WaktuDunia.kt").read()
ok=True
for n,c in [("prioritas luar",'terbaikLuar' in w and 'zonaIndonesiaId' in w),("selisih dulu",'Selisih waktu antara Indonesia dan' in w),("urutan",'Lebih lambat $b dari' in w)]:
    if not c: ok=False; print("GAGAL:",n)
if ok: print("OK")
