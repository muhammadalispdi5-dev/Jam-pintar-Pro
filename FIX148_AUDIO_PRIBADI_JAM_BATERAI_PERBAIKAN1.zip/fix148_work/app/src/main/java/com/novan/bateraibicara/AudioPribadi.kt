package com.novan.bateraibicara

import android.content.Context
import android.media.MediaPlayer
import android.os.Environment
import java.io.File

/** Penyimpanan dan pemutar audio pribadi. Semua berkas disalin ke direktori milik aplikasi. */
object AudioPribadi {
    private var player: MediaPlayer? = null

    fun folder(context: Context, kategori: String, kunci: String): File {
        val dasar = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            ?: File(context.filesDir, "Musik")
        val namaKategori = if (kategori == "Jam") "Jam" else "Baterai"
        val akar = File(File(File(dasar, "Jam Pintar Pro"), "Audio Pribadi"), namaKategori)
        val namaFungsi = when (kunci) {
            "pengantar" -> "Pengantar_Pengucapan_Jam"
            "level" -> "Persentase_Baterai"
            "lemah" -> "Baterai_Lemah"
            "kritis" -> "Baterai_Kritis"
            "penuh" -> "Baterai_Penuh"
            "charger_on" -> "Pengisi_Daya_Terhubung"
            "charger_off" -> "Pengisi_Daya_Dilepas"
            "usb_on" -> "USB_Terhubung"
            "usb_off" -> "USB_Dilepas"
            else -> kunci.replace(Regex("[^A-Za-z0-9_-]"), "_")
        }
        val dir = File(akar, namaFungsi)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun berkas(context: Context, kategori: String, kunci: String): File? {
        val dir = folder(context, kategori, kunci)
        return dir.listFiles()?.firstOrNull { it.isFile && it.nameWithoutExtension == "audio" }
    }

    fun simpan(context: Context, kategori: String, kunci: String, sumber: android.net.Uri): File {
        val dir = folder(context, kategori, kunci)
        val mime = context.contentResolver.getType(sumber).orEmpty()
        val ext = when {
            mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
            mime.contains("wav") -> "wav"
            mime.contains("ogg") -> "ogg"
            mime.contains("mp4") || mime.contains("m4a") || mime.contains("audio/") -> "m4a"
            else -> "mp3"
        }
        dir.listFiles()?.filter { it.isFile && it.nameWithoutExtension == "audio" }?.forEach { it.delete() }
        val tujuan = File(dir, "audio.$ext")
        context.contentResolver.openInputStream(sumber).use { input ->
            requireNotNull(input) { "Berkas audio tidak dapat dibuka" }
            tujuan.outputStream().use { output -> input.copyTo(output) }
        }
        return tujuan
    }

    fun hapus(context: Context, kategori: String, kunci: String) {
        berkas(context, kategori, kunci)?.delete()
    }

    fun putar(context: Context, kategori: String, kunci: String, selesai: (() -> Unit)? = null): Boolean {
        val file = berkas(context, kategori, kunci) ?: return false
        try {
            hentikan()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener {
                try { it.release() } catch (_: Exception) { }
                if (player === it) player = null
                selesai?.invoke()
            }
            mp.setOnErrorListener { p, _, _ ->
                try { p.release() } catch (_: Exception) { }
                if (player === p) player = null
                selesai?.invoke()
                true
            }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
            return true
        } catch (_: Exception) {
            hentikan()
            return false
        }
    }

    fun hentikan() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }
}
