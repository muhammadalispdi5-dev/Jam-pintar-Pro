# FIX148 — Audio pribadi untuk Jam dan notifikasi Baterai

Basis: FIX147 Timer Jam Pintar Pro.

## Implementasi
- Menambahkan `AudioPribadi.kt` untuk membuat direktori audio milik aplikasi, menyalin audio yang dipilih pengguna, memutar, menguji, dan menghapusnya.
- Berkas dipilih melalui Android Storage Access Framework (`ACTION_OPEN_DOCUMENT`), lalu disalin ke penyimpanan eksternal khusus aplikasi. Tidak memerlukan izin akses seluruh penyimpanan.
- Direktori dasar: `Android/data/com.novan.jambicarapro/files/Music/Jam Pintar Pro/Audio Pribadi/`.
- Jam: subfolder `Jam/Pengantar_Pengucapan_Jam/`.
- Baterai: subfolder terpisah untuk Persentase_Baterai, Baterai_Lemah, Baterai_Kritis, Baterai_Penuh, Pengisi_Daya_Terhubung, Pengisi_Daya_Dilepas, USB_Terhubung, dan USB_Dilepas.
- Pengumuman Jam memutar audio pengantar pilihan (jika ada), lalu TTS tetap membacakan waktu dinamis. Melodi awal tetap dihormati.
- Pengumuman baterai memutar audio kategori yang dipilih, kemudian TTS membacakan isi dinamis; beberapa kejadian diantrikan berurutan agar tidak saling menimpa. Pengulangan baterai penuh juga memakai audio kategorinya.
- Jika audio tidak dipilih atau gagal diputar, TTS tetap digunakan.
- Menu menyediakan pilih, tes, dan hapus untuk setiap audio. Status dan lokasi folder ditampilkan.
- Menambahkan terjemahan UI bahasa Inggris untuk menu baru.
- Version code/name dinaikkan menjadi 83 / 1.0.83.

## Batasan yang harus diketahui
- Rekaman Jam pada build ini adalah audio pengantar sebelum pengucapan waktu dinamis oleh TTS. Rekaman angka 0–9 dan perangkaian angka menjadi ucapan jam belum diimplementasikan pada versi ini.
- Audio notifikasi baterai berfungsi sebagai pengantar kategori; TTS tetap menyampaikan nilai persentase yang berubah-ubah.
- Audio disimpan di direktori khusus aplikasi pada `Android/data`; Android modern membatasi akses langsung aplikasi pengelola berkas ke direktori tersebut. Pengguna dapat memilih sumber audio dari lokasi mana pun melalui pemilih berkas Android.
- Format yang diterima mengikuti MIME audio perangkat; MP3, WAV, OGG, dan M4A diupayakan berdasarkan tipe MIME.
- ZIP telah diperiksa integritasnya. Kompilasi Gradle belum dijalankan di lingkungan ini karena Gradle/Gradle Wrapper tidak tersedia.
