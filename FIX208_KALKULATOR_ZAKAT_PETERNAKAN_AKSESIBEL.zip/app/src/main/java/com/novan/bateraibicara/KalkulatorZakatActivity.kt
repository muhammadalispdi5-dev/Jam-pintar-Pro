package com.novan.bateraibicara

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.app.AlertDialog
import java.text.NumberFormat
import java.util.Locale
import org.json.JSONArray

/**
 * Kalkulator zakat mandiri. Semua masukan memakai label yang terhubung ke EditText
 * agar terbaca pembaca layar. Rumus dan asumsi ditampilkan bersama hasil.
 */
class KalkulatorZakatActivity : Halaman() {

    override val judulHalaman = R.string.judul_kalkulator_zakat

    private enum class Jenis {
        EMAS_PERAK, TABUNGAN, PERDAGANGAN, PERTANIAN, FITRAH, PENGHASILAN
    }

    private var jenisAktif: Jenis? = null
    private lateinit var menuJenis: LinearLayout
    private lateinit var formulir: LinearLayout
    private lateinit var hasil: TextView
    private val isian = LinkedHashMap<String, EditText>()
    private var saklarHaul: android.widget.Switch? = null
    private var pilihanLogam: Spinner? = null
    private var pilihanIrigasi: Spinner? = null
    private var pilihanFitrah: Spinner? = null
    private var pilihanPeriode: Spinner? = null
    private var pilihanHewan: Spinner? = null
    private var pilihanGembala: Spinner? = null
    private var hasilTerakhir: String = ""

    override fun bangun() {
        info(tr(
            "Pilih jenis zakat. Isi angka tanpa pemisah ribuan, lalu tekan Hitung zakat. Hasil disertai penjelasan asumsi perhitungan.",
            "Choose a zakat type. Enter numbers without thousands separators, then tap Calculate zakat. The result includes the calculation assumptions."
        ))
        menuJenis = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        formulir = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        root.addView(menuJenis)
        root.addView(formulir)

        tambahMenu(Jenis.EMAS_PERAK, tr("Zakat emas dan perak", "Gold and silver zakat"),
            tr("Hitung berdasarkan berat, harga per gram, nisab, dan haul.", "Calculate using weight, price per gram, nisab, and haul."))
        tambahMenu(Jenis.TABUNGAN, tr("Zakat tabungan dan uang", "Savings and cash zakat"),
            tr("Hitung harta bersih yang memenuhi nisab dan haul.", "Calculate net eligible wealth subject to nisab and haul."))
        tambahMenu(Jenis.PERDAGANGAN, tr("Zakat perdagangan", "Business and trade zakat"),
            tr("Hitung aset usaha bersih yang memenuhi nisab dan haul.", "Calculate net business assets subject to nisab and haul."))
        tambahMenu(Jenis.PERTANIAN, tr("Zakat pertanian", "Agricultural zakat"),
            tr("Hitung hasil panen berdasarkan nisab dan metode pengairan.", "Calculate harvest based on the nisab and irrigation method."))
        tambahMenu(Jenis.FITRAH, tr("Zakat fitrah", "Zakat al-Fitr"),
            tr("Hitung kebutuhan beras atau nilai uang untuk seluruh anggota keluarga.", "Calculate rice quantity or cash value for the household."))
        tambahMenu(Jenis.PENGHASILAN, tr("Zakat penghasilan atau profesi", "Income or professional zakat"),
            tr("Hitung dengan metode nisab bulanan atau tahunan.", "Calculate using a monthly or annual nisab method."))
        tambahMenu(Jenis.PETERNAKAN, tr("Zakat peternakan", "Livestock zakat"),
            tr("Hitung zakat kambing atau domba, sapi atau kerbau, dan unta berdasarkan jumlah ternak.", "Calculate zakat for goats or sheep, cattle or buffalo, and camels based on herd size."))

        info(tr(
            "Catatan: kalkulator ini alat bantu. Perbedaan ketentuan fikih dapat terjadi. Ikuti pedoman lembaga zakat atau ulama tepercaya di wilayah Anda.",
            "Note: this calculator is a guide. Jurisprudential rules may differ. Follow the guidance of a trusted zakat institution or scholar in your area."
        ))
        tombolAkses(menuJenis, tr("Riwayat perhitungan zakat", "Zakat calculation history")) { tampilkanRiwayat() }
    }

    private fun tambahMenu(jenis: Jenis, judul: String, keterangan: String) {
        val b = tombolAkses(menuJenis, judul) { bukaForm(jenis) }
        b.contentDescription = "$judul. $keterangan"
        val tv = TextView(this).apply {
            text = keterangan
            textSize = 14f
            setTextColor(warnaPetunjuk())
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        menuJenis.addView(tv)
    }

    private fun tombolAkses(parent: LinearLayout, label: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 16f
        b.minimumHeight = dp(52)
        b.setTextColor(android.graphics.Color.WHITE)
        b.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(warnaAksen())
            cornerRadius = dp(14).toFloat()
        }
        b.contentDescription = label
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        b.setOnClickListener { aksi() }
        parent.addView(b, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(5); bottomMargin = dp(5) })
        return b
    }

    private fun bukaForm(jenis: Jenis) {
        jenisAktif = jenis
        menuJenis.visibility = View.GONE
        formulir.visibility = View.VISIBLE
        formulir.removeAllViews()
        isian.clear()
        saklarHaul = null
        pilihanLogam = null
        pilihanIrigasi = null
        pilihanFitrah = null
        pilihanPeriode = null
        pilihanHewan = null
        pilihanGembala = null
        hasilTerakhir = ""

        tombolAkses(formulir, tr("Ganti jenis zakat", "Choose another zakat type")) {
            formulir.visibility = View.GONE
            menuJenis.visibility = View.VISIBLE
            jenisAktif = null
        }
        val judul = when (jenis) {
            Jenis.EMAS_PERAK -> tr("Zakat emas dan perak", "Gold and silver zakat")
            Jenis.TABUNGAN -> tr("Zakat tabungan dan uang", "Savings and cash zakat")
            Jenis.PERDAGANGAN -> tr("Zakat perdagangan", "Business and trade zakat")
            Jenis.PERTANIAN -> tr("Zakat pertanian", "Agricultural zakat")
            Jenis.FITRAH -> tr("Zakat fitrah", "Zakat al-Fitr")
            Jenis.PENGHASILAN -> tr("Zakat penghasilan atau profesi", "Income or professional zakat")
            Jenis.PETERNAKAN -> tr("Zakat peternakan", "Livestock zakat")
        }
        tambahJudul(formulir, judul)

        when (jenis) {
            Jenis.EMAS_PERAK -> {
                pilihanLogam = tambahPilihan(formulir, tr("Jenis logam", "Metal type"),
                    listOf(tr("Emas", "Gold"), tr("Perak", "Silver")))
                tambahAngka("berat", tr("Berat logam dalam gram", "Metal weight in grams"), "0")
                tambahAngka("harga", tr("Harga per gram dalam rupiah", "Price per gram in rupiah"), "0")
                tambahHaul()
                tambahCatatan(tr(
                    "Acuan nisab: emas 85 gram atau perak 595 gram. Tarif 2,5% jika telah dimiliki satu haul. Pastikan harga per gram diperbarui sendiri.",
                    "Reference nisab: 85 grams of gold or 595 grams of silver. Rate is 2.5% after one lunar year of ownership. Update the per-gram price yourself."
                ))
            }
            Jenis.TABUNGAN -> {
                tambahAngka("harta", tr("Total tabungan, uang tunai, dan harta sejenis yang memenuhi syarat (rupiah)", "Total eligible savings, cash, and similar assets (rupiah)"), "0")
                tambahAngka("utang", tr("Utang jatuh tempo yang boleh diperhitungkan (rupiah)", "Due debts that may be deducted (rupiah)"), "0")
                tambahAngka("harga", tr("Harga emas per gram (rupiah)", "Gold price per gram (rupiah)"), "0")
                tambahHaul()
                tambahCatatan(tr(
                    "Nisab acuan setara 85 gram emas. Harta bersih dihitung setelah pengurangan utang jatuh tempo yang diperbolehkan. Ketentuan pengurangan utang dapat berbeda.",
                    "Reference nisab equals 85 grams of gold. Net wealth is calculated after eligible due debts. Debt deductions may differ by guidance."
                ))
            }
            Jenis.PERDAGANGAN -> {
                tambahAngka("aset", tr("Nilai persediaan barang, kas, dan piutang tertagih (rupiah)", "Value of inventory, cash, and collectible receivables (rupiah)"), "0")
                tambahAngka("utang", tr("Kewajiban usaha jangka pendek yang diperhitungkan (rupiah)", "Eligible short-term business liabilities (rupiah)"), "0")
                tambahAngka("harga", tr("Harga emas per gram (rupiah)", "Gold price per gram (rupiah)"), "0")
                tambahHaul()
                tambahCatatan(tr(
                    "Nisab acuan setara 85 gram emas dan tarif 2,5%. Masukkan nilai pada akhir haul; perlakuan aset dan kewajiban mengikuti pedoman zakat perdagangan yang Anda gunakan.",
                    "Reference nisab equals 85 grams of gold and the rate is 2.5%. Enter values at the end of the haul; asset and liability treatment should follow your chosen trade-zakat guidance."
                ))
            }
            Jenis.PERTANIAN -> {
                tambahAngka("panen", tr("Hasil panen setara gabah dalam kilogram", "Harvest in kilograms, expressed as unhusked-rice equivalent"), "0")
                pilihanIrigasi = tambahPilihan(formulir, tr("Sumber pengairan", "Irrigation source"),
                    listOf(tr("Air hujan atau alami (10%)", "Rainwater or natural (10%)"),
                        tr("Irigasi berbiaya (5%)", "Costly irrigation (5%)"),
                        tr("Campuran (7,5%)", "Mixed (7.5%)")))
                tambahCatatan(tr(
                    "Acuan yang digunakan: nisab 653 kg gabah. Masukkan hasil panen dalam satuan setara gabah. Tarif mengikuti jenis pengairan.",
                    "Reference used: nisab of 653 kg of unhusked rice. Enter harvest in unhusked-rice equivalent. The rate depends on irrigation."
                ))
            }
            Jenis.FITRAH -> {
                tambahAngka("orang", tr("Jumlah jiwa yang dibayarkan zakat fitrahnya", "Number of people covered"), "1", bilanganBulat = true)
                pilihanFitrah = tambahPilihan(formulir, tr("Pembayaran dengan", "Payment as"),
                    listOf(tr("Beras", "Rice"), tr("Uang", "Cash")))
                tambahAngka("beras", tr("Beras per orang dalam kilogram (acuan 2,5 kg)", "Rice per person in kilograms (2.5 kg reference)"), "2.5")
                tambahAngka("harga", tr("Harga beras per kilogram (rupiah), untuk pembayaran uang", "Rice price per kilogram (rupiah), for cash payment"), "0")
                tambahCatatan(tr(
                    "Acuan beras 2,5 kg per jiwa. Nilai uang mengikuti harga beras dan ketentuan lembaga zakat setempat; periksa ketetapan daerah Anda.",
                    "Reference is 2.5 kg of rice per person. Cash value follows rice prices and local zakat authority guidance; check your area's current ruling."
                ))
            }
            Jenis.PENGHASILAN -> {
                pilihanPeriode = tambahPilihan(formulir, tr("Periode perhitungan", "Calculation period"),
                    listOf(tr("Bulanan", "Monthly"), tr("Tahunan", "Annual")))
                tambahAngka("penghasilan", tr("Penghasilan kotor pada periode yang dipilih (rupiah)", "Gross income for the selected period (rupiah)"), "0")
                tambahAngka("harga", tr("Harga emas per gram (rupiah)", "Gold price per gram (rupiah)"), "0")
                tambahCatatan(tr(
                    "Nisab acuan setara 85 gram emas per tahun. Untuk metode bulanan, nisab tahunan dibagi 12. Zakat penghasilan memiliki perbedaan pandangan; gunakan metode yang sesuai dengan pedoman lembaga atau ulama yang Anda ikuti.",
                    "Reference nisab equals 85 grams of gold per year. For the monthly method, annual nisab is divided by 12. Opinions differ on income zakat; follow the method of your trusted zakat authority or scholar."
                ))
            }
            Jenis.PETERNAKAN -> {
                pilihanHewan = tambahPilihan(formulir, tr("Jenis ternak", "Livestock type"),
                    listOf(tr("Kambing atau domba", "Goats or sheep"), tr("Sapi atau kerbau", "Cattle or buffalo"), tr("Unta", "Camels")))
                tambahAngka("jumlahHewan", tr("Jumlah hewan ternak (ekor, bilangan bulat)", "Number of livestock (head, whole number)"), "0", bilanganBulat = true)
                pilihanGembala = tambahPilihan(formulir, tr("Pola pemeliharaan", "Herd management"),
                    listOf(tr("Digembalakan dan mencari pakan sendiri sebagian besar tahun", "Grazes freely for most of the year"), tr("Mayoritas diberi pakan yang dibeli atau dipelihara intensif", "Mostly stall-fed or supplied with purchased feed")))
                tambahHaul()
                tambahCatatan(tr(
                    "Acuan umum ternak zakat: kambing/domba mulai 40 ekor; sapi/kerbau mulai 30 ekor; unta mulai 5 ekor. Umumnya disyaratkan mencapai haul dan digembalakan bebas sebagian besar tahun. Ternak yang diperdagangkan dapat mengikuti aturan zakat perdagangan. Rincian jenis, umur, dan kondisi ternak harus diperiksa sesuai pedoman lembaga zakat/ulama setempat. Untuk unta lebih dari 120 ekor, kalkulator meminta konsultasi karena kombinasi umur dan jumlah memiliki tabel khusus.",
                    "General livestock references: goats/sheep start at 40; cattle/buffalo at 30; camels at 5. A haul and free grazing for most of the year are generally required. Livestock held for trade may follow trade-zakat rules. Animal type, age, and condition must be checked against local zakat guidance. For more than 120 camels, consult an authority because the age-and-count schedule is specialized."
                ))
            }
        }

        tombolAkses(formulir, tr("Hitung zakat", "Calculate zakat")) { hitung() }
        hasil = TextView(this).apply {
            text = tr("Hasil perhitungan akan ditampilkan di sini.", "The calculation result will appear here.")
            textSize = 17f
            setTextColor(warnaTeks())
            setPadding(dp(10), dp(14), dp(10), dp(14))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
            if (android.os.Build.VERSION.SDK_INT >= 19) accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        formulir.addView(hasil)
        tombolAkses(formulir, tr("Bacakan ulang hasil", "Read result again")) {
            if (hasilTerakhir.isNotBlank()) hasil.announceForAccessibility(hasilTerakhir)
            else hasil.announceForAccessibility(tr("Belum ada hasil. Tekan Hitung zakat terlebih dahulu.", "There is no result yet. Tap Calculate zakat first."))
        }
        tombolAkses(formulir, tr("Simpan hasil", "Save result")) { simpanHasil() }
        tombolAkses(formulir, tr("Lihat riwayat", "View history")) { tampilkanRiwayat() }
    }

    private fun tambahJudul(parent: LinearLayout, teks: String) {
        parent.addView(TextView(this).apply {
            text = teks
            textSize = 21f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(warnaAksen())
            setPadding(0, dp(12), 0, dp(8))
        })
    }

    private fun tambahCatatan(teks: String) {
        formulir.addView(TextView(this).apply {
            text = teks
            textSize = 14f
            setTextColor(warnaPetunjuk())
            setPadding(dp(4), dp(8), dp(4), dp(12))
        })
    }

    private fun tambahAngka(kunci: String, label: String, awal: String, bilanganBulat: Boolean = false) {
        val tv = TextView(this).apply {
            id = View.generateViewId()
            text = label
            textSize = 16f
            setTextColor(warnaTeks())
            setPadding(0, dp(10), 0, dp(2))
        }
        val et = EditText(this).apply {
            id = View.generateViewId()
            inputType = if (bilanganBulat) InputType.TYPE_CLASS_NUMBER
                else InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = label
            contentDescription = label
            setTextColor(warnaTeksIsian())
            setHintTextColor(warnaPetunjuk())
            setText(awal)
            tv.labelFor = id
        }
        isian[kunci] = et
        formulir.addView(tv)
        formulir.addView(et)
    }

    private fun tambahHaul() {
        val s = android.widget.Switch(this).apply {
            text = tr("Harta telah dimiliki satu haul (satu tahun Hijriah)", "Wealth has been held for one haul (one Hijri year)")
            isChecked = false
            textSize = 16f
            setTextColor(warnaTeks())
            contentDescription = text
            setPadding(0, dp(12), 0, dp(12))
        }
        saklarHaul = s
        formulir.addView(s)
    }

    private fun tambahPilihan(parent: LinearLayout, label: String, opsi: List<String>): Spinner {
        val tv = TextView(this).apply {
            id = View.generateViewId()
            text = label
            textSize = 16f
            setTextColor(warnaTeks())
            setPadding(0, dp(12), 0, dp(4))
        }
        val sp = Spinner(this)
        sp.id = View.generateViewId()
        tv.labelFor = sp.id
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opsi)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        parent.addView(tv)
        parent.addView(sp)
        return sp
    }

    private fun angka(kunci: String): Double {
        val raw = isian[kunci]?.text?.toString()?.trim().orEmpty()
        if (raw.isBlank()) return 0.0
        // Izinkan koma sebagai tanda desimal; pemisah ribuan tidak dianjurkan di petunjuk input.
        return raw.replace(',', '.').toDoubleOrNull() ?: Double.NaN
    }

    private fun rupiah(nilai: Double): String {
        val locale = if (BahasaAplikasi.tampilan(this) == 1) Locale.US else Locale("id", "ID")
        return NumberFormat.getCurrencyInstance(locale).apply {
            maximumFractionDigits = 0
            minimumFractionDigits = 0
        }.format(nilai.coerceAtLeast(0.0))
    }

    private fun hitung() {
        val jenis = jenisAktif ?: return
        val nol = tr("Masukkan angka yang valid dan tidak negatif pada semua kolom.", "Enter valid, non-negative numbers in all fields.")
        val nilai = isian.mapValues { angka(it.key) }
        if (nilai.values.any { it.isNaN() || it.isInfinite() || it < 0.0 }) {
            hasil.text = nol
            hasil.announceForAccessibility(nol)
            return
        }
        var wajib = 0.0
        var ringkasan = ""
        var dasar = ""
        var status = ""
        when (jenis) {
            Jenis.EMAS_PERAK -> {
                val perak = (pilihanLogam?.selectedItemPosition ?: 0) == 1
                val berat = nilai["berat"] ?: 0.0
                val harga = nilai["harga"] ?: 0.0
                val nisab = if (perak) 595.0 else 85.0
                val haul = saklarHaul?.isChecked == true
                if (berat >= nisab && harga <= 0.0) {
                    hasil.text = tr("Masukkan harga logam per gram yang valid.", "Enter a valid metal price per gram.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                val tercapai = berat >= nisab && haul
                wajib = if (tercapai) berat * harga * 0.025 else 0.0
                dasar = tr("Nisab", "Nisab") + ": $nisab " + tr("gram", "grams") +
                    "; " + tr("tarif 2,5%", "2.5% rate")
                status = when {
                    berat < nisab -> tr("Belum mencapai nisab.", "Nisab has not been reached.")
                    !haul -> tr("Belum memenuhi haul satu tahun Hijriah.", "The one Hijri-year haul has not been completed.")
                    else -> tr("Nisab dan haul terpenuhi.", "Nisab and haul are met.")
                }
                ringkasan = tr("Berat", "Weight") + ": $berat g; " + tr("nilai", "value") + ": ${rupiah(berat * harga)}"
            }
            Jenis.TABUNGAN -> {
                val bersih = ((nilai["harta"] ?: 0.0) - (nilai["utang"] ?: 0.0)).coerceAtLeast(0.0)
                val nisab = 85.0 * (nilai["harga"] ?: 0.0)
                val haul = saklarHaul?.isChecked == true
                val tercapai = nisab > 0 && bersih >= nisab && haul
                wajib = if (tercapai) bersih * 0.025 else 0.0
                dasar = tr("Harta bersih", "Net wealth") + ": ${rupiah(bersih)}; " + tr("nisab 85 gram emas", "85-gram gold nisab") + ": ${rupiah(nisab)}"
                status = when {
                    nisab <= 0 -> tr("Masukkan harga emas per gram.", "Enter the gold price per gram.")
                    bersih < nisab -> tr("Harta bersih belum mencapai nisab.", "Net wealth is below nisab.")
                    !haul -> tr("Belum memenuhi haul satu tahun Hijriah.", "The one Hijri-year haul has not been completed.")
                    else -> tr("Nisab dan haul terpenuhi.", "Nisab and haul are met.")
                }
                ringkasan = tr("Harta bersih setelah pengurangan", "Net wealth after deduction") + ": ${rupiah(bersih)}"
            }
            Jenis.PERDAGANGAN -> {
                val bersih = ((nilai["aset"] ?: 0.0) - (nilai["utang"] ?: 0.0)).coerceAtLeast(0.0)
                val nisab = 85.0 * (nilai["harga"] ?: 0.0)
                val haul = saklarHaul?.isChecked == true
                val tercapai = nisab > 0 && bersih >= nisab && haul
                wajib = if (tercapai) bersih * 0.025 else 0.0
                dasar = tr("Aset bersih usaha", "Net business assets") + ": ${rupiah(bersih)}; " + tr("nisab", "nisab") + ": ${rupiah(nisab)}; 2,5%"
                status = when {
                    nisab <= 0 -> tr("Masukkan harga emas per gram.", "Enter the gold price per gram.")
                    bersih < nisab -> tr("Aset bersih belum mencapai nisab.", "Net assets are below nisab.")
                    !haul -> tr("Belum memenuhi haul satu tahun Hijriah.", "The one Hijri-year haul has not been completed.")
                    else -> tr("Nisab dan haul terpenuhi.", "Nisab and haul are met.")
                }
                ringkasan = tr("Nilai aset bersih", "Net asset value") + ": ${rupiah(bersih)}"
            }
            Jenis.PERTANIAN -> {
                val panen = nilai["panen"] ?: 0.0
                val tarif = when (pilihanIrigasi?.selectedItemPosition ?: 0) { 1 -> 0.05; 2 -> 0.075; else -> 0.10 }
                val nisab = 653.0
                wajib = if (panen >= nisab) panen * tarif else 0.0
                dasar = tr("Nisab acuan 653 kg gabah", "Reference nisab 653 kg unhusked rice") + "; " +
                    tr("tarif", "rate") + ": " + (tarif * 100).toString().replace('.', ',') + "%"
                status = if (panen >= nisab) tr("Nisab panen terpenuhi.", "Harvest nisab is met.")
                    else tr("Hasil panen belum mencapai nisab.", "Harvest is below nisab.")
                ringkasan = tr("Hasil panen", "Harvest") + ": $panen kg"
            }
            Jenis.FITRAH -> {
                val orang = nilai["orang"] ?: 0.0
                val kgPerOrang = nilai["beras"] ?: 0.0
                val harga = nilai["harga"] ?: 0.0
                if (orang % 1.0 != 0.0) {
                    hasil.text = tr("Jumlah jiwa harus berupa bilangan bulat.", "The number of people must be a whole number.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                val totalKg = orang * kgPerOrang
                val uang = totalKg * harga
                val denganUang = pilihanFitrah?.selectedItemPosition == 1
                if (denganUang && orang > 0.0 && harga <= 0.0) {
                    hasil.text = tr("Masukkan harga beras per kilogram yang valid untuk menghitung pembayaran uang.", "Enter a valid rice price per kilogram to calculate cash payment.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                wajib = if (denganUang) uang else totalKg
                dasar = if (denganUang) tr("Nilai uang berdasarkan berat beras dan harga per kilogram", "Cash value based on rice weight and price per kilogram")
                    else tr("Jumlah beras yang perlu disiapkan", "Total rice to provide")
                status = tr("Periksa ketetapan zakat fitrah dari lembaga zakat setempat.", "Check the local zakat authority's current zakat al-Fitr guidance.")
                ringkasan = tr("Jumlah jiwa", "People") + ": ${orang.toInt()}; " + tr("total beras", "total rice") + ": $totalKg kg"
            }
            Jenis.PENGHASILAN -> {
                val income = nilai["penghasilan"] ?: 0.0
                val harga = nilai["harga"] ?: 0.0
                val tahunan = pilihanPeriode?.selectedItemPosition == 1
                val nisabTahunan = 85.0 * harga
                val nisabPeriode = if (tahunan) nisabTahunan else nisabTahunan / 12.0
                val tercapai = nisabPeriode > 0 && income >= nisabPeriode
                wajib = if (tercapai) income * 0.025 else 0.0
                dasar = tr("Nisab acuan", "Reference nisab") + ": ${rupiah(nisabPeriode)}; 2,5%"
                status = when {
                    nisabPeriode <= 0 -> tr("Masukkan harga emas per gram.", "Enter the gold price per gram.")
                    tercapai -> tr("Penghasilan mencapai nisab pada metode yang dipilih.", "Income reaches nisab under the selected method.")
                    else -> tr("Penghasilan belum mencapai nisab pada metode yang dipilih.", "Income is below nisab under the selected method.")
                }
                ringkasan = tr("Penghasilan periode ini", "Income for this period") + ": ${rupiah(income)}"
            }
            Jenis.PETERNAKAN -> {
                val jumlah = nilai["jumlahHewan"] ?: 0.0
                if (jumlah % 1.0 != 0.0) {
                    hasil.text = tr("Jumlah ternak harus berupa bilangan bulat.", "Livestock count must be a whole number.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                if (jumlah > 1000000.0) {
                    hasil.text = tr("Jumlah ternak terlalu besar untuk kalkulator ini. Silakan konsultasikan perhitungan kawanan besar kepada amil zakat.", "The herd count is too large for this calculator. Consult a zakat authority for a large-herd calculation.")
                    hasil.announceForAccessibility(hasil.text)
                    return
                }
                val n = jumlah.toInt()
                val jenisHewan = pilihanHewan?.selectedItemPosition ?: 0
                val digembala = pilihanGembala?.selectedItemPosition == 0
                val haul = saklarHaul?.isChecked == true
                val labelHewan = when (jenisHewan) {
                    1 -> tr("sapi atau kerbau", "cattle or buffalo")
                    2 -> tr("unta", "camels")
                    else -> tr("kambing atau domba", "goats or sheep")
                }
                val rincian: String
                val nisab: Int
                when (jenisHewan) {
                    1 -> {
                        nisab = 30
                        // Fiqh schedule: one tabi' for each 30, one musinnah for each 40.
                        // Find an exact decomposition to avoid undercounting a due category.
                        var best: Pair<Int, Int>? = null
                        var sisaTerbaik = Int.MAX_VALUE
                        for (musinnah in 0..(n / 40)) {
                            val sisa = n - musinnah * 40
                            val tabi = sisa / 30
                            val sisaAkhir = sisa - tabi * 30
                            if (sisaAkhir < 30 && sisaAkhir < sisaTerbaik) {
                                sisaTerbaik = sisaAkhir
                                best = tabi to musinnah
                            }
                        }
                        rincian = when {
                            n < 30 -> tr("Belum mencapai nisab sapi/kerbau 30 ekor.", "Below the cattle/buffalo nisab of 30.")
                            best != null -> {
                                val (tabi, musinnah) = best!!
                                buildString {
                                    if (tabi > 0) append("$tabi ").append(tr("ekor tabi' (sapi umur 1 tahun)", "tabi' (one-year-old bovine)"))
                                    if (tabi > 0 && musinnah > 0) append(tr(" dan ", " and "))
                                    if (musinnah > 0) append("$musinnah ").append(tr("ekor musinnah (sapi umur 2 tahun)", "musinnah (two-year-old bovine)"))
                                }
                            }
                            else -> tr("Jumlah ini berada di antara kelipatan nisab 30 dan 40. Periksa tabel perhitungan ternak kepada lembaga zakat setempat.", "This count falls between 30- and 40-head increments. Check the livestock schedule with a local zakat authority.")
                        }
                    }
                    2 -> {
                        nisab = 5
                        rincian = when (n) {
                            in 0..4 -> tr("Belum mencapai nisab unta 5 ekor.", "Below the camel nisab of 5.")
                            in 5..9 -> tr("1 ekor kambing/domba.", "1 sheep or goat.")
                            in 10..14 -> tr("2 ekor kambing/domba.", "2 sheep or goats.")
                            in 15..19 -> tr("3 ekor kambing/domba.", "3 sheep or goats.")
                            in 20..24 -> tr("4 ekor kambing/domba.", "4 sheep or goats.")
                            in 25..35 -> tr("1 ekor bint makhad (unta betina umur 1 tahun).", "1 bint makhad (one-year-old female camel).")
                            in 36..45 -> tr("1 ekor bint labun (unta betina umur 2 tahun).", "1 bint labun (two-year-old female camel).")
                            in 46..60 -> tr("1 ekor hiqqah (unta betina umur 3 tahun).", "1 hiqqah (three-year-old female camel).")
                            in 61..75 -> tr("1 ekor jadha'ah (unta betina umur 4 tahun).", "1 jadha'ah (four-year-old female camel).")
                            in 76..90 -> tr("2 ekor bint labun.", "2 bint labun camels.")
                            in 91..120 -> tr("2 ekor hiqqah.", "2 hiqqah camels.")
                            else -> tr("Untuk unta lebih dari 120 ekor, jumlah dan umur ternak harus dihitung dengan kombinasi khusus kelipatan 40 dan 50. Silakan konsultasikan kepada amil zakat.", "For more than 120 camels, the number and age categories require a special combination of groups of 40 and 50. Consult a zakat authority.")
                        }
                    }
                    else -> {
                        nisab = 40
                        rincian = when (n) {
                            in 0..39 -> tr("Belum mencapai nisab kambing/domba 40 ekor.", "Below the goat/sheep nisab of 40.")
                            in 40..120 -> tr("1 ekor kambing atau domba.", "1 goat or sheep.")
                            in 121..200 -> tr("2 ekor kambing atau domba.", "2 goats or sheep.")
                            in 201..399 -> tr("3 ekor kambing atau domba.", "3 goats or sheep.")
                            else -> "${n / 100} " + tr("ekor kambing atau domba (satu ekor setiap 100 ekor)", "goats or sheep (one for every 100 head)")
                        }
                    }
                }
                val memenuhiJumlah = n >= nisab
                status = when {
                    !memenuhiJumlah -> tr("Jumlah ternak belum mencapai nisab.", "The herd has not reached nisab.")
                    !haul -> tr("Nisab jumlah tercapai, tetapi haul satu tahun Hijriah belum ditandai terpenuhi.", "The count reaches nisab, but the one Hijri-year haul is not marked as completed.")
                    !digembala -> tr("Nisab dan haul mungkin terpenuhi, tetapi mayoritas pakan dibeli atau ternak dipelihara intensif. Perhitungan zakat ternak gembalaan ini tidak diterapkan; periksa ketentuan zakat perdagangan atau konsultasikan kepada amil.", "Nisab and haul may be met, but the animals are mostly stall-fed or intensively raised. This grazing-livestock calculation is not applied; check trade-zakat rules or consult a zakat authority.")
                    jenisHewan == 2 && n > 120 -> tr("Perlu konsultasi amil untuk unta di atas 120 ekor.", "Consult a zakat authority for more than 120 camels.")
                    else -> tr("Nisab, haul, dan syarat penggembalaan ditandai terpenuhi. Verifikasi umur serta kondisi hewan sebelum penyerahan.", "Nisab, haul, and grazing conditions are marked as met. Verify animal age and condition before payment.")
                }
                wajib = 0.0 // Livestock zakat is due in specified animals, not a fixed cash percentage.
                dasar = tr("Nisab acuan", "Reference nisab") + ": $nisab " + tr("ekor", "head") + "; " + tr("ketentuan umum ternak", "general livestock schedule")
                ringkasan = tr("Jumlah", "Count") + " $labelHewan: $n " + tr("ekor", "head") + "; " + tr("bentuk zakat", "zakat due") + ": $rincian"
                hasilTerakhir = buildString {
                    append(tr("Hasil kalkulasi zakat", "Zakat calculation result")); append("\n")
                    append(tr("Jenis", "Type")); append(": "); append(tr("Peternakan", "Livestock")); append("\n")
                    append(ringkasan); append("\n"); append(dasar); append("\n"); append(status)
                    append("\n\n"); append(tr("Zakat ternak umumnya ditunaikan dalam bentuk hewan sesuai umur dan ketentuan fikih, bukan otomatis dalam bentuk uang.", "Livestock zakat is generally paid in eligible animals according to age and jurisprudential rules, not automatically as cash."))
                    append("\n\n"); append(tr("Estimasi ini bukan fatwa. Ketentuan dapat berbeda menurut mazhab dan lembaga zakat. Ternak untuk perdagangan dapat dihitung sebagai zakat perdagangan.", "This estimate is not a religious ruling. Rules may differ by school and zakat authority. Livestock held for trade may be assessed as trade zakat."))
                }
                hasil.text = hasilTerakhir
                hasil.announceForAccessibility(hasilTerakhir)
                return
            }
        }

        val jumlah = if (jenis == Jenis.FITRAH && pilihanFitrah?.selectedItemPosition != 1)
            String.format(Locale.US, "%.2f kg", wajib) else rupiah(wajib)
        hasilTerakhir = buildString {
            append(tr("Hasil kalkulasi zakat", "Zakat calculation result"))
            append("\n")
            append(tr("Jenis", "Type")); append(": "); append(when (jenis) {
                Jenis.EMAS_PERAK -> tr("Emas dan perak", "Gold and silver")
                Jenis.TABUNGAN -> tr("Tabungan dan uang", "Savings and cash")
                Jenis.PERDAGANGAN -> tr("Perdagangan", "Trade")
                Jenis.PERTANIAN -> tr("Pertanian", "Agriculture")
                Jenis.FITRAH -> tr("Fitrah", "Al-Fitr")
                Jenis.PENGHASILAN -> tr("Penghasilan", "Income")
                Jenis.PETERNAKAN -> tr("Peternakan", "Livestock")
            })
            append("\n"); append(ringkasan)
            append("\n"); append(dasar)
            append("\n"); append(status)
            append("\n"); append(tr("Jumlah zakat yang dihitung", "Calculated zakat amount")); append(": "); append(jumlah)
            if (jenis == Jenis.FITRAH && pilihanFitrah?.selectedItemPosition == 1) {
                append("\n"); append(tr("Pembayaran uang", "Cash payment")); append(": "); append(rupiah(wajib))
            }
            append("\n\n"); append(tr(
                "Perhitungan ini merupakan estimasi berdasarkan data dan acuan yang dimasukkan, bukan fatwa. Pastikan nisab, harga, haul, dan ketentuan setempat.",
                "This is an estimate based on the entered data and selected references, not a religious ruling. Verify nisab, prices, haul, and local rules."
            ))
        }
        hasil.text = hasilTerakhir
        hasil.announceForAccessibility(hasilTerakhir)
    }

    private fun simpanHasil() {
        if (hasilTerakhir.isBlank()) {
            hasil.announceForAccessibility(tr("Hitung zakat terlebih dahulu.", "Calculate zakat first."))
            return
        }
        val prefsRiwayat = getSharedPreferences("riwayat_kalkulator_zakat", MODE_PRIVATE)
        val lama = try { JSONArray(prefsRiwayat.getString("data", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val baru = JSONArray().put(hasilTerakhir)
        for (i in 0 until minOf(lama.length(), 19)) baru.put(lama.optString(i))
        prefsRiwayat.edit().putString("data", baru.toString()).apply()
        hasil.announceForAccessibility(tr("Hasil zakat berhasil disimpan.", "Zakat result saved."))
    }

    private fun tampilkanRiwayat() {
        val arr = try {
            JSONArray(getSharedPreferences("riwayat_kalkulator_zakat", MODE_PRIVATE).getString("data", "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) {
            AlertDialog.Builder(this)
                .setTitle(tr("Riwayat zakat", "Zakat history"))
                .setMessage(tr("Belum ada hasil perhitungan yang disimpan.", "No saved calculations yet."))
                .setPositiveButton(tr("Mengerti", "OK"), null).show()
            return
        }
        val daftar = Array(arr.length()) { i -> arr.optString(i) }
        AlertDialog.Builder(this)
            .setTitle(tr("Riwayat perhitungan zakat", "Zakat calculation history"))
            .setItems(daftar.map { it as CharSequence }.toTypedArray()) { _, which ->
                AlertDialog.Builder(this).setTitle(tr("Detail hasil", "Result details"))
                    .setMessage(daftar[which])
                    .setPositiveButton(tr("Tutup", "Close"), null).show()
            }
            .setNegativeButton(tr("Tutup", "Close"), null)
            .setNeutralButton(tr("Hapus riwayat", "Clear history")) { _, _ ->
                getSharedPreferences("riwayat_kalkulator_zakat", MODE_PRIVATE).edit().remove("data").apply()
            }.show()
    }
}
