package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Satu alarm buatan pengguna pada fitur Jam. */
data class ItemAlarm(
    val id: Int,
    var jam: Int = 7,
    var menit: Int = 0,
    /** Bit 0 = Minggu ... bit 6 = Sabtu. 0 berarti berbunyi sekali saja. */
    var hari: Int = 0,
    var aktif: Boolean = true,
    var label: String = "",
    /** 0 = nada alarm sistem, 1 = ucapkan waktu dan label, 2 = nada singkat lalu ucapan bergantian. */
    var mode: Int = 2,
    /** Lama tunda dalam menit; 0 = tanpa tombol tunda. */
    var tundaMenit: Int = 10,
    var getar: Boolean = true
)

/**
 * FIX75: alarm buatan pengguna di fitur Jam.
 *
 * Disimpan sebagai JSON di SharedPreferences "alarm_jam" dan dijadwalkan dengan AlarmManager.setAlarmClock
 * (tepat waktu, tembus mode hemat daya Doze, dan tidak memerlukan izin alarm tepat waktu). Setelah boot, pembaruan
 * aplikasi, atau perubahan waktu/zona waktu, [jadwalkanSemua] dipanggil ulang oleh BootReceiver.
 */
object AlarmJam {
    private const val PREF = "alarm_jam"
    private const val K_DAFTAR = "daftar"
    private const val K_ID_BERIKUT = "id_berikut"
    private const val K_TUNDA = "tunda_"
    const val BATAS_ALARM = 20
    const val AKSI_BUNYI = "com.novan.jambicarapro.ALARM_JAM_BUNYI"
    private const val KODE_DASAR = 9100
    private const val KODE_TUNDA = 9500
    private const val KODE_TAMPIL = 9099

    private fun sp(context: Context) = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun muat(context: Context): MutableList<ItemAlarm> {
        val hasil = ArrayList<ItemAlarm>()
        try {
            val arr = JSONArray(sp(context).getString(K_DAFTAR, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                hasil.add(
                    ItemAlarm(
                        id = o.optInt("id", i + 1),
                        jam = o.optInt("jam", 7).coerceIn(0, 23),
                        menit = o.optInt("menit", 0).coerceIn(0, 59),
                        hari = o.optInt("hari", 0) and 127,
                        aktif = o.optBoolean("aktif", true),
                        label = o.optString("label", ""),
                        mode = o.optInt("mode", 2).coerceIn(0, 2),
                        tundaMenit = o.optInt("tunda", 10).coerceIn(0, 60),
                        getar = o.optBoolean("getar", true)
                    )
                )
            }
        } catch (_: Exception) { }
        return hasil.sortedWith(compareBy<ItemAlarm>({ it.jam }, { it.menit }, { it.id })).toMutableList()
    }

    private fun simpan(context: Context, daftar: List<ItemAlarm>) {
        val arr = JSONArray()
        for (a in daftar) {
            arr.put(JSONObject().put("id", a.id).put("jam", a.jam).put("menit", a.menit).put("hari", a.hari)
                .put("aktif", a.aktif).put("label", a.label).put("mode", a.mode).put("tunda", a.tundaMenit).put("getar", a.getar))
        }
        sp(context).edit().putString(K_DAFTAR, arr.toString()).commit()
    }

    fun cari(context: Context, id: Int): ItemAlarm? = muat(context).firstOrNull { it.id == id }

    /** Alarm baru (belum disimpan). Mengembalikan null bila batas jumlah alarm tercapai. */
    fun baru(context: Context): ItemAlarm? {
        val daftar = muat(context)
        if (daftar.size >= BATAS_ALARM) return null
        val p = sp(context)
        var id = p.getInt(K_ID_BERIKUT, 1)
        while (daftar.any { it.id == id }) id++
        p.edit().putInt(K_ID_BERIKUT, id + 1).commit()
        return ItemAlarm(id = id)
    }

    /** Simpan (tambah atau ganti) satu alarm lalu jadwalkan ulang semuanya. */
    fun perbarui(context: Context, item: ItemAlarm) {
        val daftar = muat(context)
        val idx = daftar.indexOfFirst { it.id == item.id }
        if (idx >= 0) daftar[idx] = item else daftar.add(item)
        simpan(context, daftar)
        hapusTunda(context, item.id)
        jadwalkanSemua(context)
    }

    fun hapus(context: Context, id: Int) {
        val daftar = muat(context).filter { it.id != id }
        simpan(context, daftar)
        batalkanPending(context, id)
        hapusTunda(context, id)
        jadwalkanSemua(context)
    }

    /** Waktu (ms) kemunculan berikutnya setelah [setelah], atau null bila alarm tidak akan berbunyi lagi. */
    fun berikut(item: ItemAlarm, setelah: Long): Long? {
        for (d in 0..7) {
            val c = Calendar.getInstance()
            c.timeInMillis = setelah
            c.set(Calendar.HOUR_OF_DAY, item.jam)
            c.set(Calendar.MINUTE, item.menit)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.DAY_OF_YEAR, d)
            if (c.timeInMillis <= setelah) continue
            val hari = c.get(Calendar.DAY_OF_WEEK) - 1
            if (item.hari == 0 || (item.hari and (1 shl hari)) != 0) return c.timeInMillis
        }
        return null
    }

    /** Alarm aktif yang akan berbunyi paling dekat (termasuk alarm yang sedang ditunda). */
    fun berikutan(context: Context): Pair<ItemAlarm, Long>? {
        val sekarang = System.currentTimeMillis()
        var terbaik: Pair<ItemAlarm, Long>? = null
        for (a in muat(context)) {
            val t = if (a.aktif) berikut(a, sekarang) else null
            val tunda = waktuTunda(context, a.id).takeIf { it > sekarang }
            val kandidat = listOfNotNull(t, tunda).minOrNull() ?: continue
            if (terbaik == null || kandidat < terbaik.second) terbaik = Pair(a, kandidat)
        }
        return terbaik
    }

    private fun flagPending() = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    private fun pendingBunyi(context: Context, id: Int, tunda: Boolean): PendingIntent {
        val i = Intent(context, AlarmJamReceiver::class.java).setAction(AKSI_BUNYI)
            .putExtra("alarm_id", id).putExtra("tunda", tunda)
        return PendingIntent.getBroadcast(context, (if (tunda) KODE_TUNDA else KODE_DASAR) + id, i, flagPending())
    }

    private fun batalkanPending(context: Context, id: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        try { am.cancel(pendingBunyi(context, id, false)) } catch (_: Exception) { }
        try { am.cancel(pendingBunyi(context, id, true)) } catch (_: Exception) { }
    }

    private fun pasang(context: Context, am: AlarmManager, id: Int, tunda: Boolean, waktu: Long) {
        val tampil = PendingIntent.getActivity(
            context, KODE_TAMPIL,
            Intent(context, JamActivity::class.java).putExtra("kelompok", "alarm"),
            flagPending()
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(waktu, tampil), pendingBunyi(context, id, tunda))
        } catch (_: Exception) {
            try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, waktu, pendingBunyi(context, id, tunda)) } catch (_: Exception) { }
        }
    }

    /** Pasang ulang semua alarm aktif dan alarm tunda yang masih di masa depan; batalkan yang tidak perlu. */
    fun jadwalkanSemua(context: Context) {
        val app = context.applicationContext
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val sekarang = System.currentTimeMillis()
        for (a in muat(app)) {
            val t = if (a.aktif) berikut(a, sekarang) else null
            if (t != null) pasang(app, am, a.id, false, t) else try { am.cancel(pendingBunyi(app, a.id, false)) } catch (_: Exception) { }
            val tunda = waktuTunda(app, a.id)
            if (tunda > sekarang) pasang(app, am, a.id, true, tunda) else {
                try { am.cancel(pendingBunyi(app, a.id, true)) } catch (_: Exception) { }
                if (tunda != 0L) hapusTunda(app, a.id)
            }
        }
    }

    // ---------- Tunda ----------
    fun waktuTunda(context: Context, id: Int): Long = sp(context).getLong(K_TUNDA + id, 0L)

    fun hapusTunda(context: Context, id: Int) {
        sp(context).edit().remove(K_TUNDA + id).commit()
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        try { am.cancel(pendingBunyi(context, id, true)) } catch (_: Exception) { }
    }

    fun jadwalkanTunda(context: Context, id: Int, menit: Int): Long {
        val app = context.applicationContext
        val waktu = System.currentTimeMillis() + menit.coerceAtLeast(1) * 60_000L
        sp(app).edit().putLong(K_TUNDA + id, waktu).commit()
        val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        if (am != null) pasang(app, am, id, true, waktu)
        return waktu
    }

    // ---------- Teks ----------
    private val HARI_ID = arrayOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")
    private val HARI_EN = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    fun ringkasHari(context: Context, mask: Int): String {
        val en = BahasaAplikasi.tampilan(context) == 1
        val m = mask and 127
        if (m == 0) return if (en) "Once" else "Sekali"
        if (m == 127) return if (en) "Every day" else "Setiap hari"
        val nama = if (en) HARI_EN else HARI_ID
        return listOf(1, 2, 3, 4, 5, 6, 0).filter { (m and (1 shl it)) != 0 }.joinToString(", ") { nama[it] }
    }

    fun ringkas(context: Context, a: ItemAlarm): String {
        val en = BahasaAplikasi.tampilan(context) == 1
        val sb = StringBuilder()
        sb.append(if (en) "Alarm " else "Alarm ").append(JamWaktu.format(a.jam * 60 + a.menit))
        sb.append(", ").append(ringkasHari(context, a.hari))
        if (a.label.isNotBlank()) sb.append(", ").append(a.label.trim())
        sb.append(", ").append(if (a.aktif) (if (en) "on" else "aktif") else (if (en) "off" else "mati"))
        return sb.toString()
    }
}
