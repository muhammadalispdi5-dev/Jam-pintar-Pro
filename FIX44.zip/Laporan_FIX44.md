# Laporan FIX44 — Penataan Hafalan, Audio, dan Putar per Halaman

Versi aplikasi dipertahankan: **1.0.69 (versionCode 69)**.

## Perubahan

1. **Pengaturan utama Khatam Al-Qur'an** kini memisahkan Pengaturan Hafalan dan Pengaturan Pemutaran Audio, selain pengingat, target, aksesibilitas, riwayat, dan statistik.
2. **Pengaturan Hafalan** memuat mode hafalan, koreksi otomatis dengan pengenalan suara, latihan tanpa mikrofon, jumlah pengulangan, dan jeda antar ayat.
3. **Pengaturan Pemutaran Audio** memuat pilihan qari, Arab/terjemahan, rentang pemutaran ayat/surah/juz/halaman, stereo/mono, equalizer, dan kecepatan.
4. **Putar per halaman mushaf** ditambahkan. Pengguna dapat memasukkan halaman 1–604 atau langsung memakai tombol Putar satu halaman mushaf. Aplikasi mengambil rentang ayat dari metadata halaman Al Quran Cloud, lalu memutar ayat satu per satu secara berurutan sampai halaman selesai. Kontrol trek sebelumnya/berikutnya tetap mengikuti batas halaman.
5. **Perbaikan tampilan koreksi otomatis**: teks ayat mushaf dan teks yang dikenali ditampilkan sebagai teks Arab, terpisah dari ringkasan hasil. Teks yang berisi HTML entity atau literal Unicode escape dibersihkan sebelum ditampilkan. Jika layanan pengenalan suara tidak mengembalikan teks Arab, aplikasi menyatakan bahwa pemeriksaan tidak dapat dilakukan dan tidak memberikan hasil palsu.
6. Rincian kesalahan tidak lagi menampilkan token/kata normalisasi internal sebagai teks teknis. TalkBack menerima ringkasan yang lebih mudah dipahami.

## Batasan penting

- Pemeriksaan tetap bergantung pada layanan SpeechRecognizer di perangkat dan bahasa Arab yang tersedia. Hasilnya merupakan perkiraan pencocokan urutan kata, bukan pengesahan bacaan.
- Pengenalan suara umum tidak dapat menilai tajwid, makhraj, sifat huruf, panjang-pendek, ghunnah, atau waqaf secara andal.
- Putar halaman memerlukan metadata `page` pada data Al-Qur'an yang tersimpan dan qari yang menyediakan audio per ayat. Qari MP3Quran yang hanya menyediakan audio surah penuh tidak dapat dipakai untuk pemutaran halaman.
- Audio per halaman diputar sebagai rangkaian berkas ayat; ini bukan satu berkas audio halaman tunggal.

## Pemeriksaan

- Pemeriksaan statis proyek: lulus.
- AndroidManifest.xml: XML valid.
- Pemeriksaan parser Kotlin tanpa classpath Android: tidak ditemukan indikator kesalahan sintaks (`Expecting`, `Unexpected tokens`, atau `Unterminated`).
- Kompilasi Gradle penuh dan uji langsung di perangkat belum dapat dilakukan pada lingkungan ini karena Android SDK/classpath build tidak tersedia. Mohon lakukan build dan uji TalkBack serta audio pada perangkat sebelum rilis.
