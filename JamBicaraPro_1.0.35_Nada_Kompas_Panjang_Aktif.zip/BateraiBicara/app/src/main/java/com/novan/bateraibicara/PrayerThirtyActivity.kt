package com.novan.bateraibicara

import android.app.DatePickerDialog
import android.os.Bundle
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Pemilih tanggal dan daftar jadwal 30 hari ke depan. */
class PrayerThirtyActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private val fmt = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID"))
    private var selectedDate = LocalDate.now()
    private lateinit var selectedInfo: android.widget.TextView

    override fun bangun() {
        bagian("Pilih hari dan jadwal 30 hari")
        if (!pp.locationSet) { info("Lokasi belum diatur. Buka Jadwal Sholat, lalu perbarui lokasi (GPS) atau atur lokasi manual."); return }
        info("Lokasi: ${pp.place}\nMetode: ${PrayerCalc.methodNames[pp.method]}")
        selectedInfo = info("")
        tombol("Pilih tanggal") {
            DatePickerDialog(this, { _, year, month, day ->
                selectedDate = LocalDate.of(year, month + 1, day)
                tampilkanTanggalTerpilih()
            }, selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth).show()
        }
        tombol("Bacakan jadwal tanggal terpilih") { tesSuara("jam", kalimat(selectedDate)) }
        tampilkanTanggalTerpilih()
        bagian("Jadwal 30 hari ke depan")
        for (i in 0 until 30) {
            val date = LocalDate.now().plusDays(i.toLong())
            val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
            bagian(date.format(fmt), 17f)
            info("Subuh ${PrayerCalc.format(t.fajr, pp.use24)} · Terbit ${PrayerCalc.format(t.sunrise, pp.use24)} · Dzuhur ${PrayerCalc.format(t.dhuhr, pp.use24)}\nAshar ${PrayerCalc.format(t.asr, pp.use24)} · Maghrib ${PrayerCalc.format(t.maghrib, pp.use24)} · Isya ${PrayerCalc.format(t.isha, pp.use24)}")
        }
    }

    private fun tampilkanTanggalTerpilih() {
        selectedInfo.text = kalimat(selectedDate)
    }
    private fun kalimat(date: LocalDate): String {
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        return "${date.format(fmt)}\nImsak ${PrayerCalc.format(t.imsak, pp.use24)} · Subuh ${PrayerCalc.format(t.fajr, pp.use24)} · Terbit ${PrayerCalc.format(t.sunrise, pp.use24)} · Dhuha ${PrayerCalc.format(t.dhuha, pp.use24)}\nDzuhur ${PrayerCalc.format(t.dhuhr, pp.use24)} · Ashar ${PrayerCalc.format(t.asr, pp.use24)} · Maghrib ${PrayerCalc.format(t.maghrib, pp.use24)} · Isya ${PrayerCalc.format(t.isha, pp.use24)}"
    }
}
