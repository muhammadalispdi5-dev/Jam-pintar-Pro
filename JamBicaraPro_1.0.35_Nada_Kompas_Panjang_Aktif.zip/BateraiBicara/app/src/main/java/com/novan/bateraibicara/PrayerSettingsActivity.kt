package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast

/** Semua pilihan jadwal, pengingat, metode, penyesuaian menit, dan sumber suara azan. */
class PrayerSettingsActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private val prayerNames = listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
    private val requestGlobal = 50
    private fun requestPrayer(key: String) = 51 + prayerNames.indexOfFirst { it.second == key }

    override fun onResume() { super.onResume(); PrayerAlarm.scheduleAll(this) }

    override fun bangun() {
        bagian("Pengaturan Jadwal Sholat")
        info("Semua fitur jadwal sholat dan pengingat dinonaktifkan pada pengaturan awal. Aktifkan hanya yang Anda perlukan. Penghitungan waktu tetap dapat dilihat pada halaman Jadwal Sholat tanpa mengaktifkan pengingat.")
        saklar("Aktifkan pengingat waktu sholat", pp.enabled) { pp.enabled = it; PrayerAlarm.scheduleAll(this); if (it) mintaIzinNotifikasi() }
        bagian("Lokasi dan perhitungan")
        info(if (pp.locationSet) "Lokasi: ${pp.place} (${"%.5f".format(pp.lat)}, ${"%.5f".format(pp.lon)})" else "Lokasi belum diatur. Atur GPS atau koordinat manual pada halaman Jadwal Sholat.")
        tombol("Buka halaman lokasi") { startActivity(Intent(this, PrayerActivity::class.java)) }
        pilihan("Metode perhitungan", PrayerCalc.methodNames, pp.method) { pp.method = it; PrayerAlarm.scheduleAll(this) }
        pilihan("Perhitungan Ashar", listOf("Mazhab Syafi'i, Maliki, Hanbali (bayangan 1x)", "Mazhab Hanafi (bayangan 2x)"), pp.asrFactor - 1) { pp.asrFactor = it + 1; PrayerAlarm.scheduleAll(this) }
        pilihan("Format waktu", listOf("24 jam", "12 jam"), if (pp.use24) 0 else 1) { pp.use24 = it == 0 }

        bagian("Pengingat setiap waktu sholat")
        for ((name, key) in prayerNames) {
            saklar("Ingatkan waktu $name", pp.reminder(key)) { pp.setReminder(key, it); PrayerAlarm.scheduleAll(this) }
        }
        saklar("Matikan pengingat Dzuhur pada hari Jumat", pp.fridayDhuhrOff) { pp.fridayDhuhrOff = it; PrayerAlarm.scheduleAll(this) }
        saklar("Notifikasi saja, tanpa suara azan", pp.notifyOnly) { pp.notifyOnly = it }
        tombol("Izinkan alarm tepat waktu") { bukaIzinAlarm() }
        tombol("Buka pengaturan notifikasi aplikasi") { bukaNotifikasi() }

        bagian("Tambah atau kurangi menit")
        info("Sesuaikan setiap waktu bila jadwal setempat berbeda. Nilai boleh negatif atau positif dari −30 sampai +30 menit.")
        val adjust = listOf("Imsak" to "imsak", "Subuh" to "subuh", "Terbit" to "terbit", "Dhuha" to "dhuha", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        for ((label, key) in adjust) {
            val field = isian("Penyesuaian $label (menit)", pp.adjustment(key).toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED) { raw ->
                raw.toIntOrNull()?.let { pp.setAdjustment(key, it) }
            }
            field.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) PrayerAlarm.scheduleAll(this) }
        }

        bagian("Sumber suara azan")
        info("Sumber bawaan menggunakan rekaman azan umum untuk Dzuhur, Ashar, Maghrib, dan Isya serta rekaman azan Subuh khusus. Anda juga dapat memilih berkas audio sendiri untuk semua waktu atau masing-masing waktu sholat.")
        tombol("Pilih berkas azan cadangan untuk semua waktu") { pilihBerkas(requestGlobal) }
        info("Berkas semua waktu: ${if (pp.globalSound.isBlank()) "azan bawaan" else pp.globalSound}")
        tombol("Hapus berkas azan semua waktu") { pp.globalSound = ""; toast("Berkas semua waktu dihapus"); recreate() }
        tombol("Hapus semua berkas azan pilihan") {
            pp.globalSound = ""
            for ((_, key) in prayerNames) pp.setSound(key, "")
            toast("Semua berkas azan pilihan dihapus"); recreate()
        }
        pilihan("Jenis volume azan", listOf("Alarm", "Notifikasi", "Media"), pp.volumeMode) { pp.volumeMode = it }
        for ((name, key) in prayerNames) {
            bagian("Azan $name", 17f)
            info("Sumber suara: ${if (pp.sound(key).isBlank()) if (pp.globalSound.isBlank()) if (key == "subuh") "azan Subuh bawaan" else "azan umum bawaan" else "berkas semua waktu" else pp.sound(key)}")
            tombol("Pilih berkas azan $name") { pilihBerkas(requestPrayer(key)) }
            tombol("Coba suara azan $name") { tesAzan(key) }
            tombol("Kembali ke sumber suara umum/bawaan untuk $name") { pp.setSound(key, ""); recreate() }
        }
        tombol("Coba suara azan semua waktu") { tesAzan("subuh") }

        bagian("Arah kiblat")
        saklar("Ucapan arah otomatis setiap 1,5 detik", pp.voiceQibla) { pp.voiceQibla = it }
        saklar("Getar panjang saat menghadap kiblat (selisih kurang dari 5 derajat)", pp.qiblaHaptic) { pp.qiblaHaptic = it }
        tombol("Buka arah kiblat") { startActivity(Intent(this, QiblaActivity::class.java)) }
    }

    private fun pilihBerkas(request: Int) {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i, request)
        } catch (e: Exception) { toast("Pemilih berkas tidak dapat dibuka pada perangkat ini.") }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        when (requestCode) {
            requestGlobal -> pp.globalSound = uri.toString()
            else -> {
                val idx = requestCode - 51
                if (idx in prayerNames.indices) pp.setSound(prayerNames[idx].second, uri.toString())
            }
        }
        toast("Sumber suara disimpan")
        recreate()
    }

    private fun tesAzan(key: String) {
        val i = Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true)
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Tidak dapat memutar suara. Periksa izin dan berkas audio.") }
    }
    private fun mintaIzinNotifikasi() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 405)
    }
    private fun bukaIzinAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        } else toast("Pada versi Android ini, izin alarm tepat waktu dikelola otomatis.")
    }
    private fun bukaNotifikasi() {
        try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
    }
}
