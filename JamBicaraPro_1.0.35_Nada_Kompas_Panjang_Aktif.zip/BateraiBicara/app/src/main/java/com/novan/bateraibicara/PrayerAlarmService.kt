package com.novan.bateraibicara

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Pemutar pengingat azan yang berjalan dari alarm meski layar mati. */
class PrayerAlarmService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "com.novan.jambicarapro.STOP_PRAYER_SOUND") {
            stopPlayback()
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val key = intent?.getStringExtra("prayer_key") ?: "subuh"
        val test = intent?.getBooleanExtra("test", false) ?: false
        val pp = PrayerPrefs(this)
        if (!test && (!pp.enabled || !pp.reminder(key))) { stopSelf(startId); return START_NOT_STICKY }
        createChannel()
        val title = if (test) "Tes suara azan ${PrayerAlarm.label(key)}" else "Saatnya menunaikan sholat ${PrayerAlarm.label(key)}"
        val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND")
        val stopPi = PendingIntent.getService(this, 810, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = n.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(if (pp.notifyOnly && !test) "Pengingat waktu sholat" else "Pengingat waktu sholat dan suara azan")
            .setContentIntent(open).setAutoCancel(false).setOngoing(true)
        builder.addAction(android.R.drawable.ic_media_pause, "Hentikan suara azan", stopPi)
        val notification = builder.build()
        startForeground(809, notification)
        if (pp.notifyOnly && !test) { handler.postDelayed({ stopSelf(startId) }, 2500); return START_NOT_STICKY }
        playSound(pp.sound(key).ifBlank { pp.globalSound }, pp.volumeMode, startId, key)
        return START_NOT_STICKY
    }

    private fun playSound(uriString: String, volumeMode: Int, startId: Int, key: String) {
        stopPlayback()
        try {
            val usage = when (volumeMode) { 1 -> AudioAttributes.USAGE_NOTIFICATION; 2 -> AudioAttributes.USAGE_MEDIA; else -> AudioAttributes.USAGE_ALARM }
            val attrs = AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            if (uriString.isNotBlank()) {
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    setDataSource(this@PrayerAlarmService, Uri.parse(uriString))
                    setOnCompletionListener { stopSelf(startId) }
                    setOnErrorListener { _, _, _ -> stopSelf(startId); true }
                    prepare(); start()
                }
                handler.postDelayed({ stopSelf(startId) }, 180_000L)
            } else {
                // Audio azan bawaan dibawa dari APK referensi: azan Subuh dan azan umum.
                val resource = if (key == "subuh") R.raw.azan_subuh else R.raw.azan_biasa
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    val afd = this@PrayerAlarmService.resources.openRawResourceFd(resource)
                    try { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                    setOnCompletionListener { stopSelf(startId) }
                    setOnErrorListener { _, _, _ -> stopSelf(startId); true }
                    prepare(); start()
                }
                handler.postDelayed({ stopSelf(startId) }, 240_000L)
            }
        } catch (_: Exception) {
            stopSelf(startId)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel("jadwal_sholat") == null) {
                val channel = NotificationChannel("jadwal_sholat", "Pengingat Jadwal Sholat", NotificationManager.IMPORTANCE_HIGH)
                channel.setSound(null, null)
                manager.createNotificationChannel(channel)
            }
        }
    }
    private fun stopPlayback() {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopPlayback()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
}
