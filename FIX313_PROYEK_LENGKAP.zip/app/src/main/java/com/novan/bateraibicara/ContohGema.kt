package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale

/**
 * FIX310: "Putar contoh gema" untuk semua pengaturan gema. Contoh memakai suara TTS saja (bukan azan, ayat, atau berkas lain),
 * dirender ke berkas, diberi efek lewat [GemaDsp], lalu diputar di dalam aplikasi. Seluruh langkah dibungkus penangkap kesalahan
 * dan berjalan lewat context aplikasi sehingga tidak menutup layar pengaturan atau membuat aplikasi keluar.
 */
object ContohGema {
    private val utama = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var pemutar: MediaPlayer? = null
    private var berkas: File? = null
    private var keringBerkas: File? = null
    private var generasi = 0
    @Volatile private var inggris = false
    private fun tr(id: String, en: String): String = if (inggris) en else id

    fun berhenti() {
        generasi++
        try { pemutar?.setOnCompletionListener(null); pemutar?.stop() } catch (_: Throwable) { }
        try { pemutar?.release() } catch (_: Throwable) { }
        pemutar = null
        try { tts?.stop() } catch (_: Throwable) { }
        try { tts?.shutdown() } catch (_: Throwable) { }
        tts = null
        try { berkas?.delete() } catch (_: Throwable) { }
        berkas = null
        try { keringBerkas?.delete() } catch (_: Throwable) { }
        keringBerkas = null
    }

    /** [kunci] salah satu GemaAudio.daftarKunci; [kekuatan] 0..100. [lapor] menerima pesan singkat (boleh null). */
    fun putar(context: Context, kunci: String, kekuatan: Int, lapor: ((String) -> Unit)? = null, mesinTts: String? = null) {
        val app = context.applicationContext
        val en = try { BahasaAplikasi.tampilan(app) == 1 } catch (_: Throwable) { false }
        inggris = en
        fun kabar(teks: String) { try { utama.post { lapor?.invoke(teks) } } catch (_: Throwable) { } }
        try {
            berhenti()
            val gen = generasi
            val f = File(app.cacheDir, "contoh_gema_" + System.nanoTime() + ".wav")
            berkas = f
            var siap = false
            // Pakai mesin suara yang sama dengan pengumuman (pilihan pengguna) agar contoh terdengar sama seperti aslinya.
            val namaMesin = mesinTts ?: try { Prefs(app).Suara("jam").engine } catch (_: Throwable) { "" }
            val awalTts = TextToSpeech.OnInitListener { status ->
                utama.post {
                    try {
                        if (gen != generasi) return@post
                        val t = tts
                        if (status != TextToSpeech.SUCCESS || t == null) { kabar(tr("Mesin suara belum siap, coba lagi.", "The speech engine is not ready, try again.")); berhenti(); return@post }
                        if (siap) return@post
                        siap = true
                        val bahasa = if (en) Locale.ENGLISH else Locale.forLanguageTag("id-ID")
                        val r = t.setLanguage(bahasa)
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.getDefault())
                        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) { }
                            override fun onDone(utteranceId: String?) {
                                Thread {
                                    try {
                                        if (gen != generasi) return@Thread
                                        // Tunggu berkas selesai ditulis mesin suara (ukuran stabil) sebelum diberi efek.
                                        var terakhir = -1L; var tunggu = 0
                                        while (tunggu < 15) { val u = if (f.exists()) f.length() else 0L; if (u > 200L && u == terakhir) break; terakhir = u; tunggu++; Thread.sleep(100) }
                                        if (!f.exists() || f.length() < 200L) { kabar(tr("Contoh suara gagal dibuat.", "The sample could not be created.")); return@Thread }
                                        val sebelum = f.length()
                                        val kering = File(app.cacheDir, "contoh_kering_" + System.nanoTime() + ".wav")
                                        try { f.copyTo(kering, true); keringBerkas = kering } catch (_: Throwable) { keringBerkas = null }
                                        val ok = GemaDsp.proses(f, kunci, kekuatan)
                                        // Bukti bahwa efek benar-benar diterapkan: berkas bertambah panjang oleh ekor gema.
                                        val berubah = f.length() > sebelum
                                        utama.post { if (gen == generasi) mainkan(app, f, gen, ok && (berubah || kunci == "normal" || kekuatan <= 0), kunci, kekuatan, en, lapor) }
                                    } catch (_: Throwable) { kabar(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) }
                                }.start()
                            }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) { kabar(tr("Contoh suara gagal dibuat.", "The sample could not be created.")) }
                        })
                        // Sebut nama efek yang dipilih lebih dulu agar pendengar tahu persis apa yang sedang dicoba.
                        val namaEfek = try { if (kunci == "normal") tr("Normal, tanpa gema", "Normal, no echo") else GemaAudio(app).label(kunci) } catch (_: Throwable) { "" }
                        val teks = (if (namaEfek.isNotEmpty()) namaEfek + ". " else "") +
                            tr("Ini adalah contoh suara gema yang Anda pilih.", "This is a sample of the echo sound you chose.") + " " + tr("Halo, halo, halo.", "Hello, hello, hello.")
                        val h = t.synthesizeToFile(teks, android.os.Bundle(), f, "contoh_gema")
                        if (h != TextToSpeech.SUCCESS) kabar(tr("Contoh suara gagal dibuat.", "The sample could not be created."))
                    } catch (_: Throwable) { kabar(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) }
                }
            }
            tts = try { if (namaMesin.isEmpty()) TextToSpeech(app, awalTts) else TextToSpeech(app, awalTts, namaMesin) } catch (_: Throwable) { TextToSpeech(app, awalTts) }
        } catch (_: Throwable) { kabar(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) }
    }

    private fun mainkan(app: Context, f: File, gen: Int, dspOk: Boolean, kunci: String, kekuatan0: Int, en: Boolean, lapor: ((String) -> Unit)?) {
        try {
            if (kunci != "normal" && kekuatan0 <= 0) lapor?.invoke(tr("Kekuatan gema 0 persen, jadi contoh terdengar tanpa gema. Naikkan kekuatannya.", "Echo strength is 0 percent, so the sample plays without echo. Raise the strength."))
            if (!dspOk && kunci != "normal" && kekuatan0 > 0) lapor?.invoke(tr("Gema tidak dapat diterapkan; diputar tanpa gema.", "The echo could not be applied; playing without echo."))
            val kering = keringBerkas
            val bandingkan = kering != null && kering.exists() && dspOk && kunci != "normal" && kekuatan0 > 0
            if (bandingkan) {
                lapor?.invoke(tr("Pertama tanpa gema, lalu dengan gema pilihan Anda.", "First without echo, then with the echo you chose."))
                putarBerkas(kering!!, gen, false) { if (gen == generasi) putarBerkas(f, gen, true, null) }
            } else putarBerkas(f, gen, true, null)
        } catch (_: Throwable) {
            try { lapor?.invoke(tr("Contoh gema gagal diputar.", "The echo sample could not be played.")) } catch (_: Throwable) { }
            berhenti()
        }
    }

    private fun putarBerkas(f: File, gen: Int, akhir: Boolean, lanjut: (() -> Unit)?) {
        try {
            try { pemutar?.setOnCompletionListener(null); pemutar?.release() } catch (_: Throwable) { }
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(f.path)
            mp.prepare()
            mp.setOnCompletionListener { if (gen == generasi) { if (akhir || lanjut == null) { if (akhir) berhenti() } else lanjut() } }
            mp.setOnErrorListener { _, _, _ -> if (gen == generasi) berhenti(); true }
            pemutar = mp
            mp.start()
        } catch (_: Throwable) { berhenti() }
    }
}
