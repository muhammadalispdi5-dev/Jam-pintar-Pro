package com.novan.bateraibicara

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Menjadwalkan ulang pengingat setelah akses alarm tepat waktu diberikan oleh Android. */
class ExactAlarmPermissionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED) return
        if (Build.VERSION.SDK_INT >= 31) {
            val alarmManager = context.getSystemService(AlarmManager::class.java) ?: return
            if (!alarmManager.canScheduleExactAlarms()) return
        }
        PrayerAlarm.scheduleAll(context.applicationContext)
    }
}
