package com.novan.bateraibicara

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/** Pemutar pengingat azan yang berjalan dari alarm meski layar mati. */
class PrayerAlarmService : Service(), SensorEventListener {
    private var player: MediaPlayer? = null
    private var isTestPlayback = false
    private var reminderTts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sensorManager: SensorManager? = null
    private var faceDownSensor: Sensor? = null
    private var faceDownSince = 0L
    private var lastFaceDownStop = 0L
    private var faceDownWakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action.orEmpty()
        if (action == "com.novan.jambicarapro.PAUSE_TEST_PLAYBACK" || action == "com.novan.jambicarapro.RESUME_TEST_PLAYBACK" || action == "com.novan.jambicarapro.STOP_TEST_PLAYBACK" || action == "com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK") {
            val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
            if (!state.getBoolean("test_playback_active", false)) { stopSelf(startId); return START_NOT_STICKY }
            when (action) {
                "com.novan.jambicarapro.PAUSE_TEST_PLAYBACK" -> { try { player?.pause(); state.edit().putBoolean("test_playback_paused", true).apply() } catch (_: Exception) { } }
                "com.novan.jambicarapro.RESUME_TEST_PLAYBACK" -> { try { player?.start(); state.edit().putBoolean("test_playback_paused", false).apply() } catch (_: Exception) { } }
                "com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK" -> {
                    try {
                        if (state.getBoolean("test_playback_paused", false)) { player?.start(); state.edit().putBoolean("test_playback_paused", false).apply() }
                        else { player?.pause(); state.edit().putBoolean("test_playback_paused", true).apply() }
                    } catch (_: Exception) { }
                }
                else -> { state.edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply(); stopPlayback(); if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true); stopSelf(startId); return START_NOT_STICKY }
            }
            updateTestNotification(state.getBoolean("test_playback_paused", false))
            return START_NOT_STICKY
        }
        if (action == "com.novan.jambicarapro.STOP_PRAYER_SOUND") {
            stopPlayback()
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (action == "com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK") {
            try { if (player?.isPlaying == true) player?.pause() else player?.start() } catch (_: Exception) { }
            return START_NOT_STICKY
        }
        val key = intent?.getStringExtra("prayer_key") ?: "subuh"
        val test = intent?.getBooleanExtra("test", false) ?: false
        val pp = PrayerPrefs(this)
        isTestPlayback = test
        val advanceReminder = intent?.getBooleanExtra("advance_reminder", false) ?: false
        if (advanceReminder) {
            if (!test && (!pp.enabled || !pp.advanceReminder(key))) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val lead = pp.advanceMinutes(key)
            val title = if (test) "Tes suara pengingat sebelum salat ${PrayerAlarm.label(key)}" else "Pengingat sebelum salat ${PrayerAlarm.label(key)}"
            val message = "Waktu salat ${PrayerAlarm.label(key)} tinggal $lead menit lagi."
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title).setContentText(message).setContentIntent(open)
                .setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            if (test) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false)
                .putString("test_playback_key", "advance_$key").apply()
            val customSound = pp.advanceSound(key)
            if (customSound.isNotBlank()) playSound(customSound, pp.volumeMode, startId, "advance_custom", test)
            else ucapkanPengingatAwal(message, startId, test)
            return START_NOT_STICKY
        }
        if (test) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
            .putBoolean("test_playback_active", true)
            .putBoolean("test_playback_paused", false)
            .putString("test_playback_key", key)
            .apply()
        if (!test && (!pp.enabled || !pp.reminder(key))) { stopSelf(startId); return START_NOT_STICKY }
        createChannel()
        val title = if (test) "Tes suara azan ${PrayerAlarm.label(key)}" else "Saatnya menunaikan sholat ${PrayerAlarm.label(key)}"
        val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND")
        val stopPi = PendingIntent.getService(this, 810, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = n.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(if (pp.notifyOnly && !test) "Pengingat waktu sholat" else "Pengingat waktu sholat dan suara azan")
            .setContentIntent(open).setAutoCancel(false).setOngoing(true)
        val toggleIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK")
        val togglePi = PendingIntent.getService(this, 811, toggleIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        if (test) {
            val pauseIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.PAUSE_TEST_PLAYBACK")
            val resumeIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.RESUME_TEST_PLAYBACK")
            val pausePi = PendingIntent.getService(this, 812, pauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val resumePi = PendingIntent.getService(this, 813, resumeIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(android.R.drawable.ic_media_pause, "Jeda tes suara azan", pausePi)
            builder.addAction(android.R.drawable.ic_media_play, "Lanjutkan tes suara azan", resumePi)
            val stopTestIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_TEST_PLAYBACK")
            val stopTestPi = PendingIntent.getService(this, 814, stopTestIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan tes suara azan", stopTestPi)
        } else {
            builder.addAction(android.R.drawable.ic_media_play, "Jeda atau lanjutkan suara azan", togglePi)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan suara azan", stopPi)
        }
        val notification = builder.build()
        startForeground(809, notification)
        if (pp.notifyOnly && !test) { handler.postDelayed({ stopSelf(startId) }, 2500); return START_NOT_STICKY }
        playSound(pp.sound(key).ifBlank { pp.globalSound }, pp.volumeMode, startId, key, test)
        if (!test && !advanceReminder && pp.stopAzanFaceDown) startFaceDownDetection()
        return START_NOT_STICKY
    }

    private fun playSound(uriString: String, volumeMode: Int, startId: Int, key: String, test: Boolean) {
        stopPlayback()
        try {
            val usage = when (volumeMode) { 1 -> AudioAttributes.USAGE_NOTIFICATION; 2 -> AudioAttributes.USAGE_MEDIA; else -> AudioAttributes.USAGE_ALARM }
            val attrs = AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            if (uriString.isNotBlank()) {
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    setDataSource(this@PrayerAlarmService, Uri.parse(uriString))
                    setOnCompletionListener { if (test) clearTestState(); stopSelf(startId) }
                    setOnErrorListener { _, _, _ -> if (test) clearTestState(); stopSelf(startId); true }
                    prepare(); start()
                }
                handler.postDelayed({ stopSelf(startId) }, 180_000L)
            } else {
                // Audio azan bawaan dibawa dari APK referensi: azan Subuh dan azan umum.
                val resource = if (key == "subuh") R.raw.azan_subuh else R.raw.azan_biasa
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    val afd = this@PrayerAlarmService.resources.openRawResourceFd(resource)
                    try { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                    setOnCompletionListener { if (test) clearTestState(); stopSelf(startId) }
                    setOnErrorListener { _, _, _ -> if (test) clearTestState(); stopSelf(startId); true }
                    prepare(); start()
                }
                handler.postDelayed({ stopSelf(startId) }, 240_000L)
            }
        } catch (_: Exception) {
            stopSelf(startId)
        }
    }

    private fun startFaceDownDetection() {
        stopFaceDownDetection()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val manager = sensorManager ?: return
        faceDownSensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
            ?: manager.getDefaultSensor(Sensor.TYPE_GRAVITY, true)
            ?: manager.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        faceDownSince = 0L
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            faceDownWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:StopAzanFaceDown").apply { setReferenceCounted(false); acquire(5 * 60_000L) }
        } catch (_: Exception) { }
        try { faceDownSensor?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) } } catch (_: Exception) { }
    }

    private fun stopFaceDownDetection() {
        try { sensorManager?.unregisterListener(this) } catch (_: Exception) { }
        sensorManager = null
        faceDownSensor = null
        faceDownSince = 0L
        try { if (faceDownWakeLock?.isHeld == true) faceDownWakeLock?.release() } catch (_: Exception) { }
        faceDownWakeLock = null
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        if (isTestPlayback || player?.isPlaying != true || !PrayerPrefs(this).stopAzanFaceDown) return
        // Ponsel dianggap menelungkup bila layar menghadap ke bawah dan perangkat relatif datar.
        val flatFaceDown = e.values.size >= 3 && e.values[2] < -7.0f && kotlin.math.abs(e.values[0]) < 3.5f && kotlin.math.abs(e.values[1]) < 3.5f
        val now = System.currentTimeMillis()
        if (flatFaceDown) {
            if (faceDownSince == 0L) faceDownSince = now
            if (now - faceDownSince >= 650L && now - lastFaceDownStop > 1800L) {
                lastFaceDownStop = now
                stopPlayback()
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
                stopSelf()
            }
        } else faceDownSince = 0L
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { }

    private fun ucapkanPengingatAwal(teks: String, startId: Int, test: Boolean = false) {
        try {
            reminderTts?.shutdown()
            reminderTts = TextToSpeech(applicationContext) { status ->
                val engine = reminderTts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    val locale = Locale("id", "ID")
                    val languageResult = engine.setLanguage(locale)
                    if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.language = Locale("id")
                    }
                    if (Build.VERSION.SDK_INT >= 21) {
                        engine.speak(teks, TextToSpeech.QUEUE_FLUSH, null, "pengingat_awal_$startId")
                    } else {
                        @Suppress("DEPRECATION")
                        engine.speak(teks, TextToSpeech.QUEUE_FLUSH, null)
                    }
                    handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, 15000L)
                } else {
                    handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, 5000L)
                }
            }
        } catch (_: Exception) {
            handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, 5000L)
        }
    }

    private fun updateTestNotification(paused: Boolean) {
        val pp = PrayerPrefs(this)
        val key = "subuh"
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val toggleIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_TEST_PLAYBACK")
        fun pi(req: Int, i: Intent) = PendingIntent.getService(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Tes suara azan — ${if (paused) "dijeda" else "sedang diputar"}")
            .setContentText("Satu tombol untuk jeda atau lanjutkan; tombol lain untuk menghentikan")
            .setOngoing(true).setAutoCancel(false)
            .addAction(if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause, if (paused) "Lanjutkan tes suara azan" else "Jeda tes suara azan", pi(812, toggleIntent))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Hentikan tes suara azan", pi(814, stopIntent))
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(809, builder.build())
    }

    private fun clearTestState() {
        getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel("jadwal_sholat") == null) {
                val channel = NotificationChannel("jadwal_sholat", "Pengingat Jadwal Sholat", NotificationManager.IMPORTANCE_HIGH)
                channel.setSound(null, null)
                manager.createNotificationChannel(channel)
            }
        }
    }
    private fun stopPlayback() {
        stopFaceDownDetection()
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (isTestPlayback) clearTestState()
        stopPlayback()
        try { reminderTts?.stop(); reminderTts?.shutdown() } catch (_: Exception) { }
        reminderTts = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
}
