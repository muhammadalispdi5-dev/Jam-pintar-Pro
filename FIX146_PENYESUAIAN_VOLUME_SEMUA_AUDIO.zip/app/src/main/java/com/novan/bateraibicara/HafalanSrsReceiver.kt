package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** FIX103: notifikasi harian "ayat hafalan perlu diulang"; tidak muncul bila tidak ada ayat jatuh tempo. */
class HafalanSrsReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = HafalanSrs.prefs(context)
        if (!prefs.getBoolean(HafalanSrs.KEY_PENGINGAT, false)) return
        val hari = HafalanSrs.hariIni()
        val due = HafalanSrs.jatuhTempo(prefs, hari)
        if (due.isEmpty()) return
        val english = BahasaAplikasi.tampilan(context) == 1
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "khatam_hafalan_srs"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, if (english) "Memorization review reminder" else "Pengingat ulasan hafalan", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val buka = Intent(context, KhatamActivity::class.java).putExtra(HafalanSrs.EXTRA_BUKA_ULASAN, true)
        val open = PendingIntent.getActivity(context, 6912, buka, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val daftar = due.take(3).joinToString(", ") { HafalanSrs.namaSurah(it.surah) + (if (english) " verse " else " ayat ") + it.ayat }
        val sisa = due.size - 3
        val terlambatMaks = due.maxOf { it.terlambat(hari) }
        val judul = if (english) "Time to review your memorization" else "Saatnya mengulas hafalan"
        var isi = if (english) ("" + (due.size) + " verse(s) to review: " + (daftar)) + (if (sisa > 0) (" and " + (sisa) + " more") else "")
            else ("" + (due.size) + " ayat perlu diulang: " + (daftar)) + (if (sisa > 0) (" dan " + (sisa) + " lainnya") else "")
        if (terlambatMaks >= 3) isi += if (english) (". Some are " + (terlambatMaks) + " days overdue.") else (". Ada yang tertunda " + (terlambatMaks) + " hari.")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, channelId) else Notification.Builder(context)
        val notification = builder
            .setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(judul)
            .setContentText(isi)
            .setStyle(Notification.BigTextStyle().bigText(isi))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { manager.notify(6913, notification) } catch (_: SecurityException) { }
        // FIX124: bunyi notifikasi ini dapat dihentikan dengan tombol volume atau telungkup, seperti notifikasi aplikasi lainnya.
        PembungkamTelungkup.mulai(context, "hafalan_srs_notif", 20_000L) { try { manager.cancel(6913) } catch (_: Exception) { } }
    }
}
