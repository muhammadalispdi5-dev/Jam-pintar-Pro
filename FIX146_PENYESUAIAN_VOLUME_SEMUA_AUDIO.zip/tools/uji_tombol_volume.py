#!/usr/bin/env python3
"""Uji FIX122: tombol volume menghentikan suara notifikasi dan tidak bisa tersangkut.
Bagian 1: port Python dari mesin status Halaman.dispatchKeyEvent (lama vs baru). Bagian 2: kontrak sumber Kotlin.
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys

def jalankan(urutan, baru, ada_suara):
    """urutan: daftar ('D'|'U', repeat). ada_suara: fungsi indeks->bool. Mengembalikan daftar hasil: 'henti','telan','sistem','lolos'."""
    dikonsumsi = False; keluar = []
    for i, (aksi, ulang) in enumerate(urutan):
        if aksi == 'D':
            if baru and ulang == 0: dikonsumsi = False
            if dikonsumsi: keluar.append('telan'); continue
            if ada_suara(i): dikonsumsi = True; keluar.append('henti'); continue
            keluar.append('sistem')
        else:
            if dikonsumsi: dikonsumsi = False; keluar.append('telan'); continue
            keluar.append('sistem')
    return keluar

gagal = []
def cek(n, k):
    if not k: gagal.append(n)

# Tekan pertama menghentikan suara tetapi ACTION_UP tidak pernah sampai (halaman jeda); tekan kedua saat suara baru berbunyi.
urutan = [('D', 0), ('D', 0)]
suara = lambda i: True
lama = jalankan(urutan, False, suara); baru = jalankan(urutan, True, suara)
cek("model lama menelan tekanan kedua (bug)", lama == ['henti', 'telan'])
cek("model baru menghentikan lagi", baru == ['henti', 'henti'])
# Tanpa suara aktif setelah status tersangkut: volume biasa harus bekerja
urutan2 = [('D', 0), ('D', 0)]
suara2 = lambda i: i == 0
cek("lama: volume biasa mati setelah tersangkut", jalankan(urutan2, False, suara2) == ['henti', 'telan'])
cek("baru: volume biasa tetap jalan", jalankan(urutan2, True, suara2) == ['henti', 'sistem'])
# Tekan-tahan tetap tidak diteruskan ke pengatur volume
tahan = [('D', 0), ('D', 1), ('D', 2), ('U', 0)]
cek("tekan-tahan ditelan sampai dilepas", jalankan(tahan, True, lambda i: i == 0) == ['henti', 'telan', 'telan', 'telan'])

B = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
hl = (B / "Halaman.kt").read_text(encoding="utf-8")
ps = (B / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
cek("Halaman: tekanan baru mereset status", "if (event.repeatCount == 0) volumeDikonsumsi = false" in hl)
cek("Halaman: reset saat jeda", "override fun onPause() {\n        volumeDikonsumsi = false" in hl)
cek("Halaman: reset saat kehilangan fokus jendela", "if (!hasFocus) volumeDikonsumsi = false" in hl)
cek("PerintahSuara: menangani tombol volume", "override fun dispatchKeyEvent" in ps and "PembungkamTelungkup.bungkamDariTombolVolume(this)" in ps)
cek("PerintahSuara: layar ditutup setelah suara dihentikan", "volumeDikonsumsi = true\n                    tutupDanLanjutAudio()" in ps)
cek("PerintahSuara: telungkup juga menutup layar", "PembungkamTelungkup.generasi != generasiBungkamAwal" in ps and "postDelayed(pantauBungkam, 400L)" in ps)
cek("semua Pembicara jawaban terdaftar sebagai bisa dibungkam", ps.count(".also { it.bisaDibungkam = true }") == 4 and ps.count("Pembicara(applicationContext") == 4)
if gagal:
    print("UJI TOMBOL VOLUME: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI TOMBOL VOLUME: LULUS (port logika + kontrak sumber)")
