#!/usr/bin/env python3
"""Pemeriksaan statis awal proyek Jam Pintar Pro sebelum build Android."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
GRADLE = ROOT / "app/build.gradle.kts"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
ANDROID = "{http://schemas.android.com/apk/res/android}"
errors = []
notes = []

def fail(message: str) -> None:
    errors.append(message)

if not GRADLE.is_file():
    fail("app/build.gradle.kts tidak ditemukan")
if not MANIFEST.is_file():
    fail("AndroidManifest.xml tidak ditemukan")

if not errors:
    gradle_text = GRADLE.read_text(encoding="utf-8")
    for key, pattern in {
        "versionCode": r"versionCode\s*=\s*(\d+)",
        "versionName": r'versionName\s*=\s*"([^\"]+)"',
        "applicationId": r'applicationId\s*=\s*"([^\"]+)"',
        "compileSdk": r"compileSdk\s*=\s*(\d+)",
        "minSdk": r"minSdk\s*=\s*(\d+)",
        "targetSdk": r"targetSdk\s*=\s*(\d+)",
    }.items():
        if not re.search(pattern, gradle_text):
            fail(f"Konfigurasi {key} tidak ditemukan")

    values = {}
    for key, pattern in {
        "versionCode": r"versionCode\s*=\s*(\d+)",
        "versionName": r'versionName\s*=\s*"([^\"]+)"',
        "applicationId": r'applicationId\s*=\s*"([^\"]+)"',
        "compileSdk": r"compileSdk\s*=\s*(\d+)",
        "minSdk": r"minSdk\s*=\s*(\d+)",
        "targetSdk": r"targetSdk\s*=\s*(\d+)",
    }.items():
        match = re.search(pattern, gradle_text)
        if match:
            values[key] = match.group(1)

    version_name = values.get("versionName", "")
    version_code = values.get("versionCode", "")
    if not version_name or not version_code or not version_code.isdigit():
        fail("VersionName atau versionCode tidak valid")
    elif not re.fullmatch(r"\d+\.\d+\.\d+", version_name):
        fail(f"Format versionName tidak valid: {version_name}")
    if values.get("minSdk") and int(values["minSdk"]) < 1:
        fail("minSdk tidak valid")
    if values.get("targetSdk") and values.get("compileSdk") and int(values["targetSdk"]) > int(values["compileSdk"]):
        fail("targetSdk lebih tinggi daripada compileSdk")

    try:
        root = ET.parse(MANIFEST).getroot()
        app = root.find("application")
        if app is None:
            fail("Elemen application tidak ditemukan di manifest")
        else:
            components = ("activity", "service", "receiver", "provider")
            source_root = ROOT / "app/src/main/java"
            for tag in components:
                for component in app.findall(tag):
                    name = component.get(ANDROID + "name", "")
                    exported = component.get(ANDROID + "exported")
                    if not name:
                        fail(f"Komponen {tag} tidak memiliki android:name")
                        continue
                    if exported is None:
                        fail(f"Komponen {tag} {name} tidak menyatakan android:exported secara eksplisit")
                    if name.startswith("."):
                        class_name = name[1:]
                    elif "." not in name:
                        class_name = name
                    else:
                        class_name = name.rsplit(".", 1)[-1]
                    matches = list(source_root.rglob(class_name + ".kt")) + list(source_root.rglob(class_name + ".java"))
                    if not matches:
                        fail(f"Sumber kelas untuk komponen manifest {name} tidak ditemukan")
            permissions = {node.get(ANDROID + "name") for node in root.findall("uses-permission")}
            for required in ("android.permission.RECEIVE_BOOT_COMPLETED", "android.permission.SCHEDULE_EXACT_ALARM"):
                if required not in permissions:
                    fail(f"Izin penting tidak ditemukan: {required}")
    except ET.ParseError as exc:
        fail(f"AndroidManifest.xml tidak valid: {exc}")

    # Pastikan setiap kunci teks utama tersedia dalam kedua bahasa tampilan.
    id_strings = ROOT / "app/src/main/res/values/strings.xml"
    en_strings = ROOT / "app/src/main/res/values-en/strings.xml"
    try:
        id_keys = {node.get("name") for node in ET.parse(id_strings).getroot().findall("string")}
        en_keys = {node.get("name") for node in ET.parse(en_strings).getroot().findall("string")}
        for key in sorted(id_keys - en_keys):
            fail(f"Teks bahasa Inggris belum memiliki kunci string: {key}")
        for key in sorted(en_keys - id_keys):
            fail(f"Teks bahasa Indonesia belum memiliki kunci string: {key}")
    except (ET.ParseError, OSError) as exc:
        fail(f"Berkas sumber daya bahasa tidak dapat diperiksa: {exc}")

    # Pemeriksaan kontrak fitur Khatam dan konsistensi bahasa aktif.
    khatam = ROOT / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt"
    receiver = ROOT / "app/src/main/java/com/novan/bateraibicara/KhatamReminderReceiver.kt"
    if khatam.is_file():
        khatam_text = khatam.read_text(encoding="utf-8")
        for feature, marker in {
            "teks Arab offline": "quran_ar.json",
            "terjemahan Indonesia": "quran_id.json",
            "terjemahan Inggris": "quran_en.json",
            "penanda ayat selesai": '"ayat_selesai"',
            "target khatam": '"target_hari"',
            "statistik harian": '"selesai_"',
            "pengulangan audio": '"pengulangan_audio_ayat"',
            "kecepatan audio": '"kecepatan_audio"',
            "izin notifikasi pengingat": "POST_NOTIFICATIONS",
            "cache tahan-gangguan": "tulisCacheAtomik",
        }.items():
            if marker not in khatam_text:
                fail(f"Fitur Khatam tidak terdeteksi: {feature}")
        if 'if (BahasaAplikasi.tampilan(this) == 1) arrayOf("0.75x"' not in khatam_text:
            fail("Label kecepatan audio belum mengikuti bahasa aktif")
        if 'if (BahasaAplikasi.tampilan(this) == 1) s.optString("englishName") else s.optString("name")' not in khatam_text:
            fail("Nama surah belum disesuaikan dengan bahasa tampilan aktif")
    if receiver.is_file():
        receiver_text = receiver.read_text(encoding="utf-8")
        if 'BahasaAplikasi.tampilan(context)' not in receiver_text:
            fail("Bahasa notifikasi Khatam belum mengikuti bahasa aplikasi")

    home = ROOT / "app/src/main/java/com/novan/bateraibicara/MainActivity.kt"
    base_ui = ROOT / "app/src/main/java/com/novan/bateraibicara/Halaman.kt"
    if home.is_file() and "QiblaActivity::class.java" not in home.read_text(encoding="utf-8"):
        fail("Pintasan Arah Kiblat langsung dari beranda tidak ditemukan")
    if base_ui.is_file() and "s.setTextColor(warnaTeks())" not in base_ui.read_text(encoding="utf-8"):
        fail("Warna teks sakelar belum mengikuti tema terang/gelap")

    if not (ROOT / ".github/workflows/build.yml").is_file():
        fail("Workflow build.yml tidak ditemukan")
    if not (ROOT / ".github/workflows/rilis.yml").is_file():
        notes.append("Workflow rilis.yml tidak ditemukan; alur rilis manual tidak bisa diverifikasi")

# Aturan tetap: semua fitur mengikuti bahasa aktif (lihat ATURAN_BAHASA_AKTIF.md).
import subprocess
if not (ROOT / "ATURAN_BAHASA_AKTIF.md").is_file():
    fail("ATURAN_BAHASA_AKTIF.md hilang")
_hasil_bahasa = subprocess.run([sys.executable, str(ROOT / "tools/periksa_bahasa_aktif.py")], capture_output=True, text=True)
if _hasil_bahasa.returncode != 0:
    fail("Pemeriksaan bahasa aktif gagal:\n" + _hasil_bahasa.stdout.strip())
else:
    notes.append(_hasil_bahasa.stdout.strip())

# Resource string harus lolos aturan aapt2 (apostrof, \\u, kutip, format) agar :app:mergeDebugResources tidak gagal.
_hasil_resource = subprocess.run([sys.executable, str(ROOT / "tools/periksa_resource_strings.py")], capture_output=True, text=True)
if _hasil_resource.returncode != 0:
    fail("Pemeriksaan resource string gagal:\n" + _hasil_resource.stdout.strip())
else:
    notes.append(_hasil_resource.stdout.strip())

if errors:
    print("PEMERIKSAAN PROYEK: GAGAL")
    for item in errors:
        print(f"- {item}")
    for item in notes:
        print(f"CATATAN: {item}")
    sys.exit(1)

print("PEMERIKSAAN PROYEK: LULUS")
gradle_text = GRADLE.read_text(encoding="utf-8")
version_name = re.search(r'versionName\s*=\s*"([^\"]+)"', gradle_text).group(1)
version_code = re.search(r"versionCode\s*=\s*(\d+)", gradle_text).group(1)
print(f"- Versi aplikasi {version_name} (versionCode {version_code})")
print("- Konfigurasi Gradle dan XML manifest dapat dibaca")
print("- Komponen manifest memiliki deklarasi exported dan sumber kelas ditemukan")
print("- Izin boot dan alarm tepat waktu terdeklarasi")
for item in notes:
    print(f"CATATAN: {item}")
print("Catatan: pemeriksaan ini bersifat statis, bukan pengganti kompilasi atau uji perangkat.")
