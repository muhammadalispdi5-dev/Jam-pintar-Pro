package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

class Prefs(context: Context) {

    internal val appContext: Context = context.applicationContext
    private val sp = context.applicationContext
        .getSharedPreferences("pengaturan", Context.MODE_PRIVATE)

    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun idx(k: String, d: Int, max: Int) = sp.getInt(k, d).coerceIn(0, max - 1)
    private fun putInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    // ---------- Umum ----------
    var enabled: Boolean
        get() = bool("enabled", false)
        set(v) = putBool("enabled", v)

    var bootOn: Boolean
        get() = bool("boot", false)
        set(v) = putBool("boot", v)

    // ---------- Profil suara: "bat" (baterai), "jam", "tgl" (pembaca tanggal), "pem" (pemanggil) ----------
    fun suara(profil: String) = Suara(profil)

    inner class Suara(private val p: String) {
        val profil: String get() = p
        // Profil baterai memakai kunci lama agar pengaturan lama tetap terbaca.
        private fun k(n: String) = if (p == "bat") n else ("" + (p) + "_" + (n))

        /**
         * Profil "tgl" (pembaca tanggal) memakai pengaturan profil "jam" selama belum pernah diubah sendiri,
         * sehingga suara tanggal tidak tiba-tiba berganti setelah pembaruan.
         */
        private fun kb(n: String) = if (p == "tgl" && !sp.contains(k(n))) ("jam_" + n) else k(n)

        /** Nama paket mesin suara; kosong = mesin bawaan sistem. */
        var engine: String
            get() = sp.getString(kb("engine"), "") ?: ""
            set(v) = sp.edit().putString(k("engine"), v).apply()

        var rateIdx: Int
            get() = idx(kb("rate"), 2, RATES.size)
            set(v) = putInt(k("rate"), v)

        var pitchIdx: Int
            get() = idx(kb("pitch"), 2, PITCHES.size)
            set(v) = putInt(k("pitch"), v)

        /** 0 = Media, 1 = Alarm, 2 = Notifikasi, 3 = Dering, 4 = Aksesibilitas, 5 = Panggilan suara, 6 = Sistem */
        var streamIdx: Int
            get() = idx(kb("stream"), if (p == "pem") 1 else 0, 7)
            set(v) = putInt(k("stream"), v)

        val rate: Float get() = RATES[rateIdx]
        val pitch: Float get() = PITCHES[pitchIdx]

        fun tanda() = (("" + (p) + "|" + (engine) + "|" + (rateIdx) + "|" + (pitchIdx) + "|" + (streamIdx) + "|") + (if (p == "jam" || p == "tgl") jamBahasaIdx else 0))

        fun audioAttributes(): AudioAttributes {
            val usage = when (streamIdx) {
                1 -> AudioAttributes.USAGE_ALARM
                2 -> AudioAttributes.USAGE_NOTIFICATION
                3 -> AudioAttributes.USAGE_NOTIFICATION_RINGTONE
                4 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
                5 -> AudioAttributes.USAGE_VOICE_COMMUNICATION
                6 -> AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
                else -> AudioAttributes.USAGE_MEDIA
            }
            return AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        }

        fun streamType(): Int = when (streamIdx) {
            1 -> AudioManager.STREAM_ALARM
            2 -> AudioManager.STREAM_NOTIFICATION
            3 -> AudioManager.STREAM_RING
            4 -> if (android.os.Build.VERSION.SDK_INT >= 26) AudioManager.STREAM_ACCESSIBILITY else AudioManager.STREAM_MUSIC
            5 -> AudioManager.STREAM_VOICE_CALL
            6 -> AudioManager.STREAM_SYSTEM
            else -> AudioManager.STREAM_MUSIC
        }
    }

    // ---------- Baterai ----------
    var bateraiOn: Boolean
        get() = bool("baterai_on", false)
        set(v) = putBool("baterai_on", v)

    var stepIdx: Int
        get() = idx("step", 1, STEPS.size)
        set(v) = putInt("step", v)

    /** 0 = berdasarkan persen baterai, 1 = berdasarkan interval waktu. */
    var batCara: Int
        get() = idx("bat_cara", 0, 2)
        set(v) = putInt("bat_cara", v)

    var batIntervalIdx: Int
        get() = idx("bat_interval", 3, BAT_INTERVALS.size)
        set(v) = putInt("bat_interval", v)

    val batInterval: Int get() = BAT_INTERVALS[batIntervalIdx]

    /** 0 = persen disebut hanya saat mengisi daya, 1 = selalu */
    var levelMode: Int
        get() = idx("level_mode", 1, 2)
        set(v) = putInt("level_mode", v)

    var lowIdx: Int
        get() = idx("low", 1, LOWS.size)
        set(v) = putInt("low", v)

    var lemahOn: Boolean
        get() = bool("lemah", false)
        set(v) = putBool("lemah", v)

    var kritisOn: Boolean
        get() = bool("kritis", false)
        set(v) = putBool("kritis", v)

    /** Batas kritis yang dapat dipilih pengguna, dalam persen. */
    var batasKritis: Int
        get() = sp.getInt("batas_kritis", 5).coerceIn(1, 20)
        set(v) = putInt("batas_kritis", v.coerceIn(1, 20))

    var penuhOn: Boolean
        get() = bool("penuh", false)
        set(v) = putBool("penuh", v)

    var chargerOn: Boolean
        get() = bool("charger", false)
        set(v) = putBool("charger", v)

    var usbOn: Boolean
        get() = bool("usb", false)
        set(v) = putBool("usb", v)

    val lowThreshold: Int get() = LOWS[lowIdx]
    val step: Int get() = STEPS[stepIdx]

    // Kalimat baterai yang dapat diubah; token {persen} diganti dengan angka aktual.
    private fun kalimat(kunci: String, bawaan: String) = sp.getString(kunci, null)?.takeIf { it.isNotBlank() } ?: bawaan
    var kalLevel: String
        get() = kalimat("kal_level", "Baterai {persen} persen.")
        set(v) = sp.edit().putString("kal_level", v).apply()
    var kalLemah: String
        get() = kalimat("kal_lemah", "Baterai lemah, tinggal {persen} persen. Segera isi daya.")
        set(v) = sp.edit().putString("kal_lemah", v).apply()
    var kalKritis: String
        get() = kalimat("kal_kritis", "Peringatan! Baterai kritis, tinggal {persen} persen. Segera isi daya.")
        set(v) = sp.edit().putString("kal_kritis", v).apply()
    var kalPenuh: String
        get() = kalimat("kal_penuh", "Baterai sudah {persen} persen. Silakan cabut pengisi daya.")
        set(v) = sp.edit().putString("kal_penuh", v).apply()
    var kalPenuh100: String
        get() = kalimat("kal_penuh_100", "Baterai sudah 100 persen. Silakan cabut pengisi daya.")
        set(v) = sp.edit().putString("kal_penuh_100", v).apply()
    var kalChargerOn: String
        get() = kalimat("kal_charger_on", "Pengisi daya terhubung.")
        set(v) = sp.edit().putString("kal_charger_on", v).apply()
    var kalChargerOff: String
        get() = kalimat("kal_charger_off", "Pengisi daya dicabut.")
        set(v) = sp.edit().putString("kal_charger_off", v).apply()
    var kalUsbOn: String
        get() = kalimat("kal_usb_on", "Kabel USB terhubung.")
        set(v) = sp.edit().putString("kal_usb_on", v).apply()
    var kalUsbOff: String
        get() = kalimat("kal_usb_off", "Kabel USB dicabut.")
        set(v) = sp.edit().putString("kal_usb_off", v).apply()

    // ---------- Pemicu Beritahu Saya ----------
    /** Mengizinkan widget layar utama membacakan waktu. Aktif secara bawaan untuk menjaga perilaku lama. */
    var beritahuSayaOn: Boolean
        get() = bool("beritahu_saya_on", false)
        set(v) = putBool("beritahu_saya_on", v)

    // ---------- Info hari libur nasional dan cuti bersama ----------
    var liburNasionalAutoSync: Boolean
        get() = bool("enable_national_auto_sync", false)
        set(v) = putBool("enable_national_auto_sync", v)
    var liburNasionalLampau: Boolean
        get() = bool("enable_national_past", false)
        set(v) = putBool("enable_national_past", v)
    var liburNasionalTerkini: Boolean
        get() = bool("enable_national_current", false)
        set(v) = putBool("enable_national_current", v)
    var liburNasionalMendatang: Boolean
        get() = bool("enable_national_upcoming", false)
        set(v) = putBool("enable_national_upcoming", v)
    var cutiBersamaAutoSync: Boolean
        get() = bool("enable_joint_auto_sync", false)
        set(v) = putBool("enable_joint_auto_sync", v)
    var cutiBersamaLampau: Boolean
        get() = bool("enable_joint_past", false)
        set(v) = putBool("enable_joint_past", v)
    var cutiBersamaTerkini: Boolean
        get() = bool("enable_joint_current", false)
        set(v) = putBool("enable_joint_current", v)
    var cutiBersamaMendatang: Boolean
        get() = bool("enable_joint_upcoming", false)
        set(v) = putBool("enable_joint_upcoming", v)

    // ---------- Jam ----------
    var jamOn: Boolean
        get() = bool("jam_on", false)
        set(v) = putBool("jam_on", v)

    /** 0 = setiap jam tepat, 1 = setiap beberapa menit */
    var jamMode: Int
        get() = idx("jam_mode", 0, 2)
        set(v) = putInt("jam_mode", v)

    var jamIntervalIdx: Int
        get() = idx("jam_interval", 4, JAM_INTERVALS.size)
        set(v) = putInt("jam_interval", v)

    val jamInterval: Int get() = JAM_INTERVALS[jamIntervalIdx]

    /** Menit sejak pukul 00.00 */
    var jamMulai: Int
        get() = sp.getInt("jam_mulai", 6 * 60).coerceIn(0, 1439)
        set(v) = putInt("jam_mulai", v)

    var jamSelesai: Int
        get() = sp.getInt("jam_selesai", 22 * 60).coerceIn(0, 1439)
        set(v) = putInt("jam_selesai", v)

    /** Bit 0 = Minggu, bit 1 = Senin, ... bit 6 = Sabtu */
    var jamHari: Int
        get() = sp.getInt("jam_hari", 127) and 127
        set(v) = putInt("jam_hari", v and 127)

    /** 0 = 24 jam, 1 = 12 jam (pagi/siang/sore/malam) */
    var jamFormat: Int
        get() = idx("jam_format", 1, 2)
        set(v) = putInt("jam_format", v)

    /** Bahasa untuk pengumuman waktu: 0 Indonesia, 1 English, 2 Arab, 3 Jawa Krama. */
    var jamBahasaIdx: Int
        get() = idx("jam_bahasa", 0, 4)
        set(v) = putInt("jam_bahasa", v)

    /** Melodi jam: 0 = mati, 1..16 = audio yang dipulihkan dari APK sumber. */
    var jamMelodiAwal: Int
        get() = idx("jam_melodi_awal", 0, 17)
        set(v) = putInt("jam_melodi_awal", v)

    var jamMelodiAkhir: Int
        get() = idx("jam_melodi_akhir", 0, 17)
        set(v) = putInt("jam_melodi_akhir", v)

    var jamJedaAwal: Float
        get() = sp.getFloat("jam_jeda_awal", 0.0f).coerceIn(0f, 30f)
        set(v) = sp.edit().putFloat("jam_jeda_awal", v.coerceIn(0f, 30f)).apply()

    var jamJedaAkhir: Float
        get() = sp.getFloat("jam_jeda_akhir", 0.0f).coerceIn(0f, 30f)
        set(v) = sp.edit().putFloat("jam_jeda_akhir", v.coerceIn(0f, 30f)).apply()

    var jamJedaJamMenit: Int
        get() {
            // Versi 1.0.29 mengembalikan jeda antarucapan jam-menit ke standar 300 ms.
            // Migrasi hanya dilakukan sekali agar nilai 650 ms dari versi sebelumnya tidak tertinggal.
            if (!sp.getBoolean("jam_jeda_standard_v1029", false)) {
                sp.edit().putInt("jam_jeda_jam_menit", 300)
                    .putBoolean("jam_jeda_standard_v1029", true).apply()
            }
            return sp.getInt("jam_jeda_jam_menit", 300).coerceIn(0, 3000)
        }
        set(v) = putInt("jam_jeda_jam_menit", v.coerceIn(0, 3000))

    // ---------- Pengulangan baterai penuh ----------
    var penuhUlangOn: Boolean
        get() = bool("penuh_ulang", false)
        set(v) = putBool("penuh_ulang", v)

    var penuhUlangJumlah: Int
        get() = sp.getInt("penuh_ulang_jumlah", 3).coerceIn(1, 20)
        set(v) = putInt("penuh_ulang_jumlah", v.coerceIn(1, 20))

    var penuhUlangJeda: Int
        get() = sp.getInt("penuh_ulang_jeda", 60).coerceIn(1, 3600)
        set(v) = putInt("penuh_ulang_jeda", v.coerceIn(1, 3600))

    var batasPenuh: Int
        get() = sp.getInt("batas_penuh", 100).coerceIn(80, 100)
        set(v) = putInt("batas_penuh", v.coerceIn(80, 100))

    var jamSebutJam: Boolean
        get() = bool("jam_sebut_jam", false)
        set(v) = putBool("jam_sebut_jam", v)

    var jamSebutMenit: Boolean
        get() = bool("jam_menit", false)
        set(v) = putBool("jam_menit", v)

    var jamSebutDetik: Boolean
        get() = bool("jam_detik", false)
        set(v) = putBool("jam_detik", v)

    /** Kata "tepat" sebelum jam, saat jam pas (mis. "Tepat pukul lima pagi"). */
    var jamTepatAwal: Boolean
        get() = bool("jam_tepat_awal", false)
        set(v) = putBool("jam_tepat_awal", v)

    /** Kata "tepat" sesudah jam, saat jam pas (mis. "pukul enam tepat"). Bawaan aktif seperti perilaku sebelumnya. */
    var jamTepatAkhir: Boolean
        get() = bool("jam_tepat_akhir", true)
        set(v) = putBool("jam_tepat_akhir", v)

    /** Info waktu sholat berikutnya ikut dibacakan dalam rangkaian ucapan jam (bawaan mati). */
    var jamInfoSholat: Boolean
        get() = bool("jam_info_sholat", false)
        set(v) = putBool("jam_info_sholat", v)

    /** Sebut nama lokasi pada info sholat berikutnya (bawaan aktif). */
    var jamInfoSholatLokasi: Boolean
        get() = bool("jam_info_sholat_lokasi", true)
        set(v) = putBool("jam_info_sholat_lokasi", v)

    var jamSebutPeriode: Boolean
        get() = bool("jam_sebut_periode", false)
        set(v) = putBool("jam_sebut_periode", v)

    /** Kata pembuka ucapan bawaan tiap bahasa ucapan: 0 Indonesia, 1 English, 2 Arab, 3 Jawa. */
    fun awalanBawaan(bahasa: Int): String = when (bahasa) {
        1 -> "It is"
        2 -> "الوقت الحالي"
        3 -> "Sapunika wekdalipun"
        else -> "Saat ini pukul"
    }

    // Tiap bahasa menyimpan kata pembuka sendiri (Indonesia tetap memakai kunci lama "jam_awalan").
    private fun kunciAwalan(bahasa: Int): String = when (bahasa) {
        1 -> "jam_awalan_en"
        2 -> "jam_awalan_ar"
        3 -> "jam_awalan_jv"
        else -> "jam_awalan"
    }

    /** Kata pembuka untuk bahasa ucapan yang sedang dipilih; kosong/spasi = kata pembuka bawaan bahasa itu. */
    var jamAwalan: String
        get() = sp.getString(kunciAwalan(jamBahasaIdx), null)?.takeIf { it.isNotBlank() } ?: awalanBawaan(jamBahasaIdx)
        set(v) = sp.edit().putString(kunciAwalan(jamBahasaIdx), v).apply()

    // ---------- Kalender yang dibacakan bersama waktu ----------
    var kalenderMasehiOn: Boolean
        get() = bool("kal_masehi_on", false)
        set(v) = putBool("kal_masehi_on", v)

    var kalenderHijriOn: Boolean
        get() = bool("kal_hijri_on", false)
        set(v) = putBool("kal_hijri_on", v)

    /** Mode otomatis memakai perhitungan Hijriah perangkat; koreksi manual dikunci saat aktif. */
    var kalenderHijriAuto: Boolean
        get() = bool("kal_hijri_auto", false)
        set(v) = putBool("kal_hijri_auto", v)

    /** Koreksi hari Hijriah manual, rentang -30 sampai +30. */
    var kalenderHijriKoreksi: Int
        get() = sp.getInt("kal_hijri_koreksi", 0).coerceIn(-30, 30)
        set(v) = putInt("kal_hijri_koreksi", v.coerceIn(-30, 30))

    /** Selisih hasil sinkronisasi daring terhadap kalender Hijriah Android. */
    var kalenderHijriOnlineOffset: Int
        get() = sp.getInt("kal_hijri_online_offset", 0).coerceIn(-3, 3)
        set(v) = putInt("kal_hijri_online_offset", v.coerceIn(-3, 3))
    val kalenderHijriOnlineTanggal: String
        get() = sp.getString("kal_hijri_online_sync_date", "") ?: ""
    val kalenderHijriOnlineHari: Int
        get() = sp.getInt("kal_hijri_online_day", 0)
    val kalenderHijriOnlineBulan: Int
        get() = sp.getInt("kal_hijri_online_month", 0)
    val kalenderHijriOnlineTahun: Int
        get() = sp.getInt("kal_hijri_online_year", 0)

    var kalenderPasaranOn: Boolean
        get() = bool("kal_pasaran_on", false)
        set(v) = putBool("kal_pasaran_on", v)

    /** Koreksi putaran pasaran manual, rentang -30 sampai +30 hari. */
    var kalenderPasaranKoreksi: Int
        get() = sp.getInt("kal_pasaran_koreksi", 0).coerceIn(-30, 30)
        set(v) = putInt("kal_pasaran_koreksi", v.coerceIn(-30, 30))

    // ---------- Nama pemanggil ----------
    var pemOn: Boolean
        get() = bool("pem_on", false)
        set(v) = putBool("pem_on", v)

    var pemWa: Boolean
        get() = bool("pem_wa", false)
        set(v) = putBool("pem_wa", v)

    var pemTelp: Boolean
        get() = bool("pem_telp", false)
        set(v) = putBool("pem_telp", v)

    var pemWb: Boolean
        get() = bool("pem_wb", false)
        set(v) = putBool("pem_wb", v)

    var pemJenis: Boolean
        get() = bool("pem_jenis", false)
        set(v) = putBool("pem_jenis", v)

    var pemNamaPanggilan: Boolean
        get() = bool("pem_nama_panggilan", false)
        set(v) = putBool("pem_nama_panggilan", v)

    // Pembacaan notifikasi pesan; semua sakelar baru nonaktif secara bawaan.
    var bacaPesanSeluler: Boolean
        get() = bool("baca_pesan_seluler", false)
        set(v) = putBool("baca_pesan_seluler", v)
    // Sakelar pesan dibedakan menurut aplikasi, jenis pesan, dan percakapan pribadi/grup.
    var bacaChatWaPribadi: Boolean get() = if (sp.contains("baca_chat_wa_pribadi")) bool("baca_chat_wa_pribadi", false) else bool("baca_chat_wa", false); set(v) = putBool("baca_chat_wa_pribadi", v)
    var bacaChatWaGrup: Boolean get() = bool("baca_chat_wa_grup", false); set(v) = putBool("baca_chat_wa_grup", v)
    var bacaSuaraWaPribadi: Boolean get() = if (sp.contains("baca_suara_wa_pribadi")) bool("baca_suara_wa_pribadi", false) else bool("baca_suara_wa", false); set(v) = putBool("baca_suara_wa_pribadi", v)
    var bacaSuaraWaGrup: Boolean get() = bool("baca_suara_wa_grup", false); set(v) = putBool("baca_suara_wa_grup", v)
    var bacaChatWbPribadi: Boolean get() = if (sp.contains("baca_chat_wb_pribadi")) bool("baca_chat_wb_pribadi", false) else bool("baca_chat_wb", false); set(v) = putBool("baca_chat_wb_pribadi", v)
    var bacaChatWbGrup: Boolean get() = bool("baca_chat_wb_grup", false); set(v) = putBool("baca_chat_wb_grup", v)
    var bacaSuaraWbPribadi: Boolean get() = if (sp.contains("baca_suara_wb_pribadi")) bool("baca_suara_wb_pribadi", false) else bool("baca_suara_wb", false); set(v) = putBool("baca_suara_wb_pribadi", v)
    var bacaSuaraWbGrup: Boolean get() = bool("baca_suara_wb_grup", false); set(v) = putBool("baca_suara_wb_grup", v)

    // Kalimat pengumuman pesan masuk; token {nama}, {grup}, {pesan}, dan {jenis} didukung.
    var kalPesanSeluler: String get() = kalimat("kal_pesan_seluler", "Pesan seluler masuk dari {nama}. {pesan}"); set(v) = sp.edit().putString("kal_pesan_seluler", v).apply()
    var kalChatWaPribadi: String get() = kalimat("kal_chat_wa_pribadi", "Chat pribadi WhatsApp Messenger dari {nama}. {pesan}"); set(v) = sp.edit().putString("kal_chat_wa_pribadi", v).apply()
    var kalChatWaGrup: String get() = kalimat("kal_chat_wa_grup", "Chat grup WhatsApp Messenger, {grup}, dari {nama}. {pesan}"); set(v) = sp.edit().putString("kal_chat_wa_grup", v).apply()
    var kalSuaraWaPribadi: String get() = kalimat("kal_suara_wa_pribadi", "Pesan suara pribadi WhatsApp Messenger dari {nama}"); set(v) = sp.edit().putString("kal_suara_wa_pribadi", v).apply()
    var kalSuaraWaGrup: String get() = kalimat("kal_suara_wa_grup", "Pesan suara grup WhatsApp Messenger, {grup}, dari {nama}"); set(v) = sp.edit().putString("kal_suara_wa_grup", v).apply()
    var kalChatWbPribadi: String get() = kalimat("kal_chat_wb_pribadi", "Chat pribadi WhatsApp Business dari {nama}. {pesan}"); set(v) = sp.edit().putString("kal_chat_wb_pribadi", v).apply()
    var kalChatWbGrup: String get() = kalimat("kal_chat_wb_grup", "Chat grup WhatsApp Business, {grup}, dari {nama}. {pesan}"); set(v) = sp.edit().putString("kal_chat_wb_grup", v).apply()
    var kalSuaraWbPribadi: String get() = kalimat("kal_suara_wb_pribadi", "Pesan suara pribadi WhatsApp Business dari {nama}"); set(v) = sp.edit().putString("kal_suara_wb_pribadi", v).apply()
    var kalSuaraWbGrup: String get() = kalimat("kal_suara_wb_grup", "Pesan suara grup WhatsApp Business, {grup}, dari {nama}"); set(v) = sp.edit().putString("kal_suara_wb_grup", v).apply()

    /** Kalimat yang diucapkan; {nama} diganti nama pemanggil. */
    var pemKalimatWaSuara: String
        get() = sp.getString("pem_k_wa_suara", null)?.takeIf { it.isNotBlank() } ?: DEF_WA_SUARA
        set(v) = sp.edit().putString("pem_k_wa_suara", v).apply()

    var pemKalimatWaVideo: String
        get() = sp.getString("pem_k_wa_video", null)?.takeIf { it.isNotBlank() } ?: DEF_WA_VIDEO
        set(v) = sp.edit().putString("pem_k_wa_video", v).apply()

    var pemKalimatTelp: String
        get() = sp.getString("pem_k_telp", null)?.takeIf { it.isNotBlank() } ?: DEF_TELP
        set(v) = sp.edit().putString("pem_k_telp", v).apply()

    var pemKalimatWbSuara: String
        get() = sp.getString("pem_k_wb_suara", null)?.takeIf { it.isNotBlank() } ?: DEF_WB_SUARA
        set(v) = sp.edit().putString("pem_k_wb_suara", v).apply()

    var pemKalimatWbVideo: String
        get() = sp.getString("pem_k_wb_video", null)?.takeIf { it.isNotBlank() } ?: DEF_WB_VIDEO
        set(v) = sp.edit().putString("pem_k_wb_video", v).apply()

    // Melodi pendek sebelum dan sesudah pengumuman nama pemanggil.
    var melodiAwalOn: Boolean
        get() = bool("melodi_awal_on", false)
        set(v) = putBool("melodi_awal_on", v)

    var melodiAkhirOn: Boolean
        get() = bool("melodi_akhir_on", false)
        set(v) = putBool("melodi_akhir_on", v)

    var melodiAwalIdx: Int
        get() = idx("pem_melodi_awal", 1, 17)
        set(v) = putInt("pem_melodi_awal", v)

    var melodiAkhirIdx: Int
        get() = idx("pem_melodi_akhir", 1, 17)
        set(v) = putInt("pem_melodi_akhir", v)

    var jedaMelodiAwal: Int
        get() = sp.getInt("jeda_melodi_awal", 350).coerceIn(0, 3000)
        set(v) = putInt("jeda_melodi_awal", v.coerceIn(0, 3000))

    var jedaMelodiAkhir: Int
        get() = sp.getInt("jeda_melodi_akhir", 250).coerceIn(0, 3000)
        set(v) = putInt("jeda_melodi_akhir", v.coerceIn(0, 3000))

    /** Jeda antar pengulangan, dalam detik. */
    var pemJeda: Float
        get() = sp.getFloat("pem_jeda", 1.5f).coerceIn(0.3f, 60f)
        set(v) = sp.edit().putFloat("pem_jeda", v).apply()

    var pemBatasIdx: Int
        get() = idx("pem_batas", 0, PEM_BATAS.size)
        set(v) = putInt("pem_batas", v)

    val pemBatas: Int get() = PEM_BATAS[pemBatasIdx]

    companion object {
        val DEF_WA_SUARA = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_WA_VIDEO = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_TELP = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_WB_SUARA = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val DEF_WB_VIDEO = "\u007Bjenis\u007D dari \u007Bnama\u007D"
        val RATES = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val PITCHES = floatArrayOf(0.6f, 0.8f, 1.0f, 1.2f, 1.4f)
        val STEPS = intArrayOf(0, 5, 10, 20, 25)
        val BAT_INTERVALS = intArrayOf(1, 2, 5, 10, 15, 30, 60)
        val LOWS = intArrayOf(10, 15, 20, 30)
        val JAM_INTERVALS = intArrayOf(5, 10, 15, 20, 30, 60)
        val PEM_BATAS = intArrayOf(0, 3, 5, 10, 20)
    }
}
