package com.novan.bateraibicara

import android.content.Context
import android.icu.util.IslamicCalendar
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.TimeZone

/** Aturan hari puasa untuk pengingat sahur, Imsak, dan berbuka. */
object FastingSchedule {
    const val NONE = "none"
    const val RAMADAN = "ramadan"
    const val MON_THU = "mon_thu"
    const val DAWUD = "dawud"
    const val SHAWWAL = "shawwal"

    fun isFastingDay(context: Context, date: LocalDate, prefs: PrayerPrefs = PrayerPrefs(context)): Boolean {
        return when (prefs.fastingType) {
            RAMADAN -> hijri(date).second == 8
            MON_THU -> date.dayOfWeek.value == 1 || date.dayOfWeek.value == 4
            DAWUD -> {
                val start = runCatching { LocalDate.parse(prefs.dawudStartDate) }.getOrNull() ?: return false
                val distance = ChronoUnit.DAYS.between(start, date)
                distance >= 0 && distance % 2L == 0L
            }
            SHAWWAL -> date.toString() in prefs.shawwalSelectedDates
            else -> false
        }
    }

    /** Tahun Hijriah, bulan 0-based, dan tanggal berdasarkan kalender ICU perangkat. */
    fun hijri(date: LocalDate): Triple<Int, Int, Int> {
        val gregorian = Calendar.getInstance(TimeZone.getDefault()).apply {
            set(date.year, date.monthValue - 1, date.dayOfMonth, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val islamic = IslamicCalendar(TimeZone.getDefault()).apply { timeInMillis = gregorian.timeInMillis }
        return Triple(islamic.get(Calendar.YEAR), islamic.get(Calendar.MONTH), islamic.get(Calendar.DAY_OF_MONTH))
    }

    fun upcomingShawwalYear(today: LocalDate = LocalDate.now()): Int {
        val (year, month, _) = hijri(today)
        return if (month <= 9) year else year + 1
    }

    /** Tanggal Masehi untuk tanggal-tanggal Syawal dalam tahun Hijriah yang diminta. */
    fun shawwalDates(year: Int): List<Pair<Int, LocalDate>> {
        val result = mutableListOf<Pair<Int, LocalDate>>()
        for (day in 1..30) {
            val islamic = IslamicCalendar(TimeZone.getDefault()).apply {
                clear()
                set(Calendar.YEAR, year)
                set(Calendar.MONTH, 9) // Syawal, bulan ke-10; indeks dimulai dari nol.
                set(Calendar.DAY_OF_MONTH, day)
                set(Calendar.HOUR_OF_DAY, 12)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            // Abaikan tanggal 30 bila bulan Syawal pada kalender perangkat hanya 29 hari.
            if (islamic.get(Calendar.YEAR) != year || islamic.get(Calendar.MONTH) != 9 || islamic.get(Calendar.DAY_OF_MONTH) != day) continue
            val g = Calendar.getInstance(TimeZone.getDefault()).apply { timeInMillis = islamic.timeInMillis }
            val date = LocalDate.of(g.get(Calendar.YEAR), g.get(Calendar.MONTH) + 1, g.get(Calendar.DAY_OF_MONTH))
            result.add(day to date)
        }
        return result
    }

    fun typeLabel(type: String, language: Int): String {
        val labels = when (type) {
            RAMADAN -> arrayOf("puasa Ramadan", "Ramadan fasting", "رمضان", "siyam Ramadhan")
            MON_THU -> arrayOf("puasa sunah Senin dan Kamis", "Monday and Thursday Sunnah fasting", "الاثنين والخميس", "siyam sunah Senen Kemis")
            DAWUD -> arrayOf("puasa sunah Nabi Dawud", "Prophet Dawud's alternating fast", "داود", "siyam sunah Nabi Dawud")
            SHAWWAL -> arrayOf("puasa sunah Syawal", "Shawwal Sunnah fasting", "شوال", "siyam sunah wulan Syawal")
            else -> arrayOf("puasa", "fasting", "الصيام", "siyam")
        }
        return labels[language.coerceIn(0, 3)]
    }

    fun sahurMessage(type: String, minutes: Int, language: Int, test: Boolean = false): String {
        val label = typeLabel(type, language)
        return when (language.coerceIn(0, 3)) {
            1 -> (if (test) "Sahur reminder test for " else "Sahur reminder for ") + label + ". Imsak is in $minutes minutes."
            2 -> (if (test) "اختبار تنبيه السحور لصيام " else "تنبيه السحور لصيام ") + label + ". بقي $minutes دقيقة على الإمساك."
            3 -> (if (test) "Tes pènget wekdal sahur kanggé " else "Pènget wekdal sahur kanggé ") + label + ". Wekdal imsak kirang langkung $minutes menit malih."
            else -> (if (test) "Tes suara pengingat sahur untuk " else "Waktu sahur untuk ") + label + ". Waktu Imsak tinggal $minutes menit lagi."
        }
    }

    fun berbukaMessage(type: String, offset: Int, language: Int, test: Boolean = false): String {
        val label = typeLabel(type, language)
        val timing = when {
            offset < 0 -> if (language == 1) "${-offset} minutes before Maghrib" else if (language == 2) "قبل المغرب بـ ${-offset} دقيقة" else if (language == 3) "${-offset} menit sadèrèngipun Maghrib" else "${-offset} menit sebelum Maghrib"
            offset > 0 -> if (language == 1) "$offset minutes after Maghrib" else if (language == 2) "بعد المغرب بـ $offset دقيقة" else if (language == 3) "$offset menit sasampunipun Maghrib" else "$offset menit setelah Maghrib"
            else -> if (language == 1) "at Maghrib" else if (language == 2) "عند المغرب" else if (language == 3) "pas wekdal Maghrib" else "tepat saat Maghrib"
        }
        return when (language.coerceIn(0, 3)) {
            1 -> (if (test) "Iftar reminder test for " else "Iftar reminder for ") + label + ": $timing."
            2 -> (if (test) "اختبار تنبيه الإفطار لصيام " else "تنبيه الإفطار لصيام ") + label + ": $timing."
            3 -> (if (test) "Tes pènget buka puasa kanggé " else "Pènget buka puasa kanggé ") + label + ": $timing."
            else -> (if (test) "Tes pengingat berbuka puasa untuk " else "Pengingat berbuka puasa untuk ") + label + ": $timing."
        }
    }
}
