package com.novan.bateraibicara

import android.app.AlertDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.ContentValues
import android.os.Environment
import android.media.MediaScannerConnection
import android.provider.Settings
import android.provider.MediaStore
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.UUID
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pembaca Al-Qur'an dan pendamping khatam. Teks/terjemahan disimpan di perangkat setelah diunduh. */
class KhatamActivity : Halaman() {
    override val judulHalaman = R.string.khatam_judul
    private val handler = Handler(Looper.getMainLooper())
    private val dataPrefs by lazy { getSharedPreferences("khatam_quran", MODE_PRIVATE) }
    private var quran: JSONObject? = null
    private var terjemahan: JSONObject? = null
    private var nomorSurah = 1
    private var nomorAyat = 1
    private var tampilkanArti = true
    private var ukuranArab = 28f
    private var pemutar: PemutarAudio? = null
    private var keluaranMono = false
    private var equalizerAudio: Equalizer? = null
    private var statusEqualizer = ""
    private var speechRecognizerHafalan: SpeechRecognizer? = null
    private var dialogKoreksiHafalan: AlertDialog? = null
    private var statusKoreksiHafalan: TextView? = null
    private var ttsTerjemahan: TextToSpeech? = null
    private var ttsSiap = false
    private var modePemutaranAudio = "arab" // arab, terjemahan (file audio terjemahan Indonesia per surah)
    private var audioTerjemahanAktif = false // true selama berkas audio terjemahan yang sedang dimuat/diputar

    /**
     * FIX72: audio terjemahan Indonesia berupa BERKAS rekaman suara (bukan suara mesin TTS).
     * Sumber: item Internet Archive "quraninindonesia" (114 berkas MP3, satu per surah, nama berkas
     * NNN + nama surah). Rekaman hanya tersedia per surah penuh; tidak ada data per ayat/juz/halaman.
     * Bila daftar ini kosong, pilihan "Arab / terjemahan" otomatis hilang dari daftar pengaturan audio.
     */
    private val URL_DASAR_TERJEMAHAN_ID = "https://archive.org/download/quraninindonesia/"
    private val daftarBerkasTerjemahanId: List<String> = listOf(
        "AlFaatihah", "AlBaqarah", "AliImran", "AnNisaa", "AlMaaidah", "AlAnaam",
        "AlAaraaf", "AlAnfaal", "AtTaubah", "Yunus", "Huud", "Yusuf",
        "ArRaad", "Ibrahim", "AlHijr", "AnNahl", "AlIsraa", "AlKahfi",
        "Maryam", "Thaahaa2", "AlAnbiyaa", "AlHajj", "AlMuminuun", "AnNuur",
        "AlFurqaan", "AsySyuaaraa", "AnNaml", "AlQashash", "AlAnkabuut", "ArRuum",
        "Luqman", "AsSajdah", "AlAhzab", "Sabaa", "Faathir", "Yaasiin",
        "AshShaaffaat", "Shaad", "AzZumar", "AlMuumin", "Fushshilat", "AsySyuura",
        "AzZukhruf", "AdDukhaan", "AlJaatsiyah", "AlAhqaaf", "Muhammad", "AlFath",
        "AlHujuraat", "Qaaf", "AdzDzaariyaat", "AthThuur", "AnNajm", "AlQamar",
        "ArRahmaan", "AlWaqiah", "AlHadiid", "AlMujaadilah", "AlHasyr", "AlMumtahanah",
        "AshShaff", "AlJumuah", "AlMunaafiquun", "AtTaghaabun", "AthThalaaq", "AtTahrim",
        "AlMulk", "AlQalam", "AlHaaqqah", "AlMaaarij", "Nuh", "AlJin",
        "AlMuzzammil", "AlMuddatstsir", "AlQiyaamah", "AlInsaan", "AlMursalaat", "AnNaba",
        "AnNaaziaat", "Abasa", "AtTakwiir", "AlInfithaar", "AlMuthaffifin", "AlInsyiqaaq",
        "AlBuruuj", "AthThaariq", "AlAalaa", "AlGhaasyiyah", "AlFajr", "AlBalad",
        "AsySyams", "AlLail", "AdhDhuhaa", "AlamNasyrah", "AtTiin", "AlAlaq",
        "AlQadr", "AlBayyinah", "AlZalzalah", "AlAadiyaat", "AlQaariah", "AtTakaatsur",
        "AlAshr", "AlHumazah", "AlFiil", "Quraisy", "AlMaauun", "AlKautsar",
        "AlKaafiruun", "AnNashr", "AlLahab", "AlIkhlash", "AlFalaq", "AnNaas"
    )

    private fun urlAudioTerjemahanId(surah: Int): String? {
        val nama = daftarBerkasTerjemahanId.getOrNull(surah - 1) ?: return null
        return URL_DASAR_TERJEMAHAN_ID + String.format(Locale.ROOT, "%03d", surah) + nama + ".mp3"
    }
    private var presetEqualizer = "normal" // normal, vocal, bass, treble, kustom
    private var latihanHafalanAktif = false
    private var audioSiap = false
    private var audioGenerasi = 0
    private var tombolStatusAudio: TextView? = null
    private var tombolJedaAudio: android.widget.Button? = null
    private var teksKecepatanAudio: TextView? = null
    private var infoQari: TextView? = null
    private var infoModeAudio: TextView? = null
    private var sedangDiPembaca = false
    private var qariId: String = "ar.alafasy"
    // Katalog dipisah berdasarkan kemampuan audio agar qari audio per surah
    // tidak memenuhi daftar qari yang memang mendukung pemutaran per ayat.
    private val daftarQari = mutableListOf(
        "ar.alafasy" to "Mishary Rashid Alafasy · merdu dan jelas",
        "ar.husary" to "Mahmoud Khalil Al-Husary · tartil dan tajwid",
        "ar.minshawi" to "Mohamed Siddiq Al-Minshawi · tartil",
        "ar.abdurrahmaansudais" to "Abdurrahman As-Sudais",
        "ar.saoodshuraym" to "Saud Al-Shuraim",
        "ar.abdulbasitmurattal" to "Abdul Basit Abdus Samad · murattal",
        "ar.ahmedajamy" to "Ahmed ibn Ali Al-Ajamy",
        "ar.muhammadayyoub" to "Muhammad Ayyoub",
        "ar.hudhaify" to "Ali Al-Hudhaify",
        "ar.shaatree" to "Abu Bakr Ash-Shaatree",
        "ar.mahermuaiqly" to "Maher Al-Muaiqly",
        "ar.yasseraldosari" to "Yasser Al-Dosari",
        "ar.nasserqatami" to "Nasser Al-Qatami",
        "ar.hanirifai" to "Hani Ar-Rifai",
        // FIX62: tambahan qari terbaik pada katalog audio per ayat (edisi resmi alquran.cloud).
        "ar.husarymujawwad" to "Mahmoud Khalil Al-Husary · mujawwad",
        "ar.minshawimujawwad" to "Mohamed Siddiq Al-Minshawi · mujawwad",
        "ar.muhammadjibreel" to "Muhammad Jibreel",
        "ar.abdullahbasfar" to "Abdullah Basfar",
        "ar.ibrahimakhbar" to "Ibrahim Al-Akhdar",
        "ar.aymanswoaid" to "Ayman Sowaid",
        "ar.abdulsamad" to "Abdul Basit Abdus Samad · mujawwad",
        "ar.parhizgar" to "Shahriar Parhizgar"
    )
    private val daftarQariPerSurah = mutableListOf<Pair<String, String>>()
    private var katalogQariSedangDimuat = false
    private var katalogQariSudahDimuat = false
    private var audioSedangJuz = false
    private var audioGlobalSaatIni = 1
    private var audioGlobalAkhir = 1
    private var juzAktif = 1
    private var halamanAktif = 1
    private var audioRentangLabel = ""
    private var dialogUnduh: AlertDialog? = null
    private var status: TextView? = null
    private var ayatArab: TextView? = null
    private var ayatArti: TextView? = null
    private var teksReferensi: TextView? = null
    private var tombolAudio: android.widget.Button? = null
    private var tombolAudioAyat: android.widget.Button? = null
    private var tombolAudioAktif: android.widget.Button? = null
    private var tombolTandaiAyat: android.widget.Button? = null
    // Pengulangan murattal ayat: 1–10 kali, atau 0 untuk terus mengulang.
    private var pengulanganAyat = 1
    private var sisaPengulanganAyat = 1
    // FIX77: hafalan per kelompok ayat. Pengguna menentukan sendiri jumlah ayat per kelompok dan jumlah pengulangan kelompok.
    private var ayatPerKelompok = 3
    private var ulangKelompok = 3 // 0 = terus-menerus
    private var lanjutKelompok = true
    private var tombolKoreksiSuaraMenu: Button? = null
    private var tombolPerintahSuaraMenu: Button? = null
    private var tombolLatihanMandiriMenu: Button? = null
    private var kelompokAwalGlobal = 0
    private var kelompokAkhirGlobal = 0
    private var sisaUlangKelompok = 1
    private var putaranKelompok = 1
    private var audioSedangAyat = false
    private var urlAudioAyatAktif = ""
    private var pesanAudioAyatAktif = ""
    private var kecepatanAudio = 1.0f
    // Mode hafalan: biasa, ayat (ulang ayat aktif), berurutan (ulang lalu lanjut ayat berikutnya).
    private var modeHafalan = "biasa"
    private var targetPemutaran = "ayat"
    private var jedaAntarAyatDetik = 2

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun onCreate(savedInstanceState: Bundle?) {
        // Perintah suara dari layar depan menjalankan pemutar secara senyap di balik layar.
        // Tema transparan dipasang sebelum Activity dibuat agar jendela aplikasi tidak sempat tampil.
        val pemutaranDariLayarDepan = intent?.getBooleanExtra(EXTRA_KEMBALI_KE_LAYAR_DEPAN, false) == true
        if (pemutaranDariLayarDepan) setTheme(R.style.AudioBackgroundTheme)
        super.onCreate(savedInstanceState)
        if (pemutaranDariLayarDepan) sembunyikanJendelaPemutarLatar()
        nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1, 114)
        nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        tampilkanArti = dataPrefs.getBoolean("tampilkan_terjemahan", true)
        ukuranArab = dataPrefs.getFloat("ukuran_arab", 28f).coerceIn(22f, 42f)
        qariId = dataPrefs.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        // Pengenal lama yang tidak ada di CDN dipetakan ke pengenal yang benar agar pilihan pengguna tetap terjaga.
        qariId = when (qariId) {
            "ar.sudais" -> "ar.abdurrahmaansudais"
            "ar.shuraim" -> "ar.saoodshuraym"
            "ar.abdulbasit" -> "ar.abdulbasitmurattal"
            "ar.ajamy" -> "ar.ahmedajamy"
            "ar.muhammadayoub" -> "ar.muhammadayyoub"
            else -> qariId
        }
        if (daftarQari.none { it.first == qariId } && !qariId.startsWith("mp3quran|") && !qariId.startsWith("ar.")) qariId = "ar.alafasy"
        dataPrefs.edit().putString("qari_audio_id", qariId).apply()
        keluaranMono = dataPrefs.getString("keluaran_suara_audio", "stereo") == "mono"
        pengulanganAyat = dataPrefs.getInt("pengulangan_audio_ayat", 1).let { if (it in 0..10) it else 1 }
        kecepatanAudio = dataPrefs.getFloat("kecepatan_audio", 1.0f).let { if (it in listOf(0.75f, 1.0f, 1.25f, 1.5f)) it else 1.0f }
        modeHafalan = dataPrefs.getString("mode_hafalan_audio", "biasa")?.takeIf { it in listOf("biasa", "ayat", "berurutan", "kelompok") } ?: "biasa"
        ayatPerKelompok = dataPrefs.getInt("hafalan_ayat_per_kelompok", 3).coerceIn(1, 100)
        ulangKelompok = dataPrefs.getInt("hafalan_ulang_kelompok", 3).coerceIn(0, 99)
        lanjutKelompok = dataPrefs.getBoolean("hafalan_lanjut_kelompok", true)
        targetPemutaran = dataPrefs.getString("target_pemutaran_audio", "ayat")?.takeIf { it in listOf("ayat", "surah", "juz", "halaman") } ?: "ayat"
        jedaAntarAyatDetik = dataPrefs.getInt("jeda_antar_ayat_detik", 2).let { if (it in listOf(0, 2, 5, 10)) it else 2 }
        senyapTalkBackPergantian = dataPrefs.getBoolean("senyap_talkback_pergantian_audio", false)
        modePemutaranAudio = if (dataPrefs.getString("mode_pemutaran_audio", "arab") == "terjemahan" && daftarBerkasTerjemahanId.isNotEmpty()) "terjemahan" else "arab"
        presetEqualizer = dataPrefs.getString("preset_equalizer_audio", "normal")?.takeIf { kunciPresetSah(it) } ?: "normal"
        ttsTerjemahan = TextToSpeech(this) { status ->
            ttsSiap = status == TextToSpeech.SUCCESS
            if (ttsSiap) {
                val locale = if (BahasaAplikasi.tampilan(this) == 1) Locale.US else Locale("id", "ID")
                val hasilBahasa = ttsTerjemahan?.setLanguage(locale)
                if (hasilBahasa == TextToSpeech.LANG_MISSING_DATA || hasilBahasa == TextToSpeech.LANG_NOT_SUPPORTED) {
                    ttsSiap = false
                }
            }
        }
        instance = this
        muatCache()
        jalankanPerintahDariLuar()
    }

    /** FIX84: Khatam singleTask; perintah putar dari Beritahu Saya tiba lewat intent baru. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_KEMBALI_KE_LAYAR_DEPAN, false)) {
            sembunyikanJendelaPemutarLatar()
        }
        jalankanPerintahDariLuar()
    }

    /**
     * Menjaga pemutar tetap berjalan tanpa menampilkan halaman Khatam.
     * Jendela dibuat transparan dan seluruh konten disembunyikan; pengguna tetap melihat
     * layar depan/perangkat, sementara AudioLatarService menjaga sesi audio.
     */
    private fun sembunyikanJendelaPemutarLatar() {
        try {
            root.visibility = View.INVISIBLE
            window.setBackgroundDrawableResource(android.R.color.transparent)
            val atribut = window.attributes
            atribut.alpha = 0f
            window.attributes = atribut
        } catch (_: Exception) { }
    }

    private fun jalankanPerintahDariLuar() {
        if (intent?.getBooleanExtra(HafalanSrs.EXTRA_BUKA_ULASAN, false) == true) {
            intent?.removeExtra(HafalanSrs.EXTRA_BUKA_ULASAN)
            handler.postDelayed({ if (!isFinishing) dialogUlasHafalan() }, 400L)
        }
        val kandidat = intent?.getStringArrayListExtra(EXTRA_PERINTAH_SUARA) ?: return
        // FIX87: perintah dari layar depan/widget/pintasan tidak boleh "menyeret" pengguna ke dalam aplikasi.
        val kembali = intent?.getBooleanExtra(EXTRA_KEMBALI_KE_LAYAR_DEPAN, false) ?: false
        intent?.removeExtra(EXTRA_PERINTAH_SUARA)
        intent?.removeExtra(EXTRA_KEMBALI_KE_LAYAR_DEPAN)
        if (kembali) { try { overridePendingTransition(0, 0) } catch (_: Exception) { } }
        handler.postDelayed({
            if (isFinishing) return@postDelayed
            if (!dataPrefs.getBoolean("perintah_suara_putar_aktif", true)) {
                toast(tr("Perintah suara untuk memutar dinonaktifkan. Aktifkan di Pengaturan Pemutaran Audio.", "Voice command for playback is turned off. Turn it on in Audio Playback Settings."))
                if (kembali) kembaliKeLayarDepan()
                return@postDelayed
            }
            if (quran == null) {
                muatCache()
                val hanyaQari = kandidat.any { u -> pisahPerintahQari(u)?.let { sisaHanyaPengisi(it.second) } == true }
                if (quran == null && !hanyaQari) {
                    if (kembali) {
                        toast(tr("Teks Al-Qur'an belum diunduh. Buka Khatam di aplikasi untuk mengunduhnya, lalu ulangi perintah suara.", "The Quran text has not been downloaded yet. Open Khatam in the app to download it, then repeat the voice command."))
                        kembaliKeLayarDepan()
                    } else dialogBelumAdaTeks()
                    return@postDelayed
                }
            }
            prosesPerintahSuaraPutar(kandidat)
            if (kembali) kembaliKeLayarDepan()
        }, if (kembali) 150L else 600L)
    }

    /**
     * FIX87: audio sudah dimulai (atau perintah tidak dapat dijalankan); kembalikan pengguna ke layar depan.
     * Audio terus diputar di latar belakang dan dijaga AudioLatarService. Memakai decorView.postDelayed (bukan handler)
     * karena hentikanAudio() membersihkan semua pesan handler.
     */
    private fun kembaliKeLayarDepan() {
        if (audioMasihBerjalan()) AudioLatarService.mulai(this)
        window.decorView.postDelayed({ if (!isFinishing) moveTaskToBack(true) }, 300L)
    }

    /** Ada pemutaran yang sedang menyambung atau berbunyi. */
    private fun audioMasihBerjalan(): Boolean {
        val p = pemutar ?: return false
        return !audioSiap || try { p.isPlaying } catch (_: Exception) { false }
    }

    companion object {
        const val EXTRA_PERINTAH_SUARA = "perintah_suara_kandidat"
        /** FIX87: true bila perintah suara datang dari luar aplikasi sehingga pengguna dikembalikan ke layar depan. */
        const val EXTRA_KEMBALI_KE_LAYAR_DEPAN = "perintah_suara_kembali_layar_depan"

        @Volatile
        private var instance: KhatamActivity? = null

        /** Dipakai AudioLatarService untuk mengetahui apakah audio masih berjalan. */
        fun sedangMemutarLatar(): Boolean = instance?.audioMasihBerjalan() ?: false

        /** Dipakai tombol "Hentikan audio" pada notifikasi AudioLatarService. */
        fun hentikanLatar() {
            val a = instance ?: return
            a.runOnUiThread { try { a.hentikanAudio() } catch (_: Exception) { } }
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        try { pemutar?.stop() } catch (_: Exception) { }
        try { pemutar?.release() } catch (_: Exception) { }
        pemutar = null
        lepasEfekAudio()
        try { speechRecognizerHafalan?.destroy() } catch (_: Exception) { }
        speechRecognizerHafalan = null
        try { dialogKoreksiHafalan?.dismiss() } catch (_: Exception) { }
        try { ttsTerjemahan?.stop(); ttsTerjemahan?.shutdown() } catch (_: Exception) { }
        ttsTerjemahan = null
        try { dialogUnduh?.dismiss() } catch (_: Exception) { }
        super.onDestroy()
    }


    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (sedangDiPembaca) {
            hentikanAudio()
            bangunMenuLagi()
        } else {
            super.onBackPressed()
        }
    }

    override fun bangun() {
        sedangDiPembaca = false
        bagian(tr("Khatam Al-Qur'an", "Qur'an Completion"), 24f)
        info(tr(
            "Pembaca Al-Qur'an yang ramah pembaca layar. Teks Arab dan terjemahan dapat disimpan di perangkat agar bisa dibaca tanpa internet setelah diunduh. Kemajuan bacaan tersimpan di perangkat ini.",
            "A screen-reader-friendly Qur'an reader. Arabic text and translation can be saved on this device for offline reading after download. Reading progress is stored on this device."
        ))
        status = info(tr("Memeriksa teks Al-Qur'an yang tersimpan…", "Checking saved Qur'an text…"))
        info(ringkasanKemajuan())
        bagian(tr("BACAAN DAN NAVIGASI", "READING AND NAVIGATION"))
        tombol(tr("Lanjutkan bacaan terakhir", "Resume last reading")) { bukaAyatTersimpan() }
        tombol(tr("Baca Al-Qur'an / pilih surah", "Read Qur'an / choose surah")) { pilihSurah() }
        tombol(tr("Pilih juz untuk membaca", "Choose juz to read")) { pilihJuz() }
        bagian(tr("LATIHAN HAFALAN", "MEMORIZATION PRACTICE"))
        info(tr(
            "Latihan memakai ayat bacaan terakhir Anda. Ayat akan disembunyikan, lalu Anda membaca dari hafalan.",
            "Practice uses your last reading position. The verse is hidden and you recite from memory."
        ))
        val aktifKoreksiSuara = dataPrefs.getBoolean("hafalan_koreksi_suara_aktif", true)
        val aktifLatihanMandiri = dataPrefs.getBoolean("hafalan_latihan_mandiri_aktif", true)
        val jumlahJatuhTempo = HafalanSrs.jatuhTempo(dataPrefs).size
        if (jumlahJatuhTempo > 0) {
            tombol(tr("Ulas hafalan hari ini (", "Review today's memorization (") + jumlahJatuhTempo + tr(" ayat)", " verses)")) { dialogUlasHafalan() }
        }
        val antreanMenu = HafalanSrs.antreanMurajaah(dataPrefs, HafalanSrs.ukuranSesi(dataPrefs), dataPrefs.getBoolean(HafalanSrs.KEY_PENGUATAN, true))
        if (antreanMenu.isNotEmpty()) {
            val tombolMurajaah = tombol(tr("Muraja'ah cerdas (", "Smart muraja'ah (") + antreanMenu.size + tr(" ayat)", " verses)")) { mulaiMurajaahCerdas() }
            tombolMurajaah.contentDescription = tr("Muraja'ah cerdas. Sesi ulasan terpandu untuk ", "Smart muraja'ah. Guided review session for ") + antreanMenu.size +
                tr(" ayat, dimulai dari yang paling mendesak.", " verses, starting with the most urgent.")
        }
        tombolKoreksiSuaraMenu = tombol(tr("Koreksi otomatis dengan pengenalan suara", "Automatic speech-recognition check")) { mulaiKoreksiOtomatisHafalan() }
        tombolLatihanMandiriMenu = tombol(tr("Latihan hafalan tanpa mikrofon", "Memorization practice without microphone")) { latihanKoreksiHafalan() }
        tombolKoreksiSuaraMenu?.visibility = if (aktifKoreksiSuara) View.VISIBLE else View.GONE
        tombolLatihanMandiriMenu?.visibility = if (aktifLatihanMandiri) View.VISIBLE else View.GONE
        bagian(tr("PENGATURAN", "SETTINGS"))
        infoQari = info(tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari())
        infoModeAudio = info(tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat())
        tombol(tr("Pengaturan Khatam Al-Qur'an", "Qur'an completion settings")) { dialogPengaturanKhatam() }
                bagian(tr("PEMUTARAN AUDIO", "AUDIO PLAYBACK"))
        tombolStatusAudio = info(tr("Audio siap. Pilih Putar untuk memulai murattal.", "Audio is ready. Choose Play to start recitation."))
        bangunKontrolPemutarAudio()
        tombolPerintahSuaraMenu = tombol(tr("Putar dengan perintah suara", "Play by voice command")) { mulaiPerintahSuaraPutar() }
        tombolPerintahSuaraMenu?.visibility = if (dataPrefs.getBoolean("perintah_suara_putar_aktif", true)) View.VISIBLE else View.GONE
        tombolPerintahSuaraMenu?.contentDescription =
            tr("Putar dengan perintah suara. Ketuk, lalu ucapkan, misalnya: putar surah Al Baqarah, atau putar surah 36 ayat 5, atau putar juz 30.",
                "Play by voice command. Tap, then say for example: play surah Al Baqarah, or play surah 36 verse 5, or play juz 30.")
        tombol(tr("Cari juz, surah, atau ayat untuk diputar", "Search a juz, surah, or verse to play")) { dialogCariAudio() }
        tombol(tr("Unduh audio Al-Qur'an", "Download Qur'an audio")) { dialogUnduhAudio() }
        bagian(tr("KELENGKAPAN BACAAN", "READING TOOLS"))
        tombol(tr("Unduh teks lengkap untuk penggunaan offline", "Download complete text for offline use")) { unduhSemuaTeks() }
        tombol(tr("Tandai ayat terakhir yang dibaca", "Mark last reading position")) { tandaiPosisi() }
        bagian(tr("Sumber teks dan audio", "Text and audio sources"))
        info(tr(
            "Teks Arab dan terjemahan diambil melalui Al Quran Cloud API dan disimpan setelah diunduh. Sumber: alquran.cloud; teks Uthmani merujuk pada sumber Al-Qur'an yang dicantumkan penyedia. Audio murattal dapat diputar secara streaming atau diunduh. Audio terjemahan Indonesia (rekaman suara per surah penuh, dipilih di Pengaturan Audio) diputar secara streaming dari Internet Archive, item quraninindonesia, unggahan komunitas. Hasil unduhan audio dan teks disimpan otomatis di folder Jam Pintar Pro pada memori internal HP, subfolder Audio dan Teks.",
            "Arabic text and translation are retrieved through the Al Quran Cloud API and saved after download. Source: alquran.cloud; the Uthmani text refers to the Qur'an source credited by the provider. Murattal audio can be streamed and downloaded for personal use. Indonesian translation audio (whole-surah voice recordings, chosen in Audio Settings) is streamed from the Internet Archive item quraninindonesia, a community upload. Downloaded audio and text are saved automatically in the Jam Pintar Pro folder in the phone's internal storage, in the Audio and Text subfolders. Juz audio is saved as individual verse MP3 files."
        ))
    
        tombolResetPengaturan(tr("Khatam Al-Qur'an", "Qur'an completion")) {
                    val kunciPengaturan = setOf(
                        "efek_bass_persen", "efek_penguat_db", "efek_spasial_persen",
                        "hafalan_ayat_per_kelompok", "hafalan_srs_pengingat", "hafalan_srs_jam", "hafalan_srs_menit", "murajaah_ukuran_sesi", "murajaah_penguatan_aktif", "perintah_suara_putar_aktif", "hafalan_audio_koreksi_aktif", "hafalan_koreksi_cerdas_aktif", "hafalan_koreksi_suara_aktif", "hafalan_latihan_mandiri_aktif",
                        "hafalan_lanjut_kelompok", "hafalan_ulang_kelompok",
                        "jeda_antar_ayat_detik", "kecepatan_audio", "keluaran_suara_audio",
                        "mode_hafalan_audio", "mode_pemutaran_audio", "pengingat_aktif",
                        "pengingat_jam", "pengingat_menit", "pengulangan_audio_ayat",
                        "preset_equalizer_audio", "qari_audio_id", "qari_audio_nama",
                        "qari_cadangan_server", "senyap_talkback_pergantian_audio",
                        "tampilkan_terjemahan", "target_hari", "target_mulai",
                        "target_pemutaran_audio", "ukuran_arab"
                    )
                    val editor = dataPrefs.edit()
                    kunciPengaturan.forEach { editor.remove(it) }
                    editor.apply()
                }
}

    private fun cacheFile(name: String) = File(filesDir, name)

    /** Tulis cache lewat berkas sementara agar unduhan yang terputus tidak merusak cache lama. */
    private fun tulisCacheAtomik(name: String, content: String) {
        val target = cacheFile(name)
        val temporary = File(filesDir, ("" + (name) + ".tmp"))
        val backup = File(filesDir, ("" + (name) + ".bak"))
        temporary.writeText(content, Charsets.UTF_8)
        if (backup.exists()) backup.delete()
        val hadOld = target.exists()
        if (hadOld && !target.renameTo(backup)) {
            temporary.delete()
            throw IllegalStateException(tr("Tidak dapat mencadangkan cache ", "Cannot back up cache ") + name)
        }
        if (!temporary.renameTo(target)) {
            if (hadOld) backup.renameTo(target)
            temporary.delete()
            throw IllegalStateException(tr("Tidak dapat menyimpan cache ", "Cannot save cache ") + name)
        }
        backup.delete()
    }

    private fun muatCache() {
        try {
            if (cacheFile("quran_ar.json").exists()) quran = JSONObject(cacheFile("quran_ar.json").readText(Charsets.UTF_8))
            val activeCache = if (BahasaAplikasi.tampilan(this) == 1) cacheFile("quran_en.json") else cacheFile("quran_id.json")
            if (activeCache.exists()) terjemahan = JSONObject(activeCache.readText(Charsets.UTF_8)) else terjemahan = null
            status?.text = if (quran != null) tr("Teks Arab tersedia di perangkat.", "Arabic text is available on this device.") else tr("Teks belum diunduh. Hubungkan internet lalu pilih unduh teks lengkap.", "Text is not downloaded yet. Connect to the internet and choose download complete text.")
        } catch (_: Exception) {
            quran = null; terjemahan = null
            status?.text = tr("Cache teks perlu diunduh ulang.", "Text cache needs to be downloaded again.")
        }
    }

    private fun fetch(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection)
        connection.connectTimeout = 20000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException(("HTTP " + (code)))
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { connection.disconnect() }
    }

    private fun unduhSemuaTeks(setelah: (() -> Unit)? = null) = pastikanIzinFolder(setelah) { unduhSemuaTeksSekarang(setelah) }

    private fun unduhSemuaTeksSekarang(setelah: (() -> Unit)? = null) {
        val progress = android.app.ProgressDialog(this)
        progress.setTitle(tr("Mengunduh teks Al-Qur'an", "Downloading Qur'an text"))
        progress.setMessage(tr("Mengunduh teks Arab serta terjemahan Indonesia dan Inggris agar pilihan bahasa tetap bisa dibaca offline. Mohon tunggu.", "Downloading Arabic text and both Indonesian and English translations so either app language works offline. Please wait."))
        progress.setCancelable(false)
        progress.show()
        dialogUnduh = progress
        Thread {
            try {
                val ar = fetch("https://api.alquran.cloud/v1/quran/quran-uthmani")
                val id = fetch("https://api.alquran.cloud/v1/quran/id.indonesian")
                val en = fetch("https://api.alquran.cloud/v1/quran/en.sahih")
                val arObj = JSONObject(ar); val idObj = JSONObject(id); val enObj = JSONObject(en)
                fun validasi(obj: JSONObject, label: String) {
                    val surahs = obj.optJSONObject("data")?.optJSONArray("surahs")
                    if (surahs?.length() != 114) throw IllegalStateException(tr("Jumlah surah " + label + " tidak lengkap", "Surah count for " + label + " is incomplete"))
                    var count = 0
                    for (i in 0 until 114) count += surahs!!.optJSONObject(i)?.optJSONArray("ayahs")?.length() ?: 0
                    if (count != 6236) throw IllegalStateException(tr("Jumlah ayat " + label + " tidak sesuai 6236", "Verse count for " + label + " does not match 6236"))
                }
                validasi(arObj, tr("Arab", "Arabic")); validasi(idObj, tr("terjemahan Indonesia", "Indonesian translation")); validasi(enObj, tr("terjemahan Inggris", "English translation"))
                tulisCacheAtomik("quran_ar.json", ar)
                tulisCacheAtomik("quran_id.json", id)
                tulisCacheAtomik("quran_en.json", en)
                val active = if (BahasaAplikasi.tampilan(this) == 1) enObj else idObj
                tulisCacheAtomik("quran_active_translation.json", active.toString())
                // Salinan berkas di folder "Jam Pintar Pro" pada memori internal. Kegagalan di sini tidak membatalkan unduhan.
                val lokasiSalinan: String? = try {
                    simpanKePenyimpananPublik("Teks", "Al-Quran-Arab-Uthmani.json", "application/json") { it.write(ar.toByteArray(Charsets.UTF_8)) }
                    simpanKePenyimpananPublik("Teks", "Al-Quran-Terjemahan-Indonesia.json", "application/json") { it.write(id.toByteArray(Charsets.UTF_8)) }
                    simpanKePenyimpananPublik("Teks", "Al-Quran-Terjemahan-Inggris.json", "application/json") { it.write(en.toByteArray(Charsets.UTF_8)) }
                } catch (_: Exception) { null }
                runOnUiThread {
                    quran = arObj; terjemahan = active
                    status?.text = tr("Teks Arab serta terjemahan Indonesia dan Inggris tersimpan di perangkat dan siap dibaca offline.", "Arabic text and Indonesian and English translations are saved on this device and ready for offline reading.")
                    progress.dismiss(); dialogUnduh = null
                    toast(if (lokasiSalinan != null)
                        tr("Unduhan selesai. Teks tersimpan di folder: ", "Download complete. Text saved in folder: ") + lokasiSalinan
                    else
                        tr("Unduhan selesai dan teks siap dibaca offline, tetapi salinan ke folder Jam Pintar Pro gagal dibuat.", "Download complete and text is ready offline, but the copy in the Jam Pintar Pro folder could not be created."))
                    setelah?.invoke()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss(); dialogUnduh = null
                    toast(tr("Unduhan gagal. Periksa koneksi internet lalu coba lagi. Detail: ", "Download failed. Check your internet connection and try again. Details: ") + (e.message ?: ""))
                    setelah?.invoke()
                }
            }
        }.start()
    }

    private fun daftarSurah(): org.json.JSONArray? = quran?.optJSONObject("data")?.optJSONArray("surahs")

    private fun pilihSurah() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val surahs = daftarSurah() ?: return
        val labels = (0 until surahs.length()).map { i ->
            val s = surahs.getJSONObject(i)
            val namaTampil = if (BahasaAplikasi.tampilan(this) == 1) s.optString("englishName") else s.optString("name")
            ("" + (s.optInt("number")) + ". " + namaTampil + " (" + (s.optInt("numberOfAyahs")) + " " + (tr("ayat", "verses")) + ")")
        }
        AlertDialog.Builder(this).setTitle(tr("Pilih surah", "Choose a surah"))
            .setItems(labels.toTypedArray()) { _, index -> nomorSurah = index + 1; nomorAyat = 1; tampilkanPembaca() }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihJuz() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val juz = (1..30).map { ("" + (tr("Juz", "Juz")) + " " + (it)) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz", "Choose a juz")).setItems(juz) { _, which ->
            val target = which + 1
            val surahs = daftarSurah() ?: return@setItems
            var foundS = 1; var foundA = 1
            loop@ for (i in 0 until surahs.length()) {
                val verses = surahs.getJSONObject(i).optJSONArray("ayahs") ?: continue
                for (j in 0 until verses.length()) {
                    val a = verses.getJSONObject(j)
                    if (a.optInt("juz") == target) { foundS = i + 1; foundA = a.optInt("numberInSurah", 1); break@loop }
                }
            }
            nomorSurah = foundS; nomorAyat = foundA; tampilkanPembaca()
        }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihAyat() {
        val maxAyat = getSurah(nomorSurah)?.optJSONArray("ayahs")?.length() ?: 0
        if (maxAyat <= 0) { toast(tr("Data ayat surah ini belum tersedia.", "Verse data for this surah is not available.")); return }
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        input.hint = tr("Nomor ayat 1 sampai ", "Verse number from 1 to ") + maxAyat
        input.contentDescription = input.hint
        input.setText(nomorAyat.toString())
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih ayat dalam surah ini", "Choose a verse in this surah"))
            .setMessage(tr("Masukkan nomor ayat antara 1 dan ", "Enter a verse number between 1 and ") + maxAyat)
            .setView(input)
            .setPositiveButton(tr("Buka ayat", "Open verse")) { _, _ ->
                val selected = input.text.toString().trim().toIntOrNull()
                if (selected != null && selected in 1..maxAyat) {
                    nomorAyat = selected
                    tampilkanPembaca()
                } else {
                    toast(tr("Nomor ayat tidak valid. Silakan masukkan angka 1 sampai ", "Invalid verse number. Enter a number from 1 to ") + maxAyat)
                }
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    private fun bukaAyatTersimpan() {
        nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1,114)
        nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return }
        tampilkanPembaca()
    }

    private fun dialogBelumAdaTeks() {
        AlertDialog.Builder(this).setTitle(tr("Teks belum tersedia", "Text not available"))
            .setMessage(tr("Untuk membaca offline, unduh dulu teks lengkap ketika tersambung ke internet.", "To read offline, first download the complete text while connected to the internet."))
            .setPositiveButton(tr("Unduh sekarang", "Download now")) { _, _ -> unduhSemuaTeks() }
            .setNegativeButton(tr("Nanti", "Later"), null).show()
    }

    private fun getSurah(n: Int): JSONObject? = daftarSurah()?.optJSONObject(n - 1)
    private fun getAyat(surah: Int, ayah: Int): JSONObject? = getSurah(surah)?.optJSONArray("ayahs")?.let { arr -> if (ayah in 1..arr.length()) arr.optJSONObject(ayah - 1) else null }

    private fun tampilkanPembaca() {
        val surah = getSurah(nomorSurah)
        if (surah == null) { dialogBelumAdaTeks(); return }
        val verses = surah.optJSONArray("ayahs") ?: return
        nomorAyat = nomorAyat.coerceIn(1, verses.length())
        // Simpan penanda terakhir tanpa menganggap ayat sudah selesai dibaca.
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        root.removeAllViews()
        sedangDiPembaca = true
        tombol(tr("Kembali ke menu khatam", "Back to Khatam menu")) { hentikanAudio(); bangunMenuLagi() }
        bagian(tr("Pembaca Al-Qur'an", "Qur'an reader"), 24f)
        val namaSurahTampil = if (BahasaAplikasi.tampilan(this) == 1) surah.optString("englishName") else surah.optString("name")
        info(namaSurahTampil)
        info(tr("Surah", "Surah") + (" " + (nomorSurah) + ", ") + tr("ayat", "verse") + (" " + (nomorAyat) + " / " + (verses.length())))
        val a = getAyat(nomorSurah, nomorAyat) ?: return
        val ar = TextView(this)
        ar.text = teksArabTampil(a.optString("text"))
        ar.textSize = ukuranArab
        ar.gravity = Gravity.CENTER
        ar.textDirection = android.view.View.TEXT_DIRECTION_RTL
        ar.setTextColor(warnaTeks())
        ar.setPadding(dp(12), dp(24), dp(12), dp(24))
        ar.contentDescription = tr("Teks Arab ayat", "Arabic verse text") + (" " + (nomorSurah) + ":" + (nomorAyat) + ". ") + teksArabTampil(a.optString("text"))
        ar.setBackgroundColor(if (modeGelap()) Color.rgb(28, 44, 40) else Color.rgb(239, 236, 221))
        root.addView(ar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })
        ayatArab = ar
        val translatedSurah = terjemahan?.optJSONObject("data")?.optJSONArray("surahs")?.optJSONObject(nomorSurah - 1)
        val translatedAyat = translatedSurah?.optJSONArray("ayahs")?.optJSONObject(nomorAyat - 1)?.optString("text", "") ?: ""
        val arti = TextView(this)
        arti.text = if (translatedAyat.isBlank()) tr("Terjemahan belum tersedia. Unduh teks sesuai bahasa aplikasi.", "Translation is not available. Download text in the app's selected language.") else translatedAyat
        arti.textSize = 17f; arti.setTextColor(warnaTeks()); arti.setPadding(dp(8), dp(8), dp(8), dp(8))
        arti.visibility = if (tampilkanArti) android.view.View.VISIBLE else android.view.View.GONE
        root.addView(arti); ayatArti = arti
        val ref = info(tr("Surah", "Surah") + (" " + (nomorSurah) + ", ") + tr("ayat", "verse") + (" " + (nomorAyat)))
        teksReferensi = ref
        tombol(tr("Ayat sebelumnya", "Previous verse")) { hentikanAudio(); if (nomorAyat > 1) nomorAyat-- else if (nomorSurah > 1) { nomorSurah--; nomorAyat = getSurah(nomorSurah)?.optJSONArray("ayahs")?.length() ?: 1 }; tampilkanPembaca() }
        tombol(tr("Ayat berikutnya", "Next verse")) { hentikanAudio(); if (nomorAyat < verses.length()) nomorAyat++ else if (nomorSurah < 114) { nomorSurah++; nomorAyat = 1 }; tampilkanPembaca() }
        tombol(tr("Pilih nomor ayat", "Choose verse number")) { hentikanAudio(); pilihAyat() }
        tombolTandaiAyat = tombol(if (ayatSudahSelesai()) tr("Batalkan tanda selesai untuk ayat ini", "Unmark this verse as completed") else tr("Tandai ayat selesai dibaca", "Mark verse as read")) {
            if (ayatSudahSelesai()) batalkanTandaAyatSelesai() else tandaiAyatSelesai()
        }
        tombol(tr("Tandai posisi terakhir", "Save reading position")) { tandaiPosisi() }
        tombol(if (tampilkanArti) tr("Sembunyikan terjemahan", "Hide translation") else tr("Tampilkan terjemahan", "Show translation")) { hentikanAudio(); tampilkanArti = !tampilkanArti; dataPrefs.edit().putBoolean("tampilkan_terjemahan", tampilkanArti).apply(); tampilkanPembaca() }
        tombol(tr("Perbesar teks Arab", "Increase Arabic text size")) { hentikanAudio(); ukuranArab = (ukuranArab + 2f).coerceAtMost(42f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); tampilkanPembaca() }
        tombol(tr("Perkecil teks Arab", "Decrease Arabic text size")) { hentikanAudio(); ukuranArab = (ukuranArab - 2f).coerceAtLeast(22f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); tampilkanPembaca() }
        bagian(tr("AUDIO DAN HAFALAN", "AUDIO AND MEMORIZATION"))
        infoQari = info(tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari())
        tombol(tr("Pengaturan utama Khatam Al-Qur'an", "Main Qur'an completion settings")) { dialogPengaturanKhatam() }
        infoModeAudio = info(tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat())
        tombolStatusAudio = info(tr("Audio belum diputar. Internet diperlukan untuk murattal.", "Audio has not started. Internet is required for murattal."))
        tombolAudioAyat = null
        bangunKontrolPemutarAudio()
        info(tr("Cara pemutaran: ", "Playback range: ") + namaTargetPemutaran())
        tombol(tr("Hentikan audio", "Stop audio")) { hentikanAudio(); perbaruiStatusAudio(tr("Audio dihentikan. Posisi bacaan disimpan.", "Audio stopped. Reading position saved.")) }
        tombol(tr("Cari juz, surah, atau ayat", "Search juz, surah, or verse")) { dialogCariAudio() }
        tombol(tr("Putar satu halaman mushaf", "Play one mushaf page")) { pilihHalamanUntukDiputar() }
        bagian(tr("NAVIGASI AYAT", "VERSE NAVIGATION"))
    }

    /** Tata letak pemutar bergaya profesional: navigasi trek, kontrol utama, lalu kecepatan. */
    private fun bangunKontrolPemutarAudio() {
        val barisNavigasi = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            contentDescription = tr("Kontrol trek audio", "Audio track controls")
        }
        fun buatKontrol(label: String, deskripsi: String, aksi: () -> Unit, utama: Boolean = false): android.widget.Button {
            return android.widget.Button(this).apply {
                text = label
                contentDescription = deskripsi
                isAllCaps = false
                textSize = if (utama) 15f else 13f
                minHeight = dp(if (utama) 64 else 56)
                minimumHeight = dp(if (utama) 64 else 56)
                setOnClickListener { aksi() }
                importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
                layoutParams = LinearLayout.LayoutParams(0, -2, if (utama) 1.35f else 1f).apply {
                    setMargins(dp(3), dp(4), dp(3), dp(4))
                }
            }
        }
        barisNavigasi.addView(buatKontrol(tr("Sebelumnya", "Previous"), tr("Audio sebelumnya", "Previous audio track"), { pindahTrekAudio(-1) }))
        val tombolUtama = buatKontrol(tr("Putar", "Play"), tr("Putar audio atau lanjutkan audio yang dijeda", "Play audio or resume paused audio"), { jedaLanjutAudio() }, true)
        tombolJedaAudio = tombolUtama
        barisNavigasi.addView(tombolUtama)
        barisNavigasi.addView(buatKontrol(tr("Berikutnya", "Next"), tr("Audio berikutnya", "Next audio track"), { pindahTrekAudio(1) }))
        root.addView(barisNavigasi, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val barisKecepatan = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        barisKecepatan.addView(buatKontrol(tr("Lebih lambat", "Slower"), tr("Perlambat kecepatan audio", "Decrease audio playback speed"), { ubahKecepatanAudio(-1) }))
        val labelKecepatan = TextView(this).apply {
            text = labelKecepatanAudio()
            textSize = 16f
            gravity = Gravity.CENTER
            contentDescription = tr("Kecepatan pemutaran saat ini ", "Current playback speed ") + labelKecepatanAudio()
            setPadding(dp(4), dp(12), dp(4), dp(12))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        teksKecepatanAudio = labelKecepatan
        barisKecepatan.addView(labelKecepatan, LinearLayout.LayoutParams(0, -2, 1f))
        barisKecepatan.addView(buatKontrol(tr("Lebih cepat", "Faster"), tr("Percepat kecepatan audio", "Increase audio playback speed"), { ubahKecepatanAudio(1) }))
        root.addView(barisKecepatan, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        perbaruiTombolJedaAudio()
    }

    private fun labelKecepatanAudio(): String = String.format(Locale.ROOT, "%.2fx", kecepatanAudio)

    private fun ubahKecepatanAudio(arah: Int) {
        val values = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)
        val index = values.indices.firstOrNull { kotlin.math.abs(values[it] - kecepatanAudio) < 0.001f } ?: 1
        kecepatanAudio = values[(index + arah + values.size) % values.size]
        dataPrefs.edit().putFloat("kecepatan_audio", kecepatanAudio).apply()
        if (Build.VERSION.SDK_INT >= 23) try { pemutar?.let { it.playbackParams = it.playbackParams.setSpeed(kecepatanAudio) } } catch (_: Exception) { }
        val label = labelKecepatanAudio()
        teksKecepatanAudio?.text = label
        teksKecepatanAudio?.contentDescription = tr("Kecepatan pemutaran saat ini ", "Current playback speed ") + label
        teksKecepatanAudio?.announceForAccessibility(teksKecepatanAudio?.contentDescription)
        perbaruiStatusAudio(tr("Kecepatan audio diatur ke ", "Audio speed set to ") + label)
    }

    /** Pindah ke trek ayat/surah sebelumnya atau berikutnya sesuai rentang yang sedang diputar. */
    private fun pindahTrekAudio(arah: Int) {
        if (quran == null) { muatCache() }
        if (quran == null) { toast(tr("Unduh teks Al-Qur'an terlebih dahulu untuk navigasi audio.", "Download Qur'an text first to navigate audio.")); return }
        if (targetPemutaran == "surah" || qariId.startsWith("mp3quran|") || (!audioSedangAyat && !audioSedangJuz && targetPemutaran == "surah")) {
            val tujuan = (nomorSurah + arah).coerceIn(1, 114)
            if (tujuan == nomorSurah) { toast(tr("Tidak ada surah lain pada arah tersebut.", "There is no other surah in that direction.")); return }
            hentikanAudio(); nomorSurah = tujuan; nomorAyat = 1
            dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
            tampilkanPembaca(); putarAudioSurah()
            return
        }
        val tujuanGlobal = if (audioSedangJuz) audioGlobalSaatIni + arah else nomorAyatGlobal() + arah
        val batas = if (audioSedangJuz) audioGlobalAkhir else 6236
        val awal = if (audioSedangJuz) (if (audioRentangLabel.startsWith(tr("Halaman", "Page"))) rentangGlobalHalaman(halamanAktif)?.first else rentangGlobalJuz(juzAktif)?.first) ?: 1 else 1
        if (tujuanGlobal !in awal..batas) { toast(tr("Tidak ada audio sebelumnya/berikutnya dalam rentang ini.", "No previous/next audio in this range.")); return }
        val posisi = posisiSurahAyatDariGlobal(tujuanGlobal) ?: return
        val tetapJuz = audioSedangJuz
        if (tetapJuz) audioGlobalSaatIni = tujuanGlobal
        nomorSurah = posisi.first; nomorAyat = posisi.second
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val url = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + tujuanGlobal + ".mp3"
        hentikanAudio()
        audioSedangJuz = tetapJuz
        if (tetapJuz) { audioGlobalSaatIni = tujuanGlobal; audioGlobalAkhir = batas }
        audioSedangAyat = !tetapJuz
        urlAudioAyatAktif = url
        pesanAudioAyatAktif = tr("Memutar ayat ", "Playing verse ") + nomorSurah + ":" + nomorAyat
        sisaPengulanganAyat = pengulanganAyat
        aturKelompokDariPosisi()
        tampilkanPembaca()
        tombolAudioAktif = tombolAudioAyat
        mulaiAudio(url, pesanAudioAyatAktif)
    }

    /**
     * FIX82: setelah audio selesai dengan sendirinya, kembali ke halaman utama Khatam dan arahkan fokus pembaca layar
     * (TalkBack) ke status pada bagian Pemutaran Audio, sehingga pengguna tunanetra langsung berada di kontrol audio.
     */
    private fun selesaiKembaliKeMenu(pesan: String) {
        if (isFinishing) return
        if (sedangDiPembaca) bangunMenuLagi()
        val v = tombolStatusAudio ?: return
        v.text = pesan
        v.isFocusable = true
        handler.postDelayed({
            if (isFinishing) return@postDelayed
            v.requestFocus()
            v.requestRectangleOnScreen(android.graphics.Rect(0, 0, v.width, v.height), true)
            v.performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
        }, 500L)
    }

    private fun bangunMenuLagi() {
        root.removeAllViews()
        tombol(tr("Kembali ke halaman sebelumnya", "Back to previous page")) { finish() }
        bangun()
    }

    /** FIX67: label qari disimpan dalam bahasa Indonesia; ditampilkan sesuai bahasa aplikasi yang aktif. */
    private fun labelQariTampil(label: String): String {
        if (BahasaAplikasi.tampilan(this) != 1) return label
        return label.replace("Anak · ", "Children · ")
            .replace("merdu dan jelas", "clear and melodious")
            .replace("tartil dan tajwid", "tartil and tajweed")
            .replace("audio per ayat", "verse-by-verse audio")
            .replace("Qari (nama Latin tidak tersedia)", "Reciter (Latin name unavailable)")
            .replace("Qari MP3Quran", "MP3Quran reciter")
    }

    private fun namaQari(): String {
        if (qariId.startsWith("mp3quran|")) return labelQariTampil(dataPrefs.getString("qari_audio_nama", "Qari MP3Quran") ?: "Qari MP3Quran")
        return labelQariTampil(daftarQari.firstOrNull { it.first == qariId }?.second
            ?: dataPrefs.getString("qari_audio_nama", null)
            ?: "Mishary Rashid Alafasy")
    }

    private fun pilihQari(induk: () -> Unit = { dialogPengaturanAudio() }) {
        // FIX57: daftar qari anak yang pernah berhasil dimuat disimpan, sehingga tetap tampil walau jaringan
        // sedang gagal. Katalog dicoba dimuat ulang setiap kali pilihan dibuka sampai berhasil (sebelumnya hanya
        // dicoba sekali per layar, sehingga satu kegagalan membuat daftar qari anak kosong terus).
        muatKatalogQariDariCache()
        if (katalogQariSudahDimuat) { tampilkanDialogPilihQari(induk); return }
        if (katalogQariSedangDimuat) {
            toast(tr("Katalog qari sedang dimuat. Coba lagi sebentar.", "The reciter catalogue is still loading. Try again in a moment."))
            return
        }
        katalogQariSedangDimuat = true
        toast(tr("Memuat katalog qari…", "Loading reciter catalogue…"))
        Thread {
            val tambahanEdisi = mutableListOf<Pair<String, String>>()
            val tambahan = mutableListOf<Pair<String, String>>()
            val cadangan = mutableMapOf<String, List<String>>()
            try {
                // Ambil hanya edisi audio ayat yang diumumkan API resmi, agar pengenal qari tambahan valid.
                try {
                    val edisiResponse = JSONObject(fetch("https://api.alquran.cloud/v1/edition?format=audio&language=ar&type=versebyverse"))
                    val edisi = edisiResponse.optJSONArray("data")
                    if (edisi != null) for (j in 0 until edisi.length()) {
                        val e = edisi.optJSONObject(j) ?: continue
                        val idEdisi = e.optString("identifier").trim()
                        val namaEdisi = e.optString("englishName").ifBlank { e.optString("name") }.trim()
                        if (idEdisi.startsWith("ar.") && namaEdisi.isNotBlank() && daftarQari.none { it.first == idEdisi } && tambahanEdisi.none { it.first == idEdisi }) {
                            tambahanEdisi.add(idEdisi to (namaEdisi + " · audio per ayat"))
                        }
                    }
                } catch (_: Exception) { }
                // API diminta dalam bahasa Inggris agar nama qari tampil dengan huruf Latin
                // dan dapat dibaca mesin TTS yang tidak memiliki suara bahasa Arab.
                val reciters = JSONObject(fetch("https://mp3quran.net/api/v3/reciters?language=eng")).optJSONArray("reciters")
                // Nama Arab dimuat terpisah (gagal tidak apa-apa) hanya untuk mengenali qari anak yang ejaan Latinnya berbeda.
                val namaArab = mutableMapOf<Int, String>()
                try {
                    val ar = JSONObject(fetch("https://mp3quran.net/api/v3/reciters?language=ar")).optJSONArray("reciters")
                    if (ar != null) for (i in 0 until ar.length()) {
                        val r = ar.optJSONObject(i) ?: continue
                        namaArab[r.optInt("id", -1)] = r.optString("name").trim()
                    }
                } catch (_: Exception) { }
                if (reciters != null) {
                    for (i in 0 until reciters.length()) {
                        val r = reciters.optJSONObject(i) ?: continue
                        val name = r.optString("name").trim()
                        if (name.isBlank()) continue
                        // Semua rekaman (moshaf) diperiksa, bukan hanya yang pertama; yang paling lengkap menjadi sumber utama
                        // dan sisanya menjadi sumber cadangan bila server utama gagal.
                        val sumber = sumberMoshafQari(r)
                        if (sumber.isEmpty()) continue
                        val utama = sumber.first()
                        // FIX61: qari yang rekamannya tidak lengkap (kurang dari 114 surah) tidak dimasukkan ke daftar.
                        if (jumlahSurahQari("mp3quran|" + utama.first + "|" + utama.second) < 114) continue
                        val child = peringkatQariAnak(name) >= 0 || peringkatQariAnak(namaArab[r.optInt("id", -1)].orEmpty()) >= 0
                        tambahan.add(("mp3quran|" + utama.first + "|" + utama.second) to ((if (child) "Anak · " else "MP3Quran · ") + namaQariLatin(name)))
                        val lain = sumber.drop(1).map { it.first }.filter { it != utama.first }.distinct()
                        if (lain.isNotEmpty()) cadangan[utama.first] = lain
                    }
                }
            } catch (_: Exception) { }
            runOnUiThread {
                tambahanEdisi.forEach { item -> if (daftarQari.none { q -> q.first == item.first }) daftarQari.add(item) }
                tambahan.forEach { item -> if (daftarQariPerSurah.none { q -> q.first == item.first }) daftarQariPerSurah.add(item) }
                if (tambahan.isNotEmpty()) {
                    katalogQariSudahDimuat = true
                    simpanKatalogQariAnak(cadangan)
                }
                katalogQariSedangDimuat = false
                tampilkanDialogPilihQari(induk)
            }
        }.start()
    }

    /**
     * FIX57: semua rekaman https milik satu qari MP3Quran yang punya daftar surah, diurutkan dari yang paling lengkap.
     * Pasangan: (alamat server berakhiran "/", daftar nomor surah dipisah koma). Server http:// dinaikkan ke https://.
     */
    private fun sumberMoshafQari(r: JSONObject): List<Pair<String, String>> {
        val moshaf = r.optJSONArray("moshaf") ?: return emptyList()
        val hasil = mutableListOf<Triple<String, String, Int>>()
        for (k in 0 until moshaf.length()) {
            val m = moshaf.optJSONObject(k) ?: continue
            var server = m.optString("server").trim()
            if (server.startsWith("http://")) server = "https://" + server.removePrefix("http://")
            val surahList = m.optString("surah_list").trim()
            if (!server.startsWith("https://") || surahList.isBlank()) continue
            val jumlah = surahList.split(",").count { it.trim().toIntOrNull() != null }
            if (jumlah == 0) continue
            hasil.add(Triple(server.trimEnd('/') + "/", surahList, jumlah))
        }
        return hasil.sortedByDescending { it.third }.map { it.first to it.second }
    }

    private fun simpanKatalogQariAnak(cadangan: Map<String, List<String>>) {
        try {
            val anak = org.json.JSONArray()
            daftarQariPerSurah.filter { it.second.startsWith("Anak · ") }.forEach { anak.put(org.json.JSONArray().put(it.first).put(it.second)) }
            val sadur = JSONObject()
            cadangan.forEach { (server, lain) -> sadur.put(server, org.json.JSONArray(lain)) }
            dataPrefs.edit().putString("katalog_qari_anak_cache", anak.toString()).putString("qari_cadangan_server", sadur.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun muatKatalogQariDariCache() {
        try {
            val teks = dataPrefs.getString("katalog_qari_anak_cache", null) ?: return
            val anak = org.json.JSONArray(teks)
            for (i in 0 until anak.length()) {
                val baris = anak.optJSONArray(i) ?: continue
                val id = baris.optString(0); val label = baris.optString(1)
                if (id.startsWith("mp3quran|") && qariLengkap(id) && label.isNotBlank() && daftarQariPerSurah.none { it.first == id }) daftarQariPerSurah.add(id to label)
            }
        } catch (_: Exception) { }
    }

    /** Server cadangan (rekaman lain dari qari yang sama) untuk sebuah server MP3Quran. */
    private fun serverCadanganMp3Quran(server: String): List<String> {
        return try {
            val o = JSONObject(dataPrefs.getString("qari_cadangan_server", null) ?: return emptyList())
            val a = o.optJSONArray(server) ?: return emptyList()
            (0 until a.length()).map { a.optString(it) }.filter { it.startsWith("https://") }
        } catch (_: Exception) { emptyList() }
    }

    /**
     * Daftar URL yang dicoba berurutan untuk satu berkas MP3Quran (FIX58): server utama (https), varian http dari
     * server MP3Quran yang sama (sebagian server lama tidak punya sertifikat https), lalu server cadangan dengan
     * urutan yang sama. Varian http hanya untuk mp3quran.net dan diizinkan oleh network_security_config.xml.
     */
    private fun urlSumberMp3Quran(url: String): List<String> {
        val nama = url.substringAfterLast('/')
        val server = url.substringBeforeLast('/') + "/"
        val hasil = LinkedHashSet<String>()
        hasil.add(url)
        for (s in listOf(server) + serverCadanganMp3Quran(server)) {
            hasil.add(s + nama)
            if (s.startsWith("https://") && Regex("^https://[a-z0-9.-]*mp3quran\\.net/").containsMatchIn(s)) {
                hasil.add("http://" + s.removePrefix("https://") + nama)
            }
        }
        return hasil.toList()
    }

    private fun maksPercobaanAudio(url: String): Int =
        if (audioTerjemahanAktif) 1
        else if (qariId.startsWith("mp3quran|")) (urlSumberMp3Quran(url).size - 1).coerceIn(0, 6) else 5

    /**
     * FIX58: Muhammad Taha Al-Junayd tetap tampil di daftar Qari anak walau katalog MP3Quran tidak memuatnya
     * (atau katalog belum bisa dimuat). Sumber: arsip rekaman Internet Archive "Muhammad-Taha-Al-Junaid"
     * (berkas 001.mp3 dst). Dipakai hanya bila katalog tidak memuat qari ini.
     */
    private val qariTahaCadangan: Pair<String, String> =
        ("mp3quran|https://archive.org/download/Muhammad-Taha-Al-Junaid/|" + (1..114).joinToString(",")) to "Anak · Muhammad Taha Al-Junayd"

    /** Normalisasi nama qari: huruf kecil tanpa spasi/tanda baca; Arab tanpa harakat dan dengan huruf alif/ya/ta marbuta seragam. */
    private fun normalisasiNamaQari(nama: String): String =
        nama.replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9\\u0600-\\u06FF]"), "")

    /**
     * Peringkat qari anak (FIX56); angka kecil = prioritas lebih tinggi, -1 = bukan qari anak.
     * Urutan disusun dari yang paling dikenal dan paling banyak rekamannya:
     * 0 Muhammad Taha Al-Junayd, 1 Ahmad Saud, 2 Junaid Adam.
     * FIX57: pencocokan memakai nama yang dinormalisasi sehingga spasi, tanda hubung, dan variasi ejaan
     * (Junaid/Junayd/Juneid/Junid, Mohamed/Muhammad, Saud/Saoud/Sa3ud) tetap terbaca.
     */
    private fun peringkatQariAnak(nama: String): Int {
        val n = normalisasiNamaQari(nama)
        if (n.isEmpty()) return -1
        val junaid = Regex("j[uoi]n[aeiyu]{1,3}d")
        val muhammad = Regex("m[uo]h?[ao]mm?[ae]d")
        return when {
            (n.contains("taha") && (junaid.containsMatchIn(n) || muhammad.containsMatchIn(n))) ||
                (n.contains("طه") && (n.contains("جنيد") || n.contains("جنید"))) -> 0
            Regex("ah?m[ae]d(bin|ibn)?(saud|saaud|saoud|saood|sa3ud|suud)").containsMatchIn(n) || n.contains("احمدسعود") || n.contains("احمدبنسعود") -> 1
            Regex("j[uoi]n[aeiyu]{1,3}dadam").containsMatchIn(n) || (n.contains("جنيد") && n.contains("ادم")) -> 2
            else -> -1
        }
    }

    /**
     * FIX62: peringkat qari dewasa terbaik pada katalog per surah (angka kecil = lebih dikenal), -1 = tidak termasuk.
     * Pencocokan memakai nama Latin yang dinormalisasi dari katalog MP3Quran; hanya yang ada dan lengkap yang tampil.
     */
    private fun peringkatQariTerbaik(nama: String): Int {
        val n = normalisasiNamaQari(nama)
        val pola = listOf(
            "alafasy|alafasi", "sudais|sudays|sdais", "shuraim|shuraym|shurain|shureim", "husari|husary|hussary|alhosary",
            "minshawi|minshawy|menshawi", "abdulbasit|abdelbasset|abdulbaset|abdalbasit", "muaiqly|moaiqly|mueaqly|maheralmu",
            "ghamdi|ghamadi", "ajmi|ajamy|ajamiy", "hudhaify|hudhayfi|huthaify|alhuthayfi", "shatri|shaatree|shatree|shaaree",
            "dosari|dossary|dawsari", "qatami|qtami", "rifai|rifa3i|alrefai", "ayyoub|ayyub|ayoub", "basfar|basfer",
            "tablawi|tablawy", "jibreel|jibril|gibril", "akhdar|alakhdar", "sowaid|swoaid|suwayd", "budair|budayr|bu3ayjan|bu3ajjan",
            "juhani|juhany|aljuhani", "ibrahimakhbar|akhbar", "mustafaismail|mustafaesmail", "shahatmuhammadanwar|shahat"
        )
        for ((i, p) in pola.withIndex()) if (p.split("|").any { n.contains(it) }) return i
        return -1
    }

    /** Qari dewasa terbaik yang tersedia lengkap (114 surah) dari katalog per surah, terurut menurut peringkat. */
    private fun daftarQariTerbaikTerurut(): List<Pair<String, String>> =
        daftarQariPerSurah.filter { !it.second.startsWith("Anak · ") && qariLengkap(it.first) && peringkatQariTerbaik(it.second) >= 0 }
            .sortedBy { peringkatQariTerbaik(it.second) }

    /** Qari anak yang benar-benar ada di katalog yang berhasil dimuat, terurut menurut peringkat. */
    private fun daftarQariAnakTerurut(): List<Pair<String, String>> {
        val dariKatalog = daftarQariPerSurah.filter { it.second.startsWith("Anak · ") && qariLengkap(it.first) }
        val lengkap = if (dariKatalog.any { peringkatQariAnak(it.second) == 0 }) dariKatalog else dariKatalog + qariTahaCadangan
        return lengkap.sortedBy { peringkatQariAnak(it.second).let { r -> if (r < 0) 99 else r } }
    }

    private fun namaQariLatin(nama: String): String {
        // Jika API tetap mengembalikan aksara Arab, gunakan nama Latin yang
        // tersedia pada katalog lokal atau transliterasi sederhana sebagai fallback.
        if (nama.none { Character.UnicodeBlock.of(it) == Character.UnicodeBlock.ARABIC }) return nama
        val peta = mapOf(
            "مشاري العفاسي" to "Mishary Rashid Alafasy",
            "محمود خليل الحصري" to "Mahmoud Khalil Al-Husary",
            "محمد صديق المنشاوي" to "Mohamed Siddiq Al-Minshawi",
            "عبدالرحمن السديس" to "Abdurrahman As-Sudais",
            "سعود الشريم" to "Saud Al-Shuraim",
            "عبدالباسط عبدالصمد" to "Abdul Basit Abdus Samad",
            "ماهر المعيقلي" to "Maher Al-Muaiqly",
            "ياسر الدوسري" to "Yasser Al-Dosari"
        )
        return peta[nama.trim()] ?: nama.filter { Character.UnicodeBlock.of(it) != Character.UnicodeBlock.ARABIC }
            .replace(Regex("\\s+"), " ").trim().ifBlank { "Qari (nama Latin tidak tersedia)" }
    }

    private fun tampilkanDialogPilihQari(induk: () -> Unit = { dialogPengaturanAudio() }) {
        val pilihan = arrayOf(
            tr("Qari anak (pilihan terbaik)", "Children's reciters (top picks)"),
            tr("Qari audio per ayat / juz", "Verse-by-verse / juz reciters"),
            tr("Qari audio per surah", "Full-surah reciters"),
            tr("Qari terbaik per surah (pilihan)", "Best full-surah reciters (top picks)")
        )
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih jenis katalog qari", "Choose reciter catalogue"))
            .setItems(pilihan) { _, jenis ->
                val sumber = when (jenis) {
                    0 -> daftarQariAnakTerurut()
                    1 -> daftarQari
                    2 -> daftarQariPerSurah.filter { q -> qariLengkap(q.first) }.sortedBy { q -> peringkatQariTerbaik(q.second).let { r -> if (r < 0) 999 else r } }
                    else -> daftarQariTerbaikTerurut()
                }
                if (sumber.isEmpty()) {
                    toast(when (jenis) {
                        0 -> tr("Daftar qari anak belum tersedia. Periksa koneksi internet lalu buka pilihan ini lagi.", "The children's reciter list is unavailable. Check your internet connection and open this option again.")
                        1 -> tr("Daftar qari per ayat belum tersedia.", "Verse-by-verse reciter list is not available.")
                        3 -> tr("Qari terbaik per surah belum tersedia. Periksa koneksi internet lalu buka pilihan ini lagi.", "Best full-surah reciters are unavailable. Check your internet connection and open this option again.")
                        else -> tr("Daftar qari per surah belum tersedia. Periksa koneksi internet.", "Full-surah reciter list is unavailable. Check your internet connection.")
                    })
                    handler.post { tampilkanDialogPilihQari(induk) }
                    return@setItems
                }
                val daftarTampil = sumber.toList()
                val labels = daftarTampil.map { labelQariTampil(it.second) + (if (it.first.startsWith("mp3quran|")) {
                    val jml = it.first.split("|").getOrNull(2)?.split(",")?.count { n -> n.trim().toIntOrNull() != null } ?: 0
                    if (jml in 1..113) tr(" · hanya " + jml + " surah", " · only " + jml + " surahs") else ""
                } else "") + if (it.first == qariId) tr(" (dipilih)", " (selected)") else "" }
                val judulDaftar = AlertDialog.Builder(this)
                if (jenis == 0) judulDaftar.setCustomTitle(judulDenganPesan(pilihan[0], tr(
                    "Urutan dari yang paling dikenal. Qari anak tersedia sebagai audio per surah; untuk audio per ayat dan hafalan per ayat, pilih qari dari katalog per ayat.",
                    "Ordered from best known. Children's reciters are available as full-surah audio; for verse-by-verse audio and memorization, choose a reciter from the verse-by-verse catalogue.")))
                else judulDaftar.setTitle(pilihan[jenis])
                judulDaftar
                    .setItems(labels.toTypedArray()) { _, which ->
                        if (which in daftarTampil.indices) {
                            hentikanAudio()
                            qariId = daftarTampil[which].first
                            dataPrefs.edit().putString("qari_audio_id", qariId).putString("qari_audio_nama", daftarTampil[which].second).apply()
                            val nama = tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari()
                            infoQari?.text = nama
                            tombolStatusAudio?.text = tr("Qari dipilih: ", "Reciter selected: ") + namaQari() +
                                if (qariId.startsWith("mp3quran|")) tr(". Qari ini menyediakan audio per surah. Tekan Putar untuk memutar surah penuh.", ". This reciter provides full-surah audio. Press Play to play the whole surah.")
                                else tr(". Silakan pilih juz, surah, atau ayat untuk diputar.", ". Choose a juz, surah, or verse to play.")
                            tombolStatusAudio?.announceForAccessibility(tombolStatusAudio?.text)
                            toast(tr("Qari audio diubah menjadi ", "Audio reciter changed to ") + namaQari())
                            handler.post { induk() }
                        }
                    }
                    .kembaliKe(tr("Kembali ke pilihan katalog qari", "Back to reciter catalogue")) { tampilkanDialogPilihQari(induk) }
                    .show()
            }
            .kembaliKe(tr("Kembali ke pengaturan audio", "Back to audio settings")) { induk() }
            .show()
    }

    /**
     * Navigasi pengaturan (FIX55): setiap sub menu punya tombol Kembali bernama induknya, dan menutup dialog
     * dengan tombol Kembali Android atau sentuhan di luar dialog juga kembali ke induk, bukan ke menu utama Khatam.
     * Susunan: Pengaturan Khatam > (Hafalan | Pemutaran audio > ... | Pengingat | Target | Aksesibilitas | Riwayat | Statistik).
     */
    private fun AlertDialog.Builder.kembaliKe(label: String, induk: () -> Unit): AlertDialog.Builder =
        setNegativeButton(label) { _, _ -> handler.post { induk() } }
            .setOnCancelListener { handler.post { induk() } }

    private fun namaModeHafalan(): String = when (modeHafalan) {
        "ayat" -> tr("Hafalan · ulang ayat pilihan", "Memorization · repeat selected verse")
        "berurutan" -> tr("Hafalan · ulang lalu lanjut ayat", "Memorization · repeat then next verse")
        "kelompok" -> tr("Hafalan · ulang kelompok ", "Memorization · repeat group of ") + ayatPerKelompok + tr(" ayat", if (ayatPerKelompok == 1) " verse" else " verses")
        else -> tr("Putar biasa · satu kali", "Normal playback · once")
    }

    /** Pusat pengaturan Khatam: fitur yang jarang dipakai tidak memenuhi menu utama. */
    /**
     * FIX106: pusat asisten tahfiz yang mengarahkan pengguna ke kemampuan yang sudah ada.
     * Tidak membuat mesin koreksi atau latihan kedua; setiap pilihan memakai alur lama.
     */
    private fun dialogAsistenTahfizCerdas() {
        val isi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        val pengantar = TextView(this).apply {
            text = tr(
                "Pilih pendamping yang ingin digunakan. Setiap tombol membuka langkah latihan yang dapat dibaca TalkBack. Asisten ini memakai mesin hafalan dan koreksi yang sudah tersedia.",
                "Choose the assistant you want to use. Each button opens practice steps that TalkBack can read. This assistant reuses the existing memorization and checking features."
            )
            textSize = 16f
            setPadding(0, 0, 0, dp(12))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        isi.addView(pengantar)
        lateinit var dialog: AlertDialog
        fun tambahAksi(judul: String, uraian: String, aksi: () -> Unit) {
            val tombol = Button(this).apply {
                text = "$judul\n$uraian"
                textSize = 15f
                isAllCaps = false
                contentDescription = "$judul. $uraian"
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
                setOnClickListener { dialog.dismiss(); aksi() }
            }
            isi.addView(tombol, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        tambahAksi(
            tr("Mulai Muraja'ah Cerdas", "Start Smart Muraja'ah"),
            tr("Susun sesi dari ayat yang jatuh tempo dan ayat yang perlu dikuatkan.", "Build a session from due verses and verses that need reinforcement.")
        ) { mulaiMurajaahCerdas() }
        tambahAksi(
            tr("Asisten Hafalan Inklusif", "Inclusive Memorization Assistant"),
            tr("Latihan mandiri tanpa mikrofon, petunjuk kata, dan pengaturan aksesibilitas.", "Self-practice without a microphone, word hints, and accessibility settings.")
        ) { dialogAsistenHafalanInklusif() }
        tambahAksi(
            tr("Asisten Koreksi Bacaan", "Recitation Checking Assistant"),
            tr("Bandingkan urutan kata melalui pengenalan suara; bukan penilaian tajwid.", "Compare word order using speech recognition; this is not a tajwid assessment.")
        ) { dialogAsistenKoreksiBacaan() }
        tambahAksi(
            tr("Pengaturan latihan dan aksesibilitas", "Practice and accessibility settings"),
            tr("Atur latihan, pembaca layar, ukuran teks, dan muraja'ah.", "Configure practice, screen reader support, text size, and muraja'ah.")
        ) { dialogPilihanPengaturanAsisten() }

        val gulir = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(isi)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        dialog = AlertDialog.Builder(this)
            .setTitle(tr("Asisten Tahfiz Cerdas", "Smart Tahfiz Assistant"))
            .setView(gulir)
            .setNegativeButton(tr("Tutup", "Close"), null)
            .create()
        dialog.setOnShowListener {
            handler.post {
                pengantar.requestFocus()
                pengantar.announceForAccessibility(tr("Asisten Tahfiz Cerdas terbuka. Empat pilihan tersedia. Geser untuk membaca pengantar dan tombol-tombolnya.", "Smart Tahfiz Assistant is open. Four options are available. Swipe to read the introduction and its buttons."))
            }
        }
        dialog.show()
    }

    /** Jalur aksesibel memakai latihan tanpa mikrofon yang sudah ada dan pengaturan aksesibilitas pembaca. */
    private fun dialogAsistenHafalanInklusif() {
        AlertDialog.Builder(this)
            .setTitle(tr("Asisten Hafalan Inklusif", "Inclusive Memorization Assistant"))
            .setMessage(tr(
                "Latihan dapat dilakukan tanpa mikrofon: ayat disembunyikan, pengguna membaca dari hafalan, lalu menampilkan jawaban untuk mencocokkan. Tombol, petunjuk, dan status memakai bahasa tampilan aktif serta dapat dibaca TalkBack. Ini bukan penilaian otomatis tajwid atau makhraj.",
                "Practice without a microphone: the verse is hidden while you recite from memory, then reveal the answer to compare. Controls, hints, and status follow the active display language and are accessible to TalkBack. This is not an automatic tajwid or articulation assessment."
            ))
            .setPositiveButton(tr("Mulai latihan tanpa mikrofon", "Start no-microphone practice")) { _, _ ->
                latihanKoreksiHafalan()
            }
            .setNeutralButton(tr("Pengaturan aksesibilitas", "Accessibility settings")) { _, _ ->
                pengaturanAksesibilitas()
            }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogAsistenTahfizCerdas() } }
            .show()
    }

    /** Nama baru untuk akses ke koreksi suara yang sudah ada; tidak membuat recognizer kedua. */
    private fun dialogAsistenKoreksiBacaan() {
        AlertDialog.Builder(this)
            .setTitle(tr("Asisten Koreksi Bacaan", "Recitation Correction Assistant"))
            .setMessage(tr(
                "Gunakan pengenalan suara untuk membandingkan bacaan dengan teks ayat. Jika tersedia, kata yang perlu diperbaiki ditandai, petunjuk diberikan, dan audio bacaan yang benar dapat diputar. Hasil pengenalan suara merupakan perkiraan, bukan sertifikasi tajwid atau makhraj.",
                "Use speech recognition to compare your recitation with the verse text. When available, words needing attention are highlighted, hints are provided, and the correct recitation audio can be played. Speech recognition is an estimate, not a tajwid or articulation certification."
            ))
            .setPositiveButton(tr("Mulai koreksi bacaan", "Start recitation check")) { _, _ ->
                mulaiKoreksiOtomatisHafalan()
            }
            .setNeutralButton(tr("Latihan tanpa mikrofon", "No-microphone practice")) { _, _ ->
                latihanKoreksiHafalan()
            }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogAsistenTahfizCerdas() } }
            .show()
    }

    private fun dialogPilihanPengaturanAsisten() {
        val opsi = arrayOf(
            tr("Pengaturan fitur latihan hafalan", "Memorization practice feature settings"),
            tr("Pengaturan aksesibilitas", "Accessibility settings"),
            tr("Pengaturan muraja'ah cerdas", "Smart muraja'ah settings")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan Asisten Tahfiz", "Tahfiz Assistant Settings"))
            .setItems(opsi) { _, which ->
                when (which) {
                    0 -> dialogSaklarLatihanHafalan()
                    1 -> pengaturanAksesibilitas()
                    2 -> dialogPengaturanMurajaah()
                }
            }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogAsistenTahfizCerdas() } }
            .show()
    }

    private fun dialogPengaturanKhatam() {
        val opsi = arrayOf(
            tr("Asisten Tahfiz Cerdas", "Smart Tahfiz Assistant"),
            tr("Pengaturan hafalan", "Memorization settings"),
            tr("Pengaturan pemutaran audio", "Audio playback settings"),
            tr("Pengingat membaca dan hafalan", "Reading and memorization reminder"),
            tr("Target khatam", "Khatam goal"),
            tr("Pengaturan aksesibilitas", "Accessibility settings"),
            tr("Riwayat khatam", "Khatam history"),
            tr("Kemajuan dan statistik", "Progress and statistics")
        )
        AlertDialog.Builder(this)
            .setTitle(tr("Pengaturan Khatam Al-Qur'an", "Qur'an completion settings"))
            .setItems(opsi) { _, which ->
                when (which) {
                    0 -> dialogAsistenTahfizCerdas()
                    1 -> dialogPengaturanHafalan()
                    2 -> dialogPengaturanAudio()
                    3 -> pengaturanPengingat()
                    4 -> pengaturanTarget()
                    5 -> pengaturanAksesibilitas()
                    6 -> tampilkanRiwayat()
                    7 -> tampilkanStatistik()
                }
            }
            .setNegativeButton(tr("Kembali ke menu Khatam", "Back to Khatam menu"), null)
            .show()
    }

    /** Pengaturan hafalan terpisah dari pengaturan pemutaran audio. */
    private fun dialogPengaturanHafalan() {
        val opsi = arrayOf(
            tr("Mode hafalan audio", "Audio memorization mode"),
            tr("Hafalan per kelompok ayat (tentukan sendiri jumlah ayat)", "Verse-group memorization (set your own number of verses)"),
            tr("Jumlah pengulangan ayat", "Verse repetition count"),
            tr("Jeda antar ayat", "Pause between verses"),
            tr("Fitur latihan hafalan (saklar)", "Memorization practice features (switches)"),
            tr("Pengingat cerdas hafalan", "Smart memorization reminder"),
            tr("Muraja'ah cerdas (ukuran sesi, penguatan)", "Smart muraja'ah (session size, reinforcement)")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan Hafalan", "Memorization Settings"))
            .setItems(opsi) { _, which -> when (which) {
                0 -> pengaturanModeHafalan()
                1 -> dialogHafalanKelompok()
                2 -> pengaturanPengulanganAyat()
                3 -> pengaturanJedaAntarAyat()
                4 -> dialogSaklarLatihanHafalan()
                5 -> dialogPengingatCerdas()
                6 -> dialogPengaturanMurajaah()
            } }.kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }.show()
    }

    /** Saklar untuk dua fitur latihan hafalan di halaman utama Khatam. Bila nonaktif, fitur tidak dapat dijalankan. */
    private fun dialogSaklarLatihanHafalan() {
        val kunciSuara = "hafalan_koreksi_suara_aktif"
        val kunciMandiri = "hafalan_latihan_mandiri_aktif"
        val suara = dataPrefs.getBoolean(kunciSuara, true)
        val mandiri = dataPrefs.getBoolean(kunciMandiri, true)
        val koreksiAudio = dataPrefs.getBoolean("hafalan_audio_koreksi_aktif", true)
        val koreksiCerdas = dataPrefs.getBoolean("hafalan_koreksi_cerdas_aktif", true)
        val opsi = arrayOf(
            tr("Koreksi otomatis dengan pengenalan suara: ", "Automatic speech-recognition check: ") + (if (suara) tr("aktif. Ketuk untuk menonaktifkan", "on. Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on")),
            tr("Latihan hafalan tanpa mikrofon: ", "Memorization practice without microphone: ") + (if (mandiri) tr("aktif. Ketuk untuk menonaktifkan", "on. Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on")),
            tr("Putar audio yang benar saat salah baca: ", "Play the correct audio on a recitation error: ") + (if (koreksiAudio) tr("aktif. Ketuk untuk menonaktifkan", "on. Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on")),
            tr("Koreksi cerdas (tandai kata salah, petunjuk, ulang otomatis): ", "Smart correction (mark wrong words, hints, auto repeat): ") + (if (koreksiCerdas) tr("aktif. Ketuk untuk menonaktifkan", "on. Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on"))
        )
        AlertDialog.Builder(this)
            .setCustomTitle(judulDenganPesan(
                tr("Fitur latihan hafalan", "Memorization practice features"),
                tr("Fitur yang dinonaktifkan tidak tampil dan tidak dapat dijalankan di halaman utama Khatam Al-Qur'an.", "A feature that is turned off is hidden and cannot be run from the main Qur'an Completion page.")))
            .setItems(opsi) { _, which ->
                val kunci = when (which) { 0 -> kunciSuara; 1 -> kunciMandiri; 2 -> "hafalan_audio_koreksi_aktif"; else -> "hafalan_koreksi_cerdas_aktif" }
                val baru = !dataPrefs.getBoolean(kunci, true)
                dataPrefs.edit().putBoolean(kunci, baru).apply()
                val tombolTerkait = when (which) { 0 -> tombolKoreksiSuaraMenu; 1 -> tombolLatihanMandiriMenu; else -> null }
                tombolTerkait?.visibility = if (baru) View.VISIBLE else View.GONE
                val nama = when (which) {
                    0 -> tr("Koreksi otomatis dengan pengenalan suara", "Automatic speech-recognition check")
                    1 -> tr("Latihan hafalan tanpa mikrofon", "Memorization practice without microphone")
                    2 -> tr("Putar audio yang benar saat salah baca", "Play the correct audio on a recitation error")
                    else -> tr("Koreksi cerdas", "Smart correction")
                }
                toast(nama + (if (baru) tr(" diaktifkan.", " turned on.") else tr(" dinonaktifkan.", " turned off.")))
                handler.post { dialogSaklarLatihanHafalan() }
            }
            .kembaliKe(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { dialogPengaturanHafalan() }
            .show()
    }

    /** Seluruh pilihan keluaran dan rentang audio berada pada satu kelompok. */
    private fun dialogPengaturanAudio() {
        // FIX72: butir "Arab / terjemahan" hanya tampil bila memang ada data audio terjemahan Indonesia.
        val daftar = mutableListOf<Pair<String, () -> Unit>>()
        daftar.add(tr("Pilih suara qari", "Choose reciter voice") to { pilihQari() })
        if (daftarBerkasTerjemahanId.isNotEmpty()) {
            daftar.add(tr("Pilihan pemutaran: Arab / terjemahan Indonesia", "Playback: Arabic / Indonesian translation") to { pilihanPemutaranAudio() })
        }
        daftar.add(tr("Cara pemutaran: ayat / surah / juz / halaman", "Playback range: verse / surah / juz / page") to { pengaturanTargetPemutaran() })
        daftar.add(tr("Keluaran suara: Stereo / Mono", "Audio output: Stereo / Mono") to { pengaturanStereoMono() })
        daftar.add(tr("Equalizer audio", "Audio equalizer") to { pengaturanEqualizer() })
        daftar.add(tr("Kecepatan audio", "Audio speed") to { pengaturanKecepatanAudio() })
        val suaraAktif = dataPrefs.getBoolean("perintah_suara_putar_aktif", true)
        daftar.add(tr("Perintah suara untuk memutar: ", "Voice command to play: ") +
            (if (suaraAktif) tr("aktif. Ketuk untuk menonaktifkan", "on. Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on")) to {
            val baru = !dataPrefs.getBoolean("perintah_suara_putar_aktif", true)
            dataPrefs.edit().putBoolean("perintah_suara_putar_aktif", baru).apply()
            tombolPerintahSuaraMenu?.visibility = if (baru) View.VISIBLE else View.GONE
            toast(if (baru) tr("Perintah suara untuk memutar diaktifkan.", "Voice command to play turned on.")
                else tr("Perintah suara untuk memutar dinonaktifkan.", "Voice command to play turned off."))
            handler.post { dialogPengaturanAudio() }
        })
        AlertDialog.Builder(this).setTitle(tr("Pengaturan Pemutaran Audio", "Audio Playback Settings"))
            .setItems(daftar.map { it.first }.toTypedArray()) { _, which -> daftar.getOrNull(which)?.second?.invoke() }
            .kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }.show()
    }

    private fun pilihanPemutaranAudio() {
        val labels = arrayOf(
            tr("Murattal Arab saja", "Arabic recitation only"),
            tr("Terjemahan Indonesia saja (berkas audio, per surah)", "Indonesian translation only (audio file, whole surah)")
        )
        val values = arrayOf("arab", "terjemahan")
        val selected = values.indexOf(modePemutaranAudio).coerceAtLeast(0)
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Pilihan pemutaran audio", "Audio playback options"), tr("Audio terjemahan Indonesia berupa rekaman suara (bukan suara mesin) yang tersedia per surah penuh dan diputar lewat internet dari arsip Internet Archive (unggahan komunitas). Rekaman tidak tersedia per ayat, juz, atau halaman, jadi tombol Putar memutar terjemahan surah yang sedang dibuka dari awal.", "The Indonesian translation is a recording of a human voice (not a speech engine), available as whole surahs and streamed over the internet from the Internet Archive (community upload). It is not available per verse, juz, or page, so the Play button plays the translation of the currently open surah from the beginning.")))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in values.indices) {
                    modePemutaranAudio = values[which]
                    dataPrefs.edit().putString("mode_pemutaran_audio", modePemutaranAudio).apply()
                    dialog.dismiss()
                    toast(labels[which])
                    handler.post { dialogPengaturanAudio() }
                }
            }.setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    /**
     * Judul + pesan penjelasan untuk dialog berdaftar. AlertDialog bawaan Android TIDAK menampilkan daftar
     * pilihan bila setMessage dipakai bersamaan, jadi pesan ditaruh di judul kustom.
     */
    private fun judulDenganPesan(judul: String, pesan: String): android.view.View {
        val kotak = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(20), dp(24), dp(8)) }
        kotak.addView(TextView(this).apply {
            text = judul
            setTextAppearance(android.R.style.TextAppearance_DeviceDefault_DialogWindowTitle)
        })
        kotak.addView(TextView(this).apply {
            text = pesan
            textSize = 15f
            setPadding(0, dp(8), 0, 0)
        })
        kotak.contentDescription = judul + ". " + pesan
        return kotak
    }

    private fun pengaturanStereoMono() {
        val labels = arrayOf(
            tr("Stereo (kiri dan kanan terpisah)", "Stereo (separate left and right)"),
            tr("Mono (kiri dan kanan digabung)", "Mono (left and right combined)")
        )
        val selected = if (keluaranMono) 1 else 0
        AlertDialog.Builder(this).setTitle(tr("Keluaran Stereo atau Mono", "Stereo or Mono output"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                val mono = which == 1
                val berubah = mono != keluaranMono
                keluaranMono = mono
                dataPrefs.edit().putString("keluaran_suara_audio", if (mono) "mono" else "stereo").apply()
                dialog.dismiss()
                val sedangJalan = pemutar != null && audioSiap
                val pesan = (if (mono) tr("Keluaran mono aktif: suara kiri dan kanan digabung.", "Mono output on: left and right are combined.") else tr("Keluaran stereo aktif.", "Stereo output on.")) +
                    (if (berubah && sedangJalan) tr(" Berlaku mulai audio berikutnya; hentikan lalu putar ulang untuk mendengarnya sekarang.", " Applies from the next audio; stop and play again to hear it now.") else "")
                toast(pesan)
                perbaruiStatusAudio(pesan)
                handler.post { dialogPengaturanAudio() }
            }
            .setNeutralButton(tr("Pengaturan mono sistem", "System mono setting")) { _, _ ->
                try {
                    kembaliSetelahLayarSistem = { pengaturanStereoMono() }
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                    kembaliSetelahLayarSistem = null
                    toast(tr("Pengaturan aksesibilitas tidak dapat dibuka otomatis.", "Could not open accessibility settings."))
                    handler.post { pengaturanStereoMono() }
                }
            }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    // ====================================================================================
    // EQUALIZER AUDIO (FIX47, diperkaya di FIX73)
    // Satu sesi audio tetap dipakai semua pemutar murattal, sehingga efek dibuat sekali, dapat diatur
    // kapan saja (juga saat audio belum diputar), dan langsung terdengar pada audio yang sedang berjalan.
    // FIX73: 8 preset bawaan dengan kurva halus, 3 slot kustom, preset bawaan perangkat, serta efek
    // tambahan (bass, suara ruang/virtualizer, penguat volume) yang dapat diatur terpisah.
    // ====================================================================================

    private var sesiAudioEfek = 0
    private var bassBoostAudio: android.media.audiofx.BassBoost? = null
    private var virtualizerAudio: android.media.audiofx.Virtualizer? = null
    private var penguatSuaraAudio: android.media.audiofx.LoudnessEnhancer? = null
    private var statusEfekTambahan = ""
    private val kunciPresetBawaan = arrayOf("normal", "vocal", "bass", "treble", "jernih", "hangat", "malam", "speaker")
    private val kunciSlotKustom = arrayOf("kustom", "kustom2", "kustom3")
    private val titikKurvaHz = floatArrayOf(60f, 150f, 400f, 1000f, 2500f, 6000f, 12000f)
    private val kurvaPreset: Map<String, FloatArray> = mapOf(
        "vocal" to floatArrayOf(-3f, -1f, 1f, 3f, 5f, 3f, 1f),
        "bass" to floatArrayOf(6f, 5f, 2f, 0f, -1f, -2f, -2f),
        "treble" to floatArrayOf(-3f, -2f, -1f, 0f, 3f, 5f, 6f),
        "jernih" to floatArrayOf(-4f, -3f, -1f, 1f, 4f, 4f, 2f),
        "hangat" to floatArrayOf(2f, 3f, 2f, 0f, -2f, -3f, -4f),
        "malam" to floatArrayOf(-3f, -1f, 0f, 0f, -1f, -3f, -5f),
        "speaker" to floatArrayOf(-5f, -2f, 1f, 3f, 3f, 2f, 0f)
    )

    private fun kunciPresetSah(k: String?): Boolean =
        k != null && (k in kunciPresetBawaan || k in kunciSlotKustom || (k.startsWith("dev_") && k.removePrefix("dev_").toIntOrNull() != null))

    private fun kunciPrefKustom(slot: String): String = when (slot) {
        "kustom2" -> "equalizer_kustom2_mb"
        "kustom3" -> "equalizer_kustom3_mb"
        else -> "equalizer_kustom_mb"
    }

    private fun adaDataKustom(slot: String): Boolean = !(dataPrefs.getString(kunciPrefKustom(slot), "") ?: "").isBlank()

    private fun labelPreset(k: String): String = when (k) {
        "normal" -> tr("Normal (mati)", "Normal (off)")
        "vocal" -> tr("Vokal / bacaan", "Vocal / recitation")
        "bass" -> "Bass"
        "treble" -> "Treble"
        "jernih" -> tr("Jernih (kata lebih jelas)", "Clear (sharper words)")
        "hangat" -> tr("Hangat (suara lembut)", "Warm (soft sound)")
        "malam" -> tr("Malam (halus, tidak tajam)", "Night (smooth, not harsh)")
        "speaker" -> tr("Speaker ponsel (kompensasi speaker kecil)", "Phone speaker (small-speaker compensation)")
        "kustom" -> tr("Kustom 1", "Custom 1")
        "kustom2" -> tr("Kustom 2", "Custom 2")
        "kustom3" -> tr("Kustom 3", "Custom 3")
        else -> {
            val n = k.removePrefix("dev_").toIntOrNull() ?: 0
            val nama = try { equalizerAudio?.getPresetName(n.toShort()) } catch (_: Exception) { null }
            tr("Bawaan perangkat: ", "Device preset: ") + (if (nama.isNullOrBlank()) tr("nomor ", "number ") + (n + 1) else nama)
        }
    }

    private fun persenBass(): Int = dataPrefs.getInt("efek_bass_persen", 0).coerceIn(0, 100)
    private fun persenSpasial(): Int = dataPrefs.getInt("efek_spasial_persen", 0).coerceIn(0, 100)
    private fun dbPenguat(): Int = dataPrefs.getInt("efek_penguat_db", 0).coerceIn(0, 10)

    /** Buat sesi audio bersama bila belum ada. */
    private fun pastikanSesiAudio(): Boolean {
        if (sesiAudioEfek > 0) return true
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            sesiAudioEfek = am.generateAudioSessionId()
            if (sesiAudioEfek <= 0) {
                sesiAudioEfek = 0
                statusEqualizer = tr("gagal membuat sesi audio", "failed to create audio session")
                false
            } else true
        } catch (e: Exception) {
            sesiAudioEfek = 0
            statusEqualizer = tr("gagal membuat sesi audio: ", "failed to create audio session: ") + e.javaClass.simpleName
            false
        }
    }

    /** Buat Equalizer pada sesi bersama bila belum ada. */
    private fun pastikanEfekAudio(): Boolean {
        if (equalizerAudio != null) return true
        if (!pastikanSesiAudio()) return false
        return try {
            equalizerAudio = Equalizer(0, sesiAudioEfek)
            true
        } catch (e: Exception) {
            statusEqualizer = tr("tidak didukung: ", "not supported: ") + e.javaClass.simpleName
            equalizerAudio = null
            false
        }
    }

    private fun lepasEfekAudio() {
        try { equalizerAudio?.release() } catch (_: Exception) { }
        equalizerAudio = null
        try { bassBoostAudio?.release() } catch (_: Exception) { }
        bassBoostAudio = null
        try { virtualizerAudio?.release() } catch (_: Exception) { }
        virtualizerAudio = null
        try { penguatSuaraAudio?.release() } catch (_: Exception) { }
        penguatSuaraAudio = null
        sesiAudioEfek = 0
    }

    /** Penguatan (dB) preset pada frekuensi tertentu; interpolasi halus pada skala logaritmik, tidak bergantung jumlah pita. */
    private fun gainPresetDb(preset: String, hz: Float): Float {
        val kurva = kurvaPreset[preset] ?: return 0f
        val x = hz.coerceAtLeast(1f)
        if (x <= titikKurvaHz.first()) return kurva.first()
        if (x >= titikKurvaHz.last()) return kurva.last()
        for (i in 0 until titikKurvaHz.size - 1) {
            if (x <= titikKurvaHz[i + 1]) {
                val a = Math.log10(titikKurvaHz[i].toDouble())
                val b = Math.log10(titikKurvaHz[i + 1].toDouble())
                val t = (Math.log10(x.toDouble()) - a) / (b - a)
                return (kurva[i] + (kurva[i + 1] - kurva[i]) * t).toFloat()
            }
        }
        return kurva.last()
    }

    private fun levelKustomTersimpan(jumlahBand: Int, slot: String): IntArray {
        val simpan = (dataPrefs.getString(kunciPrefKustom(slot), "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }
        return IntArray(jumlahBand) { simpan.getOrElse(it) { 0 } }
    }

    private fun labelFrekuensi(eq: Equalizer, band: Int): String {
        val hz = eq.getCenterFreq(band.toShort()) / 1000
        return if (hz >= 1000) String.format(Locale.ROOT, "%.1f kHz", hz / 1000f).replace(".0 kHz", " kHz") else "" + hz + " Hz"
    }

    /** Terapkan preset aktif pada Equalizer, lalu efek tambahan. Mengembalikan true bila semua efek yang diminta sah/aktif. */
    private fun terapkanEqualizer(): Boolean {
        val butuhEq = presetEqualizer != "normal"
        val baikEq = if (!pastikanEfekAudio()) !butuhEq else {
            val eq = equalizerAudio
            if (eq == null) !butuhEq else try { terapkanPitaEqualizer(eq, butuhEq) } catch (e: Exception) {
                statusEqualizer = tr("gagal diterapkan: ", "failed to apply: ") + e.javaClass.simpleName
                false
            }
        }
        val baikTambahan = terapkanEfekTambahan()
        return baikEq && baikTambahan
    }

    private fun terapkanPitaEqualizer(eq: Equalizer, butuhEq: Boolean): Boolean {
        if (!eq.hasControl()) {
            statusEqualizer = tr("efek audio sedang dikendalikan aplikasi lain atau sistem", "audio effects are being controlled by another app or the system")
            return false
        }
        val jumlahBand = eq.numberOfBands.toInt()
        if (jumlahBand <= 0) {
            statusEqualizer = tr("perangkat tidak menyediakan pita equalizer", "the device provides no equalizer bands")
            return false
        }
        val minimum = eq.bandLevelRange[0].toInt()
        val maksimum = eq.bandLevelRange[1].toInt()
        // Aktifkan dahulu: sebagian perangkat mengabaikan perubahan pita saat efek masih nonaktif.
        eq.enabled = butuhEq
        if (presetEqualizer.startsWith("dev_")) {
            val n = presetEqualizer.removePrefix("dev_").toIntOrNull() ?: -1
            if (n < 0 || n >= eq.numberOfPresets.toInt()) {
                statusEqualizer = tr("preset bawaan perangkat tidak ditemukan", "the device preset was not found")
                return false
            }
            eq.usePreset(n.toShort())
        } else {
            val kustom = if (presetEqualizer in kunciSlotKustom) levelKustomTersimpan(jumlahBand, presetEqualizer) else null
            for (i in 0 until jumlahBand) {
                val hz = eq.getCenterFreq(i.toShort()).toFloat() / 1000f
                val mB = if (kustom != null) kustom[i] else Math.round(gainPresetDb(presetEqualizer, hz) * 100f)
                eq.setBandLevel(i.toShort(), mB.coerceIn(minimum, maksimum).toShort())
            }
        }
        statusEqualizer = if (butuhEq) tr("aktif: ", "active: ") + labelPreset(presetEqualizer) else "normal"
        return !butuhEq || eq.enabled
    }

    /** Terapkan Bass tambahan, suara ruang (Virtualizer) dan penguat volume. Mengembalikan true bila semua yang diminta aktif. */
    private fun terapkanEfekTambahan(): Boolean {
        val bassP = if (presetEqualizer == "bass") maxOf(persenBass(), 60) else persenBass()
        val spasialP = persenSpasial()
        val dbP = dbPenguat()
        val catatan = mutableListOf<String>()
        if (sesiAudioEfek <= 0 && (bassP > 0 || spasialP > 0 || dbP > 0) && !pastikanSesiAudio()) {
            statusEfekTambahan = statusEqualizer
            return false
        }
        // Bass
        try {
            if (bassP > 0) {
                if (bassBoostAudio == null) bassBoostAudio = android.media.audiofx.BassBoost(0, sesiAudioEfek)
                val bb = bassBoostAudio
                if (bb != null && bb.strengthSupported) {
                    bb.setStrength((bassP * 10).coerceIn(0, 1000).toShort())
                    bb.enabled = true
                } else {
                    try { bb?.enabled = false } catch (_: Exception) { }
                    catatan.add(tr("bass tambahan tidak didukung perangkat", "extra bass is not supported by the device"))
                }
            } else {
                bassBoostAudio?.enabled = false
            }
        } catch (e: Exception) {
            try { bassBoostAudio?.release() } catch (_: Exception) { }
            bassBoostAudio = null
            if (bassP > 0) catatan.add(tr("bass tambahan gagal: ", "extra bass failed: ") + e.javaClass.simpleName)
        }
        // Suara ruang
        try {
            if (spasialP > 0) {
                if (virtualizerAudio == null) virtualizerAudio = android.media.audiofx.Virtualizer(0, sesiAudioEfek)
                val vz = virtualizerAudio
                if (vz != null && vz.strengthSupported) {
                    vz.setStrength((spasialP * 10).coerceIn(0, 1000).toShort())
                    vz.enabled = true
                } else {
                    try { vz?.enabled = false } catch (_: Exception) { }
                    catatan.add(tr("suara ruang tidak didukung perangkat", "spatial sound is not supported by the device"))
                }
            } else {
                virtualizerAudio?.enabled = false
            }
        } catch (e: Exception) {
            try { virtualizerAudio?.release() } catch (_: Exception) { }
            virtualizerAudio = null
            if (spasialP > 0) catatan.add(tr("suara ruang gagal: ", "spatial sound failed: ") + e.javaClass.simpleName)
        }
        // Penguat volume
        try {
            if (dbP > 0) {
                if (penguatSuaraAudio == null) penguatSuaraAudio = android.media.audiofx.LoudnessEnhancer(sesiAudioEfek)
                penguatSuaraAudio?.let { it.setTargetGain(dbP * 100); it.enabled = true }
            } else {
                penguatSuaraAudio?.enabled = false
            }
        } catch (e: Exception) {
            try { penguatSuaraAudio?.release() } catch (_: Exception) { }
            penguatSuaraAudio = null
            if (dbP > 0) catatan.add(tr("penguat volume gagal: ", "volume booster failed: ") + e.javaClass.simpleName)
        }
        statusEfekTambahan = catatan.joinToString("; ")
        return catatan.isEmpty()
    }

    private fun ringkasanEfek(): String {
        val b = persenBass()
        val s = persenSpasial()
        val d = dbPenguat()
        val bagian = mutableListOf<String>()
        bagian.add(tr("Preset: ", "Preset: ") + labelPreset(presetEqualizer))
        bagian.add(if (b > 0) tr("Bass tambahan ", "Extra bass ") + b + tr(" persen", " percent") else tr("Bass tambahan mati", "Extra bass off"))
        bagian.add(if (s > 0) tr("Suara ruang ", "Spatial sound ") + s + tr(" persen", " percent") else tr("Suara ruang mati", "Spatial sound off"))
        bagian.add(if (d > 0) tr("Penguat volume tambah ", "Volume booster plus ") + d + " dB" else tr("Penguat volume mati", "Volume booster off"))
        var hasil = bagian.joinToString(". ") + "."
        if (statusEfekTambahan.isNotBlank()) hasil += " " + tr("Catatan: ", "Note: ") + statusEfekTambahan + "."
        return hasil
    }

    private fun simpanPreset(kunci: String) {
        presetEqualizer = kunci
        dataPrefs.edit().putString("preset_equalizer_audio", kunci).apply()
    }

    /** Menu utama Equalizer: preset, pengaturan manual, efek tambahan, ringkasan, setel ulang. */
    private fun pengaturanEqualizer() {
        val ada = pastikanEfekAudio()
        val info = if (ada) {
            tr("Perangkat menyediakan ", "This device provides ") + (equalizerAudio?.numberOfBands?.toInt() ?: 0) + tr(" pita equalizer. Pilihan langsung berlaku, juga pada audio yang sedang diputar.", " equalizer bands. Your choice applies immediately, including audio that is playing.")
        } else tr("Equalizer pita tidak tersedia di perangkat ini (", "Band equalizer is not available on this device (") + statusEqualizer.ifBlank { tr("belum aktif", "not active yet") } + tr("). Efek tambahan mungkin masih dapat dipakai. Pemutaran tetap berjalan.", "). Extra effects may still work. Playback continues.")
        val daftar = mutableListOf<Pair<String, () -> Unit>>()
        daftar.add(tr("Pilih preset suara. Sekarang: ", "Choose a sound preset. Now: ") + labelPreset(presetEqualizer) to { dialogPilihPreset() })
        daftar.add(tr("Atur manual tiap pita (Kustom 1, 2, atau 3)", "Adjust each band manually (Custom 1, 2 or 3)") to { dialogPilihSlotKustom() })
        daftar.add(tr("Efek tambahan: bass, suara ruang, penguat volume", "Extra effects: bass, spatial sound, volume booster") to { dialogEfekTambahan() })
        daftar.add(tr("Dengar ringkasan efek yang sedang aktif", "Hear a summary of the active effects") to {
            val r = ringkasanEfek()
            toast(r); perbaruiStatusAudio(r)
            handler.post { pengaturanEqualizer() }
        })
        daftar.add(tr("Setel ulang semua efek ke normal", "Reset all effects to normal") to {
            simpanPreset("normal")
            dataPrefs.edit().putInt("efek_bass_persen", 0).putInt("efek_spasial_persen", 0).putInt("efek_penguat_db", 0).apply()
            terapkanEqualizer()
            val pesan = tr("Semua efek dikembalikan ke normal. Pengaturan kustom tetap tersimpan.", "All effects reset to normal. Custom settings are kept.")
            toast(pesan); perbaruiStatusAudio(pesan)
            handler.post { pengaturanEqualizer() }
        })
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Equalizer audio", "Audio equalizer"), info))
            .setItems(daftar.map { it.first }.toTypedArray()) { _, which -> daftar.getOrNull(which)?.second?.invoke() }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { dialogPengaturanAudio() } }
            .setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    /** Daftar preset: bawaan aplikasi, tiga slot kustom, dan preset bawaan perangkat bila ada. */
    private fun dialogPilihPreset() {
        pastikanEfekAudio()
        val kunci = mutableListOf<String>()
        kunci.addAll(kunciPresetBawaan)
        kunci.addAll(kunciSlotKustom)
        try {
            val eq = equalizerAudio
            if (eq != null) for (n in 0 until eq.numberOfPresets.toInt()) kunci.add("dev_" + n)
        } catch (_: Exception) { }
        val labels = kunci.map { k ->
            if (k in kunciSlotKustom) labelPreset(k) + (if (adaDataKustom(k)) tr(" (tersimpan)", " (saved)") else tr(" (kosong, atur dahulu)", " (empty, set it first)")) else labelPreset(k)
        }.toTypedArray()
        val selected = kunci.indexOf(presetEqualizer).coerceAtLeast(0)
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Preset equalizer", "Equalizer preset"), tr("Pilihan langsung berlaku, juga pada audio yang sedang diputar.", "Your choice applies immediately, including audio that is playing.")))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in kunci.indices) {
                    val k = kunci[which]
                    dialog.dismiss()
                    if (k in kunciSlotKustom && !adaDataKustom(k)) {
                        handler.post { dialogEqualizerKustom(k) }
                        return@setSingleChoiceItems
                    }
                    simpanPreset(k)
                    val berhasil = terapkanEqualizer()
                    val pesanEq = if (berhasil) tr("Equalizer: ", "Equalizer: ") + labelPreset(k) else tr("Preset disimpan, tetapi tidak dapat diaktifkan: ", "Preset saved but could not be activated: ") + statusEqualizer.ifBlank { statusEfekTambahan }
                    toast(pesanEq)
                    perbaruiStatusAudio(pesanEq)
                    handler.post { pengaturanEqualizer() }
                }
            }.setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { pengaturanEqualizer() } }
            .setOnCancelListener { handler.post { pengaturanEqualizer() } }.show()
    }

    private fun dialogPilihSlotKustom() {
        val labels = kunciSlotKustom.map { labelPreset(it) + (if (adaDataKustom(it)) tr(" (tersimpan)", " (saved)") else tr(" (kosong)", " (empty)")) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih slot kustom", "Choose a custom slot"))
            .setItems(labels) { _, which -> handler.post { dialogEqualizerKustom(kunciSlotKustom[which]) } }
            .setNegativeButton(tr("Kembali", "Back")) { _, _ -> handler.post { pengaturanEqualizer() } }
            .setOnCancelListener { handler.post { pengaturanEqualizer() } }.show()
    }

    /** Pengaturan kustom: satu penggeser per pita (langkah 1 dB), langsung terdengar saat digeser; dapat diisi dari preset. */
    private fun dialogEqualizerKustom(slot: String = "kustom") {
        if (!pastikanEfekAudio()) {
            toast(tr("Equalizer pita tidak tersedia di perangkat ini.", "Band equalizer is not available on this device."))
            handler.post { pengaturanEqualizer() }
            return
        }
        val eq = equalizerAudio ?: run { handler.post { pengaturanEqualizer() }; return }
        val jumlahBand = eq.numberOfBands.toInt()
        if (jumlahBand <= 0) { toast(tr("Perangkat tidak menyediakan pita equalizer.", "This device has no equalizer bands.")); handler.post { pengaturanEqualizer() }; return }
        val minimum = eq.bandLevelRange[0].toInt()
        val maksimum = eq.bandLevelRange[1].toInt()
        val langkahMax = ((maksimum - minimum) / 100).coerceAtLeast(1)
        val level = levelKustomTersimpan(jumlahBand, slot)
        fun teksDb(mB: Int): String = String.format(Locale.ROOT, "%+d dB", mB / 100)
        val isi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        val bars = mutableListOf<android.widget.SeekBar>()
        try { eq.enabled = true } catch (_: Exception) { }
        val tombolIsi = android.widget.Button(this).apply {
            text = tr("Isi dari preset…", "Fill from a preset…")
            contentDescription = tr("Isi semua penggeser dari salah satu preset sebagai titik awal", "Fill all sliders from one of the presets as a starting point")
        }
        isi.addView(tombolIsi)
        for (i in 0 until jumlahBand) {
            val nama = labelFrekuensi(eq, i)
            val label = TextView(this).apply { textSize = 16f; setPadding(0, dp(12), 0, 0) }
            val bar = android.widget.SeekBar(this).apply {
                max = langkahMax
                progress = ((level[i].coerceIn(minimum, maksimum) - minimum) / 100).coerceIn(0, langkahMax)
            }
            fun perbarui() {
                val teks = nama + ": " + teksDb(level[i])
                label.text = teks
                bar.contentDescription = teks
            }
            perbarui()
            bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                    level[i] = (minimum + progress * 100).coerceIn(minimum, maksimum)
                    perbarui()
                    if (fromUser) try { equalizerAudio?.setBandLevel(i.toShort(), level[i].toShort()) } catch (_: Exception) { }
                }
                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) { seekBar?.announceForAccessibility(label.text) }
            })
            bars.add(bar)
            isi.addView(label)
            isi.addView(bar)
        }
        val gulir = android.widget.ScrollView(this).apply { addView(isi) }
        val dialog = AlertDialog.Builder(this).setTitle(tr("Equalizer ", "Equalizer ") + labelPreset(slot))
            .setView(gulir)
            .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                dataPrefs.edit().putString(kunciPrefKustom(slot), level.joinToString(",")).apply()
                simpanPreset(slot)
                val berhasil = terapkanEqualizer()
                val pesan = if (berhasil) labelPreset(slot) + tr(" disimpan dan aktif.", " saved and active.") else tr("Disimpan, tetapi tidak dapat diaktifkan: ", "Saved but could not be activated: ") + statusEqualizer
                toast(pesan); perbaruiStatusAudio(pesan)
                handler.post { pengaturanEqualizer() }
            }
            .setNeutralButton(tr("Setel ulang", "Reset"), null)
            .setNegativeButton(tr("Batal", "Cancel")) { _, _ -> terapkanEqualizer(); handler.post { pengaturanEqualizer() } }
            .setOnCancelListener { terapkanEqualizer(); handler.post { pengaturanEqualizer() } }
            .create()
        dialog.show()
        tombolIsi.setOnClickListener {
            AlertDialog.Builder(this).setTitle(tr("Isi dari preset", "Fill from preset"))
                .setItems(kunciPresetBawaan.map { labelPreset(it) }.toTypedArray()) { _, which ->
                    val k = kunciPresetBawaan[which]
                    for (i in 0 until jumlahBand) {
                        val hz = eq.getCenterFreq(i.toShort()).toFloat() / 1000f
                        val mB = (Math.round(gainPresetDb(k, hz)) * 100).coerceIn(minimum, maksimum)
                        val kemajuan = Math.round((mB - minimum) / 100f).coerceIn(0, langkahMax)
                        bars[i].progress = kemajuan
                        level[i] = (minimum + kemajuan * 100).coerceIn(minimum, maksimum)
                        try { eq.setBandLevel(i.toShort(), level[i].toShort()) } catch (_: Exception) { }
                    }
                    dialog.window?.decorView?.announceForAccessibility(tr("Penggeser diisi dari preset ", "Sliders filled from preset ") + labelPreset(k) + tr(". Ubah sesuai selera lalu tekan Simpan.", ". Adjust to taste, then press Save."))
                }.setNegativeButton(tr("Batal", "Cancel"), null).show()
        }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            for (i in 0 until jumlahBand) {
                level[i] = 0.coerceIn(minimum, maksimum)
                try { eq.setBandLevel(i.toShort(), level[i].toShort()) } catch (_: Exception) { }
                bars[i].progress = ((level[i] - minimum) / 100).coerceIn(0, langkahMax)
            }
            dialog.window?.decorView?.announceForAccessibility(tr("Semua pita dikembalikan ke 0 dB.", "All bands reset to 0 dB."))
        }
    }

    /** Efek tambahan: bass tambahan, suara ruang (Virtualizer), penguat volume. Perubahan langsung tersimpan dan terdengar. */
    private fun dialogEfekTambahan() {
        pastikanSesiAudio()
        val isi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        isi.addView(TextView(this).apply {
            textSize = 15f
            text = tr(
                "Efek ini bekerja bersama preset dan langsung terdengar. Naikkan perlahan: penguat volume yang terlalu tinggi dapat membuat suara pecah dan tidak nyaman di telinga. Suara ruang paling terasa pada headphone. Efek hanya berlaku pada audio murattal dan audio terjemahan berupa berkas, bukan pada suara mesin pembaca (Text-to-Speech).",
                "These effects work together with the preset and are heard immediately. Raise them gradually: a very high volume booster can distort and be uncomfortable. Spatial sound is most noticeable on headphones. They apply only to murattal and file-based translation audio, not to the text-to-speech voice."
            )
        })
        val bars = mutableListOf<android.widget.SeekBar>()
        fun tambah(nama: String, satuan: String, langkahMax: Int, kelipatan: Int, awal: Int, simpan: (Int) -> Unit) {
            val label = TextView(this).apply { textSize = 16f; setPadding(0, dp(14), 0, 0) }
            val bar = android.widget.SeekBar(this).apply { max = langkahMax; progress = (awal / kelipatan).coerceIn(0, langkahMax) }
            fun perbarui(nilai: Int) {
                val teks = nama + ": " + (if (nilai == 0) tr("mati", "off") else "" + nilai + satuan)
                label.text = teks
                bar.contentDescription = teks
            }
            perbarui(bar.progress * kelipatan)
            bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                    perbarui(progress * kelipatan)
                    if (fromUser) { simpan(progress * kelipatan); terapkanEfekTambahan() }
                }
                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {
                    seekBar?.announceForAccessibility(label.text)
                    if (statusEfekTambahan.isNotBlank()) seekBar?.announceForAccessibility(statusEfekTambahan)
                }
            })
            bars.add(bar)
            isi.addView(label)
            isi.addView(bar)
        }
        tambah(tr("Bass tambahan", "Extra bass"), "%", 10, 10, persenBass()) { dataPrefs.edit().putInt("efek_bass_persen", it).apply() }
        tambah(tr("Suara ruang", "Spatial sound"), "%", 10, 10, persenSpasial()) { dataPrefs.edit().putInt("efek_spasial_persen", it).apply() }
        tambah(tr("Penguat volume", "Volume booster"), " dB", 10, 1, dbPenguat()) { dataPrefs.edit().putInt("efek_penguat_db", it).apply() }
        val gulir = android.widget.ScrollView(this).apply { addView(isi) }
        val dialog = AlertDialog.Builder(this).setTitle(tr("Efek tambahan", "Extra effects"))
            .setView(gulir)
            .setPositiveButton(tr("Selesai", "Done")) { _, _ ->
                val r = ringkasanEfek()
                toast(r); perbaruiStatusAudio(r)
                handler.post { pengaturanEqualizer() }
            }
            .setNeutralButton(tr("Matikan semua", "Turn all off"), null)
            .setOnCancelListener { handler.post { pengaturanEqualizer() } }
            .create()
        terapkanEfekTambahan()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            dataPrefs.edit().putInt("efek_bass_persen", 0).putInt("efek_spasial_persen", 0).putInt("efek_penguat_db", 0).apply()
            bars.forEach { it.progress = 0 }
            terapkanEfekTambahan()
            dialog.window?.decorView?.announceForAccessibility(tr("Semua efek tambahan dimatikan.", "All extra effects turned off."))
        }
    }

    // ====================================================================================
    // KOREKSI HAFALAN (FIX46)
    // Dua jalur: (1) koreksi otomatis dengan pengenalan suara, (2) latihan mandiri tanpa mikrofon.
    // Keduanya selalu dijalankan dari layar pembaca supaya teks ayat benar-benar dapat disembunyikan.
    // ====================================================================================

    private data class KataArab(val tampil: String, val kunci: String)
    /** FIX104: hasil diagnosis tingkat kata: indeks kata ayat yang salah/terlewat dan teksnya. */
    private data class KataBermasalah(val indeks: Set<Int>, val kata: List<String>)
    private val indeksSalahSementara = mutableSetOf<Int>()
    private var kataBermasalahTerakhir = KataBermasalah(emptySet(), emptyList())
    /** Jumlah gagal berturut-turut per ayat dalam sesi koreksi yang sedang terbuka ("surah:ayat"). */
    private val gagalBerturut = HashMap<String, Int>()
    private var koreksiUlangSisa = 0

    private var ayatTerbukaKoreksi = false
    private var hasilKoreksiTampil = false
    /** FIX102: true saat audio ayat yang benar sedang diputar sebagai koreksi otomatis (tidak boleh menutup dialog koreksi). */
    private var koreksiAudioAktif = false
    private var ayatUlasan: Pair<Int, Int>? = null
    private var sedangMendengarkanHafalan = false
    private var sudahCobaJalurSistem = false

    /** Pastikan layar pembaca tampil dengan ayat aktif. Mengembalikan false jika teks belum ada. */
    private fun pastikanDiPembaca(): Boolean {
        // FIX103: ulasan hafalan memakai ayat jatuh tempo yang dipilih, tanpa mengubah posisi bacaan terakhir yang tersimpan.
        val ulas = ayatUlasan
        ayatUlasan = null
        if (ulas != null) { nomorSurah = ulas.first; nomorAyat = ulas.second }
        // Dibuka dari menu utama: pakai posisi bacaan terakhir yang tersimpan.
        else if (!sedangDiPembaca) {
            nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1, 114)
            nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        }
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return false }
        if (getAyat(nomorSurah, nomorAyat) == null) {
            toast(tr("Teks ayat belum tersedia. Unduh teks Al-Qur'an terlebih dahulu.", "Verse text is unavailable. Download Qur'an text first."))
            return false
        }
        // FIX105: bila ayat ulasan berganti (sesi muraja'ah berurutan), pembaca harus digambar ulang.
        if (!sedangDiPembaca || ayatArab == null || ulas != null) tampilkanPembaca()
        return ayatArab != null
    }

    private fun sembunyikanAyatLatihan() {
        latihanHafalanAktif = true
        ayatTerbukaKoreksi = false
        ayatArab?.visibility = android.view.View.INVISIBLE
        ayatArti?.visibility = android.view.View.GONE
    }

    private fun tampilkanAyatLatihan() {
        latihanHafalanAktif = false
        ayatTerbukaKoreksi = true
        ayatArab?.visibility = android.view.View.VISIBLE
        ayatArti?.visibility = if (tampilkanArti) android.view.View.VISIBLE else android.view.View.GONE
    }

    // Mode senyap TalkBack (FIX50): selama mikrofon bersiap/mendengarkan, isi dialog disembunyikan dari TalkBack,
    // pengumuman dimatikan, dan ucapan TalkBack yang sedang berjalan diinterupsi agar tidak tertangkap mikrofon.
    private var modaSenyapKoreksi = false
    private var isiKoreksiHafalan: android.view.View? = null
    private var penundaMulaiKoreksi: Runnable? = null

    private fun talkBackAktif(): Boolean = try {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        am.isEnabled && am.isTouchExplorationEnabled
    } catch (_: Exception) { false }

    private fun senyapkanTalkBack(aktif: Boolean) {
        modaSenyapKoreksi = aktif
        isiKoreksiHafalan?.importantForAccessibility = if (aktif) android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS else android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        if (aktif) {
            try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
        }
    }

    /** Isyarat getar sebagai pengganti pengumuman suara saat mikrofon siap. */
    private fun getarIsyarat(ms: Long) {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun setStatusKoreksi(pesan: CharSequence, umumkan: Boolean = true) {
        val tv = statusKoreksiHafalan ?: return
        tv.text = pesan
        if (umumkan && !modaSenyapKoreksi) tv.announceForAccessibility(pesan)
    }

    /** Pemeriksaan urutan kata dengan layanan pengenalan suara Android. Ini bukan penilaian tajwid. */
    private fun mulaiKoreksiOtomatisHafalan() {
        if (!dataPrefs.getBoolean("hafalan_koreksi_suara_aktif", true)) { toast(tr("Fitur ini dinonaktifkan. Aktifkan di Pengaturan Hafalan.", "This feature is turned off. Turn it on in Memorization Settings.")); return }
        if (!pastikanDiPembaca()) return
        val layananSuaraAda = try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
        val dialogSistemAda = try { packageManager.queryIntentActivities(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).isNotEmpty() } catch (_: Exception) { false }
        if (!layananSuaraAda && !dialogSistemAda) {
            AlertDialog.Builder(this).setTitle(tr("Pengenalan suara tidak tersedia", "Speech recognition unavailable"))
                .setMessage(tr("HP ini belum menyediakan layanan pengenalan suara. Pasang atau aktifkan layanan suara (misalnya aplikasi Google) di Pengaturan Android. Anda tetap dapat memakai Latihan koreksi mandiri tanpa mikrofon.", "This phone has no speech recognition service. Install or enable a speech service (for example the Google app) in Android settings. You can still use the self-check practice without a microphone."))
                .setPositiveButton(tr("Buka latihan mandiri", "Open self-check practice")) { _, _ -> handler.post { latihanKoreksiHafalan() } }
                .setNegativeButton(tr("Tutup", "Close"), null)
                .show()
            return
        }
        val isi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        val petunjuk = TextView(this).apply {
            text = tr("Ayat yang diperiksa: surah ", "Verse to check: surah ") + nomorSurah +
                tr(", ayat ", ", verse ") + nomorAyat + tr(".\n\nTekan Mulai membaca, lalu bacalah ayat dengan jelas dari hafalan. Setelah Anda berhenti, bacaan diubah menjadi teks dan urutan katanya dibandingkan dengan ayat.\n\nPemeriksaan ini hanya perkiraan untuk menemukan kata yang mungkin terlewat, berubah, atau bertambah. Pengenalan suara bisa keliru. Fitur ini TIDAK menilai tajwid, makhraj, panjang-pendek, sifat huruf, atau kualitas bacaan. Suara diproses oleh layanan pengenalan suara di HP dan mungkin memerlukan internet.", ".\n\nPress Start reciting and recite the verse clearly from memory. When you stop, the speech is converted to text and its word order is compared with the verse.\n\nThis is an estimate to find words that may be omitted, changed, or added. Speech recognition can be wrong. It does NOT assess tajwid, articulation, elongation, letter qualities, or recitation quality. Audio is processed by the speech service on your phone and may require internet.")
            textSize = 16f
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        statusKoreksiHafalan = TextView(this).apply {
            text = tr("Status: belum dimulai.", "Status: not started.")
            textSize = 16f
            setPadding(0, dp(16), 0, dp(8))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        isi.addView(petunjuk)
        isi.addView(statusKoreksiHafalan)
        val gulir = android.widget.ScrollView(this).apply { addView(isi) }
        isiKoreksiHafalan = gulir
        modaSenyapKoreksi = false
        hasilKoreksiTampil = false
        sedangMendengarkanHafalan = false
        val dialog = AlertDialog.Builder(this)
            .setTitle(tr("Koreksi hafalan dengan suara", "Voice-assisted memorization check"))
            .setView(gulir)
            .setPositiveButton(tr("Mulai membaca", "Start reciting"), null)
            .setNeutralButton(tr("Hentikan", "Stop"), null)
            .setNegativeButton(tr("Tutup", "Close"), null)
            .create()
        dialogKoreksiHafalan = dialog
        dialog.setOnDismissListener {
            try { speechRecognizerHafalan?.cancel(); speechRecognizerHafalan?.destroy() } catch (_: Exception) { }
            speechRecognizerHafalan = null
            penundaMulaiKoreksi?.let { handler.removeCallbacks(it) }
            penundaMulaiKoreksi = null
            senyapkanTalkBack(false)
            isiKoreksiHafalan = null
            sedangMendengarkanHafalan = false
            hasilKoreksiTampil = false
            tampilkanAyatLatihan()
            latihanHafalanAktif = false
            statusKoreksiHafalan = null
            dialogKoreksiHafalan = null
            gagalBerturut.clear()
            if (koreksiAudioAktif) hentikanAudio()
            if (sesiAktif()) handler.post { setelahDialogKoreksiSesi() }
        }
        sembunyikanAyatLatihan()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 6905)
            } else mulaiPengenalanBacaanAyat()
        }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val tombolLain = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
            if (hasilKoreksiTampil) {
                if (ayatTerbukaKoreksi) {
                    sembunyikanAyatLatihan()
                    tombolLain.text = tr("Tampilkan ayat", "Reveal verse")
                    ayatArab?.announceForAccessibility(tr("Ayat disembunyikan.", "Verse hidden."))
                } else {
                    tampilkanAyatLatihan()
                    tombolLain.text = tr("Sembunyikan ayat", "Hide verse")
                    ayatArab?.announceForAccessibility(tr("Teks ayat ditampilkan.", "Verse text revealed."))
                }
            } else {
                try { speechRecognizerHafalan?.cancel() } catch (_: Exception) { }
                penundaMulaiKoreksi?.let { handler.removeCallbacks(it) }
                penundaMulaiKoreksi = null
                sedangMendengarkanHafalan = false
                senyapkanTalkBack(false)
                setStatusKoreksi(tr("Status: perekaman dihentikan. Tekan Mulai membaca untuk mencoba lagi.", "Status: listening stopped. Press Start reciting to try again."))
            }
        }
    }

    /** Titik masuk: senyapkan TalkBack lebih dulu, beri jeda ±1 detik, baru mikrofon dibuka. */
    private fun mulaiPengenalanBacaanAyat() {
        if (statusKoreksiHafalan == null) return
        senyapkanTalkBack(true)
        penundaMulaiKoreksi?.let { handler.removeCallbacks(it) }
        val r = Runnable { penundaMulaiKoreksi = null; mulaiPengenalanSekarang() }
        penundaMulaiKoreksi = r
        handler.postDelayed(r, 1000L)
    }

    private fun mulaiPengenalanSekarang() {
        if (statusKoreksiHafalan == null) return
        senyapkanTalkBack(true)
        hentikanAudio()
        sembunyikanAyatLatihan()
        hasilKoreksiTampil = false
        sudahCobaJalurSistem = false
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_POSITIVE)?.text = tr("Mulai membaca", "Start reciting")
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_NEUTRAL)?.text = tr("Hentikan", "Stop")
        try { speechRecognizerHafalan?.cancel(); speechRecognizerHafalan?.destroy() } catch (_: Exception) { }
        speechRecognizerHafalan = null
        val layananAda = try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
        if (!layananAda) { mulaiPengenalanLewatDialogSistem(); return }
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizerHafalan = recognizer
            sedangMendengarkanHafalan = true
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (speechRecognizerHafalan !== recognizer) return
                    senyapkanTalkBack(true)
                    getarIsyarat(150L)
                    setStatusKoreksi(tr("Mikrofon siap. Silakan mulai membaca ayat sekarang.", "Microphone ready. Start reciting the verse now."))
                }
                override fun onBeginningOfSpeech() {
                    if (speechRecognizerHafalan !== recognizer) return
                    setStatusKoreksi(tr("Bacaan terdeteksi. Silakan lanjutkan sampai selesai.", "Speech detected. Continue until you finish."), false)
                }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() {
                    if (speechRecognizerHafalan !== recognizer) return
                    setStatusKoreksi(tr("Bacaan selesai diterima. Sedang memeriksa urutan kata…", "Recitation received. Checking word order…"))
                }
                override fun onError(error: Int) {
                    if (speechRecognizerHafalan !== recognizer) return
                    sedangMendengarkanHafalan = false
                    // 4=SERVER, 5=CLIENT, 8=BUSY, 11=SERVER_DISCONNECTED, 12=LANGUAGE_NOT_SUPPORTED, 13=LANGUAGE_UNAVAILABLE
                    if (error in listOf(4, 5, 8, 11, 12, 13) && !sudahCobaJalurSistem) {
                        try { recognizer.cancel(); recognizer.destroy() } catch (_: Exception) { }
                        speechRecognizerHafalan = null
                        mulaiPengenalanLewatDialogSistem()
                        return
                    }
                    val pesan = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> tr("Bacaan belum dapat dikenali. Coba di tempat lebih tenang dan baca dengan jelas, lalu tekan Mulai membaca.", "Speech was not recognized. Try a quieter place and speak clearly, then press Start reciting.")
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> tr("Tidak terdengar bacaan. Tekan Mulai membaca untuk mencoba lagi.", "No speech was heard. Press Start reciting to try again.")
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> tr("Izin mikrofon belum diberikan. Aktifkan izin mikrofon untuk aplikasi ini di Pengaturan Android.", "Microphone permission was not granted. Enable the microphone permission for this app in Android settings.")
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> tr("Layanan suara memerlukan internet yang stabil. Periksa koneksi lalu coba lagi.", "The speech service needs a stable internet connection. Check your connection and try again.")
                        SpeechRecognizer.ERROR_AUDIO -> tr("Mikrofon tidak dapat dipakai. Tutup aplikasi lain yang memakai mikrofon lalu coba lagi.", "The microphone could not be used. Close other apps using the microphone and try again.")
                        else -> tr("Layanan pengenalan suara mengalami kendala (kode " + error + "). Coba lagi beberapa saat.", "Speech recognition encountered a problem (code " + error + "). Try again shortly.")
                    }
                    senyapkanTalkBack(false)
                    setStatusKoreksi(pesan)
                    if (!talkBackAktif()) bicaraUmpanBalikKoreksi(pesan)
                }
                override fun onResults(results: Bundle?) {
                    if (speechRecognizerHafalan !== recognizer) return
                    sedangMendengarkanHafalan = false
                    prosesHasilSuara(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty())
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    if (speechRecognizerHafalan !== recognizer) return
                    val sementara = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (sementara.isNotBlank()) setStatusKoreksi(tr("Terdengar sementara:\n", "Heard so far:\n") + teksArabTampil(sementara), false)
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            setStatusKoreksi(tr("Menyiapkan pengenalan suara…", "Preparing speech recognition…"), false)
            recognizer.startListening(buatIntentPengenalan(true))
        } catch (e: Exception) {
            sedangMendengarkanHafalan = false
            mulaiPengenalanLewatDialogSistem()
        }
    }

    private fun buatIntentPengenalan(sebagian: Boolean): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-SA")
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, sebagian)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        putExtra(RecognizerIntent.EXTRA_PROMPT, tr("Bacalah ayat Al-Qur'an", "Recite the Qur'an verse"))
    }

    /** Jalur cadangan: dialog pengenalan suara bawaan sistem (Google/Samsung) bila layanan langsung gagal. */
    @Suppress("DEPRECATION")
    private fun mulaiPengenalanLewatDialogSistem() {
        sudahCobaJalurSistem = true
        try {
            setStatusKoreksi(tr("Membuka layar pengenalan suara sistem. Bacalah ayat setelah layar muncul.", "Opening the system speech screen. Recite the verse once it appears."))
            sedangMendengarkanHafalan = true
            startActivityForResult(buatIntentPengenalan(false), 6906)
        } catch (e: Exception) {
            sedangMendengarkanHafalan = false
            senyapkanTalkBack(false)
            val pesan = tr("Layanan pengenalan suara tidak dapat dibuka di HP ini. Pasang atau perbarui aplikasi Google, atau gunakan Latihan koreksi mandiri tanpa mikrofon.", "Speech recognition could not be opened on this phone. Install or update the Google app, or use the self-check practice without a microphone.")
            setStatusKoreksi(pesan)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 6907) {
            if (resultCode == RESULT_OK) {
                prosesPerintahSuaraPutar(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty())
            } else toast(tr("Perintah suara tidak terdengar. Ketuk tombol dan coba lagi.", "No voice command heard. Tap the button and try again."))
            return
        }
        if (requestCode == 6906) {
            sedangMendengarkanHafalan = false
            if (statusKoreksiHafalan == null) return
            if (resultCode == RESULT_OK) {
                prosesHasilSuara(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty())
            } else {
                senyapkanTalkBack(false)
                setStatusKoreksi(tr("Tidak ada hasil pengenalan suara. Tekan Mulai membaca untuk mencoba lagi.", "No speech result. Press Start reciting to try again."))
            }
        }
    }

    private fun prosesHasilSuara(kandidat: List<String>) {
        if (statusKoreksiHafalan == null) return
        val teksAcuan = teksArabTampil(getAyat(nomorSurah, nomorAyat)?.optString("text", "").orEmpty())
        var indeksSalah = KataBermasalah(emptySet(), emptyList())
        val kandidatArab = kandidat.filter { Regex("[\\u0600-\\u06FF]").containsMatchIn(it) }
        val hasil: Triple<Int, String, String> = when {
            kandidat.isEmpty() -> Triple(-1, tr("Tidak ada hasil yang diterima. Silakan ulangi.", "No result was received. Please try again."), tr("Tidak ada hasil. Silakan ulangi.", "No result. Please try again."))
            kandidatArab.isEmpty() -> Triple(-1, tr("Layanan suara mengembalikan teks non-Arab (\"", "The speech service returned non-Arabic text (\"") + kandidat.first() + tr("\"). Tidak ada penilaian yang dibuat. Atur bahasa pengenalan suara HP ke Arab, lalu coba lagi.", "\"). No assessment was made. Set the phone's speech recognition language to Arabic and try again."), tr("Teks Arab tidak diterima. Periksa bahasa pengenalan suara.", "Arabic text was not returned. Check speech recognition language."))
            else -> kandidatArab.map { k -> val t = bandingkanBacaanAyat(teksAcuan, k); Pair(t, kataBermasalahTerakhir) }
                .filter { it.first.first >= 0 }.minByOrNull { it.first.first }?.let { indeksSalah = it.second; it.first }
                ?: Triple(-1, tr("Hasil suara belum dapat dibandingkan. Silakan ulangi.", "Speech result could not be compared. Please try again."), tr("Hasil belum dapat diperiksa.", "Result could not be checked."))
        }
        val dikenali = kandidatArab.firstOrNull().orEmpty()
        // FIX104: koreksi cerdas menyatu dengan koreksi otomatis yang sudah ada (tanpa fitur ganda).
        val cerdas = dataPrefs.getBoolean("hafalan_koreksi_cerdas_aktif", true)
        val kunciAyat = nomorSurah.toString() + ":" + nomorAyat
        val gagalSebelumnya = gagalBerturut[kunciAyat] ?: 0
        if (hasil.first == 0) gagalBerturut.remove(kunciAyat) else if (hasil.first > 0) gagalBerturut[kunciAyat] = gagalSebelumnya + 1
        val gagalKini = gagalBerturut[kunciAyat] ?: 0
        var tambahan = ""
        if (cerdas && hasil.first > 0 && indeksSalah.kata.isNotEmpty())
            tambahan += tr("\n\nKata yang perlu diperbaiki (ditandai merah pada teks asli): ", "\n\nWords to fix (marked red in the original text): ") + indeksSalah.kata.take(6).joinToString(" · ")
        if (cerdas && hasil.first > 0 && gagalKini >= 2) {
            val kataPertama = pecahKataArab(teksAcuan).firstOrNull()?.tampil.orEmpty()
            tambahan += tr("\nPercobaan ke-" + gagalKini + " pada ayat ini. Petunjuk: ayat dimulai dengan ", "\nAttempt " + gagalKini + " on this verse. Hint: the verse starts with ") + kataPertama +
                tr(". Audio yang benar akan diputar dua kali.", ". The correct audio will play twice.")
        }
        if (cerdas && hasil.first == 0 && gagalSebelumnya > 0)
            tambahan += tr("\n\nAlhamdulillah, berhasil setelah " + (gagalSebelumnya + 1) + " percobaan.", "\n\nWell done, you got it after " + (gagalSebelumnya + 1) + " attempts.")
        val awalan = tr("Teks ayat asli:\n", "Original verse text:\n")
        val pesan: CharSequence = android.text.SpannableStringBuilder(awalan + teksAcuan + "\n\n" +
            (if (dikenali.isNotBlank()) tr("Teks yang dikenali:\n", "Recognized text:\n") + teksArabTampil(dikenali) + "\n\n" else "") + hasil.second + tambahan).also { sb ->
            if (cerdas && hasil.first > 0) {
                val rentang = Regex("\\S+").findAll(teksAcuan).filter { kunciKataArab(it.value).isNotEmpty() }.toList()
                indeksSalah.indeks.forEach { idx ->
                    val m = rentang.getOrNull(idx) ?: return@forEach
                    val a = awalan.length + m.range.first
                    val b = awalan.length + m.range.last + 1
                    sb.setSpan(android.text.style.BackgroundColorSpan(0x66FF5252), a, b, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), a, b, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(android.text.style.UnderlineSpan(), a, b, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }
        // Ayat ditampilkan setelah ada hasil agar pengguna dapat membandingkan langsung.
        tampilkanAyatLatihan()
        hasilKoreksiTampil = true
        senyapkanTalkBack(false)
        if (hasil.first >= 0) {
            catatHasilKoreksiSuara(hasil.first == 0, gagalSebelumnya)
            if (sesiAktif()) dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_NEGATIVE)?.text = tr("Ayat berikutnya", "Next verse")
        }
        val salahBaca = hasil.first > 0 && dataPrefs.getBoolean("hafalan_audio_koreksi_aktif", true)
        if (salahBaca) {
            // FIX102: ucapan panjang tidak dibacakan agar tidak menimpa audio koreksi; teks lengkap tetap tampil di layar.
            setStatusKoreksi(pesan, false)
            statusKoreksiHafalan?.announceForAccessibility(
                if (cerdas && indeksSalah.kata.isNotEmpty()) tr("Ada " + indeksSalah.kata.size + " kata yang perlu diperbaiki: ", indeksSalah.kata.size.toString() + " word(s) to fix: ") + indeksSalah.kata.take(3).joinToString(", ") + tr(". Mendengarkan bacaan yang benar.", ". Playing the correct recitation.")
                else tr("Ada bacaan yang kurang tepat. Mendengarkan bacaan yang benar.", "Part of the recitation was off. Playing the correct recitation."))
        } else setStatusKoreksi(pesan)
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_POSITIVE)?.text = tr("Ulangi membaca", "Recite again")
        dialogKoreksiHafalan?.getButton(AlertDialog.BUTTON_NEUTRAL)?.text = tr("Sembunyikan ayat", "Hide verse")
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(android.os.VibrationEffect.createOneShot(180, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(180)
                }
            }
        } catch (_: Exception) { }
        if (salahBaca) {
            if (!talkBackAktif()) bicaraUmpanBalikKoreksi(tr("Ada bacaan yang kurang tepat. Dengarkan bacaan yang benar.", "Part of the recitation was off. Listen to the correct recitation."))
            handler.postDelayed({ if (statusKoreksiHafalan != null) putarAudioKoreksiAyat(if (cerdas && gagalKini >= 2) 1 else 0) }, if (cerdas && indeksSalah.kata.isNotEmpty()) 4500L else 2800L)
        } else if (!talkBackAktif()) bicaraUmpanBalikKoreksi(hasil.third)
    }

    /**
     * FIX102: memutar audio ayat yang benar (ayat yang sedang dilatih) sebagai koreksi langsung saat salah baca.
     * Qari MP3Quran hanya punya audio per surah, jadi koreksi memakai qari per ayat (Alafasy) tanpa mengubah pilihan qari.
     */
    private fun putarAudioKoreksiAyat(ulang: Int = 0) {
        if (statusKoreksiHafalan == null) return
        hentikanAudio()
        koreksiUlangSisa = ulang
        val idQari = if (qariId.startsWith("mp3quran|")) "ar.alafasy" else qariId
        audioSedangAyat = false
        audioSedangJuz = false
        koreksiAudioAktif = true
        tombolAudioAktif = tombolAudioAyat
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + idQari + "/" + nomorAyatGlobal() + ".mp3"
        pesanAudioAyatAktif = tr("Memutar bacaan yang benar, ayat ", "Playing the correct recitation, verse ") + nomorSurah + ":" + nomorAyat
        setStatusKoreksi(pesanAudioAyatAktif, false)
        mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif)
    }

    private fun bicaraUmpanBalikKoreksi(pesan: String) {
        if (!ttsSiap || pesan.isBlank()) return
        try { ttsTerjemahan?.speak(pesan, TextToSpeech.QUEUE_FLUSH, null, "koreksi_" + UUID.randomUUID()) } catch (_: Exception) { }
    }

    /** Pastikan teks mushaf yang ditampilkan adalah karakter Arab, bukan literal escape/HTML entity. */
    private fun teksArabTampil(teks: String): String {
        var hasil = teks.trim()
        try { hasil = android.text.Html.fromHtml(hasil, android.text.Html.FROM_HTML_MODE_LEGACY).toString() } catch (_: Exception) { }
        hasil = Regex("\\\\u([0-9a-fA-F]{4})").replace(hasil) { m -> m.groupValues[1].toInt(16).toChar().toString() }
        return hasil.trim()
    }

    /**
     * Kunci perbandingan kata: tanpa harakat/tanda baca mushaf, bentuk hamzah/alif disamakan, dan alif di tengah kata
     * dibuang agar ejaan mushaf (العٰلمين) dan ejaan hasil pengenalan suara (العالمين) dianggap sama.
     * Hanya untuk perbandingan kasar; bukan penilaian harakat atau tajwid.
     */
    private fun kunciKataArab(kata: String): String {
        var k = java.text.Normalizer.normalize(kata, java.text.Normalizer.Form.NFKC)
            .replace(Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]"), "")
            .replace("ـ", "")
            .replace(Regex("[أإآٱ]"), "ا")
            .replace("ؤ", "و").replace("ئ", "ي").replace("ى", "ي").replace("ة", "ه")
            .replace(Regex("[^\\u0621-\\u064A]"), "")
            .replace("ء", "")
        if (k.length > 1) k = k.substring(0, 1) + k.substring(1).replace("ا", "")
        return k
    }

    private fun pecahKataArab(teks: String): List<KataArab> =
        teks.trim().split(Regex("\\s+")).map { KataArab(it, kunciKataArab(it)) }.filter { it.kunci.isNotEmpty() }

    private fun jarakHuruf(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun kataCocok(a: String, b: String): Boolean {
        if (a == b) return true
        val pendek = minOf(a.length, b.length)
        if (pendek < 4) return false
        return jarakHuruf(a, b) <= (if (pendek >= 8) 2 else 1)
    }

    private fun selaraskanKata(expected: List<KataArab>, heard: List<KataArab>): Pair<Int, List<String>> {
        val dp = Array(expected.size + 1) { IntArray(heard.size + 1) }
        for (i in 0..expected.size) dp[i][0] = i
        for (j in 0..heard.size) dp[0][j] = j
        for (i in 1..expected.size) for (j in 1..heard.size) {
            val cost = if (kataCocok(expected[i - 1].kunci, heard[j - 1].kunci)) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
        }
        var i = expected.size
        var j = heard.size
        var jumlah = 0
        val masalah = mutableListOf<String>()
        indeksSalahSementara.clear()
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && kataCocok(expected[i - 1].kunci, heard[j - 1].kunci) && dp[i][j] == dp[i - 1][j - 1]) { i--; j--; continue }
            if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
                jumlah++
                indeksSalahSementara.add(i - 1)
                masalah.add(tr("Kata ke-" + i + " (" + expected[i - 1].tampil + ") mungkin berbeda; terdengar: " + heard[j - 1].tampil + ".", "Word " + i + " (" + expected[i - 1].tampil + ") may differ; heard: " + heard[j - 1].tampil + "."))
                i--; j--; continue
            }
            if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
                jumlah++
                indeksSalahSementara.add(i - 1)
                masalah.add(tr("Kata ke-" + i + " (" + expected[i - 1].tampil + ") mungkin terlewat.", "Word " + i + " (" + expected[i - 1].tampil + ") may have been omitted."))
                i--; continue
            }
            if (j > 0) {
                jumlah++
                masalah.add(tr("Mungkin ada kata tambahan: " + heard[j - 1].tampil + ".", "There may be an extra word: " + heard[j - 1].tampil + "."))
                j--; continue
            }
        }
        masalah.reverse()
        return Pair(jumlah, masalah)
    }

    /** Perbandingan tingkat kata. Hasil selalu disajikan sebagai perkiraan, bukan penilaian tajwid. */
    private fun bandingkanBacaanAyat(teksAsli: String, hasilSuara: String): Triple<Int, String, String> {
        val penuh = pecahKataArab(teksAsli)
        val heard = pecahKataArab(hasilSuara)
        if (penuh.isEmpty() || heard.isEmpty()) return Triple(-1, tr("Hasil suara kosong atau tidak terbaca. Silakan ulangi.", "Speech result was empty or unreadable. Please try again."), tr("Bacaan belum dapat diperiksa. Silakan ulangi.", "The recitation could not be checked. Please try again."))
        // Ayat pertama kebanyakan surah diawali basmalah pada data sumber; bacaan tanpa basmalah tetap dianggap benar.
        val basmalah = listOf("بسم", "الله", "الرحمن", "الرحيم")
        val varian = mutableListOf(penuh)
        if (penuh.size > 4 && penuh.take(4).map { it.kunci } == basmalah) varian.add(penuh.drop(4))
        val calon = varian.map { v -> val r = selaraskanKata(v, heard); Triple(v, r, indeksSalahSementara.toSet()) }
        val pilihan = calon.minByOrNull { it.second.first }!!
        val terbaik = Pair(pilihan.first, pilihan.second)
        // FIX104: indeks dihitung terhadap daftar kata ayat penuh (varian tanpa basmalah bergeser 4 kata).
        val geser = if (pilihan.first.size == penuh.size) 0 else penuh.size - pilihan.first.size
        val indeksPenuh = pilihan.third.map { it + geser }.toSet()
        kataBermasalahTerakhir = KataBermasalah(indeksPenuh, indeksPenuh.sorted().mapNotNull { penuh.getOrNull(it)?.tampil })
        val expected = terbaik.first
        val jumlah = terbaik.second.first
        val masalah = terbaik.second.second.take(6)
        val cocok = (expected.size - jumlah).coerceIn(0, expected.size)
        val ringkas = if (jumlah == 0) tr("Hasil pengenalan cocok dengan urutan kata ayat. Alhamdulillah. Ini bukan penilaian tajwid.", "Recognized words match the verse order. This is not a tajwid assessment.")
            else tr("Ada sekitar " + jumlah + " bagian kata yang perlu diperiksa. Kata yang cocok terdeteksi sekitar " + cocok + " dari " + expected.size + ".", "About " + jumlah + " word-level differences need review. Approximately " + cocok + " of " + expected.size + " expected words were recognized.")
        val detail = if (masalah.isEmpty()) ringkas else ringkas + "\n" + masalah.joinToString("\n")
        val suara = if (jumlah == 0) tr("Bacaan yang dikenali cocok dengan urutan kata ayat. Namun, tetap cocokkan dengan mushaf atau guru karena pengenalan suara bukan penilaian tajwid.", "Recognized words match the verse order. Still compare with a mushaf or teacher because speech recognition does not assess tajwid.")
            else tr("Ada " + jumlah + " bagian yang perlu diperiksa. Ini mungkin kesalahan bacaan atau kesalahan pengenalan suara. Dengarkan murattal dan cocokkan dengan mushaf atau guru.", "There are " + jumlah + " parts to review. This may be a recitation difference or a speech recognition error. Listen to the recitation and compare with a mushaf or teacher.")
        return Triple(jumlah, detail, suara)
    }

    /** Latihan koreksi mandiri tanpa mikrofon: sembunyikan ayat, baca dari hafalan, lalu tampilkan untuk mencocokkan. */
    private fun latihanKoreksiHafalan() {
        if (!dataPrefs.getBoolean("hafalan_latihan_mandiri_aktif", true)) { toast(tr("Fitur ini dinonaktifkan. Aktifkan di Pengaturan Hafalan.", "This feature is turned off. Turn it on in Memorization Settings.")); return }
        if (!pastikanDiPembaca()) return
        val pesan = tr("Ayat akan disembunyikan. Bacakan dari hafalan, lalu pilih Tampilkan jawaban untuk mencocokkan bacaan. Fitur ini adalah latihan mandiri tanpa mikrofon, bukan penilaian otomatis tajwid atau makhraj.", "The verse will be hidden. Recite from memory, then reveal the answer to compare. This is a self-guided exercise without a microphone, not automatic tajwid or articulation assessment.")
        AlertDialog.Builder(this).setTitle(tr("Latihan koreksi hafalan", "Memorization self-check"))
            .setMessage(pesan)
            .setPositiveButton(tr("Mulai latihan", "Start practice")) { _, _ -> mulaiSesiLatihanMandiri() }
            .setNegativeButton(tr("Kembali", "Back"), null).show()
    }

    private fun mulaiSesiLatihanMandiri() {
        if (!pastikanDiPembaca()) return
        hentikanAudio()
        sembunyikanAyatLatihan()
        ayatArab?.announceForAccessibility(tr("Ayat disembunyikan. Silakan membaca dari hafalan.", "Verse hidden. Recite from memory."))
        val kataPertama = pecahKataArab(teksArabTampil(getAyat(nomorSurah, nomorAyat)?.optString("text", "").orEmpty())).firstOrNull()?.tampil.orEmpty()
        val dialog = AlertDialog.Builder(this).setTitle(tr("Silakan membaca dari hafalan", "Recite from memory"))
            .setMessage(tr("Surah " + nomorSurah + ", ayat " + nomorAyat + ". Setelah selesai, tampilkan jawaban dan cocokkan setiap kata serta harakat pada mushaf.", "Surah " + nomorSurah + ", verse " + nomorAyat + ". When finished, reveal the answer and compare every word and diacritic with the text."))
            .setPositiveButton(tr("Tampilkan jawaban", "Reveal answer"), null)
            .setNeutralButton(tr("Petunjuk kata pertama", "First-word hint"), null)
            .setNegativeButton(tr("Batalkan", "Cancel")) { _, _ -> tampilkanAyatLatihan(); latihanHafalanAktif = false; if (sesiAktif()) handler.post { dialogSesiTertunda() } }
            .setOnCancelListener { tampilkanAyatLatihan(); latihanHafalanAktif = false; if (sesiAktif()) handler.post { dialogSesiTertunda() } }
            .create()
        dialog.show()
        // Tombol dipasang ulang agar dialog tidak tertutup otomatis saat petunjuk diminta.
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val petunjuk = if (kataPertama.isNotBlank()) tr("Kata pertama: ", "First word: ") + kataPertama else tr("Petunjuk tidak tersedia.", "Hint unavailable.")
            dialog.setMessage(tr("Surah " + nomorSurah + ", ayat " + nomorAyat + ".\n", "Surah " + nomorSurah + ", verse " + nomorAyat + ".\n") + petunjuk)
            dialog.window?.decorView?.announceForAccessibility(petunjuk)
        }
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            tampilkanAyatLatihan()
            ayatArab?.announceForAccessibility(tr("Jawaban ayat ditampilkan kembali.", "Verse answer revealed."))
            dialog.dismiss()
            if (sesiAktif()) { dialogNilaiMurajaah(); return@setOnClickListener }
            AlertDialog.Builder(this).setTitle(tr("Cocokkan bacaan", "Compare your recitation"))
                .setMessage(tr("Apakah bacaan hafalan Anda sudah sesuai dengan teks?", "Did your memorized recitation match the text?"))
                .setPositiveButton(tr("Sudah sesuai", "Matched")) { _, _ -> HafalanSrs.catat(dataPrefs, nomorSurah, nomorAyat, true); toast(tr("Alhamdulillah. Lanjutkan ke ayat berikutnya.", "Well done. Continue to the next verse.")) }
                .setNeutralButton(tr("Ulangi latihan", "Practice again")) { _, _ -> handler.post { mulaiSesiLatihanMandiri() } }
                .setNegativeButton(tr("Perlu diulang", "Needs more practice")) { _, _ -> HafalanSrs.catat(dataPrefs, nomorSurah, nomorAyat, false); toast(tr("Silakan dengarkan murattal dan ulangi hafalan ayat ini.", "Listen to the recitation and practice this verse again.")) }
                .show()
        }
    }

    /** FIX72: memutar berkas audio terjemahan Indonesia untuk surah yang sedang dibuka (hanya per surah penuh). */
    private fun putarTerjemahanSurah() {
        val url = urlAudioTerjemahanId(nomorSurah)
        if (url == null) {
            toast(tr("Audio terjemahan Indonesia untuk surah ini tidak tersedia.", "Indonesian translation audio is unavailable for this surah."))
            return
        }
        tombolAudioAktif = tombolAudio
        audioSedangAyat = false
        audioSedangJuz = false
        if (targetPemutaran != "surah") {
            toast(tr("Audio terjemahan hanya tersedia per surah penuh, jadi surah ", "Translation audio is only available as whole surahs, so surah ") + nomorSurah + tr(" diputar dari awal.", " is played from the beginning."))
        }
        mulaiAudio(url, tr("Memuat audio terjemahan Indonesia surah ", "Loading Indonesian translation audio, surah ") + nomorSurah)
    }

    private fun pengaturanModeHafalan() {
        val nilai = arrayOf("biasa", "ayat", "berurutan", "kelompok")
        val label = arrayOf(
            tr("Putar biasa: ayat diputar satu kali", "Normal: play verse once"),
            tr("Hafalan ayat: ulang ayat yang dipilih", "Memorize verse: repeat selected verse"),
            tr("Hafalan berurutan: ulang ayat lalu lanjut otomatis", "Sequential memorization: repeat verse then continue automatically"),
            tr("Hafalan kelompok ayat: putar beberapa ayat lalu ulangi seluruh kelompok", "Verse-group memorization: play several verses, then repeat the whole group")
        )
        val selected = nilai.indexOf(modeHafalan).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(tr("Pilih mode hafalan", "Choose memorization mode"))
            .setSingleChoiceItems(label, selected) { dialog, which ->
                if (which in nilai.indices) {
                    val modeSebelumnya = modeHafalan
                    modeHafalan = nilai[which]
                    if (modeHafalan == "biasa") pengulanganAyat = 1
                    else if (modeHafalan == "kelompok") { if (modeSebelumnya != "kelompok") pengulanganAyat = 1 }
                    else if (pengulanganAyat == 1) pengulanganAyat = 3
                    dataPrefs.edit().putString("mode_hafalan_audio", modeHafalan).putInt("pengulangan_audio_ayat", pengulanganAyat).apply()
                    val ringkasMode = tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat()
                    infoModeAudio?.text = ringkasMode
                    infoModeAudio?.announceForAccessibility(ringkasMode)
                    toast(tr("Mode diubah: ", "Mode changed: ") + namaModeHafalan())
                    dialog.dismiss()
                    handler.post { dialogPengaturanHafalan() }
                }
            }.setNegativeButton(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { _, _ -> handler.post { dialogPengaturanHafalan() } }.setOnCancelListener { handler.post { dialogPengaturanHafalan() } }.show()
    }

    // ====================================================================================
    // HAFALAN PER KELOMPOK AYAT (FIX77)
    // Putar N ayat berurutan sebagai satu kelompok, ulangi seluruh kelompok M kali, lalu lanjut ke kelompok
    // berikutnya atau berhenti. N dan M ditentukan sendiri oleh pengguna. Kelompok tidak melewati batas surah.
    // Setiap ayat dalam kelompok tetap memakai "Jumlah pengulangan ayat" (1 = diputar sekali per putaran).
    // ====================================================================================

    private fun teksUlangKelompok(): String =
        if (ulangKelompok == 0) tr("terus-menerus", "continuously") else ulangKelompok.toString() + tr(" kali", if (ulangKelompok == 1) " time" else " times")

    private fun teksKelompok(): String =
        tr("Kelompok ", "Group of ") + ayatPerKelompok + tr(" ayat, diulang ", if (ayatPerKelompok == 1) " verse, repeated " else " verses, repeated ") + teksUlangKelompok() +
            tr(", lalu ", ", then ") + (if (lanjutKelompok) tr("lanjut ke kelompok berikutnya.", "continue to the next group.") else tr("berhenti.", "stop."))

    /** Tentukan batas kelompok dari ayat yang sedang dipilih; kelompok berhenti di akhir surah. */
    private fun aturKelompokDariPosisi() {
        if (modeHafalan != "kelompok") return
        val totalSurah = getSurah(nomorSurah)?.optJSONArray("ayahs")?.length() ?: nomorAyat
        val sisaDiSurah = (totalSurah - nomorAyat + 1).coerceAtLeast(1)
        kelompokAwalGlobal = nomorAyatGlobal()
        kelompokAkhirGlobal = kelompokAwalGlobal + minOf(ayatPerKelompok, sisaDiSurah) - 1
        sisaUlangKelompok = ulangKelompok
        putaranKelompok = 1
    }

    /** Dipanggil saat satu ayat dalam mode kelompok selesai diputar (setelah pengulangan per ayat). */
    private fun lanjutDalamKelompok(generasi: Int) {
        if (kelompokAwalGlobal <= 0 || kelompokAkhirGlobal < kelompokAwalGlobal) aturKelompokDariPosisi()
        val sekarang = nomorAyatGlobal()
        var tujuan = -1
        var awalan = ""
        if (sekarang < kelompokAkhirGlobal) {
            tujuan = sekarang + 1
            awalan = tr("Jeda hafalan, ayat berikutnya ", "Memorization pause, next verse ")
        } else if (ulangKelompok == 0 || sisaUlangKelompok > 1) {
            if (sisaUlangKelompok > 1) sisaUlangKelompok--
            putaranKelompok++
            tujuan = kelompokAwalGlobal
            awalan = tr("Mengulang kelompok · putaran ", "Repeating group · round ") + putaranKelompok +
                (if (ulangKelompok == 0) "" else tr(" dari ", " of ") + ulangKelompok) + tr(" · mulai ayat ", " · starting at verse ")
        } else if (lanjutKelompok) {
            val awalBaru = kelompokAkhirGlobal + 1
            val pos = posisiSurahAyatDariGlobal(awalBaru)
            if (pos != null) {
                nomorSurah = pos.first; nomorAyat = pos.second
                aturKelompokDariPosisi()
                tujuan = awalBaru
                awalan = tr("Kelompok berikutnya · mulai ayat ", "Next group · starting at verse ")
            }
        }
        val posisi = if (tujuan > 0) posisiSurahAyatDariGlobal(tujuan) else null
        if (posisi == null) { selesaiKelompok(tujuan < 0 && lanjutKelompok); return }
        nomorSurah = posisi.first; nomorAyat = posisi.second
        sisaPengulanganAyat = pengulanganAyat
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + tujuan + ".mp3"
        pesanAudioAyatAktif = tr("Mode hafalan · ayat ", "Memorization mode · verse ") + nomorSurah + ":" + nomorAyat
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        tombolStatusAudio?.text = awalan + nomorSurah + ":" + nomorAyat
        redamTalkBackSaatPergantian()
        umumkanAudio(tombolStatusAudio, tombolStatusAudio?.text, true)
        handler.postDelayed({
            if (generasi == audioGenerasi && audioSedangAyat && modeHafalan == "kelompok") mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif, otomatis = true)
        }, jedaAntarAyatDetik * 1000L)
    }

    private fun selesaiKelompok(akhirQuran: Boolean) {
        audioSedangAyat = false
        // Kembali ke awal kelompok agar tombol putar mengulang kelompok yang sama.
        posisiSurahAyatDariGlobal(kelompokAwalGlobal)?.let {
            nomorSurah = it.first; nomorAyat = it.second
            dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        }
        val pesan = if (akhirQuran) tr("Hafalan kelompok mencapai akhir Al-Qur'an.", "Group memorization reached the end of the Qur'an.")
        else tr("Kelompok ayat selesai diulang. Tekan putar untuk mengulang kelompok ini, atau pilih ayat berikutnya.", "The verse group has finished repeating. Press play to repeat this group, or choose the next verse.")
        tombolStatusAudio?.text = pesan
        tombolAudioAktif?.text = tr("Kelompok selesai; tekan untuk memutar lagi", "Group finished; press to replay")
        tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
        umumkanAudio(tombolStatusAudio, pesan, true)
    }

    private fun perbaruiInfoModeAudio() {
        val ringkas = tr("Mode saat ini: ", "Current mode: ") + namaModeHafalan() + ". " + teksPengulanganAyat()
        infoModeAudio?.text = ringkas
        infoModeAudio?.announceForAccessibility(ringkas)
    }

    private fun aktifkanModeKelompok() {
        if (modeHafalan == "kelompok") return
        modeHafalan = "kelompok"
        pengulanganAyat = 1
        dataPrefs.edit().putString("mode_hafalan_audio", modeHafalan).putInt("pengulangan_audio_ayat", pengulanganAyat).apply()
        toast(tr("Mode hafalan kelompok diaktifkan. Setiap ayat diputar satu kali per putaran.", "Verse-group mode is on. Each verse plays once per round."))
    }

    private fun dialogHafalanKelompok() {
        val opsi = arrayOf(
            tr("Jumlah ayat per kelompok: ", "Verses per group: ") + ayatPerKelompok,
            tr("Jumlah pengulangan kelompok: ", "Group repetitions: ") + (if (ulangKelompok == 0) tr("terus-menerus", "continuous") else ulangKelompok.toString()),
            tr("Setelah kelompok selesai: ", "When a group finishes: ") + (if (lanjutKelompok) tr("lanjut ke kelompok berikutnya", "continue to the next group") else tr("berhenti", "stop")),
            if (modeHafalan == "kelompok") tr("Mode hafalan kelompok: aktif. Ketuk untuk menonaktifkan", "Verse-group mode: on. Tap to turn off")
            else tr("Mode hafalan kelompok: nonaktif. Ketuk untuk mengaktifkan", "Verse-group mode: off. Tap to turn on")
        )
        AlertDialog.Builder(this)
            .setCustomTitle(judulDenganPesan(
                tr("Hafalan per kelompok ayat", "Verse-group memorization"),
                tr("Beberapa ayat berurutan diputar sebagai satu kelompok, seluruh kelompok diulang, lalu lanjut. Tentukan sendiri jumlah ayat dan jumlah pengulangannya sesuai kebutuhan hafalan Anda.",
                    "Several consecutive verses play as one group, the whole group repeats, then it continues. Set the number of verses and repetitions that suit your memorization.")))
            .setItems(opsi) { _, which ->
                when (which) {
                    0 -> pilihAyatPerKelompok()
                    1 -> pilihUlangKelompok()
                    2 -> {
                        lanjutKelompok = !lanjutKelompok
                        dataPrefs.edit().putBoolean("hafalan_lanjut_kelompok", lanjutKelompok).apply()
                        perbaruiInfoModeAudio()
                        toast(if (lanjutKelompok) tr("Setelah kelompok selesai, hafalan lanjut ke kelompok berikutnya.", "When a group finishes, memorization continues to the next group.")
                              else tr("Setelah kelompok selesai, hafalan berhenti.", "When a group finishes, memorization stops."))
                        handler.post { dialogHafalanKelompok() }
                    }
                    3 -> {
                        if (modeHafalan == "kelompok") {
                            modeHafalan = "biasa"; pengulanganAyat = 1
                            dataPrefs.edit().putString("mode_hafalan_audio", modeHafalan).putInt("pengulangan_audio_ayat", pengulanganAyat).apply()
                            toast(tr("Mode hafalan kelompok dinonaktifkan. Mode kembali ke putar biasa.", "Verse-group mode is off. Mode is back to normal playback."))
                        } else aktifkanModeKelompok()
                        perbaruiInfoModeAudio()
                        handler.post { dialogHafalanKelompok() }
                    }
                }
            }
            .kembaliKe(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { dialogPengaturanHafalan() }
            .show()
    }

    private fun pilihAyatPerKelompok() {
        val nilai = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20)
        val label = nilai.map { n ->
            if (n == 1) tr("1 ayat (satu per satu)", "1 verse (one at a time)") else n.toString() + tr(" ayat per kelompok", " verses per group")
        }.toMutableList()
        val indeksLain = nilai.size
        val terpilih = nilai.indexOf(ayatPerKelompok).let { if (it < 0) indeksLain else it }
        label.add(if (terpilih == indeksLain) tr("Angka lain… (sekarang ", "Other number… (now ") + ayatPerKelompok + ")" else tr("Angka lain…", "Other number…"))
        AlertDialog.Builder(this).setTitle(tr("Jumlah ayat per kelompok", "Verses per group"))
            .setSingleChoiceItems(label.toTypedArray(), terpilih) { dialog, which ->
                dialog.dismiss()
                if (which in nilai.indices) simpanAyatPerKelompok(nilai[which])
                else dialogAngka(
                    tr("Jumlah ayat per kelompok", "Verses per group"),
                    tr("Ketik jumlah ayat yang ingin dihafal sekaligus", "Type how many verses to memorize together"),
                    ayatPerKelompok, 1, 100, { simpanAyatPerKelompok(it) }) { pilihAyatPerKelompok() }
            }
            .kembaliKe(tr("Kembali ke hafalan kelompok", "Back to verse-group settings")) { dialogHafalanKelompok() }.show()
    }

    private fun simpanAyatPerKelompok(n: Int) {
        ayatPerKelompok = n.coerceIn(1, 100)
        dataPrefs.edit().putInt("hafalan_ayat_per_kelompok", ayatPerKelompok).apply()
        aktifkanModeKelompok()
        perbaruiInfoModeAudio()
        toast(tr("Kelompok hafalan: ", "Memorization group: ") + ayatPerKelompok + tr(" ayat.", if (ayatPerKelompok == 1) " verse." else " verses."))
        handler.post { dialogHafalanKelompok() }
    }

    private fun pilihUlangKelompok() {
        val nilai = listOf(1, 2, 3, 4, 5, 7, 10, 15, 20, 0)
        val label = nilai.map { n ->
            when (n) {
                0 -> tr("Terus-menerus sampai dihentikan", "Continuous until stopped")
                1 -> tr("1 kali", "1 time")
                else -> n.toString() + tr(" kali", " times")
            }
        }.toMutableList()
        val indeksLain = nilai.size
        val terpilih = nilai.indexOf(ulangKelompok).let { if (it < 0) indeksLain else it }
        label.add(if (terpilih == indeksLain) tr("Angka lain… (sekarang ", "Other number… (now ") + ulangKelompok + ")" else tr("Angka lain…", "Other number…"))
        AlertDialog.Builder(this).setTitle(tr("Jumlah pengulangan kelompok", "Group repetitions"))
            .setSingleChoiceItems(label.toTypedArray(), terpilih) { dialog, which ->
                dialog.dismiss()
                if (which in nilai.indices) simpanUlangKelompok(nilai[which])
                else dialogAngka(
                    tr("Jumlah pengulangan kelompok", "Group repetitions"),
                    tr("Ketik berapa kali seluruh kelompok diulang", "Type how many times the whole group repeats"),
                    if (ulangKelompok == 0) 3 else ulangKelompok, 1, 99, { simpanUlangKelompok(it) }) { pilihUlangKelompok() }
            }
            .kembaliKe(tr("Kembali ke hafalan kelompok", "Back to verse-group settings")) { dialogHafalanKelompok() }.show()
    }

    private fun simpanUlangKelompok(n: Int) {
        ulangKelompok = n.coerceIn(0, 99)
        dataPrefs.edit().putInt("hafalan_ulang_kelompok", ulangKelompok).apply()
        aktifkanModeKelompok()
        perbaruiInfoModeAudio()
        toast(tr("Kelompok diulang ", "Group repeats ") + teksUlangKelompok() + ".")
        handler.post { dialogHafalanKelompok() }
    }

    /** Dialog input angka serupa untuk pengaturan kelompok; bahasa mengikuti bahasa aktif aplikasi. */
    private fun dialogAngka(judul: String, petunjuk: String, awal: Int, min: Int, maks: Int, simpan: (Int) -> Unit, kembali: () -> Unit) {
        val rentang = " (" + min + "–" + maks + ")"
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        input.hint = petunjuk + rentang
        input.contentDescription = petunjuk + rentang
        input.setText(awal.toString())
        input.setSelection(input.text.length)
        AlertDialog.Builder(this).setTitle(judul).setMessage(petunjuk + rentang).setView(input)
            .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                val n = input.text.toString().trim().toIntOrNull()
                if (n != null && n in min..maks) simpan(n)
                else {
                    toast(tr("Masukkan angka ", "Enter a number from ") + min + tr(" sampai ", " to ") + maks + ".")
                    handler.post { dialogAngka(judul, petunjuk, awal, min, maks, simpan, kembali) }
                }
            }
            .kembaliKe(tr("Kembali ke pilihan", "Back to options")) { kembali() }
            .show()
    }

    private fun pengaturanJedaAntarAyat() {
        val nilai = intArrayOf(0, 2, 5, 10)
        val label = arrayOf(tr("Tanpa jeda", "No pause"), tr("2 detik", "2 seconds"), tr("5 detik", "5 seconds"), tr("10 detik", "10 seconds"))
        val selected = nilai.indexOf(jedaAntarAyatDetik).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(tr("Jeda sebelum ayat berikutnya", "Pause before next verse"))
            .setSingleChoiceItems(label, selected) { dialog, which ->
                if (which in nilai.indices) {
                    jedaAntarAyatDetik = nilai[which]
                    dataPrefs.edit().putInt("jeda_antar_ayat_detik", jedaAntarAyatDetik).apply()
                    toast(tr("Jeda antar ayat: ", "Pause between verses: ") + label[which])
                    dialog.dismiss()
                    handler.post { dialogPengaturanHafalan() }
                }
            }.setNegativeButton(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { _, _ -> handler.post { dialogPengaturanHafalan() } }.setOnCancelListener { handler.post { dialogPengaturanHafalan() } }.show()
    }

    private fun namaTargetPemutaran(): String = when (targetPemutaran) {
        "surah" -> tr("Seluruh surah", "Whole surah")
        "juz" -> tr("Satu juz", "One juz")
        "halaman" -> tr("Satu halaman mushaf", "One mushaf page")
        else -> tr("Ayat pilihan", "Selected verse")
    }

    private fun pengaturanTargetPemutaran() {
        val values = arrayOf("ayat", "surah", "juz", "halaman")
        val labels = arrayOf(
            tr("Per ayat", "By verse"),
            tr("Per surah", "By surah"),
            tr("Per juz", "By juz"),
            tr("Per halaman mushaf", "By mushaf page")
        )
        AlertDialog.Builder(this).setTitle(tr("Cara pemutaran audio", "Audio playback range"))
            .setSingleChoiceItems(labels, values.indexOf(targetPemutaran).coerceAtLeast(0)) { dialog, which ->
                if (which in values.indices) {
                    targetPemutaran = values[which]
                    dataPrefs.edit().putString("target_pemutaran_audio", targetPemutaran).apply()
                    val info = tr("Cara pemutaran diatur: ", "Playback range set to: ") + namaTargetPemutaran()
                    infoModeAudio?.text = info
                    infoModeAudio?.announceForAccessibility(info)
                    toast(info)
                    dialog.dismiss()
                    handler.post { dialogPengaturanAudio() }
                }
            }.setNegativeButton(tr("Kembali ke pengaturan audio", "Back to audio settings")) { _, _ -> handler.post { dialogPengaturanAudio() } }.setOnCancelListener { handler.post { dialogPengaturanAudio() } }.show()
    }

    /** Tombol Putar menjalankan rentang yang sudah dipilih di Pengaturan Audio. */
    private fun mulaiSesuaiPengaturan() {
        if (modePemutaranAudio == "terjemahan") {
            // Jeda/lanjut pada audio yang sudah dimuat ditangani jedaLanjutAudio(); di sini selalu mulai baru.
            putarTerjemahanSurah()
            return
        }
        val player = pemutar
        if (player != null && audioSiap && !player.isPlaying) {
            try {
                player.start()
                perbaruiTombolJedaAudio(false)
                tombolJedaAudio?.announceForAccessibility(tombolJedaAudio?.contentDescription)
                perbaruiStatusAudio(tr("Murattal dilanjutkan.", "Recitation resumed."))
                return
            } catch (_: Exception) { }
        }
        // FIX57: qari MP3Quran (termasuk Qari anak) hanya punya audio per surah. Pada putar biasa, tombol Putar
        // langsung memutar surah penuh; sebelumnya cara pemutaran bawaan "Per ayat" hanya memunculkan dialog
        // "audio ayat tidak tersedia" sehingga qari anak terkesan tidak bisa diputar. Mode hafalan per ayat tetap
        // memakai dialog penjelasan karena memang memerlukan audio per ayat.
        val hanyaPerSurah = qariId.startsWith("mp3quran|") && targetPemutaran != "surah" && modeHafalan == "biasa"
        if (hanyaPerSurah) {
            toast(tr("Qari ini menyediakan audio per surah, jadi surah ", "This reciter provides full-surah audio, so surah ") + nomorSurah + tr(" diputar penuh.", " is played in full."))
        }
        when (if (hanyaPerSurah) "surah" else targetPemutaran) {
            "juz" -> pilihJuzUntukDiputar()
            "halaman" -> pilihHalamanUntukDiputar()
            "surah" -> {
                if (quran == null && !qariId.startsWith("mp3quran|")) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
                putarAudioSurah()
            }
            else -> putarAudioAyat()
        }
    }

    private fun pilihSurahUntukAudio() {
        val surahs = daftarSurah() ?: return
        val bahasaInggris = BahasaAplikasi.tampilan(this) == 1
        val labels = (0 until surahs.length()).map { i ->
            val item = surahs.optJSONObject(i) ?: JSONObject()
            val nomor = item.optInt("number")
            val nama = if (bahasaInggris) item.optString("englishName") else item.optString("name")
            "" + nomor + ". " + nama
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih surah untuk diputar", "Choose surah to play"))
            .setItems(labels) { _, which ->
                nomorSurah = which + 1
                nomorAyat = 1
                dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
                tampilkanPembaca()
                putarAudioSurah()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun dialogCariAudio() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val wadah = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(4))
        }
        fun kolom(label: String): EditText = EditText(this).apply {
            hint = label
            contentDescription = label
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_YES
            wadah.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val inputJuz = kolom(tr("Tulis nomor juz (opsional)", "Enter juz number (optional)"))
        val inputSurah = kolom(tr("Tulis nomor surah (opsional)", "Enter surah number (optional)"))
        val inputAyat = kolom(tr("Tulis nomor ayat (opsional)", "Enter verse number (optional)"))
        AlertDialog.Builder(this)
            .setTitle(tr("Cari juz, surah, atau ayat", "Find juz, surah, or verse"))
            .setMessage(tr("Isi salah satu kolom saja sudah cukup. Jika mengisi nomor ayat tanpa nomor surah, ayat dicari pada surah yang sedang dipilih (surah ", "Fill in just one field. If you enter a verse without a surah, it is searched in the currently selected surah (surah ") + nomorSurah + ").")
            .setView(wadah)
            .setPositiveButton(tr("Cari dan putar", "Find and play")) { _, _ ->
                prosesPencarianAudioTerstruktur(
                    inputJuz.text.toString().trim(),
                    inputSurah.text.toString().trim(),
                    inputAyat.text.toString().trim()
                )
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    // ===== FIX80: perintah suara "putar surah/ayat/juz ..." =====
    private fun mulaiPerintahSuaraPutar() {
        if (!dataPrefs.getBoolean("perintah_suara_putar_aktif", true)) { toast(tr("Perintah suara dinonaktifkan. Aktifkan di Pengaturan Pemutaran Audio.", "Voice command is turned off. Turn it on in Audio Playback Settings.")); return }
        // FIX83: bila "Suara TalkBack" dimatikan, senyapkan TalkBack dan beri isyarat getar sebelum mikrofon dibuka.
        if (senyapTalkBackPergantian) {
            redamTalkBackSaatPergantian()
            getarIsyarat(150L)
            handler.postDelayed({ if (!isFinishing) bukaPengenalanPerintahSuara() }, 800L)
        } else bukaPengenalanPerintahSuara()
    }

    private fun bukaPengenalanPerintahSuara() {
        if (quran == null) muatCache()
        val inggris = BahasaAplikasi.tampilan(this) == 1
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (inggris) "en-US" else "id-ID")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, if (inggris) "en-US" else "id-ID")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                if (!senyapTalkBackPergantian) putExtra(RecognizerIntent.EXTRA_PROMPT, tr("Ucapkan, misalnya: putar surah Al Baqarah ayat 255, atau pilih qari Alafasy", "Say, for example: play surah Al Baqarah verse 255, or choose reciter Alafasy"))
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, 6907)
        } catch (_: Exception) {
            toast(tr("Layanan pengenalan suara tidak dapat dibuka di HP ini. Pasang atau perbarui aplikasi Google, atau gunakan tombol Cari juz, surah, atau ayat.",
                "Speech recognition cannot be opened on this phone. Install or update the Google app, or use the Find juz, surah, or verse button."))
        }
    }

    private fun kolapsHuruf(teks: String): String {
        val sb = StringBuilder()
        for (c in teks.lowercase()) {
            if (c in 'a'..'z' && (sb.isEmpty() || sb[sb.length - 1] != c)) sb.append(c)
        }
        return sb.toString()
    }

    /** Mengubah kata bilangan (Indonesia/Inggris) menjadi angka; kata lain dibiarkan. */
    private fun gantiKataAngka(tokens: List<String>): List<String> {
        val dasar = mapOf(
            "nol" to 0, "satu" to 1, "dua" to 2, "tiga" to 3, "empat" to 4, "lima" to 5, "enam" to 6, "tujuh" to 7,
            "delapan" to 8, "sembilan" to 9, "sepuluh" to 10, "sebelas" to 11,
            "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
            "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
            "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19,
            "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
        )
        val hasil = mutableListOf<String>()
        var total = 0; var seg = 0; var ada = false
        fun tutup() { if (ada) hasil.add((total + seg).toString()); total = 0; seg = 0; ada = false }
        for (t in tokens) {
            val v = dasar[t]
            when {
                v != null -> { seg += v; ada = true }
                t == "belas" && ada -> seg += 10
                t == "puluh" && ada -> seg *= 10
                (t == "ratus" || t == "hundred") && ada -> { total += (if (seg == 0) 1 else seg) * 100; seg = 0 }
                t == "seratus" -> { total += 100; ada = true }
                (t == "dan" || t == "and") && ada -> { }
                else -> { tutup(); hasil.add(t) }
            }
        }
        tutup()
        return hasil
    }

    private fun cocokkanNamaSurah(sisa: String): Int? {
        val teks = kolapsHuruf(sisa)
        if (teks.isEmpty()) return null
        val awalan = listOf("asy", "ash", "adh", "adz", "ath", "al", "an", "ar", "as", "at", "ad", "az")
        var terbaik: Int? = null; var panjangTerbaik = 0
        fun coba(kandidat: String, nomor: Int) {
            if (kandidat.length < 2) return
            val cocok = if (kandidat.length <= 3) teks == kandidat else teks.contains(kandidat)
            if (cocok && kandidat.length > panjangTerbaik) { terbaik = nomor; panjangTerbaik = kandidat.length }
        }
        val daftar = daftarSurah()
        for (i in 0 until 114) {
            val nomor = i + 1
            val lengkap = kolapsHuruf(daftarBerkasTerjemahanId.getOrNull(i).orEmpty())
            coba(lengkap, nomor)
            awalan.firstOrNull { lengkap.startsWith(it) && lengkap.length - it.length >= 4 }?.let { coba(lengkap.substring(it.length), nomor) }
            val inggris = kolapsHuruf(daftar?.optJSONObject(i)?.optString("englishName").orEmpty())
            coba(inggris, nomor)
            awalan.firstOrNull { inggris.startsWith(it) && inggris.length - it.length >= 4 }?.let { coba(inggris.substring(it.length), nomor) }
        }
        return terbaik
    }

    private fun prosesPerintahSuaraPutar(kandidatAsli: List<String>) {
        // FIX88: perintah memilih qari ("pilih qari Alafasy", "ganti qari ke Sudais", "putar surah Yasin dengan qari Husary").
        var kandidat = kandidatAsli
        for (u in kandidatAsli) {
            val pisah = pisahPerintahQari(u) ?: continue
            if (pisah.first.isBlank()) {
                toast(tr("Sebutkan nama qari, misalnya: pilih qari Alafasy, pilih qari Sudais, atau pilih qari anak.", "Say the reciter's name, for example: choose reciter Alafasy, choose reciter Sudais, or choose children's reciter."))
                return
            }
            val qari = cariQariDariUcapan(pisah.first)
            if (qari == null) {
                toast(tr("Qari \"" + pisah.first + "\" tidak ditemukan. Coba sebut: Alafasy, Sudais, Husary, Minshawi, Abdul Basit, Maher Al Muaiqly, atau qari anak.",
                    "Reciter \"" + pisah.first + "\" was not found. Try: Alafasy, Sudais, Husary, Minshawi, Abdul Basit, Maher Al Muaiqly, or children's reciter."))
                return
            }
            terapkanQariDariPerintah(qari)
            if (sisaHanyaPengisi(pisah.second)) return // hanya memilih qari
            kandidat = listOf(pisah.second) // lanjut memutar sesuai sisa perintah, tanpa kata-kata nama qari
            break
        }
        // FIX98: pengulangan dan isyarat tambahan hanya dipahami pemutar latar belakang; di sini ucapan dibersihkan
        // agar angka seperti "5 kali" tidak terbaca sebagai nomor ayat.
        if (PenafsirQuran.adaDirektif(kandidat)) {
            kandidat = PenafsirQuran.bersihkanDirektif(kandidat)
            toast(tr("Pengulangan dan pengaturan tambahan hanya berlaku bila perintah diucapkan dari layar depan (pemutar latar belakang). Khatam memutar tanpa pengulangan.",
                "Repeats and extra options only apply when the command is spoken from the home screen (background player). Khatam plays without repeating."))
        }
        if (quran == null) muatCache()
        if (quran == null) {
            toast(tr("Teks Al-Qur'an belum diunduh. Unduh di Khatam lalu ulangi perintah suara.", "The Quran text has not been downloaded yet. Download it in Khatam, then repeat the voice command."))
            return
        }
        // FIX100: bila nama surah yang diucapkan tidak dikenali oleh kedua pencocok nama, tolak dan laporkan nama itu.
        // Sebelumnya "ayat N" tanpa nama yang terbaca diam-diam diputar pada surah terakhir (mis. An-Nas) sehingga
        // perintah dan hasil tidak sesuai.
        val periksaNama = PenafsirQuran.tafsirLengkap(kandidat)
        val namaTidakDikenal = periksaNama.second
        if (periksaNama.first == null && namaTidakDikenal != null && cocokkanNamaSurah(namaTidakDikenal) == null) {
            toast(tr("Nama surah \"" + namaTidakDikenal + "\" tidak dikenali, jadi tidak ada audio yang diputar. Ucapkan nomor surah, misalnya: putar surah 112 ayat 1.",
                "The surah name \"" + namaTidakDikenal + "\" was not recognized, so nothing was played. Say the surah number, for example: play surah 112 verse 1."))
            return
        }
        val kataPerintah = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "please", "tolong", "nomor", "number",
            "ke", "dari", "the", "of", "di", "yang", "dengan", "lalu", "alquran", "quran")
        val kunciJuz = setOf("juz", "jus", "juzz")
        val kunciAyat = setOf("ayat", "ayah", "verse", "aya")
        val kunciSurah = setOf("surah", "surat", "sura", "surat")
        val penghubungRentang = setOf("sampai", "hingga", "dengan", "sd", "s", "d", "to", "through", "until", "till", "ke", "and", "dan", "sampe")
        for (ucapan in kandidat) {
            val tokens = gantiKataAngka(ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() })
            var juz: Int? = null; var surah: Int? = null; var ayat: Int? = null; var ayatAkhir: Int? = null
            val sisa = mutableListOf<String>()
            val angkaLepas = mutableListOf<Int>()
            var i = 0
            while (i < tokens.size) {
                val t = tokens[i]
                val berikut = tokens.getOrNull(i + 1)?.toIntOrNull()
                when {
                    t in kunciJuz && berikut != null -> { juz = berikut; i += 2; continue }
                    t in kunciAyat && berikut != null -> {
                        if (ayat == null) {
                            ayat = berikut
                            var k = i + 2
                            val awalK = k
                            while (k < tokens.size && tokens[k] in penghubungRentang) k++
                            if (k > awalK && k < tokens.size && tokens[k] in kunciAyat) k++
                            val angkaAkhir = tokens.getOrNull(k)?.toIntOrNull()
                            if (angkaAkhir != null) { ayatAkhir = angkaAkhir; k++ }
                            i = k
                        } else { ayatAkhir = berikut; i += 2 }
                        continue
                    }
                    t in kunciSurah && berikut != null -> { surah = berikut; i += 2; continue }
                    t in kunciJuz || t in kunciAyat || t in kunciSurah || t in kataPerintah -> { }
                    t.toIntOrNull() != null -> angkaLepas.add(t.toInt())
                    else -> sisa.add(t)
                }
                i++
            }
            val dariNama = cocokkanNamaSurah(sisa.joinToString(" ")) ?: PenafsirQuran.nomorSurahDariNama(sisa)
            if (surah == null && dariNama != null) {
                surah = dariNama
                if (ayat == null && juz == null && angkaLepas.isNotEmpty()) {
                    ayat = angkaLepas[0]
                    if (angkaLepas.size >= 2) ayatAkhir = angkaLepas[1]
                }
            } else if (surah == null && ayat == null && juz == null && angkaLepas.size >= 2) {
                surah = angkaLepas[0]; ayat = angkaLepas[1]
            } else if (surah == null && ayat == null && juz == null && angkaLepas.size == 1 && sisa.isEmpty()) {
                surah = angkaLepas[0]
            }
            if (juz == null && surah == null && ayat == null) continue
            if (ayat != null && ayatAkhir != null && juz == null && ayatAkhir != ayat) {
                val dari = minOf(ayat, ayatAkhir); val sampai = maxOf(ayat, ayatAkhir)
                val sTujuan = surah ?: nomorSurah
                toast(tr("Perintah suara: putar surah ", "Voice command: play surah ") + sTujuan + tr(" ayat ", " verses ") + dari + tr(" sampai ", " to ") + sampai)
                putarRentangAyat(sTujuan, dari, sampai)
                return
            }
            val ringkas = if (juz != null) tr("juz ", "juz ") + juz
                else tr("surah ", "surah ") + (surah ?: nomorSurah) + (if (ayat != null) tr(" ayat ", " verse ") + ayat else "")
            toast(tr("Perintah suara: putar ", "Voice command: play ") + ringkas)
            prosesPencarianAudioTerstruktur(juz?.toString().orEmpty(), surah?.toString().orEmpty(), ayat?.toString().orEmpty())
            return
        }
        val didengar = kandidat.firstOrNull().orEmpty()
        toast(tr("Perintah belum dikenali", "Command not recognized") + (if (didengar.isNotBlank()) ": \"" + didengar + "\"" else "") +
            tr(". Coba ucapkan: putar surah Al Baqarah, putar surah 36 ayat 5, putar juz 30, atau pilih qari Alafasy.", ". Try saying: play surah Al Baqarah, play surah 36 verse 5, play juz 30, or choose reciter Alafasy."))
    }

    // ====================================================================================
    // PILIH QARI DENGAN PERINTAH SUARA (FIX88)
    // Contoh: "pilih qari Alafasy", "ganti qari ke Sudais", "gunakan qari anak", "pilih qari Muhammad Taha",
    //         "putar surah Yasin dengan qari Husary", "choose reciter Maher Al Muaiqly", "play surah 36 with reciter Alafasy".
    // Nama dicocokkan secara fonetik longgar (Misyari = Mishary, Sudaisi = Sudais, Mahir = Maher) terhadap katalog qari
    // yang tersedia: qari per ayat (selalu ada), serta qari anak dan qari per surah yang sudah pernah dimuat.
    // ====================================================================================

    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori")
    private val kataKerjaPilih = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set",
        "choose", "select", "switch", "change", "use", "with", "dengan", "oleh", "by", "using")
    private val kataHentiNamaQari = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "lalu", "kemudian", "then", "and", "dan",
        "surah", "surat", "sura", "ayat", "ayah", "verse", "juz", "jus", "juzz", "untuk", "for")
    private val kataAbaikanAwalNama = setOf("ke", "menjadi", "jadi", "to", "as", "the", "a", "bernama", "nama", "named", "yang", "adalah")
    private val kataPengisiPerintah = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "lalu", "kemudian", "then", "and", "dan",
        "tolong", "please", "dengan", "dari", "untuk", "for", "ke", "to", "with", "by", "oleh", "saja", "now", "sekarang")
    private val kataAnakQari = setOf("anak", "anakanak", "kid", "kids", "child", "children", "cilik", "kecil")

    private fun sisaHanyaPengisi(sisa: String): Boolean =
        sisa.split(" ").filter { it.isNotBlank() }.all { it in kataPengisiPerintah }

    /**
     * Pisahkan ucapan menjadi (nama qari yang disebut, sisa ucapan tanpa klausa qari); null bila bukan perintah qari.
     * Contoh: "putar surah yasin dengan qari alafasy" -> ("alafasy", "putar surah yasin").
     */
    private fun pisahPerintahQari(ucapan: String): Pair<String, String>? {
        val tokens = ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() }
        val idx = tokens.indexOfFirst { it in kataQariPasti || it in kataQariMirip }
        if (idx < 0) return null
        if (tokens[idx] in kataQariMirip && tokens.none { it in kataKerjaPilih }) return null
        val nama = mutableListOf<String>()
        var akhir = idx + 1
        while (akhir < tokens.size && tokens[akhir] !in kataHentiNamaQari) { nama.add(tokens[akhir]); akhir++ }
        while (nama.isNotEmpty() && nama.first() in kataAbaikanAwalNama) nama.removeAt(0)
        var awal = idx
        while (awal > 0 && tokens[awal - 1] in kataKerjaPilih) awal--
        val sisa = tokens.subList(0, awal) + tokens.subList(akhir, tokens.size)
        return nama.joinToString(" ") to sisa.joinToString(" ")
    }

    /** Kunci fonetik sederhana agar ejaan Indonesia/Inggris/Arab-Latin yang berbeda tetap berdekatan. */
    private fun fonetikQari(s: String): String {
        var t = s.lowercase(Locale.ROOT).filter { it in 'a'..'z' }
        for ((a, b) in listOf("sy" to "sh", "kh" to "h", "dh" to "d", "dz" to "d", "th" to "t", "gh" to "g", "ph" to "f",
            "ou" to "u", "oo" to "u", "ee" to "i", "ei" to "i", "ai" to "i", "ay" to "i")) t = t.replace(a, b)
        t = t.replace('y', 'i').replace('e', 'i').replace('o', 'u').replace('w', 'u').replace('q', 'k').replace('c', 'k')
        val sb = StringBuilder()
        for (ch in t) if (sb.isEmpty() || sb[sb.length - 1] != ch) sb.append(ch)
        return sb.toString()
    }

    private fun jarakEdit(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var sebelum = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val kini = IntArray(b.length + 1)
            kini[0] = i
            for (j in 1..b.length) {
                val biaya = if (a[i - 1] == b[j - 1]) 0 else 1
                kini[j] = minOf(kini[j - 1] + 1, sebelum[j] + 1, sebelum[j - 1] + biaya)
            }
            sebelum = kini
        }
        return sebelum[b.length]
    }

    private fun namaIntiQari(label: String): String =
        label.removePrefix("Anak · ").removePrefix("MP3Quran · ").substringBefore(" ·").trim()

    /** Cari qari dari nama yang diucapkan. Mengembalikan pasangan (id, label) atau null bila tidak ada yang cocok. */
    private fun cariQariDariUcapan(nama: String): Pair<String, String>? {
        muatKatalogQariDariCache()
        val kataAbaikan = setOf("al", "el", "as", "ash", "ad", "an", "ar", "az", "at", "bin", "ibn")
        val tokenUcapan = nama.lowercase().replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.isNotBlank() }
        val mintaAnak = tokenUcapan.any { it in kataAnakQari }
        val mintaMujawwad = tokenUcapan.any { it.startsWith("mujaw") }
        val bersih = tokenUcapan.filter { it !in kataAnakQari && !it.startsWith("mujaw") && it !in kataAbaikan && it != "murattal" && it != "tartil" }
        if (mintaAnak && bersih.isEmpty()) return daftarQariAnakTerurut().firstOrNull()
        if (bersih.isEmpty()) return null

        // Kumpulan qari: per ayat (selalu), per surah yang lengkap (dari katalog yang sudah dimuat), dan Taha cadangan.
        val kumpulan = mutableListOf<Pair<String, String>>()
        kumpulan.addAll(daftarQari)
        daftarQariPerSurah.filter { qariLengkap(it.first) }.forEach { q -> if (kumpulan.none { it.first == q.first }) kumpulan.add(q) }
        if (kumpulan.none { it.second.startsWith("Anak · ") && peringkatQariAnak(it.second) == 0 }) kumpulan.add(qariTahaCadangan)
        val kolam = if (mintaAnak) kumpulan.filter { it.second.startsWith("Anak · ") } else kumpulan

        var terbaik: Pair<String, String>? = null
        var skorTerbaik = Double.NEGATIVE_INFINITY
        for (c in kolam) {
            val tokenC = namaIntiQari(c.second).lowercase().replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.isNotBlank() && it !in kataAbaikan }
            val varian = tokenC.flatMap { t -> listOfNotNull(fonetikQari(t), if (t.startsWith("al") && t.length >= 5) fonetikQari(t.substring(2)) else null) }
            val gabung = fonetikQari(tokenC.joinToString(""))
            var cocok = 0; var panjang = 0; var jarakTotal = 0
            for (q in bersih) {
                val fq = fonetikQari(q)
                if (fq.length < 2) continue
                val batas = when { fq.length <= 3 -> 0; fq.length <= 6 -> 1; else -> 2 }
                val jarak = if (fq.length >= 6 && gabung.contains(fq)) 0 else (varian.minOfOrNull { jarakEdit(fq, it) } ?: 99)
                if (jarak <= batas) { cocok++; panjang += q.length; jarakTotal += jarak }
            }
            if (cocok == 0 || panjang < 4 || cocok * 2 < bersih.size) continue
            var skor = cocok * 100.0 + panjang - (bersih.size - cocok) * 30.0 - jarakTotal * 10.0
            val mujawwadLabel = c.second.contains("mujawwad", ignoreCase = true)
            skor += if (mujawwadLabel == mintaMujawwad) 15.0 else -15.0
            if (!c.first.startsWith("mp3quran|")) skor += 5.0 // qari per ayat mendukung semua mode hafalan
            if (c.first == qariId) skor += 1.0
            if (skor > skorTerbaik) { skorTerbaik = skor; terbaik = c }
        }
        return terbaik
    }

    private fun terapkanQariDariPerintah(qari: Pair<String, String>) {
        hentikanAudio()
        qariId = qari.first
        dataPrefs.edit().putString("qari_audio_id", qariId).putString("qari_audio_nama", qari.second).apply()
        infoQari?.text = tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari()
        tombolStatusAudio?.text = tr("Qari dipilih: ", "Reciter selected: ") + namaQari()
        toast(tr("Perintah suara: qari diganti menjadi ", "Voice command: reciter changed to ") + namaQari() +
            (if (qariId.startsWith("mp3quran|")) tr(". Qari ini menyediakan audio per surah.", ". This reciter provides full-surah audio.") else ""))
    }

    private fun prosesPencarianAudioTerstruktur(juzText: String, surahText: String, ayatText: String) {
        val juz = juzText.toIntOrNull()
        val surah = surahText.toIntOrNull()
        val ayat = ayatText.toIntOrNull()
        if (juzText.isNotBlank() && (juz == null || juz !in 1..30)) {
            toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); return
        }
        if (surahText.isNotBlank() && (surah == null || surah !in 1..114)) {
            toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); return
        }
        if (ayatText.isNotBlank() && (ayat == null || ayat < 1)) {
            toast(tr("Nomor ayat harus berupa angka positif.", "Verse number must be a positive number.")); return
        }
        if (juz == null && surah == null && ayat == null) {
            toast(tr("Isi minimal satu kolom pencarian.", "Fill in at least one search field.")); return
        }
        // Bila juz diisi, juz menjadi tujuan utama; kolom lain tidak digunakan.
        if (juz != null) {
            if (qariId.startsWith("mp3quran|")) {
                toast(tr("Qari yang dipilih hanya menyediakan audio per surah. Pilih qari per ayat untuk memutar juz.", "The selected reciter only provides surah audio. Choose a verse-by-verse reciter to play a juz.")); return
            }
            putarJuz(juz); return
        }
        val surahTujuan = surah ?: nomorSurah
        if (ayat != null) {
            mulaiDariReferensi(surahTujuan, ayat)
        } else {
            nomorSurah = surahTujuan
            nomorAyat = 1
            dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", 1).apply()
            tampilkanPembaca()
            putarAudioSurah()
        }
    }

    /** FIX81: memutar rentang ayat berurutan (mis. surah 18 ayat 1 sampai 3), masing-masing satu kali. */
    private fun putarRentangAyat(surah: Int, dari: Int, sampai: Int) {
        if (surah !in 1..114) { toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); return }
        val total = getSurah(surah)?.optJSONArray("ayahs")?.length() ?: 0
        if (dari < 1 || sampai > total) { toast(tr("Rentang ayat tidak sesuai dengan surah yang dipilih (surah ini punya ", "Verse range is not valid for the selected surah (this surah has ") + total + tr(" ayat).", " verses).")); return }
        if (qariId.startsWith("mp3quran|")) { mulaiDariReferensi(surah, dari); return }
        hentikanAudio()
        var awalGlobal = dari
        for (i in 1 until surah) awalGlobal += getSurah(i)?.optJSONArray("ayahs")?.length() ?: 0
        audioRentangLabel = tr("Surah ", "Surah ") + surah + tr(" ayat ", " verses ") + dari + "-" + sampai
        audioSedangJuz = true; audioSedangAyat = false
        audioGlobalSaatIni = awalGlobal; audioGlobalAkhir = awalGlobal + (sampai - dari)
        nomorSurah = surah; nomorAyat = dari
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
        tampilkanPembaca(); tombolAudioAktif = tombolAudioAyat
        mulaiAudio(urlAudioAyatAktif, tr("Memutar ", "Playing ") + audioRentangLabel + " · " + nomorSurah + ":" + nomorAyat)
    }

    private fun mulaiDariReferensi(surah: Int, ayat: Int) {
        if (surah !in 1..114) { toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); return }
        val total = getSurah(surah)?.optJSONArray("ayahs")?.length() ?: 0
        if (ayat !in 1..total) { toast(tr("Nomor ayat tidak sesuai dengan surah yang dipilih.", "Verse number is not valid for the selected surah.")); return }
        nomorSurah = surah; nomorAyat = ayat
        dataPrefs.edit().putInt("terakhir_surah", surah).putInt("terakhir_ayat", ayat).apply()
        tampilkanPembaca(); putarAudioAyat()
    }

    private fun nomorAyatGlobal(): Int {
        var global = nomorAyat
        for (i in 1 until nomorSurah) global += getSurah(i)?.optJSONArray("ayahs")?.length() ?: 0
        return global.coerceIn(1, 6236)
    }

    private fun putarAudioAyat() {
        tombolAudioAktif = tombolAudioAyat
        audioSedangAyat = true
        sisaPengulanganAyat = pengulanganAyat
        aturKelompokDariPosisi()
        if (qariId.startsWith("mp3quran|")) {
            audioSedangAyat = false
            AlertDialog.Builder(this)
                .setTitle(tr("Audio ayat tidak tersedia untuk qari ini", "Verse audio is unavailable for this reciter"))
                .setMessage(tr("Qari MP3Quran yang dipilih hanya menyediakan rekaman per surah. Anda dapat memutar surah penuh atau memilih qari yang menyediakan audio per ayat.", "The selected MP3Quran reciter provides full-surah recordings only. You can play the whole surah or choose a reciter with verse-by-verse audio."))
                .setPositiveButton(tr("Putar surah penuh", "Play whole surah")) { _, _ -> putarAudioSurah() }
                .setNeutralButton(tr("Pilih qari audio per ayat", "Choose verse-by-verse reciter")) { _, _ -> pilihQari { } }
                .setNegativeButton(tr("Batal", "Cancel"), null)
                .show()
            return
        }
        audioSedangJuz = false
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + nomorAyatGlobal() + ".mp3"
        pesanAudioAyatAktif = tr("Memuat murattal ayat ", "Loading verse recitation ") + nomorSurah + ":" + nomorAyat
        mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif)
    }

    /** FIX61: jumlah surah (1..114) berbeda yang tersedia pada pengenal qari MP3Quran; hanya qari lengkap (114) yang ditampilkan. */
    private fun jumlahSurahQari(id: String): Int =
        id.split("|").getOrNull(2)?.split(",")?.mapNotNull { it.trim().toIntOrNull() }?.filter { it in 1..114 }?.toSet()?.size ?: 0

    private fun qariLengkap(id: String): Boolean = !id.startsWith("mp3quran|") || jumlahSurahQari(id) >= 114

    /** Ringkas himpunan nomor surah menjadi rentang, mis. "78-114" atau "1, 55-60". */
    private fun ringkasRentangSurah(nomor: Set<Int>): String {
        val urut = nomor.filter { it in 1..114 }.sorted()
        if (urut.isEmpty()) return "-"
        val bagian = mutableListOf<String>()
        var awal = urut[0]; var akhir = urut[0]
        for (i in 1 until urut.size) {
            if (urut[i] == akhir + 1) akhir = urut[i]
            else { bagian.add(if (awal == akhir) "" + awal else "" + awal + "-" + akhir); awal = urut[i]; akhir = urut[i] }
        }
        bagian.add(if (awal == akhir) "" + awal else "" + awal + "-" + akhir)
        return bagian.joinToString(", ")
    }

    /**
     * FIX59: qari anak sering hanya punya sebagian surah. Bila surah yang sedang dibuka tidak ada pada qari ini,
     * jangan berhenti dengan toast singkat (terkesan "tidak bisa diputar"); tawarkan surah terdekat yang tersedia.
     */
    private fun tawarkanSurahTersedia(tersedia: Set<Int>) {
        val valid = tersedia.filter { it in 1..114 }.sorted()
        val pesanKosong = tr("Qari ini tidak punya surah yang dapat diputar. Pilih qari lain.", "This reciter has no playable surah. Choose another reciter.")
        if (valid.isEmpty()) { perbaruiStatusAudio(pesanKosong); toast(pesanKosong); return }
        val tujuan = valid.firstOrNull { it >= nomorSurah } ?: valid.last()
        val namaTujuan = getSurah(tujuan)?.optString("englishName", "")?.takeIf { it.isNotBlank() }?.let { " (" + it + ")" } ?: ""
        val pesan = tr("Surah ", "Surah ") + nomorSurah + tr(" tidak tersedia pada qari ", " is not available for reciter ") + namaQari() +
            tr(". Surah yang tersedia: ", ". Available surahs: ") + ringkasRentangSurah(valid.toSet()) + "."
        perbaruiStatusAudio(pesan, true)
        AlertDialog.Builder(this)
            .setTitle(tr("Surah tidak tersedia untuk qari ini", "Surah unavailable for this reciter"))
            .setMessage(pesan)
            .setPositiveButton(tr("Putar surah ", "Play surah ") + tujuan + namaTujuan) { _, _ ->
                nomorSurah = tujuan; nomorAyat = 1
                dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", 1).apply()
                tampilkanPembaca()
                putarAudioSurah()
            }
            .setNeutralButton(tr("Putar surah ini dengan qari anak lain", "Play this surah with another children's reciter")) { _, _ ->
                // FIX60: pakai qari anak lain yang punya surah ini (Taha, Junaid Adam, dst.), sisanya pilih manual.
                val lain = daftarQariAnakTerurut().firstOrNull { q ->
                    q.first != qariId && (q.first.split("|").getOrNull(2)?.split(",")?.mapNotNull { n -> n.trim().toIntOrNull() }?.contains(nomorSurah) == true)
                }
                if (lain != null) {
                    hentikanAudio()
                    qariId = lain.first
                    dataPrefs.edit().putString("qari_audio_id", qariId).putString("qari_audio_nama", lain.second).apply()
                    infoQari?.text = tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari()
                    toast(tr("Memutar dengan ", "Playing with ") + namaQari())
                    putarAudioSurah()
                } else pilihQari { }
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    private fun putarAudioSurah() {
        tombolAudioAktif = tombolAudio
        audioSedangAyat = false
        audioSedangJuz = false
        val url = if (qariId.startsWith("mp3quran|")) {
            val parts = qariId.split("|")
            val server = parts.getOrNull(1) ?: ""
            val available = parts.getOrNull(2)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            if (nomorSurah !in available) {
                tawarkanSurahTersedia(available); return
            }
            server + String.format(Locale.ROOT, "%03d", nomorSurah) + ".mp3"
        } else "https://cdn.islamic.network/quran/audio-surah/128/" + qariId + "/" + nomorSurah + ".mp3"
        mulaiAudio(url, tr("Memuat murattal surah ", "Loading surah recitation ") + nomorSurah + ", " + namaQari())
    }

    private fun posisiSurahAyatDariGlobal(global: Int): Pair<Int, Int>? {
        if (global !in 1..6236) return null
        var tersisa = global
        val surahs = daftarSurah() ?: return null
        for (i in 0 until surahs.length()) {
            val n = surahs.optJSONObject(i)?.optJSONArray("ayahs")?.length() ?: 0
            if (tersisa <= n) return (i + 1) to tersisa
            tersisa -= n
        }
        return null
    }

    private fun rentangGlobalJuz(juz: Int): IntRange? {
        val surahs = daftarSurah() ?: return null
        var global = 0
        var awal = -1
        var akhir = -1
        for (i in 0 until surahs.length()) {
            val ayahs = surahs.optJSONObject(i)?.optJSONArray("ayahs") ?: continue
            for (j in 0 until ayahs.length()) {
                global++
                val ayah = ayahs.optJSONObject(j) ?: continue
                if (ayah.optInt("juz") == juz) {
                    if (awal < 0) awal = global
                    akhir = global
                } else if (awal >= 0 && akhir >= 0) {
                    // Ayat juz tersebar berurutan dalam urutan mushaf; jangan hentikan bila metadata berpindah kembali.
                }
            }
        }
        return if (awal > 0 && akhir >= awal) awal..akhir else null
    }

    /** Mengambil rentang global ayat berdasarkan nomor halaman pada metadata mushaf. */
    private fun rentangGlobalHalaman(halaman: Int): IntRange? {
        if (halaman !in 1..604) return null
        val surahs = daftarSurah() ?: return null
        var global = 0
        var awal = -1
        var akhir = -1
        for (i in 0 until surahs.length()) {
            val ayahs = surahs.optJSONObject(i)?.optJSONArray("ayahs") ?: continue
            for (j in 0 until ayahs.length()) {
                global++
                val page = ayahs.optJSONObject(j)?.optInt("page", -1) ?: -1
                if (page == halaman) { if (awal < 0) awal = global; akhir = global }
            }
        }
        return if (awal > 0 && akhir >= awal) awal..akhir else null
    }

    private fun pilihHalamanUntukDiputar() {
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return }
        val page = getAyat(nomorSurah, nomorAyat)?.optInt("page", -1) ?: -1
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = tr("Nomor halaman 1 sampai 604", "Page number 1 to 604")
            contentDescription = hint
            setText((if (page in 1..604) page else 1).toString())
        }
        AlertDialog.Builder(this).setTitle(tr("Putar satu halaman mushaf", "Play one mushaf page"))
            .setMessage(tr("Masukkan nomor halaman. Jika dibiarkan sesuai posisi sekarang, halaman ayat aktif yang dipilih.", "Enter a page number. The current verse's page is preselected."))
            .setView(input).setPositiveButton(tr("Putar halaman", "Play page")) { _, _ ->
                val selected = input.text.toString().toIntOrNull()
                if (selected == null || selected !in 1..604) toast(tr("Nomor halaman harus 1 sampai 604.", "Page number must be from 1 to 604."))
                else putarHalaman(selected)
            }
            .setNeutralButton(tr("Pilih Qari untuk halaman", "Choose reciter for page")) { _, _ ->
                pilihQariKhususUntukHalaman()
            }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    /** Pilihan khusus qari per ayat; hanya jenis ini yang dapat diputar berurutan untuk satu halaman. */
    private fun pilihQariKhususUntukHalaman() {
        val sumber = daftarQari.toList()
        if (sumber.isEmpty()) {
            toast(tr("Daftar qari audio per ayat belum tersedia.", "Verse-by-verse reciter list is unavailable."))
            return
        }
        val labels = sumber.map { it.second + if (it.first == qariId) tr(" (dipilih)", " (selected)") else "" }
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih Qari untuk pemutaran halaman", "Choose reciter for page playback"))
            .setItems(labels.toTypedArray()) { _, which ->
                if (which in sumber.indices) {
                    hentikanAudio()
                    qariId = sumber[which].first
                    dataPrefs.edit()
                        .putString("qari_audio_id", qariId)
                        .putString("qari_audio_nama", sumber[which].second)
                        .apply()
                    val info = tr("Qari halaman dipilih: ", "Page reciter selected: ") + namaQari()
                    infoQari?.text = tr("Qari audio saat ini: ", "Current audio reciter: ") + namaQari()
                    infoQari?.announceForAccessibility(info)
                    toast(info)
                    handler.post { pilihHalamanUntukDiputar() }
                }
            }
            .setNegativeButton(tr("Batal", "Cancel"), null)
            .show()
    }

    private fun putarHalaman(halaman: Int) {
        if (qariId.startsWith("mp3quran|")) { toast(tr("Qari ini hanya menyediakan audio surah penuh. Pilih qari yang mendukung audio per ayat untuk memutar halaman.", "This reciter only provides full-surah audio. Choose a verse-by-verse reciter to play a page.")); return }
        val range = rentangGlobalHalaman(halaman)
        if (range == null) { toast(tr("Data halaman tidak tersedia. Unduh ulang teks Al-Qur'an yang memuat metadata halaman.", "Page metadata is unavailable. Download Qur'an text containing page metadata.")); return }
        hentikanAudio()
        halamanAktif = halaman; audioRentangLabel = tr("Halaman ", "Page ") + halaman
        audioSedangJuz = true; audioSedangAyat = false
        audioGlobalSaatIni = range.first; audioGlobalAkhir = range.last
        val posisi = posisiSurahAyatDariGlobal(audioGlobalSaatIni) ?: return
        nomorSurah = posisi.first; nomorAyat = posisi.second
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
        tampilkanPembaca(); tombolAudioAktif = tombolAudioAyat
        mulaiAudio(urlAudioAyatAktif, tr("Memutar halaman ", "Playing page ") + halaman + " · " + nomorSurah + ":" + nomorAyat)
    }

    private fun pilihJuzUntukDiputar() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        if (qariId.startsWith("mp3quran|")) {
            toast(tr("Pemutaran juz berurutan per ayat tersedia untuk qari CDN; qari MP3Quran hanya menyediakan audio per surah.", "Juz-by-verse playback is available for CDN reciters; MP3Quran reciters provide surah audio only.")); return
        }
        val labels = (1..30).map { tr("Juz ", "Juz ") + it }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz untuk diputar", "Choose juz to play"))
            .setItems(labels) { _, which ->
                putarJuz(which + 1)
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun putarJuz(juz: Int) {
        if (juz !in 1..30) { toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); return }
        if (qariId.startsWith("mp3quran|")) { toast(tr("Qari ini menyediakan audio per surah, bukan audio juz atau ayat terpisah. Pilih qari audio per ayat untuk pemutaran juz.", "This reciter provides surah audio, not separate juz or verse audio. Choose a verse-by-verse reciter to play a juz.")); return }
        val range = rentangGlobalJuz(juz)
        if (range == null) { toast(tr("Rentang ayat juz tidak tersedia. Unduh teks lengkap terlebih dahulu.", "Juz verse range is unavailable. Download the complete text first.")); return }
        hentikanAudio()
        juzAktif = juz; audioRentangLabel = tr("Juz ", "Juz ") + juz; audioSedangJuz = true; audioSedangAyat = false
        audioGlobalSaatIni = range.first; audioGlobalAkhir = range.last
        val posisi = posisiSurahAyatDariGlobal(audioGlobalSaatIni) ?: return
        nomorSurah = posisi.first; nomorAyat = posisi.second
        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
        tombolAudioAktif = tombolAudioAyat
        mulaiAudio(urlAudioAyatAktif, tr("Memutar juz ", "Playing juz ") + juz + " · " + nomorSurah + ":" + nomorAyat)
    }

    private fun dialogUnduhAudio() {
        val pilihan = arrayOf(
            tr("Unduh seluruh Al-Qur'an untuk qari ini (114 surah)", "Download the full Qur'an for this reciter (114 surahs)"),
            tr("Unduh surah penuh (1 berkas MP3)", "Download full surah (one MP3 file)"),
            tr("Unduh semua ayat pada surah ini (berkas terpisah)", "Download all verses in this surah (separate files)"),
            tr("Unduh semua ayat dalam satu juz (berkas terpisah)", "Download all verses in one juz (separate files)")
        )
        AlertDialog.Builder(this).setCustomTitle(judulDenganPesan(tr("Unduh audio · ", "Download audio · ") + namaQari(), tr("Unduhan seluruh Al-Qur'an cukup besar dan memerlukan ruang penyimpanan. Pastikan Wi-Fi dan ruang kosong mencukupi.", "The full Qur'an download is large and needs storage space. Make sure Wi-Fi and free space are sufficient.")))
            .setItems(pilihan) { _, which ->
                if (which == 0) mulaiUnduhSemuaSurahQari()
                else if (which == 1) mulaiUnduhAudioSurah()
                else if (which == 2) mulaiUnduhRentangAyat("surah", nomorSurah)
                else pilihJuzUntukUnduh()
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihJuzUntukUnduh() {
        val labels = (1..30).map { tr("Juz ", "Juz ") + it }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz untuk diunduh", "Choose juz to download"))
            .setItems(labels) { _, which -> mulaiUnduhRentangAyat("juz", which + 1) }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun mulaiUnduhSemuaSurahQari() {
        val available: Set<Int>? = if (qariId.startsWith("mp3quran|")) {
            qariId.split("|").getOrNull(2)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet()
        } else null
        val server = if (qariId.startsWith("mp3quran|")) qariId.split("|").getOrNull(1) else null
        val items = (1..114).filter { available == null || it in available }.map { surah ->
            val url = if (server != null) server + String.format(Locale.ROOT, "%03d", surah) + ".mp3"
                else "https://cdn.islamic.network/quran/audio-surah/128/" + qariId + "/" + surah + ".mp3"
            url to ("Qari_" + namaQari().replace(Regex("[^A-Za-z0-9_-]"), "_") + "_Surah_" + String.format(Locale.ROOT, "%03d", surah) + ".mp3")
        }
        unduhDaftarAudio(items)
    }

    private fun mulaiUnduhAudioSurah() {
        val url = if (qariId.startsWith("mp3quran|")) {
            val parts = qariId.split("|")
            val available = parts.getOrNull(2)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
            if (nomorSurah !in available) { toast(tr("Surah ini tidak tersedia untuk qari pilihan.", "This surah is unavailable for the selected reciter.")); return }
            (parts.getOrNull(1) ?: return) + String.format(Locale.ROOT, "%03d", nomorSurah) + ".mp3"
        } else "https://cdn.islamic.network/quran/audio-surah/128/" + qariId + "/" + nomorSurah + ".mp3"
        val surahName = getSurah(nomorSurah)?.optString("englishName", "Surah") ?: "Surah"
        unduhDaftarAudio(listOf(url to ("Qari_" + namaQari().replace(Regex("[^A-Za-z0-9_-]"), "_") + "_Surah_" + nomorSurah + "_" + surahName.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".mp3")))
    }

    private fun mulaiUnduhRentangAyat(mode: String, nilai: Int) {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        if (qariId.startsWith("mp3quran|")) {
            toast(tr("Qari dari katalog tambahan menyediakan audio per surah, bukan per ayat. Pilih qari CDN untuk unduh per juz/ayat.", "Additional catalog reciters provide surah audio, not individual verses. Choose a CDN reciter to download by juz/verse.")); return
        }
        val items = mutableListOf<Pair<String, String>>()
        var global = 0
        val surahs = daftarSurah() ?: return
        for (i in 0 until surahs.length()) {
            val surah = surahs.optJSONObject(i) ?: continue
            val ayahs = surah.optJSONArray("ayahs") ?: continue
            for (j in 0 until ayahs.length()) {
                global++
                val a = ayahs.optJSONObject(j) ?: continue
                val selected = if (mode == "surah") i + 1 == nilai else a.optInt("juz") == nilai
                if (selected) {
                    val file = "Qari_" + namaQari().replace(Regex("[^A-Za-z0-9_-]"), "_") + "_S" + String.format(Locale.ROOT, "%03d", i + 1) + "_A" + String.format(Locale.ROOT, "%03d", j + 1) + ".mp3"
                    items.add(("https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + global + ".mp3") to file)
                }
            }
        }
        if (items.isEmpty()) { toast(tr("Tidak ada ayat yang ditemukan untuk unduhan ini.", "No verses found for this download.")); return }
        unduhDaftarAudio(items)
    }

    private fun unduhDaftarAudio(items: List<Pair<String, String>>) = pastikanIzinFolder { unduhDaftarAudioSekarang(items) }

    private fun unduhDaftarAudioSekarang(items: List<Pair<String, String>>) {
        lokasiUnduhTerakhir = ""
        val progress = android.app.ProgressDialog(this)
        progress.setTitle(tr("Mengunduh audio Al-Qur'an", "Downloading Qur'an audio"))
        progress.setMessage(tr("Menyiapkan unduhan…", "Preparing download…"))
        progress.setCancelable(false); progress.show(); dialogUnduh = progress
        Thread {
            var sukses = 0
            var gagal = 0
            try {
                for ((index, item) in items.withIndex()) {
                    runOnUiThread { progress.setMessage(tr("Mengunduh berkas ", "Downloading file ") + (index + 1) + "/" + items.size + "\n" + item.second) }
                    try { simpanAudioKePenyimpanan(item.first, item.second); sukses++ } catch (_: Exception) { gagal++ }
                }
            } finally {
                runOnUiThread {
                    try { progress.dismiss() } catch (_: Exception) { }
                    dialogUnduh = null
                    toast(tr("Unduhan selesai: ", "Download finished: ") + sukses + tr(" berhasil, ", " succeeded, ") + gagal + tr(" gagal. Folder: ", " failed. Folder: ") + lokasiUnduhTerakhir.ifBlank { "Jam Pintar Pro/Audio" })
                }
            }
        }.start()
    }

    private fun simpanAudioKePenyimpanan(url: String, namaFile: String) {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000; connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP " + code)
            val namaFolderQari = namaQari().trim()
                .replace(Regex("[\\\\/:*?\\\"<>|]"), "_")
                .replace(Regex("\\s+"), " ")
                .take(80)
                .ifBlank { "Qari" }
            val subfolderAudio = "Al-Qur'an/simpan folder audio/" + namaFolderQari
            lokasiUnduhTerakhir = simpanKePenyimpananPublik(subfolderAudio, namaFile, "audio/mpeg") { out ->
                connection.inputStream.use { input -> input.copyTo(out) }
            }
        } finally { connection.disconnect() }
    }

    // ====================================================================================
    // FOLDER "Jam Pintar Pro" (FIX54)
    // Unduhan audio dan teks disimpan otomatis ke folder "Jam Pintar Pro" di memori internal HP:
    //   Jam Pintar Pro/Al-Qur'an/simpan folder audio/<Nama Qari>  dan  Jam Pintar Pro/Teks
    // Akses langsung ke folder tingkat atas memori internal hanya diizinkan Android bila:
    //   - Android 11+ : izin "Akses semua berkas" (MANAGE_EXTERNAL_STORAGE) diberikan pengguna sekali.
    //   - Android 7-9 : izin penyimpanan (WRITE_EXTERNAL_STORAGE) diberikan.
    // Tanpa itu (atau Android 10), berkas tetap tersimpan di Download/Jam Pintar Pro agar unduhan tidak gagal.
    // ====================================================================================

    private val namaFolderAplikasi = "Jam Pintar Pro"
    private var lokasiUnduhTerakhir = ""
    private var aksiTertundaIzinFolder: (() -> Unit)? = null
    private var lewatiIzinFolder = false

    private fun aksesFolderLangsung(): Boolean = when {
        Build.VERSION.SDK_INT >= 30 -> try { Environment.isExternalStorageManager() } catch (_: Exception) { false }
        Build.VERSION.SDK_INT >= 29 -> false
        else -> checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /** Pastikan izin folder sudah ditangani (diminta satu kali per sesi), lalu jalankan unduhan. */
    private fun pastikanIzinFolder(batal: (() -> Unit)? = null, lanjut: () -> Unit) {
        if (aksesFolderLangsung() || lewatiIzinFolder || Build.VERSION.SDK_INT == 29) { lanjut(); return }
        if (Build.VERSION.SDK_INT >= 30) {
            AlertDialog.Builder(this)
                .setTitle(tr("Izinkan penyimpanan di folder Jam Pintar Pro", "Allow saving to the Jam Pintar Pro folder"))
                .setMessage(tr(
                    "Agar unduhan audio dan teks tersimpan otomatis di folder Jam Pintar Pro pada memori internal HP, aplikasi memerlukan izin Akses semua berkas. Tekan Buka pengaturan, aktifkan izin untuk Jam Pintar Pro, lalu kembali ke aplikasi; unduhan akan berlanjut otomatis.\n\nJika Anda memilih Lanjut tanpa izin, berkas disimpan di folder Download/Jam Pintar Pro.",
                    "To save downloaded audio and text automatically in the Jam Pintar Pro folder in internal storage, the app needs All files access permission. Press Open settings, turn the permission on for Jam Pintar Pro, then return to the app; the download continues automatically.\n\nIf you choose Continue without permission, files are saved in Download/Jam Pintar Pro."))
                .setPositiveButton(tr("Buka pengaturan", "Open settings")) { _, _ ->
                    aksiTertundaIzinFolder = lanjut
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + packageName)))
                    } catch (_: Exception) {
                        try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                        catch (_: Exception) { aksiTertundaIzinFolder = null; lewatiIzinFolder = true; lanjut() }
                    }
                }
                .setNeutralButton(tr("Lanjut tanpa izin", "Continue without permission")) { _, _ -> lewatiIzinFolder = true; lanjut() }
                .setNegativeButton(tr("Batal", "Cancel")) { _, _ -> if (batal != null) handler.post { batal() } }
                .setOnCancelListener { if (batal != null) handler.post { batal() } }
                .show()
        } else {
            aksiTertundaIzinFolder = lanjut
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 6906)
        }
    }

    private var kembaliSetelahLayarSistem: (() -> Unit)? = null

    override fun onResume() {
        super.onResume()
        // Kembali dari layar pengaturan sistem: buka lagi dialog asal agar tidak terlempar ke menu utama.
        val kembali = kembaliSetelahLayarSistem
        if (kembali != null) { kembaliSetelahLayarSistem = null; handler.post { kembali() } }
        // Kembali dari layar izin "Akses semua berkas": lanjutkan unduhan yang tertunda (izin diberikan atau tidak).
        val aksi = aksiTertundaIzinFolder
        if (aksi != null && Build.VERSION.SDK_INT >= 30) {
            aksiTertundaIzinFolder = null
            if (!aksesFolderLangsung()) lewatiIzinFolder = true
            handler.post { aksi() }
        }
    }

    /**
     * Tulis satu berkas ke folder "Jam Pintar Pro/<subfolder>". Mengembalikan nama folder tempat berkas tersimpan.
     * Dipanggil dari thread latar belakang.
     */
    private fun simpanKePenyimpananPublik(subfolder: String, namaFile: String, mime: String, tulis: (java.io.OutputStream) -> Unit): String {
        val relatif = namaFolderAplikasi + "/" + subfolder
        if (aksesFolderLangsung()) {
            val folder = File(Environment.getExternalStorageDirectory(), relatif)
            if (!folder.exists() && !folder.mkdirs() && !folder.exists()) throw IllegalStateException(tr("Tidak dapat membuat folder ", "Cannot create folder ") + relatif)
            val tujuan = File(folder, namaFile)
            val sementara = File(folder, namaFile + ".tmp")
            try {
                sementara.outputStream().use { tulis(it) }
                if (tujuan.exists()) tujuan.delete()
                if (!sementara.renameTo(tujuan)) throw IllegalStateException(tr("Tidak dapat menyimpan ", "Cannot save ") + namaFile)
            } catch (e: Exception) { sementara.delete(); throw e }
            try { MediaScannerConnection.scanFile(this, arrayOf(tujuan.absolutePath), null, null) } catch (_: Exception) { }
            return relatif
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val relatifDownload = "Download/" + relatif
            try {
                contentResolver.delete(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                    arrayOf(namaFile, relatifDownload + "/"))
            } catch (_: Exception) { }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, namaFile)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relatifDownload)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException(tr("Tidak dapat membuat berkas tujuan", "Cannot create the target file"))
            try {
                contentResolver.openOutputStream(uri)?.use { tulis(it) } ?: throw IllegalStateException(tr("Tidak dapat membuka berkas tujuan", "Cannot open the target file"))
                contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
            return relatifDownload
        }
        // Android 7-9 tanpa izin penyimpanan: folder khusus aplikasi.
        val dasar = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
        val folder = File(dasar, relatif)
        if (!folder.exists() && !folder.mkdirs() && !folder.exists()) throw IllegalStateException(tr("Tidak dapat membuat folder", "Cannot create folder"))
        File(folder, namaFile).outputStream().use { tulis(it) }
        return folder.absolutePath
    }

    private fun teksPengulanganAyat(): String = (if (modeHafalan == "kelompok") teksKelompok() + " " else "") + when (pengulanganAyat) {
        0 -> tr("Ayat diulang terus sampai audio dihentikan.", "Repeat verse continuously until audio is stopped.")
        1 -> tr("Setiap ayat diputar satu kali.", "Each verse plays once.")
        else -> tr("Setiap ayat diputar ", "Each verse plays ") + pengulanganAyat + tr(" kali.", " times.")
    }

    private fun pengaturanPengulanganAyat() {
        // Beri pilihan jumlah yang berurutan agar pengguna dapat mengatur 1, 2, 3, ... 10 kali.
        // Nilai 0 berarti pengulangan terus-menerus sampai dihentikan pengguna.
        val values = (1..10).toList() + 0
        val labels = (1..10).map { n ->
            if (BahasaAplikasi.tampilan(this) == 1) {
                when (n) { 1 -> "1 time"; else -> ("" + (n) + " times") }
            } else {
                ("" + (n) + " kali")
            }
        }.toMutableList().apply { add(tr("Terus-menerus", "Continuous")) }.toTypedArray()
        val selected = values.indexOf(pengulanganAyat).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(tr("Pengulangan murattal ayat", "Verse recitation repeat"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in values.indices) {
                    pengulanganAyat = values[which]
                    dataPrefs.edit().putInt("pengulangan_audio_ayat", pengulanganAyat).apply()
                    toast(teksPengulanganAyat())
                    dialog.dismiss()
                    perbaruiStatusAudio(tr("Pengulangan audio diatur: ", "Audio repeat set: ") + labels[which])
                    handler.post { dialogPengaturanHafalan() }
                }
            }.kembaliKe(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { dialogPengaturanHafalan() }.show()
    }

    private fun pengaturanKecepatanAudio() {
        val values = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)
        val labels = if (BahasaAplikasi.tampilan(this) == 1) arrayOf("0.75x", "1.0x", "1.25x", "1.5x") else arrayOf("0,75x", "1,0x", "1,25x", "1,5x")
        val selected = values.indices.firstOrNull { kotlin.math.abs(values[it] - kecepatanAudio) < 0.001f } ?: 1
        AlertDialog.Builder(this).setTitle(tr("Kecepatan murattal", "Recitation speed"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                if (which in values.indices) {
                    kecepatanAudio = values[which]
                    dataPrefs.edit().putFloat("kecepatan_audio", kecepatanAudio).apply()
                    if (Build.VERSION.SDK_INT >= 23) {
                        try { pemutar?.let { player -> player.playbackParams = player.playbackParams.setSpeed(kecepatanAudio) } } catch (_: Exception) { }
                    }
                    toast(tr("Kecepatan murattal diubah menjadi ", "Recitation speed changed to ") + labels[which])
                    dialog.dismiss()
                    perbaruiStatusAudio(tr("Kecepatan audio diatur ke ", "Audio speed set to ") + labels[which])
                    handler.post { dialogPengaturanAudio() }
                }
            }.kembaliKe(tr("Kembali ke pengaturan audio", "Back to audio settings")) { dialogPengaturanAudio() }.show()
    }

    /**
     * Coba bitrate pada host CDN yang sama. Jangan mengganti host ke domain
     * alternatif yang belum terverifikasi memiliki struktur endpoint yang sama.
     */
    private fun urlAudioPercobaan(url: String, percobaan: Int): String {
        if (audioTerjemahanAktif) return url
        if (qariId.startsWith("mp3quran|")) return urlSumberMp3Quran(url).getOrElse(percobaan) { url }
        val bitrate = listOf("128", "64", "48", "40", "32", "192").getOrElse(percobaan) { "128" }
        return url.replace(Regex("/audio/\\d+/"), "/audio/" + bitrate + "/")
            .replace(Regex("/audio-surah/\\d+/"), "/audio-surah/" + bitrate + "/")
    }

    private fun mulaiAudio(url: String, pesanMemuat: String, percobaan: Int = 0, generasi: Int = ++audioGenerasi, otomatis: Boolean = false) {
        audioTerjemahanAktif = url.startsWith(URL_DASAR_TERJEMAHAN_ID)
        val urlPercobaan = urlAudioPercobaan(url, percobaan)
        try {
            val lama = pemutar
            pemutar = null
            audioSiap = false
            perbaruiTombolJedaAudio(true)
            try { lama?.setOnPreparedListener(null) } catch (_: Exception) { }
            try { lama?.setOnCompletionListener(null) } catch (_: Exception) { }
            try { lama?.setOnErrorListener(null) } catch (_: Exception) { }
            try { lama?.release() } catch (_: Exception) { }

            val p: PemutarAudio = if (keluaranMono) PemutarMono() else PemutarStereo()
            pemutar = p
            // Sesi audio bersama harus dipasang sebelum prepare agar Equalizer menjangkau audio ini.
            if (pastikanSesiAudio()) {
                try { p.setAudioSessionId(sesiAudioEfek) } catch (_: Exception) { }
                terapkanEqualizer()
            }
            // Hindari status "Menghubungkan audio…" yang menggantung bila jaringan tidak
            // pernah mengembalikan callback prepared/error.
            val timeoutAudio = Runnable {
                if (generasi == audioGenerasi && pemutar === p && !audioSiap) {
                    pemutar = null
                    try { p.setOnPreparedListener(null) } catch (_: Exception) { }
                    try { p.setOnCompletionListener(null) } catch (_: Exception) { }
                    try { p.setOnErrorListener(null) } catch (_: Exception) { }
                    try { p.release() } catch (_: Exception) { }
                    if (percobaan < maksPercobaanAudio(url)) {
                        tombolStatusAudio?.text = tr("Sumber audio belum merespons. Mencoba sumber/bitrate alternatif…", "Audio source did not respond. Trying an alternate source/bitrate…")
                        mulaiAudio(url, pesanMemuat, percobaan + 1, generasi, otomatis)
                    } else {
                        tombolStatusAudio?.text = tr("Audio tidak berhasil dimuat dari beberapa sumber. Periksa apakah jaringan mengizinkan akses ke server audio, lalu coba lagi.", "Audio could not load from multiple sources. Check whether your network allows access to the audio servers, then try again.")
                        tombolAudioAktif?.text = tr("Coba putar murattal lagi", "Try playing the murattal again")
                        diagnosaAudio(urlPercobaan, generasi)
                    }
                }
            }
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setOnPreparedListener { siap ->
                handler.removeCallbacks(timeoutAudio)
                if (generasi != audioGenerasi || pemutar !== siap) { try { siap.release() } catch (_: Exception) { }; return@setOnPreparedListener }
                audioSiap = true
                if (Build.VERSION.SDK_INT >= 23) {
                    try { siap.playbackParams = siap.playbackParams.setSpeed(kecepatanAudio) } catch (_: Exception) { }
                }
                // Cadangan: bila perangkat tidak menerima sesi audio bersama, pakai sesi milik pemutar ini.
                if (siap.audioSessionId > 0 && siap.audioSessionId != sesiAudioEfek) {
                    lepasEfekAudio()
                    sesiAudioEfek = siap.audioSessionId
                }
                val eqAktif = terapkanEqualizer()
                if (!eqAktif && presetEqualizer != "normal") {
                    umumkanAudio(tombolStatusAudio, tr("Equalizer belum aktif. ", "Equalizer is not active. ") + statusEqualizer.ifBlank { tr("belum aktif", "not active yet") }, otomatis)
                }
                siap.start()
                perbaruiTombolJedaAudio(false)
                tombolAudioAktif?.text = if (audioTerjemahanAktif) tr("Terjemahan sedang diputar", "Translation is playing") else tr("Murattal sedang diputar", "Murattal is playing")
                tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
                tombolStatusAudio?.text = if (audioTerjemahanAktif) tr("Sedang memutar audio terjemahan Indonesia, surah ", "Playing Indonesian translation audio, surah ") + nomorSurah
                    else tr("Sedang memutar audio. Qari: ", "Playing audio. Reciter: ") + namaQari() + ". " + namaModeHafalan()
                umumkanAudio(tombolStatusAudio, tombolStatusAudio?.text, otomatis)
            }
            p.setOnCompletionListener { selesai ->
                if (generasi != audioGenerasi || pemutar !== selesai) return@setOnCompletionListener
                audioSiap = false
                perbaruiTombolJedaAudio(true)
                if (audioSedangJuz) {
                    if (audioGlobalSaatIni < audioGlobalAkhir) {
                        audioGlobalSaatIni++
                        val posisi = posisiSurahAyatDariGlobal(audioGlobalSaatIni) ?: run { audioSedangJuz = false; return@setOnCompletionListener }
                        nomorSurah = posisi.first; nomorAyat = posisi.second
                        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + audioGlobalSaatIni + ".mp3"
                        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
                        tombolStatusAudio?.text = (if (audioRentangLabel.isNotBlank()) tr("Melanjutkan ", "Continuing ") + audioRentangLabel else tr("Memutar juz ", "Playing juz ") + juzAktif) + " · " + nomorSurah + ":" + nomorAyat
                        redamTalkBackSaatPergantian()
                        mulaiAudio(urlAudioAyatAktif, tombolStatusAudio?.text?.toString() ?: "", otomatis = true)
                    } else {
                        audioSedangJuz = false
                        val labelSelesai = if (audioRentangLabel.isNotBlank()) audioRentangLabel else tr("Juz", "Juz")
                        tombolStatusAudio?.text = labelSelesai + tr(" selesai diputar.", " playback completed.")
                        audioRentangLabel = ""
                        tombolAudioAktif?.text = labelSelesai + tr(" selesai", " completed")
                        if (!koreksiAudioAktif) selesaiKembaliKeMenu(labelSelesai + tr(" selesai diputar.", " playback completed."))
                    }
                    return@setOnCompletionListener
                }
                if (audioSedangAyat && modeHafalan != "biasa" && (pengulanganAyat == 0 || sisaPengulanganAyat > 1)) {
                    if (sisaPengulanganAyat > 1) sisaPengulanganAyat--
                    tombolStatusAudio?.text = tr("Mengulang ayat ", "Repeating verse ") + nomorSurah + ":" + nomorAyat + tr(" · sisa pengulangan ", " · repeats remaining ") + if (sisaPengulanganAyat == 0) tr("tanpa batas", "unlimited") else sisaPengulanganAyat
                    redamTalkBackSaatPergantian()
                    handler.postDelayed({
                        if (generasi == audioGenerasi && audioSedangAyat) mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif, otomatis = true)
                    }, 250L)
                    return@setOnCompletionListener
                }
                if (audioSedangAyat && modeHafalan == "kelompok") {
                    lanjutDalamKelompok(generasi)
                    return@setOnCompletionListener
                }
                if (audioSedangAyat && modeHafalan == "berurutan") {
                    val globalBerikut = nomorAyatGlobal() + 1
                    val posisiBerikut = posisiSurahAyatDariGlobal(globalBerikut)
                    if (posisiBerikut != null) {
                        nomorSurah = posisiBerikut.first
                        nomorAyat = posisiBerikut.second
                        sisaPengulanganAyat = pengulanganAyat
                        urlAudioAyatAktif = "https://cdn.islamic.network/quran/audio/128/" + qariId + "/" + globalBerikut + ".mp3"
                        pesanAudioAyatAktif = tr("Mode hafalan · ayat ", "Memorization mode · verse ") + nomorSurah + ":" + nomorAyat
                        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
                        tombolStatusAudio?.text = tr("Jeda hafalan, ayat berikutnya ", "Memorization pause, next verse ") + nomorSurah + ":" + nomorAyat
                        redamTalkBackSaatPergantian()
                        umumkanAudio(tombolStatusAudio, tombolStatusAudio?.text, true)
                        handler.postDelayed({
                            if (generasi == audioGenerasi && audioSedangAyat && modeHafalan == "berurutan") mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif, otomatis = true)
                        }, jedaAntarAyatDetik * 1000L)
                        return@setOnCompletionListener
                    }
                    audioSedangAyat = false
                    tombolStatusAudio?.text = tr("Hafalan berurutan selesai sampai akhir Al-Qur'an.", "Sequential memorization reached the end of the Qur'an.")
                }
                tombolAudioAktif?.text = if (audioTerjemahanAktif) tr("Terjemahan selesai; tekan untuk memutar lagi", "Translation finished; press to replay") else tr("Murattal selesai; tekan untuk memutar lagi", "Recitation finished; press to replay")
                tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
                tombolStatusAudio?.text = tr("Pemutaran audio selesai.", "Audio playback completed.")
                if (koreksiAudioAktif && koreksiUlangSisa > 0 && statusKoreksiHafalan != null) {
                    // FIX104: koreksi cerdas memutar audio yang benar dua kali setelah gagal berturut-turut.
                    koreksiUlangSisa--
                    handler.postDelayed({ if (generasi == audioGenerasi && statusKoreksiHafalan != null) mulaiAudio(urlAudioAyatAktif, pesanAudioAyatAktif, otomatis = true) }, 700L)
                    return@setOnCompletionListener
                }
                if (koreksiAudioAktif) {
                    koreksiAudioAktif = false
                    if (statusKoreksiHafalan != null) {
                        val selesai = tr("Audio bacaan yang benar selesai. Tekan Ulangi membaca untuk mencoba lagi.", "The correct recitation has finished. Press Recite again to try once more.")
                        setStatusKoreksi(selesai, !modaSenyapKoreksi)
                        getarIsyarat(120L)
                    }
                } else selesaiKembaliKeMenu(tr("Pemutaran audio selesai.", "Audio playback completed."))
            }
            p.setOnErrorListener { gagal, _, _ ->
                handler.removeCallbacks(timeoutAudio)
                if (generasi != audioGenerasi || pemutar !== gagal) return@setOnErrorListener true
                try { gagal.reset() } catch (_: Exception) { }
                try { gagal.release() } catch (_: Exception) { }
                pemutar = null
                audioSiap = false
                perbaruiTombolJedaAudio(true)
                if (percobaan < maksPercobaanAudio(url)) {
                    tombolStatusAudio?.text = tr("Sumber audio gagal. Mencoba sumber/bitrate alternatif…", "Audio source failed. Trying an alternate source/bitrate…")
                    mulaiAudio(url, pesanMemuat, percobaan + 1, generasi, otomatis)
                } else {
                    tombolStatusAudio?.text = tr("Audio gagal diputar setelah mencoba beberapa sumber. Masalah dapat berasal dari server, qari, atau akses jaringan ke CDN; Wi-Fi tersambung saja belum memastikan server audio dapat dijangkau.", "Audio failed after trying multiple sources. The issue may be the server, reciter, or network access to the CDN; a connected Wi-Fi does not guarantee the audio server is reachable.")
                    toast(tr("Audio gagal dari beberapa sumber. Coba qari lain atau coba lagi nanti.", "Audio failed from multiple sources. Try another reciter or try again later."))
                    tombolAudioAktif?.text = tr("Coba putar murattal lagi", "Try playing the murattal again")
                    diagnosaAudio(urlPercobaan, generasi)
                }
                true
            }
            // Berikan header HTTP yang lazim untuk pemutar media Android. Beberapa CDN
            // dapat merespons berbeda terhadap permintaan tanpa User-Agent eksplisit.
            val headerAudio = mapOf(
                "User-Agent" to ("Mozilla/5.0 (Linux; Android " + (Build.VERSION.RELEASE) + ") AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"),
                "Accept" to "audio/mpeg,audio/*;q=0.9,*/*;q=0.8"
            )
            p.setDataSource(this, Uri.parse(urlPercobaan), headerAudio)
            tombolAudioAktif?.text = tr("Menghubungkan audio…", "Connecting to audio…")
            tombolAudioAktif?.contentDescription = tombolAudioAktif?.text
            tombolStatusAudio?.text = pesanMemuat
            p.prepareAsync()
            handler.postDelayed(timeoutAudio, 30000L)
        } catch (_: Exception) {
            val gagal = pemutar
            pemutar = null
            audioSiap = false
            perbaruiTombolJedaAudio(true)
            try { gagal?.setOnPreparedListener(null) } catch (_: Exception) { }
            try { gagal?.setOnCompletionListener(null) } catch (_: Exception) { }
            try { gagal?.setOnErrorListener(null) } catch (_: Exception) { }
            try { gagal?.release() } catch (_: Exception) { }
            if (percobaan < maksPercobaanAudio(url)) {
                mulaiAudio(url, pesanMemuat, percobaan + 1, generasi, otomatis)
            } else {
                tombolStatusAudio?.text = tr("Audio tidak dapat dimuat setelah mencoba beberapa sumber. Coba qari lain atau coba lagi nanti.", "Audio could not load after trying multiple sources. Try another reciter or try again later.")
                toast(tr("Audio tidak dapat dimuat dari beberapa sumber.", "Audio could not load from multiple sources."))
                tombolAudioAktif?.text = tr("Coba putar murattal lagi", "Try playing the murattal again")
                diagnosaAudio(urlPercobaan, generasi)
            }
        }
    }

    /**
     * Saat semua percobaan gagal, periksa server di latar belakang dan tambahkan penyebab yang jelas
     * pada status audio (berkas tidak ada, server tidak terjangkau, DNS, sambungan aman, atau batas waktu).
     */
    private fun diagnosaAudio(url: String, generasiAsal: Int) {
        Thread {
            val hasil: String = try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "GET"
                c.setRequestProperty("Range", "bytes=0-0")
                c.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val kode = c.responseCode
                c.disconnect()
                when {
                    kode in 200..299 -> tr("Diagnosis: server audio dapat dijangkau (HTTP " + kode + "), tetapi pemutar perangkat tidak dapat membuka berkas ini. Coba qari lain.", "Diagnosis: the audio server is reachable (HTTP " + kode + "), but the device player cannot open this file. Try another reciter.")
                    kode == 404 -> tr("Diagnosis: berkas audio tidak ada di server (HTTP 404) untuk qari atau surah ini. Pilih qari lain.", "Diagnosis: the audio file does not exist on the server (HTTP 404) for this reciter or surah. Choose another reciter.")
                    else -> tr("Diagnosis: server menjawab HTTP " + kode + ".", "Diagnosis: the server answered HTTP " + kode + ".")
                }
            } catch (e: java.net.UnknownHostException) {
                tr("Diagnosis: nama server audio tidak dapat ditemukan. Periksa internet, DNS pribadi, atau VPN.", "Diagnosis: the audio server name could not be resolved. Check the internet connection, private DNS, or VPN.")
            } catch (e: java.net.SocketTimeoutException) {
                tr("Diagnosis: koneksi ke server audio melewati batas waktu. Jaringan mungkin lambat atau memblokir server ini.", "Diagnosis: the connection to the audio server timed out. The network may be slow or blocking this server.")
            } catch (e: javax.net.ssl.SSLException) {
                tr("Diagnosis: sambungan aman (HTTPS) gagal. Periksa tanggal dan jam perangkat.", "Diagnosis: the secure (HTTPS) connection failed. Check the device date and time.")
            } catch (e: Exception) {
                tr("Diagnosis: server audio tidak dapat dijangkau (", "Diagnosis: the audio server could not be reached (") + (e.javaClass.simpleName) + ")."
            }
            runOnUiThread {
                if (generasiAsal == audioGenerasi) {
                    val lama = tombolStatusAudio?.text?.toString().orEmpty()
                    tombolStatusAudio?.text = lama + " " + hasil
                    tombolStatusAudio?.contentDescription = tombolStatusAudio?.text
                }
            }
        }.start()
    }

    // Suara TalkBack saat pergantian audio otomatis (FIX52). Bawaan: tetap aktif (false).
    private var senyapTalkBackPergantian = false

    /** Umumkan lewat TalkBack; pengumuman pergantian audio otomatis dilewati bila pengguna memilih mematikannya. */
    private fun umumkanAudio(tampilan: android.view.View?, pesan: CharSequence?, pergantian: Boolean = false) {
        if (pesan.isNullOrBlank()) return
        if (pergantian && senyapTalkBackPergantian) return
        tampilan?.announceForAccessibility(pesan)
    }

    /** Dipanggil saat audio berpindah otomatis: hentikan ucapan TalkBack yang sedang berjalan agar tidak menimpa audio berikutnya. */
    private fun redamTalkBackSaatPergantian() {
        if (!senyapTalkBackPergantian) return
        try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
    }

    private fun perbaruiStatusAudio(pesan: String, pergantian: Boolean = false) {
        tombolStatusAudio?.text = pesan
        tombolStatusAudio?.contentDescription = pesan
        umumkanAudio(tombolStatusAudio, pesan, pergantian)
    }


    private fun perbaruiTombolJedaAudio(dijeda: Boolean? = null) {
        val p = pemutar
        val siap = audioSiap && p != null
        val sedangJalan = dijeda?.let { !it } ?: (p?.isPlaying == true)
        val label = when {
            !siap -> tr("JEDA ATAU LANJUTKAN AUDIO", "PAUSE OR RESUME AUDIO")
            sedangJalan -> tr("JEDA AUDIO SEKARANG", "PAUSE AUDIO NOW")
            else -> tr("LANJUTKAN AUDIO", "RESUME AUDIO")
        }
        tombolJedaAudio?.text = if (!siap) tr("Putar", "Play") else if (sedangJalan) tr("Jeda", "Pause") else tr("Lanjutkan", "Resume")
        tombolJedaAudio?.contentDescription = when {
            !siap -> tr("Putar audio", "Play audio")
            sedangJalan -> tr("Jeda audio", "Pause audio")
            else -> tr("Lanjutkan audio", "Resume audio")
        }
    }

    private fun jedaLanjutAudio() {
        val p = pemutar
        if (p == null || !audioSiap) {
            mulaiSesuaiPengaturan()
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
                perbaruiTombolJedaAudio(true)
                tombolJedaAudio?.announceForAccessibility(tombolJedaAudio?.contentDescription)
                perbaruiStatusAudio(if (audioTerjemahanAktif) tr("Terjemahan dijeda. Fokuskan tombol Lanjutkan Audio untuk meneruskan.", "Translation paused. Focus the Resume Audio button to continue.") else tr("Murattal dijeda. Fokuskan tombol Lanjutkan Audio untuk meneruskan.", "Recitation paused. Focus the Resume Audio button to continue."))
                toast(if (audioTerjemahanAktif) tr("Terjemahan dijeda.", "Translation paused.") else tr("Murattal dijeda.", "Murattal paused."))
            } else {
                p.start()
                perbaruiTombolJedaAudio(false)
                tombolJedaAudio?.announceForAccessibility(tombolJedaAudio?.contentDescription)
                perbaruiStatusAudio(if (audioTerjemahanAktif) tr("Terjemahan dilanjutkan.", "Translation resumed.") else tr("Murattal dilanjutkan.", "Recitation resumed."))
                toast(if (audioTerjemahanAktif) tr("Terjemahan dilanjutkan.", "Translation resumed.") else tr("Murattal dilanjutkan.", "Murattal resumed."))
            }
        } catch (_: Exception) {
            toast(tr("Audio tidak dapat dilanjutkan. Tekan tombol murattal untuk memutar ulang.", "Audio could not resume. Press the murattal button to replay."))
        }
    }

    private fun hentikanAudio() {
        audioGenerasi++
        koreksiAudioAktif = false
        koreksiUlangSisa = 0
        audioSedangAyat = false
        audioSedangJuz = false
        sisaPengulanganAyat = 1
        handler.removeCallbacksAndMessages(null)
        val p = pemutar
        pemutar = null
        audioSiap = false
        try { p?.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p?.setOnCompletionListener(null) } catch (_: Exception) { }
        try { if (p?.isPlaying == true) p.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
        try { ttsTerjemahan?.stop() } catch (_: Exception) { }
        tombolAudio?.text = tr("Putar murattal seluruh surah", "Play the whole surah recitation")
        tombolAudio?.contentDescription = tombolAudio?.text
        tombolAudioAyat?.text = tr("Putar murattal ayat ini", "Play this verse's recitation")
        tombolAudioAyat?.contentDescription = tombolAudioAyat?.text
        tombolAudioAktif = null
        perbaruiTombolJedaAudio(true)
        tombolStatusAudio?.text = tr("Audio dihentikan.", "Audio stopped.")
    }

    private fun keyAyat() = ("" + (nomorSurah) + ":" + (nomorAyat))
    private fun tandaiPosisi() {
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val today = tanggalHariIni()
        dataPrefs.edit().putString("posisi_terakhir", ("" + (nomorSurah) + ":" + (nomorAyat) + "|" + (today))).apply()
        toast(tr("Posisi bacaan disimpan.", "Reading position saved."))
    }

    private fun ayatSudahSelesai(): Boolean =
        dataPrefs.getStringSet("ayat_selesai", emptySet())?.contains(keyAyat()) == true

    private fun perbaruiLabelTandaAyat() {
        tombolTandaiAyat?.text = if (ayatSudahSelesai())
            tr("Batalkan tanda selesai untuk ayat ini", "Unmark this verse as completed")
        else tr("Tandai ayat selesai dibaca", "Mark verse as read")
        tombolTandaiAyat?.contentDescription = tombolTandaiAyat?.text
    }

    private fun tandaiAyatSelesai() {
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.toMutableSet() ?: mutableSetOf()
        val key = keyAyat()
        val added = completed.add(key)
        dataPrefs.edit().putStringSet("ayat_selesai", completed).putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val dayKey = ("selesai_" + tanggalHariIni())
        val daily = dataPrefs.getStringSet(dayKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        daily.add(key)
        dataPrefs.edit().putStringSet(dayKey, daily).apply()
        perbaruiLabelTandaAyat()
        toast(if (added) tr("Ayat ditandai selesai. Kemajuan diperbarui.", "Verse marked as read. Progress updated.") else tr("Ayat ini sudah tercatat sebagai selesai.", "This verse is already marked as read."))
    }

    private fun batalkanTandaAyatSelesai() {
        val key = keyAyat()
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.toMutableSet() ?: mutableSetOf()
        completed.remove(key)
        val editor = dataPrefs.edit().putStringSet("ayat_selesai", completed)
        // Hapus ayat ini dari catatan harian juga agar statistik dan riwayat tetap konsisten.
        dataPrefs.all.keys.filter { it.startsWith("selesai_") }.forEach { dayKey ->
            val daily = dataPrefs.getStringSet(dayKey, emptySet())?.toMutableSet() ?: mutableSetOf()
            if (daily.remove(key)) editor.putStringSet(dayKey, daily)
        }
        editor.apply()
        perbaruiLabelTandaAyat()
        toast(tr("Tanda selesai dibatalkan. Statistik diperbarui.", "Completion mark removed. Statistics updated."))
    }

    private fun ringkasanKemajuan(): String {
        val completed = (dataPrefs.getStringSet("ayat_selesai", emptySet())?.size ?: 0).coerceIn(0, jumlahAyatTotal())
        val today = dataPrefs.getStringSet("selesai_" + tanggalHariIni(), emptySet())?.size ?: 0
        val percent = completed * 100.0 / jumlahAyatTotal()
        val goal = dataPrefs.getInt("target_hari", 0)
        return buildString {
            append(tr("Kemajuan saat ini: ", "Current progress: "))
            append(completed).append(" / ").append(jumlahAyatTotal()).append(" ").append(tr("ayat", "verses"))
            append(" ( ").append(String.format(Locale.ROOT, "%.2f", percent)).append("% ).\n")
            append(tr("Ayat ditandai hari ini: ", "Verses marked today: ")).append(today).append(".\n")
            append(tr("Sisa ayat yang belum ditandai: ", "Verses remaining to mark: ")).append(jumlahAyatTotal() - completed).append(".\n")
            append(tr("Target: ", "Goal: ")).append(if (goal == 0) tr("belum ditentukan", "not set") else ("" + (goal) + " ") + tr("hari", "days"))
        }
    }

    private fun pengaturanTarget() {
        val options = arrayOf(tr("30 hari", "30 days"), tr("60 hari", "60 days"), tr("90 hari", "90 days"), tr("Tentukan jumlah hari sendiri", "Choose a custom number of days"), tr("Tanpa target", "No target"))
        AlertDialog.Builder(this).setTitle(tr("Pilih target khatam", "Choose a Khatam goal")).setItems(options) { _, which ->
            when (which) {
                0,1,2 -> { simpanTarget(listOf(30,60,90)[which]); handler.post { dialogPengaturanKhatam() } }
                3 -> {
                    val input = android.widget.EditText(this); input.inputType = android.text.InputType.TYPE_CLASS_NUMBER; input.hint = tr("Jumlah hari (1–3650)", "Number of days (1–3650)")
                    AlertDialog.Builder(this).setTitle(tr("Target khusus", "Custom goal")).setView(input)
                        .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                            val days = input.text.toString().toIntOrNull()
                            if (days != null && days in 1..3650) { simpanTarget(days); handler.post { dialogPengaturanKhatam() } }
                            else { toast(tr("Masukkan angka 1 sampai 3650.", "Enter a number from 1 to 3650.")); handler.post { pengaturanTarget() } }
                        }
                        .kembaliKe(tr("Kembali ke pilihan target", "Back to goal options")) { pengaturanTarget() }
                        .show()
                }
                else -> { dataPrefs.edit().putInt("target_hari", 0).remove("target_mulai").apply(); toast(tr("Target khatam dinonaktifkan. Kemajuan tetap disimpan.", "Khatam goal disabled. Progress will still be saved.")); handler.post { dialogPengaturanKhatam() } }
            }
        }.kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }.show()
    }

    private fun simpanTarget(days: Int) {
        dataPrefs.edit().putInt("target_hari", days).putLong("target_mulai", System.currentTimeMillis()).apply()
        toast(tr("Target disimpan: ", "Goal saved: ") + ("" + (days) + " ") + tr("hari. Baca sesuai kemampuan; target dapat diubah kapan saja.", "days. Read at your own pace; you can change the goal anytime."))
    }

    private fun jumlahAyatTotal(): Int = 6236
    private fun urutanGlobal(s: Int, a: Int): Int {
        val surahs = daftarSurah() ?: return 0
        var count = 0
        for (i in 0 until (s - 1).coerceIn(0, surahs.length())) count += surahs.optJSONObject(i)?.optInt("numberOfAyahs", 0) ?: 0
        return count + a
    }

    private fun tampilkanStatistik() {
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.size ?: 0
        val goal = dataPrefs.getInt("target_hari", 0)
        val remaining = (jumlahAyatTotal() - completed).coerceAtLeast(0)
        val start = dataPrefs.getLong("target_mulai", 0L)
        val elapsed = if (start > 0L) (((System.currentTimeMillis() - start).coerceAtLeast(0L)) / 86400000L).toInt() else 0
        val daysLeft = if (goal > 0) (goal - elapsed).coerceAtLeast(1) else 0
        val perDay = if (goal > 0) kotlin.math.ceil(remaining.toDouble() / daysLeft).toInt() else 0
        val today = dataPrefs.getStringSet(("selesai_" + tanggalHariIni()), emptySet())?.size ?: 0
        val pct = completed.coerceIn(0, jumlahAyatTotal()) * 100.0 / jumlahAyatTotal()
        val msg = buildString {
            append(tr("Ayat yang ditandai selesai: ", "Verses marked as read: ")).append(completed).append(" / 6236\n")
            append(tr("Kemajuan: ", "Progress: ")).append(String.format(Locale.ROOT, "%.2f", pct)).append("%\n")
            append(tr("Sisa ayat yang belum ditandai: ", "Verses remaining to mark: ")).append(remaining).append("\n")
            append(tr("Ayat ditandai hari ini: ", "Verses marked today: ")).append(today).append("\n")
            append(tr("Target: ", "Goal: ")).append(if (goal == 0) tr("tanpa target", "no goal") else ("" + (goal) + " ") + tr("hari", "days"))
            if (goal > 0) {
                append("\n").append(tr("Hari target yang telah berlalu: ", "Goal days elapsed: ")).append(elapsed.coerceAtMost(goal)).append(" / ").append(goal)
                append("\n").append(tr("Perkiraan ayat tersisa per hari agar sesuai target: ", "Approximate remaining verses per day to meet the goal: ")).append(perDay)
            }
            if (remaining == 0) append("\n\n").append(tr("Alhamdulillah, semua 6.236 ayat sudah ditandai selesai. Semoga Allah menerima amal ibadah kita.", "Praise be to Allah, all 6,236 verses have been marked complete. May Allah accept our worship."))
            append("\n\n").append(tr("Kemajuan dihitung dari ayat yang Anda tandai selesai, bukan dari audio yang hanya diputar. Tidak ada teguran jika target harian terlewat.", "Progress counts verses you mark as read, not audio that was merely played. There is no penalty for missing a daily target."))
        }
        AlertDialog.Builder(this).setTitle(tr("Kemajuan dan statistik", "Progress and statistics"))
            .setMessage(msg)
            .setPositiveButton(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { _, _ -> handler.post { dialogPengaturanKhatam() } }
            .setOnCancelListener { handler.post { dialogPengaturanKhatam() } }
            .show()
    }

    private fun tampilkanRiwayat() {
        val all = dataPrefs.all
        val rows = all.keys.filter { it.startsWith("selesai_") }.sortedDescending().take(30).map { key ->
            val day = key.removePrefix("selesai_")
            val count = (all[key] as? Set<*>)?.size ?: 0
            ("" + (day) + ", " + (count) + " ") + tr("ayat", "verses")
        }
        val posisi = dataPrefs.getString("posisi_terakhir", "") ?: ""
        val posisiText = if (posisi.isNotBlank()) {
            val bagianPosisi = posisi.split("|")
            val ref = bagianPosisi.firstOrNull().orEmpty()
            val tanggal = bagianPosisi.getOrNull(1).orEmpty()
            tr("Posisi terakhir: ", "Last position: ") + ref + if (tanggal.isNotBlank()) (" (" + (tanggal) + ")") else ""
        } else tr("Posisi terakhir belum disimpan secara terpisah.", "The last position has not been saved separately.")
        val aktivitas = if (rows.isEmpty()) tr("Belum ada riwayat ayat yang ditandai selesai.", "There is no history of verses marked as read yet.") else rows.joinToString("\n")
        val message = posisiText + "\n\n" + tr("Aktivitas harian (hingga 30 hari dengan data):", "Daily activity (up to 30 days with data):") + "\n" + aktivitas
        AlertDialog.Builder(this).setTitle(tr("Riwayat bacaan", "Reading history"))
            .setMessage(message)
            .setPositiveButton(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { _, _ -> handler.post { dialogPengaturanKhatam() } }
            .setOnCancelListener { handler.post { dialogPengaturanKhatam() } }
            .show()
    }

    // ===== FIX103: pengingat cerdas hafalan (pengulangan berjarak) =====
    private fun namaSurahPendek(n: Int): String {
        return n.toString() + ". " + HafalanSrs.namaSurah(n)
    }

    private fun labelAyatHafalan(item: HafalanSrs.Item, hari: Long): String {
        val telat = item.terlambat(hari)
        val ket = if (telat > 0) tr(" · terlambat " + telat + " hari", " · " + telat + " day(s) overdue") else tr(" · jatuh tempo hari ini", " · due today")
        return namaSurahPendek(item.surah) + tr(" ayat ", " verse ") + item.ayat + ket + (if (item.salah > 0) tr(" · salah " + item.salah + "x", " · missed " + item.salah + "x") else "")
    }

    /** Daftar ayat jatuh tempo; pilih salah satu untuk diulas dengan koreksi suara atau latihan mandiri. */
    private fun dialogUlasHafalan() {
        val hari = HafalanSrs.hariIni()
        val due = HafalanSrs.jatuhTempo(dataPrefs, hari)
        if (due.isEmpty()) {
            val total = HafalanSrs.semua(dataPrefs).size
            AlertDialog.Builder(this).setTitle(tr("Ulas hafalan", "Review memorization"))
                .setMessage(if (total == 0) tr("Daftar hafalan masih kosong. Latih ayat dengan Koreksi otomatis atau Latihan hafalan tanpa mikrofon, atau tambahkan ayat lewat Pengaturan Hafalan > Pengingat cerdas hafalan.", "Your memorization list is empty. Practice a verse with the automatic check or the no-microphone practice, or add verses in Memorization Settings > Smart memorization reminder.")
                    else tr("Tidak ada ayat yang jatuh tempo hari ini. Alhamdulillah. Total ayat dalam daftar: ", "No verses are due today. Total verses in your list: ") + total)
                .setNegativeButton(tr("Kembali", "Back"), null).show()
            return
        }
        val labels = (listOf(tr("Mulai muraja'ah cerdas (sesi terpandu)", "Start smart muraja'ah (guided session)")) + due.map { labelAyatHafalan(it, hari) }).toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Ulas hafalan hari ini", "Review today's memorization") + " (" + due.size + ")")
            .setItems(labels) { _, which -> if (which == 0) mulaiMurajaahCerdas() else pilihCaraUlas(due[which - 1]) }
            .setNegativeButton(tr("Kembali", "Back"), null).show()
    }

    private fun pilihCaraUlas(item: HafalanSrs.Item) {
        val suara = dataPrefs.getBoolean("hafalan_koreksi_suara_aktif", true)
        val mandiri = dataPrefs.getBoolean("hafalan_latihan_mandiri_aktif", true)
        val cara = mutableListOf<Pair<String, () -> Unit>>()
        if (suara) cara.add(tr("Koreksi otomatis dengan pengenalan suara", "Automatic speech-recognition check") to { ayatUlasan = Pair(item.surah, item.ayat); mulaiKoreksiOtomatisHafalan() })
        if (mandiri) cara.add(tr("Latihan hafalan tanpa mikrofon", "Memorization practice without microphone") to { ayatUlasan = Pair(item.surah, item.ayat); latihanKoreksiHafalan() })
        if (cara.isEmpty()) {
            toast(tr("Aktifkan salah satu fitur latihan di Pengaturan Hafalan.", "Turn on a practice feature in Memorization Settings.")); return
        }
        if (cara.size == 1) { cara[0].second(); return }
        AlertDialog.Builder(this).setTitle(namaSurahPendek(item.surah) + tr(" ayat ", " verse ") + item.ayat)
            .setItems(cara.map { it.first }.toTypedArray()) { _, which -> cara[which].second() }
            .setNegativeButton(tr("Kembali", "Back"), null).show()
    }

    /** Pengaturan pengingat cerdas: saklar, waktu, daftar hafalan, tambah/hapus ayat. */
    private fun dialogPengingatCerdas() {
        val aktif = dataPrefs.getBoolean(HafalanSrs.KEY_PENGINGAT, false)
        val jam = dataPrefs.getInt(HafalanSrs.KEY_JAM, 19)
        val menit = dataPrefs.getInt(HafalanSrs.KEY_MENIT, 30)
        val daftar = HafalanSrs.semua(dataPrefs)
        val due = HafalanSrs.jatuhTempo(dataPrefs).size
        val posisi = Pair(dataPrefs.getInt("terakhir_surah", 1).coerceIn(1, 114), dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1))
        val sudahAda = HafalanSrs.ada(dataPrefs, posisi.first, posisi.second)
        val opsi = arrayOf(
            tr("Pengingat harian: ", "Daily reminder: ") + (if (aktif) tr("aktif pukul ", "on at ") + String.format(Locale.ROOT, "%02d:%02d", jam, menit) + tr(". Ketuk untuk menonaktifkan", ". Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on")),
            tr("Ubah waktu pengingat", "Change reminder time"),
            tr("Ulas hafalan hari ini (", "Review today's memorization (") + due + tr(" ayat jatuh tempo dari ", " due of ") + daftar.size + tr(" ayat)", " verses)"),
            if (sudahAda) tr("Hapus ayat bacaan terakhir dari daftar hafalan", "Remove last-read verse from memorization list")
            else tr("Tambah ayat bacaan terakhir ke daftar hafalan", "Add last-read verse to memorization list"),
            tr("Kosongkan seluruh daftar hafalan", "Clear the whole memorization list")
        )
        AlertDialog.Builder(this)
            .setCustomTitle(judulDenganPesan(
                tr("Pengingat cerdas hafalan", "Smart memorization reminder"),
                tr("Ayat yang Anda latih dicatat otomatis. Bacaan benar membuat jarak ulasan makin panjang (1, 2, 4, 7, 14, 30, 60 hari); salah baca mengembalikannya ke besok. Pengingat harian hanya muncul bila ada ayat yang perlu diulang.",
                    "Verses you practice are recorded automatically. A correct recitation lengthens the review gap (1, 2, 4, 7, 14, 30, 60 days); a mistake brings it back to tomorrow. The daily reminder only appears when there are verses to review.")))
            .setItems(opsi) { _, which ->
                when (which) {
                    0 -> {
                        val baru = !aktif
                        dataPrefs.edit().putBoolean(HafalanSrs.KEY_PENGINGAT, baru).apply()
                        HafalanSrs.jadwalkan(this)
                        if (baru && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 6904)
                        } else toast(if (baru) tr("Pengingat cerdas hafalan diaktifkan.", "Smart memorization reminder turned on.") else tr("Pengingat cerdas hafalan dinonaktifkan.", "Smart memorization reminder turned off."))
                        handler.post { dialogPengingatCerdas() }
                    }
                    1 -> TimePickerDialog(this, { _, h, m ->
                        dataPrefs.edit().putInt(HafalanSrs.KEY_JAM, h).putInt(HafalanSrs.KEY_MENIT, m).apply()
                        HafalanSrs.jadwalkan(this)
                        toast(tr("Waktu pengingat: ", "Reminder time: ") + String.format(Locale.ROOT, "%02d:%02d", h, m))
                        handler.post { dialogPengingatCerdas() }
                    }, jam, menit, true).apply { setOnCancelListener { handler.post { dialogPengingatCerdas() } } }.show()
                    2 -> dialogUlasHafalan()
                    3 -> {
                        if (sudahAda) HafalanSrs.hapus(dataPrefs, posisi.first, posisi.second) else HafalanSrs.tambah(dataPrefs, posisi.first, posisi.second)
                        toast(if (sudahAda) tr("Ayat dihapus dari daftar hafalan.", "Verse removed from the memorization list.") else tr("Ayat ditambahkan ke daftar hafalan dan jatuh tempo hari ini.", "Verse added to the memorization list and due today."))
                        handler.post { dialogPengingatCerdas() }
                    }
                    4 -> AlertDialog.Builder(this).setTitle(tr("Kosongkan daftar hafalan?", "Clear the memorization list?"))
                        .setMessage(tr("Seluruh catatan jadwal ulasan (" + daftar.size + " ayat) akan dihapus.", "All review schedule records (" + daftar.size + " verses) will be deleted."))
                        .setPositiveButton(tr("Kosongkan", "Clear")) { _, _ -> HafalanSrs.kosongkan(dataPrefs); toast(tr("Daftar hafalan dikosongkan.", "Memorization list cleared.")); handler.post { dialogPengingatCerdas() } }
                        .setNegativeButton(tr("Batal", "Cancel")) { _, _ -> handler.post { dialogPengingatCerdas() } }.show()
                }
            }
            .kembaliKe(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { dialogPengaturanHafalan() }
            .show()
    }

    // ===== FIX105: Muraja'ah cerdas (sesi ulasan terpandu di atas pengulangan berjarak FIX103) =====
    // Aturan bahasa aktif: semua teks di blok ini memakai tr(id, en) dan mengikuti bahasa tampilan aplikasi.
    private var sesiMurajaah: List<HafalanSrs.ButirSesi>? = null
    private var sesiIndeks = 0
    /** 0 = koreksi otomatis dengan pengenalan suara, 1 = latihan tanpa mikrofon. */
    private var sesiCara = 0
    private var sesiNilaiAyatIni: HafalanSrs.Nilai? = null
    private var sesiDilewati = 0
    private var sesiAsalSurah = 1
    private var sesiAsalAyat = 1
    private val sesiHasil = mutableListOf<Pair<HafalanSrs.Item, HafalanSrs.Nilai>>()

    private fun sesiAktif(): Boolean = sesiMurajaah != null

    private fun labelSesi(butir: HafalanSrs.ButirSesi): String =
        HafalanSrs.namaSurah(butir.item.surah) + tr(" ayat ", " verse ") + butir.item.ayat + (if (butir.penguatan) tr(" · penguatan", " · reinforcement") else "")

    /** Catat hasil koreksi suara. Benar setelah beberapa kali gagal pada ayat yang sama dinilai RAGU (tingkat tidak naik). */
    private fun catatHasilKoreksiSuara(benar: Boolean, gagalSebelumnya: Int) {
        val nilai = when {
            !benar -> HafalanSrs.Nilai.LUPA
            gagalSebelumnya > 0 -> HafalanSrs.Nilai.RAGU
            else -> HafalanSrs.Nilai.LANCAR
        }
        HafalanSrs.catatNilai(dataPrefs, nomorSurah, nomorAyat, nilai)
        if (sesiAktif()) sesiNilaiAyatIni = nilai
    }

    /** Titik masuk: menyusun antrean cerdas lalu menawarkan cara muraja'ah. */
    private fun mulaiMurajaahCerdas() {
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return }
        val penguatan = dataPrefs.getBoolean(HafalanSrs.KEY_PENGUATAN, true)
        val semuaButir = HafalanSrs.antreanMurajaah(dataPrefs, HafalanSrs.ukuranSesi(dataPrefs), penguatan)
        if (semuaButir.isEmpty()) {
            val total = HafalanSrs.semua(dataPrefs).size
            AlertDialog.Builder(this).setTitle(tr("Muraja'ah cerdas", "Smart muraja'ah"))
                .setMessage(if (total == 0) tr("Daftar hafalan masih kosong. Latih ayat dengan Koreksi otomatis atau Latihan hafalan tanpa mikrofon, atau tambahkan ayat lewat Pengaturan Hafalan > Pengingat cerdas hafalan.", "Your memorization list is empty. Practice a verse with the automatic check or the no-microphone practice, or add verses in Memorization Settings > Smart memorization reminder.")
                    else tr("Tidak ada ayat yang perlu di-muraja'ah hari ini. Alhamdulillah. Total ayat dalam daftar: ", "No verses need muraja'ah today. Total verses in your list: ") + total)
                .setNegativeButton(tr("Kembali", "Back"), null).show()
            return
        }
        val antrean = semuaButir.filter { getAyat(it.item.surah, it.item.ayat) != null }
        if (antrean.isEmpty()) { dialogBelumAdaTeks(); return }
        val layananSuara = try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
        val dialogSistem = try { packageManager.queryIntentActivities(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0).isNotEmpty() } catch (_: Exception) { false }
        val suara = dataPrefs.getBoolean("hafalan_koreksi_suara_aktif", true) && (layananSuara || dialogSistem)
        val mandiri = dataPrefs.getBoolean("hafalan_latihan_mandiri_aktif", true)
        if (!suara && !mandiri) {
            toast(tr("Aktifkan Latihan hafalan tanpa mikrofon di Pengaturan Hafalan, atau pasang layanan pengenalan suara.", "Turn on the no-microphone practice in Memorization Settings, or install a speech recognition service."))
            return
        }
        val jatuh = antrean.count { !it.penguatan }
        val kuat = antrean.size - jatuh
        val rangkaian = HafalanSrs.rangkaianAktif(dataPrefs)
        val ringkas = tr(
            antrean.size.toString() + " ayat dalam sesi ini: " + jatuh + " jatuh tempo" + (if (kuat > 0) ", " + kuat + " penguatan ayat yang masih lemah" else "") + ". Ayat paling mendesak diulas lebih dulu.",
            antrean.size.toString() + " verses in this session: " + jatuh + " due" + (if (kuat > 0) ", " + kuat + " reinforcing weak verses" else "") + ". The most urgent verses come first."
        ) + (if (rangkaian > 0) tr("\nRangkaian muraja'ah: " + rangkaian + " hari berturut-turut.", "\nMuraja'ah streak: " + rangkaian + " day(s) in a row.") else "")
        val cara = mutableListOf<Pair<String, Int>>()
        if (suara) cara.add(Pair(tr("Koreksi otomatis dengan pengenalan suara", "Automatic speech-recognition check"), 0))
        if (mandiri) cara.add(Pair(tr("Latihan hafalan tanpa mikrofon", "Memorization practice without microphone"), 1))
        if (cara.size == 1) {
            AlertDialog.Builder(this).setTitle(tr("Muraja'ah cerdas", "Smart muraja'ah"))
                .setMessage(ringkas + "\n\n" + cara[0].first)
                .setPositiveButton(tr("Mulai sesi", "Start session")) { _, _ -> mulaiSesiMurajaah(antrean, cara[0].second) }
                .setNegativeButton(tr("Kembali", "Back"), null).show()
        } else {
            AlertDialog.Builder(this)
                .setCustomTitle(judulDenganPesan(tr("Muraja'ah cerdas", "Smart muraja'ah"), ringkas + tr("\n\nPilih cara muraja'ah:", "\n\nChoose how to review:")))
                .setItems(cara.map { it.first }.toTypedArray()) { _, which -> mulaiSesiMurajaah(antrean, cara[which].second) }
                .setNegativeButton(tr("Kembali", "Back"), null).show()
        }
    }

    private fun mulaiSesiMurajaah(antrean: List<HafalanSrs.ButirSesi>, cara: Int) {
        sesiMurajaah = antrean
        sesiIndeks = 0
        sesiCara = cara
        sesiNilaiAyatIni = null
        sesiDilewati = 0
        sesiHasil.clear()
        // Pembaca menyimpan posisi bacaan terakhir; posisi asli dipulihkan saat sesi berakhir.
        sesiAsalSurah = dataPrefs.getInt("terakhir_surah", 1)
        sesiAsalAyat = dataPrefs.getInt("terakhir_ayat", 1)
        jalankanAyatSesi()
    }

    private fun jalankanAyatSesi() {
        val antrean = sesiMurajaah ?: return
        val butir = antrean.getOrNull(sesiIndeks) ?: run { akhiriSesiMurajaah(); return }
        sesiNilaiAyatIni = null
        ayatUlasan = Pair(butir.item.surah, butir.item.ayat)
        toast(tr("Muraja'ah " + (sesiIndeks + 1) + " dari " + antrean.size + ": ", "Muraja'ah " + (sesiIndeks + 1) + " of " + antrean.size + ": ") + labelSesi(butir))
        if (sesiCara == 0) {
            mulaiKoreksiOtomatisHafalan()
            if (dialogKoreksiHafalan == null) {
                toast(tr("Sesi dihentikan: ayat tidak dapat dibuka.", "Session stopped: the verse could not be opened."))
                akhiriSesiMurajaah()
            }
        } else {
            if (!pastikanDiPembaca()) {
                toast(tr("Sesi dihentikan: ayat tidak dapat dibuka.", "Session stopped: the verse could not be opened."))
                akhiriSesiMurajaah()
                return
            }
            mulaiSesiLatihanMandiri()
        }
    }

    /** Dipanggil setelah dialog koreksi suara ditutup selama sesi. */
    private fun setelahDialogKoreksiSesi() {
        if (isFinishing || !sesiAktif()) return
        if (sesiNilaiAyatIni != null) lanjutSesiSetelahAyat() else dialogSesiTertunda()
    }

    /** Ayat ini belum dinilai (dialog ditutup tanpa hasil): tawarkan coba lagi, lewati, atau akhiri. */
    private fun dialogSesiTertunda() {
        if (isFinishing) return
        val antrean = sesiMurajaah ?: return
        val butir = antrean.getOrNull(sesiIndeks) ?: run { akhiriSesiMurajaah(); return }
        AlertDialog.Builder(this).setTitle(tr("Muraja'ah cerdas dijeda", "Smart muraja'ah paused"))
            .setMessage(tr("Ayat ini belum dinilai: ", "This verse has not been graded: ") + labelSesi(butir) + tr(". Pilih langkah berikutnya.", ". Choose what to do next."))
            .setCancelable(false)
            .setPositiveButton(tr("Coba lagi", "Try again")) { _, _ -> handler.post { jalankanAyatSesi() } }
            .setNeutralButton(tr("Lewati ayat", "Skip verse")) { _, _ -> handler.post { lanjutSesiSetelahAyat() } }
            .setNegativeButton(tr("Akhiri sesi", "End session")) { _, _ -> handler.post { akhiriSesiMurajaah() } }
            .show()
    }

    /** Penilaian tiga tingkat untuk latihan tanpa mikrofon dalam sesi. */
    private fun dialogNilaiMurajaah() {
        val butir = sesiMurajaah?.getOrNull(sesiIndeks)
        val judul = tr("Nilai hafalan Anda", "Grade your recall") + (if (butir != null) " — " + labelSesi(butir) else "")
        val opsi = arrayOf(
            tr("Lancar: sesuai tanpa ragu", "Fluent: matched with no hesitation"),
            tr("Ragu-ragu: sesuai, tetapi tersendat atau perlu petunjuk", "Hesitant: matched, but stumbled or needed a hint"),
            tr("Lupa atau salah: perlu diulang", "Forgot or wrong: needs review"),
            tr("Ulangi latihan ayat ini", "Practice this verse again")
        )
        AlertDialog.Builder(this).setTitle(judul)
            .setCancelable(false)
            .setItems(opsi) { _, which ->
                if (which in 0..2) {
                    val nilai = when (which) { 0 -> HafalanSrs.Nilai.LANCAR; 1 -> HafalanSrs.Nilai.RAGU; else -> HafalanSrs.Nilai.LUPA }
                    HafalanSrs.catatNilai(dataPrefs, butir?.item?.surah ?: nomorSurah, butir?.item?.ayat ?: nomorAyat, nilai)
                    sesiNilaiAyatIni = nilai
                    handler.post { lanjutSesiSetelahAyat() }
                } else handler.post { mulaiSesiLatihanMandiri() }
            }
            .setNegativeButton(tr("Akhiri sesi", "End session")) { _, _ -> handler.post { akhiriSesiMurajaah() } }
            .show()
    }

    /** Catat hasil ayat ini, lalu tawarkan ayat berikutnya atau akhiri sesi bila antrean habis. */
    private fun lanjutSesiSetelahAyat() {
        if (isFinishing) return
        val antrean = sesiMurajaah ?: return
        val butir = antrean.getOrNull(sesiIndeks) ?: run { akhiriSesiMurajaah(); return }
        val nilai = sesiNilaiAyatIni
        if (nilai != null) sesiHasil.add(Pair(butir.item, nilai)) else sesiDilewati++
        sesiNilaiAyatIni = null
        sesiIndeks++
        if (sesiIndeks >= antrean.size) { akhiriSesiMurajaah(); return }
        val komentar = when (nilai) {
            HafalanSrs.Nilai.LANCAR -> tr("Alhamdulillah, lancar.", "Well done, fluent.")
            HafalanSrs.Nilai.RAGU -> tr("Ada keraguan; ayat ini akan diulas lebih cepat.", "Some hesitation; this verse will come back sooner.")
            HafalanSrs.Nilai.LUPA -> tr("Ayat ini akan diulas lagi besok.", "This verse will come back tomorrow.")
            null -> ""
        }
        val berikut = antrean[sesiIndeks]
        val pesan = (if (komentar.isEmpty()) "" else komentar + "\n\n") +
            tr("Berikutnya (", "Next (") + (sesiIndeks + 1) + "/" + antrean.size + "): " + labelSesi(berikut)
        AlertDialog.Builder(this).setTitle(tr("Muraja'ah cerdas", "Smart muraja'ah"))
            .setMessage(pesan)
            .setCancelable(false)
            .setPositiveButton(tr("Ayat berikutnya", "Next verse")) { _, _ -> handler.post { jalankanAyatSesi() } }
            .setNegativeButton(tr("Akhiri sesi", "End session")) { _, _ -> handler.post { akhiriSesiMurajaah() } }
            .show()
    }

    /** Ringkasan sesi: nilai, ayat yang perlu perhatian, jadwal berikutnya, dan rangkaian hari. */
    private fun akhiriSesiMurajaah() {
        val hasil = sesiHasil.toList()
        val dilewati = sesiDilewati
        sesiMurajaah = null
        sesiIndeks = 0
        sesiNilaiAyatIni = null
        sesiDilewati = 0
        sesiHasil.clear()
        ayatUlasan = null
        // Pulihkan posisi bacaan terakhir pengguna dan segarkan menu agar jumlah ayat jatuh tempo mutakhir.
        dataPrefs.edit().putInt("terakhir_surah", sesiAsalSurah).putInt("terakhir_ayat", sesiAsalAyat).apply()
        nomorSurah = sesiAsalSurah.coerceIn(1, 114)
        nomorAyat = sesiAsalAyat.coerceAtLeast(1)
        if (sedangDiPembaca) { hentikanAudio(); bangunMenuLagi() }
        if (isFinishing) return
        if (hasil.isEmpty()) {
            toast(tr("Sesi muraja'ah diakhiri tanpa penilaian.", "Muraja'ah session ended with no grades."))
            return
        }
        val rangkaian = HafalanSrs.catatSesiSelesai(dataPrefs)
        val lancar = hasil.count { it.second == HafalanSrs.Nilai.LANCAR }
        val ragu = hasil.count { it.second == HafalanSrs.Nilai.RAGU }
        val lupa = hasil.count { it.second == HafalanSrs.Nilai.LUPA }
        val hari = HafalanSrs.hariIni()
        val sisaHariIni = HafalanSrs.jatuhTempo(dataPrefs, hari).size
        val besok = HafalanSrs.jatuhTempo(dataPrefs, hari + 1L).size - sisaHariIni
        val perhatian = hasil.filter { it.second != HafalanSrs.Nilai.LANCAR }.take(3)
            .joinToString(", ") { HafalanSrs.namaSurah(it.first.surah) + tr(" ayat ", " verse ") + it.first.ayat }
        var pesan = tr("Sesi selesai. ", "Session complete. ") + hasil.size + tr(" ayat dinilai: lancar ", " verses graded: fluent ") + lancar +
            tr(", ragu-ragu ", ", hesitant ") + ragu + tr(", lupa ", ", forgotten ") + lupa + "."
        if (dilewati > 0) pesan += tr(" Dilewati: ", " Skipped: ") + dilewati + "."
        if (perhatian.isNotEmpty()) pesan += tr("\nPerlu perhatian: ", "\nNeeds attention: ") + perhatian + "."
        pesan += tr("\nMasih jatuh tempo hari ini: ", "\nStill due today: ") + sisaHariIni + tr(" ayat. Jatuh tempo besok: ", " verses. Due tomorrow: ") + besok + tr(" ayat.", " verses.")
        pesan += tr("\nRangkaian muraja'ah: ", "\nMuraja'ah streak: ") + rangkaian + tr(" hari berturut-turut.", " day(s) in a row.")
        pesan += tr("\n\nSemoga Allah mudahkan dan menjaga hafalan Anda.", "\n\nMay Allah make your memorization easy and keep it firm.")
        val dialog = AlertDialog.Builder(this).setTitle(tr("Muraja'ah cerdas selesai", "Smart muraja'ah complete"))
            .setMessage(pesan)
            .setPositiveButton(tr("Selesai", "Done"), null)
        if (sisaHariIni > 0) dialog.setNeutralButton(tr("Sesi lagi", "Another session")) { _, _ -> handler.post { mulaiMurajaahCerdas() } }
        dialog.show()
    }

    /** Pengaturan muraja'ah cerdas: ukuran sesi dan penguatan ayat lemah. */
    private fun dialogPengaturanMurajaah() {
        val ukuran = HafalanSrs.ukuranSesi(dataPrefs)
        val penguatan = dataPrefs.getBoolean(HafalanSrs.KEY_PENGUATAN, true)
        val opsi = arrayOf(
            tr("Jumlah ayat per sesi: ", "Verses per session: ") + ukuran + tr(". Ketuk untuk mengubah", ". Tap to change"),
            tr("Penguatan ayat lemah: ", "Weak-verse reinforcement: ") + (if (penguatan) tr("aktif. Ketuk untuk menonaktifkan", "on. Tap to turn off") else tr("nonaktif. Ketuk untuk mengaktifkan", "off. Tap to turn on")),
            tr("Mulai muraja'ah cerdas sekarang", "Start smart muraja'ah now")
        )
        AlertDialog.Builder(this)
            .setCustomTitle(judulDenganPesan(
                tr("Muraja'ah cerdas", "Smart muraja'ah"),
                tr("Sesi memilih ayat yang jatuh tempo, paling terlambat dan paling sering salah lebih dulu. Penguatan menambahkan ayat lemah yang belum jatuh tempo bila sesi belum penuh. Tiap ayat dinilai Lancar, Ragu-ragu, atau Lupa untuk mengatur jadwal ulasan berikutnya.",
                    "A session picks due verses, the most overdue and most often missed first. Reinforcement adds weak verses that are not yet due when the session has room. Each verse is graded Fluent, Hesitant, or Forgotten to set its next review.")))
            .setItems(opsi) { _, which ->
                when (which) {
                    0 -> pilihUkuranSesiMurajaah()
                    1 -> {
                        val baru = !penguatan
                        dataPrefs.edit().putBoolean(HafalanSrs.KEY_PENGUATAN, baru).apply()
                        toast(if (baru) tr("Penguatan ayat lemah diaktifkan.", "Weak-verse reinforcement turned on.") else tr("Penguatan ayat lemah dinonaktifkan.", "Weak-verse reinforcement turned off."))
                        handler.post { dialogPengaturanMurajaah() }
                    }
                    else -> mulaiMurajaahCerdas()
                }
            }
            .kembaliKe(tr("Kembali ke pengaturan hafalan", "Back to memorization settings")) { dialogPengaturanHafalan() }
            .show()
    }

    private fun pilihUkuranSesiMurajaah() {
        val pilihan = HafalanSrs.PILIHAN_UKURAN_SESI
        val label = pilihan.map { it.toString() + tr(" ayat", " verses") }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Jumlah ayat per sesi", "Verses per session"))
            .setItems(label) { _, which ->
                dataPrefs.edit().putInt(HafalanSrs.KEY_UKURAN_SESI, pilihan[which]).apply()
                toast(tr("Jumlah ayat per sesi: ", "Verses per session: ") + pilihan[which])
                handler.post { dialogPengaturanMurajaah() }
            }
            .setNegativeButton(tr("Batal", "Cancel")) { _, _ -> handler.post { dialogPengaturanMurajaah() } }
            .setOnCancelListener { handler.post { dialogPengaturanMurajaah() } }
            .show()
    }

    private fun pengaturanPengingat() {
        val enabled = dataPrefs.getBoolean("pengingat_aktif", false)
        val hour = dataPrefs.getInt("pengingat_jam", 20)
        val minute = dataPrefs.getInt("pengingat_menit", 0)
        val dialog = AlertDialog.Builder(this)
            .setTitle(tr("Pengingat membaca dan hafalan", "Reading and memorization reminder"))
            .setMessage(tr("Status saat ini: ", "Current status: ") + if (enabled) String.format(Locale.ROOT, "%02d:%02d", hour, minute) else tr("nonaktif", "off"))
            .setPositiveButton(tr("Atur waktu", "Set time"), null)
            .setNegativeButton(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { _, _ ->
                handler.post { dialogPengaturanKhatam() }
            }
            .setNeutralButton(if (enabled) tr("Matikan pengingat", "Turn off reminder") else tr("Biarkan nonaktif", "Keep disabled"), null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                dialog.dismiss()
                TimePickerDialog(this, { _, h, m ->
                    dataPrefs.edit().putBoolean("pengingat_aktif", true).putInt("pengingat_jam", h).putInt("pengingat_menit", m).apply()
                    jadwalkanPengingat(h, m)
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 6904)
                    } else {
                        toast(tr("Pengingat harian disetel.", "Daily reminder has been set."))
                    }
                    handler.post { dialogPengaturanKhatam() }
                }, hour, minute, true).apply {
                    setOnCancelListener { handler.post { pengaturanPengingat() } }
                }.show()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                if (enabled) {
                    dataPrefs.edit().putBoolean("pengingat_aktif", false).apply()
                    batalkanPengingat()
                    toast(tr("Pengingat dimatikan.", "Reminder turned off."))
                }
                dialog.dismiss()
                handler.post { dialogPengaturanKhatam() }
            }
        }
        dialog.setOnCancelListener { handler.post { dialogPengaturanKhatam() } }
        dialog.show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 6905) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                mulaiPengenalanBacaanAyat()
            } else {
                val pesan = tr("Izin mikrofon ditolak. Koreksi otomatis tidak dapat berjalan tanpa izin mikrofon. Latihan mandiri tetap dapat digunakan.", "Microphone permission denied. Automatic checking cannot run without microphone permission. Self-check practice remains available.")
                statusKoreksiHafalan?.text = pesan
                statusKoreksiHafalan?.announceForAccessibility(pesan)
            }
        }
        if (requestCode == 6906) {
            val aksi = aksiTertundaIzinFolder
            aksiTertundaIzinFolder = null
            if (grantResults.isEmpty() || grantResults[0] != android.content.pm.PackageManager.PERMISSION_GRANTED) lewatiIzinFolder = true
            if (aksi != null) handler.post { aksi() }
        }
        if (requestCode == 6904) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                toast(tr("Pengingat harian disetel dan notifikasi diizinkan.", "Daily reminder is set and notifications are allowed."))
            } else {
                toast(tr("Jadwal pengingat tersimpan, tetapi notifikasi diblokir. Izinkan notifikasi Jam Pintar Pro di Pengaturan Android.", "The reminder is scheduled, but notifications are blocked. Allow Jam Pintar Pro notifications in Android Settings."))
            }
        }
    }

    private fun jadwalkanPengingat(hour: Int, minute: Int) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, KhatamReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 6901, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        } else {
            @Suppress("DEPRECATION")
            alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }

    private fun batalkanPengingat() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(this, 6901, Intent(this, KhatamReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.cancel(pi); pi.cancel()
    }

    private fun pengaturanAksesibilitas() {
        val options = arrayOf(
            tr("Tampilkan terjemahan: ", "Show translation: ") + if (tampilkanArti) tr("aktif", "on") else tr("nonaktif", "off"),
            tr("Perbesar teks Arab", "Increase Arabic text size"),
            tr("Perkecil teks Arab", "Decrease Arabic text size"),
            tr("Unduh ulang teks untuk bahasa aktif", "Download text for the active language"),
            tr("Suara TalkBack saat pergantian audio dan saat mikrofon dipakai: ", "TalkBack speech when audio changes and when the microphone is used: ") + if (senyapTalkBackPergantian) tr("dimatikan", "muted") else tr("tetap aktif", "kept on")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan aksesibilitas", "Accessibility settings"))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { tampilkanArti = !tampilkanArti; dataPrefs.edit().putBoolean("tampilkan_terjemahan", tampilkanArti).apply(); toast(if (tampilkanArti) tr("Terjemahan diaktifkan.", "Translation enabled.") else tr("Terjemahan disembunyikan.", "Translation hidden.")) }
                    1 -> { ukuranArab = (ukuranArab + 2).coerceAtMost(42f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); toast(tr("Ukuran teks Arab: ", "Arabic text size: ") + ukuranArab.toInt()) }
                    2 -> { ukuranArab = (ukuranArab - 2).coerceAtLeast(22f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); toast(tr("Ukuran teks Arab: ", "Arabic text size: ") + ukuranArab.toInt()) }
                    3 -> { unduhSemuaTeks { pengaturanAksesibilitas() }; return@setItems }
                    4 -> {
                        senyapTalkBackPergantian = !senyapTalkBackPergantian
                        dataPrefs.edit().putBoolean("senyap_talkback_pergantian_audio", senyapTalkBackPergantian).apply()
                        toast(if (senyapTalkBackPergantian)
                            tr("Suara TalkBack dimatikan saat audio berpindah otomatis dan saat mikrofon dipakai (perintah suara dan koreksi hafalan).", "TalkBack speech is muted when audio moves automatically and when the microphone is used (voice command and recitation check).")
                        else
                            tr("Suara TalkBack tetap aktif saat audio berpindah dan saat mikrofon dipakai.", "TalkBack speech stays on when audio moves and when the microphone is used."))
                    }
                }
                // Tetap di grup aksesibilitas agar pilihan dapat diatur berulang; Kembali menuju Pengaturan Khatam.
                handler.post { pengaturanAksesibilitas() }
            }
            .kembaliKe(tr("Kembali ke pengaturan Khatam", "Back to Khatam settings")) { dialogPengaturanKhatam() }
            .show()
    }

    private fun tanggalHariIni(): String = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())
}
