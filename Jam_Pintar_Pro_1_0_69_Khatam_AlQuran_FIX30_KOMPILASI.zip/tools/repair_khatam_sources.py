#!/usr/bin/env python3
"""Restore canonical Khatam sources before compilation, then validate them."""
from pathlib import Path
import re, shutil, sys, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
known = root / "tools" / "khatam_known_good"
pairs = [
    (known / "KhatamActivity.kt",
     root / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt"),
    (known / "strings_id.xml",
     root / "app/src/main/res/values/strings.xml"),
    (known / "strings_en.xml",
     root / "app/src/main/res/values-en/strings.xml"),
]
for src, dst in pairs:
    if not src.is_file():
        print(f"ERROR: sumber kanonis hilang: {src.relative_to(root)}", file=sys.stderr)
        sys.exit(2)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    print(f"Pulihkan: {dst.relative_to(root)}")

code = pairs[0][0].read_text(encoding="utf-8")
errors = []
for name in ("bukaAyatTersimpan", "tandaiPosisi", "pengaturanTarget",
             "tampilkanStatistik", "pengaturanPengingat", "pengaturanAksesibilitas",
             "tampilkanRiwayat", "dialogBelumAdaTeks", "tampilkanPembaca"):
    if not re.search(r"\bfun\s+" + re.escape(name) + r"\s*\(", code):
        errors.append(f"Fungsi wajib tidak ditemukan: {name}")
for token in ("SSrl4i7kMxObpgmjUH", "rrqdmzFtNspt", "okcCA9", "rEUrQgA",
              "oJ7hR1Pmal1KQ8tRt", "KECrdq4VXdW1eabhQaLzg1wiPxlw",
              "xHoceR8vhWeFGwp6hxI", "atSqBKvPQ",
              "lyuFWGJIhtbNFyIjf8tlw"):
    if token in code:
        errors.append(f"Token acak masih ada: {token}")
for _, dst in pairs[1:]:
    try:
        ET.parse(dst)
        raw = dst.read_text(encoding="utf-8")
        if re.search(r"\\u(?![0-9a-fA-F]{4})", raw):
            errors.append(f"Escape Unicode tidak valid: {dst.relative_to(root)}")
        keys = {node.get("name") for node in ET.parse(dst).getroot().findall("string")}
        for key in ("khatam_menu", "khatam_judul"):
            if key not in keys:
                errors.append(f"Sumber daya {key} tidak ditemukan: {dst.relative_to(root)}")
    except Exception as exc:
        errors.append(f"XML gagal dibaca {dst.relative_to(root)}: {exc}")
if errors:
    print("PEMERIKSAAN KODE KHATAM GAGAL:")
    for error in errors:
        print("- " + error)
    sys.exit(1)
print("PEMERIKSAAN KODE KHATAM LULUS.")
