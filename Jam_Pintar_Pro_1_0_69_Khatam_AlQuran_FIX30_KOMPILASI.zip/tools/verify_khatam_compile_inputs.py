#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root = Path(__file__).resolve().parents[1]
result = subprocess.run([sys.executable, str(root / "tools/repair_khatam_sources.py")], cwd=root)
sys.exit(result.returncode)
