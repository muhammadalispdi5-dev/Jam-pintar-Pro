# FIX314
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
- GemaDsp.proses(File): ekor gema memudar cosinus ke nol (akhir halus); "napas ruang" 260 ms sebelum kata pertama (gema/ruang terasa lebih awal).
- Pembicara: pendengar fokus audio kosong (suara asisten tidak diturunkan otomatis oleh sistem); Turunkan audio lain menurunkan sementara volume STREAM_RING dan STREAM_NOTIFICATION ke 30% lalu memulihkannya (hanya bila pengguna tidak mengubahnya). Dilewati bila aliran asisten sama; dibungkus try/catch (mode jangan ganggu bisa menolak).
- Petunjuk ID 84 / EN 81.
- Batasan: azan/murattal (PemutarMono) belum diberi fade akhir; aplikasi lain yang tidak memakai fokus audio tidak terpengaruh.

## FIX319 koreksi
Penurunan volume STREAM_RING/STREAM_NOTIFICATION lewat setStreamVolume (FIX314) dihapus karena bisa tidak pulih saat asisten dipanggil. Pembicara kini hanya memakai fokus audio (pendengar fokus kosong agar suara asisten tidak diturunkan sistem).
