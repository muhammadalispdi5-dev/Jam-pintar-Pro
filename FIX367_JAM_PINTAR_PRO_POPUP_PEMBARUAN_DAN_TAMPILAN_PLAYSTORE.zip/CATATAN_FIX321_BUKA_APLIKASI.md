# FIX321
- Buka aplikasi apa pun: PencocokAplikasi.kt (alias, kemiripan huruf, daftar pilihan bila ambigu); WhatsApp Bisnis dibedakan dari pembaca pesan. Petunjuk ID 91 / EN 88.
