# FIX320
- Jeda antarayat: PemutarMono.ekorMaksMs membatasi ekor gema (250 ms) bila masih ada ayat berikutnya (PemutarQuranService, KhatamActivity); ekor penuh hanya di ayat terakhir.
- Saklar "Turunkan audio lain saat berbicara" tunggal (kunci global turunkan_lain_global) di MainActivity; dihapus dari dialog Volume dan efek.
- Perintah "tampilkan ayat/hadis tentang ..." (Jenis.TEKS_TEMA): dialog teks + salin otomatis + tombol Salin semua.
- Petunjuk ID 89-90 / EN 86-87; item 60/57 diperbarui.
