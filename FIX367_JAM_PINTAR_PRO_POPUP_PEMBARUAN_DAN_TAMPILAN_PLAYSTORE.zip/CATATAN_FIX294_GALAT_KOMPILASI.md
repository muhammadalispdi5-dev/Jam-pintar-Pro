# FIX294 – Galat kompilasi GitHub Actions (BatteryTalkService.kt:77)

Galat: "Argument type mismatch: actual type is '<anonymous>', but 'Context' was expected."
Penyebab: pada FIX293 pemanggilan LokasiOtomatis.periksa(this) berada di dalam objek Runnable (cekInterval), sehingga `this` adalah Runnable, bukan layanan.
Perbaikan: LokasiOtomatis.periksa(this@BatteryTalkService). Uji regresi ditambahkan di tools/uji_hijriah_resmi_lokasi.py. Tidak ada galat lain pada log (kompilasi rilis dan debug gagal di baris yang sama).
