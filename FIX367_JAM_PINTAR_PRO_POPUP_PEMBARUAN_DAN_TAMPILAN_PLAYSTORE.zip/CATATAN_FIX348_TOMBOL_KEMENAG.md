FIX348: dialog unduhan gagal punya tombol 'Pakai Tafsir Kemenag dan unduh' (beralih kitab otomatis). Belum dikompilasi/diuji.
