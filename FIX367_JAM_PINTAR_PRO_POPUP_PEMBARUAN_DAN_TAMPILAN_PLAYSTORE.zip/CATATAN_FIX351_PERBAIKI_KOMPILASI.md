# FIX351
Perbaikan kegagalan kompilasi FIX350 (lambda penutup terikat ke parameter Int patuhDnd). Parameter patuhDnd dihapus dari Melodi; pengecekan DndSistem.senyap kini dilakukan di titik pemanggil (BatteryTalkService, CallerListener). Versi tetap 1.0.92. Belum dikompilasi lagi dengan Gradle; log GitHub Actions sebelumnya hanya menunjukkan galat ini.
