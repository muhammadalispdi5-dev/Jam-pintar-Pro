import re,os
from pathlib import Path
root=Path(__file__).resolve().parent.parent
B=root/"app/src/main/java/com/novan/bateraibicara"
def cek(n,c): print(("OK   " if c else "GAGAL ")+n)
g=(B/"GunungDunia.kt").read_text()
p=(B/"PerintahSuaraActivity.kt").read_text()
cek("tabel >=100 gunung", len(re.findall(r'^\s+g\("',g,re.M))>=100)
for m in re.finditer(r'g\("([^"]*)", "([^"]*)", (-?[\d.]+), (-?[\d.]+), (\d+),',g):
    la,lo,h=float(m.group(3)),float(m.group(4)),int(m.group(5))
    cek("koordinat "+m.group(1), -90<=la<=90 and -180<=lo<=180 and 100<h<9000)
cek("elevation dikirim", '"&elevation="' in g)
cek("jenis terpasang", "CUACA_GUNUNG -> bacakanCuacaGunung" in p and "GunungDunia.permintaan(ucapan)" in p)
cek("prioritas", "Jenis.CUACA_GUNUNG, Jenis.KONDISI_GUNUNG, Jenis.LAUT, Jenis.CONTOH_KALIMAT -> 130" in p)
cek("ambilData publik", "fun ambilData" in (B/"OpenMeteo.kt").read_text())
for f in ["values","values-en"]:
    s=(root/("app/src/main/res/%s/strings.xml"%f)).read_text()
    cek("petunjuk "+f, "puncak" in s.lower() or "summit" in s.lower())
cek("FIX357 CUACA berprioritas di atas tanggal", "Jenis.CUACA -> 85" in p)
cek("FIX357 pencocokan mirip", "selisihSatu" in g)
