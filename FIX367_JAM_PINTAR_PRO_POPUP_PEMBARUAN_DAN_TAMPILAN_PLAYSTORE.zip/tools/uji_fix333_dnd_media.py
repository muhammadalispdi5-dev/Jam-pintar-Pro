import sys,os
B=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","app/src/main/java/com/novan/bateraibicara/")
t=open(B+"DndAzan.kt").read()
k='PRIORITY_CATEGORY_MEDIA' in t and 'PRIORITY_CATEGORY_SYSTEM' in t and 'volumeMode == 0' not in t
print(("LULUS" if k else "GAGAL")+" dnd media sistem")
