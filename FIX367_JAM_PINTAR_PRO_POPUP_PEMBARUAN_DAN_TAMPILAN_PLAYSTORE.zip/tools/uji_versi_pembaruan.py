import sys
u=open('app/src/main/java/com/novan/bateraibicara/UpdateManager.kt').read()
b=open('app/build.gradle.kts').read()
ok=True
def cek(n,c):
    global ok
    print(("LULUS " if c else "GAGAL ")+n); ok&=c
cek("tag angka dibandingkan dengan nomor build",'angkaTag > sekarang' in u and 'tag.contains(\'.\')' in u)
cek("izin diperiksa sebelum validasi berkas",u.index('canRequestPackageInstalls()) return PASANG_BUTUH_IZIN')<u.index('getPackageArchiveInfo'))
cek("nomor build mengikuti GITHUB_RUN_NUMBER",'GITHUB_RUN_NUMBER' in b and 'versionCode = 94' in b)
cek("benturan versi dijelaskan",'kodeArsipTerakhir' in u and 'update_versi_bentrok_isi' in open('app/src/main/java/com/novan/bateraibicara/MainActivity.kt').read())
cek("versi terpasang lewat pembaruan dicatat diterima",'update_diterima_kode' in u and 'sinkronkanSetelahPembaruan' in u and 'UpdateManager.sinkronkanSetelahPembaruan(this)' in open('app/src/main/java/com/novan/bateraibicara/MainActivity.kt').read())
cek("waktu pasang dicatat",'update_waktu_pasang' in u)
sys.exit(0 if ok else 1)
