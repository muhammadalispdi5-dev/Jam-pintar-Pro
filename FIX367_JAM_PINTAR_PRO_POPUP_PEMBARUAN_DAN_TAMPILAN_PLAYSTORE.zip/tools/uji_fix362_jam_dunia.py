import sys
w=open("app/src/main/java/com/novan/bateraibicara/WaktuDunia.kt").read()
a=open("app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt").read()
g=open("app/build.gradle.kts").read()
ok=True
def cek(n,c):
    global ok
    if not c: ok=False; print("GAGAL:",n)
cek("konversi",'fun konversi(' in w and 'fun jawabKonversi(' in w and 'fun jawabUntuk(' in w)
cek("selisih",'kalimatSelisih' in w and 'Lebih cepat' in w and 'Lebih lambat' in w)
cek("pembanding indonesia",'zonaPembanding' in w)
cek("aktivitas",a.count('WaktuDunia.jawabUntuk')>=2)
cek("versi 94",'versionCode = 94' in g)
if ok: print("OK")
sys.exit(0 if ok else 1)
