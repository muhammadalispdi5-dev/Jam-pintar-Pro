from pathlib import Path
j=Path(__file__).resolve().parent.parent/"app/src/main/java/com/novan/bateraibicara"
def cek(n,c): print(("OK   " if c else "GAGAL ")+n)
for f in ["Tafsir","Hadits","DoaHarian","AsmaulHusna","PanduanIbadah","ManasikHaji","KhutbahJumat","Tajwid"]:
    s=(j/(f+"Activity.kt")).read_text()
    cek(f+": tidak dibungkam volume", "bisaDibungkam = true" not in s and "BacaanLatarService.mulai" in s)
t=(j/"TafsirActivity.kt").read_text()
cek("Tafsir: tidak berhenti saat onPause", "override fun onPause()" not in t and "hasil_kunci" in t)
h=(j/"HaditsActivity.kt").read_text()
cek("Hadits: layar mati tidak memuat ulang", "isInteractive" in h)
cek("layanan latar", (j/"BacaanLatarService.kt").exists() and "BacaanLatarService" in (j.parent.parent.parent.parent/"AndroidManifest.xml").read_text())
a=(j/"PrayerAlarm.kt").read_text(); r=(j/"PrayerAlarmReceiver.kt").read_text(); v=(j/"PrayerAlarmService.kt").read_text()
cek("setAlarmClock cadangan", "setAlarmClock" in a)
cek("Tarhim terlambat dilewati", "FIX360: Tarhim yang terlambat" in r)
cek("penjaga azan", "penjagaAzan.postDelayed" in v)
