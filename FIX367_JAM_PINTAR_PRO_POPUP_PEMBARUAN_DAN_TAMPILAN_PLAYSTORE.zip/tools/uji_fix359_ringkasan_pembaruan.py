from pathlib import Path
r=Path(__file__).resolve().parent.parent
m=(r/"app/src/main/java/com/novan/bateraibicara/MainActivity.kt").read_text()
def cek(n,c): print(("OK   " if c else "GAGAL ")+n)
cek("ringkasan sebelum unduh", "tampilkanRingkasanSebelumPembaruan(info) {" in m and "mulaiUnduh(info)" in m.split("tampilkanRingkasanSebelumPembaruan(info) {")[1][:400])
for d in ["values","values-en"]:
    s=(r/("app/src/main/res/%s/strings.xml"%d)).read_text()
    cek("string "+d, all(k in s for k in ["update_ringkasan_judul","update_ringkasan_isi","update_ringkasan_lanjut","update_ringkasan_batal"]))
