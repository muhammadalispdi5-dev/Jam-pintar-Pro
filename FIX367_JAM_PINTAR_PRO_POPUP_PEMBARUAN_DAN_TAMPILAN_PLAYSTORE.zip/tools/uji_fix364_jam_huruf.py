import sys
w=open("app/src/main/java/com/novan/bateraibicara/WaktuDunia.kt").read()
ok=True
for n,c in [("angka huruf",'fun angka(' in w),("lisan",'private fun lisan(' in w and 'Waktu Indonesia Barat' in w),("tanggal lisan",'tanggalLisan' in w),("tanpa digit jam",'j12.toString()' not in w)]:
    if not c: ok=False; print("GAGAL:",n)
if ok: print("OK")
