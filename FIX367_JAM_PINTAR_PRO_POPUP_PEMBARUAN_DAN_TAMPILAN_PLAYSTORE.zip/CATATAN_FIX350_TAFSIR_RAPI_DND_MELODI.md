# FIX350 (versi 1.0.92)
- Menu Kitab Tafsir: 1 cari kitab/surah/ayat, 2 cari tema, Hasil tafsir, Ukuran huruf, 3 Unduhan kitab (paling bawah); duplikasi isiHasil saat ubah ukuran huruf dihapus.
- Pop-up "Yang baru" memuat fitur baru tafsir/Kemenag/Pustaka Ilmu/DND.
- Jangan Ganggu: melodi jam bicara (BatteryTalkService) dan melodi pemberitahuan masuk (CallerListener) kini mengikuti DndSistem lewat DndSistem di titik pemanggil; azan dan alarm tidak diubah.
- Versi 1.0.92 (versionCode 92). Belum dikompilasi dengan Gradle / belum diuji di perangkat.

## FIX352 (mesin suara)
Tafsir dan Tajwid memakai blokSuara (volume mandiri, gema, kecepatan, nada, keluaran) di paling bawah; sebelumnya pemilih mesin lama tidak memengaruhi suara Tafsir (Pembicara membaca profil tafsir). Hadis, Khutbah, Panduan Ibadah, Manasik, Doa Harian, Asmaul Husna: tombol pemilih mesin dipindah ke paling bawah (tetap hanya pilih mesin; volume/gema belum). Belum dikompilasi/diuji.

## FIX353
Panduan Ibadah, Manasik Haji, Khutbah Jumat: TextToSpeech langsung diganti Pembicara (profil ibadah/manasik/khutbah) + blokSuara di paling bawah; Pembicara.paksaArab untuk kutipan Arab; bisaDibungkam (volume/telungkup) juga di Tafsir dan Tajwid. Hadis, Doa Harian, Asmaul Husna masih pemilih mesin saja. Belum dikompilasi/diuji.

## FIX354
Hadits, Doa Harian, Asmaul Husna: bacaan memakai Pembicara (profil hadits/doa/asma) + blokSuara di bawah; Pembicara.paksaLocale. Pembuatan berkas audio doa/Asmaul Husna (synthesizeToFile) tetap memakai TextToSpeech langsung tetapi mesinnya dari profil suara. Belum dikompilasi/diuji.
