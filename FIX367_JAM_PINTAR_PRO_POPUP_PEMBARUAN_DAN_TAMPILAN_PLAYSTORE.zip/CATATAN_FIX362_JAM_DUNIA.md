# FIX362
- Jam negara lain: format 12 jam + penanda waktu, jam Indonesia pembanding, selisih jam, beda hari, waktu musim panas.
- Konversi: kalau di Indonesia jam X, di negara Y jam berapa.
- Versi 1.0.94 agar popup 'Yang baru' tampil saat pertama dibuka setelah update; ringkasan diperbarui.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
