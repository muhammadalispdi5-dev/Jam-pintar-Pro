# FIX367 — Penyempurnaan pop-up setelah pembaruan

## Perubahan
- Pop-up "Yang baru" tetap ditampilkan satu kali setelah versi aplikasi meningkat.
- Menambahkan deteksi migrasi untuk pengguna lama yang melakukan pembaruan melalui Google Play atau installer lain, termasuk pengguna yang belum memiliki preferensi `yang_baru_kode`.
- Instalasi pertama tetap tidak memunculkan pop-up pembaruan.
- Dialog menampilkan ikon aplikasi dan mengumumkan judulnya kepada layanan aksesibilitas/TalkBack.
- Catatan bawaan yang sebelumnya masih menyebut fitur versi 1.0.89 diganti dengan ringkasan singkat yang tidak mengklaim fitur yang tidak diketahui.
- Catatan rilis aktual dari mekanisme pembaruan internal tetap digunakan jika tersedia.
- Tidak mengubah `applicationId`, `versionCode`, `versionName`, tanda tangan, maupun identitas sumber pemasangan.

## Perilaku sumber instalasi
Aplikasi tidak memalsukan Google Play sebagai installer. Jika dipasang melalui Play Store, Android tetap dapat mengenali Play Store sebagai sumbernya. Jika dipasang melalui APK/GitHub, sumber pemasangan tetap sesuai kenyataan. Dialog hanya meniru pengalaman penyajian pembaruan yang rapi, bukan mengubah provenance instalasi.

## Pengujian
- Arsip sumber diperiksa integritasnya sebelum ekstraksi.
- Perubahan diperiksa secara statis dan struktur XML diperiksa agar tetap terbentuk dengan benar.
- Build APK Android dan uji perangkat belum dijalankan dalam lingkungan ini; mohon jalankan GitHub Actions untuk verifikasi kompilasi akhir.
