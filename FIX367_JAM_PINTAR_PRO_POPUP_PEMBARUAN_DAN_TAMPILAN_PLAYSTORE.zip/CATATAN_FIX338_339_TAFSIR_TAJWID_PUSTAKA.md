# FIX338 + FIX339
- Kitab Tafsir (TafsirData/TafsirActivity): 8 edisi (Jalalayn, As-Sa'di, Al-Mukhtashar Indonesia; Muyassar, Ibnu Katsir, Jalalayn Arab; Ibn Kathir, Jalalayn Inggris) dari spa5k/tafsir_api via jsDelivr/GitHub, diunduh per surah lalu disimpan. BELUM TERVERIFIKASI: nama slug edisi dan bentuk JSON (parser dibuat longgar); bila unduhan gagal aplikasi memberi pesan.
- Pelajaran Hijaiyah dan Tajwid (TajwidData/TajwidActivity): 25 pelajaran, 3 tingkat, dapat dibacakan.
- Qari tambahan (QariTambahan): sumber sendiri 001.mp3..114.mp3; tidak ada tautan Muammar ZA bawaan karena sumber lengkap tidak terverifikasi.
- FIX339: Hadis, Tafsir, Tajwid, Panduan Ibadah, Manasik Haji/Umrah, Khutbah Jumat dikelompokkan di "Pustaka Ilmu dan Panduan Ibadah" (PustakaIlmuActivity). Asisten: Fitur.TAFSIR/TAJWID/PUSTAKA_ILMU; fitur lama tetap dibuka langsung.
Belum dikompilasi / diuji di perangkat.

## FIX340
Asisten: 'tampilkan/salin tafsir tentang <tema>' menampilkan ayat+terjemah+tafsir dan menyalin ke papan klip (maks 8 ayat); 'bacakan tafsir tentang <tema>' membacakan (maks 3 ayat). Kitab bawaan Jalalayn atau sesuai nama kitab. Butuh unduhan tafsir (internet sekali per surah). Belum dikompilasi / diuji di perangkat.
