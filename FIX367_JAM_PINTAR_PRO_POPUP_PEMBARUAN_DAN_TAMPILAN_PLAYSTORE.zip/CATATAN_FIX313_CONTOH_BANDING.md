# FIX313 - Contoh gema: mesin suara pilihan + banding tanpa/dengan gema
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
- ContohGema memakai mesin TTS pilihan pengguna (Prefs.Suara("jam").engine, atau parameter mesinTts), sama dengan Pembicara.
- Contoh diputar dua kali: kering (tanpa gema) lalu dengan gema terpilih.
- Petunjuk ID 83 / EN 80.
- Perbaikan kompilasi (log GitHub Actions run 44007500662): lambda trailing `lapor` salah terikat ke parameter `mesinTts: String?`. Urutan parameter diubah: `putar(context, kunci, kekuatan, mesinTts = null, lapor = null)` sehingga lambda trailing menjadi `lapor`.
