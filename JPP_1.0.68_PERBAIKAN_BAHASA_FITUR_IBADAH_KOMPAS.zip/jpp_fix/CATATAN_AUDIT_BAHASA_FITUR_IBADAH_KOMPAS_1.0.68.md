# Audit Bahasa Inggris — Fitur Ibadah dan Kompas (1.0.68)

Perubahan:
- Memperluas kamus terjemahan BahasaAplikasi untuk label, petunjuk, status, toast, dan pilihan pada Mode Jangan Ganggu saat salat.
- Menambahkan padanan bahasa Inggris untuk sumber suara azan, tes suara, pengingat sahur dan berbuka, serta panduan arah kiblat/kompas.
- Menambahkan padanan untuk teks Mode Acara dan fasilitas umum terdekat yang ditemukan dalam sumber terjemahan.
- Mempertahankan versionCode/versionName 68 / 1.0.68.

Validasi:
- XML values dan values-en dapat diparsing.
- Arsip ZIP diuji setelah dibuat.
- Build APK penuh belum dijalankan; teks notifikasi yang dibuat langsung di layanan Android masih memerlukan verifikasi pada perangkat.
