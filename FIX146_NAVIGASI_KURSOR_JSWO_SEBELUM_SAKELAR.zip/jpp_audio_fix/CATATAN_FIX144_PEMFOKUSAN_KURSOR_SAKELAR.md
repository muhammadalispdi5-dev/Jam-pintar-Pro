# FIX144 – Pemfokusan Kursor pada Sakelar di Halaman Pengaturan

## Tujuan
Memperbaiki perilaku ketika perintah suara sudah membuka halaman pengaturan fitur yang benar, tetapi fokus/kursor aksesibilitas masih berada pada elemen paling atas dan belum mencapai sakelar.

## Dasar perubahan
- Alur pembukaan halaman fitur dari FIX141 dipertahankan. Perintah Wi-Fi, Bluetooth, lokasi, hotspot, data seluler, mode pesawat, dan NFC tetap diarahkan ke halaman/panel fitur masing-masing.
- Tidak ada pengalihan perintah sakelar perangkat ke menu utama Aksesibilitas Android.
- Pada halaman Pengaturan yang sedang aktif, layanan mencari sakelar berdasarkan nama fitur, lalu memindahkan fokus aksesibilitas ke sakelar atau wadah kliknya sebelum menekan.
- Jika sakelar belum terlihat, layanan mencoba menggulir container halaman aktif. Jika halaman tidak menyediakan aksi gulir, layanan mencoba memindahkan fokus secara berurutan pada elemen di halaman yang sama, kemudian memindai ulang.
- Setelah tindakan klik/gestur, status tetap diverifikasi; status yang tidak terbaca tidak dianggap berhasil.

## Batasan
Android dan antarmuka OEM dapat membatasi aksesibilitas pada panel tertentu. Keberhasilan akhir harus diuji pada perangkat sasaran. Tidak ada klaim bahwa semua varian Android pasti mendukung kontrol otomatis yang sama.

## Versi
Tetap 1.0.81 (versionCode 81).
