package com.novan.bateraibicara

/**
 * Pemilih kontrol sakelar lintas tampilan Android/OEM.
 * Tidak menebak sakelar dari urutan layar: kecocokan harus menyebut perangkat yang diminta,
 * kecuali Wi-Fi/Bluetooth/lokasi pada halaman khusus yang hanya menampilkan satu kontrol.
 */
object PemilihSakelar {
    data class Info(
        /** Mencakup Switch/Toggle, kontrol checkable, serta tombol System UI dengan status eksplisit. */
        val bisaDicentang: Boolean,
        val terlihat: Boolean,
        val aktif: Boolean,
        /** Teks node, status, induk, dan label saudara yang relevan, huruf kecil. */
        val konteks: String,
        val idSumber: String
    )

    data class InfoBaris(val label: String, val bisaDiklik: Boolean, val dalamDaftar: Boolean, val bisaDicentang: Boolean)

    private val kataPerangkat = mapOf(
        "wifi" to listOf("wi-fi", "wifi", "wi fi", "wlan", "wireless lan", "wireless network"),
        "bluetooth" to listOf("bluetooth", "bluetooth radio", "bluetooth device"),
        "lokasi" to listOf("location services", "use location", "location", "lokasi", "gps"),
        "hotspot" to listOf("mobile hotspot", "wi-fi hotspot", "wifi hotspot", "hotspot", "hot spot"),
        "data_seluler" to listOf("mobile data", "cellular data", "mobile network data", "data seluler", "data selular", "mobile_data", "mobiledata", "cellular_data"),
        "pesawat" to listOf("airplane mode", "airplane_mode", "flight mode", "mode pesawat", "airplane", "pesawat"),
        "nfc" to listOf("nfc", "near field communication")
    )

    private val kataLain = mapOf(
        "wifi" to listOf("bluetooth", "airplane", "pesawat", "mobile data", "cellular data", "data seluler", "hotspot", "nfc", "location", "lokasi", "scanning", "pemindaian", "tethering"),
        "bluetooth" to listOf("wi-fi", "wifi", "wlan", "airplane", "pesawat", "mobile data", "cellular data", "data seluler", "hotspot", "nfc", "location", "lokasi", "scanning", "pemindaian", "tethering", "usb", "ethernet"),
        "lokasi" to listOf("airplane", "pesawat", "mobile data", "cellular data", "data seluler", "hotspot", "nfc", "wi-fi", "wifi", "bluetooth", "scanning", "pemindaian"),
        "hotspot" to listOf("airplane", "pesawat", "mobile data", "data seluler", "nfc", "location", "lokasi", "bluetooth", "usb", "ethernet"),
        "data_seluler" to listOf("airplane", "pesawat", "nfc", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan"),
        "pesawat" to listOf("mobile data", "data seluler", "data selular", "nfc", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan"),
        "nfc" to listOf("airplane", "pesawat", "mobile data", "data seluler", "data selular", "hotspot", "location", "lokasi", "bluetooth", "wi-fi", "wifi", "wlan")
    )

    private fun normalisasi(teks: String): String = teks.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}_-]+"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun cocokFrasa(teks: String, frasa: String): Boolean {
        val t = " ${normalisasi(teks)} "
        val f = " ${normalisasi(frasa)} "
        return t.contains(f)
    }

    /** Memeriksa bahwa konteks fokus menyebut perangkat target dan bukan perangkat lain. */
    fun konteksCocok(konteks: String, jenis: String): Boolean {
        val kata = kataPerangkat[jenis] ?: kataPerangkat["wifi"]!!
        val lain = kataLain[jenis] ?: emptyList()
        return kata.any { cocokFrasa(konteks, it) } && lain.none { cocokFrasa(konteks, it) }
    }

    fun pilih(daftar: List<Info>, jenis: String): Int? {
        val kata = kataPerangkat[jenis] ?: kataPerangkat["wifi"]!!
        val lain = kataLain[jenis] ?: emptyList()
        val calon = daftar.indices.filter { daftar[it].bisaDicentang && daftar[it].terlihat && daftar[it].aktif }
        if (calon.isEmpty()) return null

        val cocok = calon.filter { i ->
            val d = daftar[i]
            kata.any { cocokFrasa(d.konteks, it) || d.idSumber.contains(it.replace("-", "").replace(" ", "")) }
        }
        val tepat = cocok.filter { i ->
            val konteks = daftar[i].konteks
            // Kata perangkat lain hanya ditolak jika muncul sebagai frasa tersendiri.
            lain.none { cocokFrasa(konteks, it) }
        }
        if (tepat.size == 1) return tepat.single()
        // Dua sakelar dengan label sama tetap ambigu; jangan memilih secara acak.
        if (tepat.size > 1) return null

        // Fallback hanya pada halaman khusus yang menampilkan satu sakelar.
        val bolehFallback = jenis == "wifi" || jenis == "bluetooth" || jenis == "lokasi"
        return if (bolehFallback && calon.size == 1) calon.single() else null
    }

    fun pilihBarisHotspot(daftar: List<InfoBaris>): Int? {
        val tolak = listOf("bluetooth", "usb", "ethernet")
        val calon = daftar.indices.filter { i ->
            val d = daftar[i]
            !d.bisaDicentang && d.bisaDiklik && d.dalamDaftar &&
                (cocokFrasa(d.label, "hotspot") || cocokFrasa(d.label, "hot spot")) &&
                tolak.none { cocokFrasa(d.label, it) }
        }
        if (calon.isEmpty()) return null
        val wifi = calon.filter { cocokFrasa(daftar[it].label, "wi-fi") || cocokFrasa(daftar[it].label, "wifi") }
        return when {
            wifi.size == 1 -> wifi.single()
            wifi.size > 1 -> null
            calon.size == 1 -> calon.single()
            else -> null
        }
    }
}
