# FIX145 — Pemindaian jendela dan fokus sakelar perangkat

## Dasar perbaikan
FIX144 dipertahankan sebagai dasar. Jalur perintah suara untuk membuka halaman pengaturan dari FIX141 tidak diubah. Aplikasi tidak diarahkan ke menu Pengaturan Aksesibilitas Android.

## Perubahan
- Layanan aksesibilitas kini memeriksa seluruh jendela interaktif Android yang berasal dari Settings/System UI, bukan hanya `rootInActiveWindow`. Ini ditujukan untuk panel Wi-Fi/NFC dan dialog sistem yang dapat tampil sebagai jendela terpisah.
- Pohon aksesibilitas dari jendela-jendela tersebut digabung sebelum pencarian sakelar, sehingga pencarian label Bluetooth, Wi-Fi, NFC, dan perangkat lain tidak terbatas pada satu jendela.
- Pemindahan fokus aksesibilitas ke elemen berikutnya tidak lagi mensyaratkan `ACTION_ACCESSIBILITY_FOCUS` tercantum pada `actionList`; aksi fokus tetap dicoba langsung karena sebagian implementasi OEM tidak melaporkan daftar aksi secara lengkap.
- Batas percobaan penelusuran dinaikkan dan waktu tunggu permintaan diperpanjang agar halaman yang lebih panjang mendapat kesempatan dipindai.
- Rute pembukaan pengaturan, pemilihan sakelar berdasarkan nama perangkat, serta verifikasi status sebelum mengumumkan keberhasilan tetap dipertahankan.

## Pemeriksaan
Pemeriksaan statis proyek, konsistensi bahasa, resource string, dan seluruh skrip `tools/uji_*.py` dijalankan. Pemeriksaan ini bukan pengganti kompilasi Gradle atau uji pada perangkat fisik.

## Batasan
FIX145 belum diuji pada perangkat fisik. Perilaku fokus aksesibilitas dapat berbeda menurut versi Android, aplikasi Pengaturan dari produsen perangkat, dan pembaca layar yang aktif. Keberhasilan harus dikonfirmasi melalui GitHub Actions dan pengujian langsung pada perangkat.
