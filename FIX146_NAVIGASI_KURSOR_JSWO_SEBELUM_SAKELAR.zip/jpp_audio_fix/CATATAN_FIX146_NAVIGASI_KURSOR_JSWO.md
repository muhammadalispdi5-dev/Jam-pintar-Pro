# FIX146 — Navigasi kursor JSWO sebelum menekan sakelar

## Masalah yang ditangani
FIX145 dapat menemukan sakelar pada pohon aksesibilitas, tetapi masih mencoba menekan sakelar segera setelah meminta fokus. Pada perangkat pengguna, kursor JSWO tetap berada di bagian paling atas halaman Pengaturan.

## Perubahan
- Sakelar tidak lagi ditekan hanya karena node sakelar berhasil ditemukan.
- Layanan meminta fokus pada sakelar/baris kontrol, lalu menunggu putaran pemeriksaan berikutnya.
- Fokus dinyatakan benar hanya jika `isAccessibilityFocused` berada pada sakelar/baris target atau elemen fokus yang beririsan dengan baris dan konteksnya cocok dengan nama perangkat yang diminta.
- Jika fokus langsung belum berpindah, layanan mencoba satu gestur satu jari geser ke kanan, mengikuti navigasi manual yang telah dikonfirmasi pengguna. Setelah setiap gestur, fokus diperiksa kembali.
- Gestur navigasi dibatasi maksimal 20 kali. Jika fokus target tetap tidak terkonfirmasi, proses dihentikan dan aplikasi mengumumkan kegagalan; sakelar tidak ditekan.
- Setelah fokus target terkonfirmasi, mekanisme klik dan verifikasi status ON/OFF yang sudah ada tetap digunakan.
- Jalur pembukaan halaman Pengaturan dari FIX141 dan versi aplikasi 1.0.81 / versionCode 81 dipertahankan.

## Batas pengujian
Pemeriksaan statis tidak dapat membuktikan bahwa JSWO pada perangkat tertentu akan menerima gestur sintetis sebagai perintah navigasi pembaca layar. Kompilasi Gradle dan uji perangkat fisik tetap diperlukan. Bila JSWO tidak memindahkan accessibility focus saat gestur disimulasikan, FIX146 akan berhenti tanpa menekan sakelar secara membabi buta.
