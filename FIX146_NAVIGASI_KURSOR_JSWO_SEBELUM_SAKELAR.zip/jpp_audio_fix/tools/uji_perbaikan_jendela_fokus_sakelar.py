from pathlib import Path

root = Path(__file__).resolve().parents[1]
service = (root / "app/src/main/java/com/novan/bateraibicara/PanggilanWhatsAppAccessibilityService.kt").read_text(encoding="utf-8")
activity = (root / "app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt").read_text(encoding="utf-8")
assert "for (jendela in windows)" in service
assert "rootInActiveWindow" in service
assert "akar.forEach { kumpulkan(it, nodes, 0) }" in service
assert "n.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)" in service
assert "jumlahGulir < 24" in service
assert "BATAS_PERANGKAT_MS = 45_000L" in service
start = activity.index("private fun bukaPengaturanPerangkat")
end = activity.index("private fun siapkanKontrolOtomatis", start)
assert "ACTION_ACCESSIBILITY_SETTINGS" not in activity[start:end]
print("PASS: semua jendela Settings/System UI dipindai, fokus dicoba tanpa bergantung pada actionList, dan rute pengaturan lama dipertahankan")
