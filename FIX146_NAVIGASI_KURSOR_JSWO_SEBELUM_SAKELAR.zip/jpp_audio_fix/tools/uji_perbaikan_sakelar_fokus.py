from pathlib import Path

root = Path(__file__).resolve().parents[1]
service = (root / "app/src/main/java/com/novan/bateraibicara/PanggilanWhatsAppAccessibilityService.kt").read_text(encoding="utf-8")
activity = (root / "app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt").read_text(encoding="utf-8")
assert "ACTION_ACCESSIBILITY_FOCUS" in service
assert "fokuskanSakelar(node)" in service
assert "gulirHalamanPengaturan(nodes)" in service
assert "KEY_PERANGKAT_GULIR" in service
# Preserve FIX141's device-command routing; only WhatsApp call setup may open Accessibility settings.
start = activity.index("private fun bukaPengaturanPerangkat")
end = activity.index("private fun siapkanKontrolOtomatis", start)
section = activity[start:end]
assert "ACTION_ACCESSIBILITY_SETTINGS" not in section
assert "siapkanKontrolOtomatis(kontrol)" in activity
print("PASS: fokus sakelar, gulir halaman target, dan rute pengaturan FIX141 dipertahankan")
