from pathlib import Path

root = Path(__file__).resolve().parents[1]
base = root / "app/src/main/java/com/novan/bateraibicara"
service = (base / "PanggilanWhatsAppAccessibilityService.kt").read_text(encoding="utf-8")
picker = (base / "PemilihSakelar.kt").read_text(encoding="utf-8")

# FIX146: switch tidak boleh disentuh sebelum fokus target benar-benar terdeteksi.
assert "if (!menungguVerifikasi && !fokusPadaSakelar(nodes, node, jenis))" in service
assert "private fun fokusPadaSakelar(" in service
assert "fokus.isAccessibilityFocused" in service
assert "PemilihSakelar.konteksCocok(konteksSakelar(fokus), jenis)" in service

# Jalur cadangan meniru satu geseran manual ke kanan dan diverifikasi pada putaran berikutnya.
assert "private fun geserKursorKanan(): Boolean" in service
assert "dispatchGesture(gesture, null, null)" in service
assert "lineTo(akhirX, y)" in service
assert "jumlahGeser < 20" in service
assert "jadwalkanPerangkat(550L)" in service

# Fokus harus sesuai perangkat yang diminta; label fitur lain tidak boleh diterima.
assert "fun konteksCocok(konteks: String, jenis: String): Boolean" in picker
assert "lain.none { cocokFrasa(konteks, it) }" in picker

# Jalur perintah membuka Settings tetap sama; tidak boleh dialihkan ke menu aksesibilitas.
activity = (base / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
start = activity.index("private fun bukaPengaturanPerangkat")
end = activity.index("private fun siapkanKontrolOtomatis", start)
assert "ACTION_ACCESSIBILITY_SETTINGS" not in activity[start:end]

print("PASS: fokus target diverifikasi sebelum sakelar ditekan; bila perlu dicoba geser kanan satu per satu; pemilihan tetap berdasarkan perangkat yang diminta.")
