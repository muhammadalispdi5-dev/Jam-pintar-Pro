Jam Pintar Pro 1.0.56 — penambahan opsi rekaman pemberitahuan

Basis proyek: 1.0.55.

- Menambahkan tujuh rekaman dari lampiran ke res/raw.
- Pengingat sebelum Subuh, Dzuhur, Ashar, Maghrib, dan Isya memiliki tiga mode: suara bicara standar, rekaman bawaan aplikasi, dan berkas pilihan sendiri.
- Imsak dan Matahari terbit memiliki tiga mode: suara azan standar aplikasi, rekaman pemberitahuan yang sesuai, dan berkas pilihan sendiri.
- Mode suara standar untuk pengingat sebelum salat tetap TTS seperti perilaku 1.0.55.
- Tidak menyambungkan rekaman pemberitahuan ke suara azan.
- Versi APK belum dikompilasi di lingkungan ini; jalankan GitHub Actions untuk memverifikasi build.
