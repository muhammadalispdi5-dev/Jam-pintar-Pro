package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Memantau goncangan ketika diaktifkan pengguna; tidak merekam audio di latar belakang. */
class GoncanganSuaraService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var sensor: Sensor? = null
    // FIX99: pemicu hanya sah untuk pola TIGA goncangan cepat (lihat DetektorGoncangan).
    private val detektor = DetektorGoncangan()
    private var sensorTerdaftar = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buatKanalNotifikasi()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, false).apply()
            hentikanLayanan()
            return START_NOT_STICKY
        }
        if (!getSharedPreferences("pengaturan", MODE_PRIVATE).getBoolean(KEY_AKTIF, false)) {
            hentikanLayanan()
            return START_NOT_STICKY
        }
        mulaiForeground()
        if (!sensorTerdaftar) {
            // Utamakan sensor wake-up agar peristiwa tetap membangunkan CPU saat layar mati.
            sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
                ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val tersedia = sensor
            if (tersedia == null) {
                getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, false).apply()
                hentikanLayanan()
                return START_NOT_STICKY
            }
            detektor.reset()
            sensorTerdaftar = sensorManager.registerListener(this, tersedia, SensorManager.SENSOR_DELAY_GAME)
            // Sebagian perangkat tidak menyediakan akselerometer wake-up. Pada perangkat itu,
            // tahan CPU hanya selama fitur ini sengaja diaktifkan agar sensor tetap terbaca saat layar mati.
            if (sensorTerdaftar && Build.VERSION.SDK_INT >= 21 && !tersedia.isWakeUpSensor) {
                try {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, ("" + (packageName) + ":ShakeVoiceSensor")).apply {
                        setReferenceCounted(false)
                        acquire()
                    }
                } catch (_: Exception) { }
            }
            if (!sensorTerdaftar) {
                getSharedPreferences("pengaturan", MODE_PRIVATE).edit().putBoolean(KEY_AKTIF, false).apply()
                hentikanLayanan()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun mulaiForeground() {
        val english = BahasaAplikasi.tampilan(this) == 1
        val buka = PendingIntent.getActivity(
            this, 9401, Intent(this, PengaturanGoncanganActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 9402, Intent(this, GoncanganSuaraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle(if (english) "Shake voice trigger is active" else "Pemicu suara dengan goncangan aktif")
            .setContentText(if (english) "Shake three times quickly to open voice commands" else "Goyangkan HP tiga kali cepat untuk membuka perintah suara")
            .setContentIntent(buka)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, if (english) "Turn off" else "Nonaktifkan", stop)
        val notification = builder.build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER || event.values.size < 3) return
        val pref = getSharedPreferences("pengaturan", MODE_PRIVATE)
        detektor.sensitivitas = pref.getInt(KEY_SENSITIVITAS, 5).coerceIn(1, 10)
        detektor.longgar = pref.getInt(KEY_MODE, MODE_KETAT) == MODE_LONGGAR
        // Cap waktu sensor (nanodetik sejak boot) lebih akurat daripada waktu penerimaan peristiwa.
        val hasil = detektor.proses(event.values[0], event.values[1], event.values[2], event.timestamp / 1_000_000L)
        if (hasil == DetektorGoncangan.Hasil.POLA && !sedangUji) bukaPerintahSuara()
    }

    /**
     * FIX95: peluncuran dari layanan latar belakang sering ditahan Android saat layar mati/terkunci.
     * Jalur andal: notifikasi layar penuh (full-screen intent) yang membuka layar perintah suara di atas layar kunci.
     * Peluncuran langsung tetap dicoba (berhasil bila izin "Tampil di atas aplikasi lain" aktif); layar perintah
     * mengabaikan pemicu ganda.
     */
    private fun bukaPerintahSuara() {
        val english = BahasaAplikasi.tampilan(this) == 1
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, ("" + (packageName) + ":ShakeLaunch")).apply {
                setReferenceCounted(false)
                acquire(15_000L)
            }
        } catch (_: Exception) { }
        val intent = Intent(this, PerintahSuaraActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(PerintahSuaraActivity.EXTRA_PEMICU_GONCANGAN, true)
        }
        try {
            val launch = PendingIntent.getActivity(
                this, 9403, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_SIAP_ID)
                else Notification.Builder(this).setPriority(Notification.PRIORITY_MAX)
            builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(if (english) "Voice command is ready" else "Perintah suara siap")
                .setContentText(if (english) "Tap to speak" else "Ketuk untuk mulai berbicara")
                .setContentIntent(launch)
                .setFullScreenIntent(launch, true)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
            if (Build.VERSION.SDK_INT >= 26) builder.setTimeoutAfter(20_000L)
            getSystemService(NotificationManager::class.java).notify(NOTIFIKASI_SIAP_ID, builder.build())
        } catch (_: Exception) { }
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun buatKanalNotifikasi() {
        if (Build.VERSION.SDK_INT < 26) return
        val english = BahasaAplikasi.tampilan(this) == 1
        val channel = NotificationChannel(
            CHANNEL_ID,
            if (english) "Shake voice trigger" else "Pemicu suara dengan goncangan",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = if (english) "Ongoing notification while shake activation is enabled" else "Notifikasi tetap selama aktivasi goncangan dinyalakan"
            setShowBadge(false)
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
        // FIX95: kanal prioritas tinggi untuk notifikasi layar penuh "Perintah suara siap" (tanpa suara).
        val siap = NotificationChannel(
            CHANNEL_SIAP_ID,
            if (english) "Shake voice command ready" else "Perintah suara siap (goncangan)",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = if (english) "Opens voice commands on the lock screen after a shake" else "Membuka perintah suara di layar kunci setelah goncangan"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(siap)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun hentikanLayanan() {
        if (sensorTerdaftar) {
            try { sensorManager.unregisterListener(this) } catch (_: Exception) { }
            sensorTerdaftar = false
        }
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (sensorTerdaftar) try { sensorManager.unregisterListener(this) } catch (_: Exception) { }
        sensorTerdaftar = false
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val KEY_AKTIF = "pemicu_goncangan_suara_aktif"
        const val KEY_SENSITIVITAS = "pemicu_goncangan_suara_sensitivitas"
        private const val ACTION_STOP = "com.novan.bateraibicara.action.STOP_SHAKE_VOICE"
        private const val CHANNEL_ID = "pemicu_goncangan_suara"
        private const val CHANNEL_SIAP_ID = "pemicu_goncangan_suara_siap"
        private const val NOTIFICATION_ID = 9400
        const val NOTIFIKASI_SIAP_ID = 9401
        /** FIX99: 0 = ketat (HP diam dulu, lalu tiga goncangan cepat); 1 = longgar (boleh sambil bergerak, tepat tiga hentakan kuat). */
        const val KEY_MODE = "pemicu_goncangan_suara_mode"
        const val MODE_KETAT = 0
        const val MODE_LONGGAR = 1

        /** Diset true oleh layar uji goncangan agar pola yang dikenali saat uji tidak membuka perintah suara. */
        @Volatile
        var sedangUji = false

        fun mulai(context: Context) {
            val i = Intent(context, GoncanganSuaraService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun hentikan(context: Context) {
            try { context.stopService(Intent(context, GoncanganSuaraService::class.java)) } catch (_: Exception) { }
        }
    }
}
