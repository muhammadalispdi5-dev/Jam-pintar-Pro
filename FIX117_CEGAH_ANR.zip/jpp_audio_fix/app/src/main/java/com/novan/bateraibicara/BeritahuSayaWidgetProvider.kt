package com.novan.bateraibicara

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/** Widget aksesibel: status aktif/nonaktif mengikuti sakelar Beritahu Saya di halaman utama. */
class BeritahuSayaWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        perbarui(context, manager, ids)
    }

    companion object {
        fun perbaruiSemua(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, BeritahuSayaWidgetProvider::class.java))
            perbarui(context, manager, ids)
        }

        private fun perbarui(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val aktif = Prefs(context).beritahuSayaOn
            val intent = Intent(context, BeritahuSayaActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
            }
            val pending = PendingIntent.getActivity(
                context,
                817,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val intentSuara = Intent(context, PerintahSuaraActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            }
            val pendingSuara = PendingIntent.getActivity(
                context,
                818,
                intentSuara,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val langsungSuara = Prefs(context).beritahuSayaLangsungSuara
            for (id in ids) {
                val views = RemoteViews(context.packageName, R.layout.widget_beritahu_saya)
                val label = context.getString(if (aktif) R.string.widget_beritahu_saya else R.string.widget_beritahu_saya_mati)
                val deskripsi = context.getString(
                    if (aktif) R.string.widget_beritahu_saya_deskripsi else R.string.widget_beritahu_saya_mati_deskripsi
                )
                views.setTextViewText(R.id.widget_beritahu_button, label)
                views.setContentDescription(R.id.widget_beritahu_button, deskripsi)
                if (langsungSuara) {
                    // Mode satu tombol: sekali ketuk langsung perintah suara; tombol kedua disembunyikan.
                    views.setContentDescription(R.id.widget_beritahu_button, context.getString(if (aktif) R.string.widget_beritahu_saya_suara_deskripsi else R.string.widget_beritahu_saya_mati_deskripsi))
                    views.setOnClickPendingIntent(R.id.widget_beritahu_button, pendingSuara)
                    views.setViewVisibility(R.id.widget_perintah_suara_button, View.GONE)
                    manager.updateAppWidget(id, views)
                    continue
                }
                views.setViewVisibility(R.id.widget_perintah_suara_button, View.VISIBLE)
                views.setOnClickPendingIntent(R.id.widget_beritahu_button, pending)
                // FIX85: ketuk tahan widget dikuasai peluncur HP, jadi perintah suara disediakan sebagai tombol sendiri.
                views.setTextViewText(R.id.widget_perintah_suara_button, context.getString(R.string.widget_perintah_suara))
                views.setContentDescription(R.id.widget_perintah_suara_button, context.getString(R.string.widget_perintah_suara_deskripsi))
                views.setOnClickPendingIntent(R.id.widget_perintah_suara_button, pendingSuara)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
