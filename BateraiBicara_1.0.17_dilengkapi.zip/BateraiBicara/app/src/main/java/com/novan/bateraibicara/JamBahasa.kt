package com.novan.bateraibicara

/** Kata bilangan untuk pengumuman jam. */
object JamBahasa {
    private val id = arrayOf("nol", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas")
    private val en = arrayOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven")
    fun kata(n: Int, bahasa: Int): String {
        if (bahasa == 0) return JamWaktu.kata(n)
        val a = en
        return when (n) {
            in 0..11 -> a[n]
            12 -> "twelve"; 13 -> "thirteen"; 14 -> "fourteen"; 15 -> "fifteen"; 16 -> "sixteen"
            17 -> "seventeen"; 18 -> "eighteen"; 19 -> "nineteen"
            else -> {
                val tens = arrayOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
                if (n in 20..99) tens[n / 10] + if (n % 10 == 0) "" else "-" + a[n % 10] else n.toString()
            }
        }
    }
}
