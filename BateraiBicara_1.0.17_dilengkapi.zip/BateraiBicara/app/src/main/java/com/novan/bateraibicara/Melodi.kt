package com.novan.bateraibicara

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/** Nada pendek yang dapat dipakai sebagai penanda awal/akhir pengumuman. */
object Melodi {
    private val handler = Handler(Looper.getMainLooper())
    fun bunyikan(context: Context, durasiMs: Int = 180) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, durasiMs.coerceIn(80, 800))
            handler.postDelayed({ try { tg.release() } catch (_: Exception) { } }, durasiMs.coerceIn(80, 800).toLong() + 100)
        } catch (_: Exception) { }
    }
}
