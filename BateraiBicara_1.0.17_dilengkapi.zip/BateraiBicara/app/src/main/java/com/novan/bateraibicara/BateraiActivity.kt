package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/** Pengaturan kategori Baterai: tampilan baterai, kapan berbicara, dan suara. */
class BateraiActivity : Halaman() {

    override val judulHalaman = R.string.kategori_baterai

    private lateinit var teksBaterai: TextView
    private lateinit var bar: ProgressBar
    private var persen = 0

    private val penerima = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            perbarui(intent)
        }
    }

    override fun bangun() {
        // ----- Tampilan baterai -----
        teksBaterai = info("")
        teksBaterai.textSize = 18f
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        bar.importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)))

        saklar(getString(R.string.sw_baterai_on), prefs.bateraiOn) { prefs.bateraiOn = it }

        // ----- Kapan berbicara -----
        bagian(getString(R.string.bagian_ucapan))
        pilihan(getString(R.string.setiap), larik(R.array.langkah), prefs.stepIdx) { prefs.stepIdx = it }
        pilihan(getString(R.string.persen_saat), larik(R.array.mode_level), prefs.levelMode) { prefs.levelMode = it }
        saklar(getString(R.string.sw_lemah), prefs.lemahOn) { prefs.lemahOn = it }
        pilihan(getString(R.string.batas_lemah), larik(R.array.batas_lemah), prefs.lowIdx) { prefs.lowIdx = it }
        saklar(getString(R.string.sw_kritis), prefs.kritisOn) { prefs.kritisOn = it }
        saklar(getString(R.string.sw_penuh), prefs.penuhOn) { prefs.penuhOn = it }
        saklar(getString(R.string.sw_charger), prefs.chargerOn) { prefs.chargerOn = it }
        saklar(getString(R.string.sw_usb), prefs.usbOn) { prefs.usbOn = it }

        // ----- Suara -----
        blokSuara("bat") { getString(R.string.ucap_tes, persen) }
    }

    override fun onResume() {
        super.onResume()
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(penerima, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(penerima, f)
        }
        if (sticky != null) perbarui(sticky)
    }

    override fun onPause() {
        try { unregisterReceiver(penerima) } catch (e: Exception) { }
        super.onPause()
    }

    private fun perbarui(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        persen = if (level < 0) 0 else level * 100 / skala
        val mengisi = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val suhu = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        teksBaterai.text = getString(R.string.tampilan_baterai, persen, status, suhu, volt)
        bar.progress = persen
    }
}
