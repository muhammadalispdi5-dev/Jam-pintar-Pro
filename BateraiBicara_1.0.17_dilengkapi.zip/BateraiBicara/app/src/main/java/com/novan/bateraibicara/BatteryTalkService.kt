package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import java.util.Calendar

/**
 * Layanan foreground yang terus berjalan: memantau baterai dan menjalankan jadwal jam bicara.
 * (Nama pemanggil ditangani oleh [CallerListener].)
 */
class BatteryTalkService : Service() {

    private lateinit var prefs: Prefs
    private val pembicara = HashMap<String, Pembicara>()
    private var penerimaTerdaftar = false

    private var levelTerakhir = -1
    private var plugTerakhir = -1
    private var terakhirDiucap = -1
    private var lemahDiberi = false
    private var kritisDiberi = false
    private var penuhDiberi = false
    private var teksNotifTerakhir = ""

    private val penerima = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            proses(intent, false)
        }
    }

    private val penerimaWaktu = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            jadwalkanJam(context)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        buatSaluran()
        mulaiForeground()

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(penerima, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(penerima, filter)
        }
        val fw = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(penerimaWaktu, fw, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(penerimaWaktu, fw)
        }
        penerimaTerdaftar = true

        if (prefs.bateraiOn) bicara("bat")
        if (prefs.jamOn) bicara("jam")
        if (sticky != null) proses(sticky, true)
        jadwalkanJam(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.enabled = false
                batalkanJam(this)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> jadwalkanJam(this)
            ACTION_JAM -> {
                ucapkanJam()
                jadwalkanJam(this)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (penerimaTerdaftar) {
            try { unregisterReceiver(penerima) } catch (e: Exception) { }
            try { unregisterReceiver(penerimaWaktu) } catch (e: Exception) { }
        }
        for (p in pembicara.values) p.matikan()
        pembicara.clear()
        super.onDestroy()
    }

    // ---------- Pembicara per kategori ----------

    private fun bicara(profil: String): Pembicara {
        val s = prefs.suara(profil)
        val ada = pembicara[profil]
        if (ada != null && ada.tanda == s.tanda()) return ada
        ada?.matikan()
        val baru = Pembicara(this, s)
        pembicara[profil] = baru
        return baru
    }

    // ---------- Notifikasi & foreground ----------

    private fun buatSaluran() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                CHANNEL_ID, getString(R.string.notif_saluran), NotificationManager.IMPORTANCE_LOW
            )
            ch.setShowBadge(false)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun bangunNotifikasi(isi: String): Notification {
        val buka = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BatteryTalkService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this).setPriority(Notification.PRIORITY_LOW)
        }
        b.setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(getString(R.string.notif_judul))
            .setContentText(isi)
            .setContentIntent(buka)
            .setOngoing(true)
            .setShowWhen(false)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                    getString(R.string.notif_tombol_matikan),
                    stop
                ).build()
            )
        return b.build()
    }

    private fun mulaiForeground() {
        teksNotifTerakhir = getString(R.string.notif_menunggu)
        val n = bangunNotifikasi(teksNotifTerakhir)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun perbaruiTampilan(persen: Int, mengisi: Boolean) {
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        val teks = getString(R.string.notif_isi, persen, status)
        if (teks != teksNotifTerakhir) {
            teksNotifTerakhir = teks
            try {
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, bangunNotifikasi(teks))
            } catch (e: Exception) { }
        }
        BatteryWidgetProvider.refresh(this, persen, mengisi)
    }

    // ---------- Logika baterai ----------

    private fun proses(i: Intent, diam: Boolean) {
        val raw = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        if (raw < 0) return
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        val persen = raw * 100 / skala
        val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val mengisi = plug != 0

        if (persen == levelTerakhir && plug == plugTerakhir) return
        perbaruiTampilan(persen, mengisi)

        val batasLemah = prefs.lowThreshold

        if (diam || plugTerakhir == -1) {
            levelTerakhir = persen
            plugTerakhir = plug
            terakhirDiucap = persen
            lemahDiberi = !mengisi && persen <= batasLemah
            kritisDiberi = !mengisi && persen <= 5
            penuhDiberi = mengisi && persen >= 100
            return
        }

        val pesan = ArrayList<String>()

        if (plug != plugTerakhir) {
            if (plug == 0) {
                val usb = plugTerakhir == BatteryManager.BATTERY_PLUGGED_USB
                if (usb && prefs.usbOn) pesan.add(getString(R.string.ucap_usb_off))
                else if (!usb && prefs.chargerOn) pesan.add(getString(R.string.ucap_charger_off))
            } else {
                val usb = plug == BatteryManager.BATTERY_PLUGGED_USB
                if (usb && prefs.usbOn) pesan.add(getString(R.string.ucap_usb_on))
                else if (!usb && prefs.chargerOn) pesan.add(getString(R.string.ucap_charger_on))
            }
        }

        if (mengisi) {
            lemahDiberi = false
            kritisDiberi = false
        } else {
            penuhDiberi = false
        }
        if (persen > batasLemah) lemahDiberi = false
        if (persen > 5) kritisDiberi = false
        if (persen < 100) penuhDiberi = false

        if (persen != levelTerakhir) {
            var diucap = false
            if (!mengisi && persen <= 5 && prefs.kritisOn && !kritisDiberi) {
                kritisDiberi = true
                lemahDiberi = true
                pesan.add(getString(R.string.ucap_kritis, persen))
                diucap = true
            } else if (!mengisi && persen <= batasLemah && prefs.lemahOn && !lemahDiberi) {
                lemahDiberi = true
                pesan.add(getString(R.string.ucap_lemah, persen))
                diucap = true
            } else if (mengisi && persen >= 100 && prefs.penuhOn && !penuhDiberi) {
                penuhDiberi = true
                pesan.add(getString(R.string.ucap_penuh))
                diucap = true
            }
            if (!diucap) {
                val langkah = prefs.step
                // levelMode 0 = persen hanya disebut saat mengisi daya; 1 = selalu.
                val bolehUcap = prefs.levelMode == 1 || mengisi
                if (langkah > 0 && bolehUcap && persen % langkah == 0 && persen != terakhirDiucap) {
                    pesan.add(getString(R.string.ucap_level, persen))
                    diucap = true
                }
            }
            if (diucap) terakhirDiucap = persen
        }

        levelTerakhir = persen
        plugTerakhir = plug
        if (prefs.enabled && prefs.bateraiOn) {
            for (p in pesan) bicara("bat").ucapkan(p)
        }
    }

    // ---------- Jam bicara ----------

    private fun ucapkanJam() {
        if (!prefs.enabled || !prefs.jamOn) return
        val c = Calendar.getInstance()
        c.timeInMillis = c.timeInMillis + 2000 // alarm tepat waktu bisa terpicu sedikit lebih awal
        bicara("jam").ucapkan(JamWaktu.ucapan(prefs, c))
    }

    companion object {
        const val ACTION_STOP = "com.novan.bateraibicara.STOP"
        const val ACTION_RELOAD = "com.novan.bateraibicara.RELOAD"
        const val ACTION_JAM = "com.novan.bateraibicara.JAM"
        private const val CHANNEL_ID = "pemantau_baterai"
        private const val NOTIF_ID = 1

        fun start(context: Context) {
            val i = Intent(context, BatteryTalkService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        /** Muat ulang jadwal jam setelah pengaturan berubah. */
        fun reload(context: Context) {
            val i = Intent(context, BatteryTalkService::class.java).setAction(ACTION_RELOAD)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun stop(context: Context) {
            batalkanJam(context)
            context.stopService(Intent(context, BatteryTalkService::class.java))
        }

        private fun pendingJam(c: Context): PendingIntent {
            val i = Intent(c, BatteryTalkService::class.java).setAction(ACTION_JAM)
            val f = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            return if (Build.VERSION.SDK_INT >= 26) {
                PendingIntent.getForegroundService(c, 10, i, f)
            } else {
                PendingIntent.getService(c, 10, i, f)
            }
        }

        fun batalkanJam(c: Context) {
            try {
                c.getSystemService(AlarmManager::class.java).cancel(pendingJam(c))
            } catch (e: Exception) { }
        }

        /** Pasang alarm tepat waktu untuk jadwal jam bicara berikutnya. */
        fun jadwalkanJam(c: Context) {
            val am = c.getSystemService(AlarmManager::class.java)
            val pi = pendingJam(c)
            am.cancel(pi)
            val p = Prefs(c)
            if (!p.enabled || !p.jamOn) return
            val t = JamWaktu.berikut(p, System.currentTimeMillis() + 2000) ?: return
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            }
        }
    }
}
