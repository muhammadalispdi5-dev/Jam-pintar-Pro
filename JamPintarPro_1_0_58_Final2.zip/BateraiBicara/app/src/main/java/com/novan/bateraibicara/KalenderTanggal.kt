package com.novan.bateraibicara

import android.icu.util.IslamicCalendar
import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.concurrent.Executors
import android.icu.util.TimeZone as IcuTimeZone
import java.util.Calendar
import java.util.GregorianCalendar
import java.util.Locale
import java.util.TimeZone

/** Penyusun tanggal Masehi, Hijriah hitungan perangkat, dan pasaran Jawa. */
object KalenderTanggal {
    private val localeId = Locale("in", "ID")
    private val bulanMasehi = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
    private val bulanMasehiEn = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    private val bulanMasehiAr = arrayOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
    private val bulanHijriah = arrayOf("Muharam", "Safar", "Rabiulawal", "Rabiulakhir", "Jumadilawal", "Jumadilakhir", "Rajab", "Syakban", "Ramadan", "Syawal", "Zulkaidah", "Zulhijah")
    private val bulanHijriahEn = arrayOf("Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Ula", "Jumada al-Akhirah", "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhu al-Qadah", "Dhu al-Hijjah")
    // Nama bulan Hijriah dalam tradisi Jawa, dipakai agar rangkaian Jawa tidak bercampur nama bulan Indonesia.
    private val bulanHijriahJawa = arrayOf("Sura", "Sapar", "Mulud", "Bakdamulud", "Jumadilawal", "Jumadilakir", "Rejeb", "Ruwah", "Pasa", "Sawal", "Dulkangidah", "Besar")
    private val bulanHijriahAr = arrayOf("محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")
    private val hariInggris = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    private val hariArab = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
    private val hariNama = arrayOf("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
    private val hariJawa = arrayOf("Ahad", "Senen", "Selasa", "Rebo", "Kemis", "Jumuwah", "Setu")
    // Patokan kalender Jawa: 1 Januari 2026 = Kamis Pon.
    private val pasaran = arrayOf("Pon", "Wage", "Kliwon", "Legi", "Pahing")
    private val sinkronExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var sinkronBerjalan = false

    /**
     * Memperbarui offset Hijriah secara daring satu kali per tanggal kalender lokal.
     * Sumber konversi daring AlAdhan; bukan klaim sebagai API resmi Kemenag.
     * Bila offline, offset terakhir tetap dipakai dan kalender perangkat tetap menjadi fallback.
     */
    fun perbaruiHijriahOtomatis(context: Context, sekarang: Calendar = Calendar.getInstance(), paksa: Boolean = false, selesai: ((Boolean) -> Unit)? = null) {
        val prefs = context.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("kal_hijri_auto", false)) { selesai?.invoke(false); return }
        val target = tanggalHariIni(sekarang)
        val keyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val tanggalKey = keyFormat.format(target.time)
        val cacheTanggalHijriLengkap = prefs.getInt("kal_hijri_online_day", 0) in 1..30 &&
            prefs.getInt("kal_hijri_online_month", 0) in 1..12 &&
            prefs.getInt("kal_hijri_online_year", 0) > 0
        if (!paksa && prefs.getString("kal_hijri_online_sync_date", "") == tanggalKey && cacheTanggalHijriLengkap) {
            selesai?.invoke(true); return
        }
        val percobaanTerakhir = prefs.getLong("kal_hijri_online_last_attempt", 0L)
        if (!paksa && System.currentTimeMillis() - percobaanTerakhir < 6L * 60L * 60L * 1000L) {
            selesai?.invoke(false); return
        }
        prefs.edit().putLong("kal_hijri_online_last_attempt", System.currentTimeMillis()).apply()
        synchronized(this) {
            if (sinkronBerjalan) { selesai?.invoke(false); return }
            sinkronBerjalan = true
        }
        sinkronExecutor.execute {
            var sukses = false
            var offsetBaru: Int? = null
            var koneksi: HttpURLConnection? = null
            try {
                val apiDate = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(target.time)
                koneksi = (URL("https://api.aladhan.com/v1/gToH/$apiDate").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000; readTimeout = 7000; requestMethod = "GET"
                }
                if (koneksi.responseCode in 200..299) {
                    val json = JSONObject(koneksi.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                    val h = json.getJSONObject("data").getJSONObject("hijri")
                    val apiDay = h.getString("day").toInt()
                    val apiMonth = h.getJSONObject("month").getInt("number")
                    val apiYear = h.getString("year").toInt()
                    val icu = IslamicCalendar(IcuTimeZone.getDefault(), localeId).apply { timeInMillis = target.timeInMillis }
                    val icuDay = icu.get(android.icu.util.Calendar.DAY_OF_MONTH)
                    val icuMonth = icu.get(android.icu.util.Calendar.MONTH) + 1
                    val icuYear = icu.get(android.icu.util.Calendar.YEAR)
                    offsetBaru = (angkaHariHijri(apiYear, apiMonth, apiDay) - angkaHariHijri(icuYear, icuMonth, icuDay)).coerceIn(-3, 3)
                    prefs.edit().putInt("kal_hijri_online_offset", offsetBaru!!)
                        .putInt("kal_hijri_online_day", apiDay)
                        .putInt("kal_hijri_online_month", apiMonth)
                        .putInt("kal_hijri_online_year", apiYear)
                        .putString("kal_hijri_online_sync_date", tanggalKey)
                        .putLong("kal_hijri_online_sync_time", System.currentTimeMillis()).apply()
                    sukses = true
                }
            } catch (_: Exception) {
                // Jangan hapus cache saat offline atau API gagal.
            } finally {
                try { koneksi?.disconnect() } catch (_: Exception) {}
                synchronized(this) { sinkronBerjalan = false }
                val result = sukses
                if (selesai != null) Handler(Looper.getMainLooper()).post { selesai.invoke(result) }
            }
        }
    }

    private fun angkaHariHijri(tahun: Int, bulan: Int, hari: Int): Int =
        hari + ((59 * (bulan - 1) + 1) / 2) + (tahun - 1) * 354 + (3 + 11 * tahun) / 30 + 1948439 - 1

    private fun kunciTanggal(c: Calendar): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(tanggalHariIni(c).time)

    /** Hari kalender Jawa/Hijriah berganti saat matahari terbenam; digunakan pukul 18.00 lokal. */
    private fun tanggalHariIni(c: Calendar): Calendar {
        val hasil = (c.clone() as Calendar)
        if (hasil.get(Calendar.HOUR_OF_DAY) >= 18) {
            hasil.add(Calendar.DAY_OF_MONTH, 1)
        }
        hasil.set(Calendar.HOUR_OF_DAY, 12)
        hasil.set(Calendar.MINUTE, 0)
        hasil.set(Calendar.SECOND, 0)
        hasil.set(Calendar.MILLISECOND, 0)
        return hasil
    }

    fun masehi(c: Calendar, bahasa: Int = 0): String {
        val hari = c.get(Calendar.DAY_OF_MONTH)
        val bulanIndex = c.get(Calendar.MONTH)
        val bulan = bulanMasehi[bulanIndex]
        val tahun = c.get(Calendar.YEAR)
        return when (bahasa) {
            1 -> "Gregorian date $hari ${bulanMasehiEn[bulanIndex]} $tahun"
            2 -> "التاريخ الميلادي $hari ${bulanMasehiAr[bulanIndex]} $tahun"
            3 -> "Tanggal Masehi inggih menika ${JamBahasa.jawaAngka(hari)} wulan $bulan taun ${JamBahasa.jawaTaun(tahun)}"
            else -> "Tanggal $hari $bulan $tahun Masehi"
        }
    }

    fun hijriah(
        c: Calendar,
        koreksiHari: Int,
        offsetOnline: Int = 0,
        onlineTanggal: String? = null,
        onlineHari: Int? = null,
        onlineBulan: Int? = null,
        onlineTahun: Int? = null,
        bahasa: Int = 0
    ): String {
        // Nama hari/malam harus selalu mengikuti tanggal lokal sasaran, bukan offset
        // koreksi Hijriah. Offset API hanya mengoreksi tanggal Hijriah; sebelumnya ia
        // ikut menggeser nama hari sehingga Jumat malam dapat salah disebut malam Ahad.
        val tanggalNamaHari = tanggalHariIni(c)
        val targetKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(tanggalNamaHari.time)
        val pakaiTanggalOnline = koreksiHari == 0 && onlineTanggal == targetKey &&
            onlineHari != null && onlineHari in 1..30 &&
            onlineBulan != null && onlineBulan in 1..12 &&
            onlineTahun != null && onlineTahun > 0

        val hari: Int
        val bulanIndex: Int
        val tahun: Int
        if (pakaiTanggalOnline) {
            // Pakai tanggal Hijriah persis dari respons daring untuk tanggal sasaran ini,
            // bukan menghitung selisih offset yang berpotensi menutupi kesalahan kalender.
            hari = onlineHari!!
            bulanIndex = onlineBulan!! - 1
            tahun = onlineTahun!!
        } else {
            val tanggalHitung = (tanggalNamaHari.clone() as Calendar).apply {
                if (koreksiHari != 0 || offsetOnline != 0) add(Calendar.DAY_OF_MONTH, koreksiHari + offsetOnline)
            }
            val hijri = IslamicCalendar(IcuTimeZone.getDefault(), localeId)
            hijri.timeInMillis = tanggalHitung.timeInMillis
            hari = hijri.get(android.icu.util.Calendar.DAY_OF_MONTH)
            bulanIndex = hijri.get(android.icu.util.Calendar.MONTH)
            tahun = hijri.get(android.icu.util.Calendar.YEAR)
        }
        val bulanIndexValid = bulanIndex.coerceIn(0, 11)
        val bulan = bulanHijriah[bulanIndexValid]
        val indeksHari = tanggalNamaHari.get(Calendar.DAY_OF_WEEK) - 1
        val sebutanWengi = c.get(Calendar.HOUR_OF_DAY) >= 18
        return when (bahasa) {
            1 -> "Corresponding to ${if (sebutanWengi) "the night of" else "the day of"} ${hariInggris[indeksHari]}, $hari ${bulanHijriahEn[bulanIndexValid]} $tahun Hijri"
            2 -> "يوافق ${if (sebutanWengi) "ليلة" else "يوم"} ${hariArab[indeksHari]}، $hari ${bulanHijriahAr[bulanIndexValid]} $tahun هجري"
            3 -> {
                val wektuJawa = if (sebutanWengi) "dalu" else "dinten"
                "Tanggal Hijriyah ing $wektuJawa ${hariJawa[indeksHari]} menika ${JamBahasa.jawaAngka(hari)} wulan ${bulanHijriahJawa[bulanIndexValid]} taun ${JamBahasa.jawaTaun(tahun)}"
            }
            else -> "Bertepatan dengan ${if (sebutanWengi) "malam" else "hari"} ${hariNama[indeksHari]}, tanggal $hari $bulan $tahun Hijriah"
        }
    }

    fun pasaran(c: Calendar, koreksiHari: Int, bahasa: Int = 0): String {
        val tanggal = tanggalHariIni(c)
        if (koreksiHari != 0) tanggal.add(Calendar.DAY_OF_MONTH, koreksiHari)
        val target = GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.US)
        target.clear()
        target.set(tanggal.get(Calendar.YEAR), tanggal.get(Calendar.MONTH), tanggal.get(Calendar.DAY_OF_MONTH))
        val dasar = GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.US)
        dasar.clear()
        dasar.set(2026, Calendar.JANUARY, 1)
        val beda = ((target.timeInMillis - dasar.timeInMillis) / 86_400_000L).toInt()
        val indeks = ((beda % 5) + 5) % 5
        val indeksHari = tanggal.get(Calendar.DAY_OF_WEEK) - 1
        val namaHari = when (bahasa) {
            1 -> hariInggris[indeksHari]
            2 -> hariArab[indeksHari]
            3 -> hariJawa[indeksHari]
            else -> hariNama[indeksHari]
        }
        val sebutan = when (bahasa) {
            1 -> if (c.get(Calendar.HOUR_OF_DAY) >= 18) "Night" else "Day"
            2 -> if (c.get(Calendar.HOUR_OF_DAY) >= 18) "ليلة" else "يوم"
            3 -> if (c.get(Calendar.HOUR_OF_DAY) >= 18) "Dalu" else "Dinten"
            else -> if (c.get(Calendar.HOUR_OF_DAY) >= 18) "Malam" else "Hari"
        }
        val pasar = if (bahasa == 2) when (pasaran[indeks]) {
            "Pon" -> "بون"; "Wage" -> "واجي"; "Kliwon" -> "كليوون"; "Legi" -> "ليغي"; else -> "باهينغ"
        } else pasaran[indeks]
        val label = when (bahasa) { 1 -> "Javanese market day"; 2 -> "يوم السوق الجاوي"; else -> "" }
        return if (label.isNotEmpty()) "$label $sebutan $namaHari $pasar" else "$sebutan $namaHari $pasar"
    }
}
