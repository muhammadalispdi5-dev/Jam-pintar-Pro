package com.novan.bateraibicara

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.EditText

/** Pemandu jalan kaki aksesibel: memperoleh fix GPS lalu menyerahkan panduan belokan ke Google Maps. */
class PemanduJalanActivity : Halaman() {
    override val judulHalaman = R.string.judul_pemandu_jalan

    private lateinit var tujuan: EditText
    private lateinit var status: android.widget.TextView
    private var manager: LocationManager? = null
    private var listener: LocationListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sedangMencari = false
    private var pembicaraPanduan: Pembicara? = null
    private val timeout = Runnable {
        if (sedangMencari) {
            berhentiMencari()
            val pesan = "Belum mendapatkan posisi GPS satelit yang memadai. Cobalah di luar ruangan dengan pandangan langit terbuka, lalu coba lagi."
            status.text = ui(pesan)
            ucapkanPanduan(pesan, "Could not get a reliable GPS satellite position. Try again outdoors with a clear view of the sky.")
            toast("GPS satelit belum mendapatkan posisi. Silakan coba lagi di tempat terbuka.")
        }
    }

    override fun bangun() {
        info("Masukkan alamat atau nama tempat tujuan. Jam Pintar Pro akan mencoba memperoleh posisi dari GPS satelit, lalu membuka Google Maps dengan rute berjalan kaki dan panduan suara. Koneksi internet dan aplikasi peta yang mendukung navigasi mungkin diperlukan.")
        info("Panduan ini membantu arah perjalanan, tetapi tidak dapat mendeteksi semua rintangan, lubang, kendaraan, atau kondisi trotoar. Tetap gunakan tongkat, anjing pemandu, atau bantuan pendamping bila diperlukan. Berhenti di tempat aman sebelum mengoperasikan ponsel.")
        info("Suara petunjuk Jam Pintar Pro menggunakan mesin TTS yang dipilih pada profil Caller Name. Petunjuk belokan saat navigasi di Google Maps mengikuti pengaturan suara Google Maps atau mesin TTS bawaan Android.")
        tujuan = isian("Alamat atau nama tempat tujuan", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) { }
        status = info("Status: belum mulai. Masukkan tujuan, lalu pilih Mulai panduan jalan kaki.")
        tombol("Uji suara pemandu jalan") {
            ucapkanPanduan("Suara pemandu jalan siap. Panduan menggunakan mesin suara yang dipilih pada profil Caller Name.", "Walking guide voice is ready. This guide uses the speech engine selected in the Caller Name profile.")
        }
        tombol("Mulai panduan jalan kaki") { mulai() }
        tombol("Buka setelan GPS dan lokasi") {
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            catch (_: Exception) { toast("Setelan lokasi tidak dapat dibuka."); ucapkanPanduan("Setelan lokasi tidak dapat dibuka.", "Location settings could not be opened.") }
        }
        tombol("Batalkan pencarian GPS") {
            berhentiMencari()
            status.text = ui("Pencarian GPS dibatalkan.")
            ucapkanPanduan("Pencarian GPS dibatalkan.", "GPS search cancelled.")
        }
    }

    override fun onDestroy() {
        berhentiMencari()
        pembicaraPanduan?.matikan()
        pembicaraPanduan = null
        super.onDestroy()
    }

    /** Menggunakan mesin dan pengaturan suara profil Caller Name, termasuk Vocalizer bila dipilih di sana. */
    private fun ucapkanPanduan(indonesia: String, inggris: String, selesai: (() -> Unit)? = null) {
        val teks = if (prefs.jamBahasaIdx == 1) inggris else indonesia
        if (pembicaraPanduan == null) {
            pembicaraPanduan = Pembicara(this, prefs.suara("pem")) { }
        }
        pembicaraPanduan?.ucapkan(teks, true, selesai)
    }

    private fun mulai() {
        val tujuanTeks = tujuan.text?.toString()?.trim().orEmpty()
        if (tujuanTeks.isBlank()) {
            toast("Masukkan alamat atau nama tempat tujuan terlebih dahulu.")
            ucapkanPanduan("Masukkan alamat atau nama tempat tujuan terlebih dahulu.", "Please enter a destination address or place name first.")
            tujuan.requestFocus()
            return
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 871)
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        manager = lm
        val gpsAktif = try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (_: Exception) { false }
        if (!gpsAktif) {
            val pesan = "GPS satelit belum aktif. Aktifkan GPS atau layanan lokasi perangkat, lalu coba lagi."
            status.text = ui(pesan)
            ucapkanPanduan(pesan, "GPS is not enabled. Turn on GPS or device location services, then try again.")
            toast("GPS belum aktif. Buka setelan lokasi perangkat.")
            return
        }
        berhentiMencari()
        sedangMencari = true
        val pesanCari = "Sedang mencari posisi dari satelit GPS. Usahakan berada di luar ruangan dengan pandangan langit terbuka."
        status.text = ui(pesanCari)
        ucapkanPanduan(pesanCari, "Searching for a GPS satellite position. For best results, stay outdoors with a clear view of the sky.")
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!sedangMencari || location.accuracy <= 0f || location.accuracy > 150f) return
                berhentiMencari()
                val pesanSiap = "Posisi GPS diperoleh. Membuka navigasi berjalan kaki. Petunjuk belokan selanjutnya akan dibacakan oleh Google Maps."
                status.text = ui(pesanSiap)
                ucapkanPanduan(pesanSiap, "GPS position acquired. Opening walking navigation. Google Maps will provide the turn-by-turn voice guidance.") {
                    bukaNavigasi(location, tujuanTeks)
                }
            }
        }
        listener = l
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper())
            handler.postDelayed(timeout, 30_000L)
        } catch (_: SecurityException) {
            berhentiMencari()
            toast("Izin lokasi belum diberikan. Izinkan akses lokasi untuk Jam Pintar Pro.")
            ucapkanPanduan("Izin lokasi belum diberikan. Izinkan akses lokasi untuk Jam Pintar Pro.", "Location permission was not granted. Allow Jam Pintar Pro to access your location.")
        } catch (_: Exception) {
            berhentiMencari()
            toast("GPS tidak dapat dimulai pada perangkat ini.")
            ucapkanPanduan("GPS tidak dapat dimulai pada perangkat ini.", "GPS could not be started on this device.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 871) {
            if (grantResults.isNotEmpty() && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) mulai()
            else {
                toast("Izin lokasi diperlukan untuk memperoleh posisi GPS satelit.")
                ucapkanPanduan("Izin lokasi diperlukan untuk memperoleh posisi GPS satelit.", "Location permission is required to get a GPS satellite position.")
            }
        }
    }

    private fun bukaNavigasi(location: Location, destination: String) {
        val bahasa = if (BahasaAplikasi.tampilan(this) == 1) "en" else "id"
        val uri = Uri.parse("https://www.google.com/maps/dir/").buildUpon()
            .appendQueryParameter("api", "1")
            .appendQueryParameter("origin", "${location.latitude},${location.longitude}")
            .appendQueryParameter("destination", destination)
            .appendQueryParameter("travelmode", "walking")
            .appendQueryParameter("dir_action", "navigate")
            .appendQueryParameter("hl", bahasa)
            .build()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            toast("Aplikasi peta tidak dapat dibuka. Pastikan browser atau aplikasi peta tersedia.")
            ucapkanPanduan("Aplikasi peta tidak dapat dibuka. Pastikan browser atau aplikasi peta tersedia.", "The map app could not be opened. Make sure a browser or map app is available.")
        }
    }

    private fun berhentiMencari() {
        sedangMencari = false
        handler.removeCallbacks(timeout)
        val lm = manager
        val l = listener
        if (lm != null && l != null) try { lm.removeUpdates(l) } catch (_: Exception) { }
        listener = null
    }
}
