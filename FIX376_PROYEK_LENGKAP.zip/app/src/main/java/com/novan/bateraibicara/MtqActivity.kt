package com.novan.bateraibicara

import android.text.InputType

/**
 * FIX376: Latihan Musabaqah Tilawatil Qur'an (MTQ): pengenalan lagu/maqam, kriteria penilaian, cabang lomba, dan pemutaran
 * contoh bacaan mujawwad lewat perintah putar yang sudah ada. Isinya edukasi umum; aplikasi tidak menilai suara pengguna
 * dan tidak menandai maqam yang dipakai pada tiap rekaman.
 */
class MtqActivity : Halaman() {
    override val judulHalaman = R.string.judul_mtq
    private var surah = "Al Fatihah"
    private var ulang = "1"

    private class Maqam(val nama: String, val ciri: String)

    private fun daftarMaqam() = listOf(
        Maqam("Bayati", tr("Lagu dasar yang lembut dan tenang; biasa dipakai membuka bacaan.", "The basic, gentle and calm mode; commonly used to open a recitation.")),
        Maqam("Shoba", tr("Bernuansa haru dan syahdu; sering dipakai untuk ayat tentang kesedihan atau peringatan.", "Moving and tender in feeling; often used for verses of sorrow or warning.")),
        Maqam("Hijaz", tr("Bernuansa dramatis dan mendalam; sering dipakai pada bagian puncak bacaan.", "Dramatic and deep in feeling; often used at the climax of a recitation.")),
        Maqam("Nahawand", tr("Lembut dan mengalir, terasa teduh; cocok untuk ayat yang menenangkan.", "Soft and flowing, calming; suited to reassuring verses.")),
        Maqam("Rast", tr("Tegas, cerah, dan berwibawa; sering dipakai untuk ayat tentang kebesaran Allah.", "Firm, bright and dignified; often used for verses on God\'s greatness.")),
        Maqam("Jiharkah", tr("Ringan dan cerah; sering dipakai sebagai lagu penutup yang tenang.", "Light and bright; often used as a calm closing mode.")),
        Maqam("Sika", tr("Khusyuk dan lembut dengan nada yang khas; dipakai untuk variasi dan penutup.", "Devout and tender with a distinctive tone; used for variation and closing."))
    )

    override fun bangun() {
        info(tr("Latihan Musabaqah Tilawatil Qur\'an (MTQ). Aplikasi ini hanya memberi pengenalan dan contoh bacaan; aplikasi tidak menilai suara Anda. Cara terbaik berlatih adalah bersama guru atau pelatih MTQ.",
            "Qur\'an recitation competition (MTQ) practice. This app only gives an introduction and sample recitations; it does not score your voice. The best way to practise is with an MTQ teacher or coach."))
        bagian(tr("Contoh bacaan mujawwad", "Mujawwad sample recitations"))
        info(tr("Mujawwad adalah gaya bacaan yang lebih panjang dan berlagu, sering dijadikan contoh dalam latihan MTQ. Tentukan surah, lalu pilih qari. Aplikasi memutar rekamannya bila qari itu tersedia; pemutarannya memerlukan internet.",
            "Mujawwad is a slower, more melodic recitation style often used as a model in MTQ practice. Choose a surah, then a reciter. The app plays the recording if that reciter is available; playback needs the internet."))
        isian(tr("Surah (misalnya Al Fatihah)", "Surah (for example Al Fatihah)"), surah, InputType.TYPE_CLASS_TEXT) { surah = it }
        isian(tr("Jumlah pengulangan (1 sampai 20)", "Repeat count (1 to 20)"), ulang, InputType.TYPE_CLASS_NUMBER) { ulang = it }
        for ((nama, kata) in listOf("Abdul Basit Abdus Samad" to "Abdul Basit", "Mahmoud Khalil Al-Husary" to "Al Husary", "Mohamed Siddiq Al-Minshawi" to "Al Minshawi")) {
            tombol(tr("Putar mujawwad: ", "Play mujawwad: ") + nama) { putarMujawwad(kata) }
        }
        bagian(tr("Maqam atau lagu dalam MTQ", "Maqamat (tunes) in MTQ"))
        info(tr("Tujuh lagu yang lazim dipelajari dalam tilawah MTQ. Penjelasan ini bersifat umum dan dapat berbeda antar guru.",
            "Seven tunes commonly studied in MTQ tilawah. These notes are general and may differ between teachers."))
        for (m in daftarMaqam()) info(m.nama + ": " + m.ciri)
        bagian(tr("Kriteria penilaian yang lazim", "Common judging criteria"))
        info(tr("1. Tajwid dan makharijul huruf: ketepatan hukum bacaan dan pengucapan huruf. 2. Fashahah: kelancaran, ketepatan waqaf dan ibtida. 3. Suara: volume, kejernihan, napas, dan jangkauan nada. 4. Lagu: ketepatan maqam, variasi, dan perpindahan antar lagu. 5. Adab: sikap dan kekhusyukan. Bobot dan aturan berbeda menurut penyelenggara.",
            "1. Tajwid and articulation points: correct rules and letter pronunciation. 2. Fluency: smoothness and correct stops and starts. 3. Voice: volume, clarity, breath and range. 4. Tune: correct maqam, variation and transitions. 5. Manners: bearing and devotion. Weights and rules differ by organizer."))
        bagian(tr("Cabang lomba yang umum", "Common competition branches"))
        info(tr("Tilawah (anak-anak, remaja, dewasa), tahfizh (hafalan, dari 1 juz sampai 30 juz), tafsir, fahmil dan syarhil Qur\'an, khattil Qur\'an (kaligrafi), dan karya tulis ilmiah. Nama cabang dan golongan dapat berbeda antara penyelenggara.",
            "Tilawah (children, youth, adults), tahfizh (memorization, from 1 to 30 juz), tafsir, quiz and speech branches, calligraphy, and scientific writing. Branch and category names can differ between organizers."))
        bagian(tr("Tips latihan", "Practice tips"))
        info(tr("Mulailah dari tajwid dan makharij yang benar sebelum lagu. Dengarkan satu ayat berulang, tirukan pelan, lalu rekam diri sendiri dengan perekam di ponsel untuk dibandingkan. Perluas lagu satu per satu, dan jaga napas serta kesehatan suara.",
            "Start with correct tajwid and articulation before the tune. Listen to one verse repeatedly, imitate it slowly, then record yourself with your phone to compare. Add tunes one at a time and look after your breath and voice."))
    }

    private fun putarMujawwad(qari: String) {
        val n = (ulang.trim().toIntOrNull() ?: 1).coerceIn(1, 20)
        val perintah = "putar surah " + surah.trim().ifBlank { "Al Fatihah" } + " dengan qari " + qari + " mujawwad" + (if (n > 1) " " + n + " kali" else "") // contains(
        try { PemutarQuranService.kirim(this, PemutarQuranService.ACTION_PUTAR, listOf(perintah)) } catch (_: Exception) { toast(tr("Pemutar tidak dapat dimulai.", "The player could not start.")) }
        toast(tr("Memutar contoh bacaan.", "Playing the sample recitation."))
    }
}
