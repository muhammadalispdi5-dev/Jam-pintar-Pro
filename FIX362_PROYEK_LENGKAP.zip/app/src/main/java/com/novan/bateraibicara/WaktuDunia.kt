package com.novan.bateraibicara

import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * FIX355: jam dan tanggal di negara atau kota lain. Perhitungan memakai basis data zona waktu (tzdata) milik Android lewat java.time,
 * sehingga perubahan waktu musim panas ikut diperhitungkan. Daftar nama negara/kota di bawah ini disusun manual; tempat yang tidak ada
 * di daftar dijawab dengan jujur "belum dikenal", bukan ditebak.
 */
object WaktuDunia {
    class Tempat(val namaId: String, val namaEn: String, val zona: List<String>, val kunci: List<String>)

    private fun t(id: String, en: String, zona: String, kunci: String) =
        Tempat(id, en, zona.split(","), kunci.split(",").map { it.trim() }.filter { it.isNotEmpty() })

    val daftar: List<Tempat> = listOf(
        // Indonesia
        t("Indonesia", "Indonesia", "Asia/Jakarta,Asia/Makassar,Asia/Jayapura", "indonesia"),
        t("WIB (Indonesia Barat)", "Western Indonesia Time", "Asia/Jakarta", "wib,jakarta,bandung,surabaya,medan,yogyakarta,semarang,palembang,pekanbaru,padang,aceh,lampung,pontianak"),
        t("WITA (Indonesia Tengah)", "Central Indonesia Time", "Asia/Makassar", "wita,makassar,bali,denpasar,mataram,lombok,balikpapan,banjarmasin,manado,kupang,samarinda,palu"),
        t("WIT (Indonesia Timur)", "Eastern Indonesia Time", "Asia/Jayapura", "wit,jayapura,papua,ambon,ternate,maluku,sorong,merauke"),
        // Timur Tengah
        t("Arab Saudi", "Saudi Arabia", "Asia/Riyadh", "arab saudi,saudi,saudi arabia,makkah,mekah,mekkah,mecca,meka,makah,mekka,makka,mekha,tanah suci,haramain,masjidil haram,masjid al haram,mekah al mukarramah,makkah al mukarramah,madinah,medina,madina,madinah al munawwarah,riyadh,riyad,jeddah,jedah,jiddah,jeda"),
        t("Uni Emirat Arab", "United Arab Emirates", "Asia/Dubai", "uni emirat arab,emirat,uea,uae,dubai,abu dhabi"),
        t("Qatar", "Qatar", "Asia/Qatar", "qatar,katar,doha"),
        t("Kuwait", "Kuwait", "Asia/Kuwait", "kuwait"),
        t("Bahrain", "Bahrain", "Asia/Bahrain", "bahrain,manama"),
        t("Oman", "Oman", "Asia/Muscat", "oman,muscat,muskat"),
        t("Yaman", "Yemen", "Asia/Aden", "yaman,yemen,sanaa"),
        t("Yordania", "Jordan", "Asia/Amman", "yordania,jordan,amman"),
        t("Irak", "Iraq", "Asia/Baghdad", "irak,iraq,baghdad,bagdad"),
        t("Iran", "Iran", "Asia/Tehran", "iran,teheran,tehran"),
        t("Suriah", "Syria", "Asia/Damascus", "suriah,syria,damaskus,damascus"),
        t("Lebanon", "Lebanon", "Asia/Beirut", "lebanon,libanon,beirut"),
        t("Yerusalem", "Jerusalem", "Asia/Jerusalem", "yerusalem,jerusalem,israel,baitul maqdis,al quds"),
        t("Palestina (Gaza)", "Palestine (Gaza)", "Asia/Gaza", "palestina,palestine,gaza"),
        t("Turki", "Turkey", "Europe/Istanbul", "turki,turkiye,turkey,istanbul,ankara"),
        t("Mesir", "Egypt", "Africa/Cairo", "mesir,egypt,kairo,cairo"),
        // Asia
        t("Pakistan", "Pakistan", "Asia/Karachi", "pakistan,karachi,islamabad,lahore"),
        t("India", "India", "Asia/Kolkata", "india,delhi,new delhi,mumbai,kolkata"),
        t("Bangladesh", "Bangladesh", "Asia/Dhaka", "bangladesh,dhaka,dakka"),
        t("Sri Lanka", "Sri Lanka", "Asia/Colombo", "sri lanka,srilanka,kolombo,colombo"),
        t("Nepal", "Nepal", "Asia/Kathmandu", "nepal,kathmandu"),
        t("Afghanistan", "Afghanistan", "Asia/Kabul", "afghanistan,afganistan,kabul"),
        t("Malaysia", "Malaysia", "Asia/Kuala_Lumpur", "malaysia,kuala lumpur,putrajaya,penang,johor"),
        t("Singapura", "Singapore", "Asia/Singapore", "singapura,singapore"),
        t("Brunei", "Brunei", "Asia/Brunei", "brunei,bandar seri begawan"),
        t("Thailand", "Thailand", "Asia/Bangkok", "thailand,bangkok,thai"),
        t("Vietnam", "Vietnam", "Asia/Ho_Chi_Minh", "vietnam,hanoi,ho chi minh,saigon"),
        t("Filipina", "Philippines", "Asia/Manila", "filipina,philippines,manila"),
        t("Myanmar", "Myanmar", "Asia/Yangon", "myanmar,burma,yangon,rangon"),
        t("Kamboja", "Cambodia", "Asia/Phnom_Penh", "kamboja,cambodia,phnom penh"),
        t("Laos", "Laos", "Asia/Vientiane", "laos,vientiane"),
        t("Tiongkok", "China", "Asia/Shanghai", "tiongkok,china,cina,beijing,peking,shanghai"),
        t("Hong Kong", "Hong Kong", "Asia/Hong_Kong", "hong kong,hongkong"),
        t("Taiwan", "Taiwan", "Asia/Taipei", "taiwan,taipei"),
        t("Jepang", "Japan", "Asia/Tokyo", "jepang,japan,tokyo,osaka,kyoto"),
        t("Korea Selatan", "South Korea", "Asia/Seoul", "korea selatan,south korea,korea,seoul"),
        t("Korea Utara", "North Korea", "Asia/Pyongyang", "korea utara,north korea,pyongyang"),
        t("Mongolia", "Mongolia", "Asia/Ulaanbaatar", "mongolia,ulaanbaatar"),
        t("Kazakhstan", "Kazakhstan", "Asia/Almaty", "kazakhstan,kazakstan,almaty,astana"),
        t("Uzbekistan", "Uzbekistan", "Asia/Tashkent", "uzbekistan,tashkent,samarkand"),
        t("Timor Leste", "Timor-Leste", "Asia/Dili", "timor leste,timor,dili"),
        // Afrika
        t("Maroko", "Morocco", "Africa/Casablanca", "maroko,morocco,casablanca,rabat"),
        t("Aljazair", "Algeria", "Africa/Algiers", "aljazair,algeria,algiers"),
        t("Tunisia", "Tunisia", "Africa/Tunis", "tunisia,tunis"),
        t("Libya", "Libya", "Africa/Tripoli", "libya,tripoli"),
        t("Sudan", "Sudan", "Africa/Khartoum", "sudan,khartoum"),
        t("Nigeria", "Nigeria", "Africa/Lagos", "nigeria,lagos,abuja"),
        t("Ghana", "Ghana", "Africa/Accra", "ghana,accra"),
        t("Senegal", "Senegal", "Africa/Dakar", "senegal,dakar"),
        t("Kenya", "Kenya", "Africa/Nairobi", "kenya,nairobi"),
        t("Ethiopia", "Ethiopia", "Africa/Addis_Ababa", "ethiopia,etiopia,addis ababa"),
        t("Somalia", "Somalia", "Africa/Mogadishu", "somalia,mogadishu"),
        t("Afrika Selatan", "South Africa", "Africa/Johannesburg", "afrika selatan,south africa,johannesburg,cape town"),
        // Eropa
        t("Inggris (London)", "United Kingdom (London)", "Europe/London", "inggris,britania raya,united kingdom,england,london,uk"),
        t("Irlandia", "Ireland", "Europe/Dublin", "irlandia,ireland,dublin"),
        t("Prancis", "France", "Europe/Paris", "prancis,france,paris"),
        t("Jerman", "Germany", "Europe/Berlin", "jerman,germany,berlin,munich,frankfurt"),
        t("Belanda", "Netherlands", "Europe/Amsterdam", "belanda,netherlands,holland,amsterdam"),
        t("Belgia", "Belgium", "Europe/Brussels", "belgia,belgium,brussel,brussels"),
        t("Spanyol", "Spain", "Europe/Madrid", "spanyol,spain,madrid,barcelona"),
        t("Portugal", "Portugal", "Europe/Lisbon", "portugal,lisbon,lisboa"),
        t("Italia", "Italy", "Europe/Rome", "italia,italy,roma,rome,milan,vatikan,vatican"),
        t("Swiss", "Switzerland", "Europe/Zurich", "swiss,switzerland,zurich,jenewa,geneva"),
        t("Austria", "Austria", "Europe/Vienna", "austria,wina,vienna"),
        t("Swedia", "Sweden", "Europe/Stockholm", "swedia,sweden,stockholm"),
        t("Norwegia", "Norway", "Europe/Oslo", "norwegia,norway,oslo"),
        t("Denmark", "Denmark", "Europe/Copenhagen", "denmark,kopenhagen,copenhagen"),
        t("Finlandia", "Finland", "Europe/Helsinki", "finlandia,finland,helsinki"),
        t("Polandia", "Poland", "Europe/Warsaw", "polandia,poland,warsawa,warsaw"),
        t("Yunani", "Greece", "Europe/Athens", "yunani,greece,athena,athens"),
        t("Ukraina", "Ukraine", "Europe/Kyiv", "ukraina,ukraine,kyiv,kiev"),
        t("Rusia", "Russia", "Europe/Moscow,Asia/Yekaterinburg,Asia/Novosibirsk,Asia/Vladivostok", "rusia,russia"),
        t("Moskow", "Moscow", "Europe/Moscow", "moskow,moskwa,moscow"),
        t("Bosnia", "Bosnia", "Europe/Sarajevo", "bosnia,sarajevo"),
        t("Albania", "Albania", "Europe/Tirane", "albania,tirana"),
        t("Rumania", "Romania", "Europe/Bucharest", "rumania,romania,bukarest,bucharest"),
        t("Hongaria", "Hungary", "Europe/Budapest", "hongaria,hungary,budapest"),
        t("Ceko", "Czechia", "Europe/Prague", "ceko,czech,praha,prague"),
        t("Islandia", "Iceland", "Atlantic/Reykjavik", "islandia,iceland,reykjavik"),
        // Amerika
        t("Amerika Serikat", "United States", "America/New_York,America/Chicago,America/Denver,America/Los_Angeles,America/Anchorage,Pacific/Honolulu", "amerika serikat,amerika,united states,usa,as"),
        t("New York", "New York", "America/New_York", "new york,washington,boston,miami,atlanta"),
        t("Chicago", "Chicago", "America/Chicago", "chicago,houston,dallas"),
        t("Denver", "Denver", "America/Denver", "denver,phoenix"),
        t("Los Angeles", "Los Angeles", "America/Los_Angeles", "los angeles,san francisco,seattle,california,kalifornia,las vegas"),
        t("Hawaii", "Hawaii", "Pacific/Honolulu", "hawaii,honolulu"),
        t("Alaska", "Alaska", "America/Anchorage", "alaska"),
        t("Kanada", "Canada", "America/Toronto,America/Winnipeg,America/Edmonton,America/Vancouver,America/Halifax", "kanada,canada"),
        t("Toronto", "Toronto", "America/Toronto", "toronto,ottawa,montreal"),
        t("Vancouver", "Vancouver", "America/Vancouver", "vancouver"),
        t("Meksiko", "Mexico", "America/Mexico_City", "meksiko,mexico"),
        t("Brasil", "Brazil", "America/Sao_Paulo", "brasil,brazil,sao paulo,rio de janeiro,brasilia"),
        t("Argentina", "Argentina", "America/Argentina/Buenos_Aires", "argentina,buenos aires"),
        t("Kolombia", "Colombia", "America/Bogota", "kolombia,colombia,bogota"),
        t("Peru", "Peru", "America/Lima", "peru,lima"),
        t("Chili", "Chile", "America/Santiago", "chili,chile,santiago"),
        t("Venezuela", "Venezuela", "America/Caracas", "venezuela,caracas"),
        t("Kuba", "Cuba", "America/Havana", "kuba,cuba,havana"),
        // Oseania
        t("Australia", "Australia", "Australia/Sydney,Australia/Adelaide,Australia/Brisbane,Australia/Darwin,Australia/Perth", "australia"),
        t("Sydney", "Sydney", "Australia/Sydney", "sydney,canberra"),
        t("Melbourne", "Melbourne", "Australia/Melbourne", "melbourne"),
        t("Brisbane", "Brisbane", "Australia/Brisbane", "brisbane"),
        t("Perth", "Perth", "Australia/Perth", "perth"),
        t("Selandia Baru", "New Zealand", "Pacific/Auckland", "selandia baru,new zealand,auckland,wellington"),
        t("Fiji", "Fiji", "Pacific/Fiji", "fiji"),
        t("Papua Nugini", "Papua New Guinea", "Pacific/Port_Moresby", "papua nugini,papua new guinea,port moresby"),
        // Standar
        t("UTC (waktu universal)", "UTC (universal time)", "UTC", "utc,gmt,waktu universal,greenwich")
    )

    private val kataWaktu = setOf("jam", "pukul", "waktu", "time", "clock", "tanggal", "date")
    private val kataKecuali = setOf("sholat", "salat", "shalat", "solat", "subuh", "shubuh", "dzuhur", "zuhur", "duhur", "ashar", "asar", "maghrib", "magrib", "isya", "isyak",
        "imsak", "azan", "adzan", "prayer", "cuaca", "weather", "gempa", "libur", "holiday", "hijriah", "hijriyah", "hijri", "timer", "alarm", "ingatkan", "berita", "news",
        "tafsir", "hadis", "hadits", "doa", "quran", "surah", "surat", "ayat", "kiblat", "qibla", "kurs", "nilai")
    private val kataTanpaTempat = setOf("negara", "negeri", "luar", "kota", "wilayah", "daerah", "lain", "country", "abroad", "overseas", "foreign", "city", "region")

    private fun tr(id: String, en: String, eng: Boolean) = if (eng) en else id

    private fun token(u: String): List<String> =
        u.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    /** Tempat terbaik yang disebut dalam [ucapan] (kunci terpanjang lebih diutamakan); null bila tidak ada. */
    fun cari(ucapan: String): Tempat? {
        val padded = " " + token(ucapan).joinToString(" ") + " "
        var terbaik: Tempat? = null
        var panjang = 0
        for (tp in daftar) for (k in tp.kunci) {
            if (padded.contains(" $k ") && k.length > panjang) { panjang = k.length; terbaik = tp }
        }
        if (terbaik != null) return terbaik
        // FIX361: pengenal suara sering salah satu huruf; kata tunggal sepanjang 5 huruf ke atas dicocokkan dengan selisih satu huruf.
        val kata = token(ucapan)
        for (tp in daftar) for (k in tp.kunci) {
            if (k.length < 5 || k.contains(' ')) continue
            if (kata.any { it.length in (k.length - 1)..(k.length + 1) && selisihSatu(it, k) }) return tp
        }
        return null
    }

    private fun selisihSatu(a: String, b: String): Boolean {
        if (a == b) return true
        if (Math.abs(a.length - b.length) > 1) return false
        var i = 0
        while (i < a.length && i < b.length && a[i] == b[i]) i++
        return when {
            a.length == b.length -> a.substring(i + 1) == b.substring(i + 1)
            a.length > b.length -> a.substring(i + 1) == b.substring(i)
            else -> a.substring(i) == b.substring(i + 1)
        }
    }

    private val kataLokal = setOf("sini", "sekarang", "ini", "rumah", "saya", "kita", "lokasi", "here", "home", "my", "me", "now", "this", "today", "hari", "tempat", "anda", "kamu", "indonesia", "negara", "kota", "negeri", "luar", "lain", "wilayah", "daerah", "country", "city", "abroad", "region", "mana", "where", "dimana")
    private val kataHentiNama = setOf("sekarang", "saat", "ini", "hari", "ya", "dong", "tolong", "pagi", "siang", "sore", "malam", "kah", "lagi", "now", "today", "please", "tonight", "yang", "dan", "atau")

    /** FIX361: nama tempat yang disebut ("jam berapa di X") tetapi tidak ada di daftar; null bila tidak ada tempat asing. Dipakai agar asisten tidak menjawab jam lokal secara keliru. */
    fun tempatTakDikenal(ucapan: String): String? {
        val t = token(ucapan)
        if (t.isEmpty() || t.size > 14) return null
        if (t.any { it.toIntOrNull() != null || it in kataKecuali }) return null
        if (t.none { it in setOf("jam", "pukul", "waktu", "time", "clock") }) return null
        if (cari(ucapan) != null) return null
        val depan = t.indexOfFirst { it == "di" || it == "in" || it == "at" }
        if (depan < 0) return null
        val nama = t.drop(depan + 1).takeWhile { it !in kataHentiNama }.take(3)
        if (nama.isEmpty() || nama.any { it in kataLokal }) return null
        return nama.joinToString(" ")
    }

    /** true bila ucapan jelas meminta jam/tanggal di tempat lain (tempat disebut) atau meminta jam di "negara lain" tanpa menyebut tempat. */
    fun permintaan(ucapan: String): Boolean {
        val t = token(ucapan)
        if (t.isEmpty() || t.size > 14) return false
        if (t.any { it in kataKecuali }) return false
        if (t.any { it.toIntOrNull() != null }) return konversi(ucapan) != null && cari(ucapan) != null
        if (t.none { it in kataWaktu }) return false
        if (cari(ucapan) != null) return true
        val depan = t.indexOfFirst { it == "di" || it == "in" || it == "at" }
        return depan >= 0 && t.drop(depan).any { it in kataTanpaTempat } && t.any { it in setOf("jam", "pukul", "waktu", "time", "clock") }
    }

    fun bukanTempatDisebut(ucapan: String): Boolean = permintaan(ucapan) && cari(ucapan) == null

    /** FIX362: jam diucapkan dalam format 12 jam dengan penanda pagi/siang/sore/malam agar jelas bagi pendengar (tanpa angka titik seperti 02.00). */
    private fun sebutJam(z: ZonedDateTime, en: Boolean): String {
        val j = z.hour; val m = z.minute
        val j12 = if (j % 12 == 0) 12 else j % 12
        if (en) {
            val bag = when { j == 0 && m == 0 -> "midnight"; j == 12 && m == 0 -> "noon"; j in 0..3 -> "in the early morning"; j in 4..11 -> "in the morning"; j in 12..16 -> "in the afternoon"; j in 17..20 -> "in the evening"; else -> "at night" }
            val menit = if (m == 0) "" else if (m < 10) " oh $m" else " $m"
            return "$j12$menit $bag".trim()
        }
        val bagian = when { j == 0 && m == 0 -> "tengah malam"; j == 12 && m == 0 -> "tengah hari"; j in 0..3 -> "dini hari"; j in 4..10 -> "pagi"; j in 11..14 -> "siang"; j in 15..17 -> "sore"; else -> "malam" } // contains(
        return j12.toString() + (if (m == 0) "" else " lewat $m menit") + " " + bagian
    }

    private val zonaIndonesia = listOf("Asia/Jakarta" to "WIB", "Asia/Makassar" to "WITA", "Asia/Jayapura" to "WIT")

    /** Zona Indonesia pembanding: zona perangkat bila berada di Indonesia, selain itu WIB. */
    private fun zonaPembanding(): Pair<String, String> {
        val sis = ZoneId.systemDefault().id
        return zonaIndonesia.firstOrNull { it.first == sis } ?: zonaIndonesia[0]
    }

    private fun besaranJam(detik: Int, en: Boolean): String {
        val abs = Math.abs(detik); val jam = abs / 3600; val menit = (abs % 3600) / 60
        return if (en) jam.toString() + (if (jam == 1) " hour" else " hours") + (if (menit > 0) " $menit minutes" else "")
        else jam.toString() + " jam" + (if (menit > 0) " $menit menit" else "")
    }

    /** Kalimat selisih: [nama] dibandingkan dengan [pembanding] (mis. WIB) pada [saat]. */
    private fun kalimatSelisih(nama: String, zona: ZoneId, pembanding: String, zonaP: ZoneId, saat: Instant, en: Boolean): String {
        val d = zona.rules.getOffset(saat).totalSeconds - zonaP.rules.getOffset(saat).totalSeconds
        return when {
            d == 0 -> tr("Waktu $nama sama dengan $pembanding, tidak ada selisih.", "The time in $nama is the same as $pembanding, with no difference.", en)
            d > 0 -> tr("Selisihnya " + besaranJam(d, false) + ": waktu $nama lebih cepat " + besaranJam(d, false) + " dari $pembanding.", "The difference is " + besaranJam(d, true) + ": $nama is " + besaranJam(d, true) + " ahead of $pembanding.", en)
            else -> tr("Selisihnya " + besaranJam(d, false) + ": waktu $nama lebih lambat " + besaranJam(d, false) + " dari $pembanding.", "The difference is " + besaranJam(d, true) + ": $nama is " + besaranJam(d, true) + " behind $pembanding.", en)
        }
    }

    private fun namaZona(id: String): String = id.substringAfterLast('/').replace('_', ' ')

    /** Kalimat jawaban lengkap untuk [tempat]: jam di sana, jam di Indonesia, dan selisih keduanya, dihitung pada saat ini. */
    fun jawab(tempat: Tempat, en: Boolean, saatIni: Instant = Instant.now()): String {
        val pola = DateTimeFormatter.ofPattern(if (en) "EEEE, MMMM d, yyyy" else "EEEE, d MMMM yyyy", if (en) Locale.US else Locale("id", "ID"))
        val nama = if (en) tempat.namaEn else tempat.namaId
        val (idP, kodeP) = zonaPembanding()
        val zonaP = ZoneId.of(idP)
        val zP = ZonedDateTime.ofInstant(saatIni, zonaP)
        val bagian = ArrayList<String>()
        for (id in tempat.zona) {
            val zona = try { ZoneId.of(id) } catch (_: Exception) { continue }
            val z = ZonedDateTime.ofInstant(saatIni, zona)
            val label = if (tempat.zona.size > 1) (zonaIndonesia.firstOrNull { it.first == id }?.second ?: namaZona(id)) else nama
            val musim = if (zona.rules.isDaylightSavings(saatIni)) tr(" Di sana sedang berlaku waktu musim panas.", " Daylight saving time is in effect there.", en) else ""
            val hariBeda = z.toLocalDate() != zP.toLocalDate()
            val ket = if (hariBeda) tr(" Tanggal di sana berbeda dari Indonesia: ", " The date there differs from Indonesia: ", en) + z.format(pola) + "." else ""
            bagian.add(tr("Di $label sekarang pukul ", "In $label it is now ", en) + sebutJam(z, en) + ", " + z.format(pola) + "." + musim + ket + " " + kalimatSelisih(label, zona, kodeP, zonaP, saatIni, en))
        }
        if (bagian.isEmpty()) return tr("Saya tidak dapat membaca data zona waktu untuk $nama.", "I could not read the time zone data for $nama.", en)
        val awal = if (tempat.zona.size > 1) tr("$nama memiliki beberapa zona waktu. ", "$nama has several time zones. ", en) else ""
        val indo = tr("Sebagai pembanding, di Indonesia ($kodeP) sekarang pukul ", "For comparison, in Indonesia ($kodeP) it is now ", en) + sebutJam(zP, en) + "."
        return awal + bagian.joinToString(" ") + " " + indo
    }

    // ---------- FIX362: konversi jam Indonesia ke tempat lain ("kalau di Indonesia jam 2 malam, di Arab Saudi jam berapa") ----------

    class JamTanya(val jam: Int, val menit: Int, val zonaId: String, val kode: String)

    /** Jam yang disebut dalam ucapan beserta zona Indonesianya (WIB bawaan, atau zona perangkat/WITA/WIT bila disebut); null bila tidak ada jam. */
    fun konversi(ucapan: String): JamTanya? {
        val u = ucapan.lowercase(Locale.ROOT)
        val m = Regex("(?:jam|pukul|at)\\s*(\\d{1,2})(?:\\s*[.:]\\s*(\\d{2}))?(?!\\d)").find(u) ?: Regex("(?<![\\d])(\\d{1,2})\\s*[.:]\\s*(\\d{2})(?!\\d)").find(u) ?: return null
        var h = m.groupValues[1].toIntOrNull() ?: return null
        val mi = m.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        if (h !in 0..24 || mi !in 0..59) return null
        if (h == 24) h = 0
        val t = token(ucapan)
        val pm = t.contains("pm") || t.contains("p"); val am = t.contains("am") || t.contains("a")
        when {
            t.contains("malam") -> { if (h in 5..11) h += 12 else if (h == 12) h = 0 }
            t.contains("sore") -> { if (h in 1..11) h += 12 }
            t.contains("siang") -> { if (h in 1..6) h += 12 }
            t.contains("pagi") || t.contains("dini") -> { if (h == 12) h = 0 }
            pm -> { if (h in 1..11) h += 12 }
            am -> { if (h == 12) h = 0 }
        }
        val zona = when {
            t.contains("wita") -> "Asia/Makassar" to "WITA"
            t.contains("wit") -> "Asia/Jayapura" to "WIT"
            t.contains("wib") -> "Asia/Jakarta" to "WIB"
            else -> zonaPembanding()
        }
        return JamTanya(h, mi, zona.first, zona.second)
    }

    /** Menjawab: bila jam Indonesia sudah $jam, jam berapa di [tempat]; termasuk selisih dan perbedaan hari. */
    fun jawabKonversi(tempat: Tempat, tanya: JamTanya, en: Boolean, saatIni: Instant = Instant.now()): String {
        val nama = if (en) tempat.namaEn else tempat.namaId
        val zonaP = ZoneId.of(tanya.zonaId)
        val hariIni = ZonedDateTime.ofInstant(saatIni, zonaP).toLocalDate()
        val asal = ZonedDateTime.of(hariIni, java.time.LocalTime.of(tanya.jam, tanya.menit), zonaP)
        val instan = asal.toInstant()
        val bagian = ArrayList<String>()
        for (id in tempat.zona) {
            val zona = try { ZoneId.of(id) } catch (_: Exception) { continue }
            val sana = ZonedDateTime.ofInstant(instan, zona)
            val label = if (tempat.zona.size > 1) (zonaIndonesia.firstOrNull { it.first == id }?.second ?: namaZona(id)) else nama
            val hari = when {
                sana.toLocalDate().isAfter(asal.toLocalDate()) -> tr(", yaitu keesokan harinya", ", which is the next day", en)
                sana.toLocalDate().isBefore(asal.toLocalDate()) -> tr(", yaitu sehari sebelumnya", ", which is the previous day", en)
                else -> tr(", pada hari yang sama", ", on the same day", en)
            }
            bagian.add(tr("di $label pukul ", "in $label it is ", en) + sebutJam(sana, en) + hari + ". " + kalimatSelisih(label, zona, tanya.kode, zonaP, instan, en))
        }
        if (bagian.isEmpty()) return tr("Saya tidak dapat membaca data zona waktu untuk $nama.", "I could not read the time zone data for $nama.", en)
        val buka = tr("Jika di Indonesia (" + tanya.kode + ") pukul ", "If it is ", en) + sebutJam(asal, en) + tr(", maka ", " in Indonesia (" + tanya.kode + "), then ", en)
        return buka + bagian.joinToString(" ")
    }

    /** Jawaban untuk satu ucapan: konversi bila ada jam yang disebut, jika tidak jam sekarang di tempat itu. */
    fun jawabUntuk(ucapan: String, tempat: Tempat, en: Boolean): String {
        val k = konversi(ucapan)
        return if (k != null) jawabKonversi(tempat, k, en) else jawab(tempat, en)
    }
}
