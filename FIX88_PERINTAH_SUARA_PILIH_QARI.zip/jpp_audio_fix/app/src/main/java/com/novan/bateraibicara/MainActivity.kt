package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Beranda aksesibel: identitas visual, sakelar utama, pintasan fitur, dan bantuan latar belakang. */
class MainActivity : Halaman() {

    override val judulHalaman = R.string.judul

    private lateinit var saklarAktif: Switch
    private lateinit var teksStatus: TextView
    private lateinit var saklarBeritahuSaya: Switch
    private var sinkron = false
    private var sinkronPemicu = false
    private val kartu = ArrayList<Pair<Button, () -> String>>()

    // Rekaman pengantar awal: diputar utuh lebih dulu pada penggunaan pertama, baru petunjuk tampil.
    private var pemutarPengantar: MediaPlayer? = null
    private var ulangPengantar = false
    private var dialogPanduanTampil = false

    // Pembaruan aplikasi (unduh dan pasang tanpa Play Store).
    private val handlerUpdate = android.os.Handler(android.os.Looper.getMainLooper())
    private var dialogUnduh: AlertDialog? = null
    private var tawaranPasangTampil = false

    private val kodeCadangkan = 4101
    private val kodePulihkan = 4102

    /** FIX85: pintasan dinamis (selain yang statis) agar menu ketuk tahan ikon Beritahu Saya memuat "Perintah suara" di semua peluncur; label mengikuti bahasa aktif. */
    private fun daftarkanPintasanPerintahSuara() {
        if (Build.VERSION.SDK_INT < 25) return
        try {
            val sm = getSystemService(android.content.pm.ShortcutManager::class.java) ?: return
            val info = android.content.pm.ShortcutInfo.Builder(this, "perintah_suara_dinamis")
                .setShortLabel(getString(R.string.shortcut_perintah_suara_pendek))
                .setLongLabel(getString(R.string.shortcut_perintah_suara_panjang))
                .setIcon(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_launcher))
                .setIntent(Intent(this, PerintahSuaraActivity::class.java).setAction(Intent.ACTION_VIEW))
                .setActivity(ComponentName(this, BeritahuSayaActivity::class.java))
                .build()
            sm.setDynamicShortcuts(listOf(info))
        } catch (_: Exception) { }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        daftarkanPintasanPerintahSuara()
        val panduanPrefs = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (!panduanPrefs.getBoolean("panduan_awal_ditampilkan", false)) {
            if (panduanPrefs.getBoolean("pengantar_awal_selesai", false)) {
                // Rekaman sudah pernah diputar utuh (mis. layar diputar sebelum petunjuk ditutup).
                tampilkanPanduan(panduanPertama = true)
            } else {
                mulaiPengantarAwal()
            }
        } else {
            mintaIzinNotifikasiJikaPerlu()
            tampilkanPengingatIzinMerek()
            // Pemeriksaan/pengunduhan pembaruan diarahkan ke kanal Telegram resmi.
            // Kanal publik biasa tidak menyediakan endpoint versi terstruktur yang stabil.
        }
    }

    override fun onStart() {
        super.onStart()
        // Rekaman dihentikan saat aplikasi ke latar belakang; ulangi dari awal agar didengar utuh.
        if (ulangPengantar) {
            ulangPengantar = false
            mulaiPengantarAwal()
        }
    }

    override fun onStop() {
        super.onStop()
        if (pemutarPengantar != null) {
            bersihkanPemutarPengantar()
            ulangPengantar = true
        }
    }

    override fun onDestroy() {
        bersihkanPemutarPengantar()
        handlerUpdate.removeCallbacksAndMessages(null)
        try { dialogUnduh?.dismiss() } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun bersihkanPemutarPengantar() {
        val p = pemutarPengantar ?: return
        pemutarPengantar = null
        try { p.setOnCompletionListener(null) } catch (_: Exception) { }
        try { p.setOnErrorListener(null) } catch (_: Exception) { }
        try { if (p.isPlaying) p.stop() } catch (_: Exception) { }
        try { p.release() } catch (_: Exception) { }
    }

    /** Memutar rekaman pengantar awal; setelah selesai utuh barulah informasi pengembang dan petunjuk tampil. */
    private fun mulaiPengantarAwal() {
        if (pemutarPengantar != null || dialogPanduanTampil) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            val player = MediaPlayer()
            pemutarPengantar = player
            try {
                // Atribut dipasang sebelum sumber data dan prepare agar benar-benar dipakai sistem.
                player.setAudioAttributes(attrs)
                val afd = resources.openRawResourceFd(R.raw.pengantar_awal_aplikasi_jam_pintar_pro)
                try { player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                player.setOnCompletionListener { selesaiPengantarAwal() }
                player.setOnErrorListener { _, _, _ -> selesaiPengantarAwal(); true }
                player.prepare()
                player.start()
            } catch (e: Exception) {
                selesaiPengantarAwal()
            }
        } catch (e: Exception) {
            selesaiPengantarAwal()
        }
    }

    private fun selesaiPengantarAwal() {
        bersihkanPemutarPengantar()
        getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
            .putBoolean("pengantar_awal_selesai", true).apply()
        if (isFinishing || isDestroyed) return
        tampilkanPanduan(panduanPertama = true)
    }

    override fun bangun() {
        // Sapaan utama sesuai permintaan: salam Arab, bukan sapaan berdasarkan waktu.
        val salam = info("السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ")
        salam.textSize = 24f
        salam.gravity = Gravity.CENTER
        salam.setTypeface(salam.typeface, Typeface.BOLD)
        salam.setTextColor(warnaAksen())
        salam.contentDescription = "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ"
        salam.setPadding(dp(16), dp(18), dp(16), dp(18))
        salam.background = GradientDrawable().apply {
            setColor(if (modeGelap()) Color.rgb(28, 57, 50) else Color.rgb(230, 239, 230))
            setStroke(dp(1), Color.rgb(214, 181, 109))
            cornerRadius = dp(18).toFloat()
        }
        salam.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8); bottomMargin = dp(8) }
        val slogan = info(getString(R.string.slogan_aksesibilitas))
        slogan.textSize = 18f
        slogan.gravity = Gravity.CENTER
        slogan.setPadding(dp(16), dp(12), dp(16), dp(12))
        slogan.background = GradientDrawable().apply {
            setColor(if (modeGelap()) Color.rgb(31, 39, 37) else Color.rgb(247, 244, 234))
            setStroke(dp(1), Color.rgb(214, 181, 109))
            cornerRadius = dp(16).toFloat()
        }
        slogan.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(2); bottomMargin = dp(12) }
        tombol(getString(R.string.pengaturan_bahasa)) { startActivity(Intent(this, BahasaActivity::class.java)) }

        saklarAktif = saklar(getString(R.string.aktifkan), prefs.enabled) { on ->
            if (!sinkron) {
                prefs.enabled = on
                if (on) BatteryTalkService.start(this) else BatteryTalkService.stop(this)
            }
        }

        teksStatus = info("")
        teksStatus.textSize = 16f

        bagian(getString(R.string.bagian_pemicu_beritahu_saya))
        saklarBeritahuSaya = saklar(getString(R.string.sw_beritahu_saya), prefs.beritahuSayaOn) { aktif ->
            if (!sinkronPemicu) {
                prefs.beritahuSayaOn = aktif
                BeritahuSayaWidgetProvider.perbaruiSemua(this)
                toast(if (aktif) R.string.beritahu_saya_diaktifkan else R.string.beritahu_saya_dimatikan)
            }
        }
        // FIX84: ketuk tahan pada pemicu Beritahu Saya membuka perintah suara.
        saklarBeritahuSaya.setOnLongClickListener {
            startActivity(Intent(this, PerintahSuaraActivity::class.java).putExtra(PerintahSuaraActivity.EXTRA_DARI_APLIKASI, true))
            true
        }
        info(getString(R.string.info_beritahu_saya))
        // FIX86: Android tidak memungkinkan aplikasi mendeteksi ketuk tahan pada tombol widget (dikuasai peluncur HP),
        // maka satu tombol Beritahu Saya dapat diatur agar sekali ketuk langsung membuka perintah suara.
        saklar(getString(R.string.sw_beritahu_saya_langsung_suara), prefs.beritahuSayaLangsungSuara) { aktif ->
            prefs.beritahuSayaLangsungSuara = aktif
            BeritahuSayaWidgetProvider.perbaruiSemua(this)
            toast(if (aktif) R.string.beritahu_saya_langsung_suara_on else R.string.beritahu_saya_langsung_suara_off)
        }
        info(getString(R.string.info_beritahu_saya_langsung_suara))

        bagian(getString(R.string.bagian_kategori))
        kartuKategori(R.string.kategori_baterai, BateraiActivity::class.java) { prefs.bateraiOn }
        kartuKategori(R.string.kategori_jam, JamActivity::class.java) { prefs.jamOn }
        kartuKategori(R.string.kategori_kalender, KalenderActivity::class.java) {
            prefs.kalenderMasehiOn || prefs.kalenderHijriOn || prefs.kalenderPasaranOn ||
                prefs.liburNasionalLampau || prefs.liburNasionalTerkini || prefs.liburNasionalMendatang ||
                prefs.cutiBersamaLampau || prefs.cutiBersamaTerkini || prefs.cutiBersamaMendatang
        }
        kartuKategori(R.string.kategori_pemanggil, PemanggilActivity::class.java) { prefs.pemOn }
        kartuKategori(R.string.kategori_sholat, PrayerActivity::class.java) { PrayerPrefs(this).enabled }
        tombol(getString(R.string.judul_lokasi_terkini)) { startActivity(Intent(this, LokasiTerkiniActivity::class.java)) }
        tombol(getString(R.string.judul_pemandu_jalan)) { startActivity(Intent(this, PemanduJalanActivity::class.java)) }
        // Akses langsung ke arah kiblat dari beranda agar mudah ditemukan pengguna TalkBack.
        tombol(getString(R.string.kategori_kiblat)) { startActivity(Intent(this, QiblaActivity::class.java)) }
        tombol(getString(R.string.kategori_fasilitas_terdekat)) { startActivity(Intent(this, FasilitasTerdekatActivity::class.java)) }
        tombol(getString(R.string.menu_taaruf_doa)) { startActivity(Intent(this, TaarufDoaActivity::class.java)) }
        tombol(getString(R.string.khatam_menu)) { startActivity(Intent(this, KhatamActivity::class.java)) }
        tombol(getString(R.string.judul_mode_acara)) { startActivity(Intent(this, ModeAcaraActivity::class.java)) }
        tombol(getString(R.string.tombol_petunjuk_penggunaan)) { tampilkanPanduan(panduanPertama = false) }

        bagian(getString(R.string.bagian_cadangan))
        info(getString(R.string.info_cadangan))
        tombol(getString(R.string.tombol_cadangkan)) { mulaiCadangkan() }
        tombol(getString(R.string.tombol_pulihkan)) { mulaiPulihkan() }
        tombol(getString(R.string.tombol_reset)) { konfirmasiReset() }

        saklar(getString(R.string.sw_boot), prefs.bootOn) { prefs.bootOn = it }

        bagian(getString(R.string.bagian_latar))
        info(getString(R.string.teks_latar))
        tombol(getString(R.string.tombol_izin_perangkat)) {
            startActivity(Intent(this, IzinPerangkatActivity::class.java))
        }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

        bagian(getString(R.string.bagian_bantuan))
        info(getString(R.string.info_versi_app, UpdateManager.namaVersi(this)))
        info(getString(R.string.info_update_telegram))
        tombol(getString(R.string.tombol_periksa_update)) { bukaKanalPembaruanTelegram() }
        tombol(getString(R.string.tombol_hubungi_pengembang)) { startActivity(Intent(this, KeluhanActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        CallerListener.sambungkanUlang(this)
        if (saklarAktif.isChecked != prefs.enabled) {
            sinkron = true
            saklarAktif.isChecked = prefs.enabled
            sinkron = false
        }
        // Pastikan layanan tetap berjalan bila saklar utama aktif.
        if (prefs.enabled) {
            try { BatteryTalkService.start(this) } catch (e: Exception) { }
        }
        perbaruiStatus()
        tawarkanPasangJikaSiap()
        if (saklarBeritahuSaya.isChecked != prefs.beritahuSayaOn) {
            sinkronPemicu = true
            saklarBeritahuSaya.isChecked = prefs.beritahuSayaOn
            sinkronPemicu = false
        }
        for ((b, teks) in kartu) b.text = ui(teks())
    }

    private fun kartuKategori(judul: Int, tujuan: Class<*>, aktif: () -> Boolean) {
        val nama = getString(judul)
        val b = tombol(nama) { startActivity(Intent(this, tujuan)) }
        b.minimumHeight = dp(72)
        kartu.add(b to {
            nama + "\n" + getString(if (aktif()) R.string.status_aktif else R.string.status_mati)
        })
    }

    private fun tampilkanPanduan(panduanPertama: Boolean) {
        if (panduanPertama) {
            if (dialogPanduanTampil) return
            dialogPanduanTampil = true
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(ui(getString(R.string.judul_petunjuk_penggunaan)))
            .setMessage(ui(getString(R.string.isi_petunjuk_penggunaan)))
            .setPositiveButton(getString(R.string.tombol_mengerti)) { d, _ ->
                d.dismiss()
                if (panduanPertama) {
                    getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
                        .putBoolean("panduan_awal_ditampilkan", true).apply()
                    mintaIzinNotifikasiJikaPerlu()
                }
            }
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    // ---------- Cadangkan dan pulihkan pengaturan (pemilih berkas bawaan Android; tanpa izin penyimpanan) ----------

    private fun mulaiCadangkan() {
        val nama = "JamPintarPro_cadangan_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".json"
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, nama)
        }
        try { startActivityForResult(i, kodeCadangkan) } catch (e: Exception) { toast(R.string.cadangan_tidak_didukung) }
    }

    private fun mulaiPulihkan() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try { startActivityForResult(i, kodePulihkan) } catch (e: Exception) { toast(R.string.cadangan_tidak_didukung) }
    }

    @Deprecated("Memakai pemilih berkas bawaan sistem")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            kodeCadangkan -> simpanCadangan(uri)
            kodePulihkan -> konfirmasiPulihkan(uri)
        }
    }

    private fun simpanCadangan(uri: Uri) {
        try {
            val teks = CadanganPengaturan.buatJson(this)
            val keluar = contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("tidak bisa menulis")
            keluar.use { it.write(teks.toByteArray(Charsets.UTF_8)) }
            toast(R.string.cadangan_berhasil)
        } catch (e: Exception) {
            toast(R.string.cadangan_gagal)
        }
    }

    private fun konfirmasiPulihkan(uri: Uri) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pulihkan_konfirmasi_judul))
            .setMessage(getString(R.string.pulihkan_konfirmasi_isi))
            .setPositiveButton(getString(R.string.pulihkan_ya)) { d, _ ->
                d.dismiss()
                terapkanPulihan(uri)
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun konfirmasiReset() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.reset_konfirmasi_judul))
            .setMessage(getString(R.string.reset_konfirmasi_isi))
            .setPositiveButton(getString(R.string.reset_ya)) { d, _ ->
                d.dismiss()
                CadanganPengaturan.aturUlangSemua(this)
                toast(R.string.reset_berhasil)
                // Bangun ulang beranda agar semua sakelar dan status kembali ke tampilan awal.
                recreate()
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun terapkanPulihan(uri: Uri) {
        val teks = CadanganPengaturan.bacaTeks(this, uri)
        if (teks == null) {
            toast(R.string.pulihkan_gagal_baca)
            return
        }
        val jumlah = CadanganPengaturan.pulihkan(this, teks)
        if (jumlah < 0) {
            toast(R.string.pulihkan_gagal_format)
            return
        }
        CadanganPengaturan.segarkan(this)
        toast(R.string.pulihkan_berhasil)
        // Bangun ulang beranda agar semua sakelar dan status menampilkan pengaturan hasil pemulihan.
        recreate()
    }

    private fun mintaIzinNotifikasiJikaPerlu() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun perbaruiStatus() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        val persen = if (level < 0) 0 else level * 100 / skala
        val mengisi = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        teksStatus.text = ui(getString(R.string.status_format, persen, status))
    }

    /** Pengingat sekali saja untuk HP selain Samsung agar pengguna membuka layar izin khusus merek. */
    private fun tampilkanPengingatIzinMerek() {
        val pref = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (pref.getBoolean("pengingat_izin_perangkat_tampil", false) || PerangkatIzin.samsung()) return
        // Tunggu dialog izin notifikasi sistem selesai (Android 13 ke atas) agar dua dialog tidak bertumpuk.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        pref.edit().putBoolean("pengingat_izin_perangkat_tampil", true).apply()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pengingat_izin_judul))
            .setMessage(getString(R.string.pengingat_izin_isi, PerangkatIzin.namaPerangkat()))
            .setPositiveButton(getString(R.string.pengingat_buka)) { d, _ ->
                d.dismiss()
                startActivity(Intent(this, IzinPerangkatActivity::class.java))
            }
            .setNegativeButton(getString(R.string.pengingat_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    // ---------- Pembaruan aplikasi ----------

    /** Membuka kanal publik resmi tempat pengembang menerbitkan informasi dan APK terbaru. */
    private fun bukaKanalPembaruanTelegram() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_telegram_judul))
            .setMessage(getString(R.string.update_telegram_isi))
            .setPositiveButton(getString(R.string.update_telegram_buka)) { d, _ ->
                d.dismiss()
                val url = "https://t.me/JamPintarPro"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                try {
                    // Android akan memilih Telegram jika tersedia, atau browser yang menangani tautan HTTPS.
                    startActivity(intent)
                } catch (_: Exception) {
                    toast(R.string.update_telegram_gagal_buka)
                }
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun tampilkanPembaruan(info: UpdateManager.Info) {
        val catatan = if (info.catatan.isBlank()) "" else info.catatan
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_tersedia_judul))
            .setMessage(getString(R.string.update_tersedia_isi, info.versionName, UpdateManager.namaVersi(this), catatan).trim())
            .setPositiveButton(getString(R.string.update_tombol_unduh)) { d, _ ->
                d.dismiss()
                mulaiUnduh(info)
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun mulaiUnduh(info: UpdateManager.Info) {
        val id = try { UpdateManager.unduh(this, info) } catch (e: Exception) { -1L }
        if (id < 0) {
            toast(R.string.update_gagal_unduh)
            return
        }
        dialogUnduh = AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_mengunduh_judul))
            .setMessage(getString(R.string.update_mengunduh, 0))
            .setCancelable(false)
            .setNegativeButton(getString(R.string.update_batal)) { d, _ ->
                handlerUpdate.removeCallbacksAndMessages(null)
                UpdateManager.batalkan(this, id)
                d.dismiss()
            }
            .create()
        dialogUnduh?.show()
        pantauUnduh(id)
    }

    private fun pantauUnduh(id: Long) {
        if (isFinishing || isDestroyed) return
        val h = UpdateManager.progres(this, id)
        when (h[0]) {
            android.app.DownloadManager.STATUS_SUCCESSFUL -> {
                dialogUnduh?.dismiss()
                pasangPembaruan()
            }
            android.app.DownloadManager.STATUS_FAILED, -1 -> {
                dialogUnduh?.dismiss()
                toast(R.string.update_gagal_unduh)
            }
            else -> {
                dialogUnduh?.setMessage(getString(R.string.update_mengunduh, h[1]))
                handlerUpdate.postDelayed({ pantauUnduh(id) }, 800)
            }
        }
    }

    private fun pasangPembaruan() {
        when (UpdateManager.pasang(this)) {
            UpdateManager.PASANG_MULAI -> toast(R.string.update_memulai_pasang)
            UpdateManager.PASANG_BUTUH_IZIN -> {
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.update_izin_judul))
                    .setMessage(getString(R.string.update_izin_isi))
                    .setPositiveButton(getString(R.string.update_izin_buka)) { d, _ ->
                        d.dismiss()
                        try {
                            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + packageName)))
                        } catch (e: Exception) { bukaInfoApp() }
                    }
                    .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
                    .show()
            }
            else -> toast(R.string.update_gagal_pasang)
        }
    }

    /** Bila unduhan pembaruan sudah selesai tetapi belum dipasang (mis. setelah memberi izin), tawarkan memasang. */
    private fun tawarkanPasangJikaSiap() {
        if (tawaranPasangTampil || dialogPanduanTampil || pemutarPengantar != null) return
        if (dialogUnduh?.isShowing == true) return
        if (!UpdateManager.siapDipasang(this)) return
        tawaranPasangTampil = true
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_siap_judul))
            .setMessage(getString(R.string.update_siap_isi))
            .setPositiveButton(getString(R.string.update_siap_pasang)) { d, _ ->
                d.dismiss()
                pasangPembaruan()
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }
}
