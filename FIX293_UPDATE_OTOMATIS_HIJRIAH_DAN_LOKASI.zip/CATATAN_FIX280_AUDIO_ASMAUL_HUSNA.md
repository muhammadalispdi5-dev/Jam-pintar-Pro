# FIX280 Audio Asmaul Husna (versi tetap 1.0.89)
- AudioAsmaulHusna.kt: berkas lokal 001..099 (folder audio aplikasi atau Jam Pintar Pro/Asmaul Husna), templat alamat https dengan {n}/{nnn}, unduh per nama atau semua, hapus unduhan.
- AsmaulHusnaActivity: putar audio satu nama, putar berurutan sampai ke-99 (lewati yang tidak ada), jeda/lanjut, unduh satu/semua, dialog sumber audio; terhubung ke PembungkamTelungkup (tombol volume dan telungkup menghentikan).
- Tidak ada alamat server bawaan karena belum ada sumber per-nama yang dapat saya verifikasi hak pakai dan URL-nya.
- Petunjuk ID 58 / EN 55; tools/uji_audio_asmaul_husna.py. Belum dikompilasi dengan Gradle, belum diuji di perangkat.
