# FIX292 – Jeda jam ke menit terlalu lama pada pengumuman otomatis

Penyebab: sejak efek gema Jam/Baterai dirender ke berkas (FIX282), setiap ucapan dinyatakan "selesai" baru 1,8 detik setelah pemutaran berakhir (ekor gema). Ucapan menit menunggu penyelesaian jam, lalu ditambah jeda pengguna, sehingga jeda otomatis = jeda + 1,8 detik (+ waktu render). Tombol tes terasa normal bila gema tidak aktif pada jalurnya.

Perbaikan (Pembicara.kt): ucapan selesai segera saat audio berakhir; pemutar dibiarkan hidup 1,8 detik hanya agar ekor gema terdengar, dan dilepas lebih awal bila ada ucapan berikutnya atau saat dihentikan. Jeda jam-menit kini sama dengan nilai di pengaturan. Uji: tools/uji_jeda_jam_menit.py.
