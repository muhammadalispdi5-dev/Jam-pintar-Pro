# FIX271 — Pembacaan rangkaian "Beritahu Saya" tidak terpotong

Masalah: saat tombol pemicu Beritahu Saya di layar depan ditekan, rangkaian waktu, tanggal, hari libur, dan jadwal sholat terpotong karena BeritahuSayaActivity memakai batas waktu tetap 60 detik.

Perbaikan:
- BeritahuSayaActivity.kt: batas waktu dihitung dari panjang seluruh rangkaian (150 ms per karakter + 30 detik, minimal 60 detik, maksimal 15 menit).
- PerintahSuaraActivity.kt: batas baca (waktu/tanggal, teks tampilan, khusus, lokal) mengikuti panjang teks.
- Petunjuk penggunaan (ID dan EN) item Jumat/pembacaan panjang diperluas.

Versi tetap 1.0.89. Belum dikompilasi dengan Gradle dan belum diuji di perangkat; semua pemeriksa lulus (0 GAGAL).
