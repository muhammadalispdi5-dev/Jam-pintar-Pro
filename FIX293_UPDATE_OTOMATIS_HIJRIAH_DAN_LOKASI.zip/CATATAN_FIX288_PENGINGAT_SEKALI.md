# FIX288 – Pengingat sebelum salat terdengar dua kali

Penyebab: tidak ada penjaga terhadap alarm kembar untuk pengingat sebelum salat, azan, tarhim, sahur, dan berbuka (hanya iqomah yang punya). Alarm yang sama datang dua kali pada sebagian HP, lalu ucapan/suara diputar ulang.

Perbaikan (PrayerAlarmService.kt): satu penjaga di awal penanganan; permintaan non-tes dengan jenis+salat yang sama dalam 2 menit diabaikan (SharedPreferences "pengingat_sekali"). Tes tidak terpengaruh. Uji: tools/uji_pengingat_sekali.py.
