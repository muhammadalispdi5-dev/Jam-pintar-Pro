# Jam Pintar Pro — 1.0.89

Jam Pintar Pro adalah aplikasi Android dengan fitur pengumuman baterai dan jam, kalender Masehi/Hijriah dan pasaran, nama pemanggil, jadwal sholat dan pengingat, arah kiblat, Al-Qur'an/Khatam, latihan hafalan, lokasi, pemandu jalan, fasilitas sekitar, doa, serta asisten suara.

Aplikasi dirancang agar dapat digunakan oleh pengguna tunanetra maupun pengguna yang melihat. Kontrol Android, label aksesibilitas, dan petunjuk suara digunakan untuk membantu navigasi dengan TalkBack. Hasil akhir tetap perlu diuji pada perangkat dan versi Android sasaran.

## Bahasa aplikasi

- Bahasa tampilan dapat dipilih sebagai Bahasa Indonesia atau English.
- Pilihan bahasa tampilan mengatur teks antarmuka dan teks petunjuk yang sudah dilokalkan.
- Bahasa pengenalan perintah suara mengikuti bahasa tampilan aplikasi: Indonesia (Indonesia) atau English (United States).
- Mesin pengenal suara (speech recognition) berbeda dari mesin pembaca teks (Text-to-Speech/TTS). Keduanya dapat memiliki pilihan layanan dan ketersediaan bahasa yang berbeda.
- Pengelola paket bahasa offline meminta layanan pengenal suara Android memeriksa atau mengunduh model. Aplikasi tidak menyediakan model bahasa sendiri. Ketersediaan bergantung pada versi Android, perangkat, dan layanan pengenal suara yang dipilih.
- Pada Android 13 atau lebih baru, halaman pengelola dapat memeriksa dukungan/paket yang dilaporkan layanan dan mengirim permintaan unduhan. Pada versi lebih lama, gunakan pengaturan pengenal suara Android.

## Pengelola paket bahasa offline

1. Buka Pengaturan Bahasa atau halaman pengelola paket bahasa offline.
2. Pilih mesin pengenal suara yang ingin digunakan, atau pilih mesin bawaan Android.
3. Periksa ketersediaan paket bahasa untuk bahasa tampilan yang aktif.
4. Jika layanan menyatakan bahasa didukung offline tetapi belum terpasang, minta unduhan.
5. Pantau notifikasi/pengaturan layanan. Setelah proses selesai, kembali dan periksa ketersediaannya sekali lagi.
6. Jika layanan hanya mendukung pengenalan online, gunakan koneksi internet atau pilih layanan lain yang mendukung bahasa tersebut.

Status “permintaan unduhan dikirim” bukan bukti bahwa unduhan telah selesai. Status terpasang harus dikonfirmasi kembali melalui pemeriksaan layanan.

## Identitas proyek

- Versi: **1.0.89**
- `versionCode`: **89**
- Application ID: `com.novan.jambicarapro`
- Namespace sumber: `com.novan.bateraibicara`

Jangan menaikkan versi hanya untuk perubahan dokumentasi. `versionCode` dan `versionName` dipertahankan sampai ada instruksi rilis baru.

## Build dan rilis

Bangun proyek menggunakan Android Gradle Plugin dan Kotlin yang ditetapkan pada berkas Gradle proyek. Jika menggunakan GitHub Actions, pastikan workflow build memang tersedia di repositori dan periksa hasil build pada tab Actions. Arsip sumber ini tidak boleh dianggap sebagai bukti bahwa APK telah berhasil dibangun.

Untuk pembaruan aplikasi yang sudah terpasang, APK harus ditandatangani dengan kunci rilis yang sama. Simpan keystore dan kredensialnya dengan aman; jangan memasukkan rahasia ke dalam repositori.

## Pemeriksaan sebelum publikasi

- Build varian release dan pastikan tidak ada kegagalan kompilasi.
- Pasang APK pada perangkat uji dan periksa pembaruan dari versi sebelumnya.
- Uji bahasa Indonesia dan English secara terpisah: halaman utama, seluruh menu, petunjuk penggunaan, dialog, pesan status, notifikasi, label TalkBack, serta respons asisten suara.
- Uji pilihan mesin pengenal suara, pemeriksaan paket bahasa, permintaan unduhan, pemeriksaan ulang setelah unduhan, dan kondisi bahasa yang hanya tersedia online.
- Uji TTS secara terpisah dari pengenal suara; pastikan mesin dan suara yang dipilih benar-benar tersedia.
- Uji izin mikrofon, notifikasi, lokasi, alarm tepat waktu, akses notifikasi, serta pembatasan baterai.
- Uji fitur utama dengan layar menyala/mati dan TalkBack aktif.
- Pastikan catatan rilis, kebijakan privasi, materi toko, dan dukungan pengguna siap sebelum publikasi.

Pemeriksaan sumber dan skrip otomatis membantu menemukan masalah, tetapi tidak menggantikan pengujian APK pada perangkat Android nyata.
