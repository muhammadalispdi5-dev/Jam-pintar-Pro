# FIX276 — Kompatibilitas izin lintas merek Android

Sumber: `FIX275_PROYEK_LENGKAP.zip`.

## Perubahan
- Memperluas identifikasi keluarga perangkat: Xiaomi/Redmi/POCO, OPPO/Realme/OnePlus, Vivo/iQOO, Huawei/Honor, Tecno/Infinix/itel (Transsion), ASUS, Motorola/Lenovo, Sony, Google Pixel, Nothing, ZTE/Nubia/RedMagic, Meizu, Nokia/HMD, dan lainnya.
- Memperluas pintasan autostart dan manajemen baterai Transsion untuk perangkat Infinix/Tecno/itel.
- Mengubah pemilihan intent OEM agar hanya mencoba komponen yang sesuai dengan keluarga merek perangkat; bila tidak tersedia, beralih ke halaman pengaturan Android standar. Ini mencegah aplikasi membuka menu milik pabrikan lain.
- Menambahkan pemeriksaan status izin notifikasi layar penuh Android 14+ (`canUseFullScreenIntent`) dan pintasan ke halaman resmi pengaturannya.
- Menambahkan langkah opsional izin layar penuh pada pemandu izin awal Android 14+.
- Menambahkan pintasan langsung ke Info aplikasi/penggunaan baterai sebagai fallback lintas merek.
- Memperinci petunjuk Infinix/Tecno/itel (XOS/HiOS) dan merek Android lain dalam bahasa Indonesia dan Inggris.
- Memperbarui label pengaturan pop-up agar tidak lagi mengesankan bahwa fitur hanya untuk Xiaomi.

## Batasan Android yang harus dipahami
Aplikasi Android biasa tidak dapat memaksa sistem memberikan izin, mengubah toggle keamanan secara diam-diam, melewati persetujuan pengguna, atau menjamin kebijakan autostart OEM. Pengguna tetap harus mengaktifkan izin pada layar pengaturan sistem. Nama menu dan komponen vendor dapat berubah menurut versi OS/ROM. Aplikasi menampilkan status izin standar dan menyediakan pintasan/panduan yang paling sesuai, dengan fallback aman bila menu khusus tidak tersedia.

## Kompatibilitas dan versi
- `versionCode`: 89 (dipertahankan)
- `versionName`: 1.0.89 (dipertahankan)
- `targetSdk`: 36 (dipertahankan)
- Tidak menghapus izin atau layanan yang sudah ada.

## Pemeriksaan
- XML `AndroidManifest.xml`, `values/strings.xml`, dan `values-en/strings.xml` divalidasi secara sintaks.
- Arsip ZIP diuji integritasnya.
- Build Gradle penuh dan pengujian pada perangkat fisik belum dilakukan karena arsip tidak menyertakan Gradle Wrapper dan lingkungan ini tidak memiliki Gradle/Android SDK terpasang.
