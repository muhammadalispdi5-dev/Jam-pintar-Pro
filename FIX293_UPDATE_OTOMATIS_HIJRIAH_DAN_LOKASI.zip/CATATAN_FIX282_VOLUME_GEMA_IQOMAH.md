# FIX282 (versi tetap 1.0.89)
- Volume pengumuman: kurva kuadrat (persepsi); di bawah 100% ucapan dirender (synthesizeToFile) lalu diputar MediaPlayer dengan setVolume sendiri, jadi berlaku di semua mesin suara/HP; jalur lama sebagai cadangan bila render gagal. Melodi memakai kurva yang sama. Volume HP tidak diubah.
- Jeda pengulangan baterai penuh: tambah 10 dan 15 menit.
- Iqomah satu kali: permintaan sama dalam 10 menit diabaikan (prefs iqomah_sekali), margin 90 detik pada penjadwalan ulang.
- Gema Jam dan Baterai: ucapan dirender lalu diputar lewat MediaPlayer dengan GemaAudio.terapkanKunci pada sesinya (PresetReverb/EnvironmentalReverb seperti Khatam), ekor 1,8 detik.
- Petunjuk ID 59 / EN 56. Belum dikompilasi dengan Gradle, belum diuji di perangkat.
