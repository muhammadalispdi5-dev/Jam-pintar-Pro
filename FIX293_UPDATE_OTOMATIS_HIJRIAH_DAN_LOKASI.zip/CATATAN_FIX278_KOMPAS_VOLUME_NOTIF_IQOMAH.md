# FIX278–279 (versi tetap 1.0.89)

## FIX278 Kompas dan Cari Arah
- Halaman baru KompasActivity + NadaArah (menu utama, tombol di halaman Arah Kiblat, perintah suara "kompas / cari arah").
- Arah hadap dibaca dari sensor rotasi (cadangan: akselerometer+magnetometer), HP mendatar atau tegak, dengan deklinasi magnet bila lokasi diatur.
- Nada panjang khas saat tepat di salah satu dari 8 arah: Utara tinggi stabil, Selatan rendah stabil, Timur menanjak, Barat menurun, arah antara = dua nada.
- Cari arah (Utara/Timur/Selatan/Barat, arah antara, kiblat, derajat khusus): bip stereo kiri/kanan, makin cepat dan tinggi saat dekat, nada panjang + ucapan saat tepat.
- Tombol "Sebutkan arah sekarang" menyebut arah hadap dan letak U/T/S/B terhadap pengguna.

## FIX279
1. Volume pengumuman tidak lagi mengubah volume dering/notifikasi/alarm/media HP (VolumeSaluran menjadi no-op; hanya pengali suara aplikasi pada TTS dan melodi). Teks halaman volume dan petunjuk disesuaikan.
2. Notifikasi menyangkut: notifikasi tes Iqomah (id 810 + 809 ongoing) kini id 809 dan dibatalkan di onDestroy; pengaman layanan (berhenti sendiri bila tidak ada suara); batas dering panggilan 150 detik; ulang ucapan terputus maksimal 20 kali/45 detik.
3. Iqomah: tombol Jeda/Lanjutkan dan Hentikan pada notifikasi Tarhim dan Iqomah nyata; tidak bertumpuk dengan suara yang masih berbunyi; pilihan jeda bertambah (3…60 menit sejak waktu azan); jeda/lanjut menjadwalkan ulang batas waktu.

Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
