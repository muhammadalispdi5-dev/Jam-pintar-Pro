package com.novan.bateraibicara

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Pembangkit nada kompas (FIX278). Setiap arah mata angin punya nada panjang yang khas
 * sehingga pengguna tunanetra dapat mengenalinya tanpa melihat layar:
 *  Utara = nada tinggi stabil, Selatan = nada rendah stabil,
 *  Timur = nada menanjak, Barat = nada menurun,
 *  arah antara (mis. Timur Laut) = dua nada arah utama yang berdampingan secara berurutan.
 */
object NadaArah {
    private const val RATE = 22050
    private var jalur: AudioTrack? = null
    private val cache = HashMap<String, ShortArray>()

    /** Satu segmen nada: [dari]..[ke] Hz selama [detik]; envelope halus agar tidak berderak. */
    private fun segmen(dari: Double, ke: Double, detik: Double): ShortArray {
        val n = (RATE * detik).toInt()
        val out = ShortArray(n)
        var fase = 0.0
        val tepi = (RATE * 0.03).toInt().coerceAtMost(n / 2)
        for (i in 0 until n) {
            val f = dari + (ke - dari) * i / n
            fase += 2 * PI * f / RATE
            var a = 0.8 * sin(fase) + 0.2 * sin(2 * fase)
            val env = when {
                i < tepi -> i.toDouble() / tepi
                i > n - tepi -> (n - i).toDouble() / tepi
                else -> 1.0
            }
            a *= env * 0.6
            out[i] = (a * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    /** Nada utama arah: 0 Utara, 2 Timur, 4 Selatan, 6 Barat. */
    private fun utama(idx: Int, detik: Double): ShortArray = when (idx) {
        0 -> segmen(880.0, 880.0, detik)
        2 -> segmen(520.0, 880.0, detik)
        4 -> segmen(440.0, 440.0, detik)
        else -> segmen(880.0, 520.0, detik)
    }

    /** Nada panjang (sekitar 1,8 detik) untuk arah 0..7 (Utara, Timur Laut, ... Barat Laut). */
    fun nadaArah(idx: Int): ShortArray = cache.getOrPut("arah$idx") {
        if (idx % 2 == 0) utama(idx, 1.8)
        else {
            val a = if (idx == 1 || idx == 7) 0 else 4
            val b = if (idx == 1 || idx == 3) 2 else 6
            utama(a, 0.9) + utama(b, 0.9)
        }
    }

    /** Nada panjang konfirmasi untuk target bebas (kiblat atau derajat khusus). */
    fun nadaTarget(): ShortArray = cache.getOrPut("target") { segmen(660.0, 660.0, 1.0) + segmen(990.0, 990.0, 0.8) }

    /** Bip pendek berpanning: [kanan] true = telinga kanan, false = kiri; nada naik saat makin dekat. */
    fun bip(frekuensi: Int, kanan: Boolean): ShortArray = cache.getOrPut("bip$frekuensi$kanan") {
        val mono = segmen(frekuensi.toDouble(), frekuensi.toDouble(), 0.12)
        val st = ShortArray(mono.size * 2)
        for (i in mono.indices) {
            if (kanan) st[2 * i + 1] = mono[i] else st[2 * i] = mono[i]
        }
        st
    }

    @Synchronized
    fun putar(data: ShortArray, stereo: Boolean = false) {
        henti()
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(if (stereo) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(data, 0, data.size)
            t.play()
            jalur = t
        } catch (_: Exception) { jalur = null }
    }

    @Synchronized
    fun henti() {
        try { jalur?.stop() } catch (_: Exception) { }
        try { jalur?.release() } catch (_: Exception) { }
        jalur = null
    }

    /** Selisih bertanda target-saat ini dalam -180..180 (positif = putar ke kanan). */
    fun selisih(target: Double, sekarang: Double): Double = ((target - sekarang + 540.0) % 360.0) - 180.0

    fun jarak(a: Double, b: Double): Double = abs(selisih(a, b))
}
