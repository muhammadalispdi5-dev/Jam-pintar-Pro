package com.novan.bateraibicara

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.EnvironmentalReverb
import android.media.audiofx.PresetReverb

/**
 * FIX164: efek gema dan ruang untuk audio Khatam Al-Qur'an (gema aula, gema/echo, studio vokal, karaoke,
 * panggung konser, lembah, gua, dan lain-lain). Dipakai bersama oleh layar Khatam dan pemutar latar belakang
 * (EfekAudioLatar) agar terdengar sama. Pengaturan: "efek_gema_mode" (kunci mode) dan "efek_gema_persen" (0-100; 0 = gema dimatikan)
 * pada SharedPreferences "khatam_quran".
 *
 * Mode berbasis EnvironmentalReverb (parameter bebas: jeda pantulan, lama gema) dipakai untuk gema sungguhan.
 * Bila perangkat tidak mendukungnya, dipakai PresetReverb terdekat. Bila keduanya tidak ada, audio tetap normal
 * dan alasannya dicatat di [catatan]. Teks mengikuti bahasa aktif aplikasi.
 */
class GemaAudio(private val context: Context) {
    private var preset: PresetReverb? = null
    private var env: EnvironmentalReverb? = null
    private var sesi = 0

    /** Catatan kegagalan/pengganti terakhir; kosong bila efek berjalan seperti diminta. */
    var catatan: String = ""
        private set

    private fun tr(id: String, en: String): String = if (BahasaAplikasi.tampilan(context) == 1) en else id

    private class Param(
        val decay: Int, val decayHf: Int, val refLevel: Int, val refDelay: Int,
        val revLevel: Int, val revDelay: Int, val diffusion: Int, val density: Int,
        val room: Int, val roomHf: Int
    )

    companion object {
        const val KUNCI_MODE = "efek_gema_mode"
        const val KUNCI_PERSEN = "efek_gema_persen"
        val daftarKunci = listOf(
            "normal", "kamar", "aula", "aula_besar", "echo_lembut", "echo", "lembah",
            "studio", "karaoke", "panggung", "gua"
        )
        fun sah(k: String?): Boolean = k != null && k in daftarKunci
    }

    fun mode(prefs: SharedPreferences): String =
        prefs.getString(KUNCI_MODE, "normal")?.takeIf { sah(it) } ?: "normal"

    fun persen(prefs: SharedPreferences): Int = prefs.getInt(KUNCI_PERSEN, 60).coerceIn(0, 100)

    fun label(k: String): String = when (k) {
        "kamar" -> tr("Ruang kecil", "Small room")
        "aula" -> tr("Gema aula", "Hall reverb")
        "aula_besar" -> tr("Gema aula besar / masjid", "Large hall / mosque reverb")
        "echo_lembut" -> tr("Gema (echo) lembut", "Soft echo")
        "echo" -> tr("Gema (echo) jelas", "Clear echo")
        "lembah" -> tr("Gema lembah / pegunungan", "Valley / mountain echo")
        "studio" -> tr("Studio vokal", "Vocal studio")
        "karaoke" -> tr("Karaoke", "Karaoke")
        "panggung" -> tr("Panggung konser", "Concert stage")
        "gua" -> tr("Gua / katedral", "Cave / cathedral")
        else -> tr("Normal (mati)", "Normal (off)")
    }

    fun deskripsi(k: String): String = when (k) {
        "kamar" -> tr("Pantulan singkat seperti ruangan kecil; suara terasa dekat dan hangat.", "Short reflections like a small room; the sound feels close and warm.")
        "aula" -> tr("Gema ruang aula sedang; bacaan terdengar lapang.", "Medium hall reverb; the recitation sounds spacious.")
        "aula_besar" -> tr("Gema panjang ala aula besar atau masjid.", "Long reverb like a large hall or mosque.")
        "echo_lembut" -> tr("Satu pantulan suara yang halus setelah suara asli.", "A gentle single repeat after the original sound.")
        "echo" -> tr("Pantulan suara yang jelas dan terpisah, seperti berteriak di ruang terbuka.", "A clear, separate repeat, like calling out in an open space.")
        "lembah" -> tr("Gema sangat panjang seperti di lembah atau pegunungan.", "A very long echo like in a valley or the mountains.")
        "studio" -> tr("Gema halus ala plat studio rekaman; vokal terasa penuh.", "Smooth studio plate reverb; the voice feels full.")
        "karaoke" -> tr("Gema dan pantulan seperti mikrofon karaoke.", "Echo and reflections like a karaoke microphone.")
        "panggung" -> tr("Gema luas ala panggung konser dan stadion.", "Wide reverb like a concert stage or stadium.")
        "gua" -> tr("Gema sangat panjang dan dalam seperti di gua atau katedral.", "A very long, deep reverb like in a cave or cathedral.")
        else -> tr("Tanpa efek gema.", "No echo effect.")
    }

    private fun parameter(k: String): Param? = when (k) {
        "echo_lembut" -> Param(1200, 800, -1800, 160, -3000, 100, 400, 200, -1000, -300)
        "echo" -> Param(1800, 900, -900, 300, -2200, 100, 300, 100, -1000, -300)
        "lembah" -> Param(7000, 600, -1000, 300, -1500, 100, 700, 150, -1000, -400)
        "karaoke" -> Param(1800, 900, -1100, 90, -900, 40, 800, 1000, -1000, -300)
        "panggung" -> Param(3500, 700, -900, 60, -700, 60, 1000, 1000, -1000, -400)
        "gua" -> Param(10000, 500, -1000, 120, -800, 90, 1000, 800, -1000, -600)
        else -> null
    }

    private fun presetUntuk(k: String): Short = when (k) {
        "kamar" -> PresetReverb.PRESET_SMALLROOM
        "aula" -> PresetReverb.PRESET_MEDIUMHALL
        "aula_besar", "lembah", "panggung", "gua" -> PresetReverb.PRESET_LARGEHALL
        "studio", "echo_lembut" -> PresetReverb.PRESET_PLATE
        "karaoke", "echo", "ruang_sedang" -> PresetReverb.PRESET_MEDIUMROOM
        "ruang_besar" -> PresetReverb.PRESET_LARGEROOM
        "plate" -> PresetReverb.PRESET_PLATE
        else -> PresetReverb.PRESET_NONE
    }

    private fun matikan() {
        try { preset?.enabled = false } catch (_: Exception) { }
        try { env?.enabled = false } catch (_: Exception) { }
    }

    /** Terapkan mode gema aktif pada sesi audio. Mengembalikan true bila mode normal atau efek berhasil aktif. */
    fun terapkan(sesiId: Int, prefs: SharedPreferences): Boolean = terapkanKunci(sesiId, mode(prefs), persen(prefs))

    /** FIX282: terapkan mode [k] dengan kekuatan [kekuatan] (0..100); dipakai juga untuk ucapan jam dan baterai. */
    fun terapkanKunci(sesiId: Int, k: String, kekuatan: Int): Boolean {
        catatan = ""
        if (k == "normal" || kekuatan == 0) { matikan(); return true }
        if (sesiId <= 0) { catatan = tr("sesi audio belum siap", "audio session is not ready"); return false }
        if (sesiId != sesi) lepas()
        sesi = sesiId
        val p = parameter(k)
        if (p != null) {
            try {
                val e = env ?: EnvironmentalReverb(0, sesiId).also { env = it }
                if (!e.hasControl()) throw IllegalStateException("tanpa kendali")
                val geser = (kekuatan - 60) * 30
                e.setDecayTime(p.decay.coerceIn(100, 20000))
                e.setDecayHFRatio(p.decayHf.coerceIn(100, 2000).toShort())
                e.setReflectionsLevel((p.refLevel + geser).coerceIn(-9000, 1000).toShort())
                e.setReflectionsDelay(p.refDelay.coerceIn(0, 300))
                e.setReverbLevel((p.revLevel + geser).coerceIn(-9000, 2000).toShort())
                e.setReverbDelay(p.revDelay.coerceIn(0, 100))
                e.setDiffusion(p.diffusion.coerceIn(0, 1000).toShort())
                e.setDensity(p.density.coerceIn(0, 1000).toShort())
                e.setRoomLevel(p.room.coerceIn(-9000, 0).toShort())
                e.setRoomHFLevel(p.roomHf.coerceIn(-9000, 0).toShort())
                e.enabled = true
                try { preset?.enabled = false } catch (_: Exception) { }
                return true
            } catch (_: Exception) {
                try { env?.release() } catch (_: Exception) { }
                env = null
            }
        }
        return try {
            val r = preset ?: PresetReverb(0, sesiId).also { preset = it }
            if (!r.hasControl()) throw IllegalStateException("tanpa kendali")
            r.preset = presetUntuk(k)
            r.enabled = true
            if (p != null) catatan = tr(
                "gema khusus tidak didukung perangkat, dipakai ruang terdekat",
                "custom echo is not supported by the device, nearest room preset used"
            )
            true
        } catch (_: Exception) {
            try { preset?.release() } catch (_: Exception) { }
            preset = null
            catatan = tr("efek gema tidak didukung perangkat atau sedang dipakai aplikasi lain", "the echo effect is not supported by the device or is in use by another app")
            false
        }
    }

    fun lepas() {
        try { preset?.release() } catch (_: Exception) { }
        try { env?.release() } catch (_: Exception) { }
        preset = null; env = null; sesi = 0
    }
}
