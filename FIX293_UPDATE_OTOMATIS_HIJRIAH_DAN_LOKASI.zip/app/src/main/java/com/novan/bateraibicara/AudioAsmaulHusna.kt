package com.novan.bateraibicara

import android.content.Context
import android.os.Environment
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX280: audio Asmaul Husna per nama (1..99). Sumber berurutan: berkas lokal (hasil unduhan atau salinan sendiri bernama
 * 001.mp3 dst.) lalu alamat server yang diatur pengguna dengan {n} atau {nnn} sebagai nomor nama.
 */
object AudioAsmaulHusna {
    private const val PREF = "asmaul_husna"
    private const val KUNCI_URL = "url_audio"
    private val ekstensi = listOf("mp3", "m4a", "ogg", "wav", "aac", "opus")

    fun folderAplikasi(ctx: Context): File {
        val dasar = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        return File(dasar, "Asmaul Husna").also { it.mkdirs() }
    }

    /** Folder yang boleh diisi sendiri oleh pengguna (dibaca bila izin penyimpanan tersedia). */
    private fun folderPublik(): File = File(Environment.getExternalStorageDirectory(), "Jam Pintar Pro/Asmaul Husna")

    private fun nama3(nomor: Int) = String.format(java.util.Locale.ROOT, "%03d", nomor)

    fun berkas(ctx: Context, nomor: Int): File? {
        for (folder in listOf(folderAplikasi(ctx), folderPublik())) {
            for (e in ekstensi) {
                val f = File(folder, nama3(nomor) + "." + e)
                try { if (f.isFile && f.length() > 1024) return f } catch (_: Exception) { }
            }
        }
        return null
    }

    fun templat(ctx: Context): String = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KUNCI_URL, "").orEmpty().trim()
    fun setTemplat(ctx: Context, v: String) { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KUNCI_URL, v.trim()).apply() }

    fun templatSah(t: String): Boolean = t.startsWith("https://") && (t.contains("{n}") || t.contains("{nnn}"))

    fun url(ctx: Context, nomor: Int): String? {
        val t = templat(ctx)
        if (!templatSah(t)) return null
        return t.replace("{nnn}", nama3(nomor)).replace("{n}", nomor.toString())
    }

    fun jumlahTersimpan(ctx: Context): Int = (1..99).count { berkas(ctx, it) != null }

    /** Mengunduh satu nama ke folder aplikasi. Melempar pengecualian bila gagal. */
    fun unduh(ctx: Context, nomor: Int) {
        val alamat = url(ctx, nomor) ?: throw IllegalStateException("no url")
        val c = URL(alamat).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "JamPintarPro/1.0.89")
        try {
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP " + c.responseCode)
            val ext = alamat.substringBefore('?').substringAfterLast('.', "mp3").lowercase().takeIf { it in ekstensi } ?: "mp3"
            val tujuan = File(folderAplikasi(ctx), nama3(nomor) + "." + ext)
            val sementara = File(tujuan.path + ".tmp")
            c.inputStream.use { i -> sementara.outputStream().use { o -> i.copyTo(o) } }
            if (sementara.length() < 1024) { sementara.delete(); throw IllegalStateException("empty") }
            if (tujuan.exists()) tujuan.delete()
            if (!sementara.renameTo(tujuan)) { sementara.copyTo(tujuan, true); sementara.delete() }
        } finally { c.disconnect() }
    }

    fun hapusUnduhan(ctx: Context): Int {
        var n = 0
        folderAplikasi(ctx).listFiles()?.forEach { if (it.delete()) n++ }
        return n
    }
}
