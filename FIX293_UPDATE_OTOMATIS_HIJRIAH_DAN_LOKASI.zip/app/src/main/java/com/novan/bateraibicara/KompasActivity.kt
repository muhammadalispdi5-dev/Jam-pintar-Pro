package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.WindowManager
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Kompas dan Cari Arah (FIX278): menyebutkan arah hadap pengguna, memberi nada panjang khas ketika
 * tepat menghadap salah satu dari 8 arah mata angin, dan memandu pengguna memutar badan ke arah
 * target (Utara, Timur, Selatan, Barat, arah antara, kiblat, atau derajat khusus).
 */
class KompasActivity : Halaman(), SensorEventListener, TextToSpeech.OnInitListener {
    override val judulHalaman = R.string.judul_kompas_arah
    private val pp by lazy { PrayerPrefs(this) }
    private val kp by lazy { getSharedPreferences("kompas_arah", MODE_PRIVATE) }
    private lateinit var sm: SensorManager
    private var rotasi: Sensor? = null
    private var accel: Sensor? = null
    private var magnet: Sensor? = null
    private lateinit var status: TextView
    private lateinit var infoTarget: TextView
    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private val handler = Handler(Looper.getMainLooper())

    private var sinH = 0.0
    private var cosH = 1.0
    private var punyaData = false
    private var deklinasi = 0f
    private val grav = FloatArray(3)
    private val geo = FloatArray(3)
    private var adaGrav = false
    private var adaGeo = false

    private var target: Double? = null
    private var namaTarget = ""
    private var targetIdx = -1
    private var sejajarTarget = false

    private var zona = -1
    private var tungguNada = 0L
    private var terakhirUcap = 0L
    private var sektorUcap = -1
    private var sektorSejak = 0L
    private var sektorKandidat = -1
    private var terakhirPanduan = 0L
    private var terakhirStatus = 0L
    private var teksStatusTerakhir = ""
    private var akurasiTerakhir = -1
    private var terakhirPeringatan = 0L

    private fun tengah(): Double = ((Math.toDegrees(atan2(sinH, cosH)) + 360.0) % 360.0)

    private fun nama(i: Int): String = when (((i % 8) + 8) % 8) {
        0 -> tr("Utara", "North")
        1 -> tr("Timur Laut", "Northeast")
        2 -> tr("Timur", "East")
        3 -> tr("Tenggara", "Southeast")
        4 -> tr("Selatan", "South")
        5 -> tr("Barat Daya", "Southwest")
        6 -> tr("Barat", "West")
        else -> tr("Barat Laut", "Northwest")
    }

    private fun sektor(h: Double): Int = (((h + 22.5) % 360.0) / 45.0).toInt() % 8

    override fun bangun() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        bagian(tr("Kompas dan Cari Arah", "Compass and Find Direction"))
        info(tr("Gunakan di tempat asing untuk mengetahui arah mata angin. Pegang HP mendatar dengan layar menghadap ke atas, atau tegak lurus di depan dada. Saat Anda tepat menghadap Utara, Timur Laut, Timur, Tenggara, Selatan, Barat Daya, Barat, atau Barat Laut, terdengar nada panjang khas: Utara nada tinggi stabil, Selatan nada rendah stabil, Timur nada menanjak, Barat nada menurun, dan arah antara berupa gabungan dua nada. Gunakan headphone untuk panduan kiri dan kanan.",
            "Use this in an unfamiliar place to learn the compass direction. Hold the phone flat with the screen facing up, or upright in front of your chest. When you face exactly North, Northeast, East, Southeast, South, Southwest, West, or Northwest, a distinctive long tone plays: North is a high steady tone, South a low steady tone, East a rising tone, West a falling tone, and in-between directions combine two tones. Use headphones for left and right guidance."))
        status = info(tr("Mencari sensor arah…", "Looking for the direction sensor…"))
        tombol(tr("Sebutkan arah sekarang", "Tell me my direction now")) { sebutkanSekarang() }
        bagian(tr("Cari arah tertentu", "Find a specific direction"), 18f)
        info(tr("Pilih arah yang dicari lalu putar badan perlahan. Bip terdengar di telinga kiri atau kanan sesuai arah putaran; makin cepat dan tinggi berarti makin dekat. Ketika tepat, terdengar nada panjang dan ucapan konfirmasi.",
            "Pick a direction to find, then turn slowly. Beeps sound in the left or right ear according to the way you should turn; faster and higher means closer. When you are exactly right, a long tone and a spoken confirmation play."))
        infoTarget = info(tr("Belum ada arah yang dicari.", "No direction is being searched."))
        tombol(tr("Cari Utara", "Find North")) { aturTarget(0.0, nama(0), 0) }
        tombol(tr("Cari Timur", "Find East")) { aturTarget(90.0, nama(2), 2) }
        tombol(tr("Cari Selatan", "Find South")) { aturTarget(180.0, nama(4), 4) }
        tombol(tr("Cari Barat", "Find West")) { aturTarget(270.0, nama(6), 6) }
        tombol(tr("Cari arah lainnya (arah antara, kiblat, derajat)", "Find another direction (in-between, Qibla, degrees)")) { dialogTargetLain() }
        tombol(tr("Berhenti mencari arah", "Stop searching")) { hentikanTarget(true) }
        bagian(tr("Pengaturan kompas", "Compass settings"), 18f)
        saklar(tr("Nada panjang saat tepat menghadap arah mata angin", "Long tone when exactly facing a compass direction"), kp.getBoolean("nada", true)) { kp.edit().putBoolean("nada", it).apply() }
        saklar(tr("Nada hanya untuk 4 arah utama (Utara, Timur, Selatan, Barat)", "Tone only for the 4 main directions (North, East, South, West)"), kp.getBoolean("empat", false)) { kp.edit().putBoolean("empat", it).apply() }
        saklar(tr("Ucapkan nama arah otomatis saat arah berubah", "Speak the direction name automatically when it changes"), kp.getBoolean("ucap", true)) { kp.edit().putBoolean("ucap", it).apply() }
        saklar(tr("Ucapkan petunjuk putar saat mencari arah", "Speak turn instructions while searching"), kp.getBoolean("panduan", true)) { kp.edit().putBoolean("panduan", it).apply() }
        tombol(tr("Hentikan semua suara", "Stop all sound")) { NadaArah.henti(); tts?.stop() }
        tombol(tr("Buka Kompas Kiblat", "Open Qibla compass")) { startActivity(android.content.Intent(this, QiblaActivity::class.java)) }

        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotasi = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotasi == null) {
            accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            magnet = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        }
        if (rotasi == null && (accel == null || magnet == null)) {
            status.text = tr("Perangkat ini tidak memiliki sensor kompas yang diperlukan.", "This device does not have the required compass sensors.")
        }
        if (pp.locationSet) {
            try { deklinasi = GeomagneticField(pp.lat.toFloat(), pp.lon.toFloat(), 0f, System.currentTimeMillis()).declination } catch (_: Exception) { }
        }
        tts = TextToSpeech(this, this)
    }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) {
            tts?.language = if (BahasaAplikasi.tampilan(this) == 1) Locale.ENGLISH else Locale("id", "ID")
            ttsSiap = true
        }
    }

    private fun ucap(t: String) {
        if (ttsSiap) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "kompas")
    }

    // ---------- Target ----------

    private fun aturTarget(derajat: Double, nm: String, idx: Int) {
        target = derajat; namaTarget = nm; targetIdx = idx; sejajarTarget = false; tungguNada = 0L; terakhirPanduan = 0L
        infoTarget.text = tr("Mencari arah ", "Searching for ") + nm + " (" + derajat.roundToInt() + "°)"
        ucap(tr("Mencari arah $nm. Putar badan perlahan.", "Searching for $nm. Turn slowly."))
    }

    private fun hentikanTarget(bicara: Boolean) {
        if (target == null && bicara) { toast(tr("Tidak sedang mencari arah.", "Not searching for a direction.")); return }
        target = null; targetIdx = -1; sejajarTarget = false
        infoTarget.text = tr("Belum ada arah yang dicari.", "No direction is being searched.")
        NadaArah.henti()
        if (bicara) ucap(tr("Pencarian arah dihentikan.", "Search stopped."))
    }

    private fun dialogTargetLain() {
        val daftar = ArrayList<String>()
        daftar.add(nama(1)); daftar.add(nama(3)); daftar.add(nama(5)); daftar.add(nama(7))
        daftar.add(tr("Arah kiblat", "Qibla direction"))
        daftar.add(tr("Derajat khusus (0 sampai 359)", "Custom degrees (0 to 359)"))
        AlertDialog.Builder(this)
            .setTitle(tr("Cari arah lainnya", "Find another direction"))
            .setItems(daftar.toTypedArray()) { _, w ->
                when (w) {
                    0 -> aturTarget(45.0, nama(1), 1)
                    1 -> aturTarget(135.0, nama(3), 3)
                    2 -> aturTarget(225.0, nama(5), 5)
                    3 -> aturTarget(315.0, nama(7), 7)
                    4 -> if (pp.locationSet) aturTarget(PrayerCalc.qiblaBearing(pp.lat, pp.lon), tr("Kiblat", "Qibla"), -1)
                         else toast(tr("Lokasi belum diatur. Atur lokasi di Jadwal Sholat.", "Location is not set. Set it in Prayer Times."))
                    else -> dialogDerajat()
                }
            }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun dialogDerajat() {
        val et = android.widget.EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.contentDescription = tr("Derajat dari Utara, 0 sampai 359", "Degrees from North, 0 to 359")
        AlertDialog.Builder(this)
            .setTitle(tr("Derajat khusus", "Custom degrees"))
            .setMessage(tr("Masukkan derajat dari Utara searah jarum jam. Timur 90, Selatan 180, Barat 270.", "Enter degrees clockwise from North. East is 90, South 180, West 270."))
            .setView(et)
            .setPositiveButton(tr("Cari", "Find")) { _, _ ->
                val d = et.text.toString().toIntOrNull()
                if (d == null || d !in 0..359) toast(tr("Masukkan angka 0 sampai 359.", "Enter a number from 0 to 359."))
                else aturTarget(d.toDouble(), d.toString() + tr(" derajat", " degrees"), -1)
            }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    // ---------- Ucapan ----------

    private fun posisiRelatif(rel: Double): String {
        val a = abs(rel)
        val sisi = if (rel >= 0) tr("kanan", "right") else tr("kiri", "left")
        return when {
            a <= 22.5 -> tr("di depan", "ahead")
            a <= 67.5 -> tr("di $sisi depan", "front $sisi")
            a <= 112.5 -> tr("di $sisi", "to the $sisi")
            a <= 157.5 -> tr("di $sisi belakang", "back $sisi")
            else -> tr("di belakang", "behind you")
        }
    }

    private fun sebutkanSekarang() {
        if (!punyaData) { ucap(tr("Arah belum terbaca. Gerakkan HP perlahan.", "Direction not read yet. Move the phone slowly.")); return }
        val h = tengah()
        val s = sektor(h)
        val sb = StringBuilder()
        sb.append(tr("Anda menghadap ", "You are facing ")).append(nama(s)).append(", ").append(h.roundToInt()).append(tr(" derajat. ", " degrees. "))
        for (i in intArrayOf(0, 2, 4, 6)) {
            val rel = NadaArah.selisih(i * 45.0, h)
            sb.append(nama(i)).append(" ").append(posisiRelatif(rel)).append(". ")
        }
        val t = target
        if (t != null) {
            val d = NadaArah.selisih(t, h)
            sb.append(arahPutar(namaTarget, d))
        }
        ucap(sb.toString())
    }

    private fun arahPutar(nm: String, d: Double): String {
        val a = abs(d).roundToInt()
        return if (a <= 5) tr("Tepat menghadap $nm.", "Exactly facing $nm.")
        else tr("Putar ke " + (if (d > 0) "kanan " else "kiri ") + a + " derajat menuju $nm.",
                "Turn " + (if (d > 0) "right " else "left ") + a + " degrees toward $nm.")
    }

    // ---------- Sensor ----------

    private fun terapkanMatriks(r: FloatArray) {
        val tegak = abs(r[8]) < 0.7f
        val m = FloatArray(9)
        if (tegak) SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, m) else System.arraycopy(r, 0, m, 0, 9)
        val o = FloatArray(3)
        SensorManager.getOrientation(m, o)
        val derajat = (Math.toDegrees(o[0].toDouble()) + deklinasi + 360.0) % 360.0
        val rad = Math.toRadians(derajat)
        if (!punyaData) { sinH = sin(rad); cosH = cos(rad); punyaData = true }
        else { val a = 0.18; sinH += a * (sin(rad) - sinH); cosH += a * (cos(rad) - cosH) }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val r = FloatArray(9)
        when (e.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> { SensorManager.getRotationMatrixFromVector(r, e.values); terapkanMatriks(r) }
            Sensor.TYPE_ACCELEROMETER -> {
                for (i in 0..2) grav[i] = if (adaGrav) grav[i] + 0.2f * (e.values[i] - grav[i]) else e.values[i]
                adaGrav = true
                if (adaGeo && SensorManager.getRotationMatrix(r, null, grav, geo)) terapkanMatriks(r)
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                for (i in 0..2) geo[i] = if (adaGeo) geo[i] + 0.2f * (e.values[i] - geo[i]) else e.values[i]
                adaGeo = true
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        val now = System.currentTimeMillis()
        if (accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW && accuracy != akurasiTerakhir && now - terakhirPeringatan > 20000L) {
            terakhirPeringatan = now
            ucap(tr("Kompas belum akurat. Gerakkan HP membentuk angka delapan beberapa kali.", "The compass is not accurate. Move the phone in a figure eight a few times."))
        }
        akurasiTerakhir = accuracy
    }

    // ---------- Siklus utama ----------

    private val tick = object : Runnable {
        override fun run() {
            try { langkah() } catch (_: Exception) { }
            handler.postDelayed(this, 120L)
        }
    }

    private fun langkah() {
        if (!punyaData) return
        val now = System.currentTimeMillis()
        val h = tengah()
        val s = sektor(h)
        if (now - terakhirStatus > 400L) {
            terakhirStatus = now
            val t = tr("Menghadap ", "Facing ") + nama(s) + ", " + h.roundToInt() + "°"
            if (t != teksStatusTerakhir) { teksStatusTerakhir = t; status.text = t }
        }
        val tg = target
        if (tg != null) { langkahTarget(tg, h, now); return }
        // Mode bebas: nada panjang saat tepat pada salah satu dari 8 arah.
        val empat = kp.getBoolean("empat", false)
        val idx = (((h / 45.0).roundToInt()) % 8)
        val galat = NadaArah.jarak(idx * 45.0, h)
        val layak = !empat || idx % 2 == 0
        val batas = if (zona == idx) 10.0 else 6.0
        if (layak && galat <= batas) {
            if (zona != idx) {
                zona = idx
                tungguNada = 0L
                if (kp.getBoolean("ucap", true)) { ucap(nama(idx)); terakhirUcap = now; tungguNada = now + 900L }
            }
            if (kp.getBoolean("nada", true) && now >= tungguNada) {
                NadaArah.putar(NadaArah.nadaArah(idx))
                tungguNada = now + (if (idx % 2 == 0) 2300L else 2300L)
            }
        } else {
            if (zona != -1) { zona = -1; NadaArah.henti() }
            if (kp.getBoolean("ucap", true)) {
                if (s != sektorKandidat) { sektorKandidat = s; sektorSejak = now }
                else if (s != sektorUcap && now - sektorSejak > 1500L && now - terakhirUcap > 2500L) {
                    sektorUcap = s; terakhirUcap = now
                    ucap(nama(s))
                }
            }
        }
    }

    private fun langkahTarget(tg: Double, h: Double, now: Long) {
        val d = NadaArah.selisih(tg, h)
        val a = abs(d)
        val batas = if (sejajarTarget) 9.0 else 5.0
        if (a <= batas) {
            if (!sejajarTarget) {
                sejajarTarget = true
                ucap(tr("Tepat menghadap $namaTarget.", "Exactly facing $namaTarget."))
                tungguNada = now + 1400L
            }
            if (now >= tungguNada) {
                NadaArah.putar(if (targetIdx >= 0) NadaArah.nadaArah(targetIdx) else NadaArah.nadaTarget())
                tungguNada = now + 2400L
            }
            return
        }
        if (sejajarTarget) { sejajarTarget = false; NadaArah.henti(); tungguNada = 0L }
        if (now >= tungguNada) {
            val frek = (500 + (180 - a) * 4).toInt() / 20 * 20
            NadaArah.putar(NadaArah.bip(frek, d > 0), true)
            tungguNada = now + (180 + a * 5).toLong().coerceAtMost(1000L)
        }
        if (kp.getBoolean("panduan", true) && now - terakhirPanduan > 4500L) {
            terakhirPanduan = now
            ucap(arahPutar(namaTarget, d))
        }
    }

    override fun onResume() {
        super.onResume()
        val rs = rotasi
        if (rs != null) sm.registerListener(this, rs, SensorManager.SENSOR_DELAY_GAME)
        else {
            accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            magnet?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        }
        handler.removeCallbacks(tick); handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        try { sm.unregisterListener(this) } catch (_: Exception) { }
        NadaArah.henti()
        try { tts?.stop() } catch (_: Exception) { }
        zona = -1
        super.onPause()
    }

    override fun onDestroy() {
        try { tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }
}
