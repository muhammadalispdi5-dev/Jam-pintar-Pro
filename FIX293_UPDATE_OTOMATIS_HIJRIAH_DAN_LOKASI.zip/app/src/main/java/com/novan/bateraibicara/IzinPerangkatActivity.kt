package com.novan.bateraibicara

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.TextView

/**
 * Pusat perizinan: menampilkan status tiap izin penting dan tombol untuk membukanya, termasuk
 * pengaturan khusus merek (Xiaomi, OPPO/Realme/OnePlus, Vivo, Huawei/Honor, Transsion, dll.)
 * seperti "Mulai otomatis" dan "Tampil di atas aplikasi lain".
 */
class IzinPerangkatActivity : Halaman() {

    override val judulHalaman = R.string.kategori_izin_perangkat

    private lateinit var tNotif: TextView
    private lateinit var tAlarm: TextView
    private lateinit var tBaterai: TextView
    private lateinit var tOverlay: TextView
    private lateinit var tAkses: TextView
    private lateinit var tDnd: TextView
    private lateinit var tLayarPenuh: TextView

    override fun bangun() {
        info(getString(R.string.izin_perangkat_merek, PerangkatIzin.namaPerangkat(), Build.VERSION.RELEASE))
        info(getString(PerangkatIzin.panduanRes()))

        bagian(getString(R.string.bagian_izin_utama))
        tNotif = info("")
        tombol(getString(R.string.tombol_izin_notif)) { aksiNotifikasi() }
        tAlarm = info("")
        tombol(getString(R.string.tombol_izin_alarm)) {
            if (PerangkatIzin.alarmTepatWaktu(this)) toast(R.string.sudah_diizinkan)
            else if (!PerangkatIzin.bukaAlarmTepat(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        tBaterai = info("")
        tombol(getString(R.string.tombol_izin_baterai)) {
            if (PerangkatIzin.abaikanBaterai(this)) toast(R.string.sudah_diizinkan)
            else if (!PerangkatIzin.bukaAbaikanBaterai(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        tOverlay = info("")
        tombol(getString(R.string.tombol_izin_overlay)) {
            if (PerangkatIzin.tampilDiAtas(this)) toast(R.string.sudah_diizinkan)
            else if (!PerangkatIzin.bukaTampilDiAtas(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        tAkses = info("")
        tombol(getString(R.string.tombol_akses_notif)) {
            if (!PerangkatIzin.bukaAksesNotifikasi(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        tDnd = info("")
        tombol(getString(R.string.tombol_izin_dnd)) {
            if (PerangkatIzin.janganGanggu(this)) toast(R.string.sudah_diizinkan)
            else if (!PerangkatIzin.bukaJanganGanggu(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        tLayarPenuh = info("")
        tombol(getString(R.string.tombol_izin_layar_penuh)) {
            if (PerangkatIzin.layarPenuh(this)) toast(R.string.sudah_diizinkan)
            else if (!PerangkatIzin.bukaLayarPenuh(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }

        bagian(getString(R.string.bagian_izin_merek))
        info(getString(R.string.info_izin_merek))
        tombol(getString(R.string.tombol_mulai_otomatis)) { bukaKhusus(PerangkatIzin.Kategori.MULAI_OTOMATIS) }
        tombol(getString(R.string.tombol_baterai_merek)) { bukaKhusus(PerangkatIzin.Kategori.BATERAI_MEREK) }
        tombol(getString(R.string.tombol_buka_baterai_aplikasi)) {
            if (!PerangkatIzin.bukaBateraiAplikasi(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        tombol(getString(R.string.tombol_popup_latar)) { bukaKhusus(PerangkatIzin.Kategori.POPUP_LATAR) }
        tombol(getString(R.string.tombol_info_app)) { if (!PerangkatIzin.bukaInfoAplikasi(this)) bukaInfoApp() }
        info(getString(R.string.info_setelan_terbatas))
    }

    private fun bukaKhusus(kategori: PerangkatIzin.Kategori) {
        if (!PerangkatIzin.bukaKhusus(this, kategori)) {
            // Tidak ada menu khusus merek di HP ini: buka Info aplikasi sebagai jalan keluar.
            toast(R.string.menu_khusus_tidak_ada)
            if (!PerangkatIzin.bukaInfoAplikasi(this)) bukaInfoApp()
        }
    }

    private fun aksiNotifikasi() {
        if (PerangkatIzin.notifikasiAktif(this)) {
            toast(R.string.sudah_diizinkan)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        } else if (!PerangkatIzin.bukaNotifikasi(this)) {
            toast(R.string.pengaturan_tidak_ditemukan)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, hasil: IntArray) {
        super.onRequestPermissionsResult(code, perms, hasil)
        // Bila ditolak (atau sistem tidak lagi menampilkan dialog), arahkan ke pengaturan notifikasi aplikasi.
        if (code == 11 && !PerangkatIzin.notifikasiAktif(this)) {
            if (!PerangkatIzin.bukaNotifikasi(this)) toast(R.string.pengaturan_tidak_ditemukan)
        }
        segarkan()
    }

    override fun onResume() {
        super.onResume()
        segarkan()
    }

    private fun status(nama: Int, aktif: Boolean): String =
        getString(nama) + ": " + getString(if (aktif) R.string.status_izin_ya else R.string.status_izin_tidak)

    private fun segarkan() {
        if (!::tNotif.isInitialized) return
        tNotif.text = status(R.string.izin_nama_notif, PerangkatIzin.notifikasiAktif(this))
        tAlarm.text = status(R.string.izin_nama_alarm, PerangkatIzin.alarmTepatWaktu(this))
        tBaterai.text = status(R.string.izin_nama_baterai, PerangkatIzin.abaikanBaterai(this))
        tOverlay.text = status(R.string.izin_nama_overlay, PerangkatIzin.tampilDiAtas(this))
        tAkses.text = status(R.string.izin_nama_akses, PerangkatIzin.aksesNotifikasi(this))
        tDnd.text = status(R.string.izin_nama_dnd, PerangkatIzin.janganGanggu(this))
        tLayarPenuh.text = status(R.string.izin_nama_layar_penuh, PerangkatIzin.layarPenuh(this))
    }
}
