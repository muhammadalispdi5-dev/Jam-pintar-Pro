package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * Pembaruan lokasi satu-kali saat aplikasi dibuka.
 * Hanya berjalan jika izin lokasi sudah diberikan dan lokasi tersimpan bukan nama manual buatan pengguna.
 * Tidak menjalankan pelacakan terus-menerus dan tidak meminta izin secara diam-diam.
 */
object LokasiOtomatis {
    private const val JEDA_UPDATE_MS = 6L * 60L * 60L * 1000L
    private const val BATAS_USIA_CACHE_MS = 30L * 60L * 1000L
    private const val BATAS_TUNGGU_MS = 20_000L
    private const val AKURASI_CUKUP_M = 150f
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var sedangBerjalan = false

    fun perbaruiJikaPerlu(context: Context) {
        val app = context.applicationContext
        val fine = app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = app.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return

        val pp = PrayerPrefs(app)
        // Jangan menimpa koordinat/nama yang sengaja ditentukan sendiri oleh pengguna.
        if (pp.locationSet && (pp.place.trim() == "Lokasi manual" ||
                    (!NamaLokasi.belumSpesifik(pp.place) && !NamaLokasi.otomatis(app, pp)))) return

        val prefs = app.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("auto_location_last_attempt", 0L) < JEDA_UPDATE_MS) return
        synchronized(this) {
            if (sedangBerjalan) return
            sedangBerjalan = true
        }
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm == null) { selesai(); return }
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        if (providers.isEmpty()) { selesai(); return }
        prefs.edit().putLong("auto_location_last_attempt", now).apply()

        var terbaik: Location? = null
        val selesaiSekali = AtomicBoolean(false)
        lateinit var listener: LocationListener
        val timeout = Runnable { finalisasi(app, pp, lm, listener, terbaik, selesaiSekali) }
        listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!valid(location)) return
                val lama = terbaik
                if (lama == null || location.accuracy < lama.accuracy ||
                    (abs(location.accuracy - lama.accuracy) < 5f && location.time > lama.time)) {
                    terbaik = Location(location)
                }
                if (terbaik != null && terbaik!!.accuracy <= AKURASI_CUKUP_M) {
                    handler.removeCallbacks(timeout)
                    finalisasi(app, pp, lm, listener, terbaik, selesaiSekali)
                }
            }
            @Deprecated("Deprecated in Android API")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }

        // Cache lokasi hanya dipakai sebagai cadangan jika masih sangat baru.
        try {
            providers.forEach { provider ->
                val cached = lm.getLastKnownLocation(provider)
                if (cached != null && valid(cached) && now - cached.time in 0..BATAS_USIA_CACHE_MS) {
                    if (terbaik == null || cached.accuracy < terbaik!!.accuracy) terbaik = Location(cached)
                }
            }
        } catch (_: SecurityException) { }

        try {
            handler.postDelayed(timeout, BATAS_TUNGGU_MS)
            providers.forEach { provider ->
                lm.requestLocationUpdates(provider, 1_000L, 0f, listener, Looper.getMainLooper())
            }
            if (terbaik != null && terbaik!!.accuracy <= AKURASI_CUKUP_M) {
                handler.removeCallbacks(timeout)
                finalisasi(app, pp, lm, listener, terbaik, selesaiSekali)
            }
        } catch (_: SecurityException) {
            handler.removeCallbacks(timeout)
            try { lm.removeUpdates(listener) } catch (_: Exception) { }
            selesai()
        } catch (_: Exception) {
            handler.removeCallbacks(timeout)
            try { lm.removeUpdates(listener) } catch (_: Exception) { }
            selesai()
        }
    }

    private fun valid(location: Location): Boolean =
        location.latitude in -90.0..90.0 && location.longitude in -180.0..180.0 &&
            location.accuracy > 0f && location.accuracy <= 1_000f &&
            System.currentTimeMillis() - location.time in 0..(30L * 60L * 1000L)

    private fun finalisasi(
        context: Context,
        pp: PrayerPrefs,
        manager: LocationManager,
        listener: LocationListener,
        lokasi: Location?,
        selesaiSekali: AtomicBoolean
    ) {
        if (!selesaiSekali.compareAndSet(false, true)) return
        try { manager.removeUpdates(listener) } catch (_: Exception) { }
        if (lokasi != null && valid(lokasi)) {
            val lama = if (pp.locationSet) Location("stored").apply {
                latitude = pp.lat
                longitude = pp.lon
            } else null
            val berpindah = lama == null || lama.distanceTo(lokasi) >= 100f
            if (berpindah) {
                pp.lat = lokasi.latitude
                pp.lon = lokasi.longitude
                pp.locationSet = true
                pp.place = if (lokasi.provider == LocationManager.GPS_PROVIDER) "Lokasi GPS" else "Lokasi jaringan"
                context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE).edit()
                    .putLong("auto_location_last_success", System.currentTimeMillis()).apply()
                try { PrayerAlarm.scheduleAll(context) } catch (_: Exception) { }
                if (pp.autoOnline) {
                    try { PrayerOnlineTimes.sync(context) { _, _ -> try { PrayerAlarm.scheduleAll(context) } catch (_: Exception) { } } }
                    catch (_: Exception) { }
                }
                NamaLokasi.perbaruiAsinkron(context, pp)
            } else {
                context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE).edit()
                    .putLong("auto_location_last_success", System.currentTimeMillis()).apply()
            }
        }
        selesai()
    }

    private fun selesai() { synchronized(this) { sedangBerjalan = false } }
}
