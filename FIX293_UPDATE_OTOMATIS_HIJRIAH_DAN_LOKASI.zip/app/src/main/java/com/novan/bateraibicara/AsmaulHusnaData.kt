package com.novan.bateraibicara

/** FIX272: 99 Asmaul Husna menurut daftar yang lazim dipakai (riwayat At-Tirmidzi). Tiap baris: Arab, Latin, arti Indonesia, arti Inggris. */
object AsmaulHusnaData {
    class Nama(val arab: String, val latin: String, val artiId: String, val artiEn: String)

    /** Pembangun satu baris data: Arab, Latin, arti Indonesia, arti Inggris. */
    private fun teks(arab: String, latin: String, artiId: String, artiEn: String) = Nama(arab, latin, artiId, artiEn)

    val daftar: List<Nama> = listOf(
        teks("الرَّحْمَنُ", "Ar-Rahman", "Yang Maha Pengasih", "The Most Gracious"),
        teks("الرَّحِيمُ", "Ar-Rahim", "Yang Maha Penyayang", "The Most Merciful"),
        teks("الْمَلِكُ", "Al-Malik", "Yang Maha Merajai", "The King"),
        teks("الْقُدُّوسُ", "Al-Quddus", "Yang Maha Suci", "The Most Holy"),
        teks("السَّلَامُ", "As-Salam", "Yang Maha Memberi Keselamatan", "The Source of Peace"),
        teks("الْمُؤْمِنُ", "Al-Mu'min", "Yang Maha Memberi Keamanan", "The Giver of Security"),
        teks("الْمُهَيْمِنُ", "Al-Muhaymin", "Yang Maha Memelihara", "The Guardian"),
        teks("الْعَزِيزُ", "Al-'Aziz", "Yang Maha Perkasa", "The Almighty"),
        teks("الْجَبَّارُ", "Al-Jabbar", "Yang Maha Kuasa", "The Compeller"),
        teks("الْمُتَكَبِّرُ", "Al-Mutakabbir", "Yang Maha Memiliki Kebesaran", "The Supreme in Greatness"),
        teks("الْخَالِقُ", "Al-Khaliq", "Yang Maha Pencipta", "The Creator"),
        teks("الْبَارِئُ", "Al-Bari'", "Yang Maha Mengadakan", "The Originator"),
        teks("الْمُصَوِّرُ", "Al-Musawwir", "Yang Maha Membentuk Rupa", "The Fashioner"),
        teks("الْغَفَّارُ", "Al-Ghaffar", "Yang Maha Pengampun", "The Repeatedly Forgiving"),
        teks("الْقَهَّارُ", "Al-Qahhar", "Yang Maha Menundukkan", "The Subduer"),
        teks("الْوَهَّابُ", "Al-Wahhab", "Yang Maha Pemberi Karunia", "The Bestower"),
        teks("الرَّزَّاقُ", "Ar-Razzaq", "Yang Maha Pemberi Rezeki", "The Provider"),
        teks("الْفَتَّاحُ", "Al-Fattah", "Yang Maha Pembuka Rahmat", "The Opener"),
        teks("الْعَلِيمُ", "Al-'Alim", "Yang Maha Mengetahui", "The All-Knowing"),
        teks("الْقَابِضُ", "Al-Qabid", "Yang Maha Menyempitkan", "The Withholder"),
        teks("الْبَاسِطُ", "Al-Basith", "Yang Maha Melapangkan", "The Expander"),
        teks("الْخَافِضُ", "Al-Khafidh", "Yang Maha Merendahkan", "The Abaser"),
        teks("الرَّافِعُ", "Ar-Rafi'", "Yang Maha Meninggikan", "The Exalter"),
        teks("الْمُعِزُّ", "Al-Mu'izz", "Yang Maha Memuliakan", "The Giver of Honor"),
        teks("الْمُذِلُّ", "Al-Mudzill", "Yang Maha Menghinakan", "The Giver of Dishonor"),
        teks("السَّمِيعُ", "As-Sami'", "Yang Maha Mendengar", "The All-Hearing"),
        teks("الْبَصِيرُ", "Al-Bashir", "Yang Maha Melihat", "The All-Seeing"),
        teks("الْحَكَمُ", "Al-Hakam", "Yang Maha Menetapkan Hukum", "The Judge"),
        teks("الْعَدْلُ", "Al-'Adl", "Yang Maha Adil", "The Utterly Just"),
        teks("اللَّطِيفُ", "Al-Lathif", "Yang Maha Lembut", "The Subtle, Most Gentle"),
        teks("الْخَبِيرُ", "Al-Khabir", "Yang Maha Mengetahui Secara Mendalam", "The All-Aware"),
        teks("الْحَلِيمُ", "Al-Halim", "Yang Maha Penyantun", "The Forbearing"),
        teks("الْعَظِيمُ", "Al-'Azhim", "Yang Maha Agung", "The Magnificent"),
        teks("الْغَفُورُ", "Al-Ghafur", "Yang Maha Pengampun", "The Forgiving"),
        teks("الشَّكُورُ", "Asy-Syakur", "Yang Maha Mensyukuri", "The Appreciative"),
        teks("الْعَلِيُّ", "Al-'Aliyy", "Yang Maha Tinggi", "The Most High"),
        teks("الْكَبِيرُ", "Al-Kabir", "Yang Maha Besar", "The Most Great"),
        teks("الْحَفِيظُ", "Al-Hafizh", "Yang Maha Menjaga", "The Preserver"),
        teks("الْمُقِيتُ", "Al-Muqit", "Yang Maha Pemberi Kecukupan", "The Sustainer"),
        teks("الْحَسِيبُ", "Al-Hasib", "Yang Maha Membuat Perhitungan", "The Reckoner"),
        teks("الْجَلِيلُ", "Al-Jalil", "Yang Maha Luhur", "The Majestic"),
        teks("الْكَرِيمُ", "Al-Karim", "Yang Maha Mulia", "The Most Generous"),
        teks("الرَّقِيبُ", "Ar-Raqib", "Yang Maha Mengawasi", "The Watchful"),
        teks("الْمُجِيبُ", "Al-Mujib", "Yang Maha Mengabulkan", "The Responsive"),
        teks("الْوَاسِعُ", "Al-Wasi'", "Yang Maha Luas", "The All-Encompassing"),
        teks("الْحَكِيمُ", "Al-Hakim", "Yang Maha Bijaksana", "The All-Wise"),
        teks("الْوَدُودُ", "Al-Wadud", "Yang Maha Mencintai", "The Loving"),
        teks("الْمَجِيدُ", "Al-Majid", "Yang Maha Mulia", "The Glorious"),
        teks("الْبَاعِثُ", "Al-Ba'its", "Yang Maha Membangkitkan", "The Resurrector"),
        teks("الشَّهِيدُ", "Asy-Syahid", "Yang Maha Menyaksikan", "The Witness"),
        teks("الْحَقُّ", "Al-Haqq", "Yang Maha Benar", "The Truth"),
        teks("الْوَكِيلُ", "Al-Wakil", "Yang Maha Memelihara Urusan", "The Trustee"),
        teks("الْقَوِيُّ", "Al-Qawiyy", "Yang Maha Kuat", "The Most Strong"),
        teks("الْمَتِينُ", "Al-Matin", "Yang Maha Kokoh", "The Firm"),
        teks("الْوَلِيُّ", "Al-Waliyy", "Yang Maha Melindungi", "The Protecting Friend"),
        teks("الْحَمِيدُ", "Al-Hamid", "Yang Maha Terpuji", "The Praiseworthy"),
        teks("الْمُحْصِي", "Al-Muhshi", "Yang Maha Menghitung", "The Accounter"),
        teks("الْمُبْدِئُ", "Al-Mubdi'", "Yang Maha Memulai", "The Originator"),
        teks("الْمُعِيدُ", "Al-Mu'id", "Yang Maha Mengembalikan", "The Restorer"),
        teks("الْمُحْيِي", "Al-Muhyi", "Yang Maha Menghidupkan", "The Giver of Life"),
        teks("الْمُمِيتُ", "Al-Mumit", "Yang Maha Mematikan", "The Bringer of Death"),
        teks("الْحَيُّ", "Al-Hayy", "Yang Maha Hidup", "The Ever-Living"),
        teks("الْقَيُّومُ", "Al-Qayyum", "Yang Maha Berdiri Sendiri", "The Self-Subsisting"),
        teks("الْوَاجِدُ", "Al-Wajid", "Yang Maha Menemukan", "The Perceiver"),
        teks("الْمَاجِدُ", "Al-Maajid", "Yang Maha Mulia", "The Noble"),
        teks("الْوَاحِدُ", "Al-Wahid", "Yang Maha Esa", "The One"),
        teks("الْأَحَدُ", "Al-Ahad", "Yang Maha Tunggal", "The Unique"),
        teks("الصَّمَدُ", "Ash-Shamad", "Yang Maha Dibutuhkan", "The Eternal Refuge"),
        teks("الْقَادِرُ", "Al-Qadir", "Yang Maha Kuasa", "The Able"),
        teks("الْمُقْتَدِرُ", "Al-Muqtadir", "Yang Maha Berkuasa", "The Powerful"),
        teks("الْمُقَدِّمُ", "Al-Muqaddim", "Yang Maha Mendahulukan", "The Expediter"),
        teks("الْمُؤَخِّرُ", "Al-Mu'akhkhir", "Yang Maha Mengakhirkan", "The Delayer"),
        teks("الْأَوَّلُ", "Al-Awwal", "Yang Maha Awal", "The First"),
        teks("الْآخِرُ", "Al-Akhir", "Yang Maha Akhir", "The Last"),
        teks("الظَّاهِرُ", "Azh-Zhahir", "Yang Maha Nyata", "The Manifest"),
        teks("الْبَاطِنُ", "Al-Bathin", "Yang Maha Tersembunyi", "The Hidden"),
        teks("الْوَالِي", "Al-Wali", "Yang Maha Memerintah", "The Governor"),
        teks("الْمُتَعَالِي", "Al-Muta'ali", "Yang Maha Tinggi", "The Self Exalted"),
        teks("الْبَرُّ", "Al-Barr", "Yang Maha Dermawan", "The Source of Goodness"),
        teks("التَّوَّابُ", "At-Tawwab", "Yang Maha Penerima Tobat", "The Ever-Accepting of Repentance"),
        teks("الْمُنْتَقِمُ", "Al-Muntaqim", "Yang Maha Memberi Balasan", "The Avenger"),
        teks("الْعَفُوُّ", "Al-'Afuww", "Yang Maha Pemaaf", "The Pardoner"),
        teks("الرَّءُوفُ", "Ar-Ra'uf", "Yang Maha Pengasih dan Penyantun", "The Compassionate"),
        teks("مَالِكُ الْمُلْكِ", "Malikul-Mulk", "Penguasa Segala Kerajaan", "Owner of All Sovereignty"),
        teks("ذُو الْجَلَالِ وَالْإِكْرَامِ", "Dzul-Jalali wal-Ikram", "Pemilik Keagungan dan Kemuliaan", "Lord of Majesty and Generosity"),
        teks("الْمُقْسِطُ", "Al-Muqsith", "Yang Maha Adil", "The Equitable"),
        teks("الْجَامِعُ", "Al-Jami'", "Yang Maha Mengumpulkan", "The Gatherer"),
        teks("الْغَنِيُّ", "Al-Ghaniyy", "Yang Maha Kaya", "The Self-Sufficient"),
        teks("الْمُغْنِي", "Al-Mughni", "Yang Maha Memberi Kekayaan", "The Enricher"),
        teks("الْمَانِعُ", "Al-Mani'", "Yang Maha Mencegah", "The Preventer"),
        teks("الضَّارُّ", "Adh-Dharr", "Yang Maha Memberi Mudarat", "The Distresser"),
        teks("النَّافِعُ", "An-Nafi'", "Yang Maha Memberi Manfaat", "The Benefactor"),
        teks("النُّورُ", "An-Nur", "Yang Maha Bercahaya", "The Light"),
        teks("الْهَادِي", "Al-Hadi", "Yang Maha Pemberi Petunjuk", "The Guide"),
        teks("الْبَدِيعُ", "Al-Badi'", "Yang Maha Pencipta Tanpa Contoh", "The Incomparable Originator"),
        teks("الْبَاقِي", "Al-Baqi", "Yang Maha Kekal", "The Ever-Enduring"),
        teks("الْوَارِثُ", "Al-Warits", "Yang Maha Pewaris", "The Inheritor"),
        teks("الرَّشِيدُ", "Ar-Rasyid", "Yang Maha Membimbing", "The Guide to the Right Path"),
        teks("الصَّبُورُ", "Ash-Shabur", "Yang Maha Sabar", "The Patient")
    )

    /** Nomor urut (0-based) nama yang disebut ucapan, atau -1. Nama Latin dicocokkan tanpa tanda baca; kecocokan terpanjang menang. */
    fun cari(ucapan: String): Int {
        val q = normal(ucapan.replace("asmaul husna", " ").replace("asmaul husnah", " "))
        if (q.isEmpty()) return -1
        return daftar.indices.filter { q.contains(normal(daftar[it].latin)) }
            .maxByOrNull { normal(daftar[it].latin).length } ?: -1
    }

    fun normal(s: String): String = s.lowercase().replace(Regex("[^a-z0-9]"), "")

    /** Benar bila ucapan menyebut Asmaul Husna atau 99 nama Allah. */
    fun dikenali(ucapan: String): Boolean {
        val u = ucapan.lowercase()
        val n = normal(u)
        return n.contains("asmaulhusna") || n.contains("asmaulhusnah") || n.contains("asmaaulhusna") || n.contains("asmaalhusna") ||
            n.contains("asmaulhusn") || n.contains("asmaalhusna") || n.contains("asmaulhusna") ||
            n.contains("99namaallah") || n.contains("namanamaallah") || n.contains("namaallah") ||
            n.contains("99namesofallah") || n.contains("namesofallah") || n.contains("beautifulnames") ||
            n.contains("99nama")
    }
}
