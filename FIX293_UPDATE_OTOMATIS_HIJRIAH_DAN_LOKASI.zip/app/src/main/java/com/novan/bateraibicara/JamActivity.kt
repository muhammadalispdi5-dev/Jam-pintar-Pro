package com.novan.bateraibicara

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pengaturan kategori Jam: jadwal, format ucapan, dan suara. */
class JamActivity : Halaman() {

    override val judulHalaman = R.string.kategori_jam

    private lateinit var teksBerikut: TextView
    private lateinit var tombolHari: Button
    private lateinit var statusIzinAlarm: TextView

    // Urutan tampil Senin..Minggu -> nomor bit (0 = Minggu)
    private val urutanHari = intArrayOf(1, 2, 3, 4, 5, 6, 0)
    private val handlerPenyegarTimer = android.os.Handler(android.os.Looper.getMainLooper())
    private val pembaruanTimer = object : Runnable {
        override fun run() {
            if (kodeKelompok() == "timer" && ::teksStatusTimer.isInitialized) {
                segarkanTimer()
                handlerPenyegarTimer.postDelayed(this, 1000L)
            }
        }
    }

    override fun bangun() {
        when (kodeKelompok()) {
            "jadwal" -> grupJadwal()
            "ucapan" -> grupUcapan()
            "suara" -> grupSuara()
            "alarm" -> grupAlarm()
            "alarm_ubah" -> grupAlarmUbah()
            "timer" -> grupTimer()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        saklar(getString(R.string.sw_jam_on), prefs.jamOn) {
            prefs.jamOn = it
            berubah()
        }
        info(getString(R.string.info_jam))
                teksBerikut = info("")

        tombolKelompok("Jadwal pengucapan jam", "jadwal")
        tombolKelompok("Cara jam diucapkan", "ucapan")
        tombolKelompok(tr("Melodi, tes jam, dan suara", "Melody, clock test, and sound"), "suara")
        tombolKelompok(tr("Alarm jam", "Clock alarms"), "alarm")
        tombolKelompok(tr("Timer hitung mundur", "Countdown timer"), "timer")
    
        tombolResetPengaturan(tr("jam dan alarm jam", "clock and clock alarms")) {
                    hapusKunciPengaturan("pengaturan") { it.startsWith("jam_") }
                    val daftarAlarm = AlarmJam.muat(this)
                    daftarAlarm.forEach { alarm ->
                        AlarmJam.batalkanPending(this, alarm.id)
                        AlarmJam.hapusTunda(this, alarm.id)
                    }
                    getSharedPreferences("alarm_jam", MODE_PRIVATE).edit().clear().apply()
                    AlarmJam.jadwalkanSemua(this)
                    berubah()
                }
}

    private fun grupJadwal() {
        judulGrup("Jadwal pengucapan jam")
        // ----- Jadwal -----
        bagian(getString(R.string.bagian_jadwal))
        pilihan(getString(R.string.jam_mode), larik(R.array.jam_mode), prefs.jamMode) {
            prefs.jamMode = it
            berubah()
        }
        pilihan(getString(R.string.jam_interval), larik(R.array.jam_interval), prefs.jamIntervalIdx) {
            prefs.jamIntervalIdx = it
            berubah()
        }
        tombolJam(R.string.jam_mulai, { prefs.jamMulai }, { prefs.jamMulai = it; berubah() })
        tombolJam(R.string.jam_selesai, { prefs.jamSelesai }, { prefs.jamSelesai = it; berubah() })
        tombolHari = tombol("") { pilihHari() }
        segarkanHari()

    }

    private fun grupUcapan() {
        judulGrup("Cara jam diucapkan")
        // ----- Ucapan -----
        bagian(getString(R.string.bagian_ucapan_jam))
        pilihan(getString(R.string.jam_format), larik(R.array.jam_format), prefs.jamFormat) {
            prefs.jamFormat = it
            muatUlang()
        }
        bagian(getString(R.string.jam_disebut))
        saklar(getString(R.string.sw_ucap_jam), prefs.jamSebutJam) { prefs.jamSebutJam = it; muatUlang() }
        saklar(getString(R.string.sw_sebut_menit), prefs.jamSebutMenit) { prefs.jamSebutMenit = it; muatUlang() }
        saklar(getString(R.string.sw_sebut_detik), prefs.jamSebutDetik) {
            prefs.jamSebutDetik = it
            muatUlang()
        }
        // Tepat di awal dan tepat di akhir saling meniadakan; tampilan saklar lawannya ikut dimatikan.
        var saklarAwal: android.widget.Switch? = null
        var saklarAkhir: android.widget.Switch? = null
        saklarAwal = saklar(getString(R.string.sw_tepat_awal), prefs.jamTepatAwal) {
            prefs.jamTepatAwal = it
            if (it) {
                prefs.jamTepatAkhir = false
                saklarAkhir?.isChecked = false
            }
            muatUlang()
        }
        saklarAkhir = saklar(getString(R.string.sw_tepat_akhir), prefs.jamTepatAkhir) {
            prefs.jamTepatAkhir = it
            if (it) {
                prefs.jamTepatAwal = false
                saklarAwal?.isChecked = false
            }
            muatUlang()
        }
        info(getString(R.string.info_tepat_detik))
        saklar(getString(R.string.jam_sebut_periode), prefs.jamSebutPeriode) { prefs.jamSebutPeriode = it; muatUlang() }
        isian(getString(R.string.jam_awalan), prefs.jamAwalan, InputType.TYPE_CLASS_TEXT) {
            prefs.jamAwalan = it
            muatUlang()
        }
        info(getString(R.string.info_jam_awalan))

    }

    private fun grupSuara() {
        judulGrup(tr("Melodi, tes jam, dan suara", "Melody, clock test, and sound"))
        // ----- Suara -----
        bagian(getString(R.string.bagian_melodi_jam))
        val daftarMelodiJam = resources.getStringArray(R.array.jam_melodi)
        tombol(getString(R.string.jam_melodi_awal) + ": " + ui(daftarMelodiJam.getOrElse(prefs.jamMelodiAwal) { daftarMelodiJam.first() })) {
            pilihMelodiBertahap(
                getString(R.string.jam_melodi_awal), prefs.jamMelodiAwal,
                prefs.suara("jam").audioAttributes(), prefs.suara("jam").volumePersen / 100f
            ) {
                prefs.jamMelodiAwal = it
                berubah()
                recreate()
            }
        }
        tombol(getString(R.string.jam_melodi_akhir) + ": " + ui(daftarMelodiJam.getOrElse(prefs.jamMelodiAkhir) { daftarMelodiJam.first() })) {
            pilihMelodiBertahap(
                getString(R.string.jam_melodi_akhir), prefs.jamMelodiAkhir,
                prefs.suara("jam").audioAttributes(), prefs.suara("jam").volumePersen / 100f
            ) {
                prefs.jamMelodiAkhir = it
                berubah()
                recreate()
            }
        }
        // FIX264: berkas audio sendiri menggantikan melodi bawaan sebelum/sesudah pengumuman jam.
        tombolBerkasSendiri(tr("Audio sendiri sebelum jam", "Your own audio before the time"), "jam_awal", "jam")
        tombolBerkasSendiri(tr("Audio sendiri sesudah jam", "Your own audio after the time"), "jam_akhir", "jam")
        isian(getString(R.string.jam_jeda_awal), prefs.jamJedaAwal.toString(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL) {
            prefs.jamJedaAwal = it.replace(',', '.').toFloatOrNull() ?: 0f
        }
        isian(getString(R.string.jam_jeda_akhir), prefs.jamJedaAkhir.toString(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL) {
            prefs.jamJedaAkhir = it.replace(',', '.').toFloatOrNull() ?: 0f
        }
        isian(getString(R.string.jam_jeda_jam_menit), prefs.jamJedaJamMenit.toString(), android.text.InputType.TYPE_CLASS_NUMBER) {
            prefs.jamJedaJamMenit = it.toIntOrNull() ?: 300
        }
        tombol(getString(R.string.jam_tes_lengkap)) { tesJamLengkap() }
        tombol(getString(R.string.jam_tes_ucapan_saja)) {
            // Waktu dibacakan oleh suara jam; tanggal, libur, dan info sholat oleh suara pembaca tanggal.
            val c = Calendar.getInstance()
            val waktu = JamWaktu.ucapan(prefs, c)
            val tanggal = JamWaktu.segmenTanggal(prefs, c)
            val pj = Pembicara(this, prefs.suara("jam")) { toast(it) }
            val pt = Pembicara(this, prefs.suara("tgl")) { toast(it) }
            val selesaiSemua = { pj.matikan(); pt.matikan() }
            val bacaTanggal = { if (tanggal.isEmpty()) selesaiSemua() else pt.ucapkanRangkaian(tanggal, 300L) { selesaiSemua() } }
            if (waktu.isBlank()) bacaTanggal() else pj.ucapkan(waktu, true) { bacaTanggal() }
        }
        tombol(getString(R.string.jam_izin_alarm)) { bukaIzinAlarm() }
        info(getString(R.string.jam_izin_alarm_info))
        statusIzinAlarm = info("")
        segarkanStatusIzinAlarm()

        blokSuara("jam") { JamWaktu.ucapan(prefs, Calendar.getInstance()) }
    }

    override fun onResume() {
        super.onResume()
        if (kodeKelompok() == "alarm" && ::wadahAlarm.isInitialized) isiDaftarAlarm()
        if (kodeKelompok() == "timer" && ::teksStatusTimer.isInitialized) {
            TimerJamService.kirim(this, TimerJamService.ACTION_PULIHKAN)
            segarkanTimer()
            window.decorView.postDelayed({ segarkanTimer() }, 350L)
            handlerPenyegarTimer.removeCallbacks(pembaruanTimer)
            handlerPenyegarTimer.post(pembaruanTimer)
        }
        segarkanBerikut()
        if (::statusIzinAlarm.isInitialized) segarkanStatusIzinAlarm()
    }

    override fun onPause() {
        handlerPenyegarTimer.removeCallbacks(pembaruanTimer)
        super.onPause()
    }

    private fun berubah() {
        muatUlang()
        segarkanBerikut()
    }

    private fun segarkanHari() {
        tombolHari.text = getString(R.string.jam_hari, JamWaktu.ringkasHari(prefs.jamHari))
    }

    private fun segarkanBerikut() {
        if (!::teksBerikut.isInitialized) return // hanya ada di halaman daftar utama
        val t = if (prefs.jamOn) JamWaktu.berikut(prefs, System.currentTimeMillis()) else null
        teksBerikut.text = if (t == null) {
            getString(R.string.jam_berikut_tidak_ada)
        } else {
            // Pratinjau jadwal adalah teks antarmuka, jadi ikuti bahasa tampilan,
            // bukan bahasa TTS yang dipilih secara terpisah untuk pengucapan jam.
            val bahasaTampilan = BahasaAplikasi.tampilan(this)
            val localeTampilan = if (bahasaTampilan == 1) Locale.ENGLISH else Locale("id", "ID")
            val f = SimpleDateFormat("EEEE, HH.mm", localeTampilan)
            var waktuTampil = f.format(Date(t))
            if (bahasaTampilan == 0) waktuTampil = waktuTampil.replace("Minggu", "Ahad")
            getString(R.string.jam_berikut, waktuTampil)
        }
    }


    private fun tesJamLengkap() {
        val c = Calendar.getInstance()
        val (pertama, menit) = JamWaktu.bagianUcapan(prefs, c)
        val tanggal = JamWaktu.segmenTanggal(prefs, c)
        val pembicara = Pembicara(this, prefs.suara("jam")) { toast(it) }
        val pembicaraTanggal = Pembicara(this, prefs.suara("tgl")) { toast(it) }
        val akhir: () -> Unit = {
            window.decorView.postDelayed({ Melodi.putarPilihan(this, prefs.jamMelodiAkhir, prefs.berkasSendiri("jam_akhir"), prefs.suara("jam").audioAttributes(), volume = prefs.suara("jam").volumePersen / 100f) { pembicara.matikan(); pembicaraTanggal.matikan() } }, (prefs.jamJedaAkhir * 1000).toLong())
        }
        val bacaTanggal: () -> Unit = { pembicaraTanggal.ucapkanRangkaian(tanggal, 300L) { akhir() } }
        val mulai: () -> Unit = {
            pembicara.ucapkan(pertama, true) {
                if (menit != null) window.decorView.postDelayed({ pembicara.ucapkan(menit, false) { window.decorView.postDelayed({ bacaTanggal() }, 300L) } }, prefs.jamJedaJamMenit.toLong())
                else if (tanggal.isNotEmpty()) window.decorView.postDelayed({ bacaTanggal() }, 300L) else akhir()
            }
        }
        if (prefs.jamMelodiAwal > 0 || prefs.berkasSendiri("jam_awal").isNotBlank()) {
            Melodi.putarPilihan(this, prefs.jamMelodiAwal, prefs.berkasSendiri("jam_awal"), prefs.suara("jam").audioAttributes(), volume = prefs.suara("jam").volumePersen / 100f) {
                window.decorView.postDelayed({ mulai() }, (prefs.jamJedaAwal * 1000).toLong())
            }
        } else mulai()
    }

    private fun segarkanStatusIzinAlarm() {
        val status = if (android.os.Build.VERSION.SDK_INT < 31) {
            tr("Status izin alarm tepat waktu: dikelola otomatis oleh Android pada versi ini.", "Exact alarm permission status: managed automatically by Android on this version.")
        } else {
            val am = getSystemService(android.app.AlarmManager::class.java)
            if (am?.canScheduleExactAlarms() == true) {
                tr("Status izin alarm tepat waktu: SUDAH DIIZINKAN.", "Exact alarm permission status: ALLOWED.")
            } else {
                tr("Status izin alarm tepat waktu: BELUM DIIZINKAN. Buka halaman izin Android, aktifkan jika tersedia, lalu kembali ke sini untuk memeriksa ulang.", "Exact alarm permission status: NOT ALLOWED. Open the Android permission page, turn it on if available, then return here to check again.")
            }
        }
        statusIzinAlarm.text = status
        statusIzinAlarm.contentDescription = status
    }

    private fun bukaIzinAlarm() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse(("package:" + (packageName))))) }
            catch (_: Exception) { startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS)) }
        } else {
            toast(R.string.jam_izin_alarm_info)
        }
    }

    // ====================================================================================
    // ALARM JAM (FIX75)
    // ====================================================================================

    private lateinit var wadahAlarm: LinearLayout
    private lateinit var teksAlarmBerikut: TextView

    // FIX161: tr(indonesia, english) kini diwarisi dari Halaman; definisi privat di sini bentrok dengan Halaman.tr.

    private fun grupAlarm() {
        judulGrup(tr("Alarm jam", "Clock alarms"))
        info(tr(
            "Buat beberapa alarm dengan jam, hari berulang, nama, jenis suara, tunda, dan getar. Alarm berbunyi tepat waktu walau layar mati dan tetap terpasang setelah HP dihidupkan ulang. Tekan Matikan atau Tunda pada notifikasi, atau telungkupkan HP untuk mematikan alarm.",
            "Create several alarms with time, repeat days, name, sound type, snooze, and vibration. Alarms ring on time even when the screen is off and stay scheduled after a restart. Press Turn off or Snooze in the notification, or turn the phone face down to stop the alarm."
        ))
        val pp = PrayerPrefs(this)
        saklar(tr("Hentikan alarm dengan menelungkupkan HP", "Stop alarms by turning the phone face down"), pp.stopAzanFaceDown) { aktif ->
            pp.stopAzanFaceDown = aktif
            toast(if (aktif) tr("Menelungkupkan HP akan mematikan alarm dan suara notifikasi lain.", "Turning the phone face down will stop alarms and other notification sounds.")
                  else tr("Penghentian suara dengan menelungkupkan HP dinonaktifkan.", "Stopping sounds by turning the phone face down is off."))
        }
        saklar(tr("Hentikan alarm dengan tombol volume", "Stop alarms with the volume buttons"), pp.stopDenganVolume) { aktif ->
            pp.stopDenganVolume = aktif
            toast(if (aktif) tr("Tombol volume atas atau bawah akan mematikan alarm dan suara notifikasi lain.", "The volume up or down button will stop alarms and other notification sounds.")
                  else tr("Penghentian suara dengan tombol volume dinonaktifkan.", "Stopping sounds with the volume buttons is off."))
        }
        info(tr(
            "Sakelar ini sama dengan sakelar di Pengaturan Sholat dan berlaku untuk semua suara notifikasi aplikasi. HP harus terdeteksi tidak telungkup lebih dahulu, lalu ditelungkupkan sekitar satu detik. Jika HP sudah telungkup saat alarm mulai, angkat lalu telungkupkan lagi.",
            "This switch is the same as the one in Prayer Settings and applies to all notification sounds of the app. The phone must first be detected as not face down, then turned face down for about one second. If the phone is already face down when the alarm starts, lift it and turn it face down again."
        ))
        teksAlarmBerikut = info("")
        tombol(tr("Tambah alarm", "Add alarm")) { tambahAlarm() }
        wadahAlarm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(wadahAlarm)
        isiDaftarAlarm()
    }

    /** Isi ulang daftar alarm; pembangun tampilan Halaman menulis ke [root], jadi root dialihkan sementara ke wadah. */
    private fun isiDaftarAlarm() {
        val asli = root
        wadahAlarm.removeAllViews()
        root = wadahAlarm
        try {
            val daftar = AlarmJam.muat(this)
            if (daftar.isEmpty()) info(tr("Belum ada alarm. Tekan Tambah alarm untuk membuatnya.", "No alarms yet. Press Add alarm to create one."))
            for (a in daftar) {
                var sw: android.widget.Switch? = null
                sw = saklar(AlarmJam.ringkas(this, a), a.aktif) { aktif ->
                    a.aktif = aktif
                    AlarmJam.perbarui(this, a)
                    sw?.text = ui(AlarmJam.ringkas(this, a))
                    segarkanAlarmBerikut()
                }
                tombol(tr("Ubah alarm ", "Edit alarm ") + JamWaktu.format(a.jam * 60 + a.menit)) { ubahAlarm(a.id) }
            }
        } finally {
            root = asli
        }
        segarkanAlarmBerikut()
    }

    private fun segarkanAlarmBerikut() {
        if (!::teksAlarmBerikut.isInitialized) return
        val b = AlarmJam.berikutan(this)
        teksAlarmBerikut.text = if (b == null) {
            tr("Tidak ada alarm yang aktif.", "No active alarms.")
        } else {
            val en = BahasaAplikasi.tampilan(this) == 1
            val f = SimpleDateFormat("EEEE, d MMM HH.mm", if (en) Locale.ENGLISH else Locale("id", "ID"))
            var waktu = f.format(Date(b.second))
            if (!en) waktu = waktu.replace("Minggu", "Ahad")
            tr("Alarm berikutnya: ", "Next alarm: ") + waktu + (if (b.first.label.isNotBlank()) " (" + b.first.label.trim() + ")" else "")
        }
    }

    private fun tambahAlarm() {
        val a = AlarmJam.baru(this)
        if (a == null) {
            toast(tr("Jumlah alarm sudah mencapai batas " + AlarmJam.BATAS_ALARM + ".", "The alarm limit of " + AlarmJam.BATAS_ALARM + " has been reached."))
            return
        }
        AlarmJam.perbarui(this, a)
        ubahAlarm(a.id)
    }

    private fun ubahAlarm(id: Int) {
        startActivity(android.content.Intent(this, JamActivity::class.java).putExtra("kelompok", "alarm_ubah").putExtra("alarm_id", id))
    }

    private fun grupAlarmUbah() {
        val id = intent.getIntExtra("alarm_id", -1)
        val a = AlarmJam.cari(this, id)
        if (a == null) { finish(); return }
        judulGrup(tr("Ubah alarm", "Edit alarm"))
        // Perubahan langsung disimpan dan dijadwalkan ulang, seperti halaman pengaturan lain di aplikasi.
        val simpan = { AlarmJam.perbarui(this, a) }

        saklar(tr("Alarm aktif", "Alarm on"), a.aktif) { a.aktif = it; simpan() }

        var tombolWaktu: Button? = null
        fun segarWaktu() {
            val teks = ui(tr("Waktu alarm: ", "Alarm time: ") + JamWaktu.format(a.jam * 60 + a.menit) + tr(". Ketuk untuk mengubah.", ". Tap to change."))
            tombolWaktu?.text = teks
            tombolWaktu?.contentDescription = teks
        }
        tombolWaktu = tombol("") {
            TimePickerDialog(this, { _, h, m ->
                a.jam = h
                a.menit = m
                simpan()
                segarWaktu()
            }, a.jam, a.menit, true).show()
        }
        segarWaktu()

        var tombolHariAlarm: Button? = null
        fun segarHariAlarm() {
            val teks = ui(tr("Hari: ", "Days: ") + AlarmJam.ringkasHari(this, a.hari) + tr(". Ketuk untuk mengubah.", ". Tap to change."))
            tombolHariAlarm?.text = teks
            tombolHariAlarm?.contentDescription = teks
        }
        tombolHariAlarm = tombol("") { pilihHariAlarm(a) { simpan(); segarHariAlarm() } }
        segarHariAlarm()
        info(tr("Tanpa hari yang dipilih, alarm berbunyi sekali saja pada waktu berikutnya lalu mati sendiri.", "With no days selected, the alarm rings once at the next occurrence and then turns itself off."))

        isian(tr("Nama alarm (opsional)", "Alarm name (optional)"), a.label,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) {
            a.label = it.trim().take(60)
            simpan()
        }

        pilihan(
            tr("Jenis suara alarm", "Alarm sound type"),
            listOf(
                tr("Nada alarm sistem", "System alarm tone"),
                tr("Ucapkan waktu dan nama alarm", "Speak the time and alarm name"),
                tr("Nada singkat lalu ucapan bergantian", "Short tone then speech, alternating")
            ),
            a.mode
        ) { a.mode = it; simpan() }
        info(tr(
            "Ucapan memakai pengaturan suara Jam (mesin suara, kecepatan, nada, dan saluran volume). Alarm sistem memakai volume Alarm di HP.",
            "Speech uses the Clock voice settings (engine, speed, pitch, and volume channel). The system tone uses the phone's Alarm volume."
        ))

        val nilaiTunda = intArrayOf(0, 5, 10, 15)
        pilihan(
            tr("Tunda", "Snooze"),
            listOf(tr("Tanpa tombol tunda", "No snooze button"), tr("5 menit", "5 minutes"), tr("10 menit", "10 minutes"), tr("15 menit", "15 minutes")),
            nilaiTunda.indexOf(a.tundaMenit).coerceAtLeast(0)
        ) { a.tundaMenit = nilaiTunda[it]; simpan() }

        saklar(tr("Getar saat alarm berbunyi", "Vibrate while the alarm rings"), a.getar) { a.getar = it; simpan() }

        info(tr(
            "Alarm berhenti sendiri setelah tiga menit dan meninggalkan notifikasi Alarm terlewat. Telungkupkan HP, atau tekan Matikan pada notifikasi, untuk menghentikannya lebih dulu.",
            "The alarm stops by itself after three minutes and leaves a Missed alarm notification. Turn the phone face down, or press Turn off in the notification, to stop it sooner."
        ))

        tombol(tr("Tes alarm sekarang", "Test alarm now")) {
            val layanan = android.content.Intent(this, AlarmJamService::class.java)
                .putExtra("alarm_id", a.id).putExtra("tes", true)
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(layanan) else startService(layanan)
            } catch (_: Exception) { toast(tr("Tes alarm tidak dapat dimulai.", "The alarm test could not start.")) }
        }

        tombol(tr("Hapus alarm ini", "Delete this alarm")) {
            AlertDialog.Builder(this)
                .setTitle(tr("Hapus alarm?", "Delete alarm?"))
                .setMessage(AlarmJam.ringkas(this, a))
                .setPositiveButton(tr("Hapus", "Delete")) { _, _ ->
                    AlarmJam.hapus(this, a.id)
                    finish()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }


    // ====================================================================================
    // TIMER HITUNG MUNDUR
    // ====================================================================================
    private lateinit var teksStatusTimer: TextView

    private fun grupTimer() {
        judulGrup(tr("Timer hitung mundur", "Countdown timer"))
        info(tr(
            "Atur hitung mundur dalam jam, menit, dan detik. Timer tetap berjalan saat layar mati atau Anda membuka aplikasi lain. Alarm dapat dihentikan dari notifikasi. Satu timer aktif pada satu waktu; memulai timer baru akan menggantikan hitung mundur sebelumnya.",
            "Set a countdown in hours, minutes, and seconds. The timer keeps running when the screen is off or you open another app. Stop the alarm from its notification. Only one timer runs at a time; starting a new timer replaces the previous countdown."
        ))
        bagian(tr("Status timer", "Timer status"))
        teksStatusTimer = info("")
        tombol(tr("Atur dan mulai timer", "Set and start timer")) { dialogDurasiTimer() }
        tombol(tr("Jeda timer", "Pause timer")) { TimerJamService.kirim(this, TimerJamService.ACTION_JEDA); window.decorView.postDelayed({ segarkanTimer() }, 250L) }
        tombol(tr("Lanjutkan timer", "Resume timer")) { TimerJamService.kirim(this, TimerJamService.ACTION_LANJUT); window.decorView.postDelayed({ segarkanTimer() }, 250L) }
        tombol(tr("Reset timer", "Reset timer")) {
            AlertDialog.Builder(this).setTitle(tr("Reset timer?", "Reset timer?"))
                .setMessage(tr("Hitung mundur akan dihentikan dan diatur ulang.", "The countdown will be stopped and reset."))
                .setPositiveButton(tr("Reset", "Reset")) { _, _ -> TimerJamService.kirim(this, TimerJamService.ACTION_RESET); window.decorView.postDelayed({ segarkanTimer() }, 350L) }
                .setNegativeButton(android.R.string.cancel, null).show()
        }
        tombol(tr("Hentikan alarm timer", "Stop timer alarm")) { TimerJamService.kirim(this, TimerJamService.ACTION_STOP_ALARM); window.decorView.postDelayed({ segarkanTimer() }, 300L) }
        bagian(tr("Pengaturan alarm timer", "Timer alarm settings"))
        val pengaturan = getSharedPreferences("timer_jam", MODE_PRIVATE)
        val mode = pengaturan.getInt("mode", 2)
        // FIX277: alarm timer dapat memakai nada alarm bawaan Android, suara pembaca (TTS), berkas audio sendiri, atau gabungannya.
        val namaMode = arrayOf(tr("Nada alarm bawaan Android", "Android default alarm tone"), tr("Suara pembaca (TTS)", "Speech (TTS)"),
            tr("Nada bawaan Android dan suara pembaca", "Android tone and speech"), tr("Berkas audio sendiri", "Own audio file"),
            tr("Berkas audio sendiri dan suara pembaca", "Own audio file and speech"))
        tombol(tr("Jenis alarm: ", "Alarm type: ") + namaMode[mode.coerceIn(0, 4)]) {
            AlertDialog.Builder(this).setTitle(tr("Pilih jenis alarm", "Choose alarm type")).setSingleChoiceItems(namaMode, pengaturan.getInt("mode", 2).coerceIn(0, 4)) { d, which ->
                pengaturan.edit().putInt("mode", which).apply(); d.dismiss(); muatUlang()
                if ((which == 3 || which == 4) && prefs.berkasSendiri("timer_alarm").isBlank()) toast(tr("Pilih berkas audio alarm timer di bawah ini. Sebelum dipilih, nada bawaan Android dipakai.", "Choose the timer alarm audio file below. Until then the Android default tone is used."))
            }.setNegativeButton(android.R.string.cancel, null).show()
        }
        tombolBerkasSendiri(tr("Berkas audio alarm timer", "Timer alarm audio file"), "timer_alarm", "jam")
        saklar(tr("Umumkan sisa waktu", "Announce remaining time"), pengaturan.getBoolean("pengumuman", true)) {
            pengaturan.edit().putBoolean("pengumuman", it).apply()
        }
        info(tr("Pengumuman sisa waktu diberikan pada sekitar satu menit, tiga puluh detik, dan sepuluh detik terakhir. Suara menggunakan mesin suara yang dipilih untuk Jam.", "Remaining time is announced at about one minute, thirty seconds, and during the final ten seconds. Speech uses the voice engine selected for Clock."))
        segarkanTimer()
    }

    private fun dialogDurasiTimer() {
        val wadah = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
        fun kolom(hint: String, label: String): EditText {
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                this.hint = hint
                contentDescription = label
                setSingleLine(true)
            }
            wadah.addView(e, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(6) })
            return e
        }
        val jam = kolom(tr("Jam", "Hours"), tr("Jam", "Hours"))
        val menit = kolom(tr("Menit", "Minutes"), tr("Menit", "Minutes"))
        val detik = kolom(tr("Detik", "Seconds"), tr("Detik", "Seconds"))
        menit.setText("5")
        AlertDialog.Builder(this).setTitle(tr("Atur durasi timer", "Set timer duration")).setView(wadah)
            .setPositiveButton(tr("Mulai", "Start")) { _, _ ->
                val h = jam.text.toString().toLongOrNull() ?: 0L
                val m = menit.text.toString().toLongOrNull() ?: 0L
                val d = detik.text.toString().toLongOrNull() ?: 0L
                val total = h * 3600L + m * 60L + d
                if (total <= 0L || total > 99L * 3600L + 59L * 60L + 59L) {
                    toast(tr("Masukkan durasi antara satu detik dan 99 jam 59 menit 59 detik.", "Enter a duration from one second to 99 hours, 59 minutes, and 59 seconds."))
                } else {
                    val p = getSharedPreferences("timer_jam", MODE_PRIVATE)
                    TimerJamService.kirim(this, TimerJamService.ACTION_MULAI, total * 1000L, p.getInt("mode", 2), p.getBoolean("pengumuman", true))
                    window.decorView.postDelayed({ segarkanTimer() }, 350L)
                }
            }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun segarkanTimer() {
        if (!::teksStatusTimer.isInitialized) return
        val status = TimerJamService.status(this)
        val sisa = TimerJamService.sisa(this)
        val total = (sisa + 999L) / 1000L
        val h = total / 3600L; val m = total % 3600L / 60L; val d = total % 60L
        val waktu = if (h > 0) "%02d:%02d:%02d".format(h, m, d) else "%02d:%02d".format(m, d)
        teksStatusTimer.text = when (status) {
            TimerJamService.STATE_RUNNING -> tr("Timer berjalan. Sisa waktu: ", "Timer running. Time remaining: ") + waktu
            TimerJamService.STATE_PAUSED -> tr("Timer dijeda. Sisa waktu: ", "Timer paused. Time remaining: ") + waktu
            TimerJamService.STATE_ALARM -> tr("Waktu timer telah habis. Alarm sedang berbunyi.", "Timer has finished. Alarm is sounding.")
            else -> tr("Timer belum dijalankan.", "Timer is not running.")
        }
        teksStatusTimer.contentDescription = teksStatusTimer.text
    }

    private fun pilihHariAlarm(a: ItemAlarm, selesai: () -> Unit) {
        val nama = larik(R.array.nama_hari).toTypedArray()
        var mask = a.hari
        val dicentang = BooleanArray(7) { (mask and (1 shl urutanHari[it])) != 0 }
        AlertDialog.Builder(this)
            .setTitle(tr("Hari alarm berulang", "Repeat days"))
            .setMultiChoiceItems(nama, dicentang) { _, which, centang ->
                val bit = 1 shl urutanHari[which]
                mask = if (centang) (mask or bit) else (mask and bit.inv())
            }
            .setPositiveButton(android.R.string.ok) { _, _ -> a.hari = mask and 127; selesai() }
            .setNeutralButton(tr("Sekali saja", "Once only")) { _, _ -> a.hari = 0; selesai() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun pilihHari() {
        val nama = larik(R.array.nama_hari).toTypedArray()
        var mask = prefs.jamHari
        val dicentang = BooleanArray(7) { (mask and (1 shl urutanHari[it])) != 0 }
        AlertDialog.Builder(this)
            .setTitle(R.string.jam_pilih_hari)
            .setMultiChoiceItems(nama, dicentang) { _, which, centang ->
                val bit = 1 shl urutanHari[which]
                mask = if (centang) (mask or bit) else (mask and bit.inv())
            }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.jamHari = mask
                segarkanHari()
                berubah()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
