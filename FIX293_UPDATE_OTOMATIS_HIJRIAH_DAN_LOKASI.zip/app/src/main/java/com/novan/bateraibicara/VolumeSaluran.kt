package com.novan.bateraibicara

import android.content.Context

/**
 * FIX279: volume pengumuman (Nama Panggilan dan Pembacaan Notifikasi) TIDAK lagi mengubah volume saluran suara HP
 * (dering, notifikasi, alarm, media, dan lainnya). Volume HP sepenuhnya milik sistem; volume pengumuman hanya
 * menjadi pengali (gain) pada suara aplikasi sendiri: ucapan memakai parameter volume mesin suara dan melodi memakai
 * volume pemutar. Objek ini dipertahankan hanya agar pemanggil lama tetap kompatibel dan tidak menyentuh volume sistem.
 */
object VolumeSaluran {
    @Suppress("UNUSED_PARAMETER")
    fun pinjam(ctx: Context, streamType: Int, persen: Int) { }

    @Suppress("UNUSED_PARAMETER")
    fun lepas(ctx: Context) { }
}
