package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/** Pemutar melodi yang dipulihkan dari APK sumber. Indeks 0 berarti mati. */
object Melodi {
    private val handler = Handler(Looper.getMainLooper())
    private val aktif = HashSet<MediaPlayer>()
    private val audio = intArrayOf(
        0, R.raw.melodi_01, R.raw.melodi_02, R.raw.melodi_03, R.raw.melodi_04,
        R.raw.melodi_05, R.raw.melodi_06, R.raw.melodi_07, R.raw.melodi_08,
        R.raw.melodi_09, R.raw.melodi_10, R.raw.melodi_11, R.raw.melodi_12,
        R.raw.melodi_13, R.raw.melodi_14, R.raw.melodi_15, R.raw.melodi_16,
        R.raw.sirine_pengguna
    )

    /**
     * Memutar melodi lewat saluran volume pilihan pengguna ([atribut]; null = volume media).
     * Atribut dipasang sebelum sumber data/prepare agar benar-benar dipakai sistem
     * (MediaPlayer.create() langsung prepare sehingga atribut sesudahnya diabaikan).
     */
    fun putar(context: Context, pilihan: Int, atribut: AudioAttributes? = null, volume: Float = 1.0f, selesai: (() -> Unit)? = null) {
        if (pilihan <= 0 || pilihan >= audio.size) {
            selesai?.invoke()
            return
        }
        try {
            val app = context.applicationContext
            val attrs = AudioAttributes.Builder()
                .setUsage(atribut?.usage ?: AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            val player = MediaPlayer()
            synchronized(aktif) { aktif.add(player) }
            try {
                player.setAudioAttributes(attrs)
                val afd = app.resources.openRawResourceFd(audio[pilihan])
                try { player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                player.setOnCompletionListener {
                    synchronized(aktif) { aktif.remove(it) }
                    try { it.release() } catch (_: Exception) { }
                    selesai?.invoke()
                }
                player.setOnErrorListener { mp, _, _ ->
                    synchronized(aktif) { aktif.remove(mp) }
                    try { mp.release() } catch (_: Exception) { }
                    selesai?.invoke()
                    true
                }
                player.setVolume(volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f))
                player.prepare()
                player.start()
            } catch (e: Exception) {
                synchronized(aktif) { aktif.remove(player) }
                try { player.release() } catch (_: Exception) { }
                selesai?.invoke()
            }
        } catch (_: Exception) { selesai?.invoke() }
    }

    /**
     * FIX264: memutar berkas audio pilihan pengguna ([uri] content:// atau file://) lewat saluran yang sama dengan melodi.
     * [gagal] dipanggil bila berkas tidak dapat dibuka atau diputar (mis. izin dicabut atau berkas dihapus).
     */
    fun putarUri(context: Context, uri: String, atribut: AudioAttributes? = null, volume: Float = 1.0f, selesai: (() -> Unit)? = null, gagal: (() -> Unit)? = null) {
        val player = MediaPlayer()
        synchronized(aktif) { aktif.add(player) }
        var selesaiDipanggil = false
        fun akhiri(berhasil: Boolean) {
            if (selesaiDipanggil) return
            selesaiDipanggil = true
            synchronized(aktif) { aktif.remove(player) }
            try { player.release() } catch (_: Exception) { }
            if (berhasil) selesai?.invoke() else (gagal ?: selesai)?.invoke()
        }
        try {
            player.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(atribut?.usage ?: AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.setDataSource(context.applicationContext, android.net.Uri.parse(uri))
            player.setOnCompletionListener { akhiri(true) }
            player.setOnErrorListener { _, _, _ -> akhiri(false); true }
            val v = volume.coerceIn(0f, 1f)
            player.setVolume(v, v)
            player.prepare()
            player.start()
        } catch (_: Exception) { akhiri(false) }
    }

    /** FIX264: berkas pengguna (bila ada) menggantikan melodi bawaan [pilihan]; bila berkas gagal, melodi bawaan dipakai. */
    fun putarPilihan(context: Context, pilihan: Int, berkas: String, atribut: AudioAttributes? = null, volume: Float = 1.0f, selesai: (() -> Unit)? = null) {
        if (berkas.isNotBlank()) {
            putarUri(context, berkas, atribut, volume, selesai) { putar(context, pilihan, atribut, volume, selesai) }
        } else putar(context, pilihan, atribut, volume, selesai)
    }

    /** FIX74: hentikan semua melodi yang sedang berbunyi tanpa memanggil kelanjutan rangkaian pengumumannya. */
    fun hentikanSemua() {
        val salinan = synchronized(aktif) { val x = ArrayList(aktif); aktif.clear(); x }
        for (p in salinan) {
            try { p.setOnCompletionListener(null) } catch (_: Exception) { }
            try { p.setOnErrorListener(null) } catch (_: Exception) { }
            try { p.stop() } catch (_: Exception) { }
            try { p.release() } catch (_: Exception) { }
        }
    }

    /** FIX279: true bila ada melodi yang masih tercatat aktif. */
    fun sedangMemutar(): Boolean = synchronized(aktif) { aktif.isNotEmpty() }

    /** FIX242: jeda semua melodi yang sedang berbunyi (dipakai tes suara pengingat saat fase melodi). */
    fun jedaSemua(): Boolean {
        val salinan = synchronized(aktif) { ArrayList(aktif) }
        var ada = false
        for (p in salinan) { try { if (p.isPlaying) { p.pause(); ada = true } } catch (_: Exception) { } }
        return ada
    }

    /** FIX242: lanjutkan melodi yang tadi dijeda dari posisi terakhir. */
    fun lanjutSemua() {
        val salinan = synchronized(aktif) { ArrayList(aktif) }
        for (p in salinan) { try { if (!p.isPlaying) p.start() } catch (_: Exception) { } }
    }

    /** Nada singkat untuk fitur nama pemanggil. */
    fun bunyikan(context: Context, durasiMs: Int = 180) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
            val d = durasiMs.coerceIn(80, 800)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, d)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) { } }, d.toLong() + 100)
        } catch (_: Exception) { }
    }
}
