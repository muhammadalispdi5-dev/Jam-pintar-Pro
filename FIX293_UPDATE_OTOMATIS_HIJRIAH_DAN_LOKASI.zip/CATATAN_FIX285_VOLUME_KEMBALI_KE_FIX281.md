# FIX285 (versi tetap 1.0.89)
Mekanisme volume dikembalikan ke FIX281:
- VolumeSaluran.kt, PemanggilActivity.kt, Prefs.kt, CallerListener.kt dipulihkan dari FIX281 (tanpa kurva persepsi, tanpa sakelar fokus, tanpa teks tambahan FIX284).
- Pembicara: pengali volume linear (persen/100) lewat KEY_PARAM_VOLUME seperti FIX281; render-ke-berkas dibatasi hanya untuk efek gema Jam/Baterai.
- Dihapus: RedamDering (FIX283), sakelar "Turunkan audio lain" (FIX284), kurva kuadrat dan render karena volume (FIX282). Petunjuk ID 59 / EN 56 ditulis ulang (butir 60-61 / 57-58 dihapus).
Dipertahankan: jeda baterai 10/15 menit, iqomah satu kali, gema Jam/Baterai lewat pemutar sendiri, pemulihan mesin suara bila macet beserta kelanjutan antrean.
Belum dikompilasi dengan Gradle, belum diuji di perangkat.
