# FIX286 (versi tetap 1.0.89)
- Prefs.Suara.turunkanAudioLain (bawaan aktif, per profil suara; ikut tanda() agar Pembicara dibuat ulang saat diubah).
- Pembicara.mintaFokus dilewati bila dimatikan; bila aktif tetap meminta fokus MAY_DUCK seperti sebelumnya (tidak mengubah volume HP).
- Halaman.dialogVolumeDanEfek: kotak centang "Turunkan audio lain saat berbicara" + keterangan, tersedia untuk semua Suara (pengumuman Nama Panggilan/Notifikasi, Jam, Baterai, dll.). Judul dialog menyesuaikan.
- Petunjuk ID 60 / EN 57; tools/uji_turunkan_audio_lain.py. Belum dikompilasi Gradle, belum diuji di perangkat. Pengingat sholat/azan yang memakai layanan sendiri tidak terpengaruh.
