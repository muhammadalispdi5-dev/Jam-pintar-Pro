# Panduan menerbitkan pembaruan otomatis lewat GitHub (FIX291)

Pola sama dengan Apktool M: aplikasi mengambil `updates/update_<bahasa>.json?t=<waktu>` dari repositori publik, membandingkan `versionCode`, lalu mengunduh APK dan memasangnya.

## Sekali saja
1. Pastikan repositori PUBLIK dan namanya sama dengan `githubRepo` di app/build.gradle.kts (sekarang: muhammadalispdi5-dev/Jam-pintar-Bro), atau bangun dengan -PGITHUB_REPO=pemilik/repo. Cabang bernama `main`.
2. Salin folder CONTOH_REPOSITORI_PEMBARUAN (updates/ dan files/) ke akar repositori.
3. Bangun dan pasang dulu versi aplikasi yang sudah memuat fitur ini (FIX290/291). Pembaruan hanya bisa diterima oleh versi ini ke atas.
4. Tanda tangani setiap APK dengan KUNCI YANG SAMA (keystore yang sama) selamanya; bila berbeda, Android menolak pembaruan.

## Setiap rilis
1. Naikkan versionCode dan versionName di app/build.gradle.kts, bangun APK rilis bertanda tangan.
2. Ganti files/JamPintarPro.apk dengan APK baru (commit dan push).
3. Ubah updates/update_id.json dan update_en.json: versionCode (sama dengan APK), versionName, date, size, changes. Push SETELAH APK terunggah.
4. Pengguna: saklar "Periksa pembaruan otomatis" memeriksa setiap 12 jam, atau ketuk "Periksa pembaruan". Mereka mengetuk Unduh dan pasang, lalu Pasang pada konfirmasi Android.

Opsional: "apkUrl" di JSON (boleh per arsitektur, mis. {"arm64-v8a":"https://...","default":"https://..."}) bila APK ada di tempat lain, mis. GitHub Releases. Bila repositori tidak punya updates/, aplikasi memakai rilis terbaru (Releases): beri tag 1.0.90 dan lampirkan APK.
