# FIX272 — Asmaul Husna + pemeriksaan Jenis panggilan dan pengulangan

Asmaul Husna (baru): AsmaulHusnaData.kt (99 nama: Arab, Latin, arti ID/EN), AsmaulHusnaActivity.kt (cari, bacakan semua Latin+arti atau Arab, daftar 99, halaman nama, salin, bagikan, sebelumnya/berikutnya), menu utama tepat sebelum Taaruf Doa, manifest, string ID/EN, asisten suara (ASMAUL_HUSNA, "buka Asmaul Husna [nama]"), petunjuk item 51 (ID) / 48 (EN), tools/uji_asmaul_husna.py.

Jenis panggilan dan pengulangan: alur dibaca ulang (deteksi panggilan, susun kalimat, jeda, batas ulang, melodi awal/akhir, volume per sumber, berhenti saat dijawab/ditelungkupkan). Tidak ditemukan cacat; tidak ada perubahan kode di sana. Belum diuji di perangkat.

Versi tetap 1.0.89. Belum dikompilasi dengan Gradle.
