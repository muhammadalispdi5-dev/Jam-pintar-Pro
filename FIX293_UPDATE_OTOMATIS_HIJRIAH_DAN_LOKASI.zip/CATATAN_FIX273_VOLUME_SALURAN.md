# FIX273 — Volume pengumuman mengikuti saluran suara pilihan

Masalah: volume di Pengaturan volume pengumuman hanya berupa pengali (gain) pada saluran yang dipilih, sehingga tidak dapat menaikkan volume di atas volume saluran HP dan terasa tidak berfungsi.

Perbaikan:
- VolumeSaluran.kt (baru): memasang volume saluran (media/alarm/notifikasi/dering/aksesibilitas/panggilan suara/sistem) ke persen pilihan saat pengumuman mulai, lalu mengembalikannya (tunda 2,5 dtk, hitung pakai pinjam/lepas; tidak menimpa bila pengguna mengubah volume sendiri; SecurityException saat Jangan Ganggu diabaikan).
- Pembicara.kt: volumeSaluran; pinjam saat berbicara, lepas di selesaiBicara; gain 100% saat volume saluran dipasang.
- CallerListener.kt: putarMelodiSaluran untuk melodi awal/akhir (4 tempat); pembicara menerima volumeSaluran per sumber.
- Prefs.volumeSaluranPem: -1 bila belum digeser (volume HP tidak diubah).
- Halaman.tesSuaraVolume ikut memasang volume saluran; halaman volume menyebut saluran terpilih.
- Petunjuk item 52 (ID) / 49 (EN). tools/uji_volume_saluran.py.

Versi tetap 1.0.89. Belum dikompilasi dengan Gradle dan belum diuji di perangkat. Bila proses aplikasi dihentikan paksa tepat saat pengumuman, volume saluran bisa tertinggal di nilai pengumuman.

## FIX274
Volume mandiri profil pemanggil (Suara pengumuman) dihapus: Prefs.volumePersen untuk "pem" selalu 100; dialog hanya Efek vokal; info menunjuk ke Pengaturan volume pengumuman. Petunjuk item 52/49 diperluas.
