#!/usr/bin/env python3
"""FIX272: Asmaul Husna harus 99 nama, terdaftar di manifest, menu utama, asisten suara, string, dan petunjuk."""
from pathlib import Path
import re
R = Path(__file__).resolve().parents[1]
J = R / "app/src/main/java/com/novan/bateraibicara"
def t(p): return (R / p).read_text(encoding="utf-8")
gagal = []
data = (J / "AsmaulHusnaData.kt").read_text(encoding="utf-8")
baris = re.findall(r'^\s+teks\("([^"]+)", "([^"]+)", "([^"]+)", "([^"]+)"\)', data, re.M)
if len(baris) != 99: gagal.append(f"GAGAL jumlah nama {len(baris)} bukan 99")
if len({b[1] for b in baris}) != 99: gagal.append("GAGAL ada nama Latin ganda")
if any(not re.search(r"[؀-ۿ]", b[0]) for b in baris): gagal.append("GAGAL ada teks Arab kosong")
if "AsmaulHusnaActivity" not in t("app/src/main/AndroidManifest.xml"): gagal.append("GAGAL manifest")
if "AsmaulHusnaActivity::class.java" not in (J / "MainActivity.kt").read_text(encoding="utf-8"): gagal.append("GAGAL menu utama")
v = (J / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
for k in ("ASMAUL_HUSNA", "AsmaulHusnaData.dikenali", "AsmaulHusnaActivity::class.java"):
    if k not in v: gagal.append("GAGAL asisten suara: " + k)
for loc in ("values", "values-en"):
    s = t(f"app/src/main/res/{loc}/strings.xml")
    for k in ("judul_asmaul_husna", "menu_asmaul_husna"):
        if f'name="{k}"' not in s: gagal.append(f"GAGAL {loc} {k}")
    if "Asmaul Husna" not in s[s.index("isi_petunjuk_penggunaan_lanjutan"):]: gagal.append(f"GAGAL petunjuk {loc}")
print("\n".join(gagal) if gagal else "UJI ASMAUL HUSNA: LULUS (99 nama, manifest, menu, asisten suara, string, petunjuk)")
