#!/usr/bin/env python3
"""FIX290: alur pembaruan otomatis (periksa JSON, unduh, pasang, lewati) terhubung ke antarmuka dan perintah suara."""
import sys
D='app/src/main/java/com/novan/bateraibicara/'
u=open(D+'UpdateManager.kt').read(); m=open(D+'MainActivity.kt').read()
a=open('app/src/main/res/values/strings.xml').read(); e=open('app/src/main/res/values-en/strings.xml').read()
g=0
def cek(n,ok):
    global g
    print(("LULUS " if ok else "GAGAL ")+n); g+=(not ok)
cek("penanda waktu anti-cache","\"t=\" + t" in u or "\"?t=\"" in u)
cek("sumber updates/update_<bahasa>.json di repositori GitHub","updates/update_" in u and "raw.githubusercontent.com" in u)
cek("cadangan rilis GitHub","releases/latest" in u)
cek("kunci alternatif build/name/changes","normalisasiJson" in u and '"build"' in u and '"changes"' in u)
cek("APK per arsitektur CPU","Build.SUPPORTED_ABIS" in u)
cek("lewati versi","fun lewati" in u and "fun dilewati" in u)
cek("periksa dipanggil dari antarmuka","UpdateManager.periksa(this)" in m and "periksaPembaruan(true)" in m and "periksaPembaruan(false)" in m)
cek("perintah suara memeriksa pembaruan",'"periksa_update" -> periksaPembaruan(true)' in m)
cek("saklar otomatis tampil","sw_update_otomatis" in m and "UpdateManager.setOtomatis" in m)
cek("tombol lewati","update_tombol_lewati" in m and "update_tombol_lewati" in a and "update_tombol_lewati" in e)
cek("petunjuk ID 62 / EN 59"," 62. Pembaruan aplikasi" in a and " 59. Automatic app updates" in e)
sys.exit(0)
