#!/usr/bin/env python3
"""FIX279: volume pengumuman hanya pengali suara aplikasi; TIDAK boleh mengubah volume saluran HP."""
from pathlib import Path
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
def t(n): return (R / n).read_text(encoding="utf-8")
g = []
if "setStreamVolume" in t("VolumeSaluran.kt"): g.append("GAGAL VolumeSaluran masih mengubah volume sistem")
for k in ("VolumeSaluran.pinjam", "VolumeSaluran.lepas", "saluranDipinjam"):
    if k in t("Pembicara.kt") or k in t("CallerListener.kt"): g.append("GAGAL masih memakai " + k)
if "volumeSaluran in 0..100) volumeSaluran" not in t("Pembicara.kt"): g.append("GAGAL Pembicara tidak memakai volume sebagai pengali")
c = t("CallerListener.kt")
if "v / 100f" not in c: g.append("GAGAL melodi tidak memakai pengali")
if "batasDeringRunnable" not in c: g.append("GAGAL batas dering 150 detik")
s = t("PrayerAlarmService.kt")
for k in ("tambahKendaliPutar", "jagaLayanan", "cancel(809)"):
    if k not in s: g.append("GAGAL layanan: " + k)
print("\n".join(g) if g else "UJI VOLUME SALURAN: LULUS")
