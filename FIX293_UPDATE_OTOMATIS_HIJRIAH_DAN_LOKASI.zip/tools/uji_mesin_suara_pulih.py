from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
p=(R/"Pembicara.kt").read_text(encoding="utf-8")
g=[]
for k in ("fun pulihkanMesin","pulihBeruntun","val tertunda = ArrayList(callbacks.values)","panggil || item != null","gemaAktif()"):
    if k not in p: g.append("GAGAL Pembicara: "+k)
if "gain < 0.97f" in p: g.append("GAGAL render karena volume masih ada")
if (R/"RedamDering.kt").exists(): g.append("GAGAL RedamDering.kt")
print("\n".join(g) if g else "UJI MESIN SUARA PULIH: LULUS")
