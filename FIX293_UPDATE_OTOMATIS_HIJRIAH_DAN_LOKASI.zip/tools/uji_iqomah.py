#!/usr/bin/env python3
"""FIX277: iqomah (audio, jadwal, penerima, layanan, pengaturan), ulang ucapan terputus, alarm timer berkas sendiri."""
from pathlib import Path
R = Path(__file__).resolve().parents[1]
J = R / "app/src/main/java/com/novan/bateraibicara"
def t(n): return (J / n).read_text(encoding="utf-8")
g = []
if not (R / "app/src/main/res/raw/iqomah_masjidil_haram.mp3").exists(): g.append("GAGAL audio iqomah")
for n, ks in {
    "PrayerPrefs.kt": ("iqomahAktif", "iqomahMenit", "PILIHAN_IQOMAH"),
    "PrayerAlarm.kt": ("430 + index", "iqomah_reminder", "request in 430..434"),
    "PrayerAlarmReceiver.kt": ("iqomah_reminder", "iqomahAktif"),
    "PrayerAlarmService.kt": ("R.raw.iqomah_masjidil_haram", "\"iqomah_\" + key", "startForeground(809, notifIq)"),
    "PrayerSettingsActivity.kt": ("grupIqomah", "tesIqomah", "\"iqomah\" -> grupIqomah"),
    "Pembicara.kt": ("private fun terputus", "dalamProses", "tugasUlang"),
    "TimerJamService.kt": ("berkasSendiri(\"timer_alarm\")", "PembungkamTelungkup.mulai(this, \"timer_alarm\""),
    "JamActivity.kt": ("tombolBerkasSendiri(tr(\"Berkas audio alarm timer\""),
    "VolumeSaluran.kt": ("object VolumeSaluran",),
}.items():
    s = t(n)
    for k in ks:
        if k not in s: g.append(f"GAGAL {n}: {k}")
for loc in ("values", "values-en"):
    s = (R / f"app/src/main/res/{loc}/strings.xml").read_text(encoding="utf-8")
    seg = s[s.index("isi_petunjuk_penggunaan_lanjutan"):]
    for k in (("Iqomah", "timer", "volume")):
        if k.lower() not in seg.lower(): g.append(f"GAGAL petunjuk {loc}: {k}")
print("\n".join(g) if g else "UJI IQOMAH/TERPUTUS/TIMER: LULUS")
