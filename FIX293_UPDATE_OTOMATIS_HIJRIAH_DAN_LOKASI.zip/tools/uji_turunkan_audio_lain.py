from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
if "var turunkanAudioLain" not in t("Prefs.kt") or "turunkanAudioLain + " not in t("Prefs.kt"): g.append("GAGAL Prefs")
if "if (!suara.turunkanAudioLain) return" not in t("Pembicara.kt"): g.append("GAGAL Pembicara")
h=t("Halaman.kt")
if "s.turunkanAudioLain = v" not in h: g.append("GAGAL dialog")
print("\n".join(g) if g else "UJI TURUNKAN AUDIO LAIN: LULUS")
