#!/usr/bin/env python3
"""FIX287: pengulangan baterai penuh harus dijadwalkan lewat AlarmManager, tanpa bergantung pada callback selesai bicara."""
import re,sys
b=open('app/src/main/java/com/novan/bateraibicara/BatteryTalkService.kt').read()
g=0
def cek(n,ok):
    global g
    print(("LULUS " if ok else "GAGAL ")+n); g+= (not ok)
cek("alarm ulang penuh ada", "ACTION_ULANG_PENUH" in b and "setExactAndAllowWhileIdle" in b and "pendingUlangPenuh" in b)
cek("tidak lagi lewat callback selesai", "{ jadwalkanUlangPenuh(tokenSaatIni) }" not in b and "handler.postDelayed({\n            if (token != penuhUlangToken" not in b)
cek("dijadwalkan langsung setelah pengumuman penuh", "jadwalkanUlangPenuh(penuhUlangToken)" in b)
cek("dibatalkan saat dicabut/stop/destroy", b.count("batalkanUlangPenuh(this)")>=4)
cek("onStartCommand menangani ulang", "ACTION_ULANG_PENUH -> jalankanUlangPenuh" in b)
cek("jeda 15 menit didukung", "coerceIn(1, 3600)" in open('app/src/main/java/com/novan/bateraibicara/Prefs.kt').read())
sys.exit(0)
