from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
p=t("Pembicara.kt")
for k in ("gemaAktif()","terapkanKunci(mp.audioSessionId","synthesizeToFile","fun hentikanRender","fun gainSaatIni"):
    if k not in p: g.append("GAGAL Pembicara: "+k)
if "fun terapkanKunci" not in t("GemaAudio.kt"): g.append("GAGAL GemaAudio.terapkanKunci")
if "iqomah_sekali" not in t("PrayerAlarmService.kt"): g.append("GAGAL iqomah sekali")
if "nowMillis + 90_000L" not in t("PrayerAlarm.kt"): g.append("GAGAL margin iqomah")
if "600, 900" not in t("BateraiActivity.kt"): g.append("GAGAL jeda 10/15 menit")
print("\n".join(g) if g else "UJI GEMA IQOMAH SEKALI: LULUS")
