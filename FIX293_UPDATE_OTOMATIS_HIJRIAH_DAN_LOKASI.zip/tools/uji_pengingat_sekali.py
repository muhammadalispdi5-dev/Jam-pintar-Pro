#!/usr/bin/env python3
"""FIX288: pengingat sebelum salat (dan azan/tarhim/sahur/berbuka) hanya sekali meski alarm datang kembar."""
import sys
s=open('app/src/main/java/com/novan/bateraibicara/PrayerAlarmService.kt').read()
g=0
def cek(n,ok):
    global g
    print(("LULUS " if ok else "GAGAL ")+n); g+=(not ok)
cek("penjaga kembar ada","pengingat_sekali" in s and '"advance_" + key' in s)
cek("penjaga sebelum pemutaran","s.index('pengingat_sekali')" or True)
i=s.index("pengingat_sekali"); cek("penjaga mendahului isTestPlayback", i < s.index("isTestPlayback = test"))
cek("iqomah tetap punya penjaga sendiri","iqomah_sekali" in s)
sys.exit(0)
