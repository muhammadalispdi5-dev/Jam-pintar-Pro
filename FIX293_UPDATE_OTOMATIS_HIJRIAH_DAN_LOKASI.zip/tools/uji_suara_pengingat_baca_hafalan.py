#!/usr/bin/env python3
"""Pemeriksaan statis pilihan suara pengingat membaca dan hafalan."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
K = ROOT / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt"
R = ROOT / "app/src/main/java/com/novan/bateraibicara/KhatamReminderReceiver.kt"
H = ROOT / "app/src/main/java/com/novan/bateraibicara/HafalanSrsReceiver.kt"
S = ROOT / "app/src/main/java/com/novan/bateraibicara/SuaraPengingat.kt"
GID = ROOT / "app/src/main/res/values/strings.xml"
GEN = ROOT / "app/src/main/res/values-en/strings.xml"
GR = ROOT / "app/build.gradle.kts"
checks = []
def check(label, ok): checks.append((label, bool(ok)))
k, r, h, s = K.read_text(), R.read_text(), H.read_text(), S.read_text()
check("pilihan suara ucapan Android", '"tts"' in k and 'Android speech' in k)
check("pilihan nada alarm Android", '"alarm"' in k and 'Android alarm tone' in k)
check("pemilih berkas audio sendiri", 'ACTION_OPEN_DOCUMENT' in k and 'type = "audio/*"' in k)
check("izin URI berkas disimpan", 'takePersistableUriPermission' in k)
check("pengingat membaca memakai sumber suara", 'pengingat_baca_suara' in r and 'SuaraPengingat.aturSuara' in r)
check("pengingat hafalan memakai sumber suara", 'hafalan_srs_suara' in h and 'SuaraPengingat.aturSuara' in h)
check("ucapan TTS sesuai fungsi membaca dan hafalan", 'Saatnya membaca Al-Qur' in r and 'Saatnya mengulang hafalan' in h)
check("saluran notifikasi unik mengikuti jenis suara", 'channelId' in s and 'channel.setSound' in s)
check("TTS mengikuti bahasa aktif", 'Locale.US' in s and 'Locale("id", "ID")' in s)
check("petunjuk penggunaan Indonesia diperbarui", ('Ucapan Android, nada alarm bawaan Android' in GID.read_text() and 'Ucapan Android mengikuti bahasa aktif' in GID.read_text()))
check("petunjuk penggunaan Inggris diperbarui", 'Android speech that reads a reminder-specific sentence' in GEN.read_text())
g = GR.read_text()
check("versi 1.0.89 / 89", 'versionCode = 89' in g and 'versionName = "1.0.89"' in g)
for label, ok in checks: print(("LULUS" if ok else "GAGAL") + " - " + label)
raise SystemExit(0 if all(ok for _, ok in checks) else 1)
