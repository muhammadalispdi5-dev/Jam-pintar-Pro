#!/usr/bin/env python3
"""Memastikan sakelar azan Dzuhur hari Jumat tetap tersedia di Pengaturan Jadwal Sholat dan Pengingat."""
import sys, pathlib
j = pathlib.Path('app/src/main/java/com/novan/bateraibicara')
ui = (j / 'PrayerSettingsActivity.kt').read_text(encoding='utf-8')
ok = 'pp.fridayDhuhrOff = it' in ui and 'Matikan suara azan Dzuhur pada hari Jumat' in ui and (j / 'PrayerAlarm.kt').read_text(encoding='utf-8').count('fridayDhuhrOff') >= 4
print('LULUS: sakelar azan Jumat tersedia' if ok else 'GAGAL: sakelar azan Jumat hilang dari PrayerSettingsActivity')
sys.exit(0 if ok else 1)
