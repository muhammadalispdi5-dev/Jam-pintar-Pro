#!/usr/bin/env python3
"""FIX289: setiap layar yang dapat dibuka dari beranda harus punya rute perintah suara; 'buka Jam Pintar Pro' membuka beranda."""
import re,sys
D='app/src/main/java/com/novan/bateraibicara/'
m=open(D+'MainActivity.kt').read(); p=open(D+'PerintahSuaraActivity.kt').read()
g=0
def cek(n,ok):
    global g
    print(("LULUS " if ok else "GAGAL ")+n); g+=(not ok)
tujuan=set(re.findall(r'(\w+Activity)::class\.java',m))-{'PerintahSuaraActivity','BeritahuSayaActivity','MainActivity','PemicuTombolActivity'}
for t in sorted(tujuan): cek("rute suara "+t, t+"::class.java" in p[p.index("private fun bukaFitur"):])
cek("beranda dikenali", "Fitur.BERANDA" in p and "MainActivity::class.java" in p)
cek("beranda diperiksa sebelum fitur Jam", p.index('ada("jam pintar"') < p.index('ada("jam", "clock")'))
cek("sapaan tidak menelan perintah buka", 'u.contains("jam pintar") && !Regex' in p)
a=open('app/src/main/res/values/strings.xml').read(); e=open('app/src/main/res/values-en/strings.xml').read()
cek("petunjuk ID 61 dan EN 58", " 61. Asisten suara" in a and " 58. The voice assistant" in e)
sys.exit(0)
