import re,sys
b='app/src/main/java/com/novan/bateraibicara/'
k=open(b+'KompasActivity.kt',encoding='utf-8').read()
n=open(b+'NadaArah.kt',encoding='utf-8').read()
m=open('app/src/main/AndroidManifest.xml',encoding='utf-8').read()
main=open(b+'MainActivity.kt',encoding='utf-8').read()
q=open(b+'QiblaActivity.kt',encoding='utf-8').read()
pv=open(b+'PerintahSuaraActivity.kt',encoding='utf-8').read()
c=[]
def t(nama,ok): c.append((nama,ok))
t('manifest KompasActivity','.KompasActivity' in m)
t('menu utama','KompasActivity::class.java' in main)
t('tombol di Kiblat','KompasActivity::class.java' in q)
t('perintah suara','Fitur.KOMPAS_ARAH' in pv and 'KompasActivity::class.java' in pv)
t('8 arah nama', all(x in k for x in ['"Northwest"','"Timur Laut"','"Barat Daya"']))
t('nada tiap arah', 'fun nadaArah' in n and 'utama(a, 0.9) + utama(b, 0.9)' in n)
t('bip stereo', 'fun bip' in n and 'CHANNEL_OUT_STEREO' in n)
t('target kiblat', 'PrayerCalc.qiblaBearing' in k)
t('derajat khusus','dialogDerajat' in k)
t('remap tegak','remapCoordinateSystem' in k)
t('fallback accel+mag','TYPE_MAGNETIC_FIELD' in k)
t('layar menyala','FLAG_KEEP_SCREEN_ON' in k)
t('nada dihentikan onPause','NadaArah.henti()' in k.split('override fun onPause')[1])
t('volume tidak diubah','setStreamVolume' not in open(b+'VolumeSaluran.kt',encoding='utf-8').read())
t('iqomah id 809','startForeground(809, notifIq)' in open(b+'PrayerAlarmService.kt',encoding='utf-8').read())
g=0
for nm,ok in c:
    print(('OK    ' if ok else 'GAGAL ')+nm); g+= (not ok)
sys.exit(1 if g else 0)
