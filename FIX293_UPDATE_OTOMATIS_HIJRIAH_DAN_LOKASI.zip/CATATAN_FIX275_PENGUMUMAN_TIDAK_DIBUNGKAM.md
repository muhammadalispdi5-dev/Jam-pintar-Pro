# FIX275 — Pengumuman nama pemanggil dan pesan berhenti setelah volume saluran

Penyebab: FIX273 membuat aplikasi mengubah volume saluran lewat setStreamVolume. PembungkamTelungkup (pemantau tombol volume berbasis VOLUME_CHANGED_ACTION dan polling 200 ms) menganggap perubahan itu sebagai tombol volume yang ditekan pengguna, lalu membungkam pengumuman dan mengembalikan volume. Pengembalian volume sesudah pengumuman memicu hal yang sama pada pengumuman berulang/antrean.

Perbaikan: PembungkamTelungkup.volumeDiubahAplikasi() memulai ulang masa tenang 1,2 detik (nilai dasar diambil ulang) dan dipanggil VolumeSaluran sebelum dan sesudah setiap setStreamVolume (pinjam dan pulihkan). Petunjuk item 52/49 diberi satu kalimat. Pemeriksa uji_volume_saluran diperluas.

Versi tetap 1.0.89. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
