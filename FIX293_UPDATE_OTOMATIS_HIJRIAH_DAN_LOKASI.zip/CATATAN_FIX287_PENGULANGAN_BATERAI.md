# FIX287 – Pengulangan baterai penuh tidak berjalan

Penyebab: pengulangan hanya dijadwalkan di callback "selesai bicara". Callback itu tidak dipanggil bila ucapan terputus/error (mis. mesin suara dipakai pembaca layar), dan Handler.postDelayed berhenti saat HP tidur sehingga jeda panjang (5–15 menit) tidak berjalan.

Perbaikan (BatteryTalkService.kt): pengulangan dijadwalkan langsung saat pengumuman penuh diberikan dan memakai AlarmManager (setExactAndAllowWhileIdle, cadangan non-tepat). Alarm dibatalkan saat charger dicabut, menelungkupkan HP, Matikan, atau layanan berhenti. Token mencegah alarm basi. Uji: tools/uji_baterai_ulang.py.
