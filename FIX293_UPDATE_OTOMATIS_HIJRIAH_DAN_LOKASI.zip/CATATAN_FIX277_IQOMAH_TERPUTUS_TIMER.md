# FIX277 — Iqomah, ucapan terputus pembaca layar, penghentian semua notifikasi, alarm timer

Sumber: FIX276_KOMPATIBILITAS_IZIN_LINTAS_MEREK.zip (kode FIX275 + kompatibilitas izin). Versi tetap 1.0.89.

## 1. Iqomah setelah azan
- res/raw/iqomah_masjidil_haram.mp3 (audio terlampir, ±40 dtk, sampul/metadata dibuang).
- PrayerPrefs: iqomahAktif/iqomahMenit (nonaktif bawaan; pilihan 5,7,10,15,20,25,30,45 menit dari waktu masuk sholat; bawaan Subuh 15, Maghrib 7, lainnya 10).
- PrayerAlarm: alarm request 430..434 (extra iqomah_reminder); Dzuhur hari Jumat dilewati.
- PrayerAlarmReceiver/PrayerAlarmService: cabang iqomah (foreground 810, pasangBungkam 120 dtk, tes jeda/lanjut dengan kunci "iqomah_<sholat>").
- PrayerSettingsActivity: tombol "Iqomah setelah azan" -> grupIqomah (saklar, jarak, tes per sholat).

## 2. Pengumuman terputus saat layar disentuh (vocalizer pembaca layar)
Penyebab: mesin TTS yang sama dipakai TalkBack; ucapan aplikasi dihentikan (onStop interrupted) dan callback dibuang sehingga pengumuman/pengulangan mati. Perbaikan di Pembicara: ucapan yang masih tercatat (dalamProses) diulang tiap 1,5 dtk (maks 40 kali) bila terputus oleh pihak lain; berhenti() / ucapan flush baru / bersihkan membatalkan ulangan (tidak mengulang ucapan yang sengaja dihentikan).

## 3. Volume dan telungkup mematikan semua notifikasi
Audit: semua sumber (panggilan, pesan, antrean, baterai, jam, azan/pengingat/tarhim/iqomah, doa, khatam, hafalan) sudah mendaftar ke PembungkamTelungkup (telungkup, tombol volume, siaran + polling + trek senyap saat layar mati). Celah ditutup: (a) alarm timer kini terdaftar; (b) bila volume saluran di maksimum tombol volume atas tidak mengubah nilai dan tak terdeteksi — VolumeSaluran kini memakai satu tingkat di bawah maksimum saat fitur stop volume aktif.

## 4. Alarm timer
Jenis alarm: 0 nada bawaan Android, 1 TTS, 2 nada+TTS, 3 berkas audio sendiri, 4 berkas sendiri+TTS. Tombol "Berkas audio alarm timer" (slot timer_alarm); berkas kosong/rusak -> nada bawaan. Alarm timer dapat dihentikan telungkup/tombol volume.

## Pemeriksaan
Semua pemeriksa lulus (tools/uji_iqomah.py baru). uji_bmkg, uji_mikrofon_perintah_suara, uji_putar_tanpa_layar, uji_volume_dan_efek_audio_mandiri, verify_final, verify_project sudah gagal pada FIX276 asli (pemeriksa usang), bukan akibat perubahan ini. Belum dikompilasi dengan Gradle dan belum diuji di perangkat.
