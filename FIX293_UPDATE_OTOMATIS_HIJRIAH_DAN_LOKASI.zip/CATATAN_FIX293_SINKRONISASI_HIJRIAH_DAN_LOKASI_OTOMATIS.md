# FIX293 — Sinkronisasi otomatis kalender Hijriah dan lokasi

## Dasar pemeriksaan dua lampiran

### APK Jadwal Sholat v1.19.0 (190)

APK dibuka sebagai arsip dan tiga berkas DEX diperiksa. DEX memuat kelas aplikasi berikut:

- `com.andi.waktusholatdankiblat.helper.GetCityAndTimezoneViaHttpIPV6Helper` beserta kelas callback-nya;
- antarmuka `GetCityAndTimezoneViaHttpIPV6Interface` dan `GetCityAndTimezoneViaHttpInterface`;
- `com.andi.waktusholatdankiblat.utils.HijriConverter`;
- `HijriGlobalConverter`, `HijriImkanurConverter`, dan `HijriUmmConverter`.

String yang berkaitan dengan lokasi/waktu mencakup `reverse-geocode-with-timezone`, `timezoneFromAPIV2`, `usingTimezoneFromAPIV2`, `msg_loading_get_cityname_from_map`, dan pesan kegagalan pencarian kota. String kalender mencakup `autoHijri` dan pilihan koreksi tanggal Hijriah.

Temuan tersebut menunjukkan APK sumber memuat jalur pencarian kota/zona waktu berbasis HTTP/IP serta beberapa konverter kalender Hijriah dan pengaturan otomatis/koreksi. Karena alat dekompilasi DEX (JADX/apktool) tidak tersedia di lingkungan ini, isi metode, URL lengkap, urutan pemanggilan, dan interval pembaruannya tidak dapat dipastikan hanya dari string DEX. Karena itu, FIX293 tidak mengklaim menyalin implementasi internal APK sumber secara identik.

## Mekanisme Jam Pintar Pro sebelum FIX293

- `HijriahDaring` sudah mengunduh tabel Hijriah AlAdhan untuk bulan sebelumnya, bulan berjalan, dan 13 bulan ke depan; data divalidasi dan disimpan di SharedPreferences. Bulan dekat disegarkan maksimal setiap dua hari, bulan jauh setiap 30 hari, dan cache tetap digunakan saat offline.
- `KalenderTanggal.perbaruiHijriahOtomatis` sudah mengambil tanggal Gregorian-ke-Hijriah harian AlAdhan, menghitung offset terbatas, dan mempertahankan kalender ICU Android sebagai cadangan.
- Sebelum FIX293, `MainActivity` saat mulai hanya memanggil `HijriahDaring.segarkan`; sinkronisasi tanggal harian melalui `KalenderTanggal.perbaruiHijriahOtomatis` bergantung pada layar Kalender atau pemanggil lain.
- Lokasi jadwal sholat dapat diperbarui manual melalui `PrayerActivity.perbaruiLokasiGps`. Nama tempat dapat dicari otomatis melalui `NamaLokasi`, tetapi pembaruan koordinat tidak dijalankan otomatis pada awal aplikasi.

## Perubahan FIX293

1. `MainActivity.onCreate` dan `onResume` kini memanggil `KalenderTanggal.perbaruiHijriahOtomatis` jika opsi kalender Hijriah otomatis aktif. Dengan demikian, awal aplikasi memicu penyegaran tabel bulanan sekaligus sinkronisasi tanggal hari ini. Pembatasan percobaan, cache, dan fallback offline yang sudah ada tetap dipakai.
2. Ditambahkan `LokasiOtomatis.kt`. Pada awal aplikasi/ketika aplikasi kembali aktif, kelas ini melakukan pencarian posisi satu-kali jika izin lokasi sudah diberikan. Tidak meminta izin sendiri, tidak menjalankan pelacakan terus-menerus, dan tidak mengirim koordinat kepada pengembang.
3. Lokasi dicari melalui GPS dan jaringan; posisi cache hanya dipertimbangkan jika masih baru. Pencarian langsung dibatasi 20 detik, dengan validasi koordinat, umur posisi, dan akurasi.
4. Pembaruan otomatis dibatasi maksimal sekali setiap enam jam. Koordinat baru hanya disimpan bila berpindah setidaknya 100 meter.
5. Lokasi manual/nama tempat yang ditulis pengguna tidak ditimpa. Lokasi umum/GPS/jaringan dan nama otomatis dapat diperbarui. Setelah koordinat berubah, nama tempat dicari kembali lewat `NamaLokasi`, alarm dijadwalkan ulang, dan jadwal online disinkronkan bila opsi online aktif.
6. Jika izin tidak tersedia, layanan lokasi mati, atau jaringan gagal, data lokasi terakhir tetap dipertahankan. Pengguna masih dapat memakai tombol pembaruan GPS manual.

## Batasan dan pengujian

- Zona waktu sistem Android tidak diubah otomatis. Perubahan zona waktu perangkat tetap mengikuti pengaturan Android; FIX293 hanya memperbarui koordinat lokasi dan nama tempat. APK sumber menunjukkan simbol/kelas terkait zona waktu, tetapi metode dan API lengkapnya tidak dapat dipastikan dari DEX yang tersedia.
- Tidak ada APK build atau uji perangkat dalam lingkungan ini karena Android SDK/Gradle wrapper tidak tersedia.
- Pemeriksaan yang dilakukan: parsing XML manifest, pemeriksaan statis pemanggilan, dan pemeriksaan sintaks Kotlin terbatas. Ini bukan pengganti build Android penuh.
- Versi proyek dipertahankan: `versionCode 89`, `versionName 1.0.89`.
