package com.novan.bateraibicara

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.abs

/** Panduan kompas kiblat foreground agar nada dan ucapan tetap berjalan saat layar mati. */
class QiblaGuidanceService : Service(), SensorEventListener, TextToSpeech.OnInitListener {
    private lateinit var sm: SensorManager
    private var sensor: Sensor? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var tone: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var heading = 0.0
    private var target = 0.0
    private var aligned = false
    private val prefs by lazy { PrayerPrefs(this) }
    private val searchLoop = object : Runnable { override fun run() {
        if (!aligned && prefs.locationSet) { try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }; handler.postDelayed(this, 650L) }
    } }
    private val alignLoop = object : Runnable { override fun run() {
        if (aligned) { try { tone?.startTone(ToneGenerator.TONE_DTMF_5, 2200) } catch (_: Exception) { }; handler.postDelayed(this, 2450L) }
    } }
    private val voiceLoop = object : Runnable { override fun run() {
        if (prefs.voiceQibla && ready && prefs.locationSet && !aligned) {
            val d = delta(target, heading)
            tts?.speak("Arah perangkat ${direction(heading)}. Putar ke ${if (d > 0) "kanan" else "kiri"} ${abs(d).toInt()} derajat menuju kiblat", TextToSpeech.QUEUE_FLUSH, null, "qibla-background-direction")
        }
        // Mengikuti sakelar pengucapan arah otomatis: interval 1,5 detik.
        handler.postDelayed(this, 1500L)
    } }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        createChannel()
        val open = PendingIntent.getActivity(this, 910, Intent(this, QiblaActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val stop = PendingIntent.getService(this, 911, Intent(this, QiblaGuidanceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        startForeground(912, n.setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("Panduan kompas kiblat aktif")
            .setContentText("Nada dan panduan suara tetap aktif saat layar mati")
            .setContentIntent(open).setOngoing(true).setAutoCancel(false)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Matikan panduan kompas", stop).build())
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        // Utamakan sensor wake-up agar perubahan arah tetap terpantau ketika layar mati.
        // Jika perangkat tidak menyediakan varian wake-up, gunakan sensor rotasi biasa.
        sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR, true)
            ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        tone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        tts = TextToSpeech(this, this)
        target = if (prefs.locationSet) PrayerCalc.qiblaBearing(prefs.lat, prefs.lon) else 0.0
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "JamPintarPro:QiblaGuidance").apply { setReferenceCounted(false); acquire() }
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        if (prefs.locationSet) handler.post(searchLoop)
        handler.postDelayed(voiceLoop, 1500L)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit().putBoolean("qibla_screen_off_enabled", false).putBoolean("qibla_background_active", false).apply()
            stopSelf(); return START_NOT_STICKY
        }
        if (!getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getBoolean("qibla_screen_off_enabled", false) || !prefs.locationSet) {
            stopSelf(); return START_NOT_STICKY
        }
        return START_STICKY
    }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) { tts?.language = Locale("id", "ID"); ready = true } }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR || !prefs.locationSet) return
        val m = FloatArray(9); SensorManager.getRotationMatrixFromVector(m, event.values)
        val o = FloatArray(3); SensorManager.getOrientation(m, o)
        heading = (Math.toDegrees(o[0].toDouble()) + 360.0) % 360.0
        target = PrayerCalc.qiblaBearing(prefs.lat, prefs.lon)
        val nowAligned = abs(delta(target, heading)) < 5.0
        if (nowAligned && !aligned) {
            handler.removeCallbacks(searchLoop); handler.removeCallbacks(alignLoop)
            try { tone?.stopTone() } catch (_: Exception) { }
            if (prefs.voiceQibla && ready) tts?.speak("Anda tepat di arah kiblat.", TextToSpeech.QUEUE_FLUSH, null, "qibla-background-aligned")
            if (prefs.qiblaHaptic) {
                try {
                    val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE)) else vibrator.vibrate(800)
                } catch (_: Exception) { }
            }
            handler.postDelayed(alignLoop, if (prefs.voiceQibla && ready) 1400L else 0L)
        } else if (!nowAligned && aligned) {
            handler.removeCallbacks(alignLoop); try { tone?.stopTone() } catch (_: Exception) { }; handler.post(searchLoop)
        }
        aligned = nowAligned
    }
    private fun direction(deg: Double): String { val a = arrayOf("Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut"); return a[(kotlin.math.floor((((deg % 360) + 360) % 360 + 22.5) / 45).toInt()) % 8] }
    private fun delta(t: Double, h: Double) = ((t - h + 540.0) % 360.0) - 180.0
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val nm = getSystemService(NotificationManager::class.java); if (nm.getNotificationChannel(CHANNEL) == null) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Panduan Kompas Kiblat", NotificationManager.IMPORTANCE_LOW)) } }
    override fun onDestroy() {
        sm.unregisterListener(this); handler.removeCallbacksAndMessages(null)
        try { tone?.stopTone(); tone?.release() } catch (_: Exception) { }; tone = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }; tts = null
        try { wakeLock?.release() } catch (_: Exception) { }; wakeLock = null
        getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit().putBoolean("qibla_background_active", false).apply()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
    companion object { const val ACTION_STOP = "com.novan.jambicarapro.STOP_QIBLA_GUIDANCE"; const val CHANNEL = "qibla_guidance" }
}
