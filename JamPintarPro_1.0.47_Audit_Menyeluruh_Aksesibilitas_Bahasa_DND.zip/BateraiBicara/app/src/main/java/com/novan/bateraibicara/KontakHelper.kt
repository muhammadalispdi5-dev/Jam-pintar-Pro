package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

/** Mencocokkan nomor notifikasi dengan kontak lokal; dapat memilih nama panggilan kontak. */
object KontakHelper {
    fun namaDariNomor(context: Context, nomor: String, pakaiNamaPanggilan: Boolean = false): String? {
        if (nomor.isBlank() || context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(nomor))
            context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup._ID, ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (!c.moveToFirst()) return null
                val id = c.getLong(0)
                val nama = c.getString(1)?.takeIf { it.isNotBlank() }
                if (!pakaiNamaPanggilan || nama.isNullOrBlank()) return nama
                val nickUri = ContactsContract.Data.CONTENT_URI
                val nick = context.contentResolver.query(
                    nickUri,
                    arrayOf(ContactsContract.CommonDataKinds.Nickname.NAME),
                    "${ContactsContract.Data.CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?",
                    arrayOf(id.toString(), ContactsContract.CommonDataKinds.Nickname.CONTENT_ITEM_TYPE),
                    null
                )?.use { nc -> if (nc.moveToFirst()) nc.getString(0)?.takeIf { it.isNotBlank() } else null }
                nick ?: nama
            }
        } catch (_: Exception) { null }
    }
}
