package com.novan.bateraibicara

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.media.ToneGenerator
import android.media.AudioManager
import android.widget.EditText
import android.widget.TextView

/** Pengaturan kategori Nama Pemanggil. */
class PemanggilActivity : Halaman() {

    override val judulHalaman = R.string.kategori_pemanggil

    private lateinit var teksAkses: TextView
    private lateinit var teksTelepon: TextView

    override fun bangun() {
        saklar(getString(R.string.sw_pem_on), prefs.pemOn) { prefs.pemOn = it }
        info(getString(R.string.info_pemanggil))

        // ----- Izin -----
        bagian(getString(R.string.bagian_izin))
        teksAkses = info("")
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
        info(getString(R.string.info_setelan_terbatas))
        teksTelepon = info("")
        tombol(getString(R.string.tombol_izin_telepon)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 2)
        }
        tombol(getString(R.string.tombol_izin_kontak)) {
            val izin = if (Build.VERSION.SDK_INT >= 23) arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG) else arrayOf(Manifest.permission.READ_CONTACTS)
            requestPermissions(izin, 3)
        }
        saklar(getString(R.string.sw_nama_panggilan), prefs.pemNamaPanggilan) { prefs.pemNamaPanggilan = it }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

        // ----- Jenis panggilan -----
        bagian(getString(R.string.bagian_jenis))
        saklar(getString(R.string.sw_pem_wa), prefs.pemWa) { prefs.pemWa = it }
        saklar(getString(R.string.sw_pem_wb), prefs.pemWb) { prefs.pemWb = it }
        saklar(getString(R.string.sw_pem_telp), prefs.pemTelp) { prefs.pemTelp = it }
        saklar(getString(R.string.sw_pem_jenis), prefs.pemJenis) { prefs.pemJenis = it }

        // ----- Kalimat yang diucapkan -----
        bagian(getString(R.string.bagian_kalimat))
        info(getString(R.string.info_kalimat))
        val fWaSuara = isian(getString(R.string.kalimat_wa_suara), prefs.pemKalimatWaSuara, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWaSuara = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wa_suara))) { sisipkanNama(fWaSuara) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wa_suara))) { sisipkanToken(fWaSuara, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wa_suara))) { tesSuara("pem", CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh))) }
        val fWaVideo = isian(getString(R.string.kalimat_wa_video), prefs.pemKalimatWaVideo, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWaVideo = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wa_video))) { sisipkanNama(fWaVideo) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wa_video))) { sisipkanToken(fWaVideo, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wa_video))) { tesSuara("pem", CallerListener.susun(this, prefs, true, true, getString(R.string.nama_contoh))) }
        val fTelp = isian(getString(R.string.kalimat_telp), prefs.pemKalimatTelp, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatTelp = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_telp))) { sisipkanNama(fTelp) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_telp))) { sisipkanToken(fTelp, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_telp))) { tesSuara("pem", CallerListener.susun(this, prefs, false, false, getString(R.string.nama_contoh))) }
        val fWbSuara = isian(getString(R.string.kalimat_wb_suara), prefs.pemKalimatWbSuara, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWbSuara = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wb_suara))) { sisipkanNama(fWbSuara) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wb_suara))) { sisipkanToken(fWbSuara, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wb_suara))) { tesSuara("pem", CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh), true)) }
        val fWbVideo = isian(getString(R.string.kalimat_wb_video), prefs.pemKalimatWbVideo, InputType.TYPE_CLASS_TEXT) { prefs.pemKalimatWbVideo = it }
        tombol(getString(R.string.sisipkan_nama, getString(R.string.kalimat_wb_video))) { sisipkanNama(fWbVideo) }
        tombol(getString(R.string.sisipkan_jenis, getString(R.string.kalimat_wb_video))) { sisipkanToken(fWbVideo, "{jenis}") }
        tombol(getString(R.string.dengarkan, getString(R.string.kalimat_wb_video))) { tesSuara("pem", CallerListener.susun(this, prefs, true, true, getString(R.string.nama_contoh), true)) }

        // ----- Pengulangan -----
        bagian(getString(R.string.bagian_ulang))
        isian(
            getString(R.string.pem_jeda), formatDetik(prefs.pemJeda),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        ) { s ->
            val v = s.replace(',', '.').toFloatOrNull()
            if (v != null && v >= 0.3f) prefs.pemJeda = v.coerceAtMost(60f)
        }
        pilihan(getString(R.string.pem_batas), larik(R.array.pem_batas), prefs.pemBatasIdx) {
            prefs.pemBatasIdx = it
        }

        // ----- Melodi sebelum/sesudah pengumuman -----
        bagian(getString(R.string.bagian_melodi))
        info(getString(R.string.info_melodi))
        saklar(getString(R.string.sw_melodi_awal), prefs.melodiAwalOn) { prefs.melodiAwalOn = it }
        isian(getString(R.string.jeda_melodi_awal), prefs.jedaMelodiAwal.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAwal = v }
        }
        saklar(getString(R.string.sw_melodi_akhir), prefs.melodiAkhirOn) { prefs.melodiAkhirOn = it }
        isian(getString(R.string.jeda_melodi_akhir), prefs.jedaMelodiAkhir.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAkhir = v }
        }
        pilihan(getString(R.string.melodi_awal_pilih), larik(R.array.jam_melodi), prefs.melodiAwalIdx) {
            prefs.melodiAwalIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_awal)) { Melodi.putar(this, prefs.melodiAwalIdx) }
        pilihan(getString(R.string.melodi_akhir_pilih), larik(R.array.jam_melodi), prefs.melodiAkhirIdx) {
            prefs.melodiAkhirIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_akhir)) { Melodi.putar(this, prefs.melodiAkhirIdx) }
        tombol("Tes nada singkat") { Melodi.bunyikan(this, 180) }

        // ----- Suara -----
        // Tombol tes tiap kalimat diletakkan langsung di bawah kolom kalimat terkait.
        blokSuara("pem") {
            CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh))
        }
    }

    override fun onResume() {
        super.onResume()
        teksAkses.text = getString(
            if (aksesNotifikasiAktif()) R.string.akses_notif_aktif else R.string.akses_notif_mati
        )
        teksTelepon.text = getString(
            if (izinTelepon()) R.string.izin_telepon_aktif else R.string.izin_telepon_mati
        )
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, hasil: IntArray) {
        super.onRequestPermissionsResult(code, perms, hasil)
        if (code == 2 && izinTelepon()) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, CallerListener::class.java))
            } catch (e: Exception) { }
        }
        onResume()
    }

    private fun izinTelepon() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun aksesNotifikasiAktif(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun bukaAksesNotifikasi() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            bukaInfoApp()
        }
    }

    private fun sisipkanNama(field: EditText) = sisipkanToken(field, "{nama}")

    private fun sisipkanToken(field: EditText, token: String) {
        val posisi = field.selectionStart.coerceAtLeast(0).coerceAtMost(field.text.length)
        field.text.insert(posisi, token)
        field.requestFocus()
    }

    private fun formatDetik(v: Float) = if (v % 1f == 0f) v.toInt().toString() else v.toString()
}
