package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.widget.EditText
import java.util.Calendar

/** Pengaturan terpisah untuk tanggal Masehi, Hijriah, dan pasaran Jawa. */
class KalenderActivity : Halaman() {
    override val judulHalaman = R.string.kategori_kalender

    override fun bangun() {
        HariLibur.syncIfNeeded(this, prefs)
        info(getString(R.string.info_kalender_urutan))
        if (prefs.kalenderHijriAuto) KalenderTanggal.perbaruiHijriahOtomatis(this, Calendar.getInstance())
        bagian(getString(R.string.bagian_kal_masehi))
        saklar(getString(R.string.sw_kal_masehi), prefs.kalenderMasehiOn) {
            prefs.kalenderMasehiOn = it
            muatUlang()
        }

        bagian(getString(R.string.bagian_kal_pasaran))
        saklar(getString(R.string.sw_kal_pasaran), prefs.kalenderPasaranOn) {
            prefs.kalenderPasaranOn = it
            muatUlang()
        }
        isian(getString(R.string.kal_koreksi_pasaran), prefs.kalenderPasaranKoreksi.toString(),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED) {
            prefs.kalenderPasaranKoreksi = it.toIntOrNull()?.coerceIn(-30, 30) ?: 0
        }

        bagian(getString(R.string.bagian_kal_hijriah))
        saklar(getString(R.string.sw_kal_hijri), prefs.kalenderHijriOn) {
            prefs.kalenderHijriOn = it
            muatUlang()
        }
        val koreksiHijri = isian(
            getString(R.string.kal_koreksi_hijri), prefs.kalenderHijriKoreksi.toString(),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
        ) { nilai ->
            if (!prefs.kalenderHijriAuto) {
                prefs.kalenderHijriKoreksi = nilai.toIntOrNull()?.coerceIn(-30, 30) ?: 0
            }
        }
        val saklarHijriAuto = saklar(getString(R.string.sw_kal_hijri_auto), prefs.kalenderHijriAuto) {
            prefs.kalenderHijriAuto = it
            if (it) KalenderTanggal.perbaruiHijriahOtomatis(this, Calendar.getInstance(), true) { sukses ->
                runOnUiThread { toast(if (sukses) R.string.kalender_update_sukses else R.string.kalender_update_gagal) }
            }
            koreksiHijri.isEnabled = !it
            koreksiHijri.alpha = if (it) 0.5f else 1f
            muatUlang()
        }
        koreksiHijri.isEnabled = !saklarHijriAuto.isChecked
        koreksiHijri.alpha = if (saklarHijriAuto.isChecked) 0.5f else 1f
        info(getString(R.string.info_kal_hijri_auto))
        tombol(getString(R.string.kalender_update_sekarang)) {
            if (!prefs.kalenderHijriAuto) {
                toast(R.string.kalender_update_aktifkan_otomatis)
            } else {
                KalenderTanggal.perbaruiHijriahOtomatis(this, Calendar.getInstance(), true) { sukses ->
                    toast(if (sukses) R.string.kalender_update_sukses else R.string.kalender_update_gagal)
                }
            }
        }
        tombol(getString(R.string.tombol_kalender_resmi)) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://aceh.kemenag.go.id/informasi/kalender-hijriah-indonesia-tahun-2027")))
            } catch (_: Exception) { toast(R.string.kalender_resmi_gagal) }
        }
        bagian(getString(R.string.bagian_libur_nasional))
        info(getString(R.string.info_hari_libur))
        saklar(getString(R.string.sw_libur_nasional_auto), prefs.liburNasionalAutoSync) { aktif ->
            prefs.liburNasionalAutoSync = aktif
            if (aktif) HariLibur.syncIfNeeded(this, prefs)
            toast(if (aktif) R.string.libur_update_aktif else R.string.libur_update_nonaktif)
            muatUlang()
        }
        saklar(getString(R.string.sw_libur_nasional_lampau), prefs.liburNasionalLampau) { prefs.liburNasionalLampau = it; muatUlang() }
        saklar(getString(R.string.sw_libur_nasional_terkini), prefs.liburNasionalTerkini) { prefs.liburNasionalTerkini = it; muatUlang() }
        saklar(getString(R.string.sw_libur_nasional_mendatang), prefs.liburNasionalMendatang) { prefs.liburNasionalMendatang = it; muatUlang() }
        tombol(getString(R.string.tombol_bacakan_libur_nasional)) { bacakanInfoLibur("national") }

        bagian(getString(R.string.bagian_cuti_bersama))
        saklar(getString(R.string.sw_cuti_bersama_auto), prefs.cutiBersamaAutoSync) { aktif ->
            prefs.cutiBersamaAutoSync = aktif
            if (aktif) HariLibur.syncIfNeeded(this, prefs)
            toast(if (aktif) R.string.libur_update_aktif else R.string.libur_update_nonaktif)
            muatUlang()
        }
        saklar(getString(R.string.sw_cuti_bersama_lampau), prefs.cutiBersamaLampau) { prefs.cutiBersamaLampau = it; muatUlang() }
        saklar(getString(R.string.sw_cuti_bersama_terkini), prefs.cutiBersamaTerkini) { prefs.cutiBersamaTerkini = it; muatUlang() }
        saklar(getString(R.string.sw_cuti_bersama_mendatang), prefs.cutiBersamaMendatang) { prefs.cutiBersamaMendatang = it; muatUlang() }
        tombol(getString(R.string.tombol_bacakan_cuti_bersama)) { bacakanInfoLibur("joint") }

        tombol(getString(R.string.kalender_tes_ucapan)) {
            val sekarang = Calendar.getInstance()
            if (prefs.kalenderHijriAuto) KalenderTanggal.perbaruiHijriahOtomatis(this, sekarang)
            val segmen = JamWaktu.segmenTanggal(prefs, sekarang)
            if (segmen.isEmpty()) {
                toast(R.string.kalender_tes_nyalakan)
                return@tombol
            }
            val p = Pembicara(this, prefs.suara("jam")) { toast(it) }
            p.ucapkanRangkaian(segmen, 300L) { p.matikan() }
        }
    }

    private fun bacakanInfoLibur(kategori: String) {
        HariLibur.syncIfNeeded(this, prefs)
        val segmen = HariLibur.ringkasan(this, prefs, kategori)
        val p = Pembicara(this, prefs.suara("jam")) { toast(it) }
        p.ucapkanRangkaian(segmen, 300L) { p.matikan() }
    }
}
