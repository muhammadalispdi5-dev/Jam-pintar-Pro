package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val aksi = intent.action
        val bootOrUpdate = aksi == Intent.ACTION_BOOT_COMPLETED ||
            aksi == "android.intent.action.QUICKBOOT_POWERON" ||
            aksi == Intent.ACTION_MY_PACKAGE_REPLACED
        val jadwalBerubah = aksi == Intent.ACTION_TIME_CHANGED ||
            aksi == Intent.ACTION_TIMEZONE_CHANGED ||
            aksi == Intent.ACTION_DATE_CHANGED ||
            aksi == "android.app.action.NOTIFICATION_POLICY_ACCESS_GRANTED_CHANGED"
        if (bootOrUpdate) {
            val prefs = Prefs(context)
            if (prefs.enabled && prefs.bootOn) {
                try { BatteryTalkService.start(context) } catch (_: Exception) { }
            }
        }
        // Alarm RTC harus dihitung ulang setelah waktu/tanggal/zona waktu perangkat berubah.
        // Ini juga menjadwalkan ulang alarm pemulihan Jangan Ganggu yang masih aktif.
        if (bootOrUpdate || jadwalBerubah) {
            try { PrayerAlarm.scheduleAll(context) } catch (_: Exception) { }
        }
    }
}
