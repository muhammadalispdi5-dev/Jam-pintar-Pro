package com.novan.bateraibicara

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/** Pemutar 15 melodi yang dipulihkan dari APK sumber. Indeks 0 berarti mati. */
object Melodi {
    private val handler = Handler(Looper.getMainLooper())
    private val audio = intArrayOf(
        0, R.raw.melodi_01, R.raw.melodi_02, R.raw.melodi_03, R.raw.melodi_04,
        R.raw.melodi_05, R.raw.melodi_06, R.raw.melodi_07, R.raw.melodi_08,
        R.raw.melodi_09, R.raw.melodi_10, R.raw.melodi_11, R.raw.melodi_12,
        R.raw.melodi_13, R.raw.melodi_14, R.raw.melodi_15, R.raw.melodi_16
    )

    fun putar(context: Context, pilihan: Int, selesai: (() -> Unit)? = null) {
        if (pilihan <= 0 || pilihan >= audio.size) {
            selesai?.invoke()
            return
        }
        try {
            val player = MediaPlayer.create(context.applicationContext, audio[pilihan])
            if (player == null) { selesai?.invoke(); return }
            player.setOnCompletionListener {
                try { it.release() } catch (_: Exception) { }
                selesai?.invoke()
            }
            player.setOnErrorListener { mp, _, _ ->
                try { mp.release() } catch (_: Exception) { }
                selesai?.invoke()
                true
            }
            player.start()
        } catch (_: Exception) { selesai?.invoke() }
    }

    /** Nada singkat untuk fitur nama pemanggil. */
    fun bunyikan(context: Context, durasiMs: Int = 180) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
            val d = durasiMs.coerceIn(80, 800)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, d)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) { } }, d.toLong() + 100)
        } catch (_: Exception) { }
    }
}
