# FIX143 — Perbaikan kompilasi dan penelusuran sakelar perangkat

## Dasar perbaikan

FIX142 memiliki kurung kurawal penutup yang hilang setelah fungsi `cobaKontrolPerangkat`. Akibatnya, fungsi-fungsi lain terbaca seolah-olah berada di dalam fungsi tersebut dan memicu banyak kesalahan Kotlin berantai, termasuk referensi konstanta companion object yang sebenarnya tersedia.

## Perubahan

1. Menutup fungsi `cobaKontrolPerangkat` pada tempat yang benar agar deklarasi anggota kelas dan `companion object` kembali dikenali compiler.
2. Menambahkan `gulirKeKontrol`, yang mencari container aksesibilitas yang terlihat, aktif, dan dapat digulir, kemudian menjalankan `ACTION_SCROLL_FORWARD`.
3. Saat sakelar target belum terlihat, layanan mencoba menggulir halaman secara bertahap (maksimal delapan langkah) dan memindai ulang setiap tampilan. Hal ini menangani halaman Pengaturan yang membuka fokus di bagian paling atas sementara sakelar berada di bagian bawah.
4. Penanganan hotspot dua langkah tetap didahulukan agar baris hotspot dapat dibuka sebelum pencarian sakelar di halaman berikutnya.
5. Pengguliran dibatasi dan permintaan dihentikan dengan pengumuman gagal jika kontrol tidak ditemukan; tidak memilih kontrol lain secara acak.
6. Versi aplikasi dipertahankan pada 1.0.81 (versionCode 81). Dukungan bahasa aktif dan fitur lain tidak diubah.

## Pemeriksaan

- `tools/verify_project.py`: lulus.
- `tools/periksa_bahasa_aktif.py`: lulus.
- `tools/periksa_resource_strings.py`: lulus.
- Semua `tools/uji_*.py`: lulus.
- `PemilihSakelar.kt` berhasil dikompilasi mandiri dengan kotlinc.
- Tidak ditemukan kesalahan sintaks Kotlin pada pemeriksaan parser service.
- Kompilasi Android/Gradle penuh tidak dijalankan karena Gradle wrapper, Gradle terpasang, dan Android SDK tidak tersedia di lingkungan ini.
- Uji pada perangkat fisik tetap diperlukan karena hierarki aksesibilitas Pengaturan dapat berbeda antarversi Android dan OEM.
