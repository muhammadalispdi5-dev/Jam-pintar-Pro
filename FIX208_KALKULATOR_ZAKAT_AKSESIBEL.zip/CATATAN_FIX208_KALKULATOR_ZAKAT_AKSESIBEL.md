# FIX208 — Penambahan Kalkulator Zakat Aksesibel

## Perubahan
- Menambahkan menu Kalkulator Zakat pada halaman utama Jam Pintar Pro.
- Menambahkan halaman KalkulatorZakatActivity dan mendaftarkannya di AndroidManifest.
- Menyediakan enam jenis perhitungan: emas/perak, tabungan/uang, perdagangan, pertanian, fitrah, dan penghasilan/profesi.
- Menambahkan pemeriksaan input, hasil terperinci, pengumuman hasil untuk pembaca layar, penyimpanan riwayat lokal, serta fungsi melihat dan menghapus riwayat.
- Seluruh teks fitur memakai bahasa tampilan aktif aplikasi: Indonesia atau English.
- Memperbarui petunjuk penggunaan pada kedua bahasa.

## Acuan dan asumsi yang ditampilkan kepada pengguna
- Emas: nisab referensi 85 gram; perak: 595 gram; tarif 2,5% setelah haul.
- Tabungan dan perdagangan: nisab setara 85 gram emas; tarif 2,5% setelah haul.
- Pertanian: nisab referensi 653 kg gabah; tarif 10% (alami), 5% (irigasi berbiaya), atau 7,5% (campuran).
- Fitrah: acuan 2,5 kg beras per jiwa; nilai uang dihitung dari harga beras per kilogram yang dimasukkan pengguna.
- Penghasilan: nisab tahunan setara 85 gram emas atau 1/12 untuk metode bulanan; tarif 2,5%.

Harga emas/perak dan beras dimasukkan manual oleh pengguna, tidak diklaim sebagai harga terkini otomatis. Nilai nisab serta metode dapat mengikuti ketentuan lembaga zakat/ulama setempat. Hasil adalah estimasi, bukan fatwa. Zakat peternakan belum dimasukkan pada tahap ini karena memerlukan tabel nisab dan ketentuan terperinci per jenis hewan.

## Aksesibilitas
- Label formulir dihubungkan dengan kolom masukan melalui `labelFor`.
- Tombol memakai nama aksesibilitas yang jelas.
- Hasil perhitungan dapat diumumkan ulang melalui layanan aksesibilitas Android.
- Navigasi menggunakan kontrol Android standar dan tombol kembali halaman dari kelas dasar aplikasi.

## Pemeriksaan
- Berkas XML strings dan AndroidManifest berhasil diparsing.
- Struktur sumber ZIP dipertahankan dan semua entri akan diverifikasi setelah pengemasan.
- Kompilasi APK belum dijalankan di lingkungan ini karena Gradle wrapper dan Android SDK tidak tersedia.
