# FIX164 - Efek gema untuk audio Khatam Al-Qur'an

Dasar: FIX163 yang diunggah pengguna (FIX163 hanya menyentuh suara Jam/Baterai; Khatam belum punya gema).

## Perubahan
- Menu baru di Equalizer audio: **Efek gema dan ruang** dengan 10 mode: Ruang kecil, Gema aula, Gema aula besar/masjid, Gema (echo) lembut, Gema (echo) jelas, Gema lembah/pegunungan, Studio vokal, Karaoke, Panggung konser, Gua/katedral (plus Normal).
- Mode echo, lembah, karaoke, panggung, dan gua memakai `EnvironmentalReverb` dengan jeda pantulan dan lama gema sendiri, sehingga benar-benar terdengar sebagai gema. Mode lain memakai `PresetReverb`. Bila perangkat tidak mendukung efek khusus, dipakai preset ruang terdekat dan hal itu diberitahukan; bila tidak ada sama sekali, audio tetap normal dan alasannya diumumkan.
- Slider **Kekuatan gema** (0-100%) di Efek tambahan; 0 mematikan gema.
- Efek berlaku langsung, juga pada audio yang sedang diputar, dan juga pada audio yang dimulai lewat perintah suara (EfekAudioLatar).
- Ringkasan efek, "Setel ulang semua efek", "Matikan semua", dan reset pengaturan Khatam ikut memuat gema.
- File baru `GemaAudio.kt`; uji statis `tools/uji_fix164_efek_gema.py`.
- Bahasa aktif: semua teks memakai tr(id, en); pemeriksa bahasa dan resource string lulus tanpa menaikkan baseline.
- Efek vokal Jam/Baterai (FIX163) tidak diubah. Versi aplikasi tidak diubah.

## Batasan
Dukungan dan karakter bunyi tergantung perangkat; sebagian perangkat tidak mengizinkan efek gema pada sesi pemutar. Belum dikompilasi dan belum diuji di perangkat.
