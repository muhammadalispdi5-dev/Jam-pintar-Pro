package com.novan.bateraibicara

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Calendar

/**
 * FIX84: perintah suara Beritahu Saya.
 * Dibuka dengan ketuk tahan pada ikon Beritahu Saya (pintasan aplikasi) atau ketuk tahan pada saklar
 * pemicu Beritahu Saya di layar utama aplikasi. Layar pengenalan suara sistem dibuka (tanpa izin
 * mikrofon aplikasi), lalu perintah dijalankan: waktu, tanggal, atau memutar Al-Qur'an.
 * Bahasa pengenalan, teks, dan pesan mengikuti bahasa tampilan utama yang aktif.
 */
class PerintahSuaraActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutup() }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)
        if (!prefs.beritahuSayaOn) {
            Toast.makeText(this, getString(R.string.beritahu_saya_nonaktif_petunjuk), Toast.LENGTH_LONG).show()
            selesai = true
            finish()
            return
        }
        if (savedInstanceState == null) mulai()
    }

    /** Bila "Suara TalkBack saat mikrofon dipakai" dimatikan (Khatam), senyapkan TalkBack, beri getar, lalu buka mikrofon. */
    private fun mulai() {
        val senyap = getSharedPreferences("khatam_quran", MODE_PRIVATE).getBoolean("senyap_talkback_pergantian_audio", false)
        if (senyap) {
            try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
            getar(150L)
            handler.postDelayed({ if (!isFinishing) bukaPengenalan(false) }, 800L)
        } else {
            bukaPengenalan(true)
        }
    }

    private fun bukaPengenalan(denganPetunjuk: Boolean) {
        val inggris = BahasaAplikasi.tampilan(this) == 1
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (inggris) "en-US" else "id-ID")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, if (inggris) "en-US" else "id-ID")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                if (denganPetunjuk) putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.perintah_suara_petunjuk))
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, KODE_PENGENALAN)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            tutup()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != KODE_PENGENALAN) return
        val kandidat = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty() else emptyList<String>()
        if (kandidat.isEmpty()) { tutup(); return }
        jalankan(kandidat)
    }

    private fun jalankan(kandidat: List<String>) {
        when (PerintahSuara.tafsir(kandidat)) {
            PerintahSuara.Jenis.WAKTU -> bacakan(waktu = true, tanggal = false)
            PerintahSuara.Jenis.TANGGAL -> bacakan(waktu = false, tanggal = true)
            PerintahSuara.Jenis.WAKTU_TANGGAL -> bacakan(waktu = true, tanggal = true)
            PerintahSuara.Jenis.QURAN -> bukaKhatam(kandidat)
            PerintahSuara.Jenis.TIDAK_DIKENAL -> {
                val didengar = kandidat.firstOrNull().orEmpty()
                getar(300L)
                Toast.makeText(
                    this,
                    getString(R.string.perintah_suara_tidak_dikenal) + (if (didengar.isNotBlank()) " (\"" + didengar + "\")" else ""),
                    Toast.LENGTH_LONG
                ).show()
                tutup()
            }
        }
    }

    /** Waktu dibacakan suara jam; tanggal, libur, dan info sholat oleh suara pembaca tanggal (sama dengan pemicu biasa). */
    private fun bacakan(waktu: Boolean, tanggal: Boolean) {
        try {
            val prefs = Prefs(applicationContext)
            val c = Calendar.getInstance()
            val teksWaktu = if (waktu) JamWaktu.ucapan(prefs, c) else ""
            val segmenTanggal = if (tanggal) JamWaktu.segmenTanggal(prefs, c) else emptyList()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 60_000L)
            fun bacaTanggal() {
                if (segmenTanggal.isEmpty()) { tutup(); return }
                val pt = Pembicara(applicationContext, prefs.suara("tgl"))
                pembicaraTanggal = pt
                pt.ucapkanRangkaian(segmenTanggal, 300L) { tutup() }
            }
            if (teksWaktu.isBlank()) {
                bacaTanggal()
            } else {
                val p = Pembicara(applicationContext, prefs.suara("jam"))
                pembicara = p
                p.ucapkan(teksWaktu, true) { bacaTanggal() }
            }
        } catch (_: Exception) {
            tutup()
        }
    }

    /** Perintah putar Al-Qur'an diteruskan ke Khatam; Khatam menafsirkan surah/ayat/juz dan memutar audionya. */
    private fun bukaKhatam(kandidat: List<String>) {
        try {
            // FIX87: dari layar depan/pintasan/widget, Khatam hanya memutar audio lalu mengembalikan pengguna ke layar depan.
            // Bila perintah suara dibuka dari dalam aplikasi sendiri, pengguna tetap berada di Khatam seperti sebelumnya.
            val dariAplikasi = getIntent()?.getBooleanExtra(EXTRA_DARI_APLIKASI, false) ?: false
            val intent = Intent(this, KhatamActivity::class.java).apply {
                putStringArrayListExtra(KhatamActivity.EXTRA_PERINTAH_SUARA, ArrayList(kandidat))
                putExtra(KhatamActivity.EXTRA_KEMBALI_KE_LAYAR_DEPAN, !dariAplikasi)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        hentikanSuara()
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hentikanSuara()
        super.onDestroy()
    }

    companion object {
        private const val KODE_PENGENALAN = 6911
        /** FIX87: diisi true oleh pemanggil di dalam aplikasi agar pengguna tidak dikirim ke layar depan. */
        const val EXTRA_DARI_APLIKASI = "perintah_suara_dari_aplikasi"
    }
}

/** Penafsir perintah suara Beritahu Saya (Indonesia dan Inggris); tidak bergantung pada tampilan. */
object PerintahSuara {
    enum class Jenis { WAKTU, TANGGAL, WAKTU_TANGGAL, QURAN, TIDAK_DIKENAL }

    private val kataWaktu = setOf("waktu", "jam", "pukul", "time", "clock", "jamnya")
    private val kataTanggal = setOf("tanggal", "hari", "tgl", "date", "today", "day", "kalender", "calendar", "hijriah", "pasaran")
    private val kataSemua = setOf("semua", "lengkap", "semuanya", "everything", "all", "both")
    private val kataKerjaInfo = setOf(
        "informasikan", "informasi", "info", "beritahu", "beritahukan", "sebutkan", "katakan", "bacakan", "baca",
        "tolong", "tell", "say", "give", "what", "whats", "read", "announce", "saya", "me"
    )
    private val kataQuran = setOf("surah", "surat", "sura", "ayat", "ayah", "aya", "verse", "juz", "jus", "juzz", "murattal", "mushaf", "alquran", "quran", "quranul")

    fun tafsir(kandidat: List<String>): Jenis {
        for (ucapan in kandidat) {
            val j = tafsirSatu(ucapan)
            if (j != Jenis.TIDAK_DIKENAL) return j
        }
        return Jenis.TIDAK_DIKENAL
    }

    private fun tafsirSatu(ucapan: String): Jenis {
        val token = ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() }
        if (token.isEmpty()) return Jenis.TIDAK_DIKENAL
        val gabung = token.joinToString("")
        // "Qur'an" menjadi "qur an" setelah tanda baca dibuang; gabungan menangkapnya.
        val quran = token.any { it in kataQuran } || gabung.contains("quran")
        if (quran) return Jenis.QURAN
        val waktu = token.any { it in kataWaktu }
        val tanggal = token.any { it in kataTanggal }
        val semua = token.any { it in kataSemua }
        return when {
            waktu && tanggal -> Jenis.WAKTU_TANGGAL
            waktu && semua -> Jenis.WAKTU_TANGGAL
            tanggal && semua -> Jenis.WAKTU_TANGGAL
            waktu -> Jenis.WAKTU
            tanggal -> Jenis.TANGGAL
            semua -> Jenis.WAKTU_TANGGAL
            // Perintah umum tanpa sasaran ("beritahu saya", "tell me"): sama dengan mengetuk pemicu biasa.
            token.any { it in kataKerjaInfo } && token.size <= 3 -> Jenis.WAKTU_TANGGAL
            else -> Jenis.TIDAK_DIKENAL
        }
    }
}
