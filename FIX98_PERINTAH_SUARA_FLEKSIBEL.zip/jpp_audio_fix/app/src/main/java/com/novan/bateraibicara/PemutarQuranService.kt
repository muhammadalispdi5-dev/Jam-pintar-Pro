package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import java.util.Locale

/**
 * FIX96: pemutar Al-Qur'an latar belakang untuk perintah suara, termasuk saat layar terkunci.
 * Layanan foreground (mediaPlayback) memutar audio tanpa membuka layar apa pun, sehingga pengguna tetap di layar
 * kunci atau layar depan. Mengikuti qari dan kecepatan yang disimpan di Khatam. Dikendalikan dengan perintah suara
 * (berhenti, jeda, lanjut) atau tombol pada notifikasi.
 */
class PemutarQuranService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var daftarUrl: List<String> = emptyList()
    private var indeks = 0
    private var percobaan = 0
    private var gagalBerturut = 0
    private var generasi = 0
    private var dijeda = false
    private var dijedaOlehFokus = false
    private var siap = false
    private var label = ""
    private var kecepatan = 1.0f
    // FIX98: pengulangan, jeda antarbagian, dan pelacakan posisi.
    private var ulangN = 1                 // jumlah putaran; 0 = tanpa batas
    private var perAyatMode = false        // true: tiap bagian diulang berturut-turut; false: seluruh daftar diulang
    private var jedaMs = 0L
    private var globalDasar: IntArray? = null
    private var surahBerkas = 0
    private var menungguJeda = false
    private var lanjutSetelahJeda = false
    private var berikutSetelahJeda = 0
    private val penyambungJeda = Runnable {
        menungguJeda = false
        if (dijeda) { lanjutSetelahJeda = true } else mulaiIndeks(berikutSetelahJeda, 0)
    }
    private var fokus: AudioManager.OnAudioFocusChangeListener? = null
    private var permintaanFokus: AudioFocusRequest? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var penerimaTerdaftar = false
    private val penerimaBising = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) jeda()
        }
    }
    private val batasMuat = Runnable { gagalMuat() }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id
    private fun toast(teks: String) { try { Toast.makeText(applicationContext, teks, Toast.LENGTH_LONG).show() } catch (_: Exception) { } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        buatSaluran()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val aksi = intent?.action
        // Layanan foreground wajib memanggil startForeground secepatnya setelah startForegroundService.
        mulaiForeground(if (siap || mp != null) label else tr("Menyiapkan audio…", "Preparing audio…"))
        when (aksi) {
            ACTION_PUTAR -> putar(intent?.getStringArrayListExtra(EXTRA_KANDIDAT).orEmpty())
            ACTION_JEDA -> if (mp == null) tidakAdaAudio() else jeda()
            ACTION_LANJUT -> if (mp == null) tidakAdaAudio() else lanjut()
            ACTION_BERHENTI -> selesai(true)
            else -> if (mp == null) selesai(false)
        }
        return START_NOT_STICKY
    }

    private fun tidakAdaAudio() {
        toast(tr("Tidak ada audio Al-Qur'an yang sedang diputar oleh perintah suara.", "No Qur'an audio is currently playing from a voice command."))
        selesai(false)
    }

    // ---------- Perintah ----------

    private fun putar(kandidat: List<String>) {
        val kh = getSharedPreferences("khatam_quran", MODE_PRIVATE)
        if (!kh.getBoolean("perintah_suara_putar_aktif", true)) {
            toast(tr("Perintah suara untuk memutar dinonaktifkan. Aktifkan di Pengaturan Pemutaran Audio Khatam.", "Voice command for playback is turned off. Turn it on in Khatam Audio Playback Settings."))
            if (mp == null) selesai(false)
            return
        }
        val hasilTafsir = PenafsirQuran.tafsir(kandidat)
        if (hasilTafsir == null) {
            val didengar = kandidat.firstOrNull().orEmpty()
            toast(tr("Perintah belum dikenali", "Command not recognized") + (if (didengar.isNotBlank()) ": \"" + didengar + "\"" else "") +
                tr(". Coba ucapkan: putar surah Al Fatihah ayat 7 sebanyak 5 kali, putar surah 36 ayat 1 sampai 10, putar juz 30, atau ayat berikutnya.",
                    ". Try saying: play surah Al Fatihah verse 7 five times, play surah 36 verses 1 to 10, play juz 30, or next verse."))
            if (mp == null) selesai(false)
            return
        }
        var perintah: PenafsirQuran.Perintah = hasilTafsir
        if (perintah.ulangiTerakhir) {
            val dasar = muatPerintahTerakhir(kh)
            if (dasar == null) {
                toast(tr("Belum ada perintah putar sebelumnya yang dapat diulang.", "There is no previous play command to repeat."))
                if (mp == null) selesai(false)
                return
            }
            perintah = dasar.copy(ulang = perintah.ulang, perAyat = perintah.perAyat, kecepatan = perintah.kecepatan, jedaDetik = perintah.jedaDetik)
        } else if (perintah.relatif != 0) {
            val hitung = hitungRelatif(kh, perintah)
            if (hitung == null) {
                if (mp == null) selesai(false)
                return
            }
            perintah = hitung
        }
        val p = perintah
        val surah = p.surah ?: kh.getInt("terakhir_surah", 1).coerceIn(1, 114)
        var qari = kh.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        qari = when (qari) {
            "ar.sudais" -> "ar.abdurrahmaansudais"
            "ar.shuraim" -> "ar.saoodshuraym"
            "ar.abdulbasit" -> "ar.abdulbasitmurattal"
            "ar.ajamy" -> "ar.ahmedajamy"
            "ar.muhammadayoub" -> "ar.muhammadayyoub"
            else -> qari
        }
        val perSurahSaja = qari.startsWith("mp3quran|")
        val qariAyat = if (perSurahSaja) "ar.alafasy" else qari
        val ulang = p.ulang
        val urls = ArrayList<String>()
        var globalList: IntArray? = null
        var berkasSurah = 0
        var teksLabel: String
        var catatan = ""
        var simpanJuz = -1
        var simpanSurah = -1
        var simpanDari = -1
        var simpanSampai = -1
        val juzDiminta = p.juz
        if (juzDiminta != null) {
            val rentang = PenafsirQuran.rentangJuz(juzDiminta)
            if (rentang == null) { toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); if (mp == null) selesai(false); return }
            for (g in rentang) urls.add(urlAyat(qariAyat, g))
            globalList = IntArray(rentang.last - rentang.first + 1) { rentang.first + it }
            teksLabel = tr("Juz ", "Juz ") + juzDiminta
            simpanJuz = juzDiminta
            if (perSurahSaja) catatan = tr("Qari pilihan hanya punya audio per surah; juz diputar dengan Alafasy.", "The selected reciter only has whole-surah audio; the juz plays with Alafasy.")
        } else {
            val total = PenafsirQuran.jumlahAyat(surah)
            if (total == 0) { toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); if (mp == null) selesai(false); return }
            // Tiap ayat diulang pada seluruh surah ("surah Al Ikhlas setiap ayat 3 kali") memerlukan audio per ayat.
            val awal: Int? = p.ayat ?: (if (p.perAyat && ulang != 1) 1 else null)
            if (awal == null) {
                urls.add(urlSurah(qari, surah) ?: urlSurah("ar.alafasy", surah)!!)
                berkasSurah = surah
                if (perSurahSaja && urlSurah(qari, surah) == null) catatan = tr("Surah ini tidak ada pada qari pilihan; diputar dengan Alafasy.", "This surah is not available for the selected reciter; it plays with Alafasy.")
                teksLabel = tr("Surah ", "Surah ") + surah
                simpanSurah = surah
            } else {
                val akhirDiminta = p.ayatAkhir
                val dari = if (akhirDiminta != null) minOf(awal, akhirDiminta) else awal
                val sampai = when {
                    akhirDiminta != null -> maxOf(awal, akhirDiminta)
                    p.sampaiAkhir -> total
                    p.ayat == null -> total
                    ulang != 1 || p.perAyat -> awal
                    kh.getString("target_pemutaran_audio", "ayat") == "ayat" -> awal
                    else -> total
                }
                if (dari < 1 || sampai > total) {
                    toast(tr("Rentang ayat tidak sesuai (surah ini punya ", "Verse range is not valid (this surah has ") + total + tr(" ayat).", " verses)."))
                    if (mp == null) selesai(false)
                    return
                }
                val g0 = PenafsirQuran.global(surah, dari)
                for (k in 0..(sampai - dari)) urls.add(urlAyat(qariAyat, g0 + k))
                globalList = IntArray(sampai - dari + 1) { g0 + it }
                teksLabel = tr("Surah ", "Surah ") + surah + tr(" ayat ", " verse ") + dari + (if (sampai != dari) (tr(" sampai ", " to ") + sampai) else "")
                simpanSurah = surah; simpanDari = dari; simpanSampai = sampai
                if (perSurahSaja) catatan = tr("Qari pilihan hanya punya audio per surah; ayat diputar dengan Alafasy.", "The selected reciter only has whole-surah audio; verses play with Alafasy.")
            }
        }
        kecepatan = p.kecepatan ?: kh.getFloat("kecepatan_audio", 1.0f).let { if (it in listOf(0.75f, 1.0f, 1.25f, 1.5f)) it else 1.0f }
        ulangN = ulang
        perAyatMode = p.perAyat && ulang > 1 && urls.size > 1
        jedaMs = p.jedaDetik * 1000L
        globalDasar = globalList
        surahBerkas = berkasSurah
        val keterangan = keteranganUlang(p, urls.size)
        label = teksLabel + keterangan
        kh.edit().putString("quran_perintah_terakhir", listOf(simpanJuz, simpanSurah, simpanDari, simpanSampai).joinToString(",")).apply()
        toast(tr("Perintah suara: putar ", "Voice command: play ") + teksLabel + keterangan + (if (catatan.isNotBlank()) ". " + catatan else ""))
        daftarUrl = urls
        indeks = 0
        gagalBerturut = 0
        mulaiIndeks(0, 0)
    }

    /** Teks ringkas pengulangan/kecepatan/jeda untuk notifikasi dan konfirmasi, mis. ", diulang 5 kali". */
    private fun keteranganUlang(p: PenafsirQuran.Perintah, jumlahBagian: Int): String {
        val sb = StringBuilder()
        if (p.ulang == 0) sb.append(tr(", berulang terus-menerus", ", repeating continuously"))
        else if (p.ulang > 1) {
            if (p.perAyat && jumlahBagian > 1) sb.append(tr(", tiap ayat ", ", each verse ") + p.ulang + tr(" kali", " times"))
            else sb.append(tr(", diulang ", ", repeated ") + p.ulang + tr(" kali", " times"))
        }
        if (p.jedaDetik > 0) sb.append(tr(", jeda ", ", pause ") + p.jedaDetik + tr(" detik", " s"))
        val k = p.kecepatan
        if (k != null && k != 1.0f) sb.append(tr(", kecepatan ", ", speed ") + k + "x")
        return sb.toString()
    }

    /** "ayat berikutnya", "surah sebelumnya", "juz berikutnya": dihitung dari posisi terakhir yang diputar atau dibaca. */
    private fun hitungRelatif(kh: android.content.SharedPreferences, p: PenafsirQuran.Perintah): PenafsirQuran.Perintah? {
        val s = kh.getInt("terakhir_surah", 1).coerceIn(1, 114)
        val a = kh.getInt("terakhir_ayat", 1).coerceIn(1, PenafsirQuran.jumlahAyat(s))
        when (p.relatifSatuan) {
            1 -> {
                val tujuan = s + p.relatif
                if (tujuan !in 1..114) {
                    toast(tr("Tidak ada surah ", "There is no ") + (if (p.relatif > 0) tr("berikutnya setelah surah ", "next surah after surah ") else tr("sebelum surah ", "surah before surah ")) + s + ".")
                    return null
                }
                return p.copy(surah = tujuan, relatif = 0)
            }
            2 -> {
                val tujuan = PenafsirQuran.juzDari(s, a) + p.relatif
                if (tujuan !in 1..30) {
                    toast(tr("Tidak ada juz di luar 1 sampai 30.", "There is no juz outside 1 to 30."))
                    return null
                }
                return p.copy(juz = tujuan, relatif = 0)
            }
            else -> {
                val pos = PenafsirQuran.posisiDariGlobal(PenafsirQuran.global(s, a) + p.relatif)
                if (pos == null) {
                    toast(tr("Tidak ada ayat di luar awal dan akhir Al-Qur'an.", "There is no verse beyond the start or end of the Qur'an."))
                    return null
                }
                return p.copy(surah = pos.first, ayat = pos.second, ayatAkhir = null, relatif = 0)
            }
        }
    }

    /** Perintah putar terakhir (tanpa pengulangan), dipakai oleh "ulangi" dan "putar lagi". */
    private fun muatPerintahTerakhir(kh: android.content.SharedPreferences): PenafsirQuran.Perintah? {
        val bagian = (kh.getString("quran_perintah_terakhir", null) ?: return null).split(",").mapNotNull { it.trim().toIntOrNull() }
        if (bagian.size < 4) return null
        fun nilai(i: Int): Int? = bagian[i].takeIf { it > 0 }
        val juz = nilai(0); val surah = nilai(1); val ayat = nilai(2); val akhir = nilai(3)
        if (juz == null && surah == null) return null
        return PenafsirQuran.Perintah(juz, surah, ayat, akhir)
    }

    private fun urlAyat(qari: String, global: Int) = "https://cdn.islamic.network/quran/audio/128/" + qari + "/" + global + ".mp3"

    /** Null bila qari per-surah (MP3Quran) tidak memuat surah tersebut. */
    private fun urlSurah(qari: String, surah: Int): String? {
        if (qari.startsWith("mp3quran|")) {
            val bagian = qari.split("|")
            val server = bagian.getOrNull(1).orEmpty()
            val tersedia = bagian.getOrNull(2)?.split(",")?.mapNotNull { it.trim().toIntOrNull() }?.toSet() ?: emptySet()
            if (server.isBlank() || surah !in tersedia) return null
            return server + String.format(Locale.ROOT, "%03d", surah) + ".mp3"
        }
        return "https://cdn.islamic.network/quran/audio-surah/128/" + qari + "/" + surah + ".mp3"
    }

    /** Percobaan ulang untuk CDN memakai bitrate lain, seperti pemutar di Khatam. */
    private fun varianUrl(url: String, percobaan: Int): String {
        if (!url.startsWith("https://cdn.islamic.network/")) return url
        return when (percobaan) {
            1 -> url.replace("/128/", "/64/")
            2 -> url.replace("/128/", "/192/")
            else -> url
        }
    }

    // ---------- Pemutaran ----------

    private fun mulaiIndeks(i: Int, percobaanKe: Int) {
        if (i >= totalItem()) { selesai(false); return }
        indeks = i
        simpanPosisi(i)
        percobaan = percobaanKe
        siap = false
        dijeda = false
        dijedaOlehFokus = false
        val gen = ++generasi
        handler.removeCallbacks(batasMuat)
        handler.removeCallbacks(penyambungJeda)
        menungguJeda = false
        lanjutSetelahJeda = false
        lepasPemutar()
        if (!mintaFokus()) {
            toast(tr("Audio sedang dipakai aplikasi lain (misalnya panggilan).", "Audio is being used by another app (for example a call)."))
            selesai(false)
            return
        }
        ambilKunci()
        try {
            val p = MediaPlayer()
            mp = p
            p.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(varianUrl(daftarUrl[indeksDasar(i)], percobaanKe))
            p.setOnPreparedListener { pemutar ->
                if (gen != generasi) return@setOnPreparedListener
                handler.removeCallbacks(batasMuat)
                siap = true
                gagalBerturut = 0
                if (!dijeda) {
                    pemutar.start()
                    terapkanKecepatan(pemutar)
                }
                perbaruiNotifikasi()
            }
            p.setOnCompletionListener {
                if (gen != generasi) return@setOnCompletionListener
                lanjutKeBerikut()
            }
            p.setOnErrorListener { _, _, _ ->
                if (gen == generasi) gagalMuat()
                true
            }
            handler.postDelayed(batasMuat, 30_000L)
            p.prepareAsync()
            perbaruiNotifikasi()
        } catch (_: Exception) {
            gagalMuat()
        }
    }

    /** Jumlah bagian yang akan diputar seluruhnya (Int.MAX_VALUE bila tanpa batas). */
    private fun totalItem(): Int = if (ulangN == 0) Int.MAX_VALUE else daftarUrl.size * ulangN

    /** Indeks pada daftar dasar untuk urutan pemutaran ke-i (memperhitungkan pengulangan). */
    private fun indeksDasar(i: Int): Int {
        if (daftarUrl.isEmpty()) return 0
        return if (perAyatMode && ulangN > 0) i / ulangN else i % daftarUrl.size
    }

    private fun lanjutKeBerikut() {
        val berikut = indeks + 1
        if (berikut >= totalItem()) { selesai(false); return }
        if (jedaMs <= 0L) { mulaiIndeks(berikut, 0); return }
        berikutSetelahJeda = berikut
        menungguJeda = true
        perbaruiNotifikasi()
        handler.postDelayed(penyambungJeda, jedaMs)
    }

    /** Simpan posisi bacaan terakhir (dipakai Khatam dan perintah "ayat berikutnya"). */
    private fun simpanPosisi(i: Int) {
        val kh = getSharedPreferences("khatam_quran", MODE_PRIVATE)
        val g = globalDasar?.getOrNull(indeksDasar(i))
        if (g != null) {
            val pos = PenafsirQuran.posisiDariGlobal(g) ?: return
            kh.edit().putInt("terakhir_surah", pos.first).putInt("terakhir_ayat", pos.second).apply()
        } else if (surahBerkas in 1..114) {
            kh.edit().putInt("terakhir_surah", surahBerkas).putInt("terakhir_ayat", 1).apply()
        }
    }

    private fun terapkanKecepatan(p: MediaPlayer) {
        if (kecepatan == 1.0f || Build.VERSION.SDK_INT < 23) return
        try { p.playbackParams = p.playbackParams.setSpeed(kecepatan) } catch (_: Exception) { }
    }

    private fun gagalMuat() {
        handler.removeCallbacks(batasMuat)
        generasi++
        lepasPemutar()
        if (percobaan < 2) { mulaiIndeks(indeks, percobaan + 1); return }
        if (totalItem() > 1 && gagalBerturut < 4) {
            gagalBerturut++
            mulaiIndeks(indeks + 1, 0)
            return
        }
        toast(tr("Audio tidak dapat dimuat. Periksa koneksi internet lalu ulangi perintah.", "The audio could not be loaded. Check your internet connection and repeat the command."))
        selesai(false)
    }

    private fun jeda() {
        val p = mp ?: return
        try { if (p.isPlaying) p.pause() } catch (_: Exception) { }
        dijeda = true
        perbaruiNotifikasi()
    }

    private fun lanjut() {
        val p = mp ?: return
        dijeda = false
        dijedaOlehFokus = false
        if (lanjutSetelahJeda) { lanjutSetelahJeda = false; mulaiIndeks(berikutSetelahJeda, 0); return }
        if (menungguJeda) { perbaruiNotifikasi(); return }
        if (siap) {
            if (!mintaFokus()) return
            try { p.start(); terapkanKecepatan(p) } catch (_: Exception) { }
        }
        perbaruiNotifikasi()
    }

    private fun lepasPemutar() {
        val p = mp
        mp = null
        try { p?.setOnCompletionListener(null); p?.setOnErrorListener(null); p?.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p?.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
    }

    private fun selesai(denganPesan: Boolean) {
        generasi++
        handler.removeCallbacks(batasMuat)
        handler.removeCallbacks(penyambungJeda)
        menungguJeda = false
        lanjutSetelahJeda = false
        lepasPemutar()
        lepasFokus()
        lepasKunci()
        if (denganPesan) toast(tr("Audio Al-Qur'an dihentikan.", "Qur'an audio stopped."))
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    // ---------- Fokus audio dan kunci daya ----------

    private fun mintaFokus(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val pendengar = fokus ?: AudioManager.OnAudioFocusChangeListener { perubahan ->
            when (perubahan) {
                AudioManager.AUDIOFOCUS_LOSS -> handler.post { selesai(false) }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> handler.post {
                    val p = mp
                    if (p != null && siap && !dijeda) { dijedaOlehFokus = true; jeda() }
                }
                AudioManager.AUDIOFOCUS_GAIN -> handler.post {
                    try { mp?.setVolume(1f, 1f) } catch (_: Exception) { }
                    if (dijedaOlehFokus) { dijedaOlehFokus = false; lanjut() }
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> handler.post { try { mp?.setVolume(0.3f, 0.3f) } catch (_: Exception) { } }
            }
        }.also { fokus = it }
        val hasil = if (Build.VERSION.SDK_INT >= 26) {
            val req = permintaanFokus ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
                .setOnAudioFocusChangeListener(pendengar, handler)
                .build().also { permintaanFokus = it }
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(pendengar, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return hasil == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun lepasFokus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) permintaanFokus?.let { am.abandonAudioFocusRequest(it) }
            else {
                @Suppress("DEPRECATION")
                fokus?.let { am.abandonAudioFocus(it) }
            }
        } catch (_: Exception) { }
        permintaanFokus = null
    }

    private fun ambilKunci() {
        try {
            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "$packageName:QuranSuara").apply { setReferenceCounted(false) }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        } catch (_: Exception) { }
        if (!penerimaTerdaftar) {
            try { registerReceiver(penerimaBising, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)); penerimaTerdaftar = true } catch (_: Exception) { }
        }
    }

    private fun lepasKunci() {
        try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Exception) { }
        wifiLock = null
        if (penerimaTerdaftar) { try { unregisterReceiver(penerimaBising) } catch (_: Exception) { }; penerimaTerdaftar = false }
    }

    // ---------- Notifikasi ----------

    private fun buatSaluran() {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(SALURAN, tr("Pemutar Al-Qur'an (perintah suara)", "Qur'an player (voice command)"), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun aksiPending(kode: Int, aksi: String): PendingIntent = PendingIntent.getService(
        this, kode, Intent(this, PemutarQuranService::class.java).setAction(aksi), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun bangunNotifikasi(isi: String): Notification {
        val buka = PendingIntent.getActivity(this, 9611, Intent(this, KhatamActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, SALURAN) else Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(tr("Memutar Al-Qur'an", "Playing the Qur'an"))
            .setContentText(isi)
            .setContentIntent(buka)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                if (dijeda) tr("Lanjut", "Resume") else tr("Jeda", "Pause"),
                aksiPending(9612, if (dijeda) ACTION_LANJUT else ACTION_JEDA)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                tr("Berhenti", "Stop"), aksiPending(9613, ACTION_BERHENTI)).build())
        return b.build()
    }

    private fun mulaiForeground(isi: String) {
        val n = bangunNotifikasi(isi)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
        } catch (_: Exception) {
            // Android menolak layanan foreground dimulai dari latar belakang (mis. perintah kendali tanpa audio berjalan).
            stopSelf()
        }
    }

    private fun perbaruiNotifikasi() {
        val status = if (dijeda) tr(" · dijeda", " · paused") else if (menungguJeda) tr(" · jeda", " · pause") else ""
        val total = totalItem()
        val posisi = when {
            ulangN == 0 && daftarUrl.isNotEmpty() -> " · " + tr("putaran ", "round ") + (indeks / daftarUrl.size + 1)
            total > 1 -> " · " + (indeks + 1) + "/" + total
            else -> ""
        }
        try { getSystemService(NotificationManager::class.java).notify(NOTIF_ID, bangunNotifikasi(label + posisi + status)) } catch (_: Exception) { }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        generasi++
        lepasPemutar()
        lepasFokus()
        lepasKunci()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PUTAR = "com.novan.bateraibicara.action.QURAN_PUTAR"
        const val ACTION_JEDA = "com.novan.bateraibicara.action.QURAN_JEDA"
        const val ACTION_LANJUT = "com.novan.bateraibicara.action.QURAN_LANJUT"
        const val ACTION_BERHENTI = "com.novan.bateraibicara.action.QURAN_BERHENTI"
        const val EXTRA_KANDIDAT = "kandidat_perintah_quran"
        private const val SALURAN = "pemutar_quran_suara"
        private const val NOTIF_ID = 9610

        fun kirim(context: Context, aksi: String, kandidat: List<String>? = null) {
            val i = Intent(context, PemutarQuranService::class.java).setAction(aksi)
            if (kandidat != null) i.putStringArrayListExtra(EXTRA_KANDIDAT, ArrayList(kandidat))
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
}

/** Penafsir perintah putar Al-Qur'an yang berdiri sendiri (tanpa teks Al-Qur'an/Khatam): nama surah, nomor surah, ayat, rentang ayat, juz. */
object PenafsirQuran {
    data class Perintah(
        val juz: Int?, val surah: Int?, val ayat: Int?, val ayatAkhir: Int?,
        val ulang: Int = 1,              // jumlah putaran; 0 = tanpa batas
        val perAyat: Boolean = false,    // true: tiap ayat diulang; false: seluruh bagian diulang
        val sampaiAkhir: Boolean = false,
        val relatif: Int = 0,            // +1 berikutnya, -1 sebelumnya (tanpa acuan surah/ayat/juz)
        val relatifSatuan: Int = 0,      // 0 ayat, 1 surah, 2 juz
        val ulangiTerakhir: Boolean = false,
        val kecepatan: Float? = null,
        val jedaDetik: Int = 0
    ) {
        /** Ada permintaan di luar "putar X" biasa; hanya pemutar latar belakang yang memahaminya. */
        val adaDirektif: Boolean
            get() = ulang != 1 || perAyat || sampaiAkhir || relatif != 0 || ulangiTerakhir || kecepatan != null || jedaDetik > 0
    }

    private val jumlahAyatSurah = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135, 112, 78, 118, 64, 77, 227,
        93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96,
        29, 22, 24, 13, 14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17,
        19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )

    /** Awal tiap juz (surah, ayat) menurut mushaf Madinah. */
    private val awalJuz = arrayOf(
        1 to 1, 2 to 142, 2 to 253, 3 to 93, 4 to 24, 4 to 148, 5 to 82, 6 to 111, 7 to 88, 8 to 41,
        9 to 93, 11 to 6, 12 to 53, 15 to 1, 17 to 1, 18 to 75, 21 to 1, 23 to 1, 25 to 21, 27 to 56,
        29 to 46, 33 to 31, 36 to 28, 39 to 32, 41 to 47, 46 to 1, 51 to 31, 58 to 1, 67 to 1, 78 to 1
    )

    private val namaLatin = listOf(
        "AlFaatihah", "AlBaqarah", "AliImran", "AnNisaa", "AlMaaidah", "AlAnaam",
        "AlAaraaf", "AlAnfaal", "AtTaubah", "Yunus", "Huud", "Yusuf",
        "ArRaad", "Ibrahim", "AlHijr", "AnNahl", "AlIsraa", "AlKahfi",
        "Maryam", "Thaahaa2", "AlAnbiyaa", "AlHajj", "AlMuminuun", "AnNuur",
        "AlFurqaan", "AsySyuaaraa", "AnNaml", "AlQashash", "AlAnkabuut", "ArRuum",
        "Luqman", "AsSajdah", "AlAhzab", "Sabaa", "Faathir", "Yaasiin",
        "AshShaaffaat", "Shaad", "AzZumar", "AlMuumin", "Fushshilat", "AsySyuura",
        "AzZukhruf", "AdDukhaan", "AlJaatsiyah", "AlAhqaaf", "Muhammad", "AlFath",
        "AlHujuraat", "Qaaf", "AdzDzaariyaat", "AthThuur", "AnNajm", "AlQamar",
        "ArRahmaan", "AlWaqiah", "AlHadiid", "AlMujaadilah", "AlHasyr", "AlMumtahanah",
        "AshShaff", "AlJumuah", "AlMunaafiquun", "AtTaghaabun", "AthThalaaq", "AtTahrim",
        "AlMulk", "AlQalam", "AlHaaqqah", "AlMaaarij", "Nuh", "AlJin",
        "AlMuzzammil", "AlMuddatstsir", "AlQiyaamah", "AlInsaan", "AlMursalaat", "AnNaba",
        "AnNaaziaat", "Abasa", "AtTakwiir", "AlInfithaar", "AlMuthaffifin", "AlInsyiqaaq",
        "AlBuruuj", "AthThaariq", "AlAalaa", "AlGhaasyiyah", "AlFajr", "AlBalad",
        "AsySyams", "AlLail", "AdhDhuhaa", "AlamNasyrah", "AtTiin", "AlAlaq",
        "AlQadr", "AlBayyinah", "AlZalzalah", "AlAadiyaat", "AlQaariah", "AtTakaatsur",
        "AlAshr", "AlHumazah", "AlFiil", "Quraisy", "AlMaauun", "AlKautsar",
        "AlKaafiruun", "AnNashr", "AlLahab", "AlIkhlash", "AlFalaq", "AnNaas"
    )

    fun jumlahAyat(surah: Int): Int = if (surah in 1..114) jumlahAyatSurah[surah - 1] else 0

    fun global(surah: Int, ayat: Int): Int {
        var g = ayat
        for (i in 1 until surah) g += jumlahAyatSurah[i - 1]
        return g
    }

    fun rentangJuz(juz: Int): IntRange? {
        if (juz !in 1..30) return null
        val (s, a) = awalJuz[juz - 1]
        val awal = global(s, a)
        val akhir = if (juz < 30) { val (s2, a2) = awalJuz[juz]; global(s2, a2) - 1 } else 6236
        return awal..akhir
    }

    private fun kolapsHuruf(teks: String): String {
        val sb = StringBuilder()
        for (c in teks.lowercase()) {
            if (c in 'a'..'z' && (sb.isEmpty() || sb[sb.length - 1] != c)) sb.append(c)
        }
        return sb.toString()
    }

    private fun gantiKataAngka(tokens: List<String>): List<String> {
        val dasar = mapOf(
            "nol" to 0, "satu" to 1, "dua" to 2, "tiga" to 3, "empat" to 4, "lima" to 5, "enam" to 6, "tujuh" to 7,
            "delapan" to 8, "sembilan" to 9, "sepuluh" to 10, "sebelas" to 11,
            "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
            "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
            "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19,
            "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
        )
        val hasil = mutableListOf<String>()
        var total = 0; var seg = 0; var ada = false
        fun tutup() { if (ada) hasil.add((total + seg).toString()); total = 0; seg = 0; ada = false }
        for (t in tokens) {
            val v = dasar[t]
            when {
                v != null -> { seg += v; ada = true }
                t == "belas" && ada -> seg += 10
                t == "puluh" && ada -> seg *= 10
                (t == "ratus" || t == "hundred") && ada -> { total += (if (seg == 0) 1 else seg) * 100; seg = 0 }
                t == "seratus" -> { total += 100; ada = true }
                (t == "dan" || t == "and") && ada -> { }
                else -> { tutup(); hasil.add(t) }
            }
        }
        tutup()
        return hasil
    }

    private fun cocokkanNamaSurah(sisa: String): Int? {
        val teks = kolapsHuruf(sisa)
        if (teks.isEmpty()) return null
        val awalan = listOf("asy", "ash", "adh", "adz", "ath", "al", "an", "ar", "as", "at", "ad", "az")
        var terbaik: Int? = null; var panjangTerbaik = 0
        fun coba(kandidat: String, nomor: Int) {
            if (kandidat.length < 2) return
            val cocok = if (kandidat.length <= 3) teks == kandidat else teks.contains(kandidat)
            if (cocok && kandidat.length > panjangTerbaik) { terbaik = nomor; panjangTerbaik = kandidat.length }
        }
        for (i in 0 until 114) {
            val lengkap = kolapsHuruf(namaLatin.getOrNull(i).orEmpty())
            coba(lengkap, i + 1)
            awalan.firstOrNull { lengkap.startsWith(it) && lengkap.length - it.length >= 4 }?.let { coba(lengkap.substring(it.length), i + 1) }
        }
        return terbaik
    }

    private const val MAKS_ULANG = 999
    private val kunciSurahSet = setOf("surah", "surat", "sura")
    private val kunciAyatSet = setOf("ayat", "ayah", "verse", "aya")
    private val kunciJuzSet = setOf("juz", "jus", "juzz")
    private val kataKali = setOf("kali", "times", "time", "x")

    /** Isyarat tambahan dalam ucapan di luar "putar X": pengulangan, kecepatan, jeda, rentang sampai akhir, ayat berikutnya, ulangi. */
    private class Direktif {
        var ulang = 1          // 0 = tanpa batas
        var perAyat = false
        var sampaiAkhir = false
        var relatif = 0
        var satuan = 0         // 0 ayat, 1 surah, 2 juz
        var kataUlang = false
        var kecepatan: Float? = null
        var jeda = 0
    }

    private fun hapusTerakhir(daftar: ArrayList<String>) { if (daftar.isNotEmpty()) daftar.removeAt(daftar.size - 1) }

    /**
     * Mengeluarkan isyarat tambahan dari token ucapan dan mengembalikan token sisanya untuk ditafsirkan sebagai acuan
     * (surah/ayat/juz). Contoh: "putar surah 1 ayat 7 sebanyak 5 kali" menghasilkan ulang=5 dan sisa "putar surah 1 ayat 7".
     */
    private fun ekstrakDirektif(tokens: List<String>, d: Direktif): List<String> {
        val keluar = ArrayList<String>()
        val polaAngkaX = Regex("^(\\d{1,3})x$")
        val polaXAngka = Regex("^x(\\d{1,3})$")
        val kataPengisi = setOf("sebanyak", "selama", "sebesar", "sebanyaknya", "diulang", "ulangi", "ulang", "mengulang", "repeat", "repeated", "for")
        val kataUlangSemua = setOf("ulangi", "ulang", "diulang", "mengulang", "repeat", "repeated", "again", "lagi", "berulang")
        val penghubung = setOf("sampai", "hingga", "sd", "s", "d", "to", "until", "till", "through", "ke")
        val kataAkhir = setOf("akhir", "selesai", "habis", "tamat", "end", "finish")
        val kataPerAyat = setOf("setiap", "tiap", "masing", "each", "every")
        val kataBerikut = setOf("berikutnya", "selanjutnya", "next", "sesudahnya", "setelahnya")
        val kataSebelum = setOf("sebelumnya", "previous", "prev")
        val kataJeda = setOf("jeda", "selang", "jarak", "interval", "gap", "delay")
        val kataDetik = setOf("detik", "second", "seconds", "sec", "secs")
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            val n = t.toIntOrNull()
            val berikut = tokens.getOrNull(i + 1)
            // "5 kali", "lima kali" (sudah menjadi angka), "5 times"
            if (n != null && berikut != null && berikut in kataKali) {
                d.ulang = n.coerceIn(1, MAKS_ULANG)
                val pengisi = keluar.lastOrNull()
                if (pengisi != null && pengisi in kataPengisi) { if (pengisi in kataUlangSemua) d.kataUlang = true; hapusTerakhir(keluar) }
                i += 2
                continue
            }
            // "5x" atau "x5"
            val mAx = polaAngkaX.matchEntire(t) ?: polaXAngka.matchEntire(t)
            if (mAx != null) {
                d.ulang = mAx.groupValues[1].toInt().coerceIn(1, MAKS_ULANG)
                val pengisi = keluar.lastOrNull()
                if (pengisi != null && pengisi in kataPengisi) { if (pengisi in kataUlangSemua) d.kataUlang = true; hapusTerakhir(keluar) }
                i++
                continue
            }
            if (t == "sekali") { i++; continue }
            // tanpa batas: "terus menerus", "selamanya", "tanpa batas", "tak terbatas", "forever", "loop"
            if (t == "menerus" || t == "selamanya" || t == "forever" || t == "loop") {
                if (t == "menerus" && keluar.lastOrNull() == "terus") hapusTerakhir(keluar)
                d.ulang = 0; i++; continue
            }
            if (t == "batas" && keluar.lastOrNull() == "tanpa") { hapusTerakhir(keluar); d.ulang = 0; i++; continue }
            if (t == "terbatas" && (keluar.lastOrNull() == "tak" || keluar.lastOrNull() == "tidak")) { hapusTerakhir(keluar); d.ulang = 0; i++; continue }
            if (t in kataPerAyat) { d.perAyat = true; i++; continue }
            // kecepatan
            if (t == "pelan" || t == "lambat" || t == "slow" || t == "slowly" || t == "perlahan") { d.kecepatan = 0.75f; i++; continue }
            if (t == "cepat" || t == "fast" || t == "quick" || t == "quickly") {
                val k = d.kecepatan
                d.kecepatan = if (k != null && k > 1.0f) 1.5f else 1.25f
                i++; continue
            }
            if (t == "normal") { d.kecepatan = 1.0f; i++; continue }
            if (t in kataUlangSemua) { d.kataUlang = true; i++; continue }
            if (t == "mulai" || t == "mulailah" || t == "dimulai" || t == "start" || t == "begin") { i++; continue }
            // "sampai akhir", "hingga selesai", "ke akhir", "sampai ayat terakhir"
            if (t in kataAkhir && keluar.lastOrNull()?.let { it in penghubung } == true) {
                hapusTerakhir(keluar); d.sampaiAkhir = true; i++; continue
            }
            if (t == "terakhir") {
                val a = keluar.lastOrNull()
                val b = if (keluar.size >= 2) keluar[keluar.size - 2] else null
                if (a != null && a in penghubung) { hapusTerakhir(keluar); d.sampaiAkhir = true; i++; continue }
                if (a != null && a in kunciAyatSet && b != null && b in penghubung) { hapusTerakhir(keluar); hapusTerakhir(keluar); d.sampaiAkhir = true; i++; continue }
            }
            // "ayat berikutnya", "surah sebelumnya", "juz selanjutnya", "next verse"
            if (t in kataBerikut || t in kataSebelum) {
                d.relatif = if (t in kataBerikut) 1 else -1
                val terakhir = keluar.lastOrNull()
                if (terakhir != null && terakhir in kunciSurahSet) { d.satuan = 1; hapusTerakhir(keluar) }
                else if (terakhir != null && terakhir in kunciJuzSet) { d.satuan = 2; hapusTerakhir(keluar) }
                else if (terakhir != null && terakhir in kunciAyatSet) { d.satuan = 0; hapusTerakhir(keluar) }
                else if (berikut != null && berikut in kunciSurahSet) { d.satuan = 1; i++ }
                else if (berikut != null && berikut in kunciJuzSet) { d.satuan = 2; i++ }
                else if (berikut != null && berikut in kunciAyatSet) { d.satuan = 0; i++ }
                i++; continue
            }
            // jeda: "jeda 3 detik"
            if (t in kataJeda) {
                val angka = tokens.getOrNull(i + 1)?.toIntOrNull()
                val satuanWaktu = tokens.getOrNull(i + 2)
                if (angka != null && satuanWaktu != null && satuanWaktu in kataDetik) {
                    d.jeda = angka.coerceIn(0, 60)
                    val sebelum = keluar.lastOrNull()
                    if (sebelum != null && (sebelum == "dengan" || sebelum == "beri" || sebelum == "with")) hapusTerakhir(keluar)
                    i += 3
                    continue
                }
            }
            keluar.add(t)
            i++
        }
        return keluar
    }

    private fun tokenUcapan(ucapan: String): List<String> =
        gantiKataAngka(ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() })

    /** Ada isyarat tambahan (pengulangan dan lain-lain) yang hanya dipahami pemutar latar belakang. */
    fun adaDirektif(kandidat: List<String>): Boolean = tafsir(kandidat)?.adaDirektif == true

    /** Ucapan tanpa isyarat tambahan, untuk penafsir lain (Khatam) yang tidak memahaminya. */
    fun bersihkanDirektif(kandidat: List<String>): List<String> =
        kandidat.map { ekstrakDirektif(tokenUcapan(it), Direktif()).joinToString(" ") }

    /** Nomor juz (1..30) tempat ayat berada. */
    fun juzDari(surah: Int, ayat: Int): Int {
        var hasil = 1
        for (j in awalJuz.indices) {
            val (s, a) = awalJuz[j]
            if (surah > s || (surah == s && ayat >= a)) hasil = j + 1
        }
        return hasil
    }

    fun posisiDariGlobal(global: Int): Pair<Int, Int>? {
        if (global !in 1..6236) return null
        var sisa = global
        for (i in jumlahAyatSurah.indices) {
            if (sisa <= jumlahAyatSurah[i]) return (i + 1) to sisa
            sisa -= jumlahAyatSurah[i]
        }
        return null
    }

    fun tafsir(kandidat: List<String>): Perintah? {
        val kataPerintah = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "please", "tolong", "nomor", "number",
            "ke", "dari", "the", "of", "di", "yang", "dengan", "lalu", "alquran", "quran")
        val kunciJuz = kunciJuzSet
        val kunciAyat = kunciAyatSet
        val kunciSurah = kunciSurahSet
        val penghubungRentang = setOf("sampai", "hingga", "dengan", "sd", "s", "d", "to", "through", "until", "till", "ke", "and", "dan", "sampe")
        for (ucapan in kandidat) {
            val d = Direktif()
            val tokens = ekstrakDirektif(tokenUcapan(ucapan), d)
            var juz: Int? = null; var surah: Int? = null; var ayat: Int? = null; var ayatAkhir: Int? = null
            val sisa = mutableListOf<String>()
            val angkaLepas = mutableListOf<Int>()
            var i = 0
            while (i < tokens.size) {
                val t = tokens[i]
                val berikut = tokens.getOrNull(i + 1)?.toIntOrNull()
                when {
                    t in kunciJuz && berikut != null -> { juz = berikut; i += 2; continue }
                    t in kunciAyat && berikut != null -> {
                        if (ayat == null) {
                            ayat = berikut
                            var k = i + 2
                            val awalK = k
                            while (k < tokens.size && tokens[k] in penghubungRentang) k++
                            if (k > awalK && k < tokens.size && tokens[k] in kunciAyat) k++
                            val angkaAkhir = tokens.getOrNull(k)?.toIntOrNull()
                            if (angkaAkhir != null) { ayatAkhir = angkaAkhir; k++ }
                            i = k
                        } else { ayatAkhir = berikut; i += 2 }
                        continue
                    }
                    t in kunciSurah && berikut != null -> { surah = berikut; i += 2; continue }
                    t in kunciJuz || t in kunciAyat || t in kunciSurah || t in kataPerintah -> { }
                    t.toIntOrNull() != null -> angkaLepas.add(t.toInt())
                    else -> sisa.add(t)
                }
                i++
            }
            val dariNama = cocokkanNamaSurah(sisa.joinToString(" "))
            if (surah == null && dariNama != null) {
                surah = dariNama
                if (ayat == null && juz == null && angkaLepas.isNotEmpty()) {
                    ayat = angkaLepas[0]
                    if (angkaLepas.size >= 2) ayatAkhir = angkaLepas[1]
                }
            } else if (surah == null && ayat == null && juz == null && angkaLepas.size >= 2) {
                surah = angkaLepas[0]; ayat = angkaLepas[1]
            } else if (surah == null && ayat == null && juz == null && angkaLepas.size == 1 && sisa.isEmpty()) {
                surah = angkaLepas[0]
            }
            if (juz == null && surah == null && ayat == null) {
                // Tanpa acuan: "ayat berikutnya", "surah sebelumnya", "ulangi 3 kali", "putar lagi".
                if (d.relatif != 0) return Perintah(null, null, null, null, d.ulang, d.perAyat, false, d.relatif, d.satuan, false, d.kecepatan, d.jeda)
                if (d.kataUlang) return Perintah(null, null, null, null, d.ulang, d.perAyat, false, 0, 0, true, d.kecepatan, d.jeda)
                continue
            }
            return Perintah(juz, surah, ayat, ayatAkhir, d.ulang, d.perAyat, d.sampaiAkhir, 0, 0, false, d.kecepatan, d.jeda)
        }
        return null
    }
}
