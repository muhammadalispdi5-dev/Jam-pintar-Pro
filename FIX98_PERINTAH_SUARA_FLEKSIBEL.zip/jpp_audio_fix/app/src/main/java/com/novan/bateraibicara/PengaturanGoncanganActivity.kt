package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Switch
import android.widget.Toast

/** Pengaturan khusus pemicu suara dengan goncangan, terpisah dari sakelar Beritahu Saya. */
class PengaturanGoncanganActivity : Halaman() {
    override val judulHalaman = R.string.judul_pengaturan_goncangan
    private val pengaturan by lazy { getSharedPreferences("pengaturan", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var tingkat: TextView
    private var sedangMenyusun = false
    private lateinit var saklarGoncangan: Switch

    private fun teks(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun bangun() {
        bagian(teks("Aktivasi perintah suara dengan goncangan", "Shake-to-activate voice commands"))
        info(teks(
            "Goyangkan HP dua kali secara sengaja untuk membuka pengenalan perintah suara. Pemicu tetap bekerja saat layar mati atau terkunci selama layanan diizinkan berjalan oleh Android.",
            "Shake the phone twice deliberately to open voice recognition. The trigger can work while the screen is off or locked while Android allows the service to run."
        ))

        val aktifAwal = pengaturan.getBoolean(GoncanganSuaraService.KEY_AKTIF, false)
        saklarGoncangan = saklar(teks("Aktifkan pemicu goncangan", "Enable shake trigger"), aktifAwal) { aktif ->
            if (sedangMenyusun) return@saklar
            if (aktif) {
                val manager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                if (manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true) == null && manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null) {
                    Toast.makeText(this, teks("Sensor akselerometer tidak tersedia pada HP ini.", "The accelerometer sensor is not available on this phone."), Toast.LENGTH_LONG).show()
                    sedangMenyusun = true
                    // Saklar dikembalikan pada keadaan nonaktif tanpa menyimpan status aktif.
                    recreate()
                    return@saklar
                }
                pengaturan.edit().putBoolean(GoncanganSuaraService.KEY_AKTIF, true).apply()
                mintaIzinLayarKunci()
                try {
                    GoncanganSuaraService.mulai(this)
                    status.text = teks("Pemicu goncangan aktif. Goyangkan HP dua kali untuk mencoba.", "Shake trigger is active. Shake the phone twice to test.")
                } catch (_: Exception) {
                    pengaturan.edit().putBoolean(GoncanganSuaraService.KEY_AKTIF, false).apply()
                    sedangMenyusun = true
                    saklarGoncangan.isChecked = false
                    sedangMenyusun = false
                    status.text = teks("Layanan tidak dapat dimulai. Periksa izin dan pembatasan baterai Android.", "The service could not start. Check Android permissions and battery restrictions.")
                }
            } else {
                pengaturan.edit().putBoolean(GoncanganSuaraService.KEY_AKTIF, false).apply()
                GoncanganSuaraService.hentikan(this)
                status.text = teks("Pemicu goncangan dinonaktifkan.", "Shake trigger is disabled.")
            }
        }

        bagian(teks("Sensitivitas goncangan", "Shake sensitivity"))
        val nilaiAwal = pengaturan.getInt(GoncanganSuaraService.KEY_SENSITIVITAS, 5).coerceIn(1, 10)
        tingkat = info("")
        val seek = SeekBar(this).apply {
            max = 9
            progress = nilaiAwal - 1
            contentDescription = teks("Sensitivitas goncangan dari 1 paling rendah sampai 10 paling tinggi", "Shake sensitivity from 1 lowest to 10 highest")
        }
        root.addView(seek, android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            dp(56)
        ))
        perbaruiLabelSensitivitas(nilaiAwal)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val nilai = progress + 1
                perbaruiLabelSensitivitas(nilai)
                if (fromUser) pengaturan.edit().putInt(GoncanganSuaraService.KEY_SENSITIVITAS, nilai).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        info(teks(
            "1 = paling rendah (perlu goncangan lebih kuat). 10 = paling tinggi (goncangan ringan lebih mudah terdeteksi). Jika sering aktif tanpa sengaja, turunkan sensitivitas.",
            "1 = lowest (requires a stronger shake). 10 = highest (lighter shakes are detected more easily). If it triggers accidentally, lower the sensitivity."
        ))

        bagian(teks("Cara kerja dan privasi", "How it works and privacy"))
        info(teks(
            "Saat aktif, layanan sensor berjalan sebagai layanan latar depan dan menampilkan notifikasi tetap. Goncangan hanya membuka pengenalan suara; mikrofon baru digunakan oleh layanan pengenalan suara setelah layar perintah dibuka. Pada HP tanpa akselerometer wake-up, layanan perlu menjaga CPU tetap aktif sehingga baterai bisa lebih boros. Nonaktifkan sakelar ini untuk menghentikan pemantauan sensor.",
            "When enabled, the sensor runs as a foreground service with an ongoing notification. A shake only opens voice recognition; the microphone is used by the speech-recognition service after the command screen opens. Phones without a wake-up accelerometer may need the CPU held awake, which can use more battery. Turn this switch off to stop sensor monitoring."
        ))
        status = info(if (aktifAwal) teks("Status: pemicu goncangan aktif.", "Status: shake trigger is active.") else teks("Status: pemicu goncangan nonaktif.", "Status: shake trigger is off."))
        bagian(teks("Agar berfungsi saat layar terkunci", "To work while the screen is locked"))
        info(teks(
            "Izinkan mikrofon agar pengenalan suara berjalan langsung di atas layar kunci (tanpa layar pengenal aplikasi lain yang ditahan saat terkunci), izinkan notifikasi agar notifikasi layar penuh \"Perintah suara siap\" dapat membuka layar perintah, lalu izinkan notifikasi layar penuh bila Android 14 ke atas memintanya. Saat terkunci, membaca waktu, tanggal, hari libur, dan jadwal sholat langsung berjalan. Memutar Al-Qur'an (surah, ayat, juz) langsung berjalan di latar belakang tanpa membuka kunci; katakan berhenti, jeda, atau lanjut untuk mengendalikannya. Perintah yang membuka aplikasi, menelepon, memilih qari, atau membacakan pesan pribadi meminta Anda membuka kunci layar lebih dulu.",
            "Allow the microphone so voice recognition runs directly above the lock screen (other apps' recognition screens are held back while locked), allow notifications so the full-screen \"Voice command is ready\" notification can open the command screen, then allow full-screen notifications if Android 14 or newer asks for it. While locked, the time, date, holidays, and prayer times are read right away. Qur'an playback (surah, verse, juz) runs in the background without unlocking; say stop, pause, or resume to control it. Commands that open apps, place calls, choose a reciter, or read private messages ask you to unlock the screen first."
        ))
        tombol(teks("Izinkan mikrofon dan notifikasi", "Allow microphone and notifications")) { mintaIzinLayarKunci(tampilkanPesan = true) }
        tombol(teks("Izinkan notifikasi layar penuh", "Allow full-screen notifications")) { bukaIzinLayarPenuh() }
        tombol(teks("Buka pengaturan optimasi baterai Android", "Open Android battery optimization settings")) {
            try {
                val intent = android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, teks("Pengaturan baterai tidak dapat dibuka.", "Battery settings could not be opened."), Toast.LENGTH_LONG).show()
            }
        }
    }

    /** FIX95: izin yang perlu diberikan sebelum layar terkunci (tidak dapat diminta saat terkunci). */
    private fun mintaIzinLayarKunci(tampilkanPesan: Boolean = false) {
        val perlu = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) perlu.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) perlu.add(Manifest.permission.POST_NOTIFICATIONS)
        if (perlu.isNotEmpty()) {
            requestPermissions(perlu.toTypedArray(), 9411)
        } else if (tampilkanPesan) {
            Toast.makeText(this, teks("Izin mikrofon dan notifikasi sudah diberikan.", "Microphone and notification permissions are already granted."), Toast.LENGTH_LONG).show()
        }
    }

    private fun bukaIzinLayarPenuh() {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + packageName)))
            } else {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            }
        } catch (_: Exception) {
            Toast.makeText(this, teks("Pengaturan notifikasi tidak dapat dibuka.", "Notification settings could not be opened."), Toast.LENGTH_LONG).show()
        }
    }

    private fun perbaruiLabelSensitivitas(nilai: Int) {
        tingkat.text = teks("Tingkat sensitivitas: ", "Sensitivity level: ") + nilai + "/10" + when {
            nilai <= 3 -> teks(" (rendah)", " (low)")
            nilai <= 7 -> teks(" (sedang)", " (medium)")
            else -> teks(" (tinggi)", " (high)")
        }
    }
}
