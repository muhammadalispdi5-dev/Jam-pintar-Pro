package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import java.util.Calendar

/**
 * FIX75: membunyikan alarm jam (nada, ucapan, getar) dari layanan latar depan.
 *
 * Alarm dapat dihentikan dengan tombol notifikasi (Matikan/Tunda) atau dengan menelungkupkan HP lewat
 * [PembungkamTelungkup], sama seperti notifikasi aplikasi lainnya. Alarm berhenti sendiri setelah [BATAS_MS].
 */
class AlarmJamService : Service() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    companion object {
        const val AKSI_MATIKAN = "com.novan.jambicarapro.ALARM_JAM_MATIKAN"
        const val AKSI_TUNDA = "com.novan.jambicarapro.ALARM_JAM_TUNDA"
        const val BATAS_MS = 180_000L
        private const val ID_NOTIF = 9101
        private const val ID_NOTIF_TERLEWAT = 9102
        private const val KANAL = "alarm_jam"
        private const val KUNCI_BUNGKAM = "alarm_jam"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var pembicara: Pembicara? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var item: ItemAlarm? = null
    private var berhenti = true
    private var uji = false
    private var gen = 0

    override fun onBind(intent: Intent?): IBinder? = null

    private fun t(id: String, en: String): String = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            AKSI_MATIKAN -> { akhiri(); return START_NOT_STICKY }
            AKSI_TUNDA -> { tunda(); return START_NOT_STICKY }
        }
        uji = intent?.getBooleanExtra("tes", false) ?: false
        val id = intent?.getIntExtra("alarm_id", -1) ?: -1
        val a = if (id >= 0) AlarmJam.cari(this, id) else null
        // startForeground wajib segera dipanggil setelah startForegroundService, bahkan bila alarm ternyata sudah dihapus.
        buatKanal()
        startForeground(ID_NOTIF, bangunNotifikasi(a))
        if (a == null) { akhiri(); return START_NOT_STICKY }
        mulaiAlarm(a)
        return START_NOT_STICKY
    }

    private fun mulaiAlarm(a: ItemAlarm) {
        handler.removeCallbacksAndMessages(null)
        hentikanSuara()
        item = a
        berhenti = false
        gen++
        val g = gen
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock?.let { if (it.isHeld) it.release() }
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, packageName + ":AlarmJam").apply {
                setReferenceCounted(false)
                acquire(BATAS_MS + 20_000L)
            }
        } catch (_: Exception) { }
        // Telungkupkan HP untuk mematikan alarm (aturan gerakan dan sakelar sama dengan notifikasi lain).
        PembungkamTelungkup.mulai(this, KUNCI_BUNGKAM, BATAS_MS + 15_000L) { akhiri() }
        if (a.getar) mulaiGetar()
        siklus(g)
        handler.postDelayed({
            if (g == gen && !berhenti) {
                val terlewat = item
                akhiri()
                if (terlewat != null && !uji) notifikasiTerlewat(terlewat)
            }
        }, BATAS_MS)
    }

    /** Mode 0: nada berulang terus. Mode 1: bip + ucapan tiap 9 detik. Mode 2: nada 5 detik lalu ucapan, bergantian. */
    private fun siklus(g: Int) {
        if (berhenti || g != gen) return
        val a = item ?: return
        // Ucapan ditahan Mode Acara; alarm tetap berbunyi sebagai nada agar tidak senyap.
        val mode = if (a.mode != 0 && ModeAcara.aktif(this)) 0 else a.mode
        when (mode) {
            0 -> mulaiNada(true, g)
            1 -> {
                bipSingkat()
                handler.postDelayed({ if (g == gen && !berhenti) ucapkan(a) }, 600L)
                handler.postDelayed({ siklus(g) }, 9_000L)
            }
            else -> {
                mulaiNada(false, g)
                handler.postDelayed({ if (g == gen && !berhenti) { hentikanNada(); ucapkan(a) } }, 5_000L)
                handler.postDelayed({ siklus(g) }, 14_000L)
            }
        }
    }

    private fun teksUcapan(a: ItemAlarm): String {
        val dasar = try { JamWaktu.ucapan(Prefs(this), Calendar.getInstance()) } catch (_: Exception) { "" }
        val waktu = if (dasar.isBlank()) "%d:%02d".format(a.jam, a.menit) else dasar
        val label = if (a.label.isNotBlank()) a.label.trim() + ". " else ""
        return "Alarm. " + label + waktu
    }

    private fun ucapkan(a: ItemAlarm) {
        try {
            val p = pembicara ?: Pembicara(this, Prefs(this).suara("jam"), null).also { pembicara = it }
            p.ucapkan(teksUcapan(a), true)
        } catch (_: Exception) { }
    }

    private fun atributAlarm(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private fun mulaiNada(ulang: Boolean, g: Int) {
        hentikanNada()
        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            if (uri == null) { nadaCadangan(ulang, g); return }
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(atributAlarm())
            mp.setDataSource(applicationContext, uri)
            mp.isLooping = ulang
            mp.setOnPreparedListener { siap -> if (g == gen && !berhenti && player === siap) siap.start() }
            mp.setOnErrorListener { _, _, _ ->
                if (g == gen && !berhenti) { hentikanNada(); nadaCadangan(ulang, g) }
                true
            }
            mp.prepareAsync()
        } catch (_: Exception) {
            nadaCadangan(ulang, g)
        }
    }

    /** Bila nada alarm sistem tidak dapat diputar, pakai melodi bawaan aplikasi lewat saluran alarm. */
    private fun nadaCadangan(ulang: Boolean, g: Int) {
        Melodi.putar(this, 1, atributAlarm()) {
            if (ulang && g == gen && !berhenti) handler.postDelayed({ if (g == gen && !berhenti) nadaCadangan(true, g) }, 400L)
        }
    }

    private fun bipSingkat() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) { } }, 700L)
        } catch (_: Exception) { }
    }

    private fun hentikanNada() {
        val mp = player ?: return
        player = null
        try { mp.setOnPreparedListener(null) } catch (_: Exception) { }
        try { mp.setOnErrorListener(null) } catch (_: Exception) { }
        try { mp.stop() } catch (_: Exception) { }
        try { mp.release() } catch (_: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun mulaiGetar() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (v?.hasVibrator() == true) {
                val pola = longArrayOf(0, 700, 500)
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pola, 0)) else v.vibrate(pola, 0)
            }
        } catch (_: Exception) { }
    }

    private fun hentikanGetar() {
        try { (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel() } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        hentikanNada()
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
        hentikanGetar()
    }

    private fun tunda() {
        val a = item
        if (a != null && a.tundaMenit > 0 && !uji) {
            AlarmJam.jadwalkanTunda(this, a.id, a.tundaMenit)
            try {
                Toast.makeText(this, t("Alarm ditunda " + a.tundaMenit + " menit.", "Alarm snoozed for " + a.tundaMenit + " minutes."), Toast.LENGTH_LONG).show()
            } catch (_: Exception) { }
        }
        akhiri()
    }

    /** Hentikan semua suara/getar, lepaskan penahan CPU dan sensor telungkup, lalu tutup layanan. */
    private fun akhiri() {
        berhenti = true
        gen++
        handler.removeCallbacksAndMessages(null)
        hentikanSuara()
        PembungkamTelungkup.selesai(KUNCI_BUNGKAM)
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        berhenti = true
        gen++
        handler.removeCallbacksAndMessages(null)
        hentikanSuara()
        PembungkamTelungkup.selesai(KUNCI_BUNGKAM)
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    // ---------- Notifikasi ----------
    private fun buatKanal() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            val nama = t("Alarm Jam", "Clock Alarms")
            if (nm.getNotificationChannel(KANAL) == null) {
                val ch = NotificationChannel(KANAL, nama, NotificationManager.IMPORTANCE_HIGH)
                ch.setSound(null, null)
                ch.enableVibration(false)
                nm.createNotificationChannel(ch)
            } else {
                nm.createNotificationChannel(NotificationChannel(KANAL, nama, nm.getNotificationChannel(KANAL).importance))
            }
        }
    }

    private fun flag() = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    private fun builder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, KANAL) else Notification.Builder(this)

    @Suppress("DEPRECATION")
    private fun bangunNotifikasi(a: ItemAlarm?): Notification {
        val buka = PendingIntent.getActivity(
            this, 9103, Intent(this, JamActivity::class.java).putExtra("kelompok", "alarm"), flag()
        )
        val matikan = PendingIntent.getService(this, 9104, Intent(this, AlarmJamService::class.java).setAction(AKSI_MATIKAN), flag())
        val isi = if (a == null) t("Alarm berbunyi", "Alarm ringing") else {
            val jam = JamWaktu.format(a.jam * 60 + a.menit)
            if (a.label.isNotBlank()) jam + " · " + a.label.trim() else jam
        }
        val b = builder()
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(t("Alarm jam berbunyi", "Clock alarm ringing"))
            .setContentText(isi)
            .setContentIntent(buka)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_ALARM)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, t("Matikan alarm", "Turn off alarm"), matikan)
        if (a != null && a.tundaMenit > 0 && !uji) {
            val tundaPi = PendingIntent.getService(this, 9105, Intent(this, AlarmJamService::class.java).setAction(AKSI_TUNDA), flag())
            b.addAction(android.R.drawable.ic_media_pause, t("Tunda " + a.tundaMenit + " menit", "Snooze " + a.tundaMenit + " min"), tundaPi)
        }
        return b.build()
    }

    private fun notifikasiTerlewat(a: ItemAlarm) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            val buka = PendingIntent.getActivity(
                this, 9106, Intent(this, JamActivity::class.java).putExtra("kelompok", "alarm"), flag()
            )
            val jam = JamWaktu.format(a.jam * 60 + a.menit)
            val n = builder()
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(t("Alarm terlewat", "Missed alarm"))
                .setContentText(jam + (if (a.label.isNotBlank()) " · " + a.label.trim() else ""))
                .setContentIntent(buka)
                .setAutoCancel(true)
                .build()
            nm.notify(ID_NOTIF_TERLEWAT, n)
        } catch (_: Exception) { }
    }
}
