package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.Intent
import android.text.InputType
import android.widget.EditText

/** Ta'aruf and mutual prayers. Personal information remains local unless the user chooses to share it. */
class TaarufDoaActivity : Halaman() {
    override val judulHalaman = R.string.judul_taaruf_doa
    private val data by lazy { getSharedPreferences("taaruf_dan_doa", MODE_PRIVATE) }
    private lateinit var nama: EditText
    private lateinit var usia: EditText
    private lateinit var kota: EditText
    private lateinit var minat: EditText
    private lateinit var tujuan: EditText
    private lateinit var namaPenerima: EditText
    private lateinit var isiDoa: EditText

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun tr(id: String, en: String): String = if (english) en else id

    private data class DoaQurani(
        val judulId: String,
        val judulEn: String,
        val arab: String,
        val latin: String,
        val artiId: String,
        val artiEn: String,
        val sumber: String
    )

    // The Arabic supplications below are excerpts from the Qur'an; references are included for checking.
    private val kumpulanDoa = listOf(
        DoaQurani(
            "Ampunan untuk sesama orang beriman", "Forgiveness for fellow believers",
            "رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا الَّذِينَ سَبَقُونَا بِالْإِيمَانِ وَلَا تَجْعَلْ فِي قُلُوبِنَا غِلًّا لِلَّذِينَ آمَنُوا رَبَّنَا إِنَّكَ رَءُوفٌ رَحِيمٌ",
            "Rabbana-ghfir lana wa li-ikhwanina alladhina sabaquna bil-iman, wa la taj'al fi qulubina ghillan lilladhina amanu, rabbana innaka ra'ufur-rahim.",
            "Ya Tuhan kami, ampunilah kami dan saudara-saudara kami yang telah beriman lebih dahulu dari kami. Janganlah Engkau tanamkan kedengkian dalam hati kami terhadap orang-orang yang beriman. Ya Tuhan kami, sungguh, Engkau Maha Penyantun, Maha Penyayang.",
            "Our Lord, forgive us and our fellow believers who preceded us in faith, and do not place resentment in our hearts toward those who believe. Our Lord, You are truly Most Kind and Most Merciful.",
            "Al-Qur'an, Surah Al-Hasyr 59:10"
        ),
        DoaQurani(
            "Ampunan untuk orang tua dan kaum beriman", "Forgiveness for parents and believers",
            "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
            "Rabbana-ghfir li wa liwalidayya wa lil-mu'minina yawma yaqumul-hisab.",
            "Ya Tuhan kami, ampunilah aku, kedua orang tuaku, dan semua orang beriman pada hari diadakan perhitungan.",
            "Our Lord, forgive me, my parents, and all the believers on the Day the account is established.",
            "Al-Qur'an, Surah Ibrahim 14:41"
        ),
        DoaQurani(
            "Kebaikan dunia dan akhirat", "Goodness in this life and the Hereafter",
            "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            "Rabbana atina fid-dunya hasanatan wa fil-akhirati hasanatan wa qina 'adhaban-nar.",
            "Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, serta lindungilah kami dari azab neraka.",
            "Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.",
            "Al-Qur'an, Surah Al-Baqarah 2:201"
        ),
        DoaQurani(
            "Keteguhan hati dan rahmat", "Steadfast hearts and mercy",
            "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ",
            "Rabbana la tuzigh qulubana ba'da idh hadaytana wa hab lana min ladunka rahmah, innaka antal-Wahhab.",
            "Ya Tuhan kami, janganlah Engkau jadikan hati kami condong kepada kesesatan setelah Engkau beri petunjuk kepada kami, dan anugerahkanlah rahmat dari sisi-Mu. Sungguh, Engkaulah Maha Pemberi.",
            "Our Lord, do not let our hearts deviate after You have guided us, and grant us mercy from Yourself. You are indeed the Bestower.",
            "Al-Qur'an, Surah Ali 'Imran 3:8"
        ),
        DoaQurani(
            "Kebaikan bagi keluarga", "Goodness for the family",
            "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا",
            "Rabbana hab lana min azwajina wa dhurriyyatina qurrata a'yunin waj'alna lil-muttaqina imama.",
            "Ya Tuhan kami, anugerahkanlah kepada kami pasangan dan keturunan sebagai penyenang hati, dan jadikanlah kami teladan bagi orang-orang yang bertakwa.",
            "Our Lord, grant us comfort in our spouses and offspring, and make us an example for the righteous.",
            "Al-Qur'an, Surah Al-Furqan 25:74"
        ),
        DoaQurani(
            "Ampunan dan perlindungan bagi yang bertobat", "Forgiveness and protection for those who repent",
            "رَبَّنَا وَسِعْتَ كُلَّ شَيْءٍ رَحْمَةً وَعِلْمًا فَاغْفِرْ لِلَّذِينَ تَابُوا وَاتَّبَعُوا سَبِيلَكَ وَقِهِمْ عَذَابَ الْجَحِيمِ",
            "Rabbana wasi'ta kulla shay'in rahmatan wa 'ilman, faghfir lilladhina tabu wattaba'u sabilaka wa qihim 'adhabal-jahim.",
            "Ya Tuhan kami, rahmat dan ilmu-Mu meliputi segala sesuatu. Maka ampunilah orang-orang yang bertobat dan mengikuti jalan-Mu, serta lindungilah mereka dari azab neraka.",
            "Our Lord, You encompass all things in mercy and knowledge. Forgive those who repent and follow Your way, and protect them from the punishment of Hellfire.",
            "Al-Qur'an, Surah Ghafir 40:7 (bagian dari doa para malaikat)"
        )
    )

    override fun bangun() {
        bagian(tr("Ta'aruf / Berkenalan", "Ta'aruf / Introductions"), 22f)
        info(tr(
            "Kenalkan diri dengan sopan untuk membangun silaturahmi sesama muslim. Data tersimpan di perangkat ini dan tidak diunggah otomatis. Anda menentukan sendiri kapan membagikannya.",
            "Introduce yourself respectfully to build fellowship among Muslims. Your information stays on this device and is never uploaded automatically. You decide when to share it."
        ))
        nama = isian(tr("Nama atau nama panggilan", "Name or preferred name"), data.getString("nama", "").orEmpty(), InputType.TYPE_CLASS_TEXT) {}
        usia = isian(tr("Usia (opsional)", "Age (optional)"), data.getString("usia", "").orEmpty(), InputType.TYPE_CLASS_NUMBER) {}
        kota = isian(tr("Kota atau daerah (opsional)", "City or area (optional)"), data.getString("kota", "").orEmpty(), InputType.TYPE_CLASS_TEXT) {}
        minat = isian(tr("Minat atau hal yang ingin dikenalkan (opsional)", "Interests or things you'd like to introduce (optional)"), data.getString("minat", "").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) {}
        tujuan = isian(tr("Tujuan berkenalan (misalnya silaturahmi atau mencari pasangan secara serius)", "Purpose of introduction (for example, fellowship or seriously seeking a spouse)"), data.getString("tujuan", "").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) {}
        tombol(tr("Simpan profil ta'aruf di perangkat", "Save ta'aruf profile on this device")) { simpanProfil() }
        tombol(tr("Bagikan perkenalan", "Share introduction")) { simpanProfil(); bagikanProfil() }

        bagian(tr("Saling Mendoakan", "Praying for One Another"), 22f)
        info(tr(
            "Tuliskan doa baik untuk keluarga, sahabat, atau sesama muslim. Anda juga dapat memilih doa Al-Qur'an yang disertai rujukan surah dan ayat. Doa dapat disimpan atau dibagikan atas pilihan Anda.",
            "Write a kind prayer for family, friends, or fellow Muslims. You can also choose Qur'anic supplications with their surah and verse references. Save or share a prayer only when you choose to."
        ))
        namaPenerima = isian(tr("Nama penerima doa (opsional)", "Prayer recipient's name (optional)"), data.getString("nama_penerima", "").orEmpty(), InputType.TYPE_CLASS_TEXT) {
            data.edit().putString("nama_penerima", it).apply()
        }
        isiDoa = isian(tr("Tuliskan doa", "Write a prayer"), data.getString("draf_doa", "").orEmpty(), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE) {
            data.edit().putString("draf_doa", it).apply()
        }
        tombol(tr("Kumpulan doa Al-Qur'an", "Collection of Qur'anic supplications")) { tampilkanKumpulanDoa() }
        tombol(tr("Isi contoh doa umum", "Insert a general sample prayer")) {
            isiDoa.setText(tr(
                "Semoga Allah menganugerahkan kesehatan, ketenangan, kemudahan dalam urusan, keberkahan yang luas, serta kebaikan di dunia dan akhirat. Aamiin.",
                "May Allah grant you health, peace, ease in your affairs, abundant blessings, and goodness in this life and the Hereafter. Ameen."
            ))
        }
        tombol(tr("Simpan doa di perangkat", "Save prayer on this device")) { simpanDoa() }
        tombol(tr("Bagikan doa", "Share prayer")) { bagikanDoa() }
        tombol(tr("Bagikan doa umum untuk sesama muslim", "Share a general prayer for fellow Muslims")) { bagikanDoaUmum() }
        val doaTersimpan = data.getString("doa_terakhir", "").orEmpty()
        if (doaTersimpan.isNotBlank()) {
            bagian(tr("Doa terakhir yang disimpan", "Last saved prayer"))
            info(doaTersimpan)
        }
    }

    private fun tampilkanKumpulanDoa() {
        val judul = kumpulanDoa.map { if (english) it.judulEn else it.judulId }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(tr("Pilih doa dari Al-Qur'an", "Choose a supplication from the Qur'an"))
            .setItems(judul) { _, index -> tampilkanDetailDoa(index) }
            .setNegativeButton(tr("Tutup", "Close"), null)
            .show()
    }

    private fun tampilkanDetailDoa(index: Int) {
        val doa = kumpulanDoa[index]
        val detail = buildString {
            append(doa.arab)
            append("\n\n")
            append(tr("Transliterasi:", "Transliteration:")); append("\n"); append(doa.latin)
            append("\n\n")
            append(tr("Makna:", "Meaning:")); append("\n"); append(if (english) doa.artiEn else doa.artiId)
            append("\n\n")
            append(tr("Sumber:", "Source:")); append(" "); append(doa.sumber)
            append("\n\n")
            append(tr(
                "Teks Arab dan rujukan diambil dari ayat Al-Qur'an. Terjemahan di atas adalah makna dalam bahasa pilihan aplikasi.",
                "The Arabic text and reference are from the Qur'an. The translation above conveys the meaning in the app's selected language."
            ))
        }
        AlertDialog.Builder(this)
            .setTitle(if (english) doa.judulEn else doa.judulId)
            .setMessage(detail)
            .setPositiveButton(tr("Gunakan doa ini", "Use this supplication")) { _, _ ->
                val isi = buildString {
                    append(doa.arab)
                    append("\n\n")
                    append(if (english) doa.artiEn else doa.artiId)
                    append("\n\n")
                    append(doa.sumber)
                }
                isiDoa.setText(isi)
                isiDoa.setSelection(isiDoa.text.length)
                isiDoa.requestFocus()
                toast(tr("Doa dimasukkan ke kolom saling mendoakan.", "The supplication has been inserted into the mutual-prayer field."))
            }
            .setNegativeButton(tr("Kembali ke daftar", "Back to list")) { _, _ -> tampilkanKumpulanDoa() }
            .setNeutralButton(tr("Tutup", "Close"), null)
            .show()
    }

    private fun simpanProfil() {
        data.edit().putString("nama", nama.text.toString().trim())
            .putString("usia", usia.text.toString().trim())
            .putString("kota", kota.text.toString().trim())
            .putString("minat", minat.text.toString().trim())
            .putString("tujuan", tujuan.text.toString().trim()).apply()
        toast(tr("Profil ta'aruf disimpan di perangkat ini.", "Your ta'aruf profile has been saved on this device."))
    }

    private fun teksProfil(): String {
        val n = nama.text.toString().trim()
        val u = usia.text.toString().trim()
        val k = kota.text.toString().trim()
        val m = minat.text.toString().trim()
        val t = tujuan.text.toString().trim()
        val labelNama = tr("Nama", "Name")
        val labelUsia = tr("Usia", "Age")
        val labelKota = tr("Kota/daerah", "City/area")
        val labelMinat = tr("Minat", "Interests")
        val labelTujuan = tr("Tujuan berkenalan", "Purpose of introduction")
        val judul = tr("Perkenalan ta'aruf", "Ta'aruf introduction")
        val penutup = tr(
            "Semoga kita dapat saling mengenal dengan sopan dan menjaga silaturahmi sesama muslim.",
            "I hope we can get to know each other respectfully and maintain good Muslim fellowship."
        )
        return buildString {
            append(judul)
            if (n.isNotBlank()) append(("\n" + (labelNama) + ": " + (n)))
            if (u.isNotBlank()) append(("\n" + (labelUsia) + ": " + (u)))
            if (k.isNotBlank()) append(("\n" + (labelKota) + ": " + (k)))
            if (m.isNotBlank()) append(("\n" + (labelMinat) + ": " + (m)))
            if (t.isNotBlank()) append(("\n" + (labelTujuan) + ": " + (t)))
            append("\n\n")
            append(penutup)
        }
    }

    private fun bagikanProfil() {
        if (nama.text.toString().isBlank()) {
            toast(tr("Isi nama atau nama panggilan terlebih dahulu.", "Enter your name or preferred name first.")); return
        }
        bagikan(teksProfil(), tr("Bagikan perkenalan", "Share introduction"))
    }

    private fun simpanDoa() {
        val isi = isiDoa.text.toString().trim()
        if (isi.isBlank()) { toast(tr("Tuliskan doa terlebih dahulu.", "Write a prayer first.")); return }
        val penerima = namaPenerima.text.toString().trim()
        val hasil = buildString {
            if (penerima.isNotBlank()) append(tr("Doa untuk ", "A prayer for ") + penerima + ":\n")
            append(isi)
        }
        data.edit().putString("doa_terakhir", hasil).apply()
        toast(tr("Doa disimpan di perangkat ini.", "The prayer has been saved on this device."))
    }

    private fun bagikanDoa() {
        val isi = isiDoa.text.toString().trim()
        if (isi.isBlank()) { toast(tr("Tuliskan doa terlebih dahulu.", "Write a prayer first.")); return }
        val penerima = namaPenerima.text.toString().trim()
        val teks = buildString {
            if (penerima.isNotBlank()) append(tr("Doa untuk ", "A prayer for ") + penerima + ":\n")
            append(isi)
            append("\n\n")
            append(tr("Semoga Allah menerima doa-doa kita. Aamiin.", "May Allah accept our prayers. Ameen."))
        }
        data.edit().putString("doa_terakhir", teks).apply()
        bagikan(teks, tr("Bagikan doa", "Share prayer"))
    }

    private fun bagikanDoaUmum() {
        val teks = tr(
            "Semoga Allah mengampuni kita, membimbing hati kita, menjaga keluarga kita, menyembuhkan saudara-saudara yang sakit, meringankan kesulitan mereka yang sedang diuji, melapangkan rezeki yang halal, serta menganugerahkan kebaikan di dunia dan akhirat. Aamiin.",
            "May Allah forgive us, guide our hearts, protect our families, heal those who are ill, ease the burdens of those in hardship, provide lawful sustenance, and grant goodness in this life and the Hereafter. Ameen."
        )
        bagikan(teks, tr("Bagikan doa untuk sesama muslim", "Share a prayer for fellow Muslims"))
    }

    private fun bagikan(teks: String, judul: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, teks)
            startActivity(Intent.createChooser(intent, judul))
        } catch (_: Exception) {
            toast(tr("Tidak ditemukan aplikasi untuk membagikan pesan.", "No app is available to share this message."))
        }
    }
}
