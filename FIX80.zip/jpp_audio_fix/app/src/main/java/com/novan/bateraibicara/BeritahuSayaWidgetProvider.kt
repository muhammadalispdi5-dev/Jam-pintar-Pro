package com.novan.bateraibicara

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Widget aksesibel: status aktif/nonaktif mengikuti sakelar Beritahu Saya di halaman utama. */
class BeritahuSayaWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        perbarui(context, manager, ids)
    }

    companion object {
        fun perbaruiSemua(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, BeritahuSayaWidgetProvider::class.java))
            perbarui(context, manager, ids)
        }

        private fun perbarui(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val aktif = Prefs(context).beritahuSayaOn
            val intent = Intent(context, BeritahuSayaActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
            }
            val pending = PendingIntent.getActivity(
                context,
                817,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            for (id in ids) {
                val views = RemoteViews(context.packageName, R.layout.widget_beritahu_saya)
                val label = context.getString(if (aktif) R.string.widget_beritahu_saya else R.string.widget_beritahu_saya_mati)
                val deskripsi = context.getString(
                    if (aktif) R.string.widget_beritahu_saya_deskripsi else R.string.widget_beritahu_saya_mati_deskripsi
                )
                views.setTextViewText(R.id.widget_beritahu_button, label)
                views.setContentDescription(R.id.widget_beritahu_button, deskripsi)
                views.setContentDescription(R.id.widget_beritahu_root, deskripsi)
                views.setOnClickPendingIntent(R.id.widget_beritahu_root, pending)
                views.setOnClickPendingIntent(R.id.widget_beritahu_button, pending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
