package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Menjadwalkan ulang pengingat Khatam setelah ponsel dinyalakan atau aplikasi diperbarui. */
class KhatamReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("pengingat_aktif", false)) return
        val hour = prefs.getInt("pengingat_jam", 20).coerceIn(0, 23)
        val minute = prefs.getInt("pengingat_menit", 0).coerceIn(0, 59)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val broadcast = Intent(context, KhatamReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, 6901, broadcast, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT >= 23) alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        else {
            @Suppress("DEPRECATION")
            alarm.setRepeating(AlarmManager.RTC_WAKEUP, next.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }
}
