package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.nio.ByteOrder

/** Antarmuka pemutar murattal agar keluaran Stereo (MediaPlayer) dan Mono (downmix sendiri) dapat dipertukarkan. */
interface PemutarAudio {
    fun setOnPreparedListener(l: ((PemutarAudio) -> Unit)?)
    fun setOnCompletionListener(l: ((PemutarAudio) -> Unit)?)
    fun setOnErrorListener(l: ((PemutarAudio, Int, Int) -> Boolean)?)
    fun setAudioAttributes(a: AudioAttributes)
    fun setAudioSessionId(id: Int)
    val audioSessionId: Int
    fun setDataSource(context: Context, uri: Uri, headers: Map<String, String>)
    fun prepareAsync()
    fun start()
    fun pause()
    fun stop()
    fun release()
    fun reset()
    val isPlaying: Boolean
    var playbackParams: PlaybackParams
}

/** Keluaran stereo biasa: pembungkus tipis di atas MediaPlayer. */
class PemutarStereo : PemutarAudio {
    private val mp = MediaPlayer()

    override fun setOnPreparedListener(l: ((PemutarAudio) -> Unit)?) {
        if (l == null) mp.setOnPreparedListener(null) else mp.setOnPreparedListener { l(this) }
    }
    override fun setOnCompletionListener(l: ((PemutarAudio) -> Unit)?) {
        if (l == null) mp.setOnCompletionListener(null) else mp.setOnCompletionListener { l(this) }
    }
    override fun setOnErrorListener(l: ((PemutarAudio, Int, Int) -> Boolean)?) {
        if (l == null) mp.setOnErrorListener(null) else mp.setOnErrorListener { _, what, extra -> l(this, what, extra) }
    }
    override fun setAudioAttributes(a: AudioAttributes) { mp.setAudioAttributes(a) }
    override fun setAudioSessionId(id: Int) { mp.setAudioSessionId(id) }
    override val audioSessionId: Int get() = mp.audioSessionId
    override fun setDataSource(context: Context, uri: Uri, headers: Map<String, String>) { mp.setDataSource(context, uri, headers) }
    override fun prepareAsync() { mp.prepareAsync() }
    override fun start() { mp.start() }
    override fun pause() { mp.pause() }
    override fun stop() { mp.stop() }
    override fun release() { mp.release() }
    override fun reset() { mp.reset() }
    override val isPlaying: Boolean get() = try { mp.isPlaying } catch (_: Exception) { false }
    override var playbackParams: PlaybackParams
        get() = mp.playbackParams
        set(v) { mp.playbackParams = v }
}

/**
 * Keluaran mono sungguhan: audio didekode dengan MediaCodec, semua kanal dirata-ratakan menjadi satu kanal,
 * lalu diputar lewat AudioTrack mono. Dengan begitu suara kiri dan kanan tergabung di kedua telinga/speaker.
 */
class PemutarMono : PemutarAudio {
    private val utama = Handler(Looper.getMainLooper())
    private val kunci = Any()
    @Volatile private var dirilis = false
    @Volatile private var dijeda = false
    @Volatile private var mulai = false
    @Volatile private var selesai = false
    @Volatile private var kecepatan = 1f
    @Volatile private var onPrepared: ((PemutarAudio) -> Unit)? = null
    @Volatile private var onCompletion: ((PemutarAudio) -> Unit)? = null
    @Volatile private var onError: ((PemutarAudio, Int, Int) -> Boolean)? = null
    private var atribut: AudioAttributes? = null
    private var sesi = 0
    private var ctx: Context? = null
    private var uri: Uri? = null
    private var header: Map<String, String> = emptyMap()
    @Volatile private var extractor: MediaExtractor? = null
    @Volatile private var codec: MediaCodec? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var threadDekode: Thread? = null
    private var rate = 44100
    private var kanal = 2

    override fun setOnPreparedListener(l: ((PemutarAudio) -> Unit)?) { onPrepared = l }
    override fun setOnCompletionListener(l: ((PemutarAudio) -> Unit)?) { onCompletion = l }
    override fun setOnErrorListener(l: ((PemutarAudio, Int, Int) -> Boolean)?) { onError = l }
    override fun setAudioAttributes(a: AudioAttributes) { atribut = a }
    override fun setAudioSessionId(id: Int) { sesi = id }
    override val audioSessionId: Int get() = track?.audioSessionId ?: sesi
    override fun setDataSource(context: Context, uri: Uri, headers: Map<String, String>) {
        this.ctx = context.applicationContext
        this.uri = uri
        this.header = headers
    }
    override fun reset() { }

    override val isPlaying: Boolean get() = mulai && !dijeda && !selesai && !dirilis

    override var playbackParams: PlaybackParams
        get() = PlaybackParams().setSpeed(kecepatan).setPitch(1f)
        set(v) {
            try { kecepatan = v.speed } catch (_: Exception) { }
            if (mulai) terapkanKecepatan()
        }

    private fun kirim(aksi: () -> Unit) { utama.post { if (!dirilis) aksi() } }
    private fun kirimError() { kirim { onError?.invoke(this, 1, 0) } }

    private fun buatTrack(hz: Int): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(hz, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val atr = atribut ?: AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        val builder = AudioTrack.Builder()
            .setAudioAttributes(atr)
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(hz).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minBuf * 2, hz * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (sesi > 0) builder.setSessionId(sesi)
        return builder.build()
    }

    override fun prepareAsync() {
        val c = ctx ?: return
        val u = uri ?: return
        Thread {
            try {
                val ex = MediaExtractor()
                ex.setDataSource(c, u, header)
                var indeks = -1
                var fmt: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { indeks = i; fmt = f; break }
                }
                if (indeks < 0 || fmt == null) { try { ex.release() } catch (_: Exception) { }; throw IllegalStateException("tidak ada trek audio") }
                ex.selectTrack(indeks)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: throw IllegalStateException("mime kosong")
                val dc = MediaCodec.createDecoderByType(mime)
                dc.configure(fmt, null, null, 0)
                dc.start()
                rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                kanal = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val tr = buatTrack(rate)
                var batal = false
                synchronized(kunci) {
                    if (dirilis) batal = true else { extractor = ex; codec = dc; track = tr }
                }
                if (batal) {
                    try { dc.stop() } catch (_: Exception) { }
                    try { dc.release() } catch (_: Exception) { }
                    try { ex.release() } catch (_: Exception) { }
                    try { tr.release() } catch (_: Exception) { }
                    return@Thread
                }
                kirim { onPrepared?.invoke(this) }
            } catch (e: Exception) {
                kirimError()
            }
        }.start()
    }

    private fun terapkanKecepatan() {
        try {
            track?.playbackParams = PlaybackParams().setSpeed(kecepatan).setPitch(1f)
            if (dijeda) track?.pause()
        } catch (_: Exception) { }
    }

    override fun start() {
        synchronized(kunci) {
            if (dirilis || track == null) return
            if (!mulai) {
                mulai = true
                dijeda = false
                terapkanKecepatan()
                try { track?.play() } catch (_: Exception) { }
                val t = Thread { dekode() }
                threadDekode = t
                t.start()
            } else {
                dijeda = false
                terapkanKecepatan()
                try { track?.play() } catch (_: Exception) { }
            }
        }
    }

    override fun pause() {
        dijeda = true
        try { track?.pause() } catch (_: Exception) { }
    }

    override fun stop() { matikan() }
    override fun release() { matikan() }

    private fun matikan() {
        synchronized(kunci) {
            dirilis = true
            // Jeda + flush membebaskan thread yang sedang menunggu write() pada buffer penuh.
            try { track?.pause(); track?.flush() } catch (_: Exception) { }
            if (threadDekode == null) bersihkan()
        }
    }

    private fun bersihkan() {
        val dc = codec
        val ex = extractor
        val tr = track
        codec = null
        extractor = null
        track = null
        try { dc?.stop() } catch (_: Exception) { }
        try { dc?.release() } catch (_: Exception) { }
        try { ex?.release() } catch (_: Exception) { }
        try { tr?.stop() } catch (_: Exception) { }
        try { tr?.release() } catch (_: Exception) { }
    }

    private fun dekode() {
        val ex = extractor ?: return
        val dc = codec ?: return
        var tr = track ?: return
        val info = MediaCodec.BufferInfo()
        var inputEos = false
        var outputEos = false
        var frameDitulis = 0L
        try {
            while (!dirilis && !outputEos) {
                if (dijeda) { Thread.sleep(30); continue }
                if (!inputEos) {
                    val i = dc.dequeueInputBuffer(10000L)
                    if (i >= 0) {
                        val buf = dc.getInputBuffer(i)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            dc.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            dc.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = dc.dequeueOutputBuffer(info, 10000L)
                if (o >= 0) {
                    if (info.size > 0) {
                        val out = dc.getOutputBuffer(o)
                        if (out != null) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val total = sb.remaining()
                            val ch = if (kanal < 1) 1 else kanal
                            val frames = total / ch
                            val tmp = ShortArray(total)
                            sb.get(tmp)
                            val mono = ShortArray(frames)
                            for (f in 0 until frames) {
                                var jumlah = 0
                                for (c in 0 until ch) jumlah += tmp[f * ch + c].toInt()
                                mono[f] = (jumlah / ch).toShort()
                            }
                            var ofs = 0
                            while (ofs < frames && !dirilis) {
                                if (dijeda) { Thread.sleep(30); continue }
                                val w = tr.write(mono, ofs, frames - ofs)
                                if (w < 0) throw IllegalStateException("AudioTrack.write=" + w)
                                ofs += w
                            }
                            frameDitulis += frames.toLong()
                        }
                    }
                    dc.releaseOutputBuffer(o, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputEos = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dc.outputFormat
                    kanal = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    val r = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (r != rate) {
                        rate = r
                        val lama = tr
                        tr = buatTrack(r)
                        track = tr
                        try { lama.stop() } catch (_: Exception) { }
                        try { lama.release() } catch (_: Exception) { }
                        terapkanKecepatan()
                        if (!dijeda) tr.play()
                    }
                }
            }
            if (!dirilis && outputEos) {
                try { tr.stop() } catch (_: Exception) { }
                var tunggu = 0
                while (!dirilis && tr.playbackHeadPosition < frameDitulis && tunggu < 400) {
                    Thread.sleep(25)
                    tunggu++
                }
                selesai = true
                kirim { onCompletion?.invoke(this) }
            }
        } catch (e: Exception) {
            if (!dirilis) kirimError()
        } finally {
            synchronized(kunci) { bersihkan() }
        }
    }
}
