package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Vibrator

/**
 * FIX74: satu pusat untuk "hentikan suara dengan menelungkupkan HP".
 *
 * Setiap sumber suara otomatis aplikasi (azan, pengingat, pengumuman baterai dan jam, nama pemanggil,
 * notifikasi Khatam) mendaftar lewat [mulai] selama ia berbunyi dan memberi tahu cara menghentikannya.
 * Sensor hanya menyala selama ada sumber yang terdaftar, sehingga hemat baterai.
 *
 * Aturan gerakan (meniru "Flip to Shhh"): HP harus lebih dulu terdeteksi tidak telungkup (minimal 0,3 detik),
 * lalu telungkup datar sekitar 0,65 detik. Dengan begitu HP yang sudah tergeletak telungkup tidak langsung
 * membungkam suara yang baru mulai; angkat dan telungkupkan lagi untuk menghentikannya.
 *
 * FIX76: sumber yang sama juga dapat dihentikan dengan menekan tombol volume atas atau bawah
 * (sakelar [PrayerPrefs.stopDenganVolume]):
 *  - Saat salah satu halaman aplikasi terbuka, tombol volume ditangkap langsung oleh [Halaman] lewat
 *    [bungkamDariTombolVolume] (tepat, dan tidak mengubah volume).
 *  - Saat aplikasi di latar belakang atau layar mati, perubahan volume dibaca dari siaran sistem
 *    VOLUME_CHANGED_ACTION selama ada sumber suara terdaftar. Volume dikembalikan ke nilai sebelum
 *    tombol ditekan agar alarm berikutnya tidak menjadi lebih pelan.
 *
 * Semua status hanya disentuh dari thread utama. Telungkup mengikuti sakelar lama [PrayerPrefs.stopAzanFaceDown].
 */
object PembungkamTelungkup : SensorEventListener {
    private val handler = Handler(Looper.getMainLooper())
    private val daftar = LinkedHashMap<String, () -> Unit>()
    private val kedaluwarsa = HashMap<String, Runnable>()
    private var app: Context? = null
    private var manager: SensorManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var sejakTelungkup = 0L
    private var sejakTidakTelungkup = 0L
    private var siapDipicu = false
    private var terakhirBungkam = 0L
    private var penerimaVolume: BroadcastReceiver? = null
    private var sejakPemantauVolume = 0L

    private const val AKSI_VOLUME = "android.media.VOLUME_CHANGED_ACTION"
    private const val EXTRA_JENIS_VOLUME = "android.media.EXTRA_VOLUME_STREAM_TYPE"
    private const val EXTRA_NILAI_VOLUME = "android.media.EXTRA_VOLUME_STREAM_VALUE"
    private const val EXTRA_NILAI_SEBELUM = "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE"

    /** Naik setiap kali suara dibungkam; rangkaian pengumuman yang tertunda memakainya untuk membatalkan diri. */
    @Volatile
    var generasi = 0
        private set

    fun fiturAktif(context: Context): Boolean = try {
        PrayerPrefs(context.applicationContext).stopAzanFaceDown
    } catch (_: Exception) { false }

    fun volumeAktif(context: Context): Boolean = try {
        PrayerPrefs(context.applicationContext).stopDenganVolume
    } catch (_: Exception) { false }

    /** Ada sumber suara notifikasi yang sedang terdaftar (berbunyi). Hanya dipanggil dari thread utama. */
    fun adaSuaraAktif(): Boolean = daftar.isNotEmpty()

    /**
     * Dipanggil [Halaman] saat tombol volume ditekan. Mengembalikan true bila ada suara yang dihentikan;
     * tombol itu lalu dianggap sudah dipakai (volume tidak berubah). Bila tidak ada suara aktif, false
     * sehingga tombol volume bekerja seperti biasa.
     */
    fun bungkamDariTombolVolume(context: Context): Boolean {
        if (daftar.isEmpty() || !volumeAktif(context)) return false
        bungkam()
        return true
    }

    /**
     * Daftarkan sumber suara yang sedang/akan berbunyi. [henti] dipanggil di thread utama saat HP ditelungkupkan.
     * Pendaftaran kedaluwarsa otomatis setelah [batasMs] agar sensor tidak menyala selamanya.
     */
    fun mulai(context: Context, kunci: String, batasMs: Long = 180_000L, henti: () -> Unit) {
        val ctx = context.applicationContext
        val telungkup = fiturAktif(ctx)
        val volume = volumeAktif(ctx)
        if (!telungkup && !volume) return
        handler.post {
            app = ctx
            daftar[kunci] = henti
            kedaluwarsa.remove(kunci)?.let { handler.removeCallbacks(it) }
            val r = Runnable { selesai(kunci) }
            kedaluwarsa[kunci] = r
            handler.postDelayed(r, batasMs)
            if (telungkup && manager == null) nyalakanSensor(ctx)
            if (volume && penerimaVolume == null) nyalakanPemantauVolume(ctx)
        }
    }

    /** Sumber suara sudah selesai (atau sudah dihentikan dengan cara lain). */
    fun selesai(kunci: String) {
        handler.post {
            daftar.remove(kunci)
            kedaluwarsa.remove(kunci)?.let { handler.removeCallbacks(it) }
            if (daftar.isEmpty()) matikanPemantau()
        }
    }

    private fun nyalakanPemantauVolume(ctx: Context) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                if (intent?.action != AKSI_VOLUME || daftar.isEmpty()) return
                val jenis = intent.getIntExtra(EXTRA_JENIS_VOLUME, -1)
                val nilai = intent.getIntExtra(EXTRA_NILAI_VOLUME, -1)
                val sebelum = intent.getIntExtra(EXTRA_NILAI_SEBELUM, -1)
                // Hanya saluran suara biasa (sistem, dering, media, alarm, notifikasi) dan hanya bila nilainya benar-benar berubah.
                if (jenis !in 1..5 || nilai < 0 || sebelum < 0 || nilai == sebelum) return
                // Abaikan perubahan volume yang terjadi tepat saat suara mulai (diatur sistem, bukan tombol).
                if (System.currentTimeMillis() - sejakPemantauVolume < 1200L) return
                bungkam()
                try {
                    val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.setStreamVolume(jenis, sebelum, 0)
                } catch (_: Exception) { }
            }
        }
        sejakPemantauVolume = System.currentTimeMillis()
        try {
            val filter = IntentFilter(AKSI_VOLUME)
            if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(r, filter, Context.RECEIVER_NOT_EXPORTED)
            else ctx.registerReceiver(r, filter)
            penerimaVolume = r
        } catch (_: Exception) { penerimaVolume = null }
    }

    private fun matikanPemantauVolume() {
        val r = penerimaVolume ?: return
        penerimaVolume = null
        try { app?.unregisterReceiver(r) } catch (_: Exception) { }
    }

    private fun matikanPemantau() {
        matikanSensor()
        matikanPemantauVolume()
    }

    private fun nyalakanSensor(ctx: Context) {
        val m = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val sensor = m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true)
            ?: m.getDefaultSensor(Sensor.TYPE_GRAVITY, true)
            ?: m.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            ?: return
        manager = m
        sejakTelungkup = 0L
        sejakTidakTelungkup = 0L
        siapDipicu = false
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, ctx.packageName + ":BungkamTelungkup").apply {
                setReferenceCounted(false)
                acquire(5 * 60_000L)
            }
        } catch (_: Exception) { }
        try { m.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL, handler) } catch (_: Exception) { }
    }

    private fun matikanSensor() {
        try { manager?.unregisterListener(this) } catch (_: Exception) { }
        manager = null
        sejakTelungkup = 0L
        sejakTidakTelungkup = 0L
        siapDipicu = false
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        if (daftar.isEmpty() || e.values.size < 3) return
        val sekarang = System.currentTimeMillis()
        // Telungkup datar: layar menghadap ke bawah dan perangkat relatif rata.
        val telungkupDatar = e.values[2] < -7.0f && kotlin.math.abs(e.values[0]) < 3.5f && kotlin.math.abs(e.values[1]) < 3.5f
        if (!telungkupDatar) {
            sejakTelungkup = 0L
            if (sejakTidakTelungkup == 0L) sejakTidakTelungkup = sekarang
            if (sekarang - sejakTidakTelungkup >= 300L) siapDipicu = true
            return
        }
        sejakTidakTelungkup = 0L
        if (!siapDipicu) return
        if (sejakTelungkup == 0L) sejakTelungkup = sekarang
        if (sekarang - sejakTelungkup >= 650L && sekarang - terakhirBungkam > 1500L) {
            terakhirBungkam = sekarang
            bungkam()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { }

    @Suppress("DEPRECATION")
    private fun bungkam() {
        generasi++
        val aksi = ArrayList<() -> Unit>(daftar.values)
        for (r in kedaluwarsa.values) handler.removeCallbacks(r)
        kedaluwarsa.clear()
        daftar.clear()
        matikanPemantau()
        for (a in aksi) { try { a() } catch (_: Exception) { } }
        try { Melodi.hentikanSemua() } catch (_: Exception) { }
        try {
            val getar = app?.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            getar?.cancel()
        } catch (_: Exception) { }
    }
}
