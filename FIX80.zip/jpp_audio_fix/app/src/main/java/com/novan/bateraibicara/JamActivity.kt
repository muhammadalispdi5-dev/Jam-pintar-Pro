package com.novan.bateraibicara

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pengaturan kategori Jam: jadwal, format ucapan, dan suara. */
class JamActivity : Halaman() {

    override val judulHalaman = R.string.kategori_jam

    private lateinit var teksBerikut: TextView
    private lateinit var tombolHari: Button
    private lateinit var statusIzinAlarm: TextView

    // Urutan tampil Senin..Minggu -> nomor bit (0 = Minggu)
    private val urutanHari = intArrayOf(1, 2, 3, 4, 5, 6, 0)

    override fun bangun() {
        when (kodeKelompok()) {
            "jadwal" -> grupJadwal()
            "ucapan" -> grupUcapan()
            "suara" -> grupSuara()
            "alarm" -> grupAlarm()
            "alarm_ubah" -> grupAlarmUbah()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        saklar(getString(R.string.sw_jam_on), prefs.jamOn) {
            prefs.jamOn = it
            berubah()
        }
        info(getString(R.string.info_jam))
                teksBerikut = info("")

        tombolKelompok("Jadwal pengucapan jam", "jadwal")
        tombolKelompok("Cara jam diucapkan", "ucapan")
        tombolKelompok("Melodi, tes jam, dan suara", "suara")
        tombolKelompok(tt("Alarm jam", "Clock alarms"), "alarm")
    
        tombolResetPengaturan("jam dan alarm jam") {
                    hapusKunciPengaturan("pengaturan") { it.startsWith("jam_") }
                    val daftarAlarm = AlarmJam.muat(this)
                    daftarAlarm.forEach { alarm ->
                        AlarmJam.batalkanPending(this, alarm.id)
                        AlarmJam.hapusTunda(this, alarm.id)
                    }
                    getSharedPreferences("alarm_jam", MODE_PRIVATE).edit().clear().apply()
                    AlarmJam.jadwalkanSemua(this)
                    berubah()
                }
}

    private fun grupJadwal() {
        judulGrup("Jadwal pengucapan jam")
        // ----- Jadwal -----
        bagian(getString(R.string.bagian_jadwal))
        pilihan(getString(R.string.jam_mode), larik(R.array.jam_mode), prefs.jamMode) {
            prefs.jamMode = it
            berubah()
        }
        pilihan(getString(R.string.jam_interval), larik(R.array.jam_interval), prefs.jamIntervalIdx) {
            prefs.jamIntervalIdx = it
            berubah()
        }
        tombolJam(R.string.jam_mulai, { prefs.jamMulai }, { prefs.jamMulai = it; berubah() })
        tombolJam(R.string.jam_selesai, { prefs.jamSelesai }, { prefs.jamSelesai = it; berubah() })
        tombolHari = tombol("") { pilihHari() }
        segarkanHari()

    }

    private fun grupUcapan() {
        judulGrup("Cara jam diucapkan")
        // ----- Ucapan -----
        bagian(getString(R.string.bagian_ucapan_jam))
        pilihan(getString(R.string.jam_format), larik(R.array.jam_format), prefs.jamFormat) {
            prefs.jamFormat = it
            muatUlang()
        }
        bagian(getString(R.string.jam_disebut))
        saklar(getString(R.string.sw_ucap_jam), prefs.jamSebutJam) { prefs.jamSebutJam = it; muatUlang() }
        saklar(getString(R.string.sw_sebut_menit), prefs.jamSebutMenit) { prefs.jamSebutMenit = it; muatUlang() }
        saklar(getString(R.string.sw_sebut_detik), prefs.jamSebutDetik) {
            prefs.jamSebutDetik = it
            muatUlang()
        }
        // Tepat di awal dan tepat di akhir saling meniadakan; tampilan saklar lawannya ikut dimatikan.
        var saklarAwal: android.widget.Switch? = null
        var saklarAkhir: android.widget.Switch? = null
        saklarAwal = saklar(getString(R.string.sw_tepat_awal), prefs.jamTepatAwal) {
            prefs.jamTepatAwal = it
            if (it) {
                prefs.jamTepatAkhir = false
                saklarAkhir?.isChecked = false
            }
            muatUlang()
        }
        saklarAkhir = saklar(getString(R.string.sw_tepat_akhir), prefs.jamTepatAkhir) {
            prefs.jamTepatAkhir = it
            if (it) {
                prefs.jamTepatAwal = false
                saklarAwal?.isChecked = false
            }
            muatUlang()
        }
        info(getString(R.string.info_tepat_detik))
        saklar(getString(R.string.jam_sebut_periode), prefs.jamSebutPeriode) { prefs.jamSebutPeriode = it; muatUlang() }
        isian(getString(R.string.jam_awalan), prefs.jamAwalan, InputType.TYPE_CLASS_TEXT) {
            prefs.jamAwalan = it
            muatUlang()
        }
        info(getString(R.string.info_jam_awalan))

    }

    private fun grupSuara() {
        judulGrup("Melodi, tes jam, dan suara")
        // ----- Suara -----
        bagian(getString(R.string.bagian_melodi_jam))
        pilihan(getString(R.string.jam_melodi_awal), larik(R.array.jam_melodi), prefs.jamMelodiAwal) {
            prefs.jamMelodiAwal = it
            berubah()
        }
        tombol(getString(R.string.jam_melodi_awal) + ", " + getString(R.string.tombol_tes)) {
            Melodi.putar(this, prefs.jamMelodiAwal, prefs.suara("jam").audioAttributes())
        }
        pilihan(getString(R.string.jam_melodi_akhir), larik(R.array.jam_melodi), prefs.jamMelodiAkhir) {
            prefs.jamMelodiAkhir = it
            berubah()
        }
        tombol(getString(R.string.jam_melodi_akhir) + ", " + getString(R.string.tombol_tes)) {
            Melodi.putar(this, prefs.jamMelodiAkhir, prefs.suara("jam").audioAttributes())
        }
        isian(getString(R.string.jam_jeda_awal), prefs.jamJedaAwal.toString(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL) {
            prefs.jamJedaAwal = it.replace(',', '.').toFloatOrNull() ?: 0f
        }
        isian(getString(R.string.jam_jeda_akhir), prefs.jamJedaAkhir.toString(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL) {
            prefs.jamJedaAkhir = it.replace(',', '.').toFloatOrNull() ?: 0f
        }
        isian(getString(R.string.jam_jeda_jam_menit), prefs.jamJedaJamMenit.toString(), android.text.InputType.TYPE_CLASS_NUMBER) {
            prefs.jamJedaJamMenit = it.toIntOrNull() ?: 300
        }
        tombol(getString(R.string.jam_tes_lengkap)) { tesJamLengkap() }
        tombol(getString(R.string.jam_tes_ucapan_saja)) {
            // Waktu dibacakan oleh suara jam; tanggal, libur, dan info sholat oleh suara pembaca tanggal.
            val c = Calendar.getInstance()
            val waktu = JamWaktu.ucapan(prefs, c)
            val tanggal = JamWaktu.segmenTanggal(prefs, c)
            val pj = Pembicara(this, prefs.suara("jam")) { toast(it) }
            val pt = Pembicara(this, prefs.suara("tgl")) { toast(it) }
            val selesaiSemua = { pj.matikan(); pt.matikan() }
            val bacaTanggal = { if (tanggal.isEmpty()) selesaiSemua() else pt.ucapkanRangkaian(tanggal, 300L) { selesaiSemua() } }
            if (waktu.isBlank()) bacaTanggal() else pj.ucapkan(waktu, true) { bacaTanggal() }
        }
        tombol(getString(R.string.jam_izin_alarm)) { bukaIzinAlarm() }
        info(getString(R.string.jam_izin_alarm_info))
        statusIzinAlarm = info("")
        segarkanStatusIzinAlarm()

        blokSuara("jam") { JamWaktu.ucapan(prefs, Calendar.getInstance()) }
    }

    override fun onResume() {
        super.onResume()
        if (kodeKelompok() == "alarm" && ::wadahAlarm.isInitialized) isiDaftarAlarm()
        segarkanBerikut()
        if (::statusIzinAlarm.isInitialized) segarkanStatusIzinAlarm()
    }

    private fun berubah() {
        muatUlang()
        segarkanBerikut()
    }

    private fun segarkanHari() {
        tombolHari.text = getString(R.string.jam_hari, JamWaktu.ringkasHari(prefs.jamHari))
    }

    private fun segarkanBerikut() {
        if (!::teksBerikut.isInitialized) return // hanya ada di halaman daftar utama
        val t = if (prefs.jamOn) JamWaktu.berikut(prefs, System.currentTimeMillis()) else null
        teksBerikut.text = if (t == null) {
            getString(R.string.jam_berikut_tidak_ada)
        } else {
            // Pratinjau jadwal adalah teks antarmuka, jadi ikuti bahasa tampilan,
            // bukan bahasa TTS yang dipilih secara terpisah untuk pengucapan jam.
            val bahasaTampilan = BahasaAplikasi.tampilan(this)
            val localeTampilan = if (bahasaTampilan == 1) Locale.ENGLISH else Locale("id", "ID")
            val f = SimpleDateFormat("EEEE, HH.mm", localeTampilan)
            var waktuTampil = f.format(Date(t))
            if (bahasaTampilan == 0) waktuTampil = waktuTampil.replace("Minggu", "Ahad")
            getString(R.string.jam_berikut, waktuTampil)
        }
    }


    private fun tesJamLengkap() {
        val c = Calendar.getInstance()
        val (pertama, menit) = JamWaktu.bagianUcapan(prefs, c)
        val tanggal = JamWaktu.segmenTanggal(prefs, c)
        val pembicara = Pembicara(this, prefs.suara("jam")) { toast(it) }
        val pembicaraTanggal = Pembicara(this, prefs.suara("tgl")) { toast(it) }
        val akhir: () -> Unit = {
            window.decorView.postDelayed({ Melodi.putar(this, prefs.jamMelodiAkhir, prefs.suara("jam").audioAttributes()) { pembicara.matikan(); pembicaraTanggal.matikan() } }, (prefs.jamJedaAkhir * 1000).toLong())
        }
        val bacaTanggal: () -> Unit = { pembicaraTanggal.ucapkanRangkaian(tanggal, 300L) { akhir() } }
        val mulai: () -> Unit = {
            pembicara.ucapkan(pertama, true) {
                if (menit != null) window.decorView.postDelayed({ pembicara.ucapkan(menit, false) { window.decorView.postDelayed({ bacaTanggal() }, 300L) } }, prefs.jamJedaJamMenit.toLong())
                else if (tanggal.isNotEmpty()) window.decorView.postDelayed({ bacaTanggal() }, 300L) else akhir()
            }
        }
        if (prefs.jamMelodiAwal > 0) {
            Melodi.putar(this, prefs.jamMelodiAwal, prefs.suara("jam").audioAttributes()) {
                window.decorView.postDelayed({ mulai() }, (prefs.jamJedaAwal * 1000).toLong())
            }
        } else mulai()
    }

    private fun segarkanStatusIzinAlarm() {
        val status = if (android.os.Build.VERSION.SDK_INT < 31) {
            "Status izin alarm tepat waktu: dikelola otomatis oleh Android pada versi ini."
        } else {
            val am = getSystemService(android.app.AlarmManager::class.java)
            if (am?.canScheduleExactAlarms() == true) {
                "Status izin alarm tepat waktu: SUDAH DIIZINKAN."
            } else {
                "Status izin alarm tepat waktu: BELUM DIIZINKAN. Buka halaman izin Android, aktifkan jika tersedia, lalu kembali ke sini untuk memeriksa ulang."
            }
        }
        statusIzinAlarm.text = status
        statusIzinAlarm.contentDescription = status
    }

    private fun bukaIzinAlarm() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse(("package:" + (packageName))))) }
            catch (_: Exception) { startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS)) }
        } else {
            toast(R.string.jam_izin_alarm_info)
        }
    }

    // ====================================================================================
    // ALARM JAM (FIX75)
    // ====================================================================================

    private lateinit var wadahAlarm: LinearLayout
    private lateinit var teksAlarmBerikut: TextView

    /** Teks dua bahasa untuk layar yang dibangun lewat kode. */
    private fun tt(id: String, en: String): String = if (BahasaAplikasi.tampilan(this) == 1) en else id

    private fun grupAlarm() {
        judulGrup(tt("Alarm jam", "Clock alarms"))
        info(tt(
            "Buat beberapa alarm dengan jam, hari berulang, nama, jenis suara, tunda, dan getar. Alarm berbunyi tepat waktu walau layar mati dan tetap terpasang setelah HP dihidupkan ulang. Tekan Matikan atau Tunda pada notifikasi, atau telungkupkan HP untuk mematikan alarm.",
            "Create several alarms with time, repeat days, name, sound type, snooze, and vibration. Alarms ring on time even when the screen is off and stay scheduled after a restart. Press Turn off or Snooze in the notification, or turn the phone face down to stop the alarm."
        ))
        val pp = PrayerPrefs(this)
        saklar(tt("Hentikan alarm dengan menelungkupkan HP", "Stop alarms by turning the phone face down"), pp.stopAzanFaceDown) { aktif ->
            pp.stopAzanFaceDown = aktif
            toast(if (aktif) tt("Menelungkupkan HP akan mematikan alarm dan suara notifikasi lain.", "Turning the phone face down will stop alarms and other notification sounds.")
                  else tt("Penghentian suara dengan menelungkupkan HP dinonaktifkan.", "Stopping sounds by turning the phone face down is off."))
        }
        saklar(tt("Hentikan alarm dengan tombol volume", "Stop alarms with the volume buttons"), pp.stopDenganVolume) { aktif ->
            pp.stopDenganVolume = aktif
            toast(if (aktif) tt("Tombol volume atas atau bawah akan mematikan alarm dan suara notifikasi lain.", "The volume up or down button will stop alarms and other notification sounds.")
                  else tt("Penghentian suara dengan tombol volume dinonaktifkan.", "Stopping sounds with the volume buttons is off."))
        }
        info(tt(
            "Sakelar ini sama dengan sakelar di Pengaturan Sholat dan berlaku untuk semua suara notifikasi aplikasi. HP harus terdeteksi tidak telungkup lebih dahulu, lalu ditelungkupkan sekitar satu detik. Jika HP sudah telungkup saat alarm mulai, angkat lalu telungkupkan lagi.",
            "This switch is the same as the one in Prayer Settings and applies to all notification sounds of the app. The phone must first be detected as not face down, then turned face down for about one second. If the phone is already face down when the alarm starts, lift it and turn it face down again."
        ))
        teksAlarmBerikut = info("")
        tombol(tt("Tambah alarm", "Add alarm")) { tambahAlarm() }
        wadahAlarm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(wadahAlarm)
        isiDaftarAlarm()
    }

    /** Isi ulang daftar alarm; pembangun tampilan Halaman menulis ke [root], jadi root dialihkan sementara ke wadah. */
    private fun isiDaftarAlarm() {
        val asli = root
        wadahAlarm.removeAllViews()
        root = wadahAlarm
        try {
            val daftar = AlarmJam.muat(this)
            if (daftar.isEmpty()) info(tt("Belum ada alarm. Tekan Tambah alarm untuk membuatnya.", "No alarms yet. Press Add alarm to create one."))
            for (a in daftar) {
                var sw: android.widget.Switch? = null
                sw = saklar(AlarmJam.ringkas(this, a), a.aktif) { aktif ->
                    a.aktif = aktif
                    AlarmJam.perbarui(this, a)
                    sw?.text = ui(AlarmJam.ringkas(this, a))
                    segarkanAlarmBerikut()
                }
                tombol(tt("Ubah alarm ", "Edit alarm ") + JamWaktu.format(a.jam * 60 + a.menit)) { ubahAlarm(a.id) }
            }
        } finally {
            root = asli
        }
        segarkanAlarmBerikut()
    }

    private fun segarkanAlarmBerikut() {
        if (!::teksAlarmBerikut.isInitialized) return
        val b = AlarmJam.berikutan(this)
        teksAlarmBerikut.text = if (b == null) {
            tt("Tidak ada alarm yang aktif.", "No active alarms.")
        } else {
            val en = BahasaAplikasi.tampilan(this) == 1
            val f = SimpleDateFormat("EEEE, d MMM HH.mm", if (en) Locale.ENGLISH else Locale("id", "ID"))
            var waktu = f.format(Date(b.second))
            if (!en) waktu = waktu.replace("Minggu", "Ahad")
            tt("Alarm berikutnya: ", "Next alarm: ") + waktu + (if (b.first.label.isNotBlank()) " (" + b.first.label.trim() + ")" else "")
        }
    }

    private fun tambahAlarm() {
        val a = AlarmJam.baru(this)
        if (a == null) {
            toast(tt("Jumlah alarm sudah mencapai batas " + AlarmJam.BATAS_ALARM + ".", "The alarm limit of " + AlarmJam.BATAS_ALARM + " has been reached."))
            return
        }
        AlarmJam.perbarui(this, a)
        ubahAlarm(a.id)
    }

    private fun ubahAlarm(id: Int) {
        startActivity(android.content.Intent(this, JamActivity::class.java).putExtra("kelompok", "alarm_ubah").putExtra("alarm_id", id))
    }

    private fun grupAlarmUbah() {
        val id = intent.getIntExtra("alarm_id", -1)
        val a = AlarmJam.cari(this, id)
        if (a == null) { finish(); return }
        judulGrup(tt("Ubah alarm", "Edit alarm"))
        // Perubahan langsung disimpan dan dijadwalkan ulang, seperti halaman pengaturan lain di aplikasi.
        val simpan = { AlarmJam.perbarui(this, a) }

        saklar(tt("Alarm aktif", "Alarm on"), a.aktif) { a.aktif = it; simpan() }

        var tombolWaktu: Button? = null
        fun segarWaktu() {
            val teks = ui(tt("Waktu alarm: ", "Alarm time: ") + JamWaktu.format(a.jam * 60 + a.menit) + tt(". Ketuk untuk mengubah.", ". Tap to change."))
            tombolWaktu?.text = teks
            tombolWaktu?.contentDescription = teks
        }
        tombolWaktu = tombol("") {
            TimePickerDialog(this, { _, h, m ->
                a.jam = h
                a.menit = m
                simpan()
                segarWaktu()
            }, a.jam, a.menit, true).show()
        }
        segarWaktu()

        var tombolHariAlarm: Button? = null
        fun segarHariAlarm() {
            val teks = ui(tt("Hari: ", "Days: ") + AlarmJam.ringkasHari(this, a.hari) + tt(". Ketuk untuk mengubah.", ". Tap to change."))
            tombolHariAlarm?.text = teks
            tombolHariAlarm?.contentDescription = teks
        }
        tombolHariAlarm = tombol("") { pilihHariAlarm(a) { simpan(); segarHariAlarm() } }
        segarHariAlarm()
        info(tt("Tanpa hari yang dipilih, alarm berbunyi sekali saja pada waktu berikutnya lalu mati sendiri.", "With no days selected, the alarm rings once at the next occurrence and then turns itself off."))

        isian(tt("Nama alarm (opsional)", "Alarm name (optional)"), a.label,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) {
            a.label = it.trim().take(60)
            simpan()
        }

        pilihan(
            tt("Jenis suara alarm", "Alarm sound type"),
            listOf(
                tt("Nada alarm sistem", "System alarm tone"),
                tt("Ucapkan waktu dan nama alarm", "Speak the time and alarm name"),
                tt("Nada singkat lalu ucapan bergantian", "Short tone then speech, alternating")
            ),
            a.mode
        ) { a.mode = it; simpan() }
        info(tt(
            "Ucapan memakai pengaturan suara Jam (mesin suara, kecepatan, nada, dan saluran volume). Alarm sistem memakai volume Alarm di HP.",
            "Speech uses the Clock voice settings (engine, speed, pitch, and volume channel). The system tone uses the phone's Alarm volume."
        ))

        val nilaiTunda = intArrayOf(0, 5, 10, 15)
        pilihan(
            tt("Tunda", "Snooze"),
            listOf(tt("Tanpa tombol tunda", "No snooze button"), tt("5 menit", "5 minutes"), tt("10 menit", "10 minutes"), tt("15 menit", "15 minutes")),
            nilaiTunda.indexOf(a.tundaMenit).coerceAtLeast(0)
        ) { a.tundaMenit = nilaiTunda[it]; simpan() }

        saklar(tt("Getar saat alarm berbunyi", "Vibrate while the alarm rings"), a.getar) { a.getar = it; simpan() }

        info(tt(
            "Alarm berhenti sendiri setelah tiga menit dan meninggalkan notifikasi Alarm terlewat. Telungkupkan HP, atau tekan Matikan pada notifikasi, untuk menghentikannya lebih dulu.",
            "The alarm stops by itself after three minutes and leaves a Missed alarm notification. Turn the phone face down, or press Turn off in the notification, to stop it sooner."
        ))

        tombol(tt("Tes alarm sekarang", "Test alarm now")) {
            val layanan = android.content.Intent(this, AlarmJamService::class.java)
                .putExtra("alarm_id", a.id).putExtra("tes", true)
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(layanan) else startService(layanan)
            } catch (_: Exception) { toast(tt("Tes alarm tidak dapat dimulai.", "The alarm test could not start.")) }
        }

        tombol(tt("Hapus alarm ini", "Delete this alarm")) {
            AlertDialog.Builder(this)
                .setTitle(tt("Hapus alarm?", "Delete alarm?"))
                .setMessage(AlarmJam.ringkas(this, a))
                .setPositiveButton(tt("Hapus", "Delete")) { _, _ ->
                    AlarmJam.hapus(this, a.id)
                    finish()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun pilihHariAlarm(a: ItemAlarm, selesai: () -> Unit) {
        val nama = larik(R.array.nama_hari).toTypedArray()
        var mask = a.hari
        val dicentang = BooleanArray(7) { (mask and (1 shl urutanHari[it])) != 0 }
        AlertDialog.Builder(this)
            .setTitle(tt("Hari alarm berulang", "Repeat days"))
            .setMultiChoiceItems(nama, dicentang) { _, which, centang ->
                val bit = 1 shl urutanHari[which]
                mask = if (centang) (mask or bit) else (mask and bit.inv())
            }
            .setPositiveButton(android.R.string.ok) { _, _ -> a.hari = mask and 127; selesai() }
            .setNeutralButton(tt("Sekali saja", "Once only")) { _, _ -> a.hari = 0; selesai() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun pilihHari() {
        val nama = larik(R.array.nama_hari).toTypedArray()
        var mask = prefs.jamHari
        val dicentang = BooleanArray(7) { (mask and (1 shl urutanHari[it])) != 0 }
        AlertDialog.Builder(this)
            .setTitle(R.string.jam_pilih_hari)
            .setMultiChoiceItems(nama, dicentang) { _, which, centang ->
                val bit = 1 shl urutanHari[which]
                mask = if (centang) (mask or bit) else (mask and bit.inv())
            }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.jamHari = mask
                segarkanHari()
                berubah()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
