package com.novan.bateraibicara

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/** Pencarian fasilitas umum terdekat dengan lokasi perangkat dan aplikasi peta. */
class FasilitasTerdekatActivity : Halaman() {
    override val judulHalaman = R.string.kategori_fasilitas_terdekat

    private val handler = Handler(Looper.getMainLooper())
    private var lokasiMenunggu: String? = null
    private var pendengarLokasi: LocationListener? = null
    private var manajerLokasi: LocationManager? = null
    private var timeoutLokasi: Runnable? = null

    private val pilihan = listOf(
        "Masjid dan musala" to "masjid dan musala",
        "Rumah sakit" to "rumah sakit",
        "Puskesmas dan klinik" to "puskesmas klinik",
        "Apotek" to "apotek",
        "ATM" to "ATM",
        "Bank" to "bank",
        "Toilet umum" to "toilet umum",
        "Kantor polisi" to "kantor polisi",
        "Pemadam kebakaran" to "pemadam kebakaran",
        "SPBU" to "SPBU",
        "Halte dan stasiun" to "halte stasiun",
        "Pasar dan minimarket" to "pasar minimarket"
    )

    override fun bangun() {
        info("Pilih jenis fasilitas. Jam Pintar Pro akan mencoba memakai lokasi perangkat untuk memusatkan pencarian, lalu membuka hasil di Google Maps atau aplikasi peta yang tersedia. Aktifkan izin lokasi agar pencarian lebih akurat. Lokasi tidak disimpan oleh Jam Pintar Pro.")
        for ((label, query) in pilihan) tombol("Cari $label terdekat") { cari(query) }
    }

    private fun punyaIzinLokasi(): Boolean {
        val halus = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val kasar = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return halus || kasar
    }

    private fun cari(query: String) {
        if (!punyaIzinLokasi()) {
            lokasiMenunggu = query
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), KODE_IZIN_LOKASI)
            return
        }
        lokasiMenunggu = query
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        manajerLokasi = manager
        try {
            val terakhir = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                .filter { provider -> try { manager.isProviderEnabled(provider) } catch (_: Exception) { false } }
                .mapNotNull { provider -> try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }
                .maxByOrNull { it.time }
            if (terakhir != null && System.currentTimeMillis() - terakhir.time <= BATAS_LOKASI_LAMA_MS) {
                bukaPeta(query, terakhir)
                return
            }
            mulaiAmbilLokasi(manager)
        } catch (_: Exception) {
            bukaPetaTanpaKoordinat(query)
        }
    }

    private fun mulaiAmbilLokasi(manager: LocationManager) {
        val bolehGps = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val provider = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { p -> p != LocationManager.GPS_PROVIDER || bolehGps }
            .filter { p -> try { manager.isProviderEnabled(p) } catch (_: Exception) { false } }
        if (provider.isEmpty()) {
            bukaPetaTanpaKoordinat(lokasiMenunggu ?: return)
            return
        }
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val query = lokasiMenunggu ?: return
                berhentiMencariLokasi()
                bukaPeta(query, location)
            }
            @Deprecated("Deprecated by Android")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        pendengarLokasi = listener
        try {
            for (p in provider) manager.requestLocationUpdates(p, 1000L, 0f, listener, Looper.getMainLooper())
            timeoutLokasi = Runnable {
                val query = lokasiMenunggu ?: return@Runnable
                berhentiMencariLokasi()
                bukaPetaTanpaKoordinat(query)
            }
            handler.postDelayed(timeoutLokasi!!, BATAS_TUNGGU_LOKASI_MS)
            toast("Sedang mencari lokasi perangkat. Hasil peta akan dibuka setelah lokasi ditemukan.")
        } catch (_: SecurityException) {
            berhentiMencariLokasi()
            bukaPetaTanpaKoordinat(lokasiMenunggu ?: return)
        } catch (_: Exception) {
            berhentiMencariLokasi()
            bukaPetaTanpaKoordinat(lokasiMenunggu ?: return)
        }
    }

    private fun berhentiMencariLokasi() {
        timeoutLokasi?.let { handler.removeCallbacks(it) }
        timeoutLokasi = null
        val listener = pendengarLokasi
        val manager = manajerLokasi
        if (listener != null && manager != null) {
            try { manager.removeUpdates(listener) } catch (_: Exception) {}
        }
        pendengarLokasi = null
    }

    private fun bukaPeta(query: String, lokasi: Location) {
        lokasiMenunggu = null
        val pencarian = "$query near ${lokasi.latitude},${lokasi.longitude}"
        bukaPetaDenganKueri(pencarian)
    }

    private fun bukaPetaTanpaKoordinat(query: String) {
        lokasiMenunggu = null
        toast("Lokasi perangkat belum berhasil diperoleh. Peta akan mencoba mencari fasilitas terdekat dari lokasi yang tersedia di aplikasi peta.")
        bukaPetaDenganKueri("$query terdekat")
    }

    private fun bukaPetaDenganKueri(query: String) {
        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            toast("Aplikasi peta atau peramban tidak dapat dibuka.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != KODE_IZIN_LOKASI) return
        val query = lokasiMenunggu ?: return
        if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            cari(query)
        } else {
            bukaPetaTanpaKoordinat(query)
        }
    }

    override fun onDestroy() {
        berhentiMencariLokasi()
        super.onDestroy()
    }

    companion object {
        private const val KODE_IZIN_LOKASI = 7102
        private const val BATAS_LOKASI_LAMA_MS = 5 * 60 * 1000L
        private const val BATAS_TUNGGU_LOKASI_MS = 12_000L
    }
}
