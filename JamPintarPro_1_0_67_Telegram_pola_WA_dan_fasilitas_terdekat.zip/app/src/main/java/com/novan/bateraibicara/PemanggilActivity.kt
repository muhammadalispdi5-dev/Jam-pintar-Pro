package com.novan.bateraibicara

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.media.ToneGenerator
import android.media.AudioManager
import android.widget.TextView

/** Pengaturan kategori Nama Pemanggil. */
class PemanggilActivity : Halaman() {

    override val judulHalaman = R.string.kategori_pemanggil

    private lateinit var teksAkses: TextView
    private lateinit var teksTelepon: TextView

    override fun bangun() {
        when (kodeKelompok()) {
            "izin" -> grupIzin()
            "jenis" -> grupJenis()
            "melodi" -> grupMelodi()
            "suara" -> grupSuara()
            "pesan" -> grupPembacaanPesan()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        saklar(getString(R.string.sw_pem_on), prefs.pemOn) { prefs.pemOn = it }
        info(getString(R.string.info_pemanggil))

        tombolKelompok("Izin dan akses notifikasi", "izin")
        tombolKelompok("Jenis panggilan dan pengulangan", "jenis")
        tombolKelompok("Pembacaan pesan dan notifikasi masuk", "pesan")
        tombolKelompok("Melodi sebelum dan sesudah pengumuman", "melodi")
        tombolKelompok("Suara pengumuman", "suara")
    }

    private fun grupIzin() {
        judulGrup("Izin dan akses notifikasi")
        // ----- Izin -----
        bagian(getString(R.string.bagian_izin))
        teksAkses = info("")
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
        info(getString(R.string.info_setelan_terbatas))
        teksTelepon = info("")
        tombol(getString(R.string.tombol_izin_telepon)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 2)
        }
        tombol(getString(R.string.tombol_izin_kontak)) {
            // Hanya izin kontak yang dipakai (mencocokkan nomor dengan nama). Izin daftar panggilan tidak
            // pernah dipakai dan tidak dideklarasikan di manifest, jadi tidak diminta.
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 3)
        }
        saklar(getString(R.string.sw_nama_panggilan), prefs.pemNamaPanggilan) { prefs.pemNamaPanggilan = it }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

    }

    private fun grupJenis() {
        judulGrup("Jenis panggilan dan pengulangan")
        // ----- Jenis panggilan -----
        bagian(getString(R.string.bagian_jenis))
        saklar(getString(R.string.sw_pem_wa), prefs.pemWa) { prefs.pemWa = it }
        saklar(getString(R.string.sw_pem_wb), prefs.pemWb) { prefs.pemWb = it }
        saklar("Umumkan panggilan suara dan video masuk Telegram", prefs.pemTelegram) { prefs.pemTelegram = it }
        saklar(getString(R.string.sw_pem_telp), prefs.pemTelp) { prefs.pemTelp = it }
        info("Atur pesan sebelum dan sesudah nama untuk tiap jenis panggilan. Pola yang berbeda membantu mengenali panggilan telepon biasa, WhatsApp Messenger, WhatsApp Business, serta panggilan video. Kolom boleh dikosongkan untuk memakai kalimat standar.")
        pasanganPesan("Panggilan telepon seluler", prefs.pesanSebelumTelp, prefs.pesanSesudahTelp,
            { prefs.pesanSebelumTelp = it }, { prefs.pesanSesudahTelp = it }, namaLabel = "pemanggil telepon")
        pasanganPesan("Panggilan suara WhatsApp Messenger", prefs.pesanSebelumWaSuara, prefs.pesanSesudahWaSuara,
            { prefs.pesanSebelumWaSuara = it }, { prefs.pesanSesudahWaSuara = it }, namaLabel = "pemanggil WhatsApp Messenger")
        pasanganPesan("Panggilan video WhatsApp Messenger", prefs.pesanSebelumWaVideo, prefs.pesanSesudahWaVideo,
            { prefs.pesanSebelumWaVideo = it }, { prefs.pesanSesudahWaVideo = it }, namaLabel = "pemanggil video WhatsApp Messenger")
        pasanganPesan("Panggilan suara WhatsApp Business", prefs.pesanSebelumWbSuara, prefs.pesanSesudahWbSuara,
            { prefs.pesanSebelumWbSuara = it }, { prefs.pesanSesudahWbSuara = it }, namaLabel = "pemanggil WhatsApp Business")
        pasanganPesan("Panggilan video WhatsApp Business", prefs.pesanSebelumWbVideo, prefs.pesanSesudahWbVideo,
            { prefs.pesanSebelumWbVideo = it }, { prefs.pesanSesudahWbVideo = it }, namaLabel = "pemanggil video WhatsApp Business")
        pasanganPesan("Panggilan suara Telegram", prefs.pesanSebelumTelegramSuara, prefs.pesanSesudahTelegramSuara,
            { prefs.pesanSebelumTelegramSuara = it }, { prefs.pesanSesudahTelegramSuara = it }, namaLabel = "pemanggil Telegram")
        pasanganPesan("Panggilan video Telegram", prefs.pesanSebelumTelegramVideo, prefs.pesanSesudahTelegramVideo,
            { prefs.pesanSebelumTelegramVideo = it }, { prefs.pesanSesudahTelegramVideo = it }, namaLabel = "pemanggil video Telegram")

        // ----- Pengulangan -----
        bagian(getString(R.string.bagian_ulang))
        isian(
            getString(R.string.pem_jeda), formatDetik(prefs.pemJeda),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        ) { s ->
            val v = s.replace(',', '.').toFloatOrNull()
            if (v != null && v >= 0.3f) prefs.pemJeda = v.coerceAtMost(60f)
        }
        pilihan(getString(R.string.pem_batas), larik(R.array.pem_batas), prefs.pemBatasIdx) {
            prefs.pemBatasIdx = it
        }

    }


    private fun grupPembacaanPesan() {
        judulGrup("Pembacaan pesan dan notifikasi masuk")
        info("Aktifkan jenis notifikasi yang ingin dibacakan. Anda dapat mengatur pesan yang diucapkan sebelum dan sesudah nama pengirim untuk setiap jenis pesan. Untuk pesan suara WhatsApp, aplikasi membacakan pemberitahuannya dan nama pengirim jika tersedia; isi audio pesan suara tidak diubah menjadi teks.")
        bagian("Pesan seluler atau SMS", 17f)
        pilihan("Cara membaca SMS", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanSeluler) { prefs.modePesanSeluler = it }
        saklar("Bacakan notifikasi pesan seluler atau SMS", prefs.bacaPesanSeluler) { prefs.bacaPesanSeluler = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim SMS", prefs.pesanSebelumNamaSms, prefs.pesanSesudahNamaSms,
            { prefs.pesanSebelumNamaSms = it }, { prefs.pesanSesudahNamaSms = it }, "Contoh isi pesan")

        bagian("WhatsApp Messenger", 17f)
        pilihan("Cara membaca WhatsApp Messenger", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanWa) { prefs.modePesanWa = it }
        saklar("Bacakan chat teks pribadi WhatsApp Messenger", prefs.bacaChatWaPribadi) { prefs.bacaChatWaPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat pribadi WhatsApp Messenger", prefs.pesanSebelumChatWaPribadi, prefs.pesanSesudahChatWaPribadi,
            { prefs.pesanSebelumChatWaPribadi = it }, { prefs.pesanSesudahChatWaPribadi = it }, "Contoh isi pesan")
        saklar("Bacakan chat teks grup WhatsApp Messenger", prefs.bacaChatWaGrup) { prefs.bacaChatWaGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat grup WhatsApp Messenger", prefs.pesanSebelumChatWaGrup, prefs.pesanSesudahChatWaGrup,
            { prefs.pesanSebelumChatWaGrup = it }, { prefs.pesanSesudahChatWaGrup = it }, "Contoh isi pesan dari grup Keluarga")
        saklar("Bacakan pemberitahuan pesan suara pribadi WhatsApp Messenger", prefs.bacaSuaraWaPribadi) { prefs.bacaSuaraWaPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara pribadi WhatsApp Messenger", prefs.pesanSebelumSuaraWaPribadi, prefs.pesanSesudahSuaraWaPribadi,
            { prefs.pesanSebelumSuaraWaPribadi = it }, { prefs.pesanSesudahSuaraWaPribadi = it })
        saklar("Bacakan pemberitahuan pesan suara grup WhatsApp Messenger", prefs.bacaSuaraWaGrup) { prefs.bacaSuaraWaGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara grup WhatsApp Messenger", prefs.pesanSebelumSuaraWaGrup, prefs.pesanSesudahSuaraWaGrup,
            { prefs.pesanSebelumSuaraWaGrup = it }, { prefs.pesanSesudahSuaraWaGrup = it })

        bagian("WhatsApp Business", 17f)
        pilihan("Cara membaca WhatsApp Business", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanWb) { prefs.modePesanWb = it }
        saklar("Bacakan chat teks pribadi WhatsApp Business", prefs.bacaChatWbPribadi) { prefs.bacaChatWbPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat pribadi WhatsApp Business", prefs.pesanSebelumChatWbPribadi, prefs.pesanSesudahChatWbPribadi,
            { prefs.pesanSebelumChatWbPribadi = it }, { prefs.pesanSesudahChatWbPribadi = it }, "Contoh isi pesan")
        saklar("Bacakan chat teks grup WhatsApp Business", prefs.bacaChatWbGrup) { prefs.bacaChatWbGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat grup WhatsApp Business", prefs.pesanSebelumChatWbGrup, prefs.pesanSesudahChatWbGrup,
            { prefs.pesanSebelumChatWbGrup = it }, { prefs.pesanSesudahChatWbGrup = it }, "Contoh isi pesan dari grup Keluarga")
        saklar("Bacakan pemberitahuan pesan suara pribadi WhatsApp Business", prefs.bacaSuaraWbPribadi) { prefs.bacaSuaraWbPribadi = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara pribadi WhatsApp Business", prefs.pesanSebelumSuaraWbPribadi, prefs.pesanSesudahSuaraWbPribadi,
            { prefs.pesanSebelumSuaraWbPribadi = it }, { prefs.pesanSesudahSuaraWbPribadi = it })
        saklar("Bacakan pemberitahuan pesan suara grup WhatsApp Business", prefs.bacaSuaraWbGrup) { prefs.bacaSuaraWbGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara grup WhatsApp Business", prefs.pesanSebelumSuaraWbGrup, prefs.pesanSesudahSuaraWbGrup,
            { prefs.pesanSebelumSuaraWbGrup = it }, { prefs.pesanSesudahSuaraWbGrup = it })

        bagian("Telegram", 17f)
        info("Aktifkan pembacaan notifikasi chat Telegram pribadi/grup atau pemberitahuan pesan suara. Isi audio pesan suara tidak ditranskripsikan; aplikasi hanya membacakan teks pemberitahuan yang disediakan Telegram. Panggilan suara/video diumumkan jika Telegram menampilkannya sebagai notifikasi yang dapat dibaca Android.")
        pilihan("Cara membaca Telegram", listOf("Bacakan pemberitahuan dan isi pesan", "Bacakan pemberitahuan saja"), prefs.modePesanTelegram) { prefs.modePesanTelegram = it }
        saklar("Bacakan chat teks pribadi Telegram", prefs.bacaChatTelegramPribadi) { prefs.bacaChatTelegramPribadi = it }
        saklar("Bacakan chat teks grup Telegram", prefs.bacaChatTelegramGrup) { prefs.bacaChatTelegramGrup = it }
        saklar("Bacakan pemberitahuan pesan suara pribadi Telegram", prefs.bacaSuaraTelegramPribadi) { prefs.bacaSuaraTelegramPribadi = it }
        saklar("Bacakan pemberitahuan pesan suara grup Telegram", prefs.bacaSuaraTelegramGrup) { prefs.bacaSuaraTelegramGrup = it }
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat pribadi Telegram", prefs.pesanSebelumChatTelegramPribadi, prefs.pesanSesudahChatTelegramPribadi,
            { prefs.pesanSebelumChatTelegramPribadi = it }, { prefs.pesanSesudahChatTelegramPribadi = it }, "Contoh isi pesan")
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim chat grup Telegram", prefs.pesanSebelumChatTelegramGrup, prefs.pesanSesudahChatTelegramGrup,
            { prefs.pesanSebelumChatTelegramGrup = it }, { prefs.pesanSesudahChatTelegramGrup = it }, "Contoh isi pesan dari grup Keluarga")
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara pribadi Telegram", prefs.pesanSebelumSuaraTelegramPribadi, prefs.pesanSesudahSuaraTelegramPribadi,
            { prefs.pesanSebelumSuaraTelegramPribadi = it }, { prefs.pesanSesudahSuaraTelegramPribadi = it })
        pasanganPesan("Pesan sebelum dan sesudah nama pengirim pesan suara grup Telegram", prefs.pesanSebelumSuaraTelegramGrup, prefs.pesanSesudahSuaraTelegramGrup,
            { prefs.pesanSebelumSuaraTelegramGrup = it }, { prefs.pesanSesudahSuaraTelegramGrup = it })

        bagian("Pengulangan notifikasi pesan", 17f)
        info("Pengulangan ini berlaku untuk SMS, chat pribadi/grup, dan pemberitahuan pesan suara. Pengulangan panggilan masuk diatur terpisah.")
        pilihan("Jumlah pembacaan setiap notifikasi", listOf("1 kali", "2 kali", "3 kali", "5 kali"), prefs.notifUlangIdx) { prefs.notifUlangIdx = it }
        isian("Jeda antar pembacaan notifikasi dalam detik", formatDetik(prefs.notifJeda), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL) { v ->
            v.replace(',', '.').toFloatOrNull()?.let { if (it >= 1f) prefs.notifJeda = it.coerceAtMost(60f) }
        }
        tombol(getString(R.string.tombol_akses_notif)) { bukaAksesNotifikasi() }
    }

    private fun pasanganPesan(
        judul: String,
        sebelum: String,
        sesudah: String,
        simpanSebelum: (String) -> Unit,
        simpanSesudah: (String) -> Unit,
        contohTambahan: String = "",
        namaLabel: String = "pengirim"
    ) {
        bagian(judul, 14f)
        info("Isi pesan yang ingin diucapkan sebelum dan sesudah nama $namaLabel. Kolom boleh dikosongkan. Jika keduanya kosong, aplikasi memakai pemberitahuan standar.")
        val awal = isian("Pesan sebelum nama $namaLabel", sebelum, InputType.TYPE_CLASS_TEXT) { simpanSebelum(it) }
        val akhir = isian("Pesan sesudah nama $namaLabel", sesudah, InputType.TYPE_CLASS_TEXT) { simpanSesudah(it) }
        tombol("Tes susunan pesan — $judul") {
            simpanSebelum(awal.text?.toString().orEmpty())
            simpanSesudah(akhir.text?.toString().orEmpty())
            val contoh = listOf(awal.text?.toString().orEmpty(), "Ali Bima", akhir.text?.toString().orEmpty(), contohTambahan)
                .filter { it.isNotBlank() }.joinToString(" ")
            tesSuara("pem", contoh)
        }
    }

    private fun grupMelodi() {
        judulGrup("Melodi sebelum dan sesudah pengumuman")
        // ----- Melodi sebelum/sesudah pengumuman -----
        bagian(getString(R.string.bagian_melodi))
        info(getString(R.string.info_melodi))
        saklar(getString(R.string.sw_melodi_awal), prefs.melodiAwalOn) { prefs.melodiAwalOn = it }
        isian(getString(R.string.jeda_melodi_awal), prefs.jedaMelodiAwal.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAwal = v }
        }
        saklar(getString(R.string.sw_melodi_akhir), prefs.melodiAkhirOn) { prefs.melodiAkhirOn = it }
        isian(getString(R.string.jeda_melodi_akhir), prefs.jedaMelodiAkhir.toString(), InputType.TYPE_CLASS_NUMBER) {
            it.toIntOrNull()?.let { v -> prefs.jedaMelodiAkhir = v }
        }
        pilihan(getString(R.string.melodi_awal_pilih), larik(R.array.jam_melodi), prefs.melodiAwalIdx) {
            prefs.melodiAwalIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_awal)) { Melodi.putar(this, prefs.melodiAwalIdx, prefs.suara("pem").audioAttributes()) }
        pilihan(getString(R.string.melodi_akhir_pilih), larik(R.array.jam_melodi), prefs.melodiAkhirIdx) {
            prefs.melodiAkhirIdx = it
        }
        tombol(getString(R.string.dengarkan_melodi_akhir)) { Melodi.putar(this, prefs.melodiAkhirIdx, prefs.suara("pem").audioAttributes()) }
        tombol("Tes nada singkat") { Melodi.bunyikan(this, 180) }

    }

    private fun grupSuara() {
        judulGrup("Suara pengumuman")
        // ----- Suara -----
        // Tombol tes tiap kalimat diletakkan langsung di bawah kolom kalimat terkait.
        blokSuara("pem") {
            CallerListener.susun(this, prefs, true, false, getString(R.string.nama_contoh))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::teksAkses.isInitialized) teksAkses.text = getString(
            if (aksesNotifikasiAktif()) R.string.akses_notif_aktif else R.string.akses_notif_mati
        )
        if (::teksTelepon.isInitialized) teksTelepon.text = getString(
            if (izinTelepon()) R.string.izin_telepon_aktif else R.string.izin_telepon_mati
        )
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, hasil: IntArray) {
        super.onRequestPermissionsResult(code, perms, hasil)
        if (code == 2 && izinTelepon()) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, CallerListener::class.java))
            } catch (e: Exception) { }
        }
        onResume()
    }

    private fun izinTelepon() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun aksesNotifikasiAktif(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun bukaAksesNotifikasi() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            bukaInfoApp()
        }
    }

    private fun formatDetik(v: Float) = if (v % 1f == 0f) v.toInt().toString() else v.toString()
}
