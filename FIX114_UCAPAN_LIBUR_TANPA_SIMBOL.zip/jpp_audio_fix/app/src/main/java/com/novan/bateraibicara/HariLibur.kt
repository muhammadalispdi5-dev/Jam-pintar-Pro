package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

/** Data libur nasional dan cuti bersama dipisahkan seperti acuan main.lua. */
object HariLibur {
    private val formatIso = DateTimeFormatter.ISO_LOCAL_DATE
    private val sedangSinkron = HashSet<String>()

    private val nasional2026Id = mapOf(
        "2026-01-01" to "Tahun Baru Masehi",
        "2026-01-16" to "Isra Mikraj Nabi Muhammad SAW",
        "2026-02-17" to "Tahun Baru Imlek 2577 Kongzili",
        "2026-03-19" to "Hari Suci Nyepi Tahun Baru Saka 1948",
        "2026-03-21" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-03-22" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-04-03" to "Wafat Yesus Kristus",
        "2026-04-05" to "Kebangkitan Yesus Kristus Paskah",
        "2026-05-01" to "Hari Buruh Internasional",
        "2026-05-14" to "Kenaikan Yesus Kristus",
        "2026-05-27" to "Hari Raya Idul Adha 1447 Hijriah",
        "2026-05-31" to "Hari Raya Waisak 2570 BE",
        "2026-06-01" to "Hari Lahir Pancasila",
        "2026-06-16" to "Tahun Baru Islam 1448 Hijriah",
        "2026-08-17" to "Hari Proklamasi Kemerdekaan Republik Indonesia",
        "2026-08-25" to "Maulid Nabi Muhammad SAW",
        "2026-12-25" to "Hari Raya Natal"
    )
    private val nasional2026En = mapOf(
        "2026-01-01" to "New Year's Day", "2026-01-16" to "Ascension of the Prophet Muhammad",
        "2026-02-17" to "Chinese New Year 2577 Kongzili", "2026-03-19" to "Nyepi Saka 1948",
        "2026-03-21" to "Eid al-Fitr 1447 Hijriah", "2026-03-22" to "Eid al-Fitr 1447 Hijriah",
        "2026-04-03" to "Good Friday", "2026-04-05" to "Easter Sunday",
        "2026-05-01" to "International Labor Day", "2026-05-14" to "Ascension Day of Jesus Christ",
        "2026-05-27" to "Eid al-Adha 1447 Hijriah", "2026-05-31" to "Vesak Day 2570 BE",
        "2026-06-01" to "Pancasila Day", "2026-06-16" to "Islamic New Year 1448 Hijriah",
        "2026-08-17" to "Indonesian Independence Day", "2026-08-25" to "The Prophet's Birthday",
        "2026-12-25" to "Christmas Day"
    )
    private val cuti2026Id = mapOf(
        "2026-02-16" to "Tahun Baru Imlek", "2026-03-18" to "Hari Suci Nyepi",
        "2026-03-20" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-03-23" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-03-24" to "Hari Raya Idul Fitri 1447 Hijriah",
        "2026-05-15" to "Kenaikan Yesus Kristus",
        "2026-05-28" to "Hari Raya Idul Adha 1447 Hijriah",
        "2026-12-24" to "Hari Raya Natal"
    )
    private val cuti2026En = mapOf(
        "2026-02-16" to "Chinese New Year", "2026-03-18" to "Nyepi Day",
        "2026-03-20" to "Eid al-Fitr 1447 Hijriah", "2026-03-23" to "Eid al-Fitr 1447 Hijriah",
        "2026-03-24" to "Eid al-Fitr 1447 Hijriah", "2026-05-15" to "Ascension Day",
        "2026-05-28" to "Eid al-Adha 1447 Hijriah", "2026-12-24" to "Christmas Day"
    )

    /** Kata Indonesia yang tidak boleh tersisa pada rangkaian bahasa lain. */
    private val kataIndonesia = Regex(
        "\\b(hari|tahun|cuti|bersama|libur|raya|suci|lahir|wafat|kenaikan|kebangkitan|kemerdekaan|proklamasi|buruh|baru)\\b",
        RegexOption.IGNORE_CASE
    )

    private fun key(date: LocalDate) = date.format(formatIso)
    private fun cacheKey(kind: String, date: LocalDate) = ("hol_" + (kind) + "_" + (key(date)))
    private fun lang(p: Prefs) = p.bahasaAktif

    private fun staticName(kind: String, date: LocalDate, language: Int): String? {
        if (date.year != 2026) return null
        val k = key(date)
        return when (kind) {
            "national" -> if (language == 1) nasional2026En[k] else nasional2026Id[k]
            else -> if (language == 1) cuti2026En[k] else cuti2026Id[k]
        }
    }

    /** Kalimat utuh per bahasa untuk bahasa Indonesia dan English (tidak ditempel kata per kata). */
    private fun dua(english: Boolean, id: String, en: String): String = if (english) en else id

    private fun labelUmum(kind: String, language: Int): String = when (language) {
        1 -> if (kind == "national") "national holiday" else "joint leave"
        2 -> if (kind == "national") "عطلة وطنية" else "إجازة مشتركة"
        3 -> if (kind == "national") "preinan nasional" else "preinan sesarengan"
        4 -> if (kind == "national") "poé libur nasional" else "cuti babarengan"
        else -> if (kind == "national") "libur nasional" else "cuti bersama"
    }

    // ---------- Nama libur yang nyaman diucapkan (FIX114) ----------
    // Mesin suara membaca tanda baca dan singkatan secara harfiah ("kurung buka", "garis miring", "titik dua",
    // "es a we", "bee", "strip"). Nama dari sumber daring dirapikan sebelum diterjemahkan, dan singkatan yang
    // tersisa diperjelas sesudahnya.

    private val regexKutip = Regex("[\"“”„‟'’‘`´]")
    private val regexKeterangan = Regex("[(\\[{]\\s*(tentatif|tentative|perkiraan|prakiraan|estimasi|estimated)\\s*[)\\]}]", RegexOption.IGNORE_CASE)
    private val regexSawBertitik = Regex("\\bS\\.\\s?A\\.\\s?W\\b\\.?", RegexOption.IGNORE_CASE)
    private val regexRiBertitik = Regex("\\bR\\.\\s?I\\b\\.?")
    private val regexRi = Regex("\\bRI\\b")
    private val regexMiraj = Regex("\\bMiraj\\b", RegexOption.IGNORE_CASE)
    private val regexAwalanCuti = Regex("^cuti\\s+bersama\\s*,?\\s+", RegexOption.IGNORE_CASE)
    private val regexAwalanLibur = Regex("^(libur\\s+nasional|hari\\s+libur\\s+nasional|libur)\\s*,?\\s+", RegexOption.IGNORE_CASE)

    /**
     * Merapikan nama libur dari sumber daring: menghapus tanda kutip dan keterangan "(Tentatif)", mengubah tanda kurung,
     * garis miring, "&", garis hubung, titik dua, dan simbol lain menjadi kata atau jeda, memperluas singkatan "RI",
     * menyeragamkan "S.A.W." dan "Mi'raj", menjadikan akhiran tahun "1447 H", "2026 M", dan "2570 BE" kata Hijriah, Masehi,
     * dan Buddhis, serta membuang awalan "Cuti Bersama" atau "Libur Nasional" yang sudah
     * disebut oleh kalimat pembukanya.
     */
    private fun rapikanNama(sumber: String, kind: String): String {
        var t = sumber
        t = t.replace(regexKeterangan, " ")
        t = t.replace(regexKutip, "")
        t = t.replace(regexSawBertitik, "SAW")
        t = t.replace(Regex("(\\d{3,4})\\s?H\\b")) { m -> m.groupValues[1] + " Hijriah" }
        t = t.replace(Regex("(\\d{4})\\s?M\\b")) { m -> m.groupValues[1] + " Masehi" }
        t = t.replace(Regex("(\\d{4})\\s?BE\\b")) { m -> m.groupValues[1] + " Buddhis" }
        t = t.replace(regexRiBertitik, "RI").replace(regexRi, "Republik Indonesia")
        t = t.replace(regexMiraj, "Mikraj")
        t = t.replace("&", " dan ").replace("+", " dan ")
        t = t.replace(Regex("\\s*/\\s*"), " atau ")
        t = t.replace(Regex("(?<=\\d)\\s*[-–—]\\s*(?=\\d)"), " sampai ")
        t = t.replace(Regex("\\s+[-–—−]+\\s+"), ", ")
        t = t.replace(Regex("(?<=\\p{L})[-–—](?=\\p{L})"), " ")
        t = t.replace(Regex("[(\\[{]"), ", ").replace(Regex("[)\\]}]"), " ")
        t = t.replace(Regex("[:;]"), ", ")
        t = t.replace("%", " persen")
        t = t.replace(Regex("[*#@~^_|<>=\\\\]"), " ")
        t = t.replace(Regex("\\s+"), " ").replace(Regex("\\s+,"), ",").replace(Regex(",(\\s*,)+"), ",")
        t = t.trim().trim(',', '.', ' ').trim()
        val tanpaAwalan = t.replace(if (kind == "joint") regexAwalanCuti else regexAwalanLibur, "")
        if (tanpaAwalan.isNotBlank()) t = tanpaAwalan
        return t
    }

    /**
     * Langkah terakhir sebelum diucapkan: singkatan yang masih tersisa diperjelas sesuai bahasa. "SAW" menjadi ucapan
     * lengkap, tahun dengan akhiran H, M, atau BE menjadi kata (Hijriah, Masehi, Buddhis).
     */
    private fun ucapanAkhir(teks: String, language: Int): String {
        var t = teks
        val saw = when (language) { 1 -> "peace be upon him"; 2 -> "صلى الله عليه وسلم"; else -> "Shalallahu Alaihi Wasalam" }
        val hijriah = when (language) { 1 -> "Hijri"; 2 -> "هجرية"; else -> "Hijriah" }
        val masehi = when (language) { 1 -> "CE"; 2 -> "ميلادية"; else -> "Masehi" }
        val buddhis = when (language) { 1 -> "Buddhist Era"; 2 -> "بوذية"; else -> "Buddhis" }
        t = t.replace(Regex("\\bSAW\\b"), saw)
        t = t.replace(Regex("(\\d{3,4})\\s?H\\b")) { m -> m.groupValues[1] + " " + hijriah }
        t = t.replace(Regex("(\\d{4})\\s?M\\b")) { m -> m.groupValues[1] + " " + masehi }
        t = t.replace(Regex("(\\d{4})\\s?BE\\b")) { m -> m.groupValues[1] + " " + buddhis }
        return t.replace(Regex("\\s+"), " ").trim()
    }

    /** Nama libur siap ucap untuk bahasa tertentu, atau null bila tanggal itu bukan hari libur. */
    private fun name(context: Context, kind: String, date: LocalDate, language: Int): String? {
        val mentah = namaMentah(context, kind, date, language) ?: return null
        val akhir = ucapanAkhir(mentah, language)
        return if (akhir.isNotBlank()) akhir else labelUmum(kind, language)
    }

    private fun namaMentah(context: Context, kind: String, date: LocalDate, language: Int): String? {
        val cached = context.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
            .getString(cacheKey(kind, date), null)
        val dariCache = cached?.takeIf { it.isNotBlank() }
        val sumber = dariCache ?: staticName(kind, date, language) ?: return null
        // Daftar bawaan berbahasa Inggris sudah bersih; apostrof pada "New Year's Day" tidak boleh dibuang.
        val original = if (dariCache != null || language != 1) rapikanNama(sumber, kind) else sumber
        if (original.isBlank()) return labelUmum(kind, language)
        if (language == 1) {
            val englishNames = listOf(
                "Hari Raya Idul Fitri" to "Eid al-Fitr",
                "Idul Fitri" to "Eid al-Fitr",
                "Hari Raya Idul Adha" to "Eid al-Adha",
                "Idul Adha" to "Eid al-Adha",
                "Tahun Baru Islam" to "Islamic New Year",
                "Tahun Baru Hijriah" to "Islamic New Year",
                "Tahun Baru Masehi" to "New Year's Day",
                "Tahun Baru Saka" to "Saka New Year",
                "Kebangkitan Yesus Kristus Paskah" to "Easter Sunday",
                "Hijriah" to "Hijri",
                "Tahun Baru Imlek" to "Chinese New Year",
                "Maulid Nabi Muhammad SAW" to "Prophet Muhammad's Birthday",
                "Isra Mikraj Nabi Muhammad SAW" to "Isra and Mi'raj",
                "Isra Mikraj Nabi Muhammad S.A.W." to "Isra and Mi'raj",
                "Hari Suci Nyepi" to "Nyepi Day",
                "Hari Raya Waisak" to "Vesak Day",
                "Hari Lahir Pancasila" to "Pancasila Day",
                "Hari Proklamasi Kemerdekaan Republik Indonesia" to "Indonesian Independence Day",
                "Hari Kemerdekaan Republik Indonesia" to "Indonesian Independence Day",
                "Hari Buruh Internasional" to "International Workers' Day",
                "Kenaikan Yesus Kristus" to "Ascension Day",
                "Wafat Yesus Kristus" to "Good Friday",
                "Hari Raya Natal" to "Christmas Day",
                "Masehi" to "CE",
                "Buddhis" to "Buddhist Era"
            )
            val translatedEnglish = englishNames.fold(original) { teks, (asal, ganti) -> teks.replace(asal, ganti, ignoreCase = true) }
            if (!translatedEnglish.equals(original, ignoreCase = true)) {
                // Sisa kata Indonesia tidak dibiarkan masuk ke rangkaian English.
                return if (kataIndonesia.containsMatchIn(translatedEnglish)) {
                    if (kind == "national") "national holiday" else "joint leave"
                } else translatedEnglish
            }
            val likelyIndonesian = listOf("Hari ", "Tahun ", "Cuti Bersama", "Libur ", "Wafat Yesus", "Kenaikan Yesus").any {
                original.contains(it, ignoreCase = true)
            }
            return if (likelyIndonesian) {
                if (kind == "national") "national holiday" else "joint leave"
            } else original // Nama yang sudah berbahasa Inggris atau nama diri tetap dipertahankan.
        }
        if (language == 2) {
            val arab = listOf(
                "Hari Raya Idul Fitri" to "عيد الفطر",
                "Idul Fitri" to "عيد الفطر",
                "Hari Raya Idul Adha" to "عيد الأضحى",
                "Idul Adha" to "عيد الأضحى",
                "Tahun Baru Islam" to "رأس السنة الهجرية",
                "Maulid Nabi Muhammad SAW" to "المولد النبوي الشريف",
                "Isra Mikraj Nabi Muhammad SAW" to "الإسراء والمعراج",
                "Isra Mikraj Nabi Muhammad S.A.W." to "الإسراء والمعراج",
                "Hari Suci Nyepi" to "يوم نيبي",
                "Hari Raya Waisak" to "عيد ويساك",
                "Hari Lahir Pancasila" to "يوم بانكاسيلا",
                "Hari Proklamasi Kemerdekaan Republik Indonesia" to "يوم استقلال إندونيسيا",
                "Hari Kemerdekaan Republik Indonesia" to "يوم استقلال إندونيسيا",
                "Hari Buruh Internasional" to "يوم العمال العالمي",
                "Kenaikan Yesus Kristus" to "عيد صعود المسيح",
                "Wafat Yesus Kristus" to "الجمعة العظيمة",
                "Hari Raya Natal" to "عيد الميلاد",
                "Tahun Baru Masehi" to "رأس السنة الميلادية",
                "Tahun Baru Saka" to "رأس السنة الساكية",
                "Kebangkitan Yesus Kristus Paskah" to "عيد القيامة",
                "Hijriah" to "هجرية",
                "Masehi" to "ميلادية",
                "Buddhis" to "بوذية"
            )
            val translatedArabic = arab.fold(original) { teks, (asal, ganti) -> teks.replace(asal, ganti, ignoreCase = true) }
            return if (translatedArabic.equals(original, ignoreCase = true) || kataIndonesia.containsMatchIn(translatedArabic)) {
                if (kind == "national") "عطلة وطنية" else "إجازة مشتركة"
            } else translatedArabic
        }
        if (language == 4) {
            val padananSunda = listOf(
                "Hari Raya Idul Fitri" to "Poé Idul Fitri", "Hari Raya Idul Adha" to "Poé Idul Adha",
                "Tahun Baru Islam" to "Taun Anyar Islam", "Tahun Baru Masehi" to "Taun Anyar Maséhi",
                "Tahun Baru Imlek" to "Taun Anyar Imlek", "Tahun Baru Hijriah" to "Taun Anyar Hijriah",
                "Tahun Baru Saka" to "Taun Anyar Saka", "Hijriah" to "Hijriah",
                "Isra Mikraj Nabi Muhammad SAW" to "Isra Mikraj Nabi Muhammad SAW",
                "Isra Mikraj Nabi Muhammad S.A.W." to "Isra Mikraj Nabi Muhammad SAW",
                "Hari Suci Nyepi" to "Poé Nyepi", "Hari Raya Waisak" to "Poé Waisak",
                "Hari Lahir Pancasila" to "Poé Pancasila", "Hari Proklamasi Kemerdekaan Republik Indonesia" to "Poé Kamerdikaan Républik Indonésia",
                "Hari Kemerdekaan Republik Indonesia" to "Poé Kamerdikaan Républik Indonésia", "Hari Buruh Internasional" to "Poé Buruh Internasional",
                "Kenaikan Yesus Kristus" to "Poé Naékna Yesus Kristus", "Wafat Yesus Kristus" to "Poé Pupusna Yesus Kristus",
                "Kebangkitan Yesus Kristus Paskah" to "Poé Paskah", "Hari Raya Natal" to "Poé Natal",
                "Maulid Nabi Muhammad SAW" to "Maulid Nabi Muhammad SAW"
            )
            val translated = padananSunda.fold(original) { teks, (asal, ganti) -> teks.replace(asal, ganti, ignoreCase = true) }
            return if (translated.equals(original, ignoreCase = true) || kataIndonesia.containsMatchIn(translated)) {
                if (kind == "national") "libur nasional".replace("libur nasional", "poé libur nasional") else "poé cuti babarengan"
            } else JamBahasa.sundaAngkaDalamTeks(translated)
        }
        if (language != 3) return original
        // Padanan ringkes basa Jawa, manut fungsi translateHolidayNameJv ing acuan Lua.
        val padanan = listOf(
            "Hari Raya Idul Fitri" to "Riyaya Idul Fitri",
            "Hari Raya Idul Adha" to "Riyaya Idul Adha",
            "Tahun Baru Islam" to "Taun Enggal Islam",
            "Tahun Baru Masehi" to "Taun Enggal Masehi",
            "Tahun Baru Imlek" to "Taun Enggal Imlek",
            "Tahun Baru Hijriah" to "Taun Enggal Hijriyah",
            "Tahun Baru Saka" to "Taun Enggal Saka",
            "Hijriah" to "Hijriyah",
            "Isra Mikraj Nabi Muhammad SAW" to "Isra Mikraj Kanjeng Nabi Muhammad SAW",
            "Isra Mikraj Nabi Muhammad S.A.W." to "Isra Mikraj Kanjeng Nabi Muhammad SAW",
            "Hari Suci Nyepi" to "Dinten Riyaya Nyepi",
            "Hari Raya Waisak" to "Dinten Riyaya Waisak",
            "Hari Lahir Pancasila" to "Dinten Lairipun Pancasila",
            "Hari Proklamasi Kemerdekaan Republik Indonesia" to "Dinten Kamardikan Republik Indonesia",
            "Hari Kemerdekaan Republik Indonesia" to "Dinten Kamardikan Republik Indonesia",
            "Hari Buruh Internasional" to "Dinten Buruh Internasional",
            "Kenaikan Yesus Kristus" to "Minggahipun Yesus Kristus",
            "Wafat Yesus Kristus" to "Pasedanipun Yesus Kristus",
            "Kebangkitan Yesus Kristus Paskah" to "Wungunipun Yesus Kristus ing Paskah",
            "Hari Raya Natal" to "Dinten Riyaya Natal",
            "Maulid Nabi Muhammad SAW" to "Maulid Kanjeng Nabi Muhammad SAW"
        )
        val translated = padanan.fold(original) { teks, (asal, ganti) -> teks.replace(asal, ganti, ignoreCase = true) }
        // Yen sumber menehi jeneng anyar sing durung ana ing kamus, aja maca ukara
        // basa Indonesia ing tengah-tengah rangkaian Jawa.
        val umum = if (kind == "national") "preinan nasional" else "preinan sesarengan"
        if (translated.equals(original, ignoreCase = true)) {
            val fitri = original.replace("Idul Fitri", "Riyaya Idul Fitri", ignoreCase = true)
            if (!fitri.equals(original, ignoreCase = true) && !kataIndonesia.containsMatchIn(fitri)) return JamBahasa.jawaAngkaDalamTeks(fitri)
            val adha = original.replace("Idul Adha", "Riyaya Idul Adha", ignoreCase = true)
            if (!adha.equals(original, ignoreCase = true) && !kataIndonesia.containsMatchIn(adha)) return JamBahasa.jawaAngkaDalamTeks(adha)
            return umum
        }
        // Sisa kata Indonesia (mis. "Cuti Bersama") tidak dibiarkan; angka tahun dibaca dengan kata Jawa.
        if (kataIndonesia.containsMatchIn(translated)) return umum
        return JamBahasa.jawaAngkaDalamTeks(translated)
    }

    /** Sinkronisasi jaringan dijalankan di thread terpisah; kegagalan tidak menghapus cache/offline. */
    fun syncIfNeeded(context: Context, p: Prefs, year: Int = Calendar.getInstance().get(Calendar.YEAR)) {
        val national = p.liburNasionalAutoSync
        val joint = p.cutiBersamaAutoSync
        if (!national && !joint) return
        val prefs = context.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        val lockKey = ("hol_sync_year_" + (year) + "_" + (if (national && joint) "both" else if (national) "national" else "joint"))
        if (prefs.getInt(lockKey, 0) == year) return
        synchronized(sedangSinkron) {
            if (!sedangSinkron.add(lockKey)) return
        }
        Thread {
            try {
                val conn = (URL(("https://dayoffapi.vercel.app/api?year=" + (year))).openConnection() as HttpURLConnection)
                conn.requestMethod = "GET"
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.useCaches = false
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val arr = JSONArray(body)
                    val editor = prefs.edit()
                    var ditemukan = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val rawDate = item.optString("tanggal", "")
                        val name = item.optString("keterangan", "").trim()
                        if (rawDate.isBlank() || name.isBlank()) continue
                        val date = try { LocalDate.parse(rawDate.take(10), formatIso) } catch (_: Exception) { continue }
                        if (date.year != year) continue
                        val isJoint = item.optBoolean("is_cuti", false)
                        if (isJoint && joint) editor.putString(cacheKey("joint", date), name)
                        if (!isJoint && national) editor.putString(cacheKey("national", date), name)
                        if ((isJoint && joint) || (!isJoint && national)) ditemukan++
                    }
                    if (ditemukan > 0) {
                        editor.putInt(lockKey, year).putLong(("hol_sync_time_" + (year)), System.currentTimeMillis()).apply()
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
                // Tetap gunakan data offline dan cache sebelumnya.
            } finally {
                synchronized(sedangSinkron) { sedangSinkron.remove(lockKey) }
            }
        }.start()
    }

    private fun nearest(context: Context, p: Prefs, kind: String, start: LocalDate, direction: Long): Pair<LocalDate, String>? {
        // Sama dengan acuan: cari sampai 3660 hari, bukan dibatasi 7 hari.
        for (offset in 1L..3660L) {
            val date = start.plusDays(offset * direction)
            val holiday = name(context, kind, date, lang(p))
            if (holiday != null) return date to holiday
        }
        return null
    }

    private fun tanggal(date: LocalDate, p: Prefs): String {
        val bahasa = lang(p)
        val english = bahasa == 1
        val arabic = bahasa == 2
        val sunda = bahasa == 4
        val urutHari = date.dayOfWeek.value % 7 // Ahad/Minggu = indeks 0
        val hariId = arrayOf("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
        val hariJv = arrayOf("Ahad", "Senen", "Selasa", "Rebo", "Kemis", "Jemuah", "Setu")
        val hariAr = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val bulanId = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
        val bulanAr = arrayOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
        val hariSu = arrayOf("Ahad", "Senén", "Salasa", "Rebo", "Kemis", "Jumaah", "Saptu")
        val bulanSu = arrayOf("Januari", "Pébruari", "Maret", "April", "Méy", "Juni", "Juli", "Agustus", "Séptémber", "Oktober", "Nopémber", "Désémber")
        val day = when {
            english -> date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)
            arabic -> hariAr[urutHari]
            bahasa == 3 -> hariJv[urutHari]
            sunda -> hariSu[urutHari]
            else -> hariId[urutHari]
        }
        val month = when {
            english -> date.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)
            arabic -> bulanAr[date.monthValue - 1]
            sunda -> bulanSu[date.monthValue - 1]
            else -> bulanId[date.monthValue - 1]
        }
        return when {
            english -> ("" + (day) + ", " + (month) + " " + (date.dayOfMonth) + ", " + (date.year))
            arabic -> ("" + (day) + "، " + (date.dayOfMonth) + " " + (month) + " " + (date.year))
            bahasa == 3 -> ("dinten " + (day) + " tanggal " + (JamBahasa.jawaAngka(date.dayOfMonth)) + " wulan " + (month) + " taun " + (JamBahasa.jawaTaun(date.year)))
            sunda -> ("dinten " + day + ", tanggal " + JamBahasa.sundaKata(date.dayOfMonth) + " " + month + " taun " + JamBahasa.sundaTaun(date.year))
            else -> ("hari " + (day) + " tanggal " + (date.dayOfMonth) + " " + (month) + " " + (date.year))
        }
    }

    private fun addCategory(out: MutableList<String>, context: Context, p: Prefs, kind: String, date: LocalDate, pastOn: Boolean, currentOn: Boolean, upcomingOn: Boolean) {
        if (!pastOn && !currentOn && !upcomingOn) return
        val bahasa = lang(p)
        val english = bahasa == 1
        val arabic = bahasa == 2
        val jawa = bahasa == 3
        val sunda = bahasa == 4
        val label = when {
            kind == "national" && arabic -> "عطلة وطنية"
            kind != "national" && arabic -> "إجازة مشتركة"
            kind == "national" && jawa -> "preinan nasional"
            kind != "national" && jawa -> "preinan sesarengan"
            kind == "national" && sunda -> "poé libur nasional"
            kind != "national" && sunda -> "cuti babarengan"
            kind == "national" && english -> "national holiday"
            kind != "national" && english -> "joint leave"
            kind == "national" -> "libur nasional"
            else -> "cuti bersama"
        }
        if (pastOn) nearest(context, p, kind, date, -1)?.let { (d, n) ->
            out += when {
                english -> ("The most recent past " + (label) + " was " + (n) + " on " + (tanggal(d, p)) + ".")
                arabic -> ("كانت آخر " + (label) + " سابقة هي " + (n) + " بتاريخ " + (tanggal(d, p)) + ".")
                jawa -> ("" + (label) + " ingkang sampun kepengker inggih menika " + (n) + ", " + (tanggal(d, p)) + ".")
                sunda -> (label + " anu parantos kaliwat nyaéta " + n + ", " + tanggal(d, p) + ".")
                else -> ("" + (label) + " terakhir yang sudah lewat yaitu " + (n) + " pada " + (tanggal(d, p)) + ".")
            }
        }
        if (currentOn) {
            val today = name(context, kind, date, bahasa)
            out += if (today != null) when {
                english -> ("Today's " + (label) + " is " + (today) + " on " + (tanggal(date, p)) + ".")
                arabic -> ("عطلة اليوم هي " + (today) + " بتاريخ " + (tanggal(date, p)) + ".")
                jawa -> ("Dinten menika wonten " + (label) + " inggih menika " + (today) + ", " + (tanggal(date, p)) + ".")
                sunda -> ("Dinten ieu aya " + label + " nyaéta " + today + ", " + tanggal(date, p) + ".")
                else -> ("" + (label) + " hari ini yaitu " + (today) + " pada " + (tanggal(date, p)) + ".")
            } else when {
                english -> ("There is no " + (label) + " today in the available calendar data.")
                arabic -> ("لا توجد " + (label) + " مسجلة لهذا اليوم في بيانات التقويم المتاحة.")
                jawa -> ("Dinten menika boten wonten " + (label) + " ing data kalender ingkang kasimpen.")
                sunda -> ("Dinten ieu teu aya " + label + " anu kacatet dina data kalénder.")
                else -> ("hari ini tidak ada " + (label) + " yang tercatat pada data kalender.")
            }
        }
        if (upcomingOn) nearest(context, p, kind, date, 1)?.let { (d, n) ->
            out += when {
                english -> ("The next upcoming " + (label) + " is " + (n) + " on " + (tanggal(d, p)) + ".")
                arabic -> ("أقرب " + (label) + " قادمة هي " + (n) + " بتاريخ " + (tanggal(d, p)) + ".")
                jawa -> ("" + (label) + " salajengipun inggih menika " + (n) + ", " + (tanggal(d, p)) + ".")
                sunda -> (label + " salajengna nyaéta " + n + ", " + tanggal(d, p) + ".")
                else -> ("" + (label) + " terdekat berikutnya yaitu " + (n) + " pada " + (tanggal(d, p)) + ".")
            }
        }
    }

    /** Hanya segmen yang diaktifkan pengguna yang ikut dalam pengumuman tanggal otomatis. */
    fun segmen(p: Prefs, calendar: Calendar): List<String> {
        if (p.liburNasionalAutoSync || p.cutiBersamaAutoSync) syncIfNeeded(p.appContext, p, calendar.get(Calendar.YEAR))
        val date = LocalDate.of(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH))
        val out = ArrayList<String>()
        addCategory(out, p.appContext, p, "national", date, p.liburNasionalLampau, p.liburNasionalTerkini, p.liburNasionalMendatang)
        addCategory(out, p.appContext, p, "joint", date, p.cutiBersamaLampau, p.cutiBersamaTerkini, p.cutiBersamaMendatang)
        return out
    }

    /** Jawaban satu kategori dan satu rentang waktu untuk perintah suara. */
    fun jawabanKhusus(context: Context, p: Prefs, kind: String, periode: String, calendar: Calendar): String {
        val today = LocalDate.of(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH))
        syncIfNeeded(context, p, today.year)
        val label = when (p.bahasaAktif) {
            1 -> if (kind == "national") "national holiday" else "joint leave"
            2 -> if (kind == "national") "العطلة الوطنية" else "الإجازة المشتركة"
            3 -> if (kind == "national") "preinan nasional" else "preinan sesarengan"
            4 -> if (kind == "national") "poé libur nasional" else "cuti babarengan"
            else -> if (kind == "national") "libur nasional" else "cuti bersama"
        }
        val result: Pair<LocalDate, String>? = when (periode) {
            "past" -> nearest(context, p, kind, today, -1)
            "next" -> nearest(context, p, kind, today, 1)
            else -> name(context, kind, today, lang(p))?.let { today to it }
        }
        val english = p.bahasaAktif == 1
        val arabic = p.bahasaAktif == 2
        val jawa = p.bahasaAktif == 3
        val sunda = p.bahasaAktif == 4
        if (result == null) return when {
            english && periode == "today" -> "There is no $label recorded for today."
            english -> "No $label date was found in the available calendar data."
            arabic && periode == "today" -> "لا توجد $label مسجلة لهذا اليوم."
            arabic -> "لم يتم العثور على موعد $label في بيانات التقويم المتاحة."
            jawa && periode == "today" -> "Dinten menika boten wonten $label ingkang kacathet."
            jawa -> "Tanggal $label boten kapanggih ing data kalender ingkang cumawis."
            sunda && periode == "today" -> "Dinten ieu teu aya $label anu kacatet."
            sunda -> "Tanggal $label teu kapanggih dina data kalénder anu sayogi."
            periode == "today" -> "Hari ini tidak ada $label yang tercatat."
            else -> "Tanggal $label tidak ditemukan pada data kalender yang tersedia."
        }
        val tanggal = tanggal(result.first, p)
        return when {
            english && periode == "past" -> "The most recent past $label was ${result.second}, on $tanggal."
            english && periode == "next" -> "The next $label is ${result.second}, on $tanggal."
            arabic && periode == "past" -> "آخر $label سابق هو ${result.second} بتاريخ $tanggal."
            arabic && periode == "next" -> "أقرب $label قادم هو ${result.second} بتاريخ $tanggal."
            arabic -> "يوجد اليوم $label وهي ${result.second} بتاريخ $tanggal."
            jawa && periode == "past" -> "$label ingkang sampun kepengker inggih menika ${result.second}, $tanggal."
            jawa && periode == "next" -> "$label salajengipun inggih menika ${result.second}, $tanggal."
            jawa -> "Dinten menika wonten $label inggih menika ${result.second}, $tanggal."
            sunda && periode == "past" -> "$label anu parantos kaliwat nyaéta ${result.second}, $tanggal."
            sunda && periode == "next" -> "$label salajengna nyaéta ${result.second}, $tanggal."
            sunda -> "Dinten ieu aya $label nyaéta ${result.second}, $tanggal."
            periode == "past" -> "$label terakhir yang sudah lewat adalah ${result.second}, pada $tanggal."
            periode == "next" -> "$label berikutnya adalah ${result.second}, pada $tanggal."
            else -> dua(english, "Hari ini terdapat $label yaitu ${result.second}, pada $tanggal.", "Today's $label is ${result.second}, on $tanggal.")
        }
    }

    /** Bacakan seluruh ringkasan satu kategori, terlepas dari sakelar info otomatis. */
    fun ringkasan(context: Context, p: Prefs, kind: String): List<String> {
        syncIfNeeded(context, p)
        val today = LocalDate.now()
        val bahasa = lang(p)
        val jawa = bahasa == 3
        val english = bahasa == 1
        val arabic = bahasa == 2
        val sunda = bahasa == 4
        val label = when {
            kind == "national" && arabic -> "عطلة وطنية"
            kind != "national" && arabic -> "إجازة مشتركة"
            kind == "national" && jawa -> "preinan nasional"
            kind != "national" && jawa -> "preinan sesarengan"
            kind == "national" && sunda -> "poé libur nasional"
            kind != "national" && sunda -> "cuti babarengan"
            kind == "national" && english -> "national holiday"
            kind != "national" && english -> "joint leave"
            kind == "national" -> "libur nasional"
            else -> "cuti bersama"
        }
        val current = name(context, kind, today, bahasa)
        val past = nearest(context, p, kind, today, -1)
        val future = nearest(context, p, kind, today, 1)
        val out = mutableListOf(when {
            english -> ("Information about " + (label) + ".")
            arabic -> ("معلومات عن " + (label) + ".")
            jawa -> ("Pawartos babagan " + (label) + ".")
            sunda -> ("Inpormasi ngeunaan " + label + ".")
            else -> ("Informasi " + (label) + ".")
        })
        out += if (current != null) when {
            arabic -> ("توجد اليوم " + (label) + " وهي " + (current) + "، بتاريخ " + (tanggal(today, p)) + ".")
            jawa -> ("Dinten menika wonten " + (label) + " inggih menika " + (current) + ", " + (tanggal(today, p)) + ".")
            sunda -> ("Dinten ieu aya " + label + " nyaéta " + current + ", " + tanggal(today, p) + ".")
            else -> dua(english, "Hari ini terdapat " + label + " yaitu " + current + ", pada " + tanggal(today, p) + ".", "Today there is a " + label + ", " + current + ", on " + tanggal(today, p) + ".")
        } else when {
            english -> ("No " + (label) + " is recorded for today.")
            arabic -> ("لا توجد " + (label) + " مسجلة لهذا اليوم.")
            jawa -> ("Dinten menika boten wonten " + (label) + " ingkang kacathet.")
            sunda -> ("Dinten ieu teu aya " + label + " anu kacatet.")
            else -> ("Hari ini tidak ada " + (label) + " yang tercatat pada data kalender.")
        }
        if (past != null) out += when {
            arabic -> ("آخر عطلة سابقة هي " + (past.second) + " بتاريخ " + (tanggal(past.first, p)) + ".")
            jawa -> ("" + (label) + " ingkang sampun kepengker inggih menika " + (past.second) + ", " + (tanggal(past.first, p)) + ".")
            sunda -> (label + " anu parantos kaliwat nyaéta " + past.second + ", " + tanggal(past.first, p) + ".")
            else -> dua(english, "Yang terakhir sudah lewat yaitu " + past.second + ", pada " + tanggal(past.first, p) + ".", "The most recent past one was " + past.second + ", on " + tanggal(past.first, p) + ".")
        }
        if (future != null) out += when {
            arabic -> ("أقرب عطلة قادمة هي " + (future.second) + " بتاريخ " + (tanggal(future.first, p)) + ".")
            jawa -> ("" + (label) + " salajengipun inggih menika " + (future.second) + ", " + (tanggal(future.first, p)) + ".")
            sunda -> (label + " salajengna nyaéta " + future.second + ", " + tanggal(future.first, p) + ".")
            else -> dua(english, "Yang akan datang berikutnya yaitu " + future.second + ", pada " + tanggal(future.first, p) + ".", "The next upcoming one is " + future.second + ", on " + tanggal(future.first, p) + ".")
        }
        if (past == null && future == null && current == null) out += when {
            english -> "Data for this year is not available yet. Check the calendar update."
            arabic -> "بيانات هذا العام غير متاحة بعد. يرجى التحقق من تحديث التقويم."
            jawa -> "Data taun menika dereng cumawis. Mangga priksa panganyaran kalender."
            sunda -> "Data kanggo taun ieu teu acan sayogi. Mangga pariksa apdet kalénder."
            else -> "Data untuk tahun ini belum tersedia. Periksa pembaruan kalender."
        }
        return out
    }
}
