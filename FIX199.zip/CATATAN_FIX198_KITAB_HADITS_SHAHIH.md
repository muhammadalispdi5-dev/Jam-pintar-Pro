# FIX198: Fitur Kitab Hadits Shahih

Berkas baru: KitabHadits.kt (data, unduhan, pembaca JSON bertahap), HaditsActivity.kt (halaman).
Diubah: AndroidManifest.xml (activity), MainActivity.kt (tombol di beranda setelah Khatam), strings.xml id dan en (judul_hadits, menu_hadits).

Cara kerja:
- Teks hadits tidak ditulis di aplikasi. Diunduh sekali dari jsDelivr (cadangan GitHub) proyek fawazahmed0/hadith-api: edisi Arab dan terjemahan Indonesia.
- Disimpan di filesDir/hadits lalu dibaca secara streaming (memori kecil, bisa offline).
- Kitab: Shahih Bukhari (ara-bukhari, ind-bukhari), Shahih Muslim (ara-muslim, ind-muslim), Arbain Nawawi (ara-nawawi, ind-nawawi), Riyadhus Shalihin (ara-riyadussalihin, ind-riyadussalihin).
- Halaman kitab: unduh, cari nomor hadits, daftar bagian, baca dari awal, hapus data.
- Halaman baca: 5 hadits per halaman, teks Arab (RTL) + terjemahan, derajat, Salin, Bagikan, halaman/hadits berikutnya dan sebelumnya.
- Bila edisi Indonesia tidak ada, teks Arab tetap tampil dengan keterangan. Bila edisi Arab tidak ada (404), muncul pesan gagal unduh.

BELUM DIVERIFIKASI (sandbox tanpa akses jaringan ke layanan itu): nama edisi, terutama nawawi dan riyadussalihin, dan bentuk JSON (metadata.section, hadiths[].hadithnumber/text/grades/reference.book). Daftar kandidat ada di KitabHadits.daftar, mudah diubah.

Bahasa aktif: semua teks baru lewat tr() dan resource id/en; nama kitab dwibahasa. Pemeriksa bahasa aktif dan resource string LULUS.

## FIX199
Perbaikan: validasi unduhan memanggil baca(..., hanyaMetadata=true) sehingga tidak ada hadits terbaca dan semua unduhan ditolak. Kini hanyaMetadata=false.
