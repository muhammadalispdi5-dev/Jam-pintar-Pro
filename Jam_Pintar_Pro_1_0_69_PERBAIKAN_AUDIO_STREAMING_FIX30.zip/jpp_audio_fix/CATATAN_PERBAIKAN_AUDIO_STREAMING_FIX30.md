# Perbaikan audio murattal Khatam: "Audio gagal diputar setelah mencoba beberapa sumber"

Versi tetap 1.0.69.

## Penyebab yang ditemukan
1. **Pengenal qari salah (5 dari 9 qari).** CDN Al Quran Cloud memakai pengenal `ar.abdurrahmaansudais`, `ar.saoodshuraym`,
   `ar.abdulbasitmurattal`, `ar.ahmedajamy`, dan `ar.muhammadayyoub`; kode memakai `ar.sudais`, `ar.shuraim`, `ar.abdulbasit`,
   `ar.ajamy`, `ar.muhammadayoub`, sehingga server membalas 404 untuk qari tersebut. Sudah dibetulkan; pilihan qari lama yang
   tersimpan di perangkat otomatis dipetakan ke pengenal yang benar.
2. **Templat string `$qariId`, `$bitrate`, `${nomorAyatGlobal()}` pada URL.** Pada pipeline CI proyek ini penulisan `$nama` di dalam
   teks tidak terisi (pernah terbaca mentah di aplikasi). `urlAudioPercobaan` memanggil replace("/audio/128/", "/audio/$bitrate/")
   bahkan pada percobaan pertama, sehingga seluruh percobaan memakai URL berisi teks mentah dan semuanya gagal. Seluruh templat
   di kode Kotlin ditulis ulang menjadi penggabungan string (tidak ada lagi tanda dolar di kode).
3. **Diagnosis penyebab.** Bila semua percobaan gagal, aplikasi kini memeriksa server di latar belakang dan menambahkan penyebab pada
   status audio: berkas tidak ada (HTTP 404), server menjawab kode lain, nama server tidak ditemukan (DNS/VPN), batas waktu,
   sambungan HTTPS gagal, atau server terjangkau tetapi pemutar tidak dapat membuka berkas.

## Belum dapat dipastikan dari sini
Uji pemutaran nyata di ponsel dan kompilasi Gradle tidak dapat dijalankan di lingkungan ini. Audio surah penuh (`audio-surah`) mungkin
tidak tersedia untuk semua qari di CDN; bila 404, diagnosis akan menyebutkannya dan pengguna dapat memilih qari lain atau memakai audio per ayat.
