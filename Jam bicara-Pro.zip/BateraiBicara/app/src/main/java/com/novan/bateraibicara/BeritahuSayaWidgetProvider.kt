package com.novan.bateraibicara

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Widget layar utama: sekali ditekan, waktu langsung dibacakan tanpa membuka menu aplikasi. */
class BeritahuSayaWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val intent = Intent(context, BeritahuSayaActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        val pending = PendingIntent.getActivity(
            context,
            817,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_beritahu_saya)
            views.setOnClickPendingIntent(R.id.widget_beritahu_root, pending)
            views.setOnClickPendingIntent(R.id.widget_beritahu_button, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
