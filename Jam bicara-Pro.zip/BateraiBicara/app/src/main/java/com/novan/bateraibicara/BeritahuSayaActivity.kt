package com.novan.bateraibicara

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.util.Calendar

/** Aktivitas transparan yang menjadi pemicu suara dari widget layar utama. */
class BeritahuSayaActivity : Activity() {
    private var pembicara: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutup() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val prefs = Prefs(applicationContext)
            val teks = JamWaktu.ucapan(prefs, Calendar.getInstance())
            val p = Pembicara(applicationContext, prefs.suara("jam"))
            pembicara = p
            handler.postDelayed(batasWaktu, 60_000L)
            p.ucapkan(teks, true) { tutup() }
        } catch (_: Exception) {
            tutup()
        }
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
        super.onDestroy()
    }
}
