package com.novan.bateraibicara

import java.util.Calendar

/** Penyusun kalimat pengumuman waktu dalam bahasa pilihan dan penghitung jadwal berikutnya. */
object JamWaktu {

    private val SATUAN = arrayOf(
        "nol", "satu", "dua", "tiga", "empat", "lima",
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"
    )

    fun kata(n: Int): String = when {
        n < 12 -> SATUAN[n]
        n < 20 -> SATUAN[n - 10] + " belas"
        n < 100 -> {
            val s = n % 10
            SATUAN[n / 10] + " puluh" + if (s > 0) " " + SATUAN[s] else ""
        }
        else -> n.toString()
    }

    private fun bagianHari(h: Int) = when (h) {
        in 0..3 -> "dini hari"
        in 4..9 -> "pagi"
        in 10..14 -> "siang"
        in 15..17 -> "sore"
        18 -> "petang"
        else -> "malam"
    }

    fun ucapan(p: Prefs, c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val duabelas = p.jamFormat == 1
        val jam = if (duabelas) (if (h % 12 == 0) 12 else h % 12) else h
        val sebutJam = p.jamSebutJam
        val sebutMenit = p.jamSebutMenit
        val sebutPeriode = duabelas && p.jamSebutPeriode

        if (p.jamBahasaIdx == 1) {
            val sb = StringBuilder("It is")
            if (sebutJam) sb.append(" ").append(JamBahasa.kata(jam, 1))
            if (sebutMenit) {
                if (sebutJam && m == 0) sb.append(" o'clock")
                else if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(",")
                    sb.append(" ").append(JamBahasa.kata(m, 1))
                } else sb.append(" ").append(JamBahasa.kata(m, 1)).append(" minutes")
            } else if (sebutJam && m == 0) sb.append(" o'clock")
            if (sebutPeriode) sb.append(if (h < 12) " AM" else " PM")
            return sb.toString()
        }
        if (p.jamBahasaIdx == 2) {
            val sb = StringBuilder("الوقت الحالي")
            if (sebutJam) sb.append("، الساعة ").append(JamBahasa.kata(jam, 2))
            if (sebutMenit) {
                if (sebutJam && m == 0) sb.append(" تمامًا")
                else if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append("،")
                    sb.append(" و").append(JamBahasa.kata(m, 2)).append(" دقيقة")
                } else sb.append(" ").append(JamBahasa.kata(m, 2)).append(" دقيقة")
            } else if (sebutJam && m == 0) sb.append(" تمامًا")
            return sb.toString()
        }
        if (p.jamBahasaIdx == 3) {
            val sb = StringBuilder("Sapunika")
            if (sebutJam) sb.append(" tabuh ").append(jawaKata(jam))
            if (sebutMenit) {
                if (sebutJam && m == 0) sb.append(" pas")
                else if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(",")
                    sb.append(" langkung ").append(jawaKata(m)).append(" menit")
                } else sb.append(" menit ").append(jawaKata(m))
            } else if (sebutJam && m == 0) sb.append(" pas")
            if (sebutPeriode) sb.append(' ').append(when (h) {
                in 0..3 -> "tengah dalu"
                in 4..10 -> "enjing"
                in 11..14 -> "siang"
                in 15..18 -> "sonten"
                else -> "dalu"
            })
            return sb.toString()
        }

        val sb = StringBuilder(p.jamAwalan.trim())
        if (sebutJam) sb.append(' ').append(kata(jam))
        if (sebutMenit) {
            if (sebutJam && m == 0) sb.append(" tepat")
            else if (sebutJam) {
                if (p.jamJedaJamMenit > 0) sb.append(",")
                sb.append(" lewat ").append(kata(m)).append(" menit")
            } else sb.append(" menit ").append(kata(m))
        } else if (sebutJam && m == 0) sb.append(" tepat")
        if (sebutPeriode) sb.append(' ').append(bagianHari(h))
        return sb.toString()
    }

    /** Angka basa Jawa krama untuk pengumuman waktu. */
    private fun jawaKata(n: Int): String {
        val satuan = arrayOf("nol", "setunggal", "kalih", "tigang", "sekawan", "gangsal", "enem", "pitu", "wolu", "sanga")
        return when (n) {
            in 0..9 -> satuan[n]
            10 -> "sedasa"
            11 -> "setunggal welas"
            12 -> "kalih welas"
            13 -> "tiga welas"
            14 -> "sekawan welas"
            15 -> "gangsal welas"
            16 -> "enem welas"
            17 -> "pitulas"
            18 -> "wolulas"
            19 -> "sangalas"
            20 -> "kalih dasa"
            21 -> "selikur"
            22 -> "kalih likur"
            23 -> "tigang likur"
            24 -> "sekawan likur"
            25 -> "selangkung"
            26 -> "enem likur"
            27 -> "pitung likur"
            28 -> "wolung likur"
            29 -> "sangang likur"
            in 30..99 -> {
                val puluhan = when (n / 10) {
                    3 -> "tigang dasa"
                    4 -> "sekawan dasa"
                    5 -> "seket"
                    6 -> "sawidak"
                    7 -> "pitung dasa"
                    8 -> "wolung dasa"
                    9 -> "sangang dasa"
                    else -> n.toString()
                }
                if (n % 10 == 0) puluhan else "$puluhan ${satuan[n % 10]}"
            }
            else -> n.toString()
        }
    }

    /** Pecah ucapan pada tanda koma agar jeda jam-menit dapat diterapkan oleh TTS. */
    fun bagianUcapan(p: Prefs, c: Calendar): Pair<String, String?> {
        val teks = ucapan(p, c)
        if (p.jamJedaJamMenit <= 0) return Pair(teks, null)
        val posisi = teks.indexOf(", ")
        return if (posisi >= 0) Pair(teks.substring(0, posisi), teks.substring(posisi + 2)) else Pair(teks, null)
    }

    /** "06.30" */
    fun format(menit: Int): String = "%02d.%02d".format(menit / 60, menit % 60)

    private val NAMA_HARI = arrayOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")

    fun ringkasHari(mask: Int): String {
        if ((mask and 127) == 127) return "Setiap hari"
        if ((mask and 127) == 0) return "Tidak ada"
        // Urutan tampil Senin..Minggu
        return listOf(1, 2, 3, 4, 5, 6, 0).filter { (mask and (1 shl it)) != 0 }
            .joinToString(", ") { NAMA_HARI[it] }
    }

    /** Waktu (ms) jadwal pertama yang lebih besar dari [setelah], atau null bila tidak ada hari aktif. */
    fun berikut(p: Prefs, setelah: Long): Long? {
        val mulai = p.jamMulai
        val selesai = p.jamSelesai
        val panjang = when {
            selesai > mulai -> selesai - mulai
            selesai < mulai -> selesai + 1440 - mulai
            else -> 0
        }
        val langkah = if (p.jamMode == 0) 60 else p.jamInterval
        val awal = if (p.jamMode == 0) (60 - mulai % 60) % 60 else 0
        if (p.jamHari == 0) return null

        for (d in -1..8) {
            val dasar = Calendar.getInstance()
            dasar.timeInMillis = setelah
            dasar.set(Calendar.HOUR_OF_DAY, 0)
            dasar.set(Calendar.MINUTE, 0)
            dasar.set(Calendar.SECOND, 0)
            dasar.set(Calendar.MILLISECOND, 0)
            dasar.add(Calendar.DAY_OF_YEAR, d)
            val hari = dasar.get(Calendar.DAY_OF_WEEK) - 1
            if ((p.jamHari and (1 shl hari)) == 0) continue
            var off = awal
            while (off <= panjang) {
                val t = dasar.clone() as Calendar
                t.add(Calendar.MINUTE, mulai + off)
                if (t.timeInMillis > setelah) return t.timeInMillis
                off += langkah
            }
        }
        return null
    }
}
