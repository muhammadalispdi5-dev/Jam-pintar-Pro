# Catatan Audit Fitur — Baterai Bicara 1.0.18

Dokumen ini mencatat pemeriksaan kode sumber proyek. Ini bukan pengganti uji APK di perangkat.

## Baterai
- Aktif/nonaktif pemantauan dan pengucapan baterai.
- Pengucapan berdasarkan perubahan persentase atau interval waktu.
- Pilihan langkah persentase dan mode pengucapan saat mengisi/tidak mengisi.
- Peringatan baterai lemah dengan batas pilihan.
- Peringatan baterai kritis dengan batas pilihan 1%, 2%, 3%, 5%, 7%, 10%, 15%, atau 20%.
- Pengumuman baterai penuh dengan batas 80–100%, serta pilihan pengulangan dan jeda.
- Pengumuman saat pengisi daya atau kabel USB dipasang/dicabut.
- Kalimat tiap kejadian dapat diubah, dengan tombol uji ditempatkan tepat setelah kolom kalimat terkait.
- Pengaturan mesin TTS, kecepatan, nada, saluran keluaran suara (termasuk volume sistem), pratinjau contoh ucapan, dan tombol tes suara.
- Tampilan status baterai, notifikasi layanan, widget, dan pemulihan layanan setelah boot.

## Jam bicara
- Jadwal jam tepat atau interval menit (termasuk setiap 1 jam), jam mulai/selesai, dan pilihan hari aktif.
- Format 12/24 jam, sakelar terpisah untuk menyebut jam, menit, dan keterangan waktu (dini hari/pagi/siang/sore/petang/malam), kalimat pembuka, jeda jam-menit, melodi awal/akhir, serta uji ucapan.
- Bahasa Indonesia, Inggris, Arab, dan Jawa Krama Inggil.
- Untuk Jawa Krama Inggil, kode meminta locale `jv-ID`; ketersediaan dan mutu suara tetap bergantung pada mesin TTS yang terpasang. Jika tidak didukung, aplikasi menggunakan suara cadangan Indonesia dan menampilkan peringatan.

## Nama pemanggil
- Pengumuman untuk WhatsApp, WhatsApp Bisnis, dan telepon seluler dengan pilihan aktif/nonaktif.
- Kalimat khusus panggilan suara/video untuk WhatsApp dan WhatsApp Bisnis, serta kalimat telepon biasa; jenis panggilan dapat diucapkan atau disembunyikan melalui sakelar dan token `{jenis}`.
- Placeholder `{nama}`, contoh uji **Ali Bima**, opsi nama panggilan kontak, dan pengaturan jeda/batas pengulangan.
- Pengaturan akses notifikasi, izin telepon/kontak, dan tombol uji tiap kalimat di dekat kolom yang sesuai.
- Pengaturan dan tombol uji melodi awal/akhir.

## Media tambahan
- 16 berkas melodi tersedia pada `app/src/main/res/raw/`.

## Status validasi
- XML diparse tanpa kesalahan.
- Referensi resource aplikasi diperiksa; referensi yang tersisa tanpa definisi adalah resource Android bawaan (`android.R.string.cancel` dan `android.R.string.ok`).
- `JamWaktu.kt` dikompilasi dan diuji dengan harness Kotlin terpisah untuk beberapa waktu contoh.
- **Kompilasi APK Android penuh dan pengujian panggilan/baterai pada perangkat belum dilakukan di lingkungan ini.** Jalankan GitHub Actions untuk memvalidasi build lengkap dan lakukan uji pada perangkat dengan mesin TTS yang digunakan.

## Tambahan pemicu eksternal (pasca-1.0.18)
- Widget layar utama terpisah bernama **Beritahu Saya**, berdasarkan pola widget yang ditemukan di APK acuan Jam Bicara 8.17-pro.
- Ketukan widget membuka aktivitas transparan, membacakan waktu saat ini melalui `JamWaktu.ucapan()` dan profil suara `jam`, lalu menutup aktivitas setelah ucapan selesai (dengan batas waktu pengaman 60 detik).
- Widget ini berbeda dari widget status baterai; keduanya dapat ditambahkan secara terpisah ke layar utama.
- Validasi akhir kompilasi Android penuh tetap harus dilakukan lewat GitHub Actions.
