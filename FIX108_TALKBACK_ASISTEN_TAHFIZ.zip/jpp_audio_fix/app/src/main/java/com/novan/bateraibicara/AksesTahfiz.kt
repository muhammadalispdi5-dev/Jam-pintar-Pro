package com.novan.bateraibicara

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button

/**
 * FIX108: perangkat bantu aksesibilitas untuk Asisten Tahfiz Cerdas.
 *
 * Tujuan: nama kontrol = teks yang terlihat (cocok untuk TalkBack dan Voice Access), uraian dibacakan sebagai petunjuk
 * terpisah (bukan digabung ke dalam nama), judul ditandai sebagai judul, daftar diumumkan sebagai daftar berurutan,
 * dan satu kelompok teks dibaca sekali saja (tidak dua kali oleh kontainer dan anak-anaknya).
 */
object AksesTahfiz {
    private fun dp(context: Context, nilai: Int): Int = Math.round(nilai * context.resources.displayMetrics.density)

    /** Tandai tampilan sebagai judul bagian agar pembaca layar dapat melompat antarjudul (Android 9+). */
    fun tandaiJudul(v: View) {
        if (Build.VERSION.SDK_INT >= 28) v.setAccessibilityHeading(true)
    }

    /**
     * Jadikan kontainer satu simpul bacaan: kontainer difokuskan sekali dan membacakan [deskripsi];
     * anak-anaknya disembunyikan dari pembaca layar agar judul dan isi tidak terbaca dua kali.
     */
    fun satuBacaan(kontainer: ViewGroup, deskripsi: String, judul: Boolean) {
        for (i in 0 until kontainer.childCount) kontainer.getChildAt(i).importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        kontainer.contentDescription = deskripsi
        kontainer.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        if (Build.VERSION.SDK_INT >= 28) kontainer.setScreenReaderFocusable(true) else kontainer.isFocusable = true
        if (judul) tandaiJudul(kontainer)
    }

    /** Umumkan kontainer sebagai daftar dengan [jumlah] butir (TalkBack menyebut "daftar, N butir"). */
    fun tandaiDaftar(kontainer: ViewGroup, jumlah: Int) {
        kontainer.setAccessibilityDelegate(object : View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info?.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(jumlah, 1, false))
            }
        })
    }

    /**
     * Tombol aksi dua baris (judul tebal + uraian). Nama tombol bagi pembaca layar hanyalah [judul];
     * [uraian] dibacakan sebagai petunjuk setelah nama dan peran, dan posisi "butir ke-N dari M" ikut diumumkan.
     * Tinggi minimum 56 dp agar mudah disentuh; ukuran teks mengikuti pengaturan ukuran font sistem.
     */
    fun tombolAksi(context: Context, judul: String, uraian: String, urutan: Int, jumlah: Int): Button {
        val teks = SpannableStringBuilder(judul)
        teks.setSpan(StyleSpan(Typeface.BOLD), 0, judul.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        teks.append("\n")
        val awal = teks.length
        teks.append(uraian)
        teks.setSpan(RelativeSizeSpan(0.9f), awal, teks.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tombol = Button(context)
        tombol.text = teks
        tombol.textSize = 16f
        tombol.isAllCaps = false
        tombol.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        tombol.minimumHeight = dp(context, 56)
        tombol.minHeight = dp(context, 56)
        tombol.contentDescription = judul
        tombol.setAccessibilityDelegate(object : View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View?, info: AccessibilityNodeInfo?) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                if (info == null) return
                if (Build.VERSION.SDK_INT >= 26) info.setHintText(uraian) else info.setContentDescription(judul + ". " + uraian)
                info.setCollectionItemInfo(AccessibilityNodeInfo.CollectionItemInfo.obtain(urutan - 1, 1, 0, 1, false))
            }
        })
        return tombol
    }
}
