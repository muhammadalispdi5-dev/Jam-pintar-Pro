#!/usr/bin/env python3
"""Audit akhir statis Jam Pintar Pro untuk tahap 30; bukan pengganti build/perangkat."""
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(condition, message):
    if not condition:
        errors.append(message)

# Jalankan pemeriksaan struktur/version/manifest yang sudah ada.
result = subprocess.run([sys.executable, str(ROOT / "tools/verify_project.py")],
                        cwd=ROOT, capture_output=True, text=True)
print(result.stdout, end="")
if result.returncode != 0:
    print(result.stderr, end="")
    errors.append("Pemeriksaan proyek dasar gagal")

build = (ROOT / ".github/workflows/build.yml").read_text(encoding="utf-8")
release = (ROOT / ".github/workflows/rilis.yml").read_text(encoding="utf-8")
require("secrets.KEYSTORE_BASE64" in build and "KEYSTORE_PATH=$KS" in build,
        "Workflow build tidak mengonfigurasi keystore dari secret dengan benar")
require("kunci debug sementara" in build,
        "Workflow build harus memberi peringatan bila hanya menghasilkan APK uji")
require("secrets.KEYSTORE_BASE64" in release and "exit 1" in release and "Rilis publik dibatalkan" in release,
        "Workflow rilis harus berhenti jika keystore tetap belum dikonfigurasi")
require("bateraibicara\"" not in build and "bateraibicara\"" not in release,
        "Ditemukan kredensial keystore tetap yang tertanam dalam workflow")
require("KEYSTORE_BASE64" in release and "KEYSTORE_PASSWORD" in release and "KEY_ALIAS" in release,
        "Workflow rilis tidak memeriksa secret tanda tangan wajib")

if errors:
    print("AUDIT AKHIR TAHAP 30: GAGAL")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("AUDIT AKHIR TAHAP 30: LULUS")
print("- APK uji dapat dibangun tanpa menganggap kunci sementara sebagai kunci rilis")
print("- Workflow rilis menolak penerbitan tanpa keystore tetap dari GitHub Secrets")
print("- Tidak ditemukan kata sandi keystore tetap yang tertanam di workflow")
print("- Pemeriksaan ini bersifat statis; kompilasi Android dan uji perangkat tetap diperlukan")
