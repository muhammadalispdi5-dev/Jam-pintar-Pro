# Perbaikan Find Nearby Public Facilities dan Events and Meetings Mode

Versi aplikasi dipertahankan pada 1.0.68.

## Perubahan
- Layar fasilitas terdekat kini menampilkan label Indonesia atau Inggris secara utuh mengikuti bahasa tampilan yang dipilih.
- Istilah pencarian Google Maps juga mengikuti bahasa tampilan: Indonesia untuk bahasa Indonesia dan Inggris untuk bahasa Inggris.
- Kategori fasilitas yang diperiksa meliputi masjid/musala, rumah sakit, puskesmas/klinik, apotek, ATM, bank, toilet umum, kantor polisi, pemadam kebakaran, SPBU, halte/stasiun, pasar/minimarket.
- Mode Acara memiliki padanan Inggris untuk petunjuk, cakupan, durasi, izin Jangan Ganggu, tombol, pesan hasil, dan catatan.
- Status Mode Acara yang dirangkai secara dinamis sekarang dibuat eksplisit dalam bahasa terpilih; status tidak lagi mengandalkan terjemahan potongan kalimat.
- ModeAcaraActivity.kt ditulis ulang dengan string Kotlin yang bersih untuk mengatasi kesalahan sintaks kompilasi yang dilaporkan pada Run ID 40406856260.

## Pemeriksaan
- Sumber XML diperiksa dengan parser XML.
- Arsip ZIP diuji dengan `unzip -t`.
- Kompilasi Gradle penuh tidak dapat dinyatakan berhasil di lingkungan ini karena Gradle/Android SDK build runner tidak tersedia. Jalankan GitHub Actions untuk konfirmasi kompilasi final.
