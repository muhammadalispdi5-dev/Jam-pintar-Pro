package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri

/** Accessible nearby-facility search using the user's installed map app. */
class FasilitasTerdekatActivity : Halaman() {
    override val judulHalaman = R.string.kategori_fasilitas_terdekat

    override fun bangun() {
        info("Pilih jenis fasilitas yang ingin dicari. Pencarian dibuka di Google Maps atau aplikasi peta yang tersedia. Internet dan izin lokasi pada aplikasi peta mungkin diperlukan agar hasil dan jarak terdekat akurat. Jam Pintar Pro tidak menyimpan lokasi Anda.")
        val english = BahasaAplikasi.tampilan(this) == 1
        data class Facility(val idLabel: String, val enLabel: String, val idQuery: String, val enQuery: String)
        val facilities = listOf(
            Facility("Masjid dan musala", "Mosques and prayer rooms", "masjid dan musala terdekat", "mosques and prayer rooms near me"),
            Facility("Rumah sakit", "Hospitals", "rumah sakit terdekat", "hospitals near me"),
            Facility("Puskesmas dan klinik", "Community health centers and clinics", "puskesmas dan klinik terdekat", "community health centers and clinics near me"),
            Facility("Apotek", "Pharmacies", "apotek terdekat", "pharmacies near me"),
            Facility("ATM", "ATMs", "ATM terdekat", "ATMs near me"),
            Facility("Bank", "Banks", "bank terdekat", "banks near me"),
            Facility("Toilet umum", "Public restrooms", "toilet umum terdekat", "public restrooms near me"),
            Facility("Kantor polisi", "Police stations", "kantor polisi terdekat", "police stations near me"),
            Facility("Pemadam kebakaran", "Fire stations", "pemadam kebakaran terdekat", "fire stations near me"),
            Facility("SPBU", "Gas stations", "SPBU terdekat", "gas stations near me"),
            Facility("Halte dan stasiun", "Bus stops and train stations", "halte dan stasiun terdekat", "bus stops and train stations near me"),
            Facility("Pasar dan minimarket", "Markets and convenience stores", "pasar dan minimarket terdekat", "markets and convenience stores near me")
        )
        facilities.forEach { facility ->
            tombol(if (english) facility.enLabel else facility.idLabel) {
                cari(if (english) facility.enQuery else facility.idQuery)
            }
        }
    }

    private fun cari(query: String) {
        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            toast("Aplikasi peta tidak dapat dibuka.")
        }
    }
}
