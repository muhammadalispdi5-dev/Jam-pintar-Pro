package com.novan.bateraibicara

import java.time.LocalDate
import java.time.ZoneId
import java.util.Calendar

/**
 * Info waktu sholat berikutnya (beserta lokasi) yang dapat dibacakan sebagai satu rangkaian
 * dengan pembacaan waktu, seperti info libur. Mengikuti bahasa pengucapan jam yang aktif
 * (0 Indonesia, 1 English, 2 Arab, 3 Jawa krama, 4 Sunda halus) agar tidak bercampur bahasa.
 */
object InfoSholat {
    private val wajib = listOf("subuh", "dzuhur", "ashar", "maghrib", "isya")

    private fun waktuHari(pp: PrayerPrefs, p: Prefs, tanggal: LocalDate, key: String): Double {
        val t = PrayerCalc.calculate(tanggal, pp.lat, pp.lon, ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        val cadangan = when (key) {
            "subuh" -> t.fajr
            "dzuhur" -> t.dhuhr
            "ashar" -> t.asr
            "maghrib" -> t.maghrib
            else -> t.isha
        }
        val daring = if (pp.autoOnline) PrayerOnlineTimes.minutes(p.appContext, tanggal, key) else null
        return (daring?.toDouble() ?: PrayerCalc.minutes(cadangan).toDouble()) / 60.0
    }

    /**
     * Segmen info sholat berikutnya. [abaikanSakelar] dipakai tombol tes agar tetap terbaca
     * walaupun fitur belum diaktifkan. Kosong bila lokasi belum diatur atau perhitungan gagal.
     */
    fun segmen(p: Prefs, calendar: Calendar, abaikanSakelar: Boolean = false): List<String> {
        if (!abaikanSakelar && !p.jamInfoSholat) return emptyList()
        return try {
            val pp = PrayerPrefs(p.appContext)
            if (!pp.locationSet) return emptyList()
            val hari = LocalDate.of(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DAY_OF_MONTH))
            val sekarang = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
            var key: String? = null
            var jam = 0.0
            var besok = false
            for (k in wajib) {
                val j = waktuHari(pp, p, hari, k)
                if (PrayerCalc.minutes(j) > sekarang) { key = k; jam = j; break }
            }
            if (key == null) {
                key = "subuh"
                jam = waktuHari(pp, p, hari.plusDays(1), "subuh")
                besok = true
            }
            // Nama bawaan ("Lokasi GPS") tidak disebut; nama spesifik dicari di latar belakang.
            val lokasi = if (!p.jamInfoSholatLokasi) "" else NamaLokasi.nama(p.appContext, pp, p.jamBahasaIdx)
            // Sisa menit menuju waktu sholat yang disebut (sholat besok ditambah 24 jam).
            val sisa = PrayerCalc.minutes(jam) + (if (besok) 1440 else 0) - sekarang
            listOf(kalimat(key, jam, besok, lokasi, p.jamBahasaIdx, pp.use24, sisa))
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun kalimat(key: String, jam: Double, besok: Boolean, lokasi: String, bahasa: Int, use24: Boolean, sisa: Int): String {
        val nama = UcapanSholat.nama(key, bahasa)
        val waktu = waktuKata(jam, bahasa, use24)
        val lagi = sisaKata(sisa, bahasa)
        return when (bahasa) {
            1 -> "The next prayer is " + nama + (if (besok) " tomorrow" else "") + " at " + waktu +
                (if (lokasi.isNotEmpty()) " in " + lokasi else "") +
                (if (lagi.isNotEmpty()) ", which is " + lagi + " from now" else "")
            2 -> "الصلاة القادمة هي " + nama + (if (besok) " غدًا" else "") + " الساعة " + waktu +
                (if (lokasi.isNotEmpty()) " في " + lokasi else "") +
                (if (lagi.isNotEmpty()) "، أي بعد " + lagi else "")
            3 -> "Wekdal salat salajengipun inggih menika " + nama + (if (besok) " benjing" else "") + ", " + waktu +
                (if (lokasi.isNotEmpty()) ", ing " + lokasi else "") +
                (if (lagi.isNotEmpty()) ", kantun " + lagi else "")
            4 -> "Waktos salat salajengna nyaéta " + nama + (if (besok) " énjing" else "") + ", " + waktu +
                (if (lokasi.isNotEmpty()) ", kanggo wilayah " + lokasi else "") +
                (if (lagi.isNotEmpty()) ", waktosna kari " + lagi + " deui" else "")
            else -> "Waktu sholat berikutnya adalah " + nama + (if (besok) " besok" else "") + " pukul " + waktu +
                (if (lokasi.isNotEmpty()) ", untuk wilayah " + lokasi else "") +
                (if (lagi.isNotEmpty()) ", tinggal " + lagi + " lagi" else "")
        }
    }

    /**
     * Sisa waktu dalam kata sesuai bahasa: "dua puluh lima menit" atau "satu jam tiga puluh menit".
     * Kosong bila [sisa] tidak positif. Kata "lagi"/"from now"/"kantun" ditambahkan pemanggil.
     */
    private fun sisaKata(sisa: Int, bahasa: Int): String {
        if (sisa <= 0) return ""
        val h = sisa / 60
        val m = sisa % 60
        return when (bahasa) {
            1 -> {
                val a = if (h > 0) JamBahasa.kata(h, 1) + (if (h == 1) " hour" else " hours") else ""
                val b = if (m > 0) JamBahasa.kata(m, 1) + (if (m == 1) " minute" else " minutes") else ""
                listOf(a, b).filter { it.isNotEmpty() }.joinToString(" and ")
            }
            2 -> {
                val a = when {
                    h == 0 -> ""
                    h == 1 -> "ساعة واحدة"
                    h == 2 -> "ساعتين"
                    h in 3..10 -> JamBahasa.kata(h, 2) + " ساعات"
                    else -> JamBahasa.kata(h, 2) + " ساعة"
                }
                val b = when {
                    m == 0 -> ""
                    m == 1 -> "دقيقة واحدة"
                    m == 2 -> "دقيقتين"
                    m in 3..10 -> JamBahasa.kata(m, 2) + " دقائق"
                    else -> JamBahasa.kata(m, 2) + " دقيقة"
                }
                listOf(a, b).filter { it.isNotEmpty() }.joinToString(" و")
            }
            3 -> {
                val a = if (h > 0) JamBahasa.jawaKata(h) + " jam" else ""
                val b = if (m > 0) JamBahasa.jawaKata(m) + " menit" else ""
                listOf(a, b).filter { it.isNotEmpty() }.joinToString(" ")
            }
            4 -> {
                val a = if (h > 0) JamBahasa.sundaKata(h) + " jam" else ""
                val b = if (m > 0) JamBahasa.sundaKata(m) + " menit" else ""
                listOf(a, b).filter { it.isNotEmpty() }.joinToString(" " )
            }
            else -> {
                val a = if (h > 0) JamBahasa.kata(h, 0) + " jam" else ""
                val b = if (m > 0) JamBahasa.kata(m, 0) + " menit" else ""
                listOf(a, b).filter { it.isNotEmpty() }.joinToString(" ")
            }
        }
    }

    /** Waktu dibaca dengan kata agar mesin suara tidak membaca "15.10" sebagai pecahan. */
    private fun waktuKata(jam: Double, bahasa: Int, use24: Boolean): String {
        if (bahasa == 3 || bahasa == 4) return UcapanSholat.waktu(jam, bahasa, use24)
        val total = PrayerCalc.minutes(jam)
        val h = (total / 60) % 24
        val m = total % 60
        val jamSebut = if (use24) h else (if (h % 12 == 0) 12 else h % 12)
        return when (bahasa) {
            1 -> JamBahasa.kata(jamSebut, 1) +
                (if (m == 0) " o'clock" else (if (m < 10) " oh " else " ") + JamBahasa.kata(m, 1)) +
                (if (use24) "" else if (h < 12) " AM" else " PM")
            2 -> JamBahasa.kata(jamSebut, 2) + (if (m == 0) "" else " و" + JamBahasa.kata(m, 2) + " دقيقة")
            4 -> "tabuh " + JamBahasa.sundaKata(jamSebut) + (if (m == 0) " pas" else " langkung " + JamBahasa.sundaKata(m) + " menit")
            else -> JamBahasa.kata(jamSebut, 0) +
                (if (m == 0) " tepat" else " lewat " + JamBahasa.kata(m, 0) + " menit") +
                (if (use24) "" else " " + when (h) {
                    in 0..3 -> "dini hari"
                    in 4..9 -> "pagi"
                    in 10..14 -> "siang"
                    in 15..17 -> "sore"
                    18 -> "petang"
                    else -> "malam"
                })
        }
    }
}
