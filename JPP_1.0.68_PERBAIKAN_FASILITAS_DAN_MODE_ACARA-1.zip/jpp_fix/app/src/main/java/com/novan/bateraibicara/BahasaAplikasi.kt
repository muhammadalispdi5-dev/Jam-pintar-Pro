package com.novan.bateraibicara

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Bahasa tampilan utama dan penerjemahan label buatan kode agar konsisten. */
object BahasaAplikasi {
    fun tampilan(context: Context): Int = context.applicationContext
        .getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        .getInt("bahasa_tampilan", 0).coerceIn(0, 1)

    fun simpanTampilan(context: Context, index: Int) {
        context.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
            .edit().putInt("bahasa_tampilan", index.coerceIn(0, 1)).apply()
    }

    fun bungkus(context: Context): Context {
        val locale = if (tampilan(context) == 1) Locale.ENGLISH else Locale("id", "ID")
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return context.createConfigurationContext(config)
    }

    fun teks(context: Context, source: String): String {
        if (tampilan(context) == 0 || source.isBlank()) return source
        val normalized = source.trim()
        val trailingWhitespace = source.takeLastWhile { it.isWhitespace() }
        val exact = map[normalized]
        if (exact != null) return exact + trailingWhitespace
        // Also translate hard-coded labels that exactly match a string resource. This keeps
        // programmatically-built screens aligned with values-en without duplicating the map.
        resourceTranslation(context, normalized)?.let { return it }
        // Terjemahkan awalan label dan istilah yang lazim, sambil mempertahankan nama pengguna,
        // waktu, angka, nama lokasi, serta nilai dinamis yang tidak boleh diubah.
        val prefixes = listOf(
            "Jadwal berikutnya:" to "Next schedule:", "Jam mulai:" to "Start time:",
            "Jam selesai:" to "End time:", "Hari aktif:" to "Active days:",
            "Nama lokasi:" to "Location name:", "Lokasi:" to "Location:",
            "Uji susunan pesan untuk " to "Test announcement phrase for ",
            "Status izin" to "Permission status", "Perkiraan ketelitian" to "Estimated accuracy",
            "Waktu sholat" to "Prayer time", "Waktu salat" to "Prayer time",
            "Tanggal Masehi" to "Gregorian date", "Tanggal Hijriyah" to "Hijri date",
            "Berikutnya" to "Next", "Aktif" to "Enabled", "Tidak aktif" to "Disabled"
        )
        for ((id, en) in prefixes) if (source.startsWith(id)) return en + source.removePrefix(id)
        // Last-resort phrase glossary for dynamic status/help text that is assembled in code
        // instead of using a string resource. Apply longer phrases first to avoid partial matches.
        val phrasePairs = listOf(
            "lokasi anda telah ditemukan" to "Your location has been found",
            "sumber posisi: gps satelit" to "Position source: GPS satellites",
            "sumber posisi: gps" to "Position source: GPS",
            "status rinci satelit tidak tersedia pada saat pemeriksaan" to "detailed satellite status was unavailable at the time of the check",
            "jaringan wi-fi atau seluler, bukan bukti bahwa posisi ini dihitung dari satelit gps" to "Wi-Fi or cellular network; this does not mean the position was calculated from GPS satellites",
            "penyedia lokasi android" to "Android location provider",
            "sumber ini tidak dapat dipastikan sebagai posisi satelit gps" to "this source cannot be confirmed as a GPS satellite position",
            "alamat atau wilayah yang terdeteksi" to "Detected address or area",
            "nama jalan dan wilayah belum berhasil didapatkan dari layanan alamat" to "Street and area names could not be retrieved from the address service",
            "perkiraan ketelitian posisi sekitar" to "Estimated position accuracy is about",
            "ketelitian posisi sangat baik" to "Position accuracy is excellent",
            "ketelitian posisi baik" to "Position accuracy is good",
            "ketelitian posisi sedang" to "Position accuracy is moderate",
            "posisi masih kurang teliti" to "Position accuracy is low",
            "angka ini adalah perkiraan radius kesalahan, bukan jarak pasti" to "This is an estimated error radius, not an exact distance",
            "coba lagi di luar ruangan" to "Try again outdoors",
            "jumlah satelit gps yang terdeteksi sebanyak" to "Number of detected GPS satellites",
            "satelit sedang digunakan untuk menentukan posisi" to "satellites are being used to determine the position",
            "data satelit sudah tersedia" to "Satellite data is available",
            "aplikasi sedang menunggu posisi yang stabil" to "the app is waiting for a stable position",
            "belum ada satelit yang digunakan untuk menentukan posisi" to "No satellites are being used to determine the position",
            "cobalah berada di luar ruangan dengan pandangan langit terbuka" to "Try moving outdoors with a clear view of the sky",
            "informasi status satelit gps belum tersedia dari perangkat" to "GPS satellite status information is not available from the device",
            "nada pendek berulang menandakan pencarian masih aktif" to "repeated short tones indicate that the search is still active",
            "belum diizinkan" to "not granted", "sudah diizinkan" to "granted",
            "mohon tunggu" to "please wait", "silakan coba lagi" to "please try again",
            "periksa sambungan internet" to "check your internet connection",
            "pastikan internet aktif" to "make sure the internet is available",
            "tidak ditemukan" to "not found", "belum ditemukan" to "not found yet",
            "gagal memeriksa" to "failed to check", "gagal mengunduh" to "failed to download",
            "berhasil diperbarui" to "updated successfully", "berhasil disimpan" to "saved successfully",
            "sedang mencari" to "Searching for", "pencarian lokasi" to "Location search",
            "lokasi belum diatur" to "Location has not been set", "lokasi tersimpan" to "Saved location",
            "nama lokasi" to "Location name", "jadwal sholat" to "Prayer schedule",
            "waktu sholat" to "Prayer time", "waktu salat" to "Prayer time",
            "tanggal masehi" to "Gregorian date", "tanggal hijriah" to "Hijri date",
            "kalender hijriah" to "Hijri calendar", "kalender masehi" to "Gregorian calendar",
            "pasaran jawa" to "Javanese pasaran", "hari libur nasional" to "National holidays",
            "cuti bersama" to "collective leave", "baterai lemah" to "Low battery",
            "baterai kritis" to "Critical battery", "baterai penuh" to "Battery full",
            "pengisi daya" to "charger", "kabel usb" to "USB cable",
            "nama pemanggil" to "caller name", "panggilan masuk" to "incoming call",
            "panggilan keluar" to "outgoing call", "panggilan suara" to "voice call",
            "panggilan video" to "video call", "izin notifikasi" to "notification permission",
            "akses notifikasi" to "notification access", "izin alarm tepat waktu" to "exact-alarm permission",
            "pengaturan perangkat" to "device settings", "buka pengaturan" to "Open settings",
            "atur sekarang" to "Set up now", "kembali" to "Back", "simpan" to "Save",
            "batal" to "Cancel", "lanjutkan" to "Continue", "aktifkan" to "Enable",
            "dinonaktifkan" to "disabled", "diaktifkan" to "enabled", "nonaktif" to "disabled",
            "aktif" to "enabled", "otomatis" to "automatic", "manual" to "manual",
            "jumlah satelit" to "number of satellites", "akurasi" to "accuracy",
            "ketelitian" to "accuracy", "sedang mengisi" to "charging", "tidak mengisi" to "not charging",
            "perbarui" to "Update", "pembaruan" to "update", "pengaturan" to "settings",
            "berkas" to "file", "berhasil" to "successfully", "gagal" to "failed",
            "peringatan" to "Warning", "pilih" to "Select", "pilihan" to "option",
            "suara" to "speech", "ucapan" to "announcement", "pengucapan" to "speech",
            "layar mati" to "screen off", "berjalan di latar belakang" to "running in the background",
            "aplikasi ini" to "this app", "perangkat ini" to "this device", "nama pengembang" to "developer name"
        )
        var translated = source
        for ((id, en) in phrasePairs.sortedByDescending { it.first.length }) {
            translated = translated.replace(Regex(Regex.escape(id), RegexOption.IGNORE_CASE)) { match ->
                val original = match.value
                when {
                    original.all { !it.isLetter() || it.isUpperCase() } -> en.uppercase(Locale.ENGLISH)
                    original.firstOrNull()?.isUpperCase() == true -> en.replaceFirstChar { it.uppercase(Locale.ENGLISH) }
                    else -> en
                }
            }
        }
        return translated
    }

    private fun resourceTranslation(context: Context, source: String): String? {
        return try {
            val idConfig = Configuration(context.resources.configuration).apply {
                setLocale(Locale("id", "ID"))
            }
            val enConfig = Configuration(context.resources.configuration).apply {
                setLocale(Locale.ENGLISH)
            }
            val idResources = context.applicationContext.createConfigurationContext(idConfig).resources
            val enResources = context.applicationContext.createConfigurationContext(enConfig).resources
            val packageName = context.packageName
            if (idResources.getIdentifier("app_name", "string", packageName) == 0) return null
            // Android resource IDs are sparse, so enumerate known string names from the app's R class.
            val names = R.string::class.java.fields
            for (field in names) {
                val resId = field.getInt(null)
                val idText = runCatching { idResources.getString(resId) }.getOrNull() ?: continue
                if (idText != source) continue
                val enText = runCatching { enResources.getString(resId) }.getOrNull() ?: continue
                if (enText.isNotBlank() && enText != idText) return enText
            }
            null
        } catch (_: Exception) { null }
    }

    private val map = mapOf(
        "Lokasi disimpan dengan nama" to "Location saved as",
        "Pada instalasi baru, pembaruan online aktif agar jadwal mengikuti koordinat dan metode perhitungan yang dipilih. Koordinat dikirim ke layanan AlAdhan hanya untuk mengambil jadwal salat. Jika internet tidak tersedia atau layanan gagal, aplikasi memakai perhitungan lokal. Anda dapat menonaktifkan opsi ini kapan saja." to "On a new installation, online updates are enabled so the schedule follows the selected coordinates and calculation method. Coordinates are sent to the AlAdhan service only to retrieve prayer times. If the internet is unavailable or the service fails, the app uses local calculations. You can turn this option off at any time.",
        "Jadwal sholat tanggal" to "Prayer schedule for",
        "Pengingat" to "Reminders", "Metode perhitungan" to "Calculation method",
        "Ketelitian saat disimpan sekitar" to "Accuracy when saved was about",
        "Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka." to "The location could not be found. Make sure location permission and location services are enabled, then try again in a more open area.",
        "Izin lokasi belum diberikan." to "Location permission has not been granted.",
        "Izin lokasi ditolak. Fitur lokasi terkini memerlukan izin lokasi saat digunakan." to "Location permission was denied. The current-location feature requires location access while the app is in use.",
        "Koordinat ditemukan. Sedang mencari nama tempat; jika layanan nama tempat tidak tersedia, koordinat tetap dapat dibacakan." to "Coordinates found. Looking up the place name; if the place-name service is unavailable, the coordinates can still be announced.",
        "Layanan lokasi sedang mati." to "Location services are turned off.",
        "Lokasi tersimpan dengan nama" to "Location saved as",
        "Lokasi jadwal sholat diperbarui menggunakan GPS. Perkiraan ketelitian" to "Prayer schedule location updated using GPS. Estimated accuracy",
        "Perkiraan ketelitian posisi terbaik saat ini sekitar" to "The best current position accuracy is approximately",
        "Posisi terkini dari perangkat belum diterima." to "The current position has not yet been received from the device.",
        "Pencarian lokasi jadwal sholat masih berlangsung. Nada pendek berulang menandakan pencarian masih aktif." to "Prayer-schedule location search is still in progress. Repeated short tones indicate that the search is active.",
        "Jadwal sholat tanggal" to "Prayer schedule for",
        "Lokasi:" to "Location:",
        "Metode perhitungan:" to "Calculation method:",
        "Pengingat:" to "Reminders:",
        "aktif" to "Enabled", "nonaktif" to "Disabled",
        "Kemenag RI (Subuh 20°, Isya 18°)" to "Indonesian Ministry of Religious Affairs (Fajr 20°, Isha 18°)",
        "Muslim World League (18°/17°)" to "Muslim World League (18°/17°)",
        "ISNA (15°/15°)" to "ISNA (15°/15°)",
        "Mesir (19,5°/17,5°)" to "Egypt (19.5°/17.5°)",
        "Singapura (20°/18°)" to "Singapore (20°/18°)",
        "Umm Al-Qura (Isya 90 menit setelah Maghrib)" to "Umm Al-Qura (Isha 90 minutes after Maghrib)",
        "Imsak:" to "Imsak:", "Subuh:" to "Fajr:", "Terbit:" to "Sunrise:",
        "Dhuha:" to "Duha:", "Tahajud (perkiraan):" to "Tahajjud (estimated):",
        "Dzuhur:" to "Dhuhr:", "Ashar:" to "Asr:", "Maghrib:" to "Maghrib:", "Isya:" to "Isha:",
        "Imsak" to "Imsak", "Subuh" to "Fajr", "Terbit" to "Sunrise", "Dhuha" to "Duha",
        "Tahajud" to "Tahajjud", "Dzuhur" to "Dhuhr", "Ashar" to "Asr", "Maghrib" to "Maghrib ", "Isya" to "Isha",
        "Metode:" to "Method:", "Perbarui lokasi terkini" to "Update Current Location",
        "Lokasi terkini" to "Current Location", "lokasi yang diatur secara manual" to "manually set location",
        "belum diketahui" to "unknown", "Jadwal sholat" to "Prayer Schedule", "Jadwal salat" to "Prayer Schedule",
        "Kemenag RI" to "Indonesian Ministry of Religious Affairs",
        "Jadwal dihitung di HP sebagai cadangan. Jika opsi pembaruan otomatis melalui internet diaktifkan di Pengaturan Jadwal Sholat, aplikasi mengunduh jadwal berdasarkan koordinat untuk memperbarui waktu. Koordinat lokasi akan dikirim ke layanan jadwal tersebut hanya untuk meminta waktu salat." to "Prayer times are calculated on this phone as a backup. If automatic updates over the internet are enabled in Prayer Schedule Settings, the app downloads a schedule based on your coordinates. Your location coordinates are sent to that schedule service only to request prayer times.",
        "Gunakan tombol Perbarui lokasi terkini untuk mengetahui tempat Anda berada. Jam Pintar Pro akan mencoba membaca nama jalan, kawasan, kelurahan atau desa, kota, dan provinsi bila layanan nama tempat tersedia. Perkiraan ketelitian posisi akan dijelaskan dengan kalimat biasa. Angka koordinat tidak dibacakan dalam ringkasan agar informasi lokasi lebih mudah dipahami. Lokasi tidak dikirim ke pengembang." to "Use the Update Current Location button to identify your location. Jam Pintar Pro will try to read the street, area, village or urban village, city, and province when place-name services are available. The estimated position accuracy is explained in plain language. Coordinates are not spoken in the summary to make location information easier to understand. Your location is not sent to the developer.",
        "Lokasi belum diminta. Tekan Perbarui lokasi terkini." to "Location has not been requested yet. Select Update Current Location.",
        "Lokasi belum tersedia. Tekan Perbarui lokasi terkini terlebih dahulu." to "Location is not available yet. Select Update Current Location first.",
        "Jadwal sholat hari ini." to "Today's prayer schedule.",
        "Pembacaan pesan dan notifikasi masuk" to "Incoming Messages and Notifications",
        "Melodi sebelum dan sesudah pengumuman" to "Tones Before and After Announcements",
        // Caller Name screen: labels are built in Kotlin rather than XML resources.
        "Izin dan akses notifikasi" to "Permissions and Notification Access",
        "Jenis panggilan dan pengulangan" to "Call Types and Repetition",
        "Pembacaan pesan dan notifikasi masuk" to "Incoming Messages and Notifications",
        "Melodi sebelum dan sesudah pengumuman" to "Tones Before and After Announcements",
        "Suara pengumuman" to "Announcement Voice",
        "Atur pesan sebelum dan sesudah nama untuk tiap jenis panggilan. Pola yang berbeda membantu mengenali panggilan telepon biasa, WhatsApp Messenger, WhatsApp Business, serta panggilan video. Kolom boleh dikosongkan untuk memakai kalimat standar." to "Set the phrases spoken before and after the caller's name for each call type. Different phrases help distinguish regular phone calls, WhatsApp Messenger, WhatsApp Business, and video calls. Leave a field empty to use the default phrase.",
        "Pembacaan pesan dan notifikasi masuk" to "Incoming Messages and Notifications",
        "Aktifkan jenis notifikasi yang ingin dibacakan. Anda dapat mengatur pesan yang diucapkan sebelum dan sesudah nama pengirim untuk setiap jenis pesan. Untuk pesan suara WhatsApp, aplikasi membacakan pemberitahuannya dan nama pengirim jika tersedia; isi audio pesan suara tidak diubah menjadi teks." to "Enable the notifications you want read aloud. You can set phrases to be spoken before and after the sender's name for each message type. For WhatsApp voice messages, the app announces the notification and sender's name when available; the voice-message audio itself is not transcribed into text.",
        "Pesan seluler atau SMS" to "Text Messages (SMS)",
        "Cara membaca SMS" to "SMS reading mode",
        "Bacakan pemberitahuan dan isi pesan" to "Read the notification and message content",
        "Bacakan pemberitahuan saja" to "Read the notification only",
        "Bacakan notifikasi pesan seluler atau SMS" to "Read text-message (SMS) notifications",
        "Pesan sebelum dan sesudah nama pengirim SMS" to "Phrase before and after the SMS sender's name",
        "Contoh isi pesan" to "Example message content",
        "WhatsApp Messenger" to "WhatsApp Messenger",
        "Cara membaca WhatsApp Messenger" to "WhatsApp Messenger reading mode",
        "Bacakan chat teks pribadi WhatsApp Messenger" to "Read personal WhatsApp Messenger text chats",
        "Pesan sebelum dan sesudah nama pengirim chat pribadi WhatsApp Messenger" to "Phrase before and after the sender's name in personal WhatsApp Messenger chats",
        "Bacakan chat teks grup WhatsApp Messenger" to "Read WhatsApp Messenger group text chats",
        "Pesan sebelum dan sesudah nama pengirim chat grup WhatsApp Messenger" to "Phrase before and after the sender's name in WhatsApp Messenger group chats",
        "Contoh isi pesan dari grup Keluarga" to "Example message from the Family group",
        "Bacakan pemberitahuan pesan suara pribadi WhatsApp Messenger" to "Read personal WhatsApp Messenger voice-message notifications",
        "Pesan sebelum dan sesudah nama pengirim pesan suara pribadi WhatsApp Messenger" to "Phrase before and after the sender's name in personal WhatsApp Messenger voice messages",
        "Bacakan pemberitahuan pesan suara grup WhatsApp Messenger" to "Read WhatsApp Messenger group voice-message notifications",
        "Pesan sebelum dan sesudah nama pengirim pesan suara grup WhatsApp Messenger" to "Phrase before and after the sender's name in WhatsApp Messenger group voice messages",
        "WhatsApp Business" to "WhatsApp Business",
        "Cara membaca WhatsApp Business" to "WhatsApp Business reading mode",
        "Bacakan chat teks pribadi WhatsApp Business" to "Read personal WhatsApp Business text chats",
        "Pesan sebelum dan sesudah nama pengirim chat pribadi WhatsApp Business" to "Phrase before and after the sender's name in personal WhatsApp Business chats",
        "Bacakan chat teks grup WhatsApp Business" to "Read WhatsApp Business group text chats",
        "Pesan sebelum dan sesudah nama pengirim chat grup WhatsApp Business" to "Phrase before and after the sender's name in WhatsApp Business group chats",
        "Bacakan pemberitahuan pesan suara pribadi WhatsApp Business" to "Read personal WhatsApp Business voice-message notifications",
        "Pesan sebelum dan sesudah nama pengirim pesan suara pribadi WhatsApp Business" to "Phrase before and after the sender's name in personal WhatsApp Business voice messages",
        "Bacakan pemberitahuan pesan suara grup WhatsApp Business" to "Read WhatsApp Business group voice-message notifications",
        "Pesan sebelum dan sesudah nama pengirim pesan suara grup WhatsApp Business" to "Phrase before and after the sender's name in WhatsApp Business group voice messages",
        "Pengaturan pengulangan notifikasi pesan" to "Message Notification Repetition Settings",
        "Atur sendiri berapa kali notifikasi SMS, chat pribadi/grup WhatsApp Messenger, WhatsApp Business, dan pesan suara dibacakan. Pilih Tidak aktif untuk menonaktifkan pembacaan notifikasi dari bagian ini. Pengulangan panggilan masuk diatur terpisah. Pembaruan sistem atas notifikasi yang sama tidak akan dianggap sebagai pesan baru hanya karena teks notifikasinya berubah." to "Choose how many times SMS, personal or group WhatsApp Messenger chats, WhatsApp Business messages, and voice-message notifications are read aloud. Select Disabled to turn off repetition for these notifications. Incoming-call repetition is configured separately. System updates to an existing notification will not be treated as a new message merely because its text changes.",
        "Jumlah pembacaan setiap notifikasi" to "Number of readings per notification",
        "Tidak aktif" to "Disabled",
        "Jeda antar pembacaan notifikasi dalam detik" to "Delay between notification readings (seconds)",
        "Tes nada singkat" to "Test short tone",
        "Atur pesan sebelum dan sesudah nama untuk tiap jenis panggilan." to "Set the phrases spoken before and after the caller's name for each call type.",
        "Panggilan telepon seluler" to "Mobile phone call",
        "Panggilan suara WhatsApp Messenger" to "WhatsApp Messenger voice call",
        "Panggilan video WhatsApp Messenger" to "WhatsApp Messenger video call",
        "Panggilan suara WhatsApp Business" to "WhatsApp Business voice call",
        "Panggilan video WhatsApp Business" to "WhatsApp Business video call",
        "Tuliskan kalimat yang ingin diucapkan sebelum atau sesudah nama pengirim atau pemanggil. Kedua kolom boleh dikosongkan. Jika kedua kolom kosong, aplikasi akan menggunakan kalimat pemberitahuan standar." to "Enter the phrase to be spoken before or after the sender's or caller's name. Both fields may be left empty. If both fields are empty, the app will use the default announcement phrase.",
        "Kalimat sebelum nama" to "Phrase before the name",
        "Kalimat sesudah nama" to "Phrase after the name",
        "Uji susunan pesan untuk " to "Test announcement phrase for ",
        "Tes nada singkat" to "Test short tone",
        "Izin dan akses notifikasi" to "Permissions and Notification Access",
        "Atur sendiri berapa kali notifikasi SMS, chat pribadi/grup WhatsApp Messenger, WhatsApp Business, dan pesan suara dibacakan. Pilih Tidak aktif untuk menonaktifkan pembacaan notifikasi dari bagian ini. Pengulangan panggilan masuk diatur terpisah. Pembaruan sistem atas notifikasi yang sama tidak akan dianggap sebagai pesan baru hanya karena teks notifikasinya berubah." to "Choose how many times SMS, personal or group WhatsApp Messenger chats, WhatsApp Business messages, and voice-message notifications are read aloud. Select Disabled to turn off repetition for these notifications. Incoming-call repetition is configured separately. System updates to an existing notification will not be treated as a new message merely because its text changes.",
        "Satu Sahabat Suara untuk Waktu, Ibadah, dan Aktivitas Sehari-hari. Dirancang dengan perhatian khusus pada kemudahan penggunaan bagi pengguna tunanetra dan pembaca layar." to "One voice companion for time, worship, and everyday activities. Designed with special care for blind users and screen-reader accessibility.",
        "Pengaturan Bahasa" to "Language Settings", "Bahasa Tampilan Utama" to "Main Display Language",
        "Bahasa Pengucapan" to "Speech Language", "Bahasa Indonesia" to "Indonesian",
        "English" to "English", "Simpan dan terapkan bahasa" to "Save and apply language settings",
        "Bahasa tampilan mengubah bahasa antarmuka aplikasi. Bahasa pengucapan mengatur bahasa suara untuk fitur yang mendukungnya." to "The display language changes the app interface. The speech language sets the spoken language for supported features.",
        "Baterai" to "Battery", "Jam" to "Clock", "Kalender" to "Calendar", "Nama Pemanggil" to "Caller Name",
        "Jadwal Sholat" to "Prayer Schedule", "Arah Kiblat" to "Qibla Direction",
        "Ketahui lokasi terkini" to "Current Location", "Cari fasilitas umum terdekat" to "Find Nearby Public Facilities",
        "Mode Acara dan Pertemuan" to "Events and Meetings Mode", "Petunjuk penggunaan" to "User Guide",
        "Cadangkan pengaturan" to "Back Up Settings", "Pulihkan pengaturan" to "Restore Settings",
        "Reset semua pengaturan ke awal" to "Reset All Settings", "Pembaruan dan bantuan" to "Updates and Help",
        "Izin dan kompatibilitas perangkat" to "Device Permissions and Compatibility", "Buka info aplikasi" to "Open App Info",
        "Hubungi pengembang" to "Contact Developer", "Periksa pembaruan" to "Check for Updates",
        "Aktifkan" to "Enable", "Aktif" to "Enabled", "Mati" to "Off", "Status aktif" to "Enabled",
        "Status mati" to "Disabled", "Jadwal" to "Schedule", "Ucapan" to "Speech",
        "Yang disebutkan saat jam bicara" to "What the clock announces", "Ucapkan jam" to "Speak the hour",
        "Sebutkan menit" to "Speak the minutes", "Bacakan detik" to "Speak the seconds",
        "Format waktu" to "Time Format", "Setiap beberapa menit: selang waktu" to "Interval in minutes",
        "Bacakan info waktu sholat berikutnya sekarang" to "Announce the next prayer time now",
        "Atur lokasi jadwal sholat" to "Set prayer schedule location", "Perbarui nama lokasi (kelurahan, kota, provinsi)" to "Update location name (district, city, province)",
        "Nama lokasi yang Anda isi sendiri dipakai apa adanya:" to "Your manually entered location name is used as entered:",
        "Mencari nama lokasi, mohon tunggu." to "Looking up the location name. Please wait.",
        "Nama lokasi belum ditemukan. Pastikan internet aktif, atau isi nama lokasi secara manual di halaman Jadwal Sholat." to "Location name not found. Check your internet connection or enter the location manually on the Prayer Schedule page.",
        "Lokasi jadwal sholat belum diatur. Atur lokasi di halaman Jadwal Sholat." to "The prayer schedule location has not been set. Set it on the Prayer Schedule page.",
        "Mesin suara" to "Speech Engine", "Kecepatan" to "Speed", "Nada" to "Pitch", "Keluaran volume" to "Audio Output",
        "Tes" to "Test", "Tes pengucapan" to "Speech Test", "Pengaturan suara" to "Speech Settings",
        "Pengaturan jam" to "Clock Settings", "Pengaturan kalender" to "Calendar Settings",
        "Pilih hari aktif" to "Select active days", "Minggu" to "Sunday", "Senin" to "Monday",
        "Selasa" to "Tuesday", "Rabu" to "Wednesday", "Kamis" to "Thursday", "Jumat" to "Friday", "Sabtu" to "Saturday",
        "Lokasi GPS" to "GPS location", "Lokasi jaringan" to "Network location", "Lokasi perangkat" to "Device location",
        "Perkiraan ketelitian" to "Estimated accuracy", "meter" to "meters", "Tidak ditemukan" to "Not found",
        "Kembali" to "Back", "Batal" to "Cancel", "Ya" to "Yes", "Tidak" to "No", "Simpan" to "Save",
        "Mati / tanpa melodi" to "Off / no melody", "Pagi" to "Morning", "Siang" to "Afternoon", "Sore" to "Late afternoon", "Malam" to "Night",
        "Setiap 5 menit" to "Every 5 minutes", "Setiap 10 menit" to "Every 10 minutes", "Setiap 15 menit" to "Every 15 minutes", "Setiap 20 menit" to "Every 20 minutes", "Setiap 30 menit" to "Every 30 minutes", "Setiap 1 jam" to "Every hour",
        "Format 24 jam" to "24-hour format", "Format 12 jam" to "12-hour format", "Mati" to "Off", "Hidup" to "On", "Otomatis" to "Automatic", "Manual" to "Manual",
        "Gregorian" to "Gregorian", "Hijriah" to "Hijri", "Masehi" to "Gregorian", "Pasaran Jawa" to "Javanese pasaran",
        "Aktifkan jam bicara" to "Enable talking clock", "Bacakan tanggal Masehi" to "Announce Gregorian date", "Bacakan tanggal Hijriah" to "Announce Hijri date", "Bacakan pasaran Jawa" to "Announce Javanese pasaran",
        "Bacakan info libur nasional" to "Announce national holidays", "Bacakan info cuti bersama" to "Announce collective leave information",
        "Sebutkan lokasi pada info sholat berikutnya" to "Include the location in the next prayer announcement", "Bacakan info waktu sholat berikutnya bersama pembacaan waktu" to "Announce the next prayer time with the clock",
        "Izinkan alarm tepat waktu untuk pemulihan otomatis" to "Allow exact alarms for automatic recovery", "Pengaturan waktu" to "Time Settings", "Pengaturan suara" to "Speech Settings",
        "Buka halaman arah kiblat dan jarum kompas" to "Open the Qibla direction and compass needle page", "Panduan kompas saat layar mati" to "Compass guidance while the screen is off",
        "Lokasi tersimpan" to "Saved location", "Lokasi belum diatur" to "Location has not been set", "Mencari lokasi, mohon tunggu." to "Finding location. Please wait.",
        "Izin diperlukan" to "Permission required", "Buka pengaturan" to "Open settings", "Pengaturan perangkat" to "Device settings", "Tes pengucapan" to "Speech test"
,
        "Arah Kiblat" to "Qibla Direction", "Arah kiblat" to "Qibla direction", "Arah kiblat dan kompas" to "Qibla Direction and Compass",
        "Atur lokasi manual" to "Set Location Manually", "Atur lokasi pada Jadwal Sholat" to "Set Location in Prayer Schedule", "Atur lokasi terlebih dahulu." to "Set the location first.",
        "Bacakan jadwal sholat hari ini" to "Announce today's prayer schedule", "Bacakan jadwal tanggal terpilih" to "Announce the selected date's schedule", "Bacakan kembali lokasi terakhir" to "Read the last location again",
        "Bacakan notifikasi pesan seluler atau SMS" to "Read mobile text messages or SMS notifications", "Pesan seluler atau SMS" to "Mobile messages or SMS",
        "Bacakan chat teks pribadi WhatsApp Messenger" to "Read private WhatsApp Messenger text chats", "Bacakan chat teks grup WhatsApp Messenger" to "Read WhatsApp Messenger group text chats",
        "Bacakan chat teks pribadi WhatsApp Business" to "Read private WhatsApp Business text chats", "Bacakan chat teks grup WhatsApp Business" to "Read WhatsApp Business group text chats",
        "Bacakan pemberitahuan pesan suara pribadi WhatsApp Messenger" to "Read private WhatsApp Messenger voice-message notifications", "Bacakan pemberitahuan pesan suara grup WhatsApp Messenger" to "Read WhatsApp Messenger group voice-message notifications",
        "Bacakan pemberitahuan pesan suara pribadi WhatsApp Business" to "Read private WhatsApp Business voice-message notifications", "Bacakan pemberitahuan pesan suara grup WhatsApp Business" to "Read WhatsApp Business group voice-message notifications",
        "Pengingat sebelum salat lima waktu" to "Reminders before the five daily prayers", "Pengingat sebelum sholat" to "Pre-prayer reminder", "Pengingat setiap waktu sholat" to "Reminder for each prayer time",
        "Pengingat waktu Imsak" to "Imsak Reminder", "Pengingat waktu berbuka puasa" to "Iftar Reminder", "Pengingat waktu sahur" to "Suhoor Reminder", "Pengingat waktu sholat" to "Prayer Time Reminder",
        "Pengingat Waktu Sahur dan Berbuka" to "Suhoor and Iftar Reminders", "Pengaturan Jadwal Sholat dan Pengingat" to "Prayer Schedule and Reminder Settings", "Suara azan dan tes suara" to "Adhan Sound and Sound Test",
        "Suara pemberitahuan berbuka puasa" to "Iftar Notification Sound", "Suara pemberitahuan sahur" to "Suhoor Notification Sound", "Sumber suara pengingat dan azan" to "Reminder and Adhan Sound Source",
        "Pembaruan otomatis jadwal melalui internet" to "Automatic Schedule Updates via Internet", "Perbarui jadwal sholat otomatis melalui internet" to "Automatically Update Prayer Times via Internet", "Perbarui jadwal sekarang melalui internet" to "Update Schedule Now via Internet",
        "Perbarui lokasi (GPS)" to "Update Location (GPS)", "Perbarui lokasi terkini" to "Update Current Location", "Buka halaman lokasi" to "Open Location Page", "Buka lokasi terakhir di peta" to "Open Last Location on Map",
        "Kelola lokasi tersimpan" to "Manage Saved Locations", "Simpan lokasi dengan nama pilihan" to "Save Location with a Custom Name", "Lokasi dan perhitungan" to "Location and Calculation", "Jadwal dan lokasi" to "Schedule and Location", "Metode perhitungan" to "Calculation Method",
        "Perhitungan Ashar" to "Asr Calculation", "Jenis puasa yang sedang diikuti" to "Fasting Type", "Jenis suara berbuka puasa: " to "Iftar sound type: ", "Jenis suara sahur: " to "Suhoor sound type: ", "Jenis puasa: " to "Fasting type: ",
        "Waktu khusus Dhuha dan Tahajud" to "Custom Dhuha and Tahajud Times", "Gunakan waktu khusus Dhuha" to "Use Custom Dhuha Time", "Gunakan waktu khusus Tahajud" to "Use Custom Tahajud Time",
        "Pilih berapa lama mode berlangsung" to "Choose How Long the Mode Lasts", "Durasi Mode Acara" to "Event Mode Duration", "Durasi Mode Jangan Ganggu" to "Do Not Disturb Duration", "Apa yang terdampak selama acara?" to "What Is Affected During the Event?",
        "Aktifkan Mode Acara" to "Enable Event Mode", "Akhiri Mode Acara dan Pulihkan" to "End Event Mode and Restore Settings", "Mode Acara diakhiri." to "Event Mode ended.", "Mode Acara diaktifkan sesuai cakupan yang dipilih." to "Event Mode enabled according to the selected scope.",
        "Aktifkan Mode Jangan Ganggu otomatis saat waktu salat" to "Automatically Enable Do Not Disturb at Prayer Time", "Mode Jangan Ganggu otomatis saat salat" to "Automatic Do Not Disturb During Prayer", "Mode Jangan Ganggu saat sholat" to "Do Not Disturb During Prayer",
        "Izinkan aplikasi mengatur Mode Jangan Ganggu" to "Allow the App to Control Do Not Disturb", "Izin Mode Jangan Ganggu sudah diberikan" to "Do Not Disturb permission has been granted", "Buka pengaturan izin Jangan Ganggu" to "Open Do Not Disturb Permission Settings",
        "Hentikan azan dengan menelungkupkan HP" to "Stop the Adhan by Placing the Phone Face Down", "Cara cepat menghentikan suara azan" to "Quick Way to Stop the Adhan", "Hentikan tes suara azan" to "Stop Adhan Sound Test", "Tes suara azan Subuh" to "Fajr Adhan Sound Test",
        "Kontrol tes suara azan" to "Adhan Sound Test Controls", "Tes nada singkat" to "Short Tone Test", "Ucapan arah otomatis setiap 1,5 detik" to "Automatic Direction Announcement Every 1.5 Seconds", "Panduan kompas saat layar mati" to "Compass Guidance While Screen Is Off",
        "Jadwal 30 hari ke depan" to "Schedule for the Next 30 Days", "Pilih hari dan jadwal 30 hari" to "Select a Day and View the 30-Day Schedule", "Pilih tanggal" to "Select Date", "Pilih hari aktif" to "Select Active Days",
        "Tambah atau kurangi menit" to "Add or Subtract Minutes", "Berkas semua waktu dihapus" to "All time-specific files have been deleted", "Semua berkas azan pilihan dihapus" to "All selected adhan files have been deleted", "Sumber suara disimpan" to "Sound source saved", "Lokasi disimpan" to "Location saved",
        "Pemilih berkas tidak dapat dibuka pada perangkat ini." to "The file picker cannot be opened on this device.", "Aplikasi peta tidak dapat dibuka." to "The map app could not be opened.", "Aplikasi peta tidak tersedia." to "The map app is unavailable.", "Layanan lokasi sedang mati." to "Location services are turned off.",
        "Lokasi belum ditemukan. Silakan coba lagi." to "Location not found. Please try again.", "Lokasi belum tersedia. Perbarui lokasi terlebih dahulu." to "Location is unavailable. Update the location first.", "Belum ada lokasi untuk disimpan. Cari lokasi terlebih dahulu." to "There is no location to save yet. Find a location first.",
        "Izin lokasi diperlukan untuk mengetahui lokasi terkini." to "Location permission is required to find the current location.", "Izinkan akses lokasi untuk menggunakan fitur ini." to "Allow location access to use this feature.", "Setelan lokasi tidak dapat dibuka." to "Location settings could not be opened.",
        "Mode Acara belum dapat diaktifkan. Periksa izin Jangan Ganggu." to "Event Mode could not be enabled. Check Do Not Disturb permission.", "Mode Jangan Ganggu otomatis memerlukan Android 6.0 atau lebih baru" to "Automatic Do Not Disturb requires Android 6.0 or later",
        "Pada versi Android ini, izin alarm tepat waktu dikelola otomatis." to "On this Android version, exact-alarm permission is managed automatically.", "Periksa atau izinkan alarm tepat waktu" to "Check or Allow Exact Alarms", "Periksa izin perangkat" to "Check Device Permissions",
        "Pilih jenis fasilitas yang ingin dicari." to "Choose the type of facility to find.", "Info Jadwal Sholat" to "Prayer Schedule Information", "Tanggal Syawal belum dapat disiapkan pada kalender perangkat" to "The Shawwal dates could not be prepared using the device calendar",
        "Format waktu" to "Time Format", "Jenis volume azan / Keluaran suara" to "Adhan Volume Type / Audio Output", "Jumlah pembacaan setiap notifikasi" to "Number of Reads per Notification", "Pengaturan pengulangan notifikasi pesan" to "Message Notification Repeat Settings",
        "Bacakan info libur nasional" to "Announce National Holidays", "Bacakan info cuti bersama" to "Announce Collective Leave Information", "Bacakan tanggal Masehi" to "Announce Gregorian Date", "Bacakan tanggal Hijriah" to "Announce Hijri Date", "Bacakan pasaran Jawa" to "Announce Javanese Pasaran",
        "Bacakan info waktu sholat berikutnya bersama pembacaan waktu" to "Announce the Next Prayer Time Along with the Clock", "Sebutkan lokasi pada info sholat berikutnya" to "Include the Location in the Next Prayer Announcement",
        "Pilih berkas audio dari penyimpanan internal untuk semua waktu atau atur suara berbeda bagi Imsak, Subuh, Terbit, Dhuha, Tahajud, Dzuhur, Ashar, Maghrib, dan Isya. Saat tes sedang diputar, gunakan tombol Jeda tes suara azan, Lanjutkan tes suara azan, atau Hentikan tes suara azan di bawah. Tombol-tombol ini hanya untuk tes di pengaturan, bukan azan normal." to "Choose an audio file from internal storage for all prayer times, or set different sounds for Imsak, Fajr, Sunrise, Dhuha, Tahajud, Dhuhr, Asr, Maghrib, and Isha. While the test is playing, use the Pause Adhan Sound Test, Resume Adhan Sound Test, or Stop Adhan Sound Test buttons below. These buttons are only for the settings test, not the actual adhan.",
        "Gunakan satu tombol ini saja. Ketuk pertama untuk memutar tes; ketika suara berjalan, ketuk lagi untuk menjeda; ketuk sekali lagi untuk melanjutkan dari posisi terakhir. Ketuk lama tidak diperlukan. Untuk menghentikan tes, gunakan tombol Hentikan tes di bagian bawah atau tindakan pada notifikasi." to "Use this single button. Tap once to play the test; tap again while it is playing to pause; tap once more to resume from the last position. A long press is not needed. To stop the test, use the Stop Test button at the bottom or the notification action.",
        "Arah kiblat dihitung dari koordinat lokasi ke Ka'bah. Jarum menunjukkan arah relatif menuju kiblat. Pengaturan terpisah di Pengaturan Jadwal Sholat menentukan apakah panduan tetap berjalan ketika layar mati. Pegang HP mendatar, layar menghadap ke atas, saat memakai kompas." to "The Qibla direction is calculated from your location coordinates to the Kaaba. The needle shows the relative direction of the Qibla. A separate setting in Prayer Schedule Settings controls whether guidance continues when the screen is off. Hold the phone flat with the screen facing up when using the compass.",
        "Gunakan saat rapat, musyawarah, pengajian, atau acara lain. Pilih apakah mode hanya menahan pengumuman Jam Pintar Pro atau juga menyenyapkan notifikasi HP. Mode akan berakhir otomatis sesuai durasi dan berusaha memulihkan pengaturan sebelumnya." to "Use this during meetings, discussions, religious study, or other events. Choose whether the mode silences only Jam Pintar Pro announcements or also mutes phone notifications. The mode ends automatically after the selected duration and attempts to restore the previous settings."
,
        "Pilih hari dan jadwal 30 hari" to "Choose a date and view the 30-day schedule",
        "Lokasi belum diatur. Buka Jadwal Sholat, lalu perbarui lokasi (GPS) atau atur lokasi manual." to "Location has not been set. Open Prayer Schedule, then update the location (GPS) or set it manually.",
        "Metode:" to "Method:", "Imsak" to "Imsak", "Subuh" to "Fajr", "Terbit" to "Sunrise",
        "Dhuha" to "Dhuha ", "Tahajud" to "Tahajjud", "Dzuhur" to "Dhuhr", "Ashar" to "Asr",
        "Maghrib" to "Maghrib ", "Isya" to "Isha",
        "Jadwal pengucapan jam" to "Clock Announcement Schedule", "Cara jam diucapkan" to "Clock Announcement Style", "Melodi, tes jam, dan suara" to "Melody, Clock Test, and Sound",
        "Status izin alarm tepat waktu: dikelola otomatis oleh Android pada versi ini." to "Exact alarm permission status: managed automatically by Android on this version.",
        "Status izin alarm tepat waktu: SUDAH DIIZINKAN." to "Exact alarm permission status: ALLOWED.",
        "Status izin alarm tepat waktu: BELUM DIIZINKAN. Buka halaman izin Android, aktifkan jika tersedia, lalu kembali ke sini untuk memeriksa ulang." to "Exact alarm permission status: NOT ALLOWED. Open the Android permission page, enable it if available, then return here to check again.",
        "Kapan baterai berbicara" to "When the battery is announced", "Kalimat ucapan baterai" to "Battery announcement wording", "Suara baterai" to "Battery voice",
        "Tanggal Masehi dan pasaran Jawa" to "Gregorian Date and Javanese Pasaran", "Tanggal Hijriah" to "Hijri Date", "Hari libur nasional dan cuti bersama" to "National Holidays and Collective Leave", "Info sholat berikutnya" to "Next Prayer Information", "Suara pembaca tanggal" to "Date Reader Voice",
        "Izin dan akses notifikasi" to "Notification Permission and Access", "Jenis panggilan dan pengulangan" to "Call Types and Repetition", "Suara pengumuman" to "Announcement Voice",
        "Atur pesan sebelum dan sesudah nama untuk tiap jenis panggilan. Pola yang berbeda membantu mengenali panggilan telepon biasa, WhatsApp Messenger, WhatsApp Business, serta panggilan video. Kolom boleh dikosongkan untuk memakai kalimat standar." to "Set the message before and after the name for each call type. Different patterns help identify regular phone calls, WhatsApp Messenger, WhatsApp Business, and video calls. Leave fields empty to use the default wording.",
        "Panggilan telepon seluler" to "Mobile Phone Call", "Panggilan suara WhatsApp Messenger" to "WhatsApp Messenger Voice Call", "Panggilan video WhatsApp Messenger" to "WhatsApp Messenger Video Call", "Panggilan suara WhatsApp Business" to "WhatsApp Business Voice Call", "Panggilan video WhatsApp Business" to "WhatsApp Business Video Call",
        "Bacakan pemberitahuan dan isi pesan" to "Read the notification and message content", "Bacakan pemberitahuan saja" to "Read the notification only", "Pesan sebelum dan sesudah nama pengirim SMS" to "Message Before and After the SMS Sender's Name",
        "Pengaturan pengulangan notifikasi pesan" to "Message Notification Repetition Settings", "Tidak aktif" to "Disabled", "Jeda antar pembacaan notifikasi dalam detik" to "Delay Between Notification Readings in Seconds", "Kalimat sebelum nama" to "Text Before the Name", "Kalimat sesudah nama" to "Text After the Name",
        "Tes nada singkat" to "Short Tone Test", "Arah perangkat" to "Device Direction", "Panduan kompas kiblat aktif" to "Qibla Compass Guidance Is Active", "Nada dan panduan suara tetap aktif saat layar mati" to "Tones and voice guidance remain active while the screen is off", "Matikan panduan kompas" to "Turn Off Compass Guidance", "Panduan Kompas Kiblat" to "Qibla Compass Guidance",
        "Perangkat ini tidak punya sensor kompas. Gunakan arah kiblat di atas bersama kompas lain." to "This device does not have a compass sensor. Use the Qibla direction shown above with another compass.", "Panduan layar mati tidak dapat dimulai. Periksa izin notifikasi dan baterai." to "Screen-off guidance could not start. Check notification and battery permissions.", "Akurasi kompas rendah. Gerakkan HP membentuk angka delapan di udara untuk mengkalibrasi." to "Compass accuracy is low. Move the phone in a figure-eight pattern in the air to calibrate it.",
        "Atur lokasi terlebih dahulu." to "Set the location first.", "Jadwal online masih baru." to "The online schedule is still new.", "Internet belum tersedia; jadwal offline tetap digunakan." to "The internet is unavailable; the offline schedule will continue to be used.", "Server jadwal tidak dapat dijangkau." to "The schedule server cannot be reached.", "Format jadwal online tidak dikenali." to "The online schedule format is not recognized.", "Data jadwal online tidak lengkap." to "The online schedule data is incomplete.", "Jadwal diperbarui melalui internet. Koreksi menit yang Anda atur tetap diterapkan." to "The schedule was updated via the internet. Your minute adjustments remain applied.", "Pembaruan online gagal. Jadwal perhitungan offline tetap digunakan." to "The online update failed. The offline calculated schedule will continue to be used.", "Belum pernah diperbarui melalui internet" to "Never updated via the internet", "Pembaruan terakhir:" to "Last update:",
        "Lokasi manual" to "Manual Location", "Lokasi tersimpan" to "Saved Location", "Lokasi belum diatur" to "Location Not Set", "Lokasi GPS" to "GPS Location", "Lokasi jaringan" to "Network Location", "Lokasi perangkat" to "Device Location",
        "Jadwal dihitung secara lokal tanpa internet. Untuk Indonesia, metode yang disarankan adalah Kemenag RI. Hasil dapat berbeda beberapa menit dari jadwal masjid setempat karena koordinat, metode, dan penyesuaian menit. Pengingat dan suara azan dalam keadaan nonaktif sampai Anda mengaktifkannya di Pengaturan Jadwal Sholat." to "The schedule is calculated locally without internet access. For Indonesia, the recommended method is the Ministry of Religious Affairs (Kemenag RI). Results may differ by a few minutes from local mosque schedules due to coordinates, calculation method, and minute adjustments. Reminders and adhan sounds are disabled until you enable them in Prayer Schedule Settings.",
        "Jadwal belum dapat dihitung sampai lokasi ditentukan." to "The schedule cannot be calculated until a location is set.", "Layanan lokasi mati. Nyalakan lokasi di setelan perangkat, atau atur lokasi manual." to "Location services are off. Turn on location in device settings or set a location manually.", "Setelan lokasi" to "Location Settings", "Sedang mencari lokasi untuk jadwal sholat melalui GPS dan jaringan. Mohon tunggu hingga 45 detik. Untuk hasil lebih teliti, usahakan berada di tempat terbuka. Nada pendek berulang menandakan pencarian aktif." to "Searching for a location for the prayer schedule using GPS and network services. Please wait up to 45 seconds. For better accuracy, try to be outdoors. Repeated short tones indicate that the search is active.",
        "Perangkat tidak mengizinkan pembaruan lokasi. Periksa izin lokasi dan coba lagi." to "The device does not allow location updates. Check location permissions and try again.", "Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka atau atur lokasi manual." to "The location could not be found. Make sure location permission and services are enabled, then try again in a more open area or set the location manually.", "Nama kota/lokasi (opsional)" to "City/Location Name (Optional)", "Koordinat tidak valid. Lintang harus −90 sampai 90 dan bujur −180 sampai 180." to "Invalid coordinates. Latitude must be between −90 and 90 and longitude between −180 and 180.",
        "Pencarian lokasi masih berlangsung. Data satelit sudah tersedia. Aplikasi sedang menunggu posisi yang stabil." to "Location search is still in progress. Satellite data is available. The app is waiting for a stable position.",
        "Data satelit sudah tersedia. Aplikasi sedang menunggu posisi yang stabil." to "Satellite data is available. The app is waiting for a stable position.", "Belum ada satelit yang digunakan untuk menentukan posisi. Cobalah berada di luar ruangan dengan pandangan langit terbuka." to "No satellites are being used to determine the position. Try moving outdoors with a clear view of the sky.",
        "Lokasi belum diminta. Tekan Perbarui lokasi terkini." to "Location has not been requested yet. Select Update Current Location.", "Lokasi belum tersedia. Tekan Perbarui lokasi terkini terlebih dahulu." to "Location is not available yet. Select Update Current Location first.", "Buka setelan lokasi perangkat" to "Open Device Location Settings", "Layanan lokasi perangkat sedang mati. Aktifkan lokasi lalu coba lagi." to "Device location services are off. Turn on location and try again.", "Sedang mencari posisi satelit dan posisi terbaik. Nada pendek berulang menandakan pencarian masih berlangsung. Mohon tunggu hingga 45 detik. Untuk hasil lebih teliti, usahakan berada di tempat terbuka dan jauh dari dinding atau bangunan tinggi." to "Searching for satellites and the best position. Repeated short tones indicate that the search is ongoing. Please wait up to 45 seconds. For better accuracy, move outdoors away from walls and tall buildings.",
        "Alamat atau wilayah yang terdeteksi: " to "Detected address or area: ", "Nama jalan dan wilayah belum berhasil didapatkan dari layanan alamat." to "Street and area names could not be retrieved from the address service.", "tidak diketahui" to "unknown", "Ketelitian posisi sangat baik." to "Position accuracy is excellent.", "Ketelitian posisi baik." to "Position accuracy is good.", "Ketelitian posisi sedang. Untuk hasil lebih teliti, tunggu beberapa saat atau coba di tempat terbuka." to "Position accuracy is moderate. For better accuracy, wait a moment or try an open area.", "Belum ada lokasi untuk disimpan. Cari lokasi terlebih dahulu." to "There is no location to save yet. Find a location first.", "Nama atau label lokasi yang akan disimpan" to "Name or label for the location to save", "Beri nama yang mudah diingat agar lokasi ini dapat ditemukan kembali nanti." to "Choose an easy-to-remember name so you can find this location again later.", "Nama lokasi harus diisi" to "A location name is required", "Pilih lokasi tersimpan" to "Select a Saved Location", "Data lokasi tidak valid." to "The location data is invalid.", "Bacakan informasi lokasi" to "Read Location Information", "Buka lokasi di peta" to "Open Location on Map", "Hapus lokasi tersimpan" to "Delete Saved Location", "Lokasi ini akan dihapus dari daftar lokasi tersimpan pada perangkat ini." to "This location will be removed from the saved locations list on this device.",
        "Pilih jenis fasilitas yang ingin dicari. Pencarian dibuka di Google Maps atau aplikasi peta yang tersedia. Internet dan izin lokasi pada aplikasi peta mungkin diperlukan agar hasil dan jarak terdekat akurat. Jam Pintar Pro tidak menyimpan lokasi Anda." to "Choose the type of facility to find. The search opens in Google Maps or another available map app. Internet access and location permission in the map app may be needed for accurate results and distances. Jam Pintar Pro does not store your location.",
        "Lokasi belum diatur. Buka Jadwal Sholat lalu atur lokasi GPS atau manual." to "Location has not been set. Open Prayer Schedule and set a GPS or manual location.", "Info Jadwal Sholat" to "Prayer Schedule Information", "Jadwal sholat hari ini." to "Today's prayer schedule.",
        "Pilih hari dan jadwal 30 hari" to "Select a Day and View the 30-Day Schedule", "Jadwal 30 hari ke depan" to "Schedule for the Next 30 Days", "Bacakan jadwal tanggal terpilih" to "Announce the Selected Date's Schedule", "Bacakan jadwal sholat hari ini" to "Announce Today's Prayer Schedule",
        "Baterai lemah, tinggal {persen} persen. Segera isi daya." to "Battery is low at {persen} percent. Please charge soon.", "Peringatan! Baterai kritis, tinggal {persen} persen. Segera isi daya." to "Warning! Battery is critically low at {persen} percent. Please charge soon.", "Baterai sudah {persen} persen. Silakan cabut pengisi daya." to "Battery is at {persen} percent. You may disconnect the charger.", "Baterai sudah 100 persen. Silakan cabut pengisi daya." to "Battery is at 100 percent. You may disconnect the charger.",
        "Masjid dan musala" to "Mosques and prayer rooms", "Rumah sakit" to "Hospitals", "Puskesmas dan klinik" to "Community health centers and clinics", "Apotek" to "Pharmacies", "ATM" to "ATMs", "Bank" to "Banks", "Toilet umum" to "Public restrooms", "Kantor polisi" to "Police stations", "Pemadam kebakaran" to "Fire stations", "SPBU" to "Gas stations", "Halte dan stasiun" to "Bus stops and train stations", "Pasar dan minimarket" to "Markets and convenience stores",
        "Apa yang terdampak selama acara?" to "What Is Affected During the Event?", "Pilih cakupan Mode Acara" to "Choose Event Mode Scope", "Hanya suara/pengumuman Jam Pintar Pro" to "Jam Pintar Pro announcements only", "Notifikasi prioritas (atur pengecualian di Android)" to "Priority notifications (configure exceptions in Android)", "Alarm saja yang boleh berbunyi" to "Allow alarms only", "Senyapkan semua notifikasi HP" to "Mute all phone notifications", "Keterangan: Notifikasi prioritas mengikuti pengecualian Jangan Ganggu pada Android, misalnya panggilan, pesan, atau aplikasi tertentu yang Anda izinkan. Untuk memilih aplikasi yang boleh tetap memberi notifikasi, buka pengaturan pengecualian Android di bawah ini." to "Note: Priority notifications follow Android Do Not Disturb exceptions, such as calls, messages, or apps you allow. To choose which apps can still send notifications, open the Android exception settings below.", "Atur pengecualian notifikasi di Android" to "Configure Android Notification Exceptions", "Pilih berapa lama mode berlangsung" to "Choose How Long the Mode Lasts", "30 menit" to "30 minutes", "1 jam" to "1 hour", "2 jam" to "2 hours", "3 jam" to "3 hours", "Tanpa batas waktu" to "No time limit", "Aktifkan Mode Acara" to "Enable Event Mode", "Akhiri Mode Acara dan Pulihkan" to "End Event Mode and Restore Settings", "Buka pengaturan izin Jangan Ganggu" to "Open Do Not Disturb Permission Settings",
        "Buka Pengaturan Android, lalu izinkan akses Jangan Ganggu untuk Jam Pintar Pro." to "Open Android Settings and allow Jam Pintar Pro to access Do Not Disturb.", "Silakan cari akses Jangan Ganggu pada Pengaturan Android." to "Find Do Not Disturb access in Android Settings.", "Buka Pengaturan Android, lalu cari Jangan Ganggu atau Pengecualian notifikasi." to "Open Android Settings and look for Do Not Disturb or notification exceptions.", "Catatan: pilihan Hanya suara/pengumuman Jam Pintar Pro tidak mengubah Jangan Ganggu sistem, sehingga aplikasi lain tetap dapat berbunyi. Pilihan lainnya memakai filter Jangan Ganggu Android. Jika Jangan Ganggu sudah aktif sebelum acara dimulai, pengaturan sebelumnya akan dipulihkan. Perubahan manual pengguna selama acara tidak sengaja ditimpa." to "Note: The Jam Pintar Pro announcements-only option does not change the system Do Not Disturb setting, so other apps can still make sounds. Other options use Android's Do Not Disturb filter. If Do Not Disturb was already enabled before the event, the previous settings will be restored. Manual changes you make during the event will not be overwritten intentionally.",
        "Status Mode Acara:" to "Event Mode status:", "Cakupan:" to "Scope:", "Izin Jangan Ganggu:" to "Do Not Disturb permission:", "Notifikasi prioritas Android" to "Android priority notifications", "Alarm saja" to "Alarms only", "Semua notifikasi HP disenyapkan" to "All phone notifications muted", "diizinkan" to "granted", "tidak diperlukan untuk cakupan ini" to "not required for this scope", "belum diizinkan" to "not granted", "Sisa waktu sekitar" to "Approximately", "menit." to "minutes remaining.", "Mode ini tidak memiliki batas waktu." to "This mode has no time limit.",
    )
}
