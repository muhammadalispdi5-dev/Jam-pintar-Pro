package com.novan.bateraibicara

import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView

/** Accessible controls to temporarily silence app announcements and phone notifications. */
class ModeAcaraActivity : Halaman() {
    override val judulHalaman = R.string.judul_mode_acara
    private var durasi = 60
    private var cakupan = ModeAcara.CAKUPAN_SEMUA
    private lateinit var status: TextView

    override fun bangun() {
        info("Gunakan saat rapat, musyawarah, pengajian, atau acara lain. Pilih apakah mode hanya menahan pengumuman Jam Pintar Pro atau juga menyenyapkan notifikasi HP. Mode akan berakhir otomatis sesuai durasi dan berusaha memulihkan pengaturan sebelumnya.")
        bagian("Apa yang terdampak selama acara?")
        cakupan = ModeAcara.cakupan(this)
        pilihan(
            "Pilih cakupan Mode Acara",
            listOf(
                "Hanya suara/pengumuman Jam Pintar Pro",
                "Notifikasi prioritas (atur pengecualian di Android)",
                "Alarm saja yang boleh berbunyi",
                "Senyapkan semua notifikasi HP"
            ),
            cakupan
        ) {
            cakupan = it
            getSharedPreferences("mode_acara", MODE_PRIVATE).edit().putInt("cakupan", cakupan).apply()
            perbaruiStatus()
        }
        info("Keterangan: Notifikasi prioritas mengikuti pengecualian Jangan Ganggu pada Android, misalnya panggilan, pesan, atau aplikasi tertentu yang Anda izinkan. Untuk memilih aplikasi yang boleh tetap memberi notifikasi, buka pengaturan pengecualian Android di bawah ini.")
        tombol("Atur pengecualian notifikasi di Android") { bukaPengaturanPrioritas() }
        bagian("Durasi Mode Acara")
        pilihan("Pilih berapa lama mode berlangsung", listOf("30 menit", "1 jam", "2 jam", "3 jam", "Tanpa batas waktu"), 1) {
            durasi = when (it) { 0 -> 30; 1 -> 60; 2 -> 120; 3 -> 180; else -> 0 }
        }
        status = info("")
        tombol("Aktifkan Mode Acara") {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val perluIzinDnd = cakupan != ModeAcara.CAKUPAN_JAM_PINTAR
            if (perluIzinDnd && !nm.isNotificationPolicyAccessGranted) {
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                catch (_: Exception) { toast("Buka Pengaturan Android, lalu izinkan akses Jangan Ganggu untuk Jam Pintar Pro.") }
                return@tombol
            }
            if (ModeAcara.mulai(this, durasi, cakupan)) {
                perbaruiStatus()
                toast("Mode Acara diaktifkan sesuai cakupan yang dipilih.")
            } else toast("Mode Acara belum dapat diaktifkan. Periksa izin Jangan Ganggu.")
        }
        tombol("Akhiri Mode Acara dan Pulihkan") {
            ModeAcara.selesai(this)
            perbaruiStatus()
            toast("Mode Acara diakhiri.")
        }
        tombol("Buka pengaturan izin Jangan Ganggu") {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Silakan cari akses Jangan Ganggu pada Pengaturan Android.") }
        }
        info("Catatan: pilihan Hanya suara/pengumuman Jam Pintar Pro tidak mengubah Jangan Ganggu sistem, sehingga aplikasi lain tetap dapat berbunyi. Pilihan lainnya memakai filter Jangan Ganggu Android. Jika Jangan Ganggu sudah aktif sebelum acara dimulai, pengaturan sebelumnya akan dipulihkan. Perubahan manual pengguna selama acara tidak sengaja ditimpa.")
        perbaruiStatus()
    }

    private fun bukaPengaturanPrioritas() {
        try {
            startActivity(Intent("android.settings.ZEN_MODE_PRIORITY_SETTINGS"))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Buka Pengaturan Android, lalu cari Jangan Ganggu atau Pengecualian notifikasi.") }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) perbaruiStatus()
    }

    private fun perbaruiStatus() {
        if (!::status.isInitialized) return
        val english = BahasaAplikasi.tampilan(this) == 1
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val aktif = ModeAcara.aktif(this)
        val akhir = getSharedPreferences("mode_acara", MODE_PRIVATE).getLong("berakhir", 0L)
        val menit = if (akhir > 0L) ((akhir - System.currentTimeMillis()).coerceAtLeast(0L) / 60_000L) else 0L
        val durasiText = when {
            akhir > 0L && english -> " Approximately $menit minutes remaining."
            akhir > 0L -> " Sisa waktu sekitar $menit menit."
            aktif && english -> " This mode has no time limit."
            aktif -> " Mode ini tidak memiliki batas waktu."
            else -> ""
        }
        val activeText = when {
            english && aktif -> "ENABLED"
            english -> "DISABLED"
            aktif -> "AKTIF"
            else -> "NONAKTIF"
        }
        val permissionText = when {
            cakupan == ModeAcara.CAKUPAN_JAM_PINTAR && english -> "not required for this scope"
            cakupan == ModeAcara.CAKUPAN_JAM_PINTAR -> "tidak diperlukan untuk cakupan ini"
            nm.isNotificationPolicyAccessGranted && english -> "granted"
            nm.isNotificationPolicyAccessGranted -> "diizinkan"
            english -> "not granted"
            else -> "belum diizinkan"
        }
        val scopeText = when (ModeAcara.cakupan(this)) {
            ModeAcara.CAKUPAN_JAM_PINTAR -> if (english) "Jam Pintar Pro announcements only" else "Hanya suara/pengumuman Jam Pintar Pro"
            ModeAcara.CAKUPAN_PRIORITAS -> if (english) "Android priority notifications" else "Notifikasi prioritas Android"
            ModeAcara.CAKUPAN_ALARM -> if (english) "Alarms only" else "Alarm saja"
            else -> if (english) "All phone notifications muted" else "Semua notifikasi HP disenyapkan"
        }
        status.text = if (english) {
            "Event Mode status: $activeText. Scope: $scopeText. Do Not Disturb permission: $permissionText.$durasiText"
        } else {
            "Status Mode Acara: $activeText. Cakupan: $scopeText. Izin Jangan Ganggu: $permissionText.$durasiText"
        }
    }
}
