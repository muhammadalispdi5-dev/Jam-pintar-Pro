package com.novan.bateraibicara

import android.app.AlertDialog
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pengaturan kategori Jam: jadwal, format ucapan, dan suara. */
class JamActivity : Halaman() {

    override val judulHalaman = R.string.kategori_jam

    private lateinit var teksBerikut: TextView
    private lateinit var tombolHari: Button
    private lateinit var statusIzinAlarm: TextView

    // Urutan tampil Senin..Minggu -> nomor bit (0 = Minggu)
    private val urutanHari = intArrayOf(1, 2, 3, 4, 5, 6, 0)

    override fun bangun() {
        when (kodeKelompok()) {
            "jadwal" -> grupJadwal()
            "ucapan" -> grupUcapan()
            "suara" -> grupSuara()
            else -> menuUtama()
        }
    }

    private fun menuUtama() {
        saklar(getString(R.string.sw_jam_on), prefs.jamOn) {
            prefs.jamOn = it
            berubah()
        }
        info(getString(R.string.info_jam))
        teksBerikut = info("")

        tombolKelompok("Jadwal pengucapan jam", "jadwal")
        tombolKelompok("Cara jam diucapkan", "ucapan")
        tombolKelompok("Melodi, tes jam, dan suara", "suara")
    }

    private fun grupJadwal() {
        judulGrup("Jadwal pengucapan jam")
        // ----- Jadwal -----
        bagian(getString(R.string.bagian_jadwal))
        pilihan(getString(R.string.jam_mode), larik(R.array.jam_mode), prefs.jamMode) {
            prefs.jamMode = it
            berubah()
        }
        pilihan(getString(R.string.jam_interval), larik(R.array.jam_interval), prefs.jamIntervalIdx) {
            prefs.jamIntervalIdx = it
            berubah()
        }
        tombolJam(R.string.jam_mulai, { prefs.jamMulai }, { prefs.jamMulai = it; berubah() })
        tombolJam(R.string.jam_selesai, { prefs.jamSelesai }, { prefs.jamSelesai = it; berubah() })
        tombolHari = tombol("") { pilihHari() }
        segarkanHari()

    }

    private fun grupUcapan() {
        judulGrup("Cara jam diucapkan")
        // ----- Ucapan -----
        bagian(getString(R.string.bagian_ucapan_jam))
        pilihan(getString(R.string.jam_format), larik(R.array.jam_format), prefs.jamFormat) {
            prefs.jamFormat = it
            muatUlang()
        }
        bagian(getString(R.string.jam_disebut))
        saklar(getString(R.string.sw_ucap_jam), prefs.jamSebutJam) { prefs.jamSebutJam = it; muatUlang() }
        saklar(getString(R.string.sw_sebut_menit), prefs.jamSebutMenit) { prefs.jamSebutMenit = it; muatUlang() }
        saklar(getString(R.string.sw_sebut_detik), prefs.jamSebutDetik) {
            prefs.jamSebutDetik = it
            muatUlang()
        }
        // Tepat di awal dan tepat di akhir saling meniadakan; tampilan saklar lawannya ikut dimatikan.
        var saklarAwal: android.widget.Switch? = null
        var saklarAkhir: android.widget.Switch? = null
        saklarAwal = saklar(getString(R.string.sw_tepat_awal), prefs.jamTepatAwal) {
            prefs.jamTepatAwal = it
            if (it) {
                prefs.jamTepatAkhir = false
                saklarAkhir?.isChecked = false
            }
            muatUlang()
        }
        saklarAkhir = saklar(getString(R.string.sw_tepat_akhir), prefs.jamTepatAkhir) {
            prefs.jamTepatAkhir = it
            if (it) {
                prefs.jamTepatAwal = false
                saklarAwal?.isChecked = false
            }
            muatUlang()
        }
        info(getString(R.string.info_tepat_detik))
        saklar(getString(R.string.jam_sebut_periode), prefs.jamSebutPeriode) { prefs.jamSebutPeriode = it; muatUlang() }
        isian(getString(R.string.jam_awalan), prefs.jamAwalan, InputType.TYPE_CLASS_TEXT) {
            prefs.jamAwalan = it
            muatUlang()
        }
        info(getString(R.string.info_jam_awalan))

    }

    private fun grupSuara() {
        judulGrup("Melodi, tes jam, dan suara")
        // ----- Suara -----
        bagian(getString(R.string.bagian_melodi_jam))
        pilihan(getString(R.string.jam_melodi_awal), larik(R.array.jam_melodi), prefs.jamMelodiAwal) {
            prefs.jamMelodiAwal = it
            berubah()
        }
        tombol(getString(R.string.jam_melodi_awal) + " — " + getString(R.string.tombol_tes)) {
            Melodi.putar(this, prefs.jamMelodiAwal, prefs.suara("jam").audioAttributes())
        }
        pilihan(getString(R.string.jam_melodi_akhir), larik(R.array.jam_melodi), prefs.jamMelodiAkhir) {
            prefs.jamMelodiAkhir = it
            berubah()
        }
        tombol(getString(R.string.jam_melodi_akhir) + " — " + getString(R.string.tombol_tes)) {
            Melodi.putar(this, prefs.jamMelodiAkhir, prefs.suara("jam").audioAttributes())
        }
        isian(getString(R.string.jam_jeda_awal), prefs.jamJedaAwal.toString(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL) {
            prefs.jamJedaAwal = it.replace(',', '.').toFloatOrNull() ?: 0f
        }
        isian(getString(R.string.jam_jeda_akhir), prefs.jamJedaAkhir.toString(), android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL) {
            prefs.jamJedaAkhir = it.replace(',', '.').toFloatOrNull() ?: 0f
        }
        isian(getString(R.string.jam_jeda_jam_menit), prefs.jamJedaJamMenit.toString(), android.text.InputType.TYPE_CLASS_NUMBER) {
            prefs.jamJedaJamMenit = it.toIntOrNull() ?: 300
        }
        tombol(getString(R.string.jam_tes_lengkap)) { tesJamLengkap() }
        tombol(getString(R.string.jam_tes_ucapan_saja)) {
            // Waktu dibacakan oleh suara jam; tanggal, libur, dan info sholat oleh suara pembaca tanggal.
            val c = Calendar.getInstance()
            val waktu = JamWaktu.ucapan(prefs, c)
            val tanggal = JamWaktu.segmenTanggal(prefs, c)
            val pj = Pembicara(this, prefs.suara("jam")) { toast(it) }
            val pt = Pembicara(this, prefs.suara("tgl")) { toast(it) }
            val selesaiSemua = { pj.matikan(); pt.matikan() }
            val bacaTanggal = { if (tanggal.isEmpty()) selesaiSemua() else pt.ucapkanRangkaian(tanggal, 300L) { selesaiSemua() } }
            if (waktu.isBlank()) bacaTanggal() else pj.ucapkan(waktu, true) { bacaTanggal() }
        }
        tombol(getString(R.string.jam_izin_alarm)) { bukaIzinAlarm() }
        info(getString(R.string.jam_izin_alarm_info))
        statusIzinAlarm = info("")
        segarkanStatusIzinAlarm()

        blokSuara("jam") { JamWaktu.ucapan(prefs, Calendar.getInstance()) }
    }

    override fun onResume() {
        super.onResume()
        segarkanBerikut()
        if (::statusIzinAlarm.isInitialized) segarkanStatusIzinAlarm()
    }

    private fun berubah() {
        muatUlang()
        segarkanBerikut()
    }

    private fun segarkanHari() {
        tombolHari.text = getString(R.string.jam_hari, JamWaktu.ringkasHari(prefs.jamHari))
    }

    private fun segarkanBerikut() {
        if (!::teksBerikut.isInitialized) return // hanya ada di halaman daftar utama
        val t = if (prefs.jamOn) JamWaktu.berikut(prefs, System.currentTimeMillis()) else null
        teksBerikut.text = if (t == null) {
            getString(R.string.jam_berikut_tidak_ada)
        } else {
            // Pratinjau jadwal adalah teks antarmuka, jadi ikuti bahasa tampilan,
            // bukan bahasa TTS yang dipilih secara terpisah untuk pengucapan jam.
            val bahasaTampilan = BahasaAplikasi.tampilan(this)
            val localeTampilan = if (bahasaTampilan == 1) Locale.ENGLISH else Locale("id", "ID")
            val f = SimpleDateFormat("EEEE, HH.mm", localeTampilan)
            var waktuTampil = f.format(Date(t))
            if (bahasaTampilan == 0) waktuTampil = waktuTampil.replace("Minggu", "Ahad")
            getString(R.string.jam_berikut, waktuTampil)
        }
    }


    private fun tesJamLengkap() {
        val c = Calendar.getInstance()
        val (pertama, menit) = JamWaktu.bagianUcapan(prefs, c)
        val tanggal = JamWaktu.segmenTanggal(prefs, c)
        val pembicara = Pembicara(this, prefs.suara("jam")) { toast(it) }
        val pembicaraTanggal = Pembicara(this, prefs.suara("tgl")) { toast(it) }
        val akhir: () -> Unit = {
            window.decorView.postDelayed({ Melodi.putar(this, prefs.jamMelodiAkhir, prefs.suara("jam").audioAttributes()) { pembicara.matikan(); pembicaraTanggal.matikan() } }, (prefs.jamJedaAkhir * 1000).toLong())
        }
        val bacaTanggal: () -> Unit = { pembicaraTanggal.ucapkanRangkaian(tanggal, 300L) { akhir() } }
        val mulai: () -> Unit = {
            pembicara.ucapkan(pertama, true) {
                if (menit != null) window.decorView.postDelayed({ pembicara.ucapkan(menit, false) { window.decorView.postDelayed({ bacaTanggal() }, 300L) } }, prefs.jamJedaJamMenit.toLong())
                else if (tanggal.isNotEmpty()) window.decorView.postDelayed({ bacaTanggal() }, 300L) else akhir()
            }
        }
        if (prefs.jamMelodiAwal > 0) {
            Melodi.putar(this, prefs.jamMelodiAwal, prefs.suara("jam").audioAttributes()) {
                window.decorView.postDelayed({ mulai() }, (prefs.jamJedaAwal * 1000).toLong())
            }
        } else mulai()
    }

    private fun segarkanStatusIzinAlarm() {
        val status = if (android.os.Build.VERSION.SDK_INT < 31) {
            "Status izin alarm tepat waktu: dikelola otomatis oleh Android pada versi ini."
        } else {
            val am = getSystemService(android.app.AlarmManager::class.java)
            if (am?.canScheduleExactAlarms() == true) {
                "Status izin alarm tepat waktu: SUDAH DIIZINKAN."
            } else {
                "Status izin alarm tepat waktu: BELUM DIIZINKAN. Buka halaman izin Android, aktifkan jika tersedia, lalu kembali ke sini untuk memeriksa ulang."
            }
        }
        statusIzinAlarm.text = status
        statusIzinAlarm.contentDescription = status
    }

    private fun bukaIzinAlarm() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse(("package:" + (packageName))))) }
            catch (_: Exception) { startActivity(android.content.Intent(android.provider.Settings.ACTION_SETTINGS)) }
        } else {
            toast(R.string.jam_izin_alarm_info)
        }
    }

    private fun pilihHari() {
        val nama = larik(R.array.nama_hari).toTypedArray()
        var mask = prefs.jamHari
        val dicentang = BooleanArray(7) { (mask and (1 shl urutanHari[it])) != 0 }
        AlertDialog.Builder(this)
            .setTitle(R.string.jam_pilih_hari)
            .setMultiChoiceItems(nama, dicentang) { _, which, centang ->
                val bit = 1 shl urutanHari[which]
                mask = if (centang) (mask or bit) else (mask and bit.inv())
            }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.jamHari = mask
                segarkanHari()
                berubah()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
