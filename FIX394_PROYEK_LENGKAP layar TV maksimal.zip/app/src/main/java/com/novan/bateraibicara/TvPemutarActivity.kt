package com.novan.bateraibicara

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView

/**
 * FIX394: pemutar TV Islami dengan tampilan layar penuh dan kontrol yang ramah TalkBack.
 * Tanpa TalkBack, siaran langsung dibuka mendatar layar penuh. Dengan TalkBack aktif, siaran dibuka tegak 16:9 agar layar tidak
 * berputar tiba-tiba, dan pengguna dapat masuk layar penuh lewat tombol. Status siaran diumumkan lewat wilayah langsung (live region).
 */
class TvPemutarActivity : Halaman() {
    override val judulHalaman = R.string.judul_radio_tv
    private var video: VideoView? = null
    private var status: TextView? = null
    private var bingkai: FrameLayout? = null
    private var tombolPenuh: Button? = null
    private var judulView: View? = null
    private var penuh = false
    private var senyap = false
    private var pemutarMedia: MediaPlayer? = null
    private var fokusAudio: AudioManager.OnAudioFocusChangeListener? = null

    private fun talkBackAktif(): Boolean = try {
        (getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager).isTouchExplorationEnabled
    } catch (_: Exception) { false }

    override fun bangun() {
        val nama = intent.getStringExtra("nama").orEmpty()
        val url = intent.getStringExtra("url").orEmpty()
        PemutarSaluran.berhenti()
        val idx = root.childCount
        bagian(nama)
        judulView = root.getChildAt(idx)
        status = info(tr("Memuat siaran…", "Loading the broadcast…")).also { it.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        bingkai = frame
        val v = VideoView(this)
        video = v
        v.contentDescription = tr("Layar siaran TV: ", "TV broadcast screen: ") + nama
        v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        v.keepScreenOn = true
        frame.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, tinggiVideo()))

        val baris = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun kontrol(teks: String, deskripsi: String, aksi: () -> Unit): Button = Button(this).apply {
            text = teks; contentDescription = deskripsi; textSize = 14f; minHeight = dp(56); minimumHeight = dp(56)
            setOnClickListener { aksi() }
            baris.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        kontrol(tr("Jeda", "Pause"), tr("Jeda atau lanjutkan siaran", "Pause or resume the broadcast")) {
            if (v.isPlaying) { v.pause(); setStatus(tr("Dijeda.", "Paused.")) } else { v.start(); setStatus(tr("Dilanjutkan.", "Resumed.")) }
        }
        kontrol(tr("Vol -", "Vol -"), tr("Turunkan volume", "Volume down")) { ubahVolume(-1) }
        kontrol(tr("Vol +", "Vol +"), tr("Naikkan volume", "Volume up")) { ubahVolume(1) }
        kontrol(tr("Senyap", "Mute"), tr("Senyapkan atau bunyikan suara", "Mute or unmute the sound")) { senyap = !senyap; terapkanSenyap(); setStatus(if (senyap) tr("Suara disenyapkan.", "Sound muted.") else tr("Suara dibunyikan.", "Sound on.")) }
        root.addView(baris, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        tombolPenuh = tombol(tr("Layar penuh", "Full screen")) { aturPenuh(!penuh) }
        tombol(tr("Berhenti dan kembali", "Stop and go back")) { v.stopPlayback(); finish() }

        v.setOnPreparedListener { mp ->
            pemutarMedia = mp
            mp.setOnInfoListener { _, what, _ ->
                if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) setStatus(tr("Memuat, mohon tunggu…", "Buffering, please wait…"))
                else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) setStatus(tr("Siaran berlanjut.", "The broadcast continues."))
                false
            }
            terapkanSenyap()
            mp.start(); setStatus(tr("Memutar: ", "Playing: ") + nama)
        }
        v.setOnCompletionListener { setStatus(tr("Siaran berakhir.", "The broadcast ended.")) }
        v.setOnErrorListener { _, _, _ -> setStatus(tr("Siaran tidak dapat diputar. Saluran mungkin sedang tidak tersedia. Coba saluran lain.", "The broadcast could not be played. The channel may be unavailable. Try another channel.")); true }
        mintaFokusAudio()
        try { v.setVideoURI(Uri.parse(url)); v.requestFocus() } catch (_: Exception) { setStatus(tr("Alamat siaran tidak valid.", "The stream address is invalid.")) }
        // Tanpa TalkBack: langsung layar penuh mendatar. Dengan TalkBack: tegak, masuk layar penuh lewat tombol.
        if (!talkBackAktif()) aturPenuh(true)
    }

    private fun tinggiVideo(): Int {
        val dm = resources.displayMetrics
        return if (penuh) (dm.heightPixels - dp(150)).coerceAtLeast(dp(200)) else (dm.widthPixels * 9 / 16).coerceAtLeast(dp(180))
    }

    @Suppress("DEPRECATION")
    private fun aturPenuh(p: Boolean) {
        penuh = p
        requestedOrientation = if (p) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.decorView.systemUiVisibility = if (p) (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else View.SYSTEM_UI_FLAG_VISIBLE
        judulView?.visibility = if (p) View.GONE else View.VISIBLE
        tombolPenuh?.text = if (p) tr("Keluar layar penuh", "Exit full screen") else tr("Layar penuh", "Full screen")
        bingkai?.layoutParams = (bingkai?.layoutParams as LinearLayout.LayoutParams).also { it.height = tinggiVideo() }
        setStatus(if (p) tr("Layar penuh. Tombol kontrol ada di bawah layar.", "Full screen. The control buttons are below the screen.") else tr("Keluar dari layar penuh.", "Left full screen."))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bingkai?.layoutParams = (bingkai?.layoutParams as? LinearLayout.LayoutParams)?.also { it.height = tinggiVideo() }
    }

    private fun ubahVolume(arah: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (arah > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        val maks = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        setStatus(tr("Volume ", "Volume ") + (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maks) + tr(" persen", " percent"))
    }

    private fun terapkanSenyap() { try { pemutarMedia?.setVolume(if (senyap) 0f else 1f, if (senyap) 0f else 1f) } catch (_: Exception) { } }

    private fun mintaFokusAudio() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val l = AudioManager.OnAudioFocusChangeListener { }
        fokusAudio = l
        @Suppress("DEPRECATION") am.requestAudioFocus(l, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
    }

    private fun setStatus(t: String) { runOnUiThread { status?.text = t } }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        try { video?.stopPlayback() } catch (_: Exception) { }
        try { fokusAudio?.let { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocus(it) } } catch (_: Exception) { }
        super.onDestroy()
    }
}
