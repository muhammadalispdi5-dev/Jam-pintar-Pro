package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.PowerManager

/** FIX392: pemutar radio daring tunggal yang tetap hidup saat pindah halaman. Siaran berhenti bila Android menutup aplikasi. */
object PemutarSaluran {
    private var mp: MediaPlayer? = null
    var nama: String = ""
        private set

    fun sedangMain(): Boolean = try { mp?.isPlaying == true } catch (_: Exception) { false }

    fun putar(c: Context, s: RadioTvData.Saluran, status: (String) -> Unit) {
        berhenti()
        nama = s.nama
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setWakeMode(c.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(s.url)
            p.setOnPreparedListener { if (mp === p) { it.start(); status("start") } }
            p.setOnErrorListener { _, _, _ -> if (mp === p) { berhenti(); status("gagal") }; true }
            p.setOnCompletionListener { if (mp === p) status("selesai") }
            p.prepareAsync()
        } catch (_: Exception) { berhenti(); status("gagal") }
    }

    fun jedaLanjut(): Boolean? {
        val p = mp ?: return null
        return try { if (p.isPlaying) { p.pause(); false } else { p.start(); true } } catch (_: Exception) { null }
    }

    fun berhenti() {
        val p = mp; mp = null
        try { p?.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
    }
}
