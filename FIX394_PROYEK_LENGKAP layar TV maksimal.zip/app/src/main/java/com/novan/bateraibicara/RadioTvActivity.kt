package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.Intent
import android.text.InputType
import android.widget.EditText
import android.widget.TextView

/** FIX392: menu Radio dan TV Islami. mode kosong = menu utama; "radio" atau "tv" = daftar saluran. */
class RadioTvActivity : Halaman() {
    override val judulHalaman = R.string.judul_radio_tv

    private var status: TextView? = null
    private var tampilAwal = -1
    private var nomorMuat = 0
    private var memindai = false
    private var batalPindai = false
    private var daringTerakhir: List<RadioTvData.Saluran> = emptyList()

    override fun bangun() {
        val mode = intent.getStringExtra("mode").orEmpty()
        if (mode != "radio" && mode != "tv") { menu(); return }
        val tv = mode == "tv"
        bagian(if (tv) tr("TV Islami", "Islamic TV") else tr("Radio Islami", "Islamic radio"))
        status = info(tr("Memuat daftar…", "Loading the list…")).also { it.accessibilityLiveRegion = android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE }
        if (!tv) {
            tombol(tr("Jeda atau lanjutkan radio", "Pause or resume the radio")) {
                val r = PemutarSaluran.jedaLanjut()
                setStatus(if (r == null) tr("Belum ada radio yang diputar.", "No radio is playing.") else if (r) tr("Dilanjutkan.", "Resumed.") else tr("Dijeda.", "Paused."))
            }
            tombol(tr("Hentikan radio", "Stop the radio")) { PemutarSaluran.berhenti(); setStatus(tr("Radio dihentikan.", "Radio stopped.")) }
            tombol(tr("Naikkan volume radio", "Radio volume up")) { ubahVolume(1) }
            tombol(tr("Turunkan volume radio", "Radio volume down")) { ubahVolume(-1) }
            tombol(tr("Radio yang sedang diputar", "Radio now playing")) {
                setStatus(if (PemutarSaluran.sedangMain()) tr("Sedang diputar: ", "Now playing: ") + PemutarSaluran.nama else tr("Tidak ada radio yang sedang diputar.", "No radio is playing."))
            }
        }
        tombol(tr("Muat ulang daftar", "Reload the list")) { recreate() }
        tombol(tr("Pindai saluran otomatis", "Scan channels automatically")) { mulaiPindai(tv) }
        tombol(tr("Batalkan pemindaian", "Cancel the scan")) { if (memindai) { batalPindai = true; setStatus(tr("Membatalkan pemindaian…", "Cancelling the scan…")) } }
        tombol(tr("Tambah saluran sendiri", "Add your own channel")) { dialogTambah(tv) }
        tampilAwal = root.childCount
        daringTerakhir = RadioTvData.cadangan(this, tv)
        segarkanDaftar(tv)
        val nomor = ++nomorMuat
        Thread {
            val hasil = try { if (tv) RadioTvData.muatTv(this) else RadioTvData.muatRadio(this) } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || nomor != nomorMuat) return@runOnUiThread
                if (hasil == null) setStatus(tr("Daftar tidak dapat dimuat dari internet. Daftar tersimpan terakhir ditampilkan bila ada.", "The list could not be loaded from the internet. The last saved list is shown if there is one."))
                else if (hasil.isEmpty()) setStatus(tr("Tidak ada saluran Islami yang ditemukan saat ini.", "No Islamic channels were found right now."))
                else {
                    setStatus(tr("Daftar dimuat: ", "List loaded: ") + hasil.size)
                    daringTerakhir = hasil
                    segarkanDaftar(tv)
                }
            }
        }.start()
    }

    /** Daftar tampil: saluran sendiri, hasil pemindaian tersimpan (terverifikasi), lalu daftar daring/cadangan; tanpa alamat ganda. */
    private fun segarkanDaftar(tv: Boolean) {
        val sendiri = RadioTvData.milikSendiri(this, tv)
        val gabung = (sendiri + RadioTvData.hasilPindai(this, tv) + daringTerakhir).distinctBy { it.url }
        isiDaftar(tv, gabung, sendiri.size)
    }

    private fun mulaiPindai(tv: Boolean) {
        if (memindai) { setStatus(tr("Pemindaian sedang berjalan.", "A scan is already running.")); return }
        memindai = true; batalPindai = false
        setStatus(tr("Memulai pemindaian. Mengumpulkan calon saluran…", "Starting the scan. Collecting candidate channels…"))
        Thread {
            val hasil = try {
                RadioTvData.pindai(this, tv, { batalPindai }) { d, t, f ->
                    if (d == t || d % 20 == 0) setStatus(tr("Memindai: ", "Scanning: ") + d + tr(" dari ", " of ") + t + tr(", ditemukan ", ", found ") + f)
                }
            } catch (_: Exception) { -2 }
            memindai = false
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                setStatus(when {
                    hasil == -1 -> tr("Tidak ada calon saluran yang ditemukan. Periksa internet.", "No candidate channels were found. Check the internet.")
                    hasil < 0 -> tr("Pemindaian gagal.", "The scan failed.")
                    batalPindai -> tr("Pemindaian dibatalkan. Saluran yang sudah ditemukan disimpan: ", "The scan was cancelled. Channels found so far are saved: ") + hasil
                    else -> tr("Pemindaian selesai. Saluran yang aktif dan disimpan: ", "The scan finished. Active channels saved: ") + hasil
                })
                segarkanDaftar(tv)
            }
        }.start()
    }

    private fun ubahVolume(arah: Int) {
        val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, if (arah > 0) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER, 0)
        val maks = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        setStatus(tr("Volume ", "Volume ") + (am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / maks) + tr(" persen", " percent"))
    }

    private fun menu() {
        info(tr("Saluran radio dan TV bernuansa Islami (Al-Qur'an, kajian, dakwah). Daftar diambil dari internet saat dibuka, jadi saluran bisa berubah atau sesekali tidak tersedia. Anda juga dapat menambah saluran sendiri.",
            "Islamic-themed radio and TV channels (Quran, lectures, da'wah). The list is fetched from the internet when opened, so channels can change or be occasionally unavailable. You can also add your own channels."))
        tombol(tr("Radio Islami", "Islamic radio")) { startActivity(Intent(this, RadioTvActivity::class.java).putExtra("mode", "radio")) }
        tombol(tr("TV Islami", "Islamic TV")) { startActivity(Intent(this, RadioTvActivity::class.java).putExtra("mode", "tv")) }
    }

    private fun setStatus(t: String) { runOnUiThread { status?.text = t; status?.announceForAccessibility(t) } }

    private fun isiDaftar(tv: Boolean, daftar: List<RadioTvData.Saluran>, sendiri: Int) {
        if (tampilAwal < 0) return
        while (root.childCount > tampilAwal) root.removeViewAt(tampilAwal)
        for ((i, s) in daftar.withIndex()) {
            val label = ui(s.nama) + (if (s.negara.isNotEmpty()) ", " + s.negara else "")
            tombol((if (tv) tr("Tonton: ", "Watch: ") else tr("Dengarkan: ", "Listen: ")) + label) {
                if (tv) startActivity(Intent(this, TvPemutarActivity::class.java).putExtra("nama", s.nama).putExtra("url", s.url))
                else {
                    setStatus(tr("Memuat: ", "Loading: ") + s.nama)
                    PemutarSaluran.putar(this, s) { h ->
                        setStatus(when (h) {
                            "start" -> tr("Diputar: ", "Playing: ") + s.nama
                            "gagal" -> tr("Saluran tidak dapat diputar: ", "The channel could not be played: ") + s.nama
                            else -> tr("Siaran berakhir: ", "The broadcast ended: ") + s.nama
                        })
                    }
                }
            }
            if (i < sendiri) tombol(tr("Hapus saluran sendiri: ", "Remove your channel: ") + ui(s.nama)) { RadioTvData.hapusSendiri(this, tv, s); recreate() }
        }
    }

    private fun dialogTambah(tv: Boolean) {
        val nama = EditText(this).apply { hint = tr("Nama saluran", "Channel name"); inputType = InputType.TYPE_CLASS_TEXT }
        val url = EditText(this).apply { hint = tr("Alamat siaran (http atau https)", "Stream address (http or https)"); inputType = InputType.TYPE_TEXT_VARIATION_URI }
        val kolom = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(48, 16, 48, 0); addView(nama); addView(url) }
        AlertDialog.Builder(this).setTitle(tr("Tambah saluran", "Add a channel")).setView(kolom)
            .setPositiveButton(tr("Simpan", "Save")) { _, _ ->
                if (RadioTvData.tambahSendiri(this, tv, nama.text.toString(), url.text.toString())) { toast(tr("Ditambahkan", "Added")); recreate() }
                else toast(tr("Isi nama dan alamat yang diawali http atau https, dan jangan ganda.", "Enter a name and an address starting with http or https, and no duplicates."))
            }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }
}
