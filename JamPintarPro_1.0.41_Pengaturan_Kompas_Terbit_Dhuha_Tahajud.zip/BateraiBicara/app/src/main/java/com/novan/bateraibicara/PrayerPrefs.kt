package com.novan.bateraibicara

import android.content.Context

/** Preferensi khusus jadwal sholat; seluruh sakelar fitur dimulai nonaktif. */
class PrayerPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
    var enabled: Boolean get() = sp.getBoolean("enabled", false); set(v) = sp.edit().putBoolean("enabled", v).apply()
    var locationSet: Boolean get() = sp.getBoolean("location_set", false); set(v) = sp.edit().putBoolean("location_set", v).apply()
    var lat: Double get() = java.lang.Double.longBitsToDouble(sp.getLong("lat", java.lang.Double.doubleToRawLongBits(0.0))); set(v) = sp.edit().putLong("lat", java.lang.Double.doubleToRawLongBits(v)).apply()
    var lon: Double get() = java.lang.Double.longBitsToDouble(sp.getLong("lon", java.lang.Double.doubleToRawLongBits(0.0))); set(v) = sp.edit().putLong("lon", java.lang.Double.doubleToRawLongBits(v)).apply()
    var place: String get() = sp.getString("place", "Lokasi belum diatur") ?: "Lokasi belum diatur"; set(v) = sp.edit().putString("place", v).apply()
    var method: Int get() = sp.getInt("method", 0).coerceIn(0, PrayerCalc.methodNames.lastIndex); set(v) = sp.edit().putInt("method", v).apply()
    var asrFactor: Int get() = sp.getInt("asr_factor", 1).coerceIn(1, 2); set(v) = sp.edit().putInt("asr_factor", v).apply()
    var use24: Boolean get() = sp.getBoolean("use24", true); set(v) = sp.edit().putBoolean("use24", v).apply()
    var notifyOnly: Boolean get() = sp.getBoolean("notify_only", false); set(v) = sp.edit().putBoolean("notify_only", v).apply()
    var autoOnline: Boolean get() = sp.getBoolean("auto_online", false); set(v) = sp.edit().putBoolean("auto_online", v).apply()
    var fridayDhuhrOff: Boolean get() = sp.getBoolean("friday_dhuhr_off", false); set(v) = sp.edit().putBoolean("friday_dhuhr_off", v).apply()
    var voiceQibla: Boolean get() = sp.getBoolean("voice_qibla", false); set(v) = sp.edit().putBoolean("voice_qibla", v).apply()
    var qiblaHaptic: Boolean get() = sp.getBoolean("qibla_haptic", false); set(v) = sp.edit().putBoolean("qibla_haptic", v).apply()
    var dhuhaAfterSunrise: Int get() = sp.getInt("dhuha_after_sunrise", 20).coerceIn(5, 120); set(v) = sp.edit().putInt("dhuha_after_sunrise", v.coerceIn(5, 120)).apply()
    var tahajudOffset: Int get() = sp.getInt("tahajud_offset", 0).coerceIn(-180, 180); set(v) = sp.edit().putInt("tahajud_offset", v.coerceIn(-180, 180)).apply()
    var volumeMode: Int get() = sp.getInt("volume_mode", 0).coerceIn(0, 2); set(v) = sp.edit().putInt("volume_mode", v).apply()
    var globalSound: String get() = sp.getString("sound_all", "") ?: ""; set(v) = sp.edit().putString("sound_all", v).apply()
    fun reminder(name: String): Boolean = sp.getBoolean("reminder_$name", false)
    fun setReminder(name: String, value: Boolean) { sp.edit().putBoolean("reminder_$name", value).apply() }
    fun adjustment(name: String): Int = sp.getInt("adjust_$name", 0).coerceIn(-30, 30)
    fun setAdjustment(name: String, value: Int) { sp.edit().putInt("adjust_$name", value.coerceIn(-30, 30)).apply() }
    fun sound(name: String): String = sp.getString("sound_$name", "") ?: ""
    fun setSound(name: String, value: String) { sp.edit().putString("sound_$name", value).apply() }
    fun adjustments() = intArrayOf(adjustment("imsak"), adjustment("subuh"), adjustment("terbit"), dhuhaAfterSunrise - 20, adjustment("dzuhur"), adjustment("ashar"), adjustment("maghrib"), adjustment("isya"))
}
