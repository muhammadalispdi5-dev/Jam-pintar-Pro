package com.novan.bateraibicara

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Cadangkan dan pulihkan pengaturan aplikasi ke/dari satu berkas JSON.
 *
 * Yang dicadangkan: seluruh pengaturan pada berkas preferensi "pengaturan" dan "jadwal_sholat"
 * (termasuk lokasi sholat dan pilihan suara). Yang TIDAK dicadangkan: data sementara dan cache
 * (cache hari libur dan Hijriah daring, status tes suara, status Jangan Ganggu yang sedang berjalan,
 * penanda panduan awal), karena semuanya dibuat ulang otomatis.
 *
 * Pemulihan memeriksa seluruh berkas lebih dulu; bila berkas tidak valid, tidak ada yang diubah.
 */
object CadanganPengaturan {
    const val FORMAT = 1
    private const val PENANDA = "JamPintarPro-Cadangan"
    private const val BATAS_BYTE = 2 * 1024 * 1024
    private val berkas = listOf("pengaturan", "jadwal_sholat")
    private val awalanDikecualikan = listOf("hol_", "kal_hijri_online_", "test_playback_")
    private val kunciDikecualikan = setOf(
        "qibla_background_active",
        "prayer_dnd_active_until",
        "prayer_dnd_previous_filter",
        "prayer_dnd_exact_prompted_v2"
    )
    private val polaKunci = Regex("^[A-Za-z0-9_.\\-]{1,80}$")

    private fun dikecualikan(kunci: String): Boolean =
        kunci in kunciDikecualikan || awalanDikecualikan.any { kunci.startsWith(it) }

    private fun entri(nilai: Any?): JSONObject? {
        val e = JSONObject()
        when (nilai) {
            is Boolean -> { e.put("t", "b"); e.put("v", nilai) }
            is Int -> { e.put("t", "i"); e.put("v", nilai) }
            // Long disimpan sebagai teks agar tidak kehilangan ketelitian (koordinat disimpan sebagai bit Long).
            is Long -> { e.put("t", "l"); e.put("v", nilai.toString()) }
            is Float -> { e.put("t", "f"); e.put("v", nilai.toDouble()) }
            is String -> { e.put("t", "s"); e.put("v", nilai) }
            is Set<*> -> {
                val arr = JSONArray()
                for (x in nilai) if (x is String) arr.put(x)
                e.put("t", "ss"); e.put("v", arr)
            }
            else -> return null
        }
        return e
    }

    /** Membuat isi berkas cadangan dari pengaturan saat ini. */
    fun buatJson(context: Context): String {
        val app = context.applicationContext
        val root = JSONObject()
        root.put("penanda", PENANDA)
        root.put("format", FORMAT)
        val versi = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
        root.put("versi_aplikasi", versi)
        root.put("dibuat", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
        val files = JSONObject()
        for (nama in berkas) {
            val sp = app.getSharedPreferences(nama, Context.MODE_PRIVATE)
            val obj = JSONObject()
            for ((kunci, nilai) in sp.all) {
                if (dikecualikan(kunci)) continue
                val e = entri(nilai) ?: continue
                obj.put(kunci, e)
            }
            files.put(nama, obj)
        }
        root.put("berkas", files)
        return root.toString(2)
    }

    /** Membaca isi berkas sebagai teks; null bila tidak terbaca atau melebihi batas ukuran. */
    fun bacaTeks(context: Context, uri: Uri): String? {
        try {
            context.contentResolver.openInputStream(uri)?.use { masuk ->
                val keluar = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = masuk.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > BATAS_BYTE) return null
                    keluar.write(buf, 0, n)
                }
                return keluar.toString("UTF-8")
            }
        } catch (_: Exception) { }
        return null
    }

    /**
     * Memulihkan pengaturan dari [teks]. Mengembalikan jumlah pengaturan yang dipulihkan,
     * atau -1 bila berkas bukan cadangan yang valid (pengaturan saat ini tidak diubah).
     */
    fun pulihkan(context: Context, teks: String): Int {
        val root = try { JSONObject(teks) } catch (_: Exception) { return -1 }
        if (root.optString("penanda") != PENANDA) return -1
        if (root.optInt("format", 0) !in 1..FORMAT) return -1
        val files = root.optJSONObject("berkas") ?: return -1

        // Tahap 1: validasi seluruh isi tanpa mengubah apa pun.
        val rencana = LinkedHashMap<String, LinkedHashMap<String, Any>>()
        for (nama in berkas) {
            val obj = files.optJSONObject(nama) ?: continue
            val peta = LinkedHashMap<String, Any>()
            val kunciIter = obj.keys()
            while (kunciIter.hasNext()) {
                val kunci = kunciIter.next()
                if (!polaKunci.matches(kunci)) return -1
                if (dikecualikan(kunci)) continue
                val e = obj.optJSONObject(kunci) ?: return -1
                val nilai: Any = try {
                    when (e.getString("t")) {
                        "b" -> e.getBoolean("v")
                        "i" -> e.getInt("v")
                        "l" -> e.getString("v").toLong()
                        "f" -> e.getDouble("v").toFloat()
                        "s" -> e.getString("v")
                        "ss" -> {
                            val arr = e.getJSONArray("v")
                            val himpunan = LinkedHashSet<String>()
                            for (i in 0 until arr.length()) himpunan.add(arr.getString(i))
                            himpunan
                        }
                        else -> return -1
                    }
                } catch (_: Exception) { return -1 }
                peta[kunci] = nilai
            }
            rencana[nama] = peta
        }
        if (rencana.isEmpty()) return -1

        // Tahap 2: terapkan. Pengaturan lama diganti; data sementara/cache dibiarkan.
        var jumlah = 0
        val app = context.applicationContext
        for ((nama, peta) in rencana) {
            val sp = app.getSharedPreferences(nama, Context.MODE_PRIVATE)
            val ed = sp.edit()
            for (kunci in sp.all.keys) if (!dikecualikan(kunci)) ed.remove(kunci)
            for ((kunci, nilai) in peta) {
                when (nilai) {
                    is Boolean -> ed.putBoolean(kunci, nilai)
                    is Int -> ed.putInt(kunci, nilai)
                    is Long -> ed.putLong(kunci, nilai)
                    is Float -> ed.putFloat(kunci, nilai)
                    is String -> ed.putString(kunci, nilai)
                    is Set<*> -> ed.putStringSet(kunci, nilai.filterIsInstance<String>().toSet())
                    else -> continue
                }
                jumlah++
            }
            ed.commit()
        }
        return jumlah
    }

    /**
     * Mengembalikan SEMUA pengaturan ke keadaan awal (seperti pemasangan baru): semua sakelar fitur
     * nonaktif dan lokasi sholat dihapus. Cache lokasi/jadwal online ikut dibersihkan. Penanda panduan
     * awal tidak disentuh sehingga rekaman pengantar dan petunjuk tidak diputar ulang; versi aplikasi tidak berubah.
     */
    fun aturUlangSemua(context: Context) {
        val app = context.applicationContext
        for (nama in berkas) {
            val sp = app.getSharedPreferences(nama, Context.MODE_PRIVATE)
            val ed = sp.edit()
            for (kunci in sp.all.keys) if (!dikecualikan(kunci)) ed.remove(kunci)
            ed.commit()
        }
        for (cache in listOf("nama_lokasi", "jadwal_sholat_online")) {
            try { app.getSharedPreferences(cache, Context.MODE_PRIVATE).edit().clear().commit() } catch (_: Exception) { }
        }
        try { app.stopService(android.content.Intent(app, QiblaGuidanceService::class.java)) } catch (_: Exception) { }
        segarkan(app)
    }

    /** Menyegarkan layanan, widget, dan alarm agar sesuai pengaturan yang baru dipulihkan. */
    fun segarkan(context: Context) {
        val app = context.applicationContext
        try {
            if (Prefs(app).enabled) BatteryTalkService.reload(app) else BatteryTalkService.stop(app)
        } catch (_: Exception) { }
        try { BeritahuSayaWidgetProvider.perbaruiSemua(app) } catch (_: Exception) { }
        try { PrayerAlarm.scheduleAll(app) } catch (_: Exception) { }
    }
}
