package com.novan.bateraibicara

import android.Manifest
import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Membaca notifikasi panggilan MASUK (WhatsApp, WhatsApp Bisnis, & aplikasi telepon) lalu mengucapkan
 * nama pemanggil berulang-ulang sampai panggilan dijawab, ditolak, atau berhenti berdering.
 * Panggilan KELUAR (yang kita lakukan sendiri), panggilan yang sedang berlangsung, dan panggilan tak
 * terjawab tidak pernah diumumkan.
 * Dijalankan sistem secara otomatis (termasuk setelah HP dihidupkan ulang) selama
 * "Akses notifikasi" diizinkan.
 */
class CallerListener : NotificationListenerService() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var pembicara: Pembicara? = null

    private var berdering = false
    private var sumber = SUMBER_WA
    private var teks = ""
    private var ulang = 0
    private val kunciAktif = HashSet<String>()
    private var namaAktif = ""

    private var telCallback: Any? = null
    private var telListener: PhoneStateListener? = null

    private val ulangRunnable = Runnable { ucapUlang() }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (prefs.enabled && prefs.pemOn) siapkanPembicara()
        daftarTelepon()
        // Tangani panggilan yang notifikasinya sudah tampil sebelum listener tersambung.
        try { activeNotifications?.forEach { sbn -> proses(sbn) } } catch (_: Exception) { }
    }

    override fun onListenerDisconnected() {
        hentikan()
        lepasTelepon()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        hentikan()
        lepasTelepon()
        pembicara?.matikan()
        pembicara = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try { proses(sbn) } catch (e: Exception) { }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null || !berdering) return
        if (kunciAktif.remove(sbn.key) && kunciAktif.isEmpty()) hentikan()
    }

    // ---------- Deteksi panggilan ----------

    private fun proses(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val bisnis = pkg == "com.whatsapp.w4b"
        val wa = pkg == "com.whatsapp" || bisnis
        if (!wa && !PAKET_TELEPON.containsMatchIn(pkg)) return

        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        val tipe = if (extras.containsKey("android.callType")) extras.getInt("android.callType") else -1
        if (n.category != Notification.CATEGORY_CALL && tipe <= 0) return

        val aktifSaja = prefs.enabled && prefs.pemOn && (if (bisnis) prefs.pemWb else if (wa) prefs.pemWa else prefs.pemTelp)
        val masuk = aktifSaja && apakahMasuk(n, extras, tipe)

        if (!masuk) {
            // Panggilan yang sedang diumumkan berubah menjadi berlangsung / selesai: berhenti.
            if (berdering && kunciAktif.contains(sbn.key)) hentikan()
            return
        }

        val nama = namaPemanggil(extras)
        if (berdering) {
            val sumberBaru = if (bisnis) SUMBER_WB else if (wa) SUMBER_WA else SUMBER_TELP
            if (sumber == sumberBaru && nama == namaAktif) {
                kunciAktif.add(sbn.key) // notifikasi tambahan untuk panggilan yang sama
                return
            }
            hentikan()
        }

        // Judul biasanya nama pemanggil (mis. kontak bernama "Video Studio" bukan panggilan video),
        // jadi judul hanya dipakai bila memuat frasa panggilan video yang jelas.
        val judul = (extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "").lowercase()
        val video = wa && (KATA_VIDEO.containsMatchIn(gabungTeks(n, extras)) || KATA_VIDEO_JUDUL.containsMatchIn(judul))
        mulai(sbn.key, if (bisnis) SUMBER_WB else if (wa) SUMBER_WA else SUMBER_TELP, video, nama)
    }

    /**
     * True hanya untuk panggilan MASUK yang sedang berdering. Urutan pemeriksaan:
     * 1. Jenis panggilan dari sistem (CallStyle): 1 = masuk, 2 = berlangsung/keluar, 3 = disaring.
     * 2. Stopwatch tampil, atau teks berlangsung/tak terjawab/selesai: bukan panggilan berdering.
     * 3. Ada tombol Jawab/Tolak: panggilan masuk. Panggilan keluar hanya punya tombol Akhiri.
     * 4. Teks bernada panggilan keluar (Memanggil, Calling, Berdering, Dialing, ...): bukan masuk.
     * 5. Teks bernada panggilan masuk, atau notifikasi layar penuh tanpa tanda keluar: masuk.
     */
    private fun apakahMasuk(n: Notification, e: Bundle, tipe: Int): Boolean {
        if (tipe > 0) return tipe == 1
        if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) return false
        val t = gabungTeks(n, e)
        if (KATA_SELESAI.containsMatchIn(t)) return false
        if (adaTombolJawab(n)) return true
        if (KATA_KELUAR.containsMatchIn(t)) return false
        if (KATA_MASUK.containsMatchIn(t)) return true
        return n.fullScreenIntent != null
    }

    private fun adaTombolJawab(n: Notification): Boolean {
        val daftar = n.actions ?: return false
        return daftar.any { a ->
            val judulTombol = a.title?.toString()?.lowercase() ?: return@any false
            KATA_TOMBOL_JAWAB.containsMatchIn(judulTombol)
        }
    }

    private fun gabungTeks(n: Notification, e: Bundle): String {
        val daftar = listOf(
            Notification.EXTRA_TEXT, Notification.EXTRA_SUB_TEXT,
            Notification.EXTRA_BIG_TEXT, Notification.EXTRA_INFO_TEXT
        ).mapNotNull { e.getCharSequence(it)?.toString() }
        return (daftar + listOfNotNull(n.tickerText?.toString())).joinToString(" ").lowercase()
    }

    @Suppress("DEPRECATION")
    private fun namaPemanggil(e: Bundle): String {
        var nama = ""
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val p = if (Build.VERSION.SDK_INT >= 33) {
                    e.getParcelable("android.callPerson", android.app.Person::class.java)
                } else {
                    e.getParcelable<android.app.Person>("android.callPerson")
                }
                nama = p?.name?.toString().orEmpty()
            } catch (ex: Exception) { }
        }
        if (nama.isBlank()) nama = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        nama = nama.trim()
        if (nama.any { it.isDigit() } && nama.count { it.isDigit() } >= 5) {
            nama = KontakHelper.namaDariNomor(this, nama, prefs.pemNamaPanggilan) ?: nama
        }
        return nama
    }

    // ---------- Pengumuman berulang ----------

    private fun siapkanPembicara(): Pembicara {
        val s = prefs.suara("pem")
        val ada = pembicara
        if (ada != null && ada.tanda == s.tanda()) return ada
        ada?.matikan()
        val baru = Pembicara(this, s)
        pembicara = baru
        return baru
    }

    private fun mulai(kunci: String, jenisSumber: Int, video: Boolean, nama: String) {
        berdering = true
        sumber = jenisSumber
        namaAktif = nama
        kunciAktif.clear()
        kunciAktif.add(kunci)
        ulang = 0
        teks = susun(this, prefs, jenisSumber == SUMBER_WA || jenisSumber == SUMBER_WB, video, nama, jenisSumber == SUMBER_WB)
        if (prefs.melodiAwalOn) {
            Melodi.putar(this, prefs.melodiAwalIdx, prefs.suara("pem").audioAttributes()) {
                handler.postDelayed({ if (berdering) ucapUlang() }, prefs.jedaMelodiAwal.toLong())
            }
        } else {
            ucapUlang()
        }
    }

    private fun ucapUlang() {
        if (!berdering) return
        val batas = prefs.pemBatas
        if (batas > 0 && ulang >= batas) {
            hentikan()
            return
        }
        ulang++
        siapkanPembicara().ucapkan(teks, ulang == 1) {
            if (berdering) {
                handler.postDelayed(ulangRunnable, (prefs.pemJeda * 1000).toLong())
            }
        }
    }

    private fun hentikan() {
        // Jangan mengulang melodi akhir bila beberapa notifikasi pembaruan datang berurutan.
        val memangAktif = berdering
        berdering = false
        handler.removeCallbacks(ulangRunnable)
        kunciAktif.clear()
        pembicara?.berhenti()
        if (memangAktif && prefs.melodiAkhirOn) {
            handler.postDelayed({
                if (!berdering) Melodi.putar(this, prefs.melodiAkhirIdx, prefs.suara("pem").audioAttributes())
            }, prefs.jedaMelodiAkhir.toLong())
        }
    }

    // ---------- Status telepon seluler (untuk berhenti saat diangkat/ditolak) ----------

    private fun statusTelepon(state: Int) {
        if (berdering && sumber == SUMBER_TELP && state != TelephonyManager.CALL_STATE_RINGING) {
            hentikan()
        }
    }

    private fun daftarTelepon() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        lepasTelepon()
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        handler.post { statusTelepon(state) }
                    }
                }
                tm.registerTelephonyCallback(mainExecutor, cb)
                telCallback = cb
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        statusTelepon(state)
                    }
                }
                @Suppress("DEPRECATION")
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                telListener = l
            }
        } catch (e: Exception) { }
    }

    private fun lepasTelepon() {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val cb = telCallback
            if (Build.VERSION.SDK_INT >= 31 && cb is TelephonyCallback) {
                tm.unregisterTelephonyCallback(cb)
            }
            telListener?.let {
                @Suppress("DEPRECATION")
                tm.listen(it, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) { }
        telCallback = null
        telListener = null
    }

    companion object {
        private const val SUMBER_WA = 1
        private const val SUMBER_TELP = 2
        private const val SUMBER_WB = 3

        private val PAKET_TELEPON =
            Regex("dialer|incall|telecom|phone|oplus|coloros|oppo|miui|contacts")
        // Nada panggilan MASUK. Kata "ringing/berdering/calling/memanggil" sengaja TIDAK di sini:
        // WhatsApp dan aplikasi telepon memakainya juga untuk panggilan keluar.
        private val KATA_MASUK = Regex("incoming|panggilan masuk|masuk")
        // Nada panggilan KELUAR (kita yang menelepon).
        private val KATA_KELUAR = Regex(
            "outgoing|keluar|dialing|dialling|calling|memanggil|menelepon|menelpon|menghubungi|" +
                "connecting|reconnecting|menyambung|ringing|berdering"
        )
        // Tombol pada notifikasi panggilan masuk; panggilan keluar hanya punya tombol Akhiri.
        private val KATA_TOMBOL_JAWAB = Regex("answer|jawab|angkat|accept|terima|decline|reject|tolak")
        private val KATA_VIDEO = Regex("video")
        private val KATA_VIDEO_JUDUL = Regex("video call|videocall|panggilan video")
        private val KATA_SELESAI = Regex(
            "ongoing|berlangsung|connected|tersambung|in call|dalam panggilan|missed|" +
                "tak terjawab|tidak terjawab|terlewat|ended|berakhir|declin|ditolak|" +
                "return to call|kembali ke panggilan"
        )

        /** Nomor tanpa nama dibaca angka per angka. */
        private fun bacaNama(nama: String): String {
            if (nama.isBlank()) return ""
            if (nama.none { it.isLetter() } && nama.count { it.isDigit() } >= 5) {
                return nama.filter { it.isDigit() }.toCharArray().joinToString(" ")
            }
            return nama
        }

        /** Kalimat yang diucapkan untuk satu panggilan. Dipakai juga oleh tombol tes. */
        fun susun(ctx: Context, p: Prefs, wa: Boolean, video: Boolean, nama: String, bisnis: Boolean = false): String {
            val n = bacaNama(nama).ifEmpty { ctx.getString(R.string.nama_tidak_dikenal) }
            val jenis = when {
                bisnis && video -> "Panggilan video WhatsApp Bisnis"
                bisnis -> "Panggilan suara WhatsApp Bisnis"
                wa && video -> "Panggilan video WhatsApp"
                wa -> "Panggilan suara WhatsApp"
                else -> "Panggilan telepon"
            }
            val kalimat = when {
                bisnis && video -> p.pemKalimatWbVideo
                bisnis -> p.pemKalimatWbSuara
                wa && video -> p.pemKalimatWaVideo
                wa -> p.pemKalimatWaSuara
                else -> p.pemKalimatTelp
            }
            val denganJenis = if (p.pemJenis) {
                kalimat.replace("{jenis}", jenis)
            } else {
                kalimat
                    .replace(Regex("\\{jenis\\}\\s*(?:dari|oleh)?\\s*"), "")
                    // Jaga kompatibilitas kalimat lama yang tersimpan sebelum token {jenis} ada.
                    .replace(Regex(("(?i)" + (Regex.escape(jenis)) + "\\s*(?:dari|oleh)?\\s*")), "")
            }
            val denganNama = if (denganJenis.contains("{nama}")) {
                denganJenis.replace("{nama}", n)
            } else ("" + (denganJenis) + " " + (n))
            return denganNama.replace(Regex("\\s+"), " ").trim().trim(',', '.', ':')
        }
    }
}
