package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action.orEmpty()
        val pp = PrayerPrefs(context)
        if (action == "com.novan.jambicarapro.RESTORE_PRAYER_DND") {
            val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
            val until = state.getLong("prayer_dnd_active_until", 0L)
            if (System.currentTimeMillis() >= until && until > 0L) {
                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    val nm = context.getSystemService(android.app.NotificationManager::class.java)
                    if (nm.isNotificationPolicyAccessGranted) {
                        val previous = state.getInt("prayer_dnd_previous_filter", android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
                        try { nm.setInterruptionFilter(previous) } catch (_: Exception) { }
                    }
                }
                state.edit().remove("prayer_dnd_active_until").remove("prayer_dnd_previous_filter").apply()
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        val key = intent.getStringExtra("prayer_key") ?: return
        if (action == "com.novan.jambicarapro.START_PRAYER_DND") {
            if (pp.dndEnabled && pp.locationSet && pp.dndPrayer(key) && android.os.Build.VERSION.SDK_INT >= 23) {
                val nm = context.getSystemService(android.app.NotificationManager::class.java)
                if (nm.isNotificationPolicyAccessGranted) {
                    val state = context.getSharedPreferences("jadwal_sholat", Context.MODE_PRIVATE)
                    val now = System.currentTimeMillis()
                    val oldUntil = state.getLong("prayer_dnd_active_until", 0L)
                    if (oldUntil <= now) state.edit().putInt("prayer_dnd_previous_filter", nm.currentInterruptionFilter).apply()
                    val until = now + pp.dndDuration * 60_000L
                    state.edit().putLong("prayer_dnd_active_until", until).apply()
                    try { nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_ALARMS) } catch (_: Exception) { }
                }
            }
            PrayerAlarm.scheduleAll(context)
            return
        }
        val advance = intent.getBooleanExtra("advance_reminder", false)
        val allowed = if (advance) pp.advanceReminder(key) else pp.reminder(key)
        if (pp.enabled && allowed) {
            val service = Intent(context, PrayerAlarmService::class.java)
                .putExtra("prayer_key", key)
                .putExtra("advance_reminder", advance)
            try { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service) } catch (_: Exception) { }
        }
        PrayerAlarm.scheduleAll(context)
    }
}
