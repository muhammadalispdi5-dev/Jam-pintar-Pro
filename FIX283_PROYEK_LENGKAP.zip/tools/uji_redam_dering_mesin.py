from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
v=t("RedamDering.kt"); c=t("CallerListener.kt"); p=t("Pembicara.kt")
for k in ("object RedamDering","STREAM_RING","volumeDiubahAplikasi","fun pulihkan"):
    if k not in v: g.append("GAGAL RedamDering: "+k)
if c.count("RedamDering.pulihkan(this)")<3: g.append("GAGAL pulihkan dering kurang")
if "RedamDering.redam(" not in c: g.append("GAGAL redam tidak dipanggil")
if "hanyaKecilkanAudioLain = hanyaDuck" not in c: g.append("GAGAL fokus penuh panggilan")
for k in ("fun pulihkanMesin","pulihBeruntun","val tertunda = ArrayList(callbacks.values)","panggil || item != null"):
    if k not in p: g.append("GAGAL Pembicara: "+k)
if "pemRedamDering" not in t("Prefs.kt") or "pemRedamDering" not in t("PemanggilActivity.kt"): g.append("GAGAL sakelar redam dering")
print("\n".join(g) if g else "UJI REDAM DERING MESIN: LULUS")
