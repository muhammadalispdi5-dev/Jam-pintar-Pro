package com.novan.bateraibicara

import android.content.Context

/**
 * FIX283: saat pengumuman panggilan diucapkan, volume NADA DERING diredam sementara (bukan suara pengumuman), lalu dikembalikan
 * begitu pengumuman selesai. Dilewati bila pengumuman memakai saluran dering/notifikasi/sistem (saluran itu sama dengan dering),
 * bila HP tidak dalam mode dering normal, atau bila pengguna mematikan pilihannya.
 */
object RedamDering {
    private var awal = -1
    private var diterapkan = -1
    private var app: Context? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pengaman = Runnable { app?.let { pulihkan(it) } }

    fun redam(ctx: Context, streamPengumuman: Int) {
        try {
            if (streamPengumuman == android.media.AudioManager.STREAM_RING || streamPengumuman == android.media.AudioManager.STREAM_NOTIFICATION ||
                streamPengumuman == android.media.AudioManager.STREAM_SYSTEM) return
            if (!PrefsPemanggil.redamDering(ctx)) return
            if (awal >= 0) return
            val am = ctx.applicationContext.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            if (am.ringerMode != android.media.AudioManager.RINGER_MODE_NORMAL) return
            val sekarang = am.getStreamVolume(android.media.AudioManager.STREAM_RING)
            if (sekarang <= 1) return
            val target = (sekarang * 0.25f).toInt().coerceAtLeast(1)
            app = ctx.applicationContext
            PembungkamTelungkup.volumeDiubahAplikasi()
            am.setStreamVolume(android.media.AudioManager.STREAM_RING, target, 0)
            PembungkamTelungkup.volumeDiubahAplikasi()
            awal = sekarang
            diterapkan = am.getStreamVolume(android.media.AudioManager.STREAM_RING)
            handler.removeCallbacks(pengaman); handler.postDelayed(pengaman, 120_000L)
        } catch (_: Exception) { awal = -1 }
    }

    fun pulihkan(ctx: Context) {
        handler.removeCallbacks(pengaman)
        if (awal < 0) return
        val nilai = awal
        awal = -1
        try {
            val am = ctx.applicationContext.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            // Hanya bila belum diubah pengguna sejak diredam.
            if (am.getStreamVolume(android.media.AudioManager.STREAM_RING) == diterapkan) {
                PembungkamTelungkup.volumeDiubahAplikasi()
                am.setStreamVolume(android.media.AudioManager.STREAM_RING, nilai, 0)
                PembungkamTelungkup.volumeDiubahAplikasi()
            }
        } catch (_: Exception) { }
    }
}

object PrefsPemanggil {
    fun redamDering(ctx: Context): Boolean = Prefs(ctx).pemRedamDering
}

