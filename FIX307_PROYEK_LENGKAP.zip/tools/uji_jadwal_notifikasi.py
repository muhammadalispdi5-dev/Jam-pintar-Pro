b='app/src/main/java/com/novan/bateraibicara/'
g=0
def cek(c,m):
    global g
    if not c: print("GAGAL",m); g+=1
j=open(b+'JadwalNotifikasi.kt').read()
cek('setChronometerCountDown' in j and 'sudah lewat' in j and 'AKSI_PERBARUI' in j,'notifikasi')
cek('JadwalNotifikasi.perbarui' in open(b+'PrayerAlarm.kt').read(),'scheduleAll')
cek('AKSI_PERBARUI' in open(b+'PrayerAlarmReceiver.kt').read(),'receiver')
m=open(b+'MainActivity.kt').read()
cek('lanjutPasangSetelahIzin' in m and 'update_terbaru_terpasang' in m,'pembaruan')
cek('versionCode = 90' in open('app/build.gradle.kts').read(),'versi')
print("selesai",g)
