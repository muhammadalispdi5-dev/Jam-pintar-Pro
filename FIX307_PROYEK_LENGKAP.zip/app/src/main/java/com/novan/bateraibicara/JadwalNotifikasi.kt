package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.util.Calendar

/**
 * FIX307: notifikasi jadwal salat di layar pemberitahuan (seperti aplikasi azan populer).
 * Menampilkan waktu berikutnya dengan hitung mundur, dan daftar waktu hari ini beserta keterangan
 * "sudah lewat" / "berikutnya" dalam kata (agar terbaca jelas oleh TalkBack). Diperbarui setiap waktu salat tiba.
 */
object JadwalNotifikasi {
    private const val KANAL = "jadwal_sholat_harian"
    private const val ID_NOTIF = 8120
    const val AKSI_PERBARUI = "com.novan.jambicarapro.REFRESH_PRAYER_NOTIF"
    private val kunci = listOf("subuh", "terbit", "dzuhur", "ashar", "maghrib", "isya")

    private fun milis(tanggal: LocalDate, menit: Int): Long = Calendar.getInstance().apply {
        set(Calendar.YEAR, tanggal.year); set(Calendar.MONTH, tanggal.monthValue - 1); set(Calendar.DAY_OF_MONTH, tanggal.dayOfMonth)
        set(Calendar.HOUR_OF_DAY, menit / 60); set(Calendar.MINUTE, menit % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun jam(menit: Int) = String.format(java.util.Locale.US, "%02d:%02d", menit / 60, menit % 60)

    private fun pendingPerbarui(c: Context): PendingIntent {
        val i = Intent(c, PrayerAlarmReceiver::class.java).setAction(AKSI_PERBARUI).putExtra("prayer_key", "notif")
        return PendingIntent.getBroadcast(c, 7990, i, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    }

    fun perbarui(context: Context) {
        val c = context.applicationContext
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val pp = PrayerPrefs(c)
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!pp.jadwalNotif || !pp.locationSet) {
                nm.cancel(ID_NOTIF)
                try { am.cancel(pendingPerbarui(c)) } catch (_: Exception) { }
                return
            }
            val en = BahasaAplikasi.tampilan(c) == 1
            fun tr(id: String, e: String) = if (en) e else id
            val sekarang = System.currentTimeMillis()
            val hariIni = LocalDate.now()
            val menit = kunci.map { PrayerAlarm.prayerMinutes(c, pp, hariIni, it) }
            val waktu = menit.map { milis(hariIni, it) }
            val idxBerikut = waktu.indexOfFirst { it > sekarang }
            val namaBerikut: String; val menitBerikut: Int; val milisBerikut: Long
            if (idxBerikut >= 0) {
                namaBerikut = PrayerAlarm.label(kunci[idxBerikut]); menitBerikut = menit[idxBerikut]; milisBerikut = waktu[idxBerikut]
            } else {
                val besok = hariIni.plusDays(1)
                menitBerikut = PrayerAlarm.prayerMinutes(c, pp, besok, kunci[0]); namaBerikut = PrayerAlarm.label(kunci[0]); milisBerikut = milis(besok, menitBerikut)
            }
            val baris = ArrayList<String>()
            for ((n, k) in kunci.withIndex()) {
                val ket = when {
                    idxBerikut == n || (idxBerikut < 0 && false) -> tr("berikutnya", "next")
                    waktu[n] <= sekarang -> tr("sudah lewat", "passed")
                    else -> tr("akan datang", "upcoming")
                }
                baris.add(PrayerAlarm.label(k) + " " + jam(menit[n]) + " (" + ket + ")")
            }
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(KANAL) == null) {
                val ch = NotificationChannel(KANAL, tr("Jadwal salat harian", "Daily prayer times"), NotificationManager.IMPORTANCE_LOW)
                ch.setSound(null, null); ch.enableVibration(false)
                nm.createNotificationChannel(ch)
            }
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, KANAL) else Notification.Builder(c)
            val buka = PendingIntent.getActivity(c, 7991, Intent(c, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val ringkas = tr("Berikutnya: ", "Next: ") + namaBerikut + " " + jam(menitBerikut)
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(ringkas)
                .setContentText(baris.joinToString(" · "))
                .setContentIntent(buka).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(true).setWhen(milisBerikut)
            if (Build.VERSION.SDK_INT >= 24) { b.setUsesChronometer(true); b.setChronometerCountDown(true) }
            b.setStyle(Notification.BigTextStyle().bigText(baris.joinToString("\n")))
            nm.notify(ID_NOTIF, b.build())
            // Perbarui lagi tepat saat waktu berikutnya tiba (lalu keterangan "sudah lewat/berikutnya" bergeser).
            val pi = pendingPerbarui(c)
            val picu = milisBerikut + 1_000L
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, picu, pi)
                else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, picu, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, picu, pi)
            } catch (_: Exception) { try { am.set(AlarmManager.RTC_WAKEUP, picu, pi) } catch (_: Exception) { } }
        } catch (_: Exception) { }
    }
}
