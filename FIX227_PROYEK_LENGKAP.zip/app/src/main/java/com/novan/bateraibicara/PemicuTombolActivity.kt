package com.novan.bateraibicara

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Button
import android.widget.TextView

/**
 * FIX227: memilih tombol fisik yang membuka asisten/perintah suara. Pilihan disimpan di pengaturan, lalu dijalankan
 * oleh [TombolSuaraAccessibilityService] (harus diaktifkan pengguna di Pengaturan > Aksesibilitas).
 * Layar ini juga memiliki uji tombol yang bekerja selama layar ini terbuka, tanpa layanan.
 */
class PemicuTombolActivity : Halaman() {
    override val judulHalaman = R.string.judul_pemicu_tombol

    private val pengaturan by lazy { getSharedPreferences("pengaturan", Context.MODE_PRIVATE) }
    private val pilihan = ArrayList<Pair<PemicuTombol.Mode, Button>>()
    private lateinit var statusLayanan: TextView
    private lateinit var statusUji: TextView
    private lateinit var tombolDurasi: Button
    private var ujiAktif = false
    private val detektorUji = PemicuTombol()
    private val daftarDurasi = intArrayOf(500, 800, 1200, 1600, 2000)

    private fun namaMode(m: PemicuTombol.Mode): String = when (m) {
        PemicuTombol.Mode.NONAKTIF -> tr("Nonaktif (tidak memakai tombol)", "Off (do not use buttons)")
        PemicuTombol.Mode.TAHAN_ATAS -> tr("Tahan tombol volume atas", "Hold volume up")
        PemicuTombol.Mode.TAHAN_BAWAH -> tr("Tahan tombol volume bawah", "Hold volume down")
        PemicuTombol.Mode.DUA_VOLUME -> tr("Tekan volume atas dan bawah bersamaan", "Press volume up and down together")
        PemicuTombol.Mode.DUA_KALI_ATAS -> tr("Tekan volume atas dua kali cepat", "Double-press volume up")
        PemicuTombol.Mode.DUA_KALI_BAWAH -> tr("Tekan volume bawah dua kali cepat", "Double-press volume down")
        PemicuTombol.Mode.AKSESIBILITAS -> tr("Tombol aksesibilitas (tombol atau gestur aksesibilitas sistem)", "Accessibility button (system accessibility button or gesture)")
    }

    private fun modeSaatIni(): PemicuTombol.Mode = PemicuTombol.modeDariIndeks(pengaturan.getInt(TombolSuaraAccessibilityService.KEY_MODE, 0))
    private fun durasiSaatIni(): Int = pengaturan.getInt(TombolSuaraAccessibilityService.KEY_TAHAN_MS, 800).coerceIn(400, 3000)

    private fun labelPilihan(m: PemicuTombol.Mode): String =
        (if (m == modeSaatIni()) tr("Dipilih: ", "Selected: ") else "") + namaMode(m)

    private fun labelDurasi(): String {
        val detik = durasiSaatIni() / 1000.0
        val teks = String.format(java.util.Locale.US, "%.1f", detik).let { if (BahasaAplikasi.tampilan(this) == 1) it else it.replace('.', ',') }
        return tr("Lama menahan tombol: ", "Hold time: ") + teks + tr(" detik. Ketuk untuk mengubah.", " seconds. Tap to change.")
    }

    override fun bangun() {
        bagian(tr("Pilih tombol pemicu asisten suara", "Choose the voice assistant button"), 22f)
        info(tr(
            "Pilih tombol di HP Anda yang membuka asisten atau perintah suara, sesuai kebiasaan Anda. Setelah memilih, aktifkan layanan aksesibilitas \"Jam Pintar Pro: pemicu tombol perintah suara\" di Pengaturan Aksesibilitas agar tombol dapat dikenali, termasuk saat layar mati atau terkunci. Layanan ini hanya menerima tekanan tombol volume dan tombol aksesibilitas; ia tidak membaca isi layar dan tidak merekam suara.",
            "Choose which phone button opens the voice assistant or voice commands, to suit your habits. After choosing, turn on the accessibility service \"Jam Pintar Pro: voice command button trigger\" in Accessibility settings so the button can be recognized, including when the screen is off or locked. The service only receives volume button presses and the accessibility button; it does not read the screen and does not record audio."
        ))

        subjudul(tr("Status layanan", "Service status"))
        statusLayanan = info("")
        tombol(tr("Buka pengaturan aksesibilitas", "Open accessibility settings")) {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {
                toast(tr("Pengaturan aksesibilitas tidak dapat dibuka.", "Accessibility settings could not be opened."))
            }
        }
        tombol(tr("Buka info aplikasi (untuk mengizinkan pengaturan terbatas)", "Open app info (to allow restricted settings)")) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) { }
        }
        info(tr(
            "Jika layanan tidak dapat dinyalakan dan muncul pesan pengaturan dibatasi (Android 13 ke atas untuk aplikasi yang dipasang dari berkas APK): buka info aplikasi, ketuk titik tiga di pojok kanan atas, pilih Izinkan pengaturan terbatas, lalu ulangi mengaktifkan layanan.",
            "If the service cannot be turned on and a restricted settings message appears (Android 13 and later for apps installed from an APK file): open app info, tap the three dots at the top right, choose Allow restricted settings, then try enabling the service again."
        ))

        subjudul(tr("Pilihan tombol", "Button choices"))
        PemicuTombol.Mode.values().forEach { m ->
            val b = tombol(labelPilihan(m)) {
                pengaturan.edit().putInt(TombolSuaraAccessibilityService.KEY_MODE, m.ordinal).apply()
                segarkan()
                val pesan = tr("Dipilih: ", "Selected: ") + namaMode(m)
                statusUji.announceForAccessibility(pesan)
                if (m != PemicuTombol.Mode.NONAKTIF && !PemicuSuara.layananAktif(this)) {
                    toast(tr("Pilihan disimpan. Aktifkan layanan aksesibilitas agar tombol bekerja.", "Choice saved. Turn on the accessibility service so the button works."))
                }
            }
            pilihan.add(m to b)
        }
        tombolDurasi = tombol(labelDurasi()) {
            val i = daftarDurasi.indexOfFirst { it >= durasiSaatIni() }.let { if (it < 0) 0 else if (daftarDurasi[it] == durasiSaatIni()) (it + 1) % daftarDurasi.size else it }
            pengaturan.edit().putInt(TombolSuaraAccessibilityService.KEY_TAHAN_MS, daftarDurasi[i]).apply()
            segarkan()
            tombolDurasi.announceForAccessibility(labelDurasi())
        }

        subjudul(tr("Uji tombol", "Test the button"))
        info(tr(
            "Nyalakan uji, lalu lakukan pola tombol yang Anda pilih di layar ini. Selama uji, tombol volume tidak mengubah volume. Matikan uji setelah selesai.",
            "Turn the test on, then perform the button pattern you chose on this screen. During the test the volume buttons do not change the volume. Turn the test off when finished."
        ))
        val tombolUji = tombol(tr("Mulai uji tombol", "Start button test")) { }
        tombolUji.setOnClickListener {
            ujiAktif = !ujiAktif
            detektorUji.reset()
            tombolUji.text = if (ujiAktif) tr("Hentikan uji tombol", "Stop button test") else tr("Mulai uji tombol", "Start button test")
            statusUji.text = if (ujiAktif) tr("Uji aktif. Lakukan pola tombol Anda.", "Test is on. Perform your button pattern.") else tr("Uji dimatikan.", "Test is off.")
            statusUji.announceForAccessibility(statusUji.text)
        }
        statusUji = info(tr("Uji belum dimulai.", "Test has not started."))

        subjudul(tr("Catatan penting", "Important notes"))
        info(tr(
            "Tombol daya: Android tidak mengizinkan aplikasi biasa menangkap tombol daya. Untuk tombol daya, gunakan pengaturan bawaan HP (misalnya tekan lama tombol daya untuk asisten) pada pengaturan asisten digital bawaan sistem.\nTombol aksesibilitas: tersedia pada Android 8 ke atas. Pada Android 11 ke atas Anda dapat memilih layanan ini sebagai pintasan tombol aksesibilitas di pengaturan aksesibilitas; sebagian HP menampilkan tombol aksesibilitas di bilah navigasi, sebagian memakai gestur dua jari atau tiga jari.\nVolume dua kali, tahan, atau bersamaan: tekanan pertama pada mode tahan mengubah volume satu langkah, yang langsung dikembalikan saat pola dikenali. Selama panggilan telepon pemicu volume dinonaktifkan agar tidak mengganggu.\nBila pintasan volume bawaan Android (tahan kedua tombol volume 3 detik) sedang aktif untuk layanan aksesibilitas lain, pilih pola yang berbeda.",
            "Power button: Android does not let ordinary apps capture the power button. For the power button, use your phone's built-in setting (for example press and hold power for the assistant) in the system's default digital assistant settings.\nAccessibility button: available on Android 8 and later. On Android 11 and later you can select this service as the accessibility button shortcut in accessibility settings; some phones show the accessibility button in the navigation bar, others use a two-finger or three-finger gesture.\nDouble-press, hold, or both volume buttons: in hold mode the first press changes the volume by one step, which is restored when the pattern is recognized. Volume triggers are disabled during phone calls so they do not interfere.\nIf Android's built-in shortcut (hold both volume keys for 3 seconds) is enabled for another accessibility service, choose a different pattern."
        ))
        segarkan()
    }

    override fun onResume() {
        super.onResume()
        if (::statusLayanan.isInitialized) segarkan()
    }

    private fun segarkan() {
        val aktif = PemicuSuara.layananAktif(this)
        statusLayanan.text = if (aktif) tr("Layanan aksesibilitas pemicu tombol: AKTIF.", "Button trigger accessibility service: ON.")
            else tr("Layanan aksesibilitas pemicu tombol: BELUM AKTIF. Aktifkan di Pengaturan Aksesibilitas.", "Button trigger accessibility service: OFF. Turn it on in Accessibility settings.")
        pilihan.forEach { (m, b) -> b.text = ui(labelPilihan(m)) }
        tombolDurasi.text = ui(labelDurasi())
        detektorUji.mode = modeSaatIni()
        detektorUji.tahanMs = durasiSaatIni().toLong()
    }

    private fun subjudul(teks: String) = bagian(teks, 18f)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (ujiAktif && (event.keyCode == KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            val m = modeSaatIni()
            if (m == PemicuTombol.Mode.AKSESIBILITAS || m == PemicuTombol.Mode.NONAKTIF) {
                val pesan = tr("Mode yang dipilih tidak memakai tombol volume.", "The selected mode does not use the volume buttons.")
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) statusUji.text = pesan
                return true
            }
            val h = detektorUji.proses(event.keyCode, event.action == KeyEvent.ACTION_DOWN, event.repeatCount, event.eventTime, event.downTime)
            if (h == PemicuTombol.Hasil.PICU) {
                val pesan = tr("Pola tombol dikenali. Perintah suara akan terbuka bila ini terjadi di luar uji.", "Button pattern recognized. Voice commands would open if this happened outside the test.")
                statusUji.text = pesan
                statusUji.announceForAccessibility(pesan)
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
