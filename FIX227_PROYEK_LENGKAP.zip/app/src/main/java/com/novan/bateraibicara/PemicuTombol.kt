package com.novan.bateraibicara

/**
 * FIX227: pendeteksi pola tombol fisik untuk membuka perintah suara. Kelas ini murni logika (tanpa Android)
 * agar dapat diuji terpisah. Dipanggil dari satu thread dengan cap waktu dalam milidetik.
 *
 * Pola yang didukung (mode):
 *  - TAHAN_ATAS / TAHAN_BAWAH: tombol volume ditahan selama [tahanMs].
 *  - DUA_VOLUME: volume atas dan bawah ditekan bersamaan (selisih paling lama [SELISIH_BERSAMAAN_MS]).
 *  - DUA_KALI_ATAS / DUA_KALI_BAWAH: tombol volume ditekan dua kali cepat (jeda paling lama [JEDA_DUA_KALI_MS]).
 *  - AKSESIBILITAS: dipicu oleh tombol aksesibilitas sistem, bukan oleh tombol fisik (ditangani layanan).
 *
 * Hasil: LEWAT = teruskan ke sistem (volume bekerja biasa); TELAN = jangan teruskan (mis. pengulangan saat ditahan);
 * PICU = pola dikenali (peristiwa ditelan dan perintah suara dibuka).
 */
class PemicuTombol {
    enum class Mode { NONAKTIF, TAHAN_ATAS, TAHAN_BAWAH, DUA_VOLUME, DUA_KALI_ATAS, DUA_KALI_BAWAH, AKSESIBILITAS }
    enum class Hasil { LEWAT, TELAN, PICU }

    var mode: Mode = Mode.NONAKTIF
        set(nilai) { if (field != nilai) { field = nilai; reset() } }
    var tahanMs: Long = 800L

    private var atasTekan = false
    private var bawahTekan = false
    private var sudahPicu = false
    private var tekanTerakhirAtas = -1_000_000L
    private var tekanTerakhirBawah = -1_000_000L
    private var waktuAtas = 0L
    private var waktuBawah = 0L

    fun reset() {
        atasTekan = false; bawahTekan = false; sudahPicu = false
        tekanTerakhirAtas = -1_000_000L; tekanTerakhirBawah = -1_000_000L
    }

    /**
     * @param kode KEYCODE_VOLUME_UP (24) atau KEYCODE_VOLUME_DOWN (25); kode lain selalu LEWAT.
     * @param turun true untuk ACTION_DOWN, false untuk ACTION_UP
     * @param ulang repeatCount peristiwa
     * @param waktu waktu peristiwa (ms)
     * @param waktuTekan downTime (ms) saat tombol mulai ditekan
     */
    fun proses(kode: Int, turun: Boolean, ulang: Int, waktu: Long, waktuTekan: Long): Hasil {
        val atas = kode == KODE_ATAS
        val bawah = kode == KODE_BAWAH
        if (!atas && !bawah) return Hasil.LEWAT
        if (mode == Mode.NONAKTIF || mode == Mode.AKSESIBILITAS) return Hasil.LEWAT

        if (!turun) {
            val telan = sudahPicu
            if (atas) atasTekan = false else bawahTekan = false
            if (!atasTekan && !bawahTekan) sudahPicu = false
            return if (telan) Hasil.TELAN else Hasil.LEWAT
        }

        if (ulang == 0) {
            if (atas) { atasTekan = true; waktuAtas = waktuTekan } else { bawahTekan = true; waktuBawah = waktuTekan }
        }

        return when (mode) {
            Mode.TAHAN_ATAS -> tahan(atas, ulang, waktu, waktuTekan, true)
            Mode.TAHAN_BAWAH -> tahan(bawah, ulang, waktu, waktuTekan, false)
            Mode.DUA_VOLUME -> {
                if (ulang > 0) return if (sudahPicu) Hasil.TELAN else Hasil.LEWAT
                val lain = if (atas) bawahTekan else atasTekan
                val waktuLain = if (atas) waktuBawah else waktuAtas
                if (lain && !sudahPicu && kotlin.math.abs(waktuTekan - waktuLain) <= SELISIH_BERSAMAAN_MS) {
                    sudahPicu = true
                    Hasil.PICU
                } else Hasil.LEWAT
            }
            Mode.DUA_KALI_ATAS -> duaKali(atas, ulang, waktuTekan, true)
            Mode.DUA_KALI_BAWAH -> duaKali(bawah, ulang, waktuTekan, false)
            else -> Hasil.LEWAT
        }
    }

    private fun tahan(sasaran: Boolean, ulang: Int, waktu: Long, waktuTekan: Long, atas: Boolean): Hasil {
        if (!sasaran) return Hasil.LEWAT
        // Tekanan pertama diteruskan (volume berubah satu langkah; layanan mengembalikannya saat pola dikenali).
        if (ulang == 0) return Hasil.LEWAT
        if (sudahPicu) return Hasil.TELAN
        if (waktu - waktuTekan >= tahanMs) {
            sudahPicu = true
            return Hasil.PICU
        }
        // Pengulangan sebelum batas waktu ditelan agar volume tidak berubah terus selama ditahan.
        return Hasil.TELAN
    }

    private fun duaKali(sasaran: Boolean, ulang: Int, waktuTekan: Long, atas: Boolean): Hasil {
        if (!sasaran || ulang > 0) return if (sudahPicu && sasaran) Hasil.TELAN else Hasil.LEWAT
        val terakhir = if (atas) tekanTerakhirAtas else tekanTerakhirBawah
        if (waktuTekan - terakhir <= JEDA_DUA_KALI_MS) {
            if (atas) tekanTerakhirAtas = -1_000_000L else tekanTerakhirBawah = -1_000_000L
            sudahPicu = true
            return Hasil.PICU
        }
        if (atas) tekanTerakhirAtas = waktuTekan else tekanTerakhirBawah = waktuTekan
        return Hasil.LEWAT
    }

    companion object {
        const val KODE_ATAS = 24
        const val KODE_BAWAH = 25
        const val SELISIH_BERSAMAAN_MS = 450L
        const val JEDA_DUA_KALI_MS = 600L

        fun modeDariIndeks(i: Int): Mode = Mode.values().getOrElse(i) { Mode.NONAKTIF }
    }
}
