import com.novan.bateraibicara.PemicuTombol
import com.novan.bateraibicara.PemicuTombol.Hasil
import com.novan.bateraibicara.PemicuTombol.Mode
fun main() {
    val U = 24; val B = 25
    var gagal = 0
    fun cek(n: String, ok: Boolean) { println((if (ok) "OK   " else "GAGAL") + " " + n); if (!ok) gagal++ }
    // Tahan volume atas 800 ms; repeat mulai ~500ms tiap 50ms
    run {
        val p = PemicuTombol(); p.mode = Mode.TAHAN_ATAS; p.tahanMs = 800
        val h0 = p.proses(U, true, 0, 0, 0)
        var picu = 0; var waktuPicu = -1L
        var t = 500L
        while (t <= 1500) { val h = p.proses(U, true, ((t - 450) / 50).toInt(), t, 0); if (h == Hasil.PICU) { picu++; waktuPicu = t }; t += 50 }
        val up = p.proses(U, false, 0, 1550, 0)
        cek("tahan atas: tekan pertama lewat", h0 == Hasil.LEWAT)
        cek("tahan atas: picu sekali pada >=800ms (t=$waktuPicu)", picu == 1 && waktuPicu in 800..850)
        cek("tahan atas: lepas ditelan", up == Hasil.TELAN)
        cek("tahan atas: tekan singkat berikutnya lewat", p.proses(U, true, 0, 3000, 3000) == Hasil.LEWAT && p.proses(U, false, 0, 3100, 3000) == Hasil.LEWAT)
    }
    run {
        val p = PemicuTombol(); p.mode = Mode.TAHAN_ATAS
        p.proses(B, true, 0, 0, 0); var pic = false
        for (t in 500L..1500L step 50) if (p.proses(B, true, 5, t, 0) == Hasil.PICU) pic = true
        cek("tahan atas: volume bawah tidak memicu", !pic)
    }
    run {
        val p = PemicuTombol(); p.mode = Mode.TAHAN_BAWAH; p.tahanMs = 500
        p.proses(B, true, 0, 0, 0); var pic = 0
        for (t in 500L..1000L step 50) if (p.proses(B, true, 1, t, 0) == Hasil.PICU) pic++
        cek("tahan bawah 500ms picu sekali", pic == 1)
    }
    run {
        val p = PemicuTombol(); p.mode = Mode.TAHAN_ATAS; p.tahanMs = 1200
        p.proses(U, true, 0, 0, 0); var pic = false
        for (t in 500L..1000L step 50) if (p.proses(U, true, 1, t, 0) == Hasil.PICU) pic = true
        p.proses(U, false, 0, 1050, 0)
        cek("tahan 1200: dilepas pada 1000ms tidak memicu", !pic)
    }
    run {
        val p = PemicuTombol(); p.mode = Mode.DUA_VOLUME
        val a = p.proses(U, true, 0, 100, 100)
        val b = p.proses(B, true, 0, 250, 250)
        cek("dua volume bersamaan memicu", a == Hasil.LEWAT && b == Hasil.PICU)
        cek("dua volume: lepas ditelan lalu reset", p.proses(U, false, 0, 400, 100) == Hasil.TELAN && p.proses(B, false, 0, 420, 250) == Hasil.TELAN)
        val c = p.proses(U, true, 0, 2000, 2000)
        cek("dua volume: satu tombol saja tidak memicu", c == Hasil.LEWAT)
        p.proses(U, false, 0, 2050, 2000)
        p.proses(U, true, 0, 3000, 3000); val d = p.proses(B, true, 0, 3900, 3900)
        cek("dua volume: selisih 900ms tidak memicu", d == Hasil.LEWAT)
    }
    run {
        val p = PemicuTombol(); p.mode = Mode.DUA_KALI_ATAS
        val a = p.proses(U, true, 0, 0, 0); p.proses(U, false, 0, 80, 0)
        val b = p.proses(U, true, 0, 300, 300)
        cek("dua kali atas memicu pada tekan kedua", a == Hasil.LEWAT && b == Hasil.PICU)
        p.proses(U, false, 0, 380, 300)
        val c = p.proses(U, true, 0, 5000, 5000)
        cek("dua kali: tekan tunggal setelah jeda lewat", c == Hasil.LEWAT)
        p.proses(U, false, 0, 5050, 5000)
        val d = p.proses(U, true, 0, 5900, 5900)
        cek("dua kali: jeda 900ms tidak memicu", d == Hasil.LEWAT)
    }
    run {
        val p = PemicuTombol(); p.mode = Mode.NONAKTIF
        cek("nonaktif: semua lewat", p.proses(U, true, 3, 900, 0) == Hasil.LEWAT)
        p.mode = Mode.AKSESIBILITAS
        cek("aksesibilitas: tombol fisik lewat", p.proses(U, true, 3, 900, 0) == Hasil.LEWAT)
        p.mode = Mode.TAHAN_ATAS
        cek("kode lain lewat", p.proses(26, true, 3, 900, 0) == Hasil.LEWAT)
    }
    println(if (gagal == 0) "SEMUA LULUS" else "GAGAL: $gagal")
    if (gagal > 0) kotlin.system.exitProcess(1)
}
