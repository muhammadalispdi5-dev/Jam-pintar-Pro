package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.util.Locale

/** Membacakan lokasi GPS terkini dengan kontrol yang dapat dijelajahi pembaca layar. */
class LokasiTerkiniActivity : Halaman() {
    override val judulHalaman = R.string.judul_lokasi_terkini

    private lateinit var status: android.widget.TextView
    private var lokasiTerakhir: Location? = null
    private var namaLokasiTerakhir: String? = null
    private var sedangMencari = false
    private val handler = Handler(Looper.getMainLooper())
    private var manager: LocationManager? = null
    private var listener: LocationListener? = null

    override fun bangun() {
        info("Gunakan tombol Perbarui lokasi terkini untuk mengetahui tempat Anda berada. Jam Pintar Pro akan mencoba membaca nama jalan, kawasan, kelurahan atau desa, kota, dan provinsi bila layanan nama tempat tersedia. Koordinat dan perkiraan akurasi juga akan dibacakan. Lokasi tidak dikirim ke pengembang.")
        status = info("Lokasi belum diminta. Tekan Perbarui lokasi terkini.")
        tombol("Perbarui lokasi terkini") { perbaruiLokasi() }
        tombol("Bacakan kembali lokasi terakhir") {
            val l = lokasiTerakhir
            if (l == null) toast("Lokasi belum tersedia. Tekan Perbarui lokasi terkini terlebih dahulu.")
            else bacakanLokasi(l, namaLokasiTerakhir)
        }
        tombol("Buka lokasi terakhir di peta") {
            val l = lokasiTerakhir
            if (l == null) toast("Lokasi belum tersedia. Perbarui lokasi terlebih dahulu.")
            else {
                val uri = Uri.parse("geo:${l.latitude},${l.longitude}?q=${l.latitude},${l.longitude}(Lokasi%20terkini)")
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                catch (_: Exception) { toast("Aplikasi peta tidak tersedia.") }
            }
        }
        tombol("Buka setelan lokasi perangkat") {
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            catch (_: Exception) { toast("Setelan lokasi tidak dapat dibuka.") }
        }
    }

    override fun onDestroy() {
        berhentiMencari()
        super.onDestroy()
    }

    private fun perbaruiLokasi() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 715)
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        manager = lm
        val penyedia = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        if (penyedia.isEmpty()) {
            status.text = "Layanan lokasi perangkat sedang mati. Aktifkan lokasi lalu coba lagi."
            toast("Layanan lokasi sedang mati.")
            return
        }
        berhentiMencari()
        sedangMencari = true
        lokasiTerakhir = null
        status.text = "Sedang mencari lokasi terkini. Mohon tunggu hingga 20 detik."
        val callback = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (location.accuracy <= 0f || location.accuracy > 10_000f) return
                val old = lokasiTerakhir
                if (old == null || location.accuracy < old.accuracy || location.time > old.time + 30_000L) {
                    lokasiTerakhir = location
                    if (location.accuracy <= 1_000f) selesaiDenganLokasi(location)
                }
            }
            @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        listener = callback
        try {
            for (p in penyedia) {
                try {
                    @Suppress("MissingPermission")
                    lm.requestLocationUpdates(p, 1_000L, 0f, callback, Looper.getMainLooper())
                } catch (_: Exception) { }
                try {
                    @Suppress("MissingPermission")
                    val cached = lm.getLastKnownLocation(p)
                    if (cached != null && System.currentTimeMillis() - cached.time <= 120_000L && cached.accuracy > 0f && cached.accuracy <= 10_000f) {
                        val old = lokasiTerakhir
                        if (old == null || cached.accuracy < old.accuracy) lokasiTerakhir = cached
                    }
                } catch (_: Exception) { }
            }
            handler.postDelayed({
                if (sedangMencari) {
                    val best = lokasiTerakhir
                    if (best != null) selesaiDenganLokasi(best)
                    else {
                        berhentiMencari()
                        status.text = "Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka."
                        toast("Lokasi belum ditemukan. Silakan coba lagi.")
                    }
                }
            }, 20_000L)
        } catch (_: SecurityException) {
            berhentiMencari()
            status.text = "Izin lokasi belum diberikan."
            toast("Izinkan akses lokasi untuk menggunakan fitur ini.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 715) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) perbaruiLokasi()
            else {
                status.text = "Izin lokasi ditolak. Fitur lokasi terkini memerlukan izin lokasi saat digunakan."
                toast("Izin lokasi diperlukan untuk mengetahui lokasi terkini.")
            }
        }
    }

    private fun selesaiDenganLokasi(location: Location) {
        if (!sedangMencari) return
        berhentiMencari()
        lokasiTerakhir = location
        status.text = "Koordinat ditemukan. Sedang mencari nama tempat; jika layanan nama tempat tidak tersedia, koordinat tetap dapat dibacakan."
        Thread {
            val nama = try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val daftar: List<Address>? = Geocoder(this, Locale("id", "ID")).getFromLocation(location.latitude, location.longitude, 1)
                    daftar?.firstOrNull()?.let { alamat ->
                        val namaJalan = listOfNotNull(
                            alamat.thoroughfare?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.subThoroughfare?.trim()?.takeIf { it.isNotEmpty() }
                        ).joinToString(" ").takeIf { it.isNotBlank() }
                        val bagianAlamat = listOfNotNull(
                            namaJalan,
                            alamat.subLocality?.trim()?.takeIf { it.isNotEmpty() },
                            (alamat.locality ?: alamat.subAdminArea)?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.adminArea?.trim()?.takeIf { it.isNotEmpty() },
                            alamat.countryName?.trim()?.takeIf { it.isNotEmpty() }
                        ).distinctBy { it.lowercase(Locale("id", "ID")) }
                        if (bagianAlamat.isNotEmpty()) bagianAlamat.joinToString(", ")
                        else alamat.featureName?.trim()?.takeIf { it.isNotEmpty() && !it.all { c -> c.isDigit() || c == '.' || c == '-' } }
                    }?.takeIf { it.isNotBlank() }
                } else null
            } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                namaLokasiTerakhir = nama
                status.text = susunKalimat(location, nama)
                tesSuara("jam", susunKalimat(location, nama))
            }
        }.start()
    }

    private fun susunKalimat(location: Location, nama: String?): String {
        val tempat = nama?.takeIf { it.isNotBlank() }?.let {
            " Perkiraan tempat Anda: $it."
        } ?: " Nama jalan atau wilayah belum berhasil ditemukan."
        val lintangArah = if (location.latitude < 0) "selatan" else "utara"
        val bujurArah = if (location.longitude < 0) "barat" else "timur"
        val lintang = formatDerajatMenitDetik(kotlin.math.abs(location.latitude))
        val bujur = formatDerajatMenitDetik(kotlin.math.abs(location.longitude))
        val ketelitian = location.accuracy.toInt().coerceAtLeast(1)
        return "Saya berhasil menemukan perkiraan lokasi Anda.$tempat " +
            "Perkiraan ketelitian lokasi sekitar $ketelitian meter. " +
            "Jika diperlukan, koordinat geografisnya adalah: lintang $lintangArah, $lintang; " +
            "bujur $bujurArah, $bujur."
    }

    /** Menulis koordinat sebagai derajat, menit, dan detik agar lebih mudah dipahami melalui suara. */
    private fun formatDerajatMenitDetik(nilai: Double): String {
        val derajat = nilai.toInt()
        val menitPenuh = (nilai - derajat) * 60.0
        val menit = menitPenuh.toInt()
        val detik = (menitPenuh - menit) * 60.0
        val detikTeks = String.format(Locale("id", "ID"), "%.1f", detik)
            .replace(',', ' ').replace(" ", " koma ")
        return "$derajat derajat, $menit menit, $detikTeks detik"
    }

    private fun bacakanLokasi(location: Location, nama: String?) {
        val kalimat = susunKalimat(location, nama)
        status.text = kalimat
        tesSuara("jam", kalimat)
    }

    private fun berhentiMencari() {
        sedangMencari = false
        handler.removeCallbacksAndMessages(null)
        val lm = manager
        val cb = listener
        if (lm != null && cb != null) try { lm.removeUpdates(cb) } catch (_: Exception) { }
        listener = null
    }
}
