package com.novan.bateraibicara

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Dasar semua halaman: pembangun tampilan sederhana dan blok pengaturan suara. */
abstract class Halaman : Activity() {

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    protected fun ui(teks: String): String = BahasaAplikasi.teks(this, teks)

    protected lateinit var prefs: Prefs
    protected lateinit var root: LinearLayout
    private var pembicaraTes: Pembicara? = null
    private lateinit var halamanScroll: ScrollView
    private val namaEngine = ArrayList<String>()
    private val paketEngine = ArrayList<String>()

    protected abstract val judulHalaman: Int
    protected abstract fun bangun()

    private var volumeDikonsumsi = false

    /**
     * FIX76: selama ada suara notifikasi aplikasi yang berbunyi (azan, alarm jam, pengingat, pengumuman baterai/jam,
     * nama pemanggil), menekan volume atas atau bawah menghentikannya dan tidak mengubah volume.
     * Bila tidak ada suara yang berbunyi, tombol volume bekerja seperti biasa.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (volumeDikonsumsi) return true // tekan-tahan: jangan teruskan pengulangan ke pengatur volume
                if (PembungkamTelungkup.bungkamDariTombolVolume(this)) { volumeDikonsumsi = true; return true }
            } else if (event.action == KeyEvent.ACTION_UP && volumeDikonsumsi) {
                volumeDikonsumsi = false
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        muatEngine()
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(24))
        // Identitas visual Zamrud Islami Premium: zamrud, gading, dan aksen emas lembut.
        root.setBackgroundColor(warnaLatar()) // gading terang / hijau gelap saat mode malam
        window.statusBarColor = if (modeGelap()) Color.rgb(20, 29, 28) else Color.rgb(7, 94, 84)
        window.navigationBarColor = if (modeGelap()) Color.rgb(20, 29, 28) else Color.rgb(7, 94, 84)
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = 0
        }
        halamanScroll = ScrollView(this)
        halamanScroll.clipToPadding = false
        halamanScroll.isFillViewport = false
        halamanScroll.addView(root)
        halamanScroll.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            }
            insets
        }
        setContentView(halamanScroll)
        // Navigasi konsisten: setiap halaman fitur memiliki tombol Kembali sebagai
        // elemen fokus pertama, sehingga pengguna TalkBack tidak perlu menyusuri
        // seluruh isi halaman untuk kembali ke tingkat sebelumnya.
        if (this !is MainActivity) {
            val tombolKembali = tombol("Kembali ke halaman sebelumnya") { finish() }
            tombolKembali.contentDescription = ui("Kembali ke halaman sebelumnya")
        }
        setTitle(ui(getString(judulHalaman)))
        bagian(getString(judulHalaman), 26f)
        bangun()
        val posisiSimpan = savedInstanceState?.getInt("halaman_scroll_y", 0) ?: 0
        halamanScroll.post { halamanScroll.scrollTo(0, posisiSimpan.coerceAtLeast(0)) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::halamanScroll.isInitialized) outState.putInt("halaman_scroll_y", halamanScroll.scrollY)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        pembicaraTes?.matikan()
        pembicaraTes = null
        super.onDestroy()
    }

    // ---------- Pembangun tampilan ----------

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    protected fun modeGelap(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    protected fun warnaAksen(): Int = if (modeGelap()) Color.rgb(75, 181, 158) else Color.rgb(7, 94, 84)
    protected fun warnaLatar(): Int = if (modeGelap()) Color.rgb(20, 29, 28) else Color.rgb(247, 244, 234)
    protected fun warnaTeks(): Int = if (modeGelap()) Color.rgb(237, 241, 235) else Color.rgb(39, 50, 45)
    protected fun warnaTeksIsian(): Int = if (modeGelap()) Color.rgb(237, 241, 235) else Color.rgb(30, 45, 40)
    protected fun warnaPetunjuk(): Int = if (modeGelap()) Color.rgb(180, 193, 184) else Color.rgb(105, 112, 103)

    protected fun larik(id: Int): List<String> = resources.getStringArray(id).toList()

    /** Kode kelompok yang sedang dibuka (null = halaman daftar utama). */
    protected fun kodeKelompok(): String? = intent.getStringExtra("kelompok")

    /** Tombol yang membuka kelompok pengaturan di halaman tersendiri (tombol Kembali kembali ke daftar). */
    protected fun tombolKelompok(label: String, kode: String): Button =
        tombol(label) { startActivity(Intent(this, javaClass).putExtra("kelompok", kode)) }

    /** Judul jendela dan judul utama (heading) sebuah kelompok. */
    protected fun judulGrup(nama: String) {
        title = ui(nama)
        bagian(nama, 22f)
    }

    protected fun bagian(teks: String, ukuran: Float = 20f) {
        val tv = TextView(this)
        tv.text = ui(teks)
        tv.textSize = ukuran
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(24), 0, dp(8))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
        val aksen = View(this)
        aksen.contentDescription = null
        aksen.setBackgroundColor(Color.rgb(214, 181, 109)) // #D6B56D
        root.addView(aksen, LinearLayout.LayoutParams(dp(44), dp(3)).apply {
            topMargin = dp(2)
            bottomMargin = dp(4)
        })
    }

    protected fun info(teks: String): TextView {
        val tv = TextView(this)
        tv.text = ui(teks)
        tv.textSize = 16f
        tv.setTextColor(warnaTeks())
        tv.setPadding(0, dp(6), 0, dp(6))
        root.addView(tv)
        return tv
    }

    protected fun saklar(teks: String, nilai: Boolean, onUbah: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = ui(teks)
        s.textSize = 16f
        s.setTextColor(warnaTeks())
        s.isChecked = nilai
        if (Build.VERSION.SDK_INT >= 21) {
            s.thumbTintList = android.content.res.ColorStateList.valueOf(warnaAksen())
            // Trek sakelar dibedakan menurut tema agar tetap terlihat pada latar terang maupun gelap.
            val warnaTrek = if (modeGelap()) Color.rgb(100, 124, 115) else Color.rgb(170, 183, 173)
            s.trackTintList = android.content.res.ColorStateList.valueOf(warnaTrek)
        }
        s.setPadding(0, dp(12), 0, dp(12))
        s.setOnCheckedChangeListener { _, c -> onUbah(c) }
        root.addView(s)
        return s
    }

    protected fun tombol(teks: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = ui(teks)
        b.isAllCaps = false
        b.textSize = 16f
        b.minimumHeight = dp(52)
        b.setTextColor(Color.WHITE)
        val bentuk = GradientDrawable().apply {
            setColor(warnaAksen())
            cornerRadius = dp(14).toFloat()
        }
        if (Build.VERSION.SDK_INT >= 21) {
            b.background = bentuk
            b.elevation = dp(2).toFloat()
        } else {
            b.background = bentuk
        }
        b.setPadding(dp(16), dp(10), dp(16), dp(10))
        b.contentDescription = ui(teks)
        b.setOnClickListener { aksi() }
        root.addView(b, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(5)
            bottomMargin = dp(5)
        })
        return b
    }

    protected fun pilihan(judul: String, items: List<String>, terpilih: Int, onPilih: (Int) -> Unit) {
        val tv = TextView(this)
        tv.text = ui(judul)
        tv.textSize = 16f
        tv.setPadding(0, dp(12), 0, 0)
        val sp = Spinner(this)
        sp.id = View.generateViewId()
        tv.labelFor = sp.id
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items.map { ui(it) })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setSelection(terpilih, false)
        var terakhir = terpilih
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != terakhir) {
                    terakhir = pos
                    onPilih(pos)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(tv)
        root.addView(sp)
    }

    protected fun EditText.ubah(aksi: (String) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { aksi(s?.toString() ?: "") }
        })
    }

    /** Kolom isian dengan label yang terbaca TalkBack. */
    protected fun isian(label: String, nilai: String, tipe: Int, onUbah: (String) -> Unit): EditText {
        val tv = TextView(this)
        tv.text = ui(label)
        tv.textSize = 16f
        tv.setTextColor(warnaTeks())
        tv.setPadding(0, dp(12), 0, 0)
        val et = EditText(this)
        et.id = View.generateViewId()
        tv.labelFor = et.id
        et.inputType = tipe
        et.hint = ui(label)
        et.setTextColor(warnaTeksIsian())
        et.setHintTextColor(warnaPetunjuk())
        et.setText(nilai)
        et.ubah(onUbah)
        root.addView(tv)
        root.addView(et)
        return et
    }

    protected fun tombolJam(formatRes: Int, get: () -> Int, set: (Int) -> Unit) {
        val b = Button(this)
        b.isAllCaps = false
        fun segarkan() { b.text = getString(formatRes, JamWaktu.format(get())) }
        segarkan()
        b.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                set(h * 60 + m)
                segarkan()
            }, get() / 60, get() % 60, true).show()
        }
        root.addView(b)
    }

    protected fun toast(id: Int) = Toast.makeText(this, ui(getString(id)), Toast.LENGTH_LONG).show()
    protected fun toast(teks: String) = Toast.makeText(this, ui(teks), Toast.LENGTH_LONG).show()

    /** Simpan perubahan ke layanan yang sedang berjalan (jadwal jam dipasang ulang). */
    protected fun muatUlang() {
        if (prefs.enabled) BatteryTalkService.reload(this)
    }

    // ---------- Blok pengaturan suara ----------

    @Suppress("DEPRECATION")
    private fun muatEngine() {
        paketEngine.add("")
        namaEngine.add(getString(R.string.mesin_bawaan))
        val daftar = packageManager.queryIntentServices(
            Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE), 0
        )
        for (ri in daftar) {
            val si = ri.serviceInfo ?: continue
            if (paketEngine.contains(si.packageName)) continue
            paketEngine.add(si.packageName)
            namaEngine.add(ri.loadLabel(packageManager).toString())
        }
    }

    /** Mesin suara, kecepatan, nada, keluaran volume, dan tombol tes untuk satu profil. */
    protected fun blokSuara(profil: String, contoh: () -> String) {
        val s = prefs.suara(profil)
        bagian(getString(R.string.bagian_suara))
        pilihan(
            getString(R.string.mesin_suara), namaEngine,
            paketEngine.indexOf(s.engine).coerceAtLeast(0)
        ) { s.engine = paketEngine[it] }
        pilihan(getString(R.string.kecepatan), larik(R.array.kecepatan), s.rateIdx) { s.rateIdx = it }
        pilihan(getString(R.string.nada), larik(R.array.nada), s.pitchIdx) { s.pitchIdx = it }
        pilihan(getString(R.string.keluaran), larik(R.array.keluaran), s.streamIdx) { s.streamIdx = it }
        info(getString(R.string.contoh_hasil, contoh()))
        tombol(getString(R.string.tombol_tes)) { tesSuara(profil, contoh()) }
        tombol(getString(R.string.tombol_pengaturan_tts)) { bukaPengaturanTts() }
    }

    protected fun tesSuara(profil: String, teks: String) {
        pembicaraTes?.matikan()
        val p = Pembicara(this, prefs.suara(profil)) { toast(it) }
        pembicaraTes = p
        p.ucapkan(teks, true)
    }

    private fun bukaPengaturanTts() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    protected fun bukaInfoApp() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(("package:" + (packageName))))
            )
        } catch (e: Exception) { }
    }
}
