#!/usr/bin/env python3
"""Uji kontrak sumber FIX120: mikrofon perintah suara tidak boleh tertahan oleh instance lama atau audio yang terus berbunyi.
Bukan hasil kompilasi dan bukan uji perangkat."""
from pathlib import Path
import sys
B = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
ps = (B / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
kh = (B / "KhatamActivity.kt").read_text(encoding="utf-8")
gagal = []
def cek(n, k):
    if not k: gagal.append(n)
cek("satu instance aktif", "lama.tutupPaksa()" in ps and "aktif = this" in ps and "if (aktif === this) aktif = null" in ps)
cek("mulai: jeda audio Khatam + batas waktu 45 dtk", "KhatamActivity.jedakanUntukMikrofon()" in ps and "batasWaktu, 45_000L" in ps)
# FIX121
cek("fokus audio hanya untuk pengenal dalam (layar sistem meminta sendiri)", ps.count("ambilFokusMikrofon()") == 2 and "ambilFokusMikrofon() // layar pengenal sistem" in ps)
cek("pemicu baru setelah 6 detik memulai ulang pengenalan macet", "SystemClock.elapsedRealtime() - waktuMulai > 6_000L) mulaiUlangPengenalan()" in ps)
cek("hasil layar pengenal lama diabaikan (kode per generasi)", "generasiPengenalan++" in ps and "if (requestCode != kodePengenalan()) return" in ps)
cek("galat mikrofon diulang satu kali", "percobaanUlangMic++ < 1" in ps and "RecognizerIntent.RESULT_AUDIO_ERROR" in ps)
cek("kegagalan akhir diberi tahu bilingual", "R.string.perintah_suara_mikrofon_gagal" in ps)
idn = (B.parents[3] / "res/values/strings.xml").read_text(encoding="utf-8")
eng = (B.parents[3] / "res/values-en/strings.xml").read_text(encoding="utf-8")
cek("string gagal ada di dua bahasa", 'name="perintah_suara_mikrofon_gagal"' in idn and 'name="perintah_suara_mikrofon_gagal"' in eng)
cek("jeda sebelum layar sistem pada cadangan", "}, 500L)" in ps)
cek("jalankan: lepas fokus + batas longgar", "lepasFokusMikrofon()\n        handler.removeCallbacks(batasWaktu)\n        handler.postDelayed(batasWaktu, 120_000L)" in ps)
cek("tutup menutup layar pengenal sistem", "finishActivity(kodePengenalan())" in ps)
cek("onDestroy melepas fokus dan pengenal", "lepasPengenal()\n        lepasFokusMikrofon()" in ps)
cek("batasWaktu melanjutkan audio", "Runnable { tutupDanLanjutAudio() }" in ps)
cek("Khatam: jeda/lanjut mikrofon", "fun jedakanUntukMikrofon()" in kh and "fun lanjutkanSetelahMikrofon()" in kh)
cek("Khatam: pelanjutan hanya bila dijeda mikrofon", "if (!dijedaUntukMikrofon) return" in kh)
cek("Khatam: perintah pengguna/hentikan membatalkan pelanjutan", kh.count("dijedaUntukMikrofon = false") >= 3)
cek("layanan penjaga tidak menganggap selesai saat jeda mikrofon", "if (dijedaUntukMikrofon) return true" in kh)
if gagal:
    print("UJI MIKROFON PERINTAH SUARA: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI MIKROFON PERINTAH SUARA: LULUS (kontrak sumber)")
