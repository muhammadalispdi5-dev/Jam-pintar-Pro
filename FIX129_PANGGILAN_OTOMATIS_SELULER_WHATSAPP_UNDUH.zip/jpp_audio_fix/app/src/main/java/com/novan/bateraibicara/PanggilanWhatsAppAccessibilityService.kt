package com.novan.bateraibicara

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

/**
 * Mengoperasikan kontrol panggilan WhatsApp hanya untuk permintaan yang baru saja
 * dikonfirmasi pengguna dengan ucapan "telepon suara" atau "telepon video".
 * Tidak membaca isi chat dan tidak mengirim pesan.
 */
class PanggilanWhatsAppAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_PENDING, false)) return
        val dibuat = prefs.getLong(KEY_CREATED, 0L)
        if (dibuat <= 0L || System.currentTimeMillis() - dibuat > 45_000L) {
            prefs.edit().clear().apply(); return
        }
        val paket = prefs.getString(KEY_PACKAGE, "") ?: ""
        if (event.packageName?.toString() != paket) return
        val root = rootInActiveWindow ?: return
        val jenis = prefs.getString(KEY_TYPE, "voice") ?: "voice"
        val target = if (jenis == "video") VIDEO_LABELS else VOICE_LABELS
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        kumpulkan(root, nodes, 0)

        // Utamakan kontrol yang menyebut jenis panggilan secara spesifik. Bila WhatsApp
        // menampilkan menu konfirmasi, item spesifik akan ditemukan pada event berikutnya.
        val stage = prefs.getInt(KEY_STAGE, 0)
        if (stage == 2) {
            // Hanya tekan tombol konfirmasi bila dialog benar-benar menyebut jenis panggilan
            // yang baru saja dipilih pengguna. Jangan menekan tombol umum di layar chat.
            val teksLayar = nodes.joinToString(" ") { label(it) }
            val judulKonfirmasi = if (jenis == "video")
                listOf("start video call", "mulai panggilan video", "mulai panggilan vidio", "memulai panggilan video").any { teksLayar.contains(it) }
            else listOf("start voice call", "mulai panggilan suara", "memulai panggilan suara").any { teksLayar.contains(it) }
            if (judulKonfirmasi) {
                val tombol = nodes.firstOrNull { node ->
                    val l = label(node)
                    node.isEnabled && (l == "call" || l == "panggil" || l == "start" || l == "mulai") && punyaIndukKlik(node)
                }
                if (tombol != null && klik(tombol)) prefs.edit().putBoolean(KEY_PENDING, false).apply()
            }
            return
        }

        val spesifik = nodes.firstOrNull { node ->
            val l = label(node)
            target.any { l.contains(it) } && node.isEnabled && punyaIndukKlik(node)
        }
        if (spesifik != null && klik(spesifik)) {
            prefs.edit().putInt(KEY_STAGE, 2).apply()
            return
        }

        // Beberapa versi WhatsApp hanya menampilkan tombol umum "Call" yang membuka
        // pilihan suara/video. Klik tombol umum satu kali, lalu tunggu item spesifik.
        if (stage == 0) {
            val umum = nodes.firstOrNull { node ->
                val label = label(node)
                node.isEnabled && (label == "call" || label == "panggilan" || label == "telepon" || label == "voice/video call")
            }
            if (umum != null && klik(umum)) {
                prefs.edit().putInt(KEY_STAGE, 1).apply()
                return
            }
        }
    }

    private fun label(node: AccessibilityNodeInfo): String =
        ((node.text?.toString().orEmpty()) + " " + (node.contentDescription?.toString().orEmpty()))
            .lowercase().replace(Regex("\\s+"), " ").trim()

    private fun kumpulkan(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 500) return
        out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { kumpulkan(it, out, depth + 1) }
    }

    private fun punyaIndukKlik(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 6) {
            if (current.isClickable && current.isEnabled) return true
            current = current.parent
        }
        return false
    }

    private fun klik(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth++ < 6) {
            if (current.isClickable && current.isEnabled) return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            current = current.parent
        }
        return false
    }

    override fun onInterrupt() = Unit

    companion object {
        const val PREFS = "wa_auto_call"
        const val KEY_PENDING = "pending"
        const val KEY_PACKAGE = "package"
        const val KEY_TYPE = "type"
        const val KEY_CREATED = "created"
        const val KEY_STAGE = "stage"
        private val VOICE_LABELS = listOf("voice call", "panggilan suara", "telepon suara", "panggilan audio", "audio call", "call by voice")
        private val VIDEO_LABELS = listOf("video call", "panggilan video", "telepon video", "panggilan vidio")
    }
}
