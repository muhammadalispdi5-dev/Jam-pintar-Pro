package com.novan.bateraibicara

import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView

/** Pengaturan aksesibel untuk menyenyapkan HP dan pengumuman Jam Pintar Pro sementara. */
class ModeAcaraActivity : Halaman() {
    override val judulHalaman = R.string.judul_mode_acara
    private var durasi = 60
    private var cakupan = ModeAcara.CAKUPAN_SEMUA
    private lateinit var status: TextView

    override fun bangun() {
        info("Gunakan saat rapat, musyawarah, pengajian, atau acara lain. Pilih apakah mode hanya menahan pengumuman Jam Pintar Pro atau juga menyenyapkan notifikasi HP. Mode akan berakhir otomatis sesuai durasi dan berusaha memulihkan pengaturan sebelumnya.")
        bagian("Apa yang terdampak selama acara?")
        cakupan = ModeAcara.cakupan(this)
        pilihan(
            "Pilih cakupan Mode Acara",
            listOf(
                "Hanya suara/pengumuman Jam Pintar Pro",
                "Notifikasi prioritas (atur pengecualian di Android)",
                "Alarm saja yang boleh berbunyi",
                "Senyapkan semua notifikasi HP"
            ),
            cakupan
        ) {
            cakupan = it
            getSharedPreferences("mode_acara", MODE_PRIVATE).edit().putInt("cakupan", cakupan).apply()
        }
        info("Keterangan: Notifikasi prioritas mengikuti pengecualian Jangan Ganggu pada Android, misalnya panggilan, pesan, atau aplikasi tertentu yang Anda izinkan. Untuk memilih aplikasi yang boleh tetap memberi notifikasi, buka pengaturan pengecualian Android di bawah ini.")
        tombol("Atur pengecualian notifikasi di Android") {
            bukaPengaturanPrioritas()
        }
        bagian("Durasi Mode Acara")
        pilihan("Pilih berapa lama mode berlangsung", listOf("30 menit", "1 jam", "2 jam", "3 jam", "Tanpa batas waktu"), 1) {
            durasi = when (it) { 0 -> 30; 1 -> 60; 2 -> 120; 3 -> 180; else -> 0 }
        }
        status = info("")
        tombol("Aktifkan Mode Acara") {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val perluIzinDnd = cakupan != ModeAcara.CAKUPAN_JAM_PINTAR
            if (perluIzinDnd && !nm.isNotificationPolicyAccessGranted) {
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                catch (_: Exception) { toast("Buka Pengaturan Android, lalu izinkan akses Jangan Ganggu untuk Jam Pintar Pro.") }
                return@tombol
            }
            if (ModeAcara.mulai(this, durasi, cakupan)) {
                perbaruiStatus()
                toast("Mode Acara diaktifkan sesuai cakupan yang dipilih.")
            } else toast("Mode Acara belum dapat diaktifkan. Periksa izin Jangan Ganggu.")
        }
        tombol("Akhiri Mode Acara dan Pulihkan") {
            ModeAcara.selesai(this)
            perbaruiStatus()
            toast("Mode Acara diakhiri.")
        }
        tombol("Buka pengaturan izin Jangan Ganggu") {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Silakan cari akses Jangan Ganggu pada Pengaturan Android.") }
        }
        info("Catatan: pilihan Hanya suara/pengumuman Jam Pintar Pro tidak mengubah Jangan Ganggu sistem, sehingga aplikasi lain tetap dapat berbunyi. Pilihan lainnya memakai filter Jangan Ganggu Android. Jika Jangan Ganggu sudah aktif sebelum acara dimulai, pengaturan sebelumnya akan dipulihkan. Perubahan manual pengguna selama acara tidak sengaja ditimpa.")
        perbaruiStatus()
    }

    private fun bukaPengaturanPrioritas() {
        try {
            startActivity(Intent("android.settings.ZEN_MODE_PRIORITY_SETTINGS"))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Buka Pengaturan Android, lalu cari Jangan Ganggu atau Pengecualian notifikasi.") }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) perbaruiStatus()
    }

    private fun perbaruiStatus() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val aktif = ModeAcara.aktif(this)
        val akhir = getSharedPreferences("mode_acara", MODE_PRIVATE).getLong("berakhir", 0L)
        val durasiText = if (akhir > 0L) {
            val menit = ((akhir - System.currentTimeMillis()).coerceAtLeast(0L) / 60_000L)
            " " + ui("Sisa waktu sekitar ") + menit + " " + ui("menit.")
        } else if (aktif) " " + ui("Mode ini tidak memiliki batas waktu.") else ""
        val teksStatusAktif = if (aktif) "AKTIF" else "NONAKTIF"
        val teksStatusIzin = when {
            ModeAcara.cakupan(this) == ModeAcara.CAKUPAN_JAM_PINTAR -> "tidak diperlukan untuk cakupan ini"
            nm.isNotificationPolicyAccessGranted -> "diizinkan"
            else -> "belum diizinkan"
        }
        val namaCakupan = when (ModeAcara.cakupan(this)) {
            ModeAcara.CAKUPAN_JAM_PINTAR -> "Hanya suara/pengumuman Jam Pintar Pro"
            ModeAcara.CAKUPAN_PRIORITAS -> "Notifikasi prioritas Android"
            ModeAcara.CAKUPAN_ALARM -> "Alarm saja"
            else -> "Semua notifikasi HP disenyapkan"
        }
        status.text = ui("Status Mode Acara: ") + ui(teksStatusAktif) + ". " + ui("Cakupan: ") + ui(namaCakupan) + ". " + ui("Izin Jangan Ganggu: ") + ui(teksStatusIzin) + "." + durasiText
    }
}
