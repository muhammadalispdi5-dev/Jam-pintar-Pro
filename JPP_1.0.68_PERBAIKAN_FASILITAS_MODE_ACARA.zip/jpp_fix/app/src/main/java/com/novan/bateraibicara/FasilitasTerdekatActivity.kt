package com.novan.bateraibicara

import android.content.Intent
import android.net.Uri

/** Pencarian fasilitas terdekat lewat aplikasi peta yang dipilih pengguna. */
class FasilitasTerdekatActivity : Halaman() {
    override val judulHalaman = R.string.kategori_fasilitas_terdekat

    override fun bangun() {
        info("Pilih jenis fasilitas yang ingin dicari. Pencarian dibuka di Google Maps atau aplikasi peta yang tersedia. Internet dan izin lokasi pada aplikasi peta mungkin diperlukan agar hasil dan jarak terdekat akurat. Jam Pintar Pro tidak menyimpan lokasi Anda.")
        val pilihan = listOf(
            "Masjid dan musala" to "masjid dan musala terdekat",
            "Rumah sakit" to "rumah sakit terdekat",
            "Puskesmas dan klinik" to "puskesmas klinik terdekat",
            "Apotek" to "apotek terdekat",
            "ATM" to "ATM terdekat",
            "Bank" to "bank terdekat",
            "Toilet umum" to "toilet umum terdekat",
            "Kantor polisi" to "kantor polisi terdekat",
            "Pemadam kebakaran" to "pemadam kebakaran terdekat",
            "SPBU" to "SPBU terdekat",
            "Halte dan stasiun" to "halte stasiun terdekat",
            "Pasar dan minimarket" to "pasar minimarket terdekat"
        )
        val queryEnglish = listOf(
            "nearby mosques and prayer rooms", "nearby hospitals", "nearby community health centers and clinics",
            "nearby pharmacies", "nearby ATMs", "nearby banks", "nearby public restrooms",
            "nearby police stations", "nearby fire stations", "nearby fuel stations",
            "nearby bus stops and train stations", "nearby markets and convenience stores"
        )
        for ((index, item) in pilihan.withIndex()) {
            tombol(item.first) {
                val query = if (BahasaAplikasi.tampilan(this) == 1) queryEnglish[index] else item.second
                cari(query)
            }
        }
    }

    private fun cari(query: String) {
        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { toast("Aplikasi peta tidak dapat dibuka.") }
    }
}
