package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Beranda aksesibel: identitas visual, sakelar utama, pintasan fitur, dan bantuan latar belakang. */
/** FIX303: sudah memeriksa pembaruan sejak proses aplikasi ini dimulai (pemeriksaan pertama tidak menunggu jeda 12 jam). */
private var cekPembaruanAwalSelesai = false

class MainActivity : Halaman() {
    // FIX247: pemandu perizinan dasar otomatis.
    private val pemanduIzin by lazy { PemanduIzinAwal(this) { i, e -> tr(i, e) } }

    override val judulHalaman = R.string.judul

    private lateinit var saklarAktif: Switch
    private lateinit var teksStatus: TextView
    private var sinkron = false
    private val kartu = ArrayList<Pair<Button, () -> String>>()

    // Rekaman pengantar awal: diputar utuh lebih dulu pada penggunaan pertama, baru petunjuk tampil.
    private var pemutarPengantar: MediaPlayer? = null
    private var ulangPengantar = false
    private var dialogPanduanTampil = false

    // Pembaruan aplikasi (unduh dan pasang tanpa Play Store).
    private val handlerUpdate = android.os.Handler(android.os.Looper.getMainLooper())
    private var dialogUnduh: AlertDialog? = null
    private var tawaranPasangTampil = false
    private var infoMenungguIzinPasang: UpdateManager.Info? = null

    private val kodePulihkan = 4102
    private var cadanganMenungguIzin = false
    private var pulihanMenungguIzin = false
    private var pulihkanSetelahIzinLama = false
    private val kodeIzinCadangan = 6911

    /** FIX85: pintasan dinamis (selain yang statis) agar menu ketuk tahan ikon Beritahu Saya memuat "Perintah suara" di semua peluncur; label mengikuti bahasa aktif. */
    private fun daftarkanPintasanPerintahSuara() {
        if (Build.VERSION.SDK_INT < 25) return
        try {
            val sm = getSystemService(android.content.pm.ShortcutManager::class.java) ?: return
            val info = android.content.pm.ShortcutInfo.Builder(this, "perintah_suara_dinamis")
                .setShortLabel(getString(R.string.shortcut_perintah_suara_pendek))
                .setLongLabel(getString(R.string.shortcut_perintah_suara_panjang))
                .setIcon(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_launcher))
                .setIntent(Intent(this, PerintahSuaraActivity::class.java).setAction(Intent.ACTION_VIEW))
                .setActivity(ComponentName(this, BeritahuSayaActivity::class.java))
                .build()
            sm.setDynamicShortcuts(listOf(info))
        } catch (_: Exception) { }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FIX216: segarkan tabel Hijriah daring di latar (tidak menghambat tampilan; aman tanpa internet).
        try { if (Prefs(applicationContext).kalenderHijriAuto) HijriahDaring.segarkan(applicationContext) } catch (_: Throwable) { }
        daftarkanPintasanPerintahSuara()
        val panduanPrefs = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (!panduanPrefs.getBoolean("panduan_awal_ditampilkan", false)) {
            if (panduanPrefs.getBoolean("pengantar_awal_selesai", false)) {
                // Rekaman sudah pernah diputar utuh (mis. layar diputar sebelum petunjuk ditutup).
                tampilkanPanduan(panduanPertama = true)
            } else {
                mulaiPengantarAwal()
            }
        } else {
            pemanduIzin.mulaiBerkala()
            tanganiAksiSuara(intent)
            // Pemeriksaan/pengunduhan pembaruan diarahkan ke kanal Telegram resmi.
            // Kanal publik biasa tidak menyediakan endpoint versi terstruktur yang stabil.
        }
    }

    // FIX250: aksi menu beranda yang diminta lewat asisten suara.
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        tanganiAksiSuara(intent)
    }

    private fun tanganiAksiSuara(i: android.content.Intent?) {
        val aksi = i?.getStringExtra("aksi_suara") ?: return
        i.removeExtra("aksi_suara")
        root.post {
            when (aksi) {
                "petunjuk" -> tampilkanPanduan(panduanPertama = false)
                "cadangkan" -> mulaiCadangkan()
                "pulihkan" -> mulaiPulihkan()
                "reset" -> konfirmasiReset()
                "info_app" -> bukaInfoApp()
                "periksa_update" -> periksaPembaruan(true)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Rekaman dihentikan saat aplikasi ke latar belakang; ulangi dari awal agar didengar utuh.
        if (ulangPengantar) {
            ulangPengantar = false
            mulaiPengantarAwal()
        }
    }

    override fun onStop() {
        super.onStop()
        if (pemutarPengantar != null) {
            bersihkanPemutarPengantar()
            ulangPengantar = true
        }
    }

    override fun onDestroy() {
        try { pembicaraProses?.matikan() } catch (_: Exception) { }
        pembicaraProses = null
        bersihkanPemutarPengantar()
        handlerUpdate.removeCallbacksAndMessages(null)
        try { dialogUnduh?.dismiss() } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun bersihkanPemutarPengantar() {
        val p = pemutarPengantar ?: return
        pemutarPengantar = null
        try { p.setOnCompletionListener(null) } catch (_: Exception) { }
        try { p.setOnErrorListener(null) } catch (_: Exception) { }
        try { if (p.isPlaying) p.stop() } catch (_: Exception) { }
        try { p.release() } catch (_: Exception) { }
    }

    /** Memutar rekaman pengantar awal; setelah selesai utuh barulah informasi pengembang dan petunjuk tampil. */
    private fun mulaiPengantarAwal() {
        if (pemutarPengantar != null || dialogPanduanTampil) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            val player = MediaPlayer()
            pemutarPengantar = player
            try {
                // Atribut dipasang sebelum sumber data dan prepare agar benar-benar dipakai sistem.
                player.setAudioAttributes(attrs)
                val afd = resources.openRawResourceFd(R.raw.pengantar_awal_aplikasi_jam_pintar_pro)
                try { player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                player.setOnCompletionListener { selesaiPengantarAwal() }
                player.setOnErrorListener { _, _, _ -> selesaiPengantarAwal(); true }
                player.prepare()
                player.start()
            } catch (e: Exception) {
                selesaiPengantarAwal()
            }
        } catch (e: Exception) {
            selesaiPengantarAwal()
        }
    }

    private fun selesaiPengantarAwal() {
        bersihkanPemutarPengantar()
        getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
            .putBoolean("pengantar_awal_selesai", true).apply()
        if (isFinishing || isDestroyed) return
        tampilkanPanduan(panduanPertama = true)
    }

    override fun bangun() {
        // Sapaan utama sesuai permintaan: salam Arab, bukan sapaan berdasarkan waktu.
        val salam = info("السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ")
        salam.textSize = 24f
        salam.gravity = Gravity.CENTER
        salam.setTypeface(salam.typeface, Typeface.BOLD)
        salam.setTextColor(warnaAksen())
        salam.contentDescription = "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ"
        salam.setPadding(dp(16), dp(18), dp(16), dp(18))
        salam.background = GradientDrawable().apply {
            setColor(if (modeGelap()) Color.rgb(28, 57, 50) else Color.rgb(230, 239, 230))
            setStroke(dp(1), Color.rgb(214, 181, 109))
            cornerRadius = dp(18).toFloat()
        }
        salam.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8); bottomMargin = dp(8) }
        val slogan = info(getString(R.string.slogan_aksesibilitas))
        slogan.textSize = 18f
        slogan.gravity = Gravity.CENTER
        slogan.setPadding(dp(16), dp(12), dp(16), dp(12))
        slogan.background = GradientDrawable().apply {
            setColor(if (modeGelap()) Color.rgb(31, 39, 37) else Color.rgb(247, 244, 234))
            setStroke(dp(1), Color.rgb(214, 181, 109))
            cornerRadius = dp(16).toFloat()
        }
        slogan.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(2); bottomMargin = dp(12) }
        tombol(getString(R.string.pengaturan_bahasa)) { startActivity(Intent(this, BahasaActivity::class.java)) }

        saklarAktif = saklar(getString(R.string.aktifkan), prefs.enabled) { on ->
            if (!sinkron) {
                prefs.enabled = on
                if (on) BatteryTalkService.start(this) else BatteryTalkService.stop(this)
            }
        }

        teksStatus = info("")
        teksStatus.textSize = 16f

        // FIX229: semua pemicu asisten suara (Beritahu Saya, goncangan, tombol fisik, tombol aksesibilitas) dikumpulkan dalam satu pengaturan.
        bagian(getString(R.string.bagian_pemicu_asisten))
        tombol(getString(R.string.judul_pemicu_asisten)) {
            startActivity(Intent(this, PemicuAsistenActivity::class.java))
        }
        info(getString(R.string.info_pemicu_asisten))

        // Penghemat daya bersifat menyeluruh, sehingga ditempatkan di beranda,
        // terpisah dari kategori Baterai yang hanya mengatur pengumuman baterai.
        bagian(if (BahasaAplikasi.tampilan(this) == 1) "Application-wide settings" else "Pengaturan seluruh aplikasi")
        tombol(if (BahasaAplikasi.tampilan(this) == 1) "Power saving mode" else "Penghemat daya") {
            startActivity(Intent(this, PenghematDayaActivity::class.java))
        }

        bagian(getString(R.string.bagian_kategori))
        kartuKategori(R.string.kategori_baterai, BateraiActivity::class.java) { prefs.bateraiOn }
        kartuKategori(R.string.kategori_jam, JamActivity::class.java) { prefs.jamOn }
        kartuKategori(R.string.kategori_kalender, KalenderActivity::class.java) {
            prefs.kalenderMasehiOn || prefs.kalenderHijriOn || prefs.kalenderPasaranOn ||
                prefs.liburNasionalLampau || prefs.liburNasionalTerkini || prefs.liburNasionalMendatang ||
                prefs.cutiBersamaLampau || prefs.cutiBersamaTerkini || prefs.cutiBersamaMendatang
        }
        kartuKategori(R.string.kategori_pemanggil, PemanggilActivity::class.java) { prefs.pemOn }
        kartuKategori(R.string.kategori_sholat, PrayerActivity::class.java) { PrayerPrefs(this).enabled }
        tombol(getString(R.string.judul_lokasi_terkini)) { startActivity(Intent(this, LokasiTerkiniActivity::class.java)) }
        tombol(getString(R.string.judul_pemandu_jalan)) { startActivity(Intent(this, PemanduJalanActivity::class.java)) }
        // Akses langsung ke arah kiblat dari beranda agar mudah ditemukan pengguna TalkBack.
        tombol(getString(R.string.kategori_kiblat)) { startActivity(Intent(this, QiblaActivity::class.java)) }
        tombol(getString(R.string.judul_kompas_arah)) { startActivity(Intent(this, KompasActivity::class.java)) }
        tombol(getString(R.string.kategori_fasilitas_terdekat)) { startActivity(Intent(this, FasilitasTerdekatActivity::class.java)) }
        tombol(getString(R.string.menu_doa_harian)) { startActivity(Intent(this, DoaHarianActivity::class.java)) }
        tombol(getString(R.string.menu_asmaul_husna)) { startActivity(Intent(this, AsmaulHusnaActivity::class.java)) }
        tombol(getString(R.string.menu_taaruf_doa)) { startActivity(Intent(this, TaarufDoaActivity::class.java)) }
        tombol(getString(R.string.khatam_menu)) { startActivity(Intent(this, KhatamActivity::class.java)) }
        tombol(getString(R.string.menu_hadits)) { startActivity(Intent(this, HaditsActivity::class.java)) }
        tombol(getString(R.string.menu_khutbah)) { startActivity(Intent(this, KhutbahJumatActivity::class.java)) }
        tombol(getString(R.string.menu_panduan_ibadah)) { startActivity(Intent(this, PanduanIbadahActivity::class.java)) }
        tombol(getString(R.string.menu_manasik_haji)) { startActivity(Intent(this, ManasikHajiActivity::class.java)) }
        tombol(getString(R.string.menu_kalkulator_zakat)) { startActivity(Intent(this, KalkulatorZakatActivity::class.java)) }
        tombol(getString(R.string.judul_mode_acara)) { startActivity(Intent(this, ModeAcaraActivity::class.java)) }
        tombol(getString(R.string.tombol_petunjuk_penggunaan)) { tampilkanPanduan(panduanPertama = false) }

        bagian(getString(R.string.bagian_cadangan))
        info(getString(R.string.info_cadangan))
        tombol(getString(R.string.tombol_cadangkan)) { mulaiCadangkan() }
        tombol(getString(R.string.tombol_pulihkan)) { mulaiPulihkan() }
        tombol(getString(R.string.tombol_reset)) { konfirmasiReset() }

        saklar(getString(R.string.sw_boot), prefs.bootOn) { prefs.bootOn = it }

        bagian(getString(R.string.bagian_latar))
        info(getString(R.string.teks_latar))
        tombol(getString(R.string.tombol_izin_perangkat)) {
            startActivity(Intent(this, IzinPerangkatActivity::class.java))
        }
        tombol(getString(R.string.tombol_info_app)) { bukaInfoApp() }

        bagian(getString(R.string.bagian_bantuan))
        info(getString(R.string.info_versi_app, UpdateManager.namaVersi(this)))
        info(getString(R.string.info_update_telegram))
        saklar(getString(R.string.sw_update_otomatis), UpdateManager.otomatisAktif(this)) { UpdateManager.setOtomatis(this, it) }
        tombol(getString(R.string.tombol_periksa_update)) { periksaPembaruan(true) }
        tombol(getString(R.string.tombol_hubungi_pengembang)) { startActivity(Intent(this, KeluhanActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        if (cadanganMenungguIzin) {
            if (Build.VERSION.SDK_INT >= 30 && android.os.Environment.isExternalStorageManager()) {
                cadanganMenungguIzin = false
                simpanCadanganInternal()
            } else if (Build.VERSION.SDK_INT >= 30) {
                cadanganMenungguIzin = false
                toast(R.string.cadangan_gagal)
            }
        }
        if (pulihanMenungguIzin) {
            if (Build.VERSION.SDK_INT >= 30 && android.os.Environment.isExternalStorageManager()) {
                pulihanMenungguIzin = false
                mulaiPulihkanDariLokasiTetap()
            } else if (Build.VERSION.SDK_INT >= 30) {
                pulihanMenungguIzin = false
                toast(R.string.pulihkan_gagal_baca)
            }
        }
        CallerListener.sambungkanUlang(this)
        LokasiOtomatis.periksa(this)
        pemanduIzin.lanjutJikaMenunggu()
        if (saklarAktif.isChecked != prefs.enabled) {
            sinkron = true
            saklarAktif.isChecked = prefs.enabled
            sinkron = false
        }
        // Pastikan layanan tetap berjalan bila saklar utama aktif.
        if (prefs.enabled) {
            try { BatteryTalkService.start(this) } catch (e: Exception) { }
        }
        // FIX246: jadwal sholat aktif bawaan; pastikan alarmnya terpasang walau layar jadwal belum pernah dibuka.
        try { if (PrayerPrefs(this).enabled && PrayerPrefs(this).locationSet) PrayerAlarm.scheduleAll(this) } catch (_: Exception) { }
        perbaruiStatus()
        tawarkanPasangJikaSiap()
        // FIX295: sinkronkan tanggal Hijriah otomatis setiap aplikasi dibuka (cache dan cadangan offline tetap berlaku).
        try { if (Prefs(applicationContext).kalenderHijriAuto) KalenderTanggal.perbaruiHijriahOtomatis(applicationContext, java.util.Calendar.getInstance()) } catch (_: Throwable) { }
        // FIX303: setelah kembali dari layar izin pemasangan, unduhan yang tertunda langsung dimulai.
        infoMenungguIzinPasang?.let { menunggu -> infoMenungguIzinPasang = null; mulaiUnduh(menunggu) }
        // FIX290/303: pembaruan otomatis diperiksa SETIAP aplikasi dibuka pertama kali (proses baru), lalu paling sering sekali per 12 jam
        // saat kembali ke layar ini. Dialog pembaruan langsung muncul bila ada versi baru; tidak mengganggu panduan awal atau unduhan berjalan.
        if (UpdateManager.otomatisAktif(this) && (!cekPembaruanAwalSelesai || UpdateManager.sudahWaktunyaCek(this)) && !dialogPanduanTampil &&
            pemutarPengantar == null && dialogUnduh?.isShowing != true && !tawaranPasangTampil) {
            cekPembaruanAwalSelesai = true
            UpdateManager.catatCek(this)
            periksaPembaruan(false)
        }
        for ((b, teks) in kartu) b.text = ui(teks())
    }

    private fun kartuKategori(judul: Int, tujuan: Class<*>, aktif: () -> Boolean) {
        val nama = getString(judul)
        val b = tombol(nama) { startActivity(Intent(this, tujuan)) }
        b.minimumHeight = dp(72)
        kartu.add(b to {
            nama + "\n" + getString(if (aktif()) R.string.status_aktif else R.string.status_mati)
        })
    }

    private fun tampilkanPanduan(panduanPertama: Boolean) {
        if (panduanPertama) {
            if (dialogPanduanTampil) return
            dialogPanduanTampil = true
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(ui(getString(R.string.judul_petunjuk_penggunaan)))
            .setMessage(ui(getString(R.string.isi_petunjuk_penggunaan) + "\n" + getString(R.string.isi_petunjuk_penggunaan_lanjutan) + "\n" + getString(R.string.isi_petunjuk_penggunaan_lanjutan_3)))
            .setPositiveButton(getString(R.string.tombol_mengerti)) { d, _ ->
                d.dismiss()
                if (panduanPertama) {
                    getSharedPreferences("panduan_aplikasi", MODE_PRIVATE).edit()
                        .putBoolean("panduan_awal_ditampilkan", true).apply()
                    pemanduIzin.mulai()
                }
            }
            .create()
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    // ---------- Cadangkan otomatis ke folder internal dan pulihkan dari berkas pilihan pengguna ----------

    /**
     * Simpan satu cadangan tetap ke memori internal:
     * Jam Pintar Pro/Cadangan/Cadangan_Pengaturan.json.
     * Berkas lama diganti secara atomik agar cadangan sebelumnya tidak rusak bila penulisan gagal.
     */
    private fun mulaiCadangkan() {
        // Selalu minta persetujuan sebelum membuat atau menimpa berkas cadangan.
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.cadangan_konfirmasi_judul))
            .setMessage(getString(R.string.cadangan_konfirmasi_isi))
            .setPositiveButton(getString(R.string.cadangan_konfirmasi_ya)) { dialog, _ ->
                dialog.dismiss()
                lanjutkanMulaiCadangkan()
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun lanjutkanMulaiCadangkan() {
        when {
            Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager() -> {
                AlertDialog.Builder(this)
                    .setTitle(ui("Izin penyimpanan diperlukan"))
                    .setMessage(ui("Untuk menyimpan cadangan di Penyimpanan internal/Jam Pintar Pro/Cadangan, izinkan Akses semua berkas. Setelah kembali ke aplikasi, pencadangan akan dilanjutkan otomatis."))
                    .setPositiveButton(ui("Buka pengaturan")) { _, _ ->
                        cadanganMenungguIzin = true
                        try {
                            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:" + packageName)))
                        } catch (_: Exception) {
                            try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                            catch (_: Exception) { cadanganMenungguIzin = false; toast(R.string.cadangan_gagal) }
                        }
                    }
                    .setNegativeButton(ui("Batal"), null)
                    .show()
            }
            Build.VERSION.SDK_INT <= 28 &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED -> {
                requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), kodeIzinCadangan)
            }
            else -> simpanCadanganInternal()
        }
    }

    private fun simpanCadanganInternal() {
        // FIX248: diawali basmalah dan ditutup hamdalah (bila berhasil).
        ucapProses(tr("Bismillah. Memulai pencadangan pengaturan.", "Bismillah. Starting the settings backup."), true)
        try {
            val teks = CadanganPengaturan.buatJson(this)
            if (Build.VERSION.SDK_INT == 29) {
                // Android 10 membatasi penulisan langsung ke folder akar; gunakan koleksi Download
                // agar tetap tersimpan di memori internal tanpa meminta izin yang tidak tersedia.
                simpanCadanganMediaStore(teks)
            } else {
                val dasar = android.os.Environment.getExternalStorageDirectory()
                val folder = java.io.File(dasar, "Jam Pintar Pro/Cadangan")
                if (!folder.exists() && !folder.mkdirs() && !folder.exists()) {
                    throw IllegalStateException("Tidak dapat membuat folder cadangan")
                }
                val tujuan = java.io.File(folder, "Cadangan_Pengaturan.json")
                val sementara = java.io.File(folder, "Cadangan_Pengaturan.json.tmp")
                val lama = java.io.File(folder, "Cadangan_Pengaturan.json.bak")
                if (lama.exists()) lama.delete()
                try {
                    sementara.writeText(teks, Charsets.UTF_8)
                    if (tujuan.exists() && !tujuan.renameTo(lama)) {
                        throw IllegalStateException("Tidak dapat mengamankan cadangan lama")
                    }
                    if (!sementara.renameTo(tujuan)) {
                        if (lama.exists()) lama.renameTo(tujuan)
                        throw IllegalStateException("Tidak dapat mengganti cadangan")
                    }
                    lama.delete()
                } catch (e: Exception) {
                    sementara.delete()
                    if (!tujuan.exists() && lama.exists()) lama.renameTo(tujuan)
                    throw e
                }
            }
            toast(R.string.cadangan_berhasil)
            ucapProses(tr("Alhamdulillah, pencadangan pengaturan selesai.", "Alhamdulillah, the settings backup is complete."), false)
        } catch (_: Exception) {
            toast(R.string.cadangan_gagal)
            ucapProses(tr("Pencadangan pengaturan gagal.", "The settings backup failed."), false)
        }
    }

    @android.annotation.TargetApi(29)
    private fun simpanCadanganMediaStore(teks: String) {
        val nama = "Cadangan_Pengaturan.json"
        val relatif = "Download/Jam Pintar Pro/Cadangan/"
        val resolver = contentResolver
        resolver.query(
            android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(android.provider.MediaStore.MediaColumns._ID),
            android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " +
                android.provider.MediaStore.MediaColumns.RELATIVE_PATH + "=?",
            arrayOf(nama, relatif), null
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                resolver.delete(android.content.ContentUris.withAppendedId(
                    android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, id), null, null)
            }
        }
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, nama)
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/json")
            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, relatif)
            put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak dapat membuat berkas cadangan")
        try {
            resolver.openOutputStream(uri)?.use { it.write(teks.toByteArray(Charsets.UTF_8)) }
                ?: throw IllegalStateException("Tidak dapat menulis cadangan")
            resolver.update(uri, android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
            }, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PemanduIzinAwal.KODE) pemanduIzin.hasilIzinRuntime()
        if (requestCode == kodeIzinCadangan) {
            val diizinkan = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (diizinkan && pulihkanSetelahIzinLama) {
                pulihkanSetelahIzinLama = false
                mulaiPulihkanDariLokasiTetap()
            } else if (diizinkan) {
                simpanCadanganInternal()
            } else {
                pulihkanSetelahIzinLama = false
                toast(R.string.cadangan_gagal)
            }
        }
    }

    /** Pulihkan otomatis dari lokasi cadangan yang sama dengan lokasi pencadangan. */
    private fun mulaiPulihkan() {
        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pulihkanSetelahIzinLama = true
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), kodeIzinCadangan)
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.pulihkan_izin_judul))
                .setMessage(getString(R.string.pulihkan_izin_isi))
                .setPositiveButton(getString(R.string.pulihkan_izin_tombol)) { _, _ ->
                    pulihanMenungguIzin = true
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + packageName)))
                    } catch (_: Exception) {
                        try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                        catch (_: Exception) { pulihanMenungguIzin = false; toast(R.string.pulihkan_gagal_baca) }
                    }
                }
                .setNegativeButton(getString(R.string.cadangan_batal), null)
                .show()
            return
        }
        mulaiPulihkanDariLokasiTetap()
    }

    private fun mulaiPulihkanDariLokasiTetap() {
        try {
            val teks = if (Build.VERSION.SDK_INT == 29) bacaCadanganMediaStore()
            else {
                val berkas = java.io.File(android.os.Environment.getExternalStorageDirectory(),
                    "Jam Pintar Pro/Cadangan/Cadangan_Pengaturan.json")
                if (berkas.isFile) berkas.readText(Charsets.UTF_8) else null
            }
            if (teks.isNullOrBlank()) {
                toast(R.string.pulihkan_tidak_ditemukan)
                return
            }
            konfirmasiPulihkanTeks(teks)
        } catch (_: Exception) {
            toast(R.string.pulihkan_gagal_baca)
        }
    }

    @android.annotation.TargetApi(29)
    private fun bacaCadanganMediaStore(): String? {
        val relativo = "Download/Jam Pintar Pro/Cadangan/"
        val uriDasar = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
        contentResolver.query(uriDasar, arrayOf(android.provider.MediaStore.MediaColumns._ID),
            android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " +
                android.provider.MediaStore.MediaColumns.RELATIVE_PATH + "=?",
            arrayOf("Cadangan_Pengaturan.json", relativo), null)?.use { c ->
            if (c.moveToFirst()) {
                val uri = android.content.ContentUris.withAppendedId(uriDasar, c.getLong(0))
                return contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            }
        }
        return null
    }

    @Deprecated("Memakai pemilih berkas bawaan sistem untuk pemulihan")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == kodePulihkan) konfirmasiPulihkan(uri)
    }

    private fun konfirmasiPulihkan(uri: Uri) {
        val teks = CadanganPengaturan.bacaTeks(this, uri)
        if (teks == null) { toast(R.string.pulihkan_gagal_baca); return }
        konfirmasiPulihkanTeks(teks)
    }

    private fun konfirmasiPulihkanTeks(teks: String) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pulihkan_konfirmasi_judul))
            .setMessage(getString(R.string.pulihkan_konfirmasi_isi))
            .setPositiveButton(getString(R.string.pulihkan_ya)) { d, _ ->
                d.dismiss()
                terapkanPulihanTeks(teks)
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun konfirmasiReset() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.reset_konfirmasi_judul))
            .setMessage(getString(R.string.reset_konfirmasi_isi))
            .setPositiveButton(getString(R.string.reset_ya)) { d, _ ->
                d.dismiss()
                CadanganPengaturan.aturUlangSemua(this)
                toast(R.string.reset_berhasil)
                // Bangun ulang beranda agar semua sakelar dan status kembali ke tampilan awal.
                recreate()
            }
            .setNegativeButton(getString(R.string.cadangan_batal)) { d, _ -> d.dismiss() }
            .show()
    }

    private fun terapkanPulihanTeks(teks: String) {
        // FIX248: diawali basmalah dan ditutup hamdalah (bila berhasil).
        ucapProses(tr("Bismillah. Memulai pemulihan pengaturan dari cadangan.", "Bismillah. Starting to restore settings from the backup."), true)
        val jumlah = CadanganPengaturan.pulihkan(this, teks)
        if (jumlah < 0) {
            toast(R.string.pulihkan_gagal_format)
            ucapProses(tr("Pemulihan pengaturan gagal. Berkas cadangan tidak dikenali.", "Restoring settings failed. The backup file was not recognized."), false)
            return
        }
        CadanganPengaturan.segarkan(this)
        toast(R.string.pulihkan_berhasil)
        // Bangun ulang beranda setelah ucapan selesai (atau paling lama 8 detik) agar suara tidak terpotong.
        var sudah = false
        val bangunUlang = Runnable { if (!sudah && !isFinishing && !isDestroyed) { sudah = true; recreate() } }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(bangunUlang, 8000L)
        ucapProses(tr("Alhamdulillah, pemulihan pengaturan dari cadangan selesai.", "Alhamdulillah, restoring settings from the backup is complete."), false) {
            runOnUiThread(bangunUlang)
        }
    }

    private var pembicaraProses: Pembicara? = null

    private fun ucapProses(teks: String, flush: Boolean, selesai: (() -> Unit)? = null) {
        try {
            val p = pembicaraProses ?: Pembicara(this, prefs.suara("jam")) { toast(it) }.also { pembicaraProses = it }
            p.ucapkan(teks, flush, selesai)
        } catch (_: Exception) { selesai?.invoke() }
    }


    private fun mintaIzinNotifikasiJikaPerlu() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun perbaruiStatus() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val skala = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).let { if (it <= 0) 100 else it }
        val persen = if (level < 0) 0 else level * 100 / skala
        val mengisi = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val status = getString(if (mengisi) R.string.status_mengisi else R.string.status_tidak_mengisi)
        teksStatus.text = ui(getString(R.string.status_format, persen, status))
    }

    /** Pengingat sekali saja untuk HP selain Samsung agar pengguna membuka layar izin khusus merek. */
    private fun tampilkanPengingatIzinMerek() {
        val pref = getSharedPreferences("panduan_aplikasi", MODE_PRIVATE)
        if (pref.getBoolean("pengingat_izin_perangkat_tampil", false) || PerangkatIzin.samsung()) return
        // Tunggu dialog izin notifikasi sistem selesai (Android 13 ke atas) agar dua dialog tidak bertumpuk.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        pref.edit().putBoolean("pengingat_izin_perangkat_tampil", true).apply()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pengingat_izin_judul))
            .setMessage(getString(R.string.pengingat_izin_isi, PerangkatIzin.namaPerangkat()))
            .setPositiveButton(getString(R.string.pengingat_buka)) { d, _ ->
                d.dismiss()
                startActivity(Intent(this, IzinPerangkatActivity::class.java))
            }
            .setNegativeButton(getString(R.string.pengingat_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    // ---------- Pembaruan aplikasi ----------

    /** Membuka kanal publik resmi tempat pengembang menerbitkan informasi dan APK terbaru. */
    private fun bukaKanalPembaruanTelegram() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_telegram_judul))
            .setMessage(getString(R.string.update_telegram_isi))
            .setPositiveButton(getString(R.string.update_telegram_buka)) { d, _ ->
                d.dismiss()
                val url = "https://t.me/JamPintarPro"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                try {
                    // Android akan memilih Telegram jika tersedia, atau browser yang menangani tautan HTTPS.
                    startActivity(intent)
                } catch (_: Exception) {
                    toast(R.string.update_telegram_gagal_buka)
                }
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }

    /**
     * FIX290: alur pembaruan mengikuti Apktool M: ambil JSON versi (dengan penanda waktu), bandingkan nomor build, tampilkan nama, tanggal,
     * ukuran, dan catatan perubahan, lalu Unduh dan pasang / Nanti / Lewati versi ini. Pemeriksaan otomatis diam bila tidak ada pembaruan
     * atau versinya sudah dilewati; bila sumber tidak dapat dihubungi, pemeriksaan manual menawarkan kanal Telegram resmi.
     */
    private fun periksaPembaruan(manual: Boolean) {
        if (manual) toast(R.string.update_memeriksa)
        UpdateManager.periksa(this) { status, info ->
            if (isFinishing || isDestroyed) return@periksa
            when (status) {
                UpdateManager.STATUS_ADA -> if (info != null && (manual || !UpdateManager.dilewati(this, info.versionCode))) tampilkanPembaruan(info)
                UpdateManager.STATUS_TERBARU -> if (manual) toast(R.string.update_terbaru)
                else -> if (manual) {
                    toast(if (UpdateManager.terkonfigurasi()) R.string.update_gagal_cek else R.string.update_belum_diatur)
                    bukaKanalPembaruanTelegram()
                }
            }
        }
    }

    private fun tampilkanPembaruan(info: UpdateManager.Info) {
        val rincian = StringBuilder()
        if (info.tanggal.isNotBlank()) rincian.append(getString(R.string.update_rincian_tanggal, info.tanggal)).append('\n')
        if (info.ukuran.isNotBlank()) rincian.append(getString(R.string.update_rincian_ukuran, info.ukuran)).append('\n')
        val catatan = (rincian.toString() + info.catatan).trim()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_tersedia_judul))
            .setMessage(getString(R.string.update_tersedia_isi, info.versionName, UpdateManager.namaVersi(this), catatan).trim())
            .setPositiveButton(getString(R.string.update_tombol_unduh)) { d, _ ->
                d.dismiss()
                // FIX303: izin memasang aplikasi dari sumber ini diminta lebih dulu, bukan setelah unduhan selesai.
                if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) mintaIzinPasangLaluUnduh(info) else mulaiUnduh(info)
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .setNeutralButton(getString(R.string.update_tombol_lewati)) { d, _ ->
                UpdateManager.lewati(this, info.versionCode)
                d.dismiss()
            }
            .show()
    }

    private fun mintaIzinPasangLaluUnduh(info: UpdateManager.Info) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_izin_judul))
            .setMessage(getString(R.string.update_izin_isi_awal))
            .setCancelable(false)
            .setPositiveButton(getString(R.string.update_izin_buka)) { d, _ ->
                d.dismiss()
                infoMenungguIzinPasang = info
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + packageName)))
                } catch (e: Exception) { infoMenungguIzinPasang = null; bukaInfoApp(); mulaiUnduh(info) }
            }
            .setNegativeButton(getString(R.string.update_izin_lewati)) { d, _ -> d.dismiss(); mulaiUnduh(info) }
            .show()
    }

    private fun mulaiUnduh(info: UpdateManager.Info) {
        val id = try { UpdateManager.unduh(this, info) } catch (e: Exception) { -1L }
        if (id < 0) {
            toast(R.string.update_gagal_unduh)
            return
        }
        dialogUnduh = AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_mengunduh_judul))
            .setMessage(getString(R.string.update_mengunduh, 0))
            .setCancelable(false)
            .setNegativeButton(getString(R.string.update_batal)) { d, _ ->
                handlerUpdate.removeCallbacksAndMessages(null)
                UpdateManager.batalkan(this, id)
                d.dismiss()
            }
            .create()
        dialogUnduh?.show()
        pantauUnduh(id)
    }

    private fun pantauUnduh(id: Long) {
        if (isFinishing || isDestroyed) return
        val h = UpdateManager.progres(this, id)
        when (h[0]) {
            android.app.DownloadManager.STATUS_SUCCESSFUL -> {
                dialogUnduh?.dismiss()
                pasangPembaruan()
            }
            android.app.DownloadManager.STATUS_FAILED, -1 -> {
                dialogUnduh?.dismiss()
                toast(R.string.update_gagal_unduh)
            }
            else -> {
                dialogUnduh?.setMessage(getString(R.string.update_mengunduh, h[1]))
                handlerUpdate.postDelayed({ pantauUnduh(id) }, 800)
            }
        }
    }

    private fun pasangPembaruan() {
        when (UpdateManager.pasang(this)) {
            UpdateManager.PASANG_MULAI -> toast(R.string.update_memulai_pasang)
            UpdateManager.PASANG_BUTUH_IZIN -> {
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.update_izin_judul))
                    .setMessage(getString(R.string.update_izin_isi))
                    .setPositiveButton(getString(R.string.update_izin_buka)) { d, _ ->
                        d.dismiss()
                        try {
                            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + packageName)))
                        } catch (e: Exception) { bukaInfoApp() }
                    }
                    .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
                    .show()
            }
            else -> toast(R.string.update_gagal_pasang)
        }
    }

    /** Bila unduhan pembaruan sudah selesai tetapi belum dipasang (mis. setelah memberi izin), tawarkan memasang. */
    private fun tawarkanPasangJikaSiap() {
        if (tawaranPasangTampil || dialogPanduanTampil || pemutarPengantar != null) return
        if (dialogUnduh?.isShowing == true) return
        if (!UpdateManager.siapDipasang(this)) return
        tawaranPasangTampil = true
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_siap_judul))
            .setMessage(getString(R.string.update_siap_isi))
            .setPositiveButton(getString(R.string.update_siap_pasang)) { d, _ ->
                d.dismiss()
                pasangPembaruan()
            }
            .setNegativeButton(getString(R.string.update_tombol_nanti)) { d, _ -> d.dismiss() }
            .show()
    }
}
