#!/usr/bin/env python3
"""Uji FIX216: kalimat status baterai dan teks tampilan lain dirangkai dengan penggabungan teks biasa, tanpa templat dolar,
sehingga angka persen dan status benar-benar terucap ("Baterai tersisa 85 persen, tidak sedang diisi daya.").
Kontrak sumber + simulasi kalimat; bukan hasil kompilasi dan bukan uji perangkat."""
import re, sys
from pathlib import Path
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
gagal = []
def cek(nama, ok):
    if not ok: gagal.append(nama)
act = (R / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
zak = (R / "KalkulatorZakatActivity.kt").read_text(encoding="utf-8")

# 1. Blok kalimat baterai: tanpa templat, memakai penggabungan
awal = act.index("val statusBaterai = when (bahasa) {")
akhir = act.index("bacakanBateraiDenganSuara(teks)", awal)
blok = act[awal:akhir]
cek("blok baterai tanpa templat dolar", re.search(r"\$[A-Za-z_{]", blok.replace("\\$", "")) is None)
kalimat = {
    1: 'Battery is " + persen + " percent" + statusBaterai + "."',
    3: 'Baterei " + persen + " persen" + statusBaterai + "."',
    4: 'Batré " + persen + " persén" + statusBaterai + "."',
    0: 'Baterai tersisa " + persen + " persen" + statusBaterai + "."',
}
for k, v in kalimat.items():
    cek("kalimat bahasa %d memakai penggabungan" % k, v in blok)
cek("kalimat Arab memakai penggabungan", '" + persen + " بالمئة" + statusBaterai' in blok)

# 2. Simulasi kalimat (port dari blok Kotlin)
def status(bahasa, mengisi):
    return {1: (", and charging", ", not charging"), 2: ("، وهي قيد الشحن", "، وليست قيد الشحن"),
            3: (", lagi diisi", ", ora lagi diisi"), 4: (", keur dieusi", ", henteu keur dieusi"),
            0: (", dan sedang diisi daya", ", tidak sedang diisi daya")}[bahasa][0 if mengisi else 1]
def kalimat_baterai(bahasa, persen, mengisi):
    s = status(bahasa, mengisi)
    return {1: "Battery is " + str(persen) + " percent" + s + ".", 2: "مستوى البطارية " + str(persen) + " بالمئة" + s + ".",
            3: "Baterei " + str(persen) + " persen" + s + ".", 4: "Batré " + str(persen) + " persén" + s + ".",
            0: "Baterai tersisa " + str(persen) + " persen" + s + "."}[bahasa]
cek("Indonesia tidak diisi", kalimat_baterai(0, 85, False) == "Baterai tersisa 85 persen, tidak sedang diisi daya.")
cek("Indonesia diisi", kalimat_baterai(0, 100, True) == "Baterai tersisa 100 persen, dan sedang diisi daya.")
cek("English", kalimat_baterai(1, 7, True) == "Battery is 7 percent, and charging.")
for b in range(5):
    for p in (0, 5, 50, 100):
        for m in (False, True):
            t = kalimat_baterai(b, p, m)
            cek("angka %d muncul (bahasa %d)" % (p, b), str(p) in t and "$" not in t)

# 3. Tidak ada templat dolar pada teks yang diucapkan/ditampilkan
def baris_templat(sumber, kecuali=()):
    hasil = []
    for n, l in enumerate(sumber.split("\n"), 1):
        s = l.strip()
        if s.startswith("//") or s.startswith("*") or s.startswith("/*"): continue
        if re.search(r"\$[A-Za-z_{]", l.replace("\\$", "")) and not any(k in l for k in kecuali):
            hasil.append((n, s[:100]))
    return hasil
sisa_act = baris_templat(act, kecuali=("https://", "HTTP_STATUS"))
cek("PerintahSuaraActivity: tidak ada templat dolar pada teks ucapan/tampilan %s" % sisa_act[:2], not sisa_act)
sisa_zak = baris_templat(zak)
cek("KalkulatorZakatActivity: tidak ada templat dolar pada teks tampilan %s" % sisa_zak[:2], not sisa_zak)
cek("durasi timer tanpa templat", 'add("" + h + " "' in act and '"Timer started for " + lama + "."' in act)

if gagal:
    print("UJI UCAPAN BATERAI: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI UCAPAN BATERAI: LULUS (kontrak sumber + simulasi 5 bahasa)")
