# FIX216 — Ucapan status baterai menyebut angka dan status yang sebenarnya

Basis: FIX215. Berkas: `PerintahSuaraActivity.kt`, `KalkulatorZakatActivity.kt`, uji baru `tools/uji_ucapan_baterai.py`.

## Masalah
Saat asisten (perintah suara) diminta menyebut status atau indikator baterai, yang terdengar: "baterai tersisa persen, persen status baterai", tanpa angka persen dan tanpa keterangan diisi/tidak diisi.

## Penyebab
Kalimat dirangkai dengan templat Kotlin: `"Baterai tersisa $persen persen$statusBaterai."` (dan padanan Inggris, Arab, Jawa, Sunda). Pada build yang dipakai, templat itu sampai ke mesin suara
sebagai teks mentah. Pengaman di `Pembicara` membuang simbol dolar agar tidak dibaca "dolar", tetapi nama variabelnya tertinggal, sehingga terdengar "persen persen status baterai"
(`persen` dan `statusBaterai` terbaca sebagai kata). Ini kelas masalah yang sama dengan FIX53, FIX115, FIX133, dan FIX166: kalimat yang diucapkan atau ditampilkan tidak boleh memakai templat dolar.

## Perbaikan
- Lima kalimat baterai (Indonesia, English, Arab, Jawa, Sunda) kini memakai penggabungan teks biasa, mis. `"Baterai tersisa " + persen + " persen" + statusBaterai + "."`.
  Hasilnya: "Baterai tersisa 85 persen, tidak sedang diisi daya." atau "Baterai tersisa 100 persen, dan sedang diisi daya." (English: "Battery is 7 percent, and charging.").
- Kelas masalah yang sama dibersihkan pada teks lain yang diucapkan atau ditampilkan: jawaban sisa waktu timer dan durasi timer di `PerintahSuaraActivity`, serta ringkasan hasil di `KalkulatorZakatActivity`
  (nisab, nilai, harta bersih, hasil panen, jumlah jiwa, jumlah ternak). Templat pada kunci internal dan alamat URL tidak diubah karena tidak diucapkan atau ditampilkan.
- Tidak ada perubahan perilaku selain teks yang kini terisi nilainya.

## Bahasa aktif
Kalimat baterai tetap mengikuti bahasa tampilan aktif (5 bahasa) dan tidak ada teks baru yang dibuat; hanya cara perangkaiannya yang diganti.

## Cara menguji
1. Ucapkan "status baterai" atau "berapa persen baterai" lewat perintah suara dalam tiap bahasa aplikasi: angka persen dan keterangan "sedang diisi daya"/"tidak sedang diisi daya" harus terdengar.
2. Colok dan cabut pengisi daya lalu ulangi; keterangan harus berubah mengikuti kondisi.
3. Ucapkan "sisa waktu timer" dan pastikan durasi terbaca lengkap. Buka Kalkulator Zakat dan pastikan ringkasan hasil menampilkan angka.

## Batas pemeriksaan
Belum dikompilasi dan belum diuji di perangkat. Pemeriksaan statis lulus: kurung seimbang, tidak ada escape string tidak sah, `verify_project.py`, dan uji baru `uji_ucapan_baterai.py`
(kontrak sumber + simulasi kalimat 5 bahasa). Dua uji lama (`uji_mikrofon_perintah_suara.py`, `uji_suara_pengingat_baca_hafalan.py`) dan pemeriksa bahasa aktif
(7 teks Indonesia di `PerintahSuaraActivity.kt` yang belum dibungkus `tr()`) sudah gagal pada FIX215 asli dan tidak terkait perubahan ini.
