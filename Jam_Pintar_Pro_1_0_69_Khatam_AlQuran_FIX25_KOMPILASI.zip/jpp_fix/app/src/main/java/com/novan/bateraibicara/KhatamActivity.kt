package com.novan.bateraibicara

import android.app.AlertDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Pembaca Al-Qur'an dan pendamping khatam. Teks/terjemahan disimpan di perangkat setelah diunduh. */
class KhatamActivity : Halaman() {
    override val judulHalaman = R.string.khatam_judul
    private val handler = Handler(Looper.getMainLooper())
    private val dataPrefs by lazy { getSharedPreferences("khatam_quran", MODE_PRIVATE) }
    private var quran: JSONObject? = null
    private var terjemahan: JSONObject? = null
    private var nomorSurah = 1
    private var nomorAyat = 1
    private var tampilkanArti = true
    private var ukuranArab = 28f
    private var pemutar: MediaPlayer? = null
    private var audioSiap = false
    private var dialogUnduh: AlertDialog? = null
    private var status: TextView? = null
    private var ayatArab: TextView? = null
    private var ayatArti: TextView? = null
    private var teksReferensi: TextView? = null
    private var tombolAudio: android.widget.Button? = null

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1, 114)
        nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        tampilkanArti = dataPrefs.getBoolean("tampilkan_terjemahan", true)
        ukuranArab = dataPrefs.getFloat("ukuran_arab", 28f).coerceIn(22f, 42f)
        muatCache()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { pemutar?.stop() } catch (_: Exception) { }
        try { pemutar?.release() } catch (_: Exception) { }
        pemutar = null
        try { dialogUnduh?.dismiss() } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun bangun() {
        bagian(tr("Khatam Al-Qur'an", "Qur'an Completion"), 24f)
        info(tr(
            "Pembaca Al-Qur'an yang ramah pembaca layar. Teks Arab dan terjemahan dapat disimpan di perangkat agar bisa dibaca tanpa internet setelah diunduh. Kemajuan bacaan tersimpan di perangkat ini.",
            "A screen-reader-friendly Qur'an reader. Arabic text and translation can be saved on this device for offline reading after download. Reading progress is stored on this device."
        ))
        status = info(tr("Memeriksa teks Al-Qur'an yang tersimpan…", "Checking saved Qur'an text…"))
        tombol(tr("Lanjutkan bacaan terakhir", "Resume last reading")) { bukaAyatTersimpan() }
        tombol(tr("Baca Al-Qur'an / pilih surah", "Read Qur'an / choose surah")) { pilihSurah() }
        tombol(tr("Pilih juz", "Choose juz")) { pilihJuz() }
        tombol(tr("Unduh teks lengkap untuk penggunaan offline", "Download complete text for offline use")) { unduhSemuaTeks() }
        tombol(tr("Tandai ayat terakhir yang dibaca", "Mark last reading position")) { tandaiPosisi() }
        tombol(tr("Target khatam", "Khatam goal")) { pengaturanTarget() }
        tombol(tr("Kemajuan dan statistik", "Progress and statistics")) { tampilkanStatistik() }
        tombol(tr("Pengingat membaca Al-Qur'an", "Qur'an reading reminder")) { pengaturanPengingat() }
        tombol(tr("Pengaturan aksesibilitas", "Accessibility settings")) { pengaturanAksesibilitas() }
        tombol(tr("Riwayat khatam", "Khatam history")) { tampilkanRiwayat() }
        tombol(tr("Kembali ke beranda", "Back to home")) { finish() }
        bagian(tr("Sumber teks dan audio", "Text and audio sources"))
        info(tr(
            "Teks Arab dan terjemahan diambil melalui Al Quran Cloud API dan disimpan setelah diunduh. Sumber: alquran.cloud; teks Uthmani merujuk pada sumber Al-Qur'an yang dicantumkan penyedia. Audio murattal diputar secara streaming dan memerlukan internet. Audio offline belum disediakan karena izin pengunduhan dan distribusi rekaman perlu dipastikan.",
            "Arabic text and translation are retrieved through the Al Quran Cloud API and saved after download. Source: alquran.cloud; the Uthmani text refers to the Qur'an source credited by the provider. Murattal audio is streamed and requires internet. Offline audio is not provided until download and redistribution permissions for recordings are confirmed."
        ))
    }

    private fun cacheFile(name: String) = File(filesDir, name)
    private fun muatCache() {
        try {
            if (cacheFile("quran_ar.json").exists()) quran = JSONObject(cacheFile("quran_ar.json").readText(Charsets.UTF_8))
            val activeCache = if (BahasaAplikasi.tampilan(this) == 1) cacheFile("quran_en.json") else cacheFile("quran_id.json")
            if (activeCache.exists()) terjemahan = JSONObject(activeCache.readText(Charsets.UTF_8)) else terjemahan = null
            status?.text = if (quran != null) tr("Teks Arab tersedia di perangkat.", "Arabic text is available on this device.") else tr("Teks belum diunduh. Hubungkan internet lalu pilih unduh teks lengkap.", "Text is not downloaded yet. Connect to the internet and choose download complete text.")
        } catch (_: Exception) {
            quran = null; terjemahan = null
            status?.text = tr("Cache teks perlu diunduh ulang.", "Text cache needs to be downloaded again.")
        }
    }

    private fun fetch(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection)
        connection.connectTimeout = 20000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "JamPintarPro/1.0.69")
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException(("HTTP " + (code)))
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { connection.disconnect() }
    }

    private fun unduhSemuaTeks() {
        val progress = android.app.ProgressDialog(this)
        progress.setTitle(tr("Mengunduh teks Al-Qur'an", "Downloading Qur'an text"))
        progress.setMessage(tr("Mengunduh teks Arab dan terjemahan. Mohon tunggu; jangan tutup aplikasi.", "Downloading Arabic text and translation. Please wait; do not close the app."))
        progress.setCancelable(false)
        progress.show()
        dialogUnduh = progress
        Thread {
            try {
                val ar = fetch("https://api.alquran.cloud/v1/quran/quran-uthmani")
                val langCode = if (BahasaAplikasi.tampilan(this) == 1) "en.sahih" else "id.indonesian"
                val arti = fetch(("https://api.alquran.cloud/v1/quran/" + (langCode)))
                val arObj = JSONObject(ar); val artiObj = JSONObject(arti)
                val surahAr = arObj.optJSONObject("data")?.optJSONArray("surahs")
                val surahArti = artiObj.optJSONObject("data")?.optJSONArray("surahs")
                if (surahAr?.length() != 114) throw IllegalStateException("Jumlah surah Arab tidak lengkap")
                if (surahArti?.length() != 114) throw IllegalStateException("Jumlah surah terjemahan tidak lengkap")
                var countAr = 0; var countArti = 0
                for (i in 0 until 114) {
                    countAr += surahAr!!.optJSONObject(i)?.optJSONArray("ayahs")?.length() ?: 0
                    countArti += surahArti!!.optJSONObject(i)?.optJSONArray("ayahs")?.length() ?: 0
                }
                if (countAr != 6236 || countArti != 6236) throw IllegalStateException("Jumlah ayat tidak sesuai 6236")
                cacheFile("quran_ar.json").writeText(ar, Charsets.UTF_8)
                cacheFile(if (langCode == "en.sahih") "quran_en.json" else "quran_id.json").writeText(arti, Charsets.UTF_8)
                // Simpan cache aktif bahasa, sehingga pembaca tidak mencampur bahasa.
                cacheFile("quran_active_translation.json").writeText(arti, Charsets.UTF_8)
                runOnUiThread {
                    quran = arObj; terjemahan = artiObj
                    status?.text = tr("Teks lengkap tersimpan di perangkat dan siap dibaca offline.", "Complete text is saved on this device and ready for offline reading.")
                    progress.dismiss(); dialogUnduh = null
                    toast(tr("Unduhan teks selesai. Bacaan kini dapat dibuka tanpa internet.", "Text download complete. Reading is now available offline."))
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss(); dialogUnduh = null
                    toast(tr("Unduhan gagal. Periksa koneksi internet lalu coba lagi. Detail: ", "Download failed. Check your internet connection and try again. Details: ") + (e.message ?: ""))
                }
            }
        }.start()
    }

    private fun daftarSurah(): org.json.JSONArray? = quran?.optJSONObject("data")?.optJSONArray("surahs")

    private fun pilihSurah() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val surahs = daftarSurah() ?: return
        val labels = (0 until surahs.length()).map { i ->
            val s = surahs.getJSONObject(i)
            ("" + (s.optInt("number")) + ". " + (s.optString("englishName")) + " — " + (s.optString("name")) + " (" + (s.optInt("numberOfAyahs")) + " " + (tr("ayat", "verses")) + ")")
        }
        AlertDialog.Builder(this).setTitle(tr("Pilih surah", "Choose a surah"))
            .setItems(labels.toTypedArray()) { _, index -> nomorSurah = index + 1; nomorAyat = 1; tampilkanPembaca() }
            .setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun pilihJuz() {
        if (quran == null) { muatCache(); if (quran == null) { dialogBelumAdaTeks(); return } }
        val juz = (1..30).map { ("" + (tr("Juz", "Juz")) + " " + (it)) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Pilih juz", "Choose a juz")).setItems(juz) { _, which ->
            val target = which + 1
            val surahs = daftarSurah() ?: return@setItems
            var foundS = 1; var foundA = 1
            loop@ for (i in 0 until surahs.length()) {
                val verses = surahs.getJSONObject(i).optJSONArray("ayahs") ?: continue
                for (j in 0 until verses.length()) {
                    val a = verses.getJSONObject(j)
                    if (a.optInt("juz") == target) { foundS = i + 1; foundA = a.optInt("numberInSurah", 1); break@loop }
                }
            }
            nomorSurah = foundS; nomorAyat = foundA; tampilkanPembaca()
        }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun bukaAyatTersimpan() {
        nomorSurah = dataPrefs.getInt("terakhir_surah", 1).coerceIn(1,114)
        nomorAyat = dataPrefs.getInt("terakhir_ayat", 1).coerceAtLeast(1)
        if (quran == null) muatCache()
        if (quran == null) { dialogBelumAdaTeks(); return }
        tampilkanPembaca()
    }

    private fun dialogBelumAdaTeks() {
        AlertDialog.Builder(this).setTitle(tr("Teks belum tersedia", "Text not available"))
            .setMessage(tr("Untuk membaca offline, unduh dulu teks lengkap ketika tersambung ke internet.", "To read offline, first download the complete text while connected to the internet."))
            .setPositiveButton(tr("Unduh sekarang", "Download now")) { _, _ -> unduhSemuaTeks() }
            .setNegativeButton(tr("Nanti", "Later"), null).show()
    }

    private fun getSurah(n: Int): JSONObject? = daftarSurah()?.optJSONObject(n - 1)
    private fun getAyat(surah: Int, ayah: Int): JSONObject? = getSurah(surah)?.optJSONArray("ayahs")?.let { arr -> if (ayah in 1..arr.length()) arr.optJSONObject(ayah - 1) else null }

    private fun tampilkanPembaca() {
        val surah = getSurah(nomorSurah)
        if (surah == null) { dialogBelumAdaTeks(); return }
        val verses = surah.optJSONArray("ayahs") ?: return
        nomorAyat = nomorAyat.coerceIn(1, verses.length())
        // Simpan penanda terakhir tanpa menganggap ayat sudah selesai dibaca.
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        root.removeAllViews()
        bagian(tr("Pembaca Al-Qur'an", "Qur'an reader"), 24f)
        info(("" + (surah.optString("englishName")) + " — " + (surah.optString("name"))))
        info(tr("Surah", "Surah") + (" " + (nomorSurah) + ", ") + tr("ayat", "verse") + (" " + (nomorAyat) + " / " + (verses.length())))
        val a = getAyat(nomorSurah, nomorAyat) ?: return
        val ar = TextView(this)
        ar.text = a.optString("text")
        ar.textSize = ukuranArab
        ar.gravity = Gravity.CENTER
        ar.textDirection = android.view.View.TEXT_DIRECTION_RTL
        ar.setTextColor(warnaTeks())
        ar.setPadding(dp(12), dp(24), dp(12), dp(24))
        ar.contentDescription = tr("Teks Arab ayat", "Arabic verse text") + (" " + (nomorSurah) + ":" + (nomorAyat) + ". ") + a.optString("text")
        ar.setBackgroundColor(if (modeGelap()) Color.rgb(28, 44, 40) else Color.rgb(239, 236, 221))
        root.addView(ar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })
        ayatArab = ar
        val translatedSurah = terjemahan?.optJSONObject("data")?.optJSONArray("surahs")?.optJSONObject(nomorSurah - 1)
        val translatedAyat = translatedSurah?.optJSONArray("ayahs")?.optJSONObject(nomorAyat - 1)?.optString("text", "") ?: ""
        val arti = TextView(this)
        arti.text = if (translatedAyat.isBlank()) tr("Terjemahan belum tersedia. Unduh teks sesuai bahasa aplikasi.", "Translation is not available. Download text in the app's selected language.") else translatedAyat
        arti.textSize = 17f; arti.setTextColor(warnaTeks()); arti.setPadding(dp(8), dp(8), dp(8), dp(8))
        arti.visibility = if (tampilkanArti) android.view.View.VISIBLE else android.view.View.GONE
        root.addView(arti); ayatArti = arti
        val ref = info(tr("Surah", "Surah") + (" " + (nomorSurah) + ", ") + tr("ayat", "verse") + (" " + (nomorAyat)))
        teksReferensi = ref
        tombol(tr("Ayat sebelumnya", "Previous verse")) { if (nomorAyat > 1) nomorAyat-- else if (nomorSurah > 1) { nomorSurah--; nomorAyat = getSurah(nomorSurah)?.optJSONArray("ayahs")?.length() ?: 1 }; tampilkanPembaca() }
        tombol(tr("Ayat berikutnya", "Next verse")) { if (nomorAyat < verses.length()) nomorAyat++ else if (nomorSurah < 114) { nomorSurah++; nomorAyat = 1 }; tampilkanPembaca() }
        tombol(tr("Tandai ayat selesai dibaca", "Mark verse as read")) { tandaiAyatSelesai() }
        tombol(tr("Tandai posisi terakhir", "Save reading position")) { tandaiPosisi() }
        tombol(if (tampilkanArti) tr("Sembunyikan terjemahan", "Hide translation") else tr("Tampilkan terjemahan", "Show translation")) { tampilkanArti = !tampilkanArti; dataPrefs.edit().putBoolean("tampilkan_terjemahan", tampilkanArti).apply(); tampilkanPembaca() }
        tombol(tr("Perbesar teks Arab", "Increase Arabic text size")) { ukuranArab = (ukuranArab + 2f).coerceAtMost(42f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); tampilkanPembaca() }
        tombol(tr("Perkecil teks Arab", "Decrease Arabic text size")) { ukuranArab = (ukuranArab - 2f).coerceAtLeast(22f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); tampilkanPembaca() }
        tombolAudio = tombol(tr("Putar murattal surah ini (internet)", "Play this surah's murattal (internet)")) { putarAudioSurah() }
        tombol(tr("Jeda / lanjutkan audio", "Pause / resume audio")) { jedaLanjutAudio() }
        tombol(tr("Hentikan audio", "Stop audio")) { hentikanAudio(); toast(tr("Audio dihentikan.", "Audio stopped.")) }
        tombol(tr("Kembali ke menu khatam", "Back to Khatam menu")) { hentikanAudio(); bangunMenuLagi() }
    }

    private fun bangunMenuLagi() { root.removeAllViews(); bangun() }

    private fun putarAudioSurah() {
        try {
            try { pemutar?.release() } catch (_: Exception) { }
            pemutar = MediaPlayer()
            audioSiap = false
            val p = pemutar ?: return
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            p.setDataSource(("https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/" + (nomorSurah) + ".mp3"))
            p.setOnPreparedListener { audioSiap = true; it.start(); tombolAudio?.text = tr("Murattal sedang diputar", "Murattal is playing") }
            p.setOnCompletionListener { tombolAudio?.text = tr("Murattal selesai", "Murattal finished") }
            p.setOnErrorListener { _, _, _ -> toast(tr("Audio gagal diputar. Periksa koneksi internet.", "Audio could not be played. Check your internet connection.")); true }
            tombolAudio?.text = tr("Menghubungkan audio…", "Connecting to audio…")
            p.prepareAsync()
        } catch (e: Exception) { toast(tr("Audio tidak dapat diputar.", "Audio cannot be played.")) }
    }

    private fun jedaLanjutAudio() {
        val p = pemutar
        if (p == null || !audioSiap) { toast(tr("Putar murattal terlebih dahulu.", "Start the murattal first.")); return }
        try { if (p.isPlaying) p.pause() else p.start() } catch (_: Exception) { }
    }

    private fun hentikanAudio() {
        val p = pemutar
        pemutar = null
        audioSiap = false
        try { p?.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p?.setOnCompletionListener(null) } catch (_: Exception) { }
        try { if (p?.isPlaying == true) p.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
        tombolAudio?.text = tr("Putar murattal surah ini (internet)", "Play this surah's murattal (internet)")
    }

    private fun keyAyat() = ("" + (nomorSurah) + ":" + (nomorAyat))
    private fun tandaiPosisi() {
        dataPrefs.edit().putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val today = tanggalHariIni()
        dataPrefs.edit().putString("posisi_terakhir", ("" + (nomorSurah) + ":" + (nomorAyat) + "|" + (today))).apply()
        toast(tr("Posisi bacaan disimpan.", "Reading position saved."))
    }

    private fun tandaiAyatSelesai() {
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.toMutableSet() ?: mutableSetOf()
        val key = keyAyat()
        val added = completed.add(key)
        dataPrefs.edit().putStringSet("ayat_selesai", completed).putInt("terakhir_surah", nomorSurah).putInt("terakhir_ayat", nomorAyat).apply()
        val dayKey = ("selesai_" + (tanggalHariIni) + "()")
        val daily = dataPrefs.getStringSet(dayKey, emptySet())?.toMutableSet() ?: mutableSetOf()
        daily.add(key)
        dataPrefs.edit().putStringSet(dayKey, daily).apply()
        toast(if (added) tr("Ayat ditandai selesai. Kemajuan diperbarui.", "Verse marked as read. Progress updated.") else tr("Ayat ini sudah tercatat sebagai selesai.", "This verse is already marked as read."))
    }

    private fun pengaturanTarget() {
        val options = arrayOf(tr("30 hari", "30 days"), tr("60 hari", "60 days"), tr("90 hari", "90 days"), tr("Tentukan jumlah hari sendiri", "Choose a custom number of days"), tr("Tanpa target", "No target"))
        AlertDialog.Builder(this).setTitle(tr("Pilih target khatam", "Choose a Khatam goal")).setItems(options) { _, which ->
            when (which) {
                0,1,2 -> simpanTarget(listOf(30,60,90)[which])
                3 -> {
                    val input = android.widget.EditText(this); input.inputType = android.text.InputType.TYPE_CLASS_NUMBER; input.hint = tr("Jumlah hari (1–3650)", "Number of days (1–3650)")
                    AlertDialog.Builder(this).setTitle(tr("Target khusus", "Custom goal")).setView(input)
                        .setPositiveButton(tr("Simpan", "Save")) { _, _ -> val days = input.text.toString().toIntOrNull(); if (days != null && days in 1..3650) simpanTarget(days) else toast(tr("Masukkan angka 1 sampai 3650.", "Enter a number from 1 to 3650.")) }
                        .setNegativeButton(tr("Batal", "Cancel"), null).show()
                }
                else -> { dataPrefs.edit().putInt("target_hari", 0).remove("target_mulai").apply(); toast(tr("Target khatam dinonaktifkan. Kemajuan tetap disimpan.", "Khatam goal disabled. Progress will still be saved.")) }
            }
        }.show()
    }

    private fun simpanTarget(days: Int) {
        dataPrefs.edit().putInt("target_hari", days).putLong("target_mulai", System.currentTimeMillis()).apply()
        toast(tr("Target disimpan: ", "Goal saved: ") + ("" + (days) + " ") + tr("hari. Baca sesuai kemampuan; target dapat diubah kapan saja.", "days. Read at your own pace; you can change the goal anytime."))
    }

    private fun jumlahAyatTotal(): Int = 6236
    private fun urutanGlobal(s: Int, a: Int): Int {
        val surahs = daftarSurah() ?: return 0
        var count = 0
        for (i in 0 until (s - 1).coerceIn(0, surahs.length())) count += surahs.optJSONObject(i)?.optInt("numberOfAyahs", 0) ?: 0
        return count + a
    }

    private fun tampilkanStatistik() {
        val completed = dataPrefs.getStringSet("ayat_selesai", emptySet())?.size ?: 0
        val goal = dataPrefs.getInt("target_hari", 0)
        val perDay = if (goal > 0) kotlin.math.ceil(jumlahAyatTotal().toDouble() / goal).toInt() else 0
        val today = dataPrefs.getStringSet(("selesai_" + (tanggalHariIni) + "()"), emptySet())?.size ?: 0
        val pct = completed * 100.0 / jumlahAyatTotal()
        val msg = buildString {
            append(tr("Ayat yang ditandai selesai: ", "Verses marked as read: ")).append(completed).append(" / 6236\n")
            append(tr("Kemajuan: ", "Progress: ")).append(String.format(Locale.ROOT, "%.2f", pct)).append("%\n")
            append(tr("Ayat ditandai hari ini: ", "Verses marked today: ")).append(today).append("\n")
            append(tr("Target: ", "Goal: ")).append(if (goal == 0) tr("tanpa target", "no goal") else ("" + (goal) + " ") + tr("hari", "days"))
            if (goal > 0) append("\n").append(tr("Perkiraan ayat per hari untuk satu kali khatam: ", "Approximate verses per day for one completion: ")).append(perDay)
            append("\n\n").append(tr("Kemajuan dihitung dari ayat yang Anda tandai selesai, bukan dari audio yang hanya diputar. Tidak ada teguran jika target harian terlewat.", "Progress counts verses you mark as read, not audio that was merely played. There is no penalty for missing a daily target."))
        }
        AlertDialog.Builder(this).setTitle(tr("Kemajuan dan statistik", "Progress and statistics")).setMessage(msg).setPositiveButton(tr("Tutup", "Close"), null).show()
    }

    private fun tampilkanRiwayat() {
        val all = dataPrefs.all
        val rows = all.keys.filter { it.startsWith("selesai_") }.sortedDescending().take(30).map { key ->
            val day = key.removePrefix("selesai_")
            val count = (all[key] as? Set<*>)?.size ?: 0
            ("" + (day) + " — " + (count) + " ") + tr("ayat", "verses")
        }
        val message = if (rows.isEmpty()) tr("Belum ada riwayat ayat yang ditandai selesai.", "There is no history of verses marked as read yet.") else rows.joinToString("\n")
        AlertDialog.Builder(this).setTitle(tr("Riwayat bacaan", "Reading history")).setMessage(message).setPositiveButton(tr("Tutup", "Close"), null).show()
    }

    private fun pengaturanPengingat() {
        val enabled = dataPrefs.getBoolean("pengingat_aktif", false)
        val hour = dataPrefs.getInt("pengingat_jam", 20)
        val minute = dataPrefs.getInt("pengingat_menit", 0)
        AlertDialog.Builder(this).setTitle(tr("Pengingat membaca Al-Qur'an", "Qur'an reading reminder"))
            .setMessage(tr("Status saat ini: ", "Current status: ") + if (enabled) String.format(Locale.ROOT, "%02d:%02d", hour, minute) else tr("nonaktif", "off"))
            .setPositiveButton(tr("Atur waktu", "Set time")) { _, _ ->
                TimePickerDialog(this, { _, h, m ->
                    dataPrefs.edit().putBoolean("pengingat_aktif", true).putInt("pengingat_jam", h).putInt("pengingat_menit", m).apply()
                    jadwalkanPengingat(h, m)
                    toast(tr("Pengingat harian disetel.", "Daily reminder has been set."))
                }, hour, minute, true).show()
            }
            .setNeutralButton(if (enabled) tr("Matikan", "Turn off") else tr("Tutup", "Close")) { _, _ ->
                if (enabled) { dataPrefs.edit().putBoolean("pengingat_aktif", false).apply(); batalkanPengingat(); toast(tr("Pengingat dimatikan.", "Reminder turned off.")) }
            }.setNegativeButton(tr("Batal", "Cancel"), null).show()
    }

    private fun jadwalkanPengingat(hour: Int, minute: Int) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, KhatamReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 6901, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        if (Build.VERSION.SDK_INT >= 23) {
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        } else {
            @Suppress("DEPRECATION")
            alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }

    private fun batalkanPengingat() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(this, 6901, Intent(this, KhatamReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.cancel(pi); pi.cancel()
    }

    private fun pengaturanAksesibilitas() {
        val options = arrayOf(
            tr("Tampilkan terjemahan: ", "Show translation: ") + if (tampilkanArti) tr("aktif", "on") else tr("nonaktif", "off"),
            tr("Perbesar teks Arab", "Increase Arabic text size"),
            tr("Perkecil teks Arab", "Decrease Arabic text size"),
            tr("Unduh ulang teks untuk bahasa aktif", "Download text for the active language")
        )
        AlertDialog.Builder(this).setTitle(tr("Pengaturan aksesibilitas", "Accessibility settings")).setItems(options) { _, which ->
            when (which) {
                0 -> { tampilkanArti = !tampilkanArti; dataPrefs.edit().putBoolean("tampilkan_terjemahan", tampilkanArti).apply(); toast(if (tampilkanArti) tr("Terjemahan diaktifkan.", "Translation enabled.") else tr("Terjemahan disembunyikan.", "Translation hidden.")) }
                1 -> { ukuranArab = (ukuranArab + 2).coerceAtMost(42f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); toast(tr("Ukuran teks Arab: ", "Arabic text size: ") + ukuranArab.toInt()) }
                2 -> { ukuranArab = (ukuranArab - 2).coerceAtLeast(22f); dataPrefs.edit().putFloat("ukuran_arab", ukuranArab).apply(); toast(tr("Ukuran teks Arab: ", "Arabic text size: ") + ukuranArab.toInt()) }
                3 -> unduhSemuaTeks()
            }
        }.show()
    }

    private fun tanggalHariIni(): String = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())
}
