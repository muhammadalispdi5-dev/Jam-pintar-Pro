package com.novan.bateraibicara

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Bahasa tampilan utama dan penerjemahan label buatan kode agar konsisten. */
object BahasaAplikasi {
    fun tampilan(context: Context): Int = context.applicationContext
        .getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
        .getInt("bahasa_tampilan", 0).coerceIn(0, 1)

    fun simpanTampilan(context: Context, index: Int) {
        context.applicationContext.getSharedPreferences("pengaturan", Context.MODE_PRIVATE)
            .edit().putInt("bahasa_tampilan", index.coerceIn(0, 1)).apply()
    }

    fun bungkus(context: Context): Context {
        val locale = if (tampilan(context) == 1) Locale.ENGLISH else Locale("id", "ID")
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return context.createConfigurationContext(config)
    }

    fun teks(context: Context, source: String): String {
        if (tampilan(context) == 0 || source.isBlank()) return source
        val exact = map[source.trim()]
        if (exact != null) return exact
        // Terjemahkan awalan label dan istilah yang lazim, sambil mempertahankan nama pengguna,
        // waktu, angka, nama lokasi, serta nilai dinamis yang tidak boleh diubah.
        val prefixes = listOf(
            "Jadwal berikutnya:" to "Next schedule:", "Jam mulai:" to "Start time:",
            "Jam selesai:" to "End time:", "Hari aktif:" to "Active days:",
            "Nama lokasi:" to "Location name:", "Lokasi:" to "Location:",
            "Status izin" to "Permission status", "Perkiraan ketelitian" to "Estimated accuracy",
            "Waktu sholat" to "Prayer time", "Waktu salat" to "Prayer time",
            "Tanggal Masehi" to "Gregorian date", "Tanggal Hijriyah" to "Hijri date",
            "Berikutnya" to "Next", "Aktif" to "Enabled", "Tidak aktif" to "Disabled"
        )
        for ((id, en) in prefixes) if (source.startsWith(id)) return en + source.removePrefix(id)
        return source
    }

    private val map = mapOf(
        "Satu Sahabat Suara untuk Waktu, Ibadah, dan Aktivitas Sehari-hari. Dirancang dengan perhatian khusus pada kemudahan penggunaan bagi pengguna tunanetra dan pembaca layar." to "One voice companion for time, worship, and everyday activities. Designed with special care for blind users and screen-reader accessibility.",
        "Pengaturan Bahasa" to "Language Settings", "Bahasa Tampilan Utama" to "Main Display Language",
        "Bahasa Pengucapan" to "Speech Language", "Bahasa Indonesia" to "Indonesian",
        "English" to "English", "Simpan dan terapkan bahasa" to "Save and apply language settings",
        "Bahasa tampilan mengubah bahasa antarmuka aplikasi. Bahasa pengucapan mengatur bahasa suara untuk fitur yang mendukungnya." to "The display language changes the app interface. The speech language sets the spoken language for supported features.",
        "Baterai" to "Battery", "Jam" to "Clock", "Kalender" to "Calendar", "Nama Pemanggil" to "Caller Name",
        "Jadwal Sholat" to "Prayer Schedule", "Arah Kiblat" to "Qibla Direction",
        "Ketahui lokasi terkini" to "Current Location", "Cari fasilitas umum terdekat" to "Find Nearby Public Facilities",
        "Mode Acara dan Pertemuan" to "Events and Meetings Mode", "Petunjuk penggunaan" to "User Guide",
        "Cadangkan pengaturan" to "Back Up Settings", "Pulihkan pengaturan" to "Restore Settings",
        "Reset semua pengaturan ke awal" to "Reset All Settings", "Pembaruan dan bantuan" to "Updates and Help",
        "Izin dan kompatibilitas perangkat" to "Device Permissions and Compatibility", "Buka info aplikasi" to "Open App Info",
        "Hubungi pengembang" to "Contact Developer", "Periksa pembaruan" to "Check for Updates",
        "Aktifkan" to "Enable", "Aktif" to "Enabled", "Mati" to "Off", "Status aktif" to "Enabled",
        "Status mati" to "Disabled", "Jadwal" to "Schedule", "Ucapan" to "Speech",
        "Yang disebutkan saat jam bicara" to "What the clock announces", "Ucapkan jam" to "Speak the hour",
        "Sebutkan menit" to "Speak the minutes", "Bacakan detik" to "Speak the seconds",
        "Format waktu" to "Time Format", "Setiap beberapa menit: selang waktu" to "Interval in minutes",
        "Bacakan info waktu sholat berikutnya sekarang" to "Announce the next prayer time now",
        "Atur lokasi jadwal sholat" to "Set prayer schedule location", "Perbarui nama lokasi (kelurahan, kota, provinsi)" to "Update location name (district, city, province)",
        "Nama lokasi yang Anda isi sendiri dipakai apa adanya:" to "Your manually entered location name is used as entered:",
        "Mencari nama lokasi, mohon tunggu." to "Looking up the location name. Please wait.",
        "Nama lokasi belum ditemukan. Pastikan internet aktif, atau isi nama lokasi secara manual di halaman Jadwal Sholat." to "Location name not found. Check your internet connection or enter the location manually on the Prayer Schedule page.",
        "Lokasi jadwal sholat belum diatur. Atur lokasi di halaman Jadwal Sholat." to "The prayer schedule location has not been set. Set it on the Prayer Schedule page.",
        "Mesin suara" to "Speech Engine", "Kecepatan" to "Speed", "Nada" to "Pitch", "Keluaran volume" to "Audio Output",
        "Tes" to "Test", "Tes pengucapan" to "Speech Test", "Pengaturan suara" to "Speech Settings",
        "Pengaturan jam" to "Clock Settings", "Pengaturan kalender" to "Calendar Settings",
        "Pilih hari aktif" to "Select active days", "Minggu" to "Sunday", "Senin" to "Monday",
        "Selasa" to "Tuesday", "Rabu" to "Wednesday", "Kamis" to "Thursday", "Jumat" to "Friday", "Sabtu" to "Saturday",
        "Lokasi GPS" to "GPS location", "Lokasi jaringan" to "Network location", "Lokasi perangkat" to "Device location",
        "Perkiraan ketelitian" to "Estimated accuracy", "meter" to "meters", "Tidak ditemukan" to "Not found",
        "Kembali" to "Back", "Batal" to "Cancel", "Ya" to "Yes", "Tidak" to "No", "Simpan" to "Save",
        "Mati / tanpa melodi" to "Off / no melody", "Pagi" to "Morning", "Siang" to "Afternoon", "Sore" to "Late afternoon", "Malam" to "Night",
        "Setiap 5 menit" to "Every 5 minutes", "Setiap 10 menit" to "Every 10 minutes", "Setiap 15 menit" to "Every 15 minutes", "Setiap 20 menit" to "Every 20 minutes", "Setiap 30 menit" to "Every 30 minutes", "Setiap 1 jam" to "Every hour",
        "Format 24 jam" to "24-hour format", "Format 12 jam" to "12-hour format", "Mati" to "Off", "Hidup" to "On", "Otomatis" to "Automatic", "Manual" to "Manual",
        "Gregorian" to "Gregorian", "Hijriah" to "Hijri", "Masehi" to "Gregorian", "Pasaran Jawa" to "Javanese pasaran",
        "Aktifkan jam bicara" to "Enable talking clock", "Bacakan tanggal Masehi" to "Announce Gregorian date", "Bacakan tanggal Hijriah" to "Announce Hijri date", "Bacakan pasaran Jawa" to "Announce Javanese pasaran",
        "Bacakan info libur nasional" to "Announce national holidays", "Bacakan info cuti bersama" to "Announce collective leave information",
        "Sebutkan lokasi pada info sholat berikutnya" to "Include the location in the next prayer announcement", "Bacakan info waktu sholat berikutnya bersama pembacaan waktu" to "Announce the next prayer time with the clock",
        "Izinkan alarm tepat waktu untuk pemulihan otomatis" to "Allow exact alarms for automatic recovery", "Pengaturan waktu" to "Time Settings", "Pengaturan suara" to "Speech Settings",
        "Buka halaman arah kiblat dan jarum kompas" to "Open the Qibla direction and compass needle page", "Panduan kompas saat layar mati" to "Compass guidance while the screen is off",
        "Lokasi tersimpan" to "Saved location", "Lokasi belum diatur" to "Location has not been set", "Mencari lokasi, mohon tunggu." to "Finding location. Please wait.",
        "Izin diperlukan" to "Permission required", "Buka pengaturan" to "Open settings", "Pengaturan perangkat" to "Device settings", "Tes pengucapan" to "Speech test"
,
        "Arah Kiblat" to "Qibla Direction", "Arah kiblat" to "Qibla direction", "Arah kiblat dan kompas" to "Qibla Direction and Compass",
        "Atur lokasi manual" to "Set Location Manually", "Atur lokasi pada Jadwal Sholat" to "Set Location in Prayer Schedule", "Atur lokasi terlebih dahulu." to "Set the location first.",
        "Bacakan jadwal sholat hari ini" to "Announce today's prayer schedule", "Bacakan jadwal tanggal terpilih" to "Announce the selected date's schedule", "Bacakan kembali lokasi terakhir" to "Read the last location again",
        "Bacakan notifikasi pesan seluler atau SMS" to "Read mobile text messages or SMS notifications", "Pesan seluler atau SMS" to "Mobile messages or SMS",
        "Bacakan chat teks pribadi WhatsApp Messenger" to "Read private WhatsApp Messenger text chats", "Bacakan chat teks grup WhatsApp Messenger" to "Read WhatsApp Messenger group text chats",
        "Bacakan chat teks pribadi WhatsApp Business" to "Read private WhatsApp Business text chats", "Bacakan chat teks grup WhatsApp Business" to "Read WhatsApp Business group text chats",
        "Bacakan pemberitahuan pesan suara pribadi WhatsApp Messenger" to "Read private WhatsApp Messenger voice-message notifications", "Bacakan pemberitahuan pesan suara grup WhatsApp Messenger" to "Read WhatsApp Messenger group voice-message notifications",
        "Bacakan pemberitahuan pesan suara pribadi WhatsApp Business" to "Read private WhatsApp Business voice-message notifications", "Bacakan pemberitahuan pesan suara grup WhatsApp Business" to "Read WhatsApp Business group voice-message notifications",
        "Pengingat sebelum salat lima waktu" to "Reminders before the five daily prayers", "Pengingat sebelum sholat" to "Pre-prayer reminder", "Pengingat setiap waktu sholat" to "Reminder for each prayer time",
        "Pengingat waktu Imsak" to "Imsak Reminder", "Pengingat waktu berbuka puasa" to "Iftar Reminder", "Pengingat waktu sahur" to "Suhoor Reminder", "Pengingat waktu sholat" to "Prayer Time Reminder",
        "Pengingat Waktu Sahur dan Berbuka" to "Suhoor and Iftar Reminders", "Pengaturan Jadwal Sholat dan Pengingat" to "Prayer Schedule and Reminder Settings", "Suara azan dan tes suara" to "Adhan Sound and Sound Test",
        "Suara pemberitahuan berbuka puasa" to "Iftar Notification Sound", "Suara pemberitahuan sahur" to "Suhoor Notification Sound", "Sumber suara pengingat dan azan" to "Reminder and Adhan Sound Source",
        "Pembaruan otomatis jadwal melalui internet" to "Automatic Schedule Updates via Internet", "Perbarui jadwal sholat otomatis melalui internet" to "Automatically Update Prayer Times via Internet", "Perbarui jadwal sekarang melalui internet" to "Update Schedule Now via Internet",
        "Perbarui lokasi (GPS)" to "Update Location (GPS)", "Perbarui lokasi terkini" to "Update Current Location", "Buka halaman lokasi" to "Open Location Page", "Buka lokasi terakhir di peta" to "Open Last Location on Map",
        "Kelola lokasi tersimpan" to "Manage Saved Locations", "Simpan lokasi dengan nama pilihan" to "Save Location with a Custom Name", "Lokasi dan perhitungan" to "Location and Calculation", "Jadwal dan lokasi" to "Schedule and Location", "Metode perhitungan" to "Calculation Method",
        "Perhitungan Ashar" to "Asr Calculation", "Jenis puasa yang sedang diikuti" to "Fasting Type", "Jenis suara berbuka puasa: " to "Iftar sound type: ", "Jenis suara sahur: " to "Suhoor sound type: ", "Jenis puasa: " to "Fasting type: ",
        "Waktu khusus Dhuha dan Tahajud" to "Custom Dhuha and Tahajud Times", "Gunakan waktu khusus Dhuha" to "Use Custom Dhuha Time", "Gunakan waktu khusus Tahajud" to "Use Custom Tahajud Time",
        "Pilih berapa lama mode berlangsung" to "Choose How Long the Mode Lasts", "Durasi Mode Acara" to "Event Mode Duration", "Durasi Mode Jangan Ganggu" to "Do Not Disturb Duration", "Apa yang terdampak selama acara?" to "What Is Affected During the Event?",
        "Aktifkan Mode Acara" to "Enable Event Mode", "Akhiri Mode Acara dan Pulihkan" to "End Event Mode and Restore Settings", "Mode Acara diakhiri." to "Event Mode ended.", "Mode Acara diaktifkan sesuai cakupan yang dipilih." to "Event Mode enabled according to the selected scope.",
        "Aktifkan Mode Jangan Ganggu otomatis saat waktu salat" to "Automatically Enable Do Not Disturb at Prayer Time", "Mode Jangan Ganggu otomatis saat salat" to "Automatic Do Not Disturb During Prayer", "Mode Jangan Ganggu saat sholat" to "Do Not Disturb During Prayer",
        "Izinkan aplikasi mengatur Mode Jangan Ganggu" to "Allow the App to Control Do Not Disturb", "Izin Mode Jangan Ganggu sudah diberikan" to "Do Not Disturb permission has been granted", "Buka pengaturan izin Jangan Ganggu" to "Open Do Not Disturb Permission Settings",
        "Hentikan azan dengan menelungkupkan HP" to "Stop the Adhan by Placing the Phone Face Down", "Cara cepat menghentikan suara azan" to "Quick Way to Stop the Adhan", "Hentikan tes suara azan" to "Stop Adhan Sound Test", "Tes suara azan Subuh" to "Fajr Adhan Sound Test",
        "Kontrol tes suara azan" to "Adhan Sound Test Controls", "Tes nada singkat" to "Short Tone Test", "Ucapan arah otomatis setiap 1,5 detik" to "Automatic Direction Announcement Every 1.5 Seconds", "Panduan kompas saat layar mati" to "Compass Guidance While Screen Is Off",
        "Jadwal 30 hari ke depan" to "Schedule for the Next 30 Days", "Pilih hari dan jadwal 30 hari" to "Select a Day and View the 30-Day Schedule", "Pilih tanggal" to "Select Date", "Pilih hari aktif" to "Select Active Days",
        "Tambah atau kurangi menit" to "Add or Subtract Minutes", "Berkas semua waktu dihapus" to "All time-specific files have been deleted", "Semua berkas azan pilihan dihapus" to "All selected adhan files have been deleted", "Sumber suara disimpan" to "Sound source saved", "Lokasi disimpan" to "Location saved",
        "Pemilih berkas tidak dapat dibuka pada perangkat ini." to "The file picker cannot be opened on this device.", "Aplikasi peta tidak dapat dibuka." to "The map app could not be opened.", "Aplikasi peta tidak tersedia." to "The map app is unavailable.", "Layanan lokasi sedang mati." to "Location services are turned off.",
        "Lokasi belum ditemukan. Silakan coba lagi." to "Location not found. Please try again.", "Lokasi belum tersedia. Perbarui lokasi terlebih dahulu." to "Location is unavailable. Update the location first.", "Belum ada lokasi untuk disimpan. Cari lokasi terlebih dahulu." to "There is no location to save yet. Find a location first.",
        "Izin lokasi diperlukan untuk mengetahui lokasi terkini." to "Location permission is required to find the current location.", "Izinkan akses lokasi untuk menggunakan fitur ini." to "Allow location access to use this feature.", "Setelan lokasi tidak dapat dibuka." to "Location settings could not be opened.",
        "Mode Acara belum dapat diaktifkan. Periksa izin Jangan Ganggu." to "Event Mode could not be enabled. Check Do Not Disturb permission.", "Mode Jangan Ganggu otomatis memerlukan Android 6.0 atau lebih baru" to "Automatic Do Not Disturb requires Android 6.0 or later",
        "Pada versi Android ini, izin alarm tepat waktu dikelola otomatis." to "On this Android version, exact-alarm permission is managed automatically.", "Periksa atau izinkan alarm tepat waktu" to "Check or Allow Exact Alarms", "Periksa izin perangkat" to "Check Device Permissions",
        "Pilih jenis fasilitas yang ingin dicari." to "Choose the type of facility to find.", "Info Jadwal Sholat" to "Prayer Schedule Information", "Tanggal Syawal belum dapat disiapkan pada kalender perangkat" to "The Shawwal dates could not be prepared using the device calendar",
        "Format waktu" to "Time Format", "Jenis volume azan / Keluaran suara" to "Adhan Volume Type / Audio Output", "Jumlah pembacaan setiap notifikasi" to "Number of Reads per Notification", "Pengaturan pengulangan notifikasi pesan" to "Message Notification Repeat Settings",
        "Bacakan info libur nasional" to "Announce National Holidays", "Bacakan info cuti bersama" to "Announce Collective Leave Information", "Bacakan tanggal Masehi" to "Announce Gregorian Date", "Bacakan tanggal Hijriah" to "Announce Hijri Date", "Bacakan pasaran Jawa" to "Announce Javanese Pasaran",
        "Bacakan info waktu sholat berikutnya bersama pembacaan waktu" to "Announce the Next Prayer Time Along with the Clock", "Sebutkan lokasi pada info sholat berikutnya" to "Include the Location in the Next Prayer Announcement",
        "Pilih berkas audio dari penyimpanan internal untuk semua waktu atau atur suara berbeda bagi Imsak, Subuh, Terbit, Dhuha, Tahajud, Dzuhur, Ashar, Maghrib, dan Isya. Saat tes sedang diputar, gunakan tombol Jeda tes suara azan, Lanjutkan tes suara azan, atau Hentikan tes suara azan di bawah. Tombol-tombol ini hanya untuk tes di pengaturan, bukan azan normal." to "Choose an audio file from internal storage for all prayer times, or set different sounds for Imsak, Fajr, Sunrise, Dhuha, Tahajud, Dhuhr, Asr, Maghrib, and Isha. While the test is playing, use the Pause Adhan Sound Test, Resume Adhan Sound Test, or Stop Adhan Sound Test buttons below. These buttons are only for the settings test, not the actual adhan.",
        "Gunakan satu tombol ini saja. Ketuk pertama untuk memutar tes; ketika suara berjalan, ketuk lagi untuk menjeda; ketuk sekali lagi untuk melanjutkan dari posisi terakhir. Ketuk lama tidak diperlukan. Untuk menghentikan tes, gunakan tombol Hentikan tes di bagian bawah atau tindakan pada notifikasi." to "Use this single button. Tap once to play the test; tap again while it is playing to pause; tap once more to resume from the last position. A long press is not needed. To stop the test, use the Stop Test button at the bottom or the notification action.",
        "Arah kiblat dihitung dari koordinat lokasi ke Ka'bah. Jarum menunjukkan arah relatif menuju kiblat. Pengaturan terpisah di Pengaturan Jadwal Sholat menentukan apakah panduan tetap berjalan ketika layar mati. Pegang HP mendatar, layar menghadap ke atas, saat memakai kompas." to "The Qibla direction is calculated from your location coordinates to the Kaaba. The needle shows the relative direction of the Qibla. A separate setting in Prayer Schedule Settings controls whether guidance continues when the screen is off. Hold the phone flat with the screen facing up when using the compass.",
        "Gunakan saat rapat, musyawarah, pengajian, atau acara lain. Pilih apakah mode hanya menahan pengumuman Jam Pintar Pro atau juga menyenyapkan notifikasi HP. Mode akan berakhir otomatis sesuai durasi dan berusaha memulihkan pengaturan sebelumnya." to "Use this during meetings, discussions, religious study, or other events. Choose whether the mode silences only Jam Pintar Pro announcements or also mutes phone notifications. The mode ends automatically after the selected duration and attempts to restore the previous settings."
    )
}
