package com.novan.bateraibicara

import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView

/** Pengaturan aksesibel untuk menyenyapkan HP dan pengumuman Jam Pintar Pro sementara. */
class ModeAcaraActivity : Halaman() {
    override val judulHalaman = R.string.judul_mode_acara
    private var durasi = 60
    private lateinit var status: TextView

    override fun bangun() {
        info("Gunakan saat rapat, musyawarah, pengajian, atau acara lain. Mode ini mengaktifkan Jangan Ganggu, menahan pembacaan suara dari Jam Pintar Pro, lalu memulihkan pengaturan setelah durasi selesai. Mode ini tidak mengubah volume media secara permanen.")
        bagian("Durasi Mode Acara")
        pilihan("Pilih berapa lama mode berlangsung", listOf("30 menit", "1 jam", "2 jam", "3 jam", "Tanpa batas waktu"), 1) {
            durasi = when (it) { 0 -> 30; 1 -> 60; 2 -> 120; 3 -> 180; else -> 0 }
        }
        status = info("")
        tombol("Aktifkan Mode Acara") {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) {
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                catch (_: Exception) { toast("Buka Pengaturan Android, lalu izinkan akses Jangan Ganggu untuk Jam Pintar Pro.") }
                return@tombol
            }
            if (ModeAcara.mulai(this, durasi)) {
                perbaruiStatus()
                toast("Mode Acara diaktifkan. Pengumuman suara Jam Pintar Pro ditahan.")
            } else toast("Mode Acara belum dapat diaktifkan. Periksa izin Jangan Ganggu.")
        }
        tombol("Akhiri Mode Acara dan Pulihkan") {
            ModeAcara.selesai(this)
            perbaruiStatus()
            toast("Mode Acara diakhiri.")
        }
        tombol("Buka pengaturan izin Jangan Ganggu") {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Silakan cari akses Jangan Ganggu pada Pengaturan Android.") }
        }
        info("Catatan: jika Jangan Ganggu sudah aktif sebelum Mode Acara dimulai, pengaturan sebelumnya akan dipulihkan. Jika Anda mengubah Jangan Ganggu secara manual selama acara, aplikasi berusaha tidak menimpa perubahan tersebut.")
        perbaruiStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) perbaruiStatus()
    }

    private fun perbaruiStatus() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val aktif = ModeAcara.aktif(this)
        val akhir = getSharedPreferences("mode_acara", MODE_PRIVATE).getLong("berakhir", 0L)
        val durasiText = if (akhir > 0L) {
            val menit = ((akhir - System.currentTimeMillis()).coerceAtLeast(0L) / 60_000L)
            " Sisa waktu sekitar $menit menit."
        } else if (aktif) " Mode ini tidak memiliki batas waktu." else ""
        val teksStatusAktif = if (aktif) "AKTIF" else "NONAKTIF"
        val teksStatusIzin = if (nm.isNotificationPolicyAccessGranted) "diizinkan" else "belum diizinkan"
        status.text = "Status Mode Acara: " + teksStatusAktif + ". Izin Jangan Ganggu: " + teksStatusIzin + "." + durasiText
    }
}
