package com.novan.bateraibicara

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * FIX103: pengingat cerdas untuk hafalan Al-Qur'an (pengulangan berjarak / spaced repetition).
 *
 * Setiap ayat yang dilatih punya "tingkat" (0..6). Bila bacaan benar, tingkat naik dan jarak ulasan berikutnya
 * makin panjang (1, 2, 4, 7, 14, 30, 60 hari). Bila salah baca, tingkat kembali ke 0 dan ayat diulas lagi besok.
 * Pengingat harian hanya muncul bila ada ayat jatuh tempo (cerdas: tidak mengganggu saat tidak ada yang perlu diulang),
 * dan mengutamakan ayat yang paling terlambat serta paling sering salah.
 *
 * Data disimpan di SharedPreferences "khatam_quran". Objek ini murni logika + penjadwal alarm, dipakai oleh layar
 * Khatam, penerima pengingat, dan penerima boot.
 */
object HafalanSrs {
    const val PREF = "khatam_quran"
    private const val KEY_DATA = "hafalan_srs_data"
    const val KEY_PENGINGAT = "hafalan_srs_pengingat"
    const val KEY_JAM = "hafalan_srs_jam"
    const val KEY_MENIT = "hafalan_srs_menit"
    const val EXTRA_BUKA_ULASAN = "buka_ulasan_hafalan"
    const val ALARM_ID = 6911
    /** Nama surah (transliterasi Latin) untuk notifikasi dan daftar; tersedia tanpa memuat teks Al-Qur'an. */
    val NAMA_SURAH = arrayOf(
        "Al-Fatihah",
        "Al-Baqarah",
        "Ali 'Imran",
        "An-Nisa'",
        "Al-Ma'idah",
        "Al-An'am",
        "Al-A'raf",
        "Al-Anfal",
        "At-Taubah",
        "Yunus",
        "Hud",
        "Yusuf",
        "Ar-Ra'd",
        "Ibrahim",
        "Al-Hijr",
        "An-Nahl",
        "Al-Isra'",
        "Al-Kahf",
        "Maryam",
        "Ta Ha",
        "Al-Anbiya'",
        "Al-Hajj",
        "Al-Mu'minun",
        "An-Nur",
        "Al-Furqan",
        "Asy-Syu'ara'",
        "An-Naml",
        "Al-Qasas",
        "Al-'Ankabut",
        "Ar-Rum",
        "Luqman",
        "As-Sajdah",
        "Al-Ahzab",
        "Saba'",
        "Fatir",
        "Yasin",
        "As-Saffat",
        "Sad",
        "Az-Zumar",
        "Gafir",
        "Fussilat",
        "Asy-Syura",
        "Az-Zukhruf",
        "Ad-Dukhan",
        "Al-Jasiyah",
        "Al-Ahqaf",
        "Muhammad",
        "Al-Fath",
        "Al-Hujurat",
        "Qaf",
        "Az-Zariyat",
        "At-Tur",
        "An-Najm",
        "Al-Qamar",
        "Ar-Rahman",
        "Al-Waqi'ah",
        "Al-Hadid",
        "Al-Mujadalah",
        "Al-Hasyr",
        "Al-Mumtahanah",
        "As-Saff",
        "Al-Jumu'ah",
        "Al-Munafiqun",
        "At-Tagabun",
        "At-Talaq",
        "At-Tahrim",
        "Al-Mulk",
        "Al-Qalam",
        "Al-Haqqah",
        "Al-Ma'arij",
        "Nuh",
        "Al-Jinn",
        "Al-Muzzammil",
        "Al-Muddassir",
        "Al-Qiyamah",
        "Al-Insan",
        "Al-Mursalat",
        "An-Naba'",
        "An-Nazi'at",
        "'Abasa",
        "At-Takwir",
        "Al-Infitar",
        "Al-Mutaffifin",
        "Al-Insyiqaq",
        "Al-Buruj",
        "At-Tariq",
        "Al-A'la",
        "Al-Gasyiyah",
        "Al-Fajr",
        "Al-Balad",
        "Asy-Syams",
        "Al-Lail",
        "Ad-Duha",
        "Asy-Syarh",
        "At-Tin",
        "Al-'Alaq",
        "Al-Qadr",
        "Al-Bayyinah",
        "Az-Zalzalah",
        "Al-'Adiyat",
        "Al-Qari'ah",
        "At-Takasur",
        "Al-'Asr",
        "Al-Humazah",
        "Al-Fil",
        "Quraisy",
        "Al-Ma'un",
        "Al-Kausar",
        "Al-Kafirun",
        "An-Nasr",
        "Al-Lahab",
        "Al-Ikhlas",
        "Al-Falaq",
        "An-Nas"
    )

    fun namaSurah(n: Int): String = NAMA_SURAH.getOrNull(n - 1) ?: ("Surah " + n)

    val INTERVAL_HARI = intArrayOf(1, 2, 4, 7, 14, 30, 60)

    data class Item(val surah: Int, val ayat: Int, var level: Int, var jatuhTempo: Long, var salah: Int) {
        fun terlambat(hariIni: Long): Long = (hariIni - jatuhTempo).coerceAtLeast(0L)
    }

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Nomor hari lokal sejak epoch. */
    fun hariIni(now: Long = System.currentTimeMillis()): Long = (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L

    fun semua(p: SharedPreferences): MutableList<Item> {
        val hasil = mutableListOf<Item>()
        try {
            val arr = JSONArray(p.getString(KEY_DATA, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val s = o.optInt("s"); val a = o.optInt("a")
                if (s !in 1..114 || a < 1) continue
                hasil.add(Item(s, a, o.optInt("l").coerceIn(0, INTERVAL_HARI.size - 1), o.optLong("d"), o.optInt("x")))
            }
        } catch (_: Exception) { }
        return hasil
    }

    private fun simpan(p: SharedPreferences, daftar: List<Item>) {
        val arr = JSONArray()
        daftar.forEach { arr.put(JSONObject().put("s", it.surah).put("a", it.ayat).put("l", it.level).put("d", it.jatuhTempo).put("x", it.salah)) }
        p.edit().putString(KEY_DATA, arr.toString()).apply()
    }

    fun ada(p: SharedPreferences, s: Int, a: Int): Boolean = semua(p).any { it.surah == s && it.ayat == a }

    /** Tambah ayat ke daftar hafalan; jatuh tempo hari ini. */
    fun tambah(p: SharedPreferences, s: Int, a: Int) {
        val daftar = semua(p)
        if (daftar.none { it.surah == s && it.ayat == a }) { daftar.add(Item(s, a, 0, hariIni(), 0)); simpan(p, daftar) }
    }

    fun hapus(p: SharedPreferences, s: Int, a: Int) {
        simpan(p, semua(p).filterNot { it.surah == s && it.ayat == a })
    }

    fun kosongkan(p: SharedPreferences) { p.edit().remove(KEY_DATA).apply() }

    /** Catat hasil latihan: benar -> tingkat naik dan jarak melebar; salah -> kembali ke tingkat 0, ulas besok. */
    fun catat(p: SharedPreferences, s: Int, a: Int, benar: Boolean) {
        val daftar = semua(p)
        var item = daftar.firstOrNull { it.surah == s && it.ayat == a }
        if (item == null) { item = Item(s, a, 0, hariIni(), 0); daftar.add(item) }
        val hari = hariIni()
        if (benar) {
            item.jatuhTempo = hari + INTERVAL_HARI[item.level]
            item.level = (item.level + 1).coerceAtMost(INTERVAL_HARI.size - 1)
        } else {
            item.level = 0
            item.salah++
            item.jatuhTempo = hari + 1
        }
        simpan(p, daftar)
    }

    /** Ayat yang jatuh tempo, paling mendesak lebih dulu (paling terlambat, lalu paling sering salah). */
    fun jatuhTempo(p: SharedPreferences, hari: Long = hariIni()): List<Item> =
        semua(p).filter { it.jatuhTempo <= hari }.sortedWith(compareByDescending<Item> { it.terlambat(hari) }.thenByDescending { it.salah })

    // ---- alarm harian ----
    private fun pendingIntent(c: Context): PendingIntent =
        PendingIntent.getBroadcast(c, ALARM_ID, Intent(c, HafalanSrsReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun jadwalkan(c: Context) {
        val p = prefs(c)
        if (!p.getBoolean(KEY_PENGINGAT, false)) { batalkan(c); return }
        val jam = p.getInt(KEY_JAM, 19).coerceIn(0, 23)
        val menit = p.getInt(KEY_MENIT, 30).coerceIn(0, 59)
        val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, jam); set(Calendar.MINUTE, menit); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.timeInMillis, AlarmManager.INTERVAL_DAY, pendingIntent(c))
            else {
                @Suppress("DEPRECATION")
                alarm.setRepeating(AlarmManager.RTC_WAKEUP, next.timeInMillis, AlarmManager.INTERVAL_DAY, pendingIntent(c))
            }
        } catch (_: Exception) { }
    }

    fun batalkan(c: Context) {
        try {
            val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pendingIntent(c)
            alarm.cancel(pi); pi.cancel()
        } catch (_: Exception) { }
    }
}
