package com.novan.bateraibicara

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX198: data Kitab Hadits. Teks hadits TIDAK ditulis di dalam aplikasi; diunduh sekali dari layanan hadits publik
 * (proyek fawazahmed0/hadith-api lewat jsDelivr, cadangan GitHub), disimpan di penyimpanan aplikasi, lalu dibaca
 * secara bertahap (streaming) sehingga memori tetap kecil dan dapat dibaca tanpa internet.
 */
object KitabHadits {

    class Kitab(
        val kode: String,
        val judulId: String,
        val judulEn: String,
        /** Kandidat nama edisi Arab (dicoba berurutan). */
        val arab: List<String>,
        /** Kandidat nama edisi terjemahan Indonesia (opsional). */
        val indo: List<String>,
        /** Kitab yang seluruh haditsnya shahih (derajat tidak perlu dibaca dari data). */
        val seluruhShahih: Boolean
    )

    val daftar = listOf(
        Kitab("bukhari", "Shahih Bukhari", "Sahih al-Bukhari", listOf("ara-bukhari"), listOf("ind-bukhari"), true),
        Kitab("muslim", "Shahih Muslim", "Sahih Muslim", listOf("ara-muslim"), listOf("ind-muslim"), true),
        Kitab("arbain", "Arbain Nawawi (40 Hadits)", "Forty Hadith of an-Nawawi", listOf("ara-nawawi"), listOf("ind-nawawi"), false),
        Kitab("riyadus", "Riyadhus Shalihin", "Riyad as-Salihin", listOf("ara-riyadussalihin"), listOf("ind-riyadussalihin"), false)
    )

    fun cari(kode: String?): Kitab? = daftar.firstOrNull { it.kode == kode }

    class Hadis(val nomor: String, val teks: String, val bagian: Int, val derajat: String)

    class Hasil(val bagian: Map<Int, String>, val item: List<Hadis>, val adaLagi: Boolean)

    private fun folder(context: Context): File = File(context.filesDir, "hadits").also { it.mkdirs() }

    private fun berkas(context: Context, edisi: String) = File(folder(context), edisi + ".json")

    /** Berkas edisi pertama dari daftar kandidat yang sudah diunduh, atau null. */
    fun berkasAda(context: Context, kandidat: List<String>): File? =
        kandidat.map { berkas(context, it) }.firstOrNull { it.exists() && it.length() > 1024 }

    fun tersedia(context: Context, k: Kitab): Boolean = berkasAda(context, k.arab) != null

    fun hapus(context: Context, k: Kitab) {
        (k.arab + k.indo).forEach { try { berkas(context, it).delete() } catch (_: Exception) { } }
    }

    private fun alamat(edisi: String): List<String> = listOf(
        "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/" + edisi + ".min.json",
        "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/" + edisi + ".json",
        "https://raw.githubusercontent.com/fawazahmed0/hadith-api/1/editions/" + edisi + ".json"
    )

    /**
     * Unduh edisi pertama yang berhasil dari [kandidat]. Dipanggil dari utas latar.
     * [lapor] menerima jumlah byte yang sudah diterima. Mengembalikan berkas, atau null bila semua gagal.
     */
    fun unduh(context: Context, kandidat: List<String>, lapor: (Long) -> Unit): File? {
        for (edisi in kandidat) {
            for (url in alamat(edisi)) {
                val sementara = File(folder(context), edisi + ".part")
                var koneksi: HttpURLConnection? = null
                try {
                    koneksi = (URL(url).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000; readTimeout = 30000; requestMethod = "GET"; instanceFollowRedirects = true
                    }
                    if (koneksi.responseCode !in 200..299) continue
                    var total = 0L
                    koneksi.inputStream.use { masuk ->
                        FileOutputStream(sementara).use { keluar ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = masuk.read(buf)
                                if (n < 0) break
                                keluar.write(buf, 0, n)
                                total += n
                                lapor(total)
                            }
                        }
                    }
                    // Validasi: harus bisa dibaca dan memuat setidaknya satu hadits.
                    val uji = baca(sementara, 0, 1, true) { _, _ -> true }
                    if (total > 1024 && uji.item.isNotEmpty()) {
                        val tujuan = berkas(context, edisi)
                        tujuan.delete()
                        if (sementara.renameTo(tujuan)) return tujuan
                    }
                    sementara.delete()
                } catch (_: Exception) {
                    try { sementara.delete() } catch (_: Exception) { }
                } finally {
                    try { koneksi?.disconnect() } catch (_: Exception) { }
                }
            }
        }
        return null
    }

    private fun JsonReader.teksAtauKosong(): String = when (peek()) {
        JsonToken.STRING, JsonToken.NUMBER -> nextString()
        JsonToken.NULL -> { nextNull(); "" }
        else -> { skipValue(); "" }
    }

    private fun rapikanNomor(n: String): String = if (n.endsWith(".0")) n.substring(0, n.length - 2) else n

    /**
     * Baca berkas edisi secara bertahap. [lewati] hadits yang cocok dilompati, lalu diambil paling banyak [batas].
     * [hanyaMetadata] = berhenti begitu daftar hadits dimulai (untuk mengambil nama bagian saja).
     */
    fun baca(file: File, lewati: Int, batas: Int, hanyaMetadata: Boolean, cocok: (String, Int) -> Boolean): Hasil {
        val bagian = LinkedHashMap<Int, String>()
        val item = ArrayList<Hadis>()
        var adaLagi = false
        var dilewati = 0
        val pembaca = JsonReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8).buffered())
        try {
            pembaca.beginObject()
            while (pembaca.hasNext()) {
                when (pembaca.nextName()) {
                    "metadata" -> {
                        if (pembaca.peek() != JsonToken.BEGIN_OBJECT) { pembaca.skipValue(); continue }
                        pembaca.beginObject()
                        while (pembaca.hasNext()) {
                            if (pembaca.nextName() == "section" && pembaca.peek() == JsonToken.BEGIN_OBJECT) {
                                pembaca.beginObject()
                                while (pembaca.hasNext()) {
                                    val kunci = pembaca.nextName()
                                    val nilai = pembaca.teksAtauKosong().trim()
                                    val angka = kunci.toIntOrNull()
                                    if (angka != null && nilai.isNotEmpty()) bagian[angka] = nilai
                                }
                                pembaca.endObject()
                            } else pembaca.skipValue()
                        }
                        pembaca.endObject()
                    }
                    "hadiths" -> {
                        if (hanyaMetadata) return Hasil(bagian, item, false)
                        if (pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                        pembaca.beginArray()
                        while (pembaca.hasNext()) {
                            var nomor = ""
                            var teks = ""
                            var buku = 0
                            val derajat = ArrayList<String>()
                            pembaca.beginObject()
                            while (pembaca.hasNext()) {
                                when (pembaca.nextName()) {
                                    "hadithnumber" -> nomor = rapikanNomor(pembaca.teksAtauKosong())
                                    "text" -> teks = pembaca.teksAtauKosong()
                                    "grades" -> {
                                        if (pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                                        pembaca.beginArray()
                                        while (pembaca.hasNext()) {
                                            if (pembaca.peek() != JsonToken.BEGIN_OBJECT) { pembaca.skipValue(); continue }
                                            var nama = ""
                                            var nilai = ""
                                            pembaca.beginObject()
                                            while (pembaca.hasNext()) {
                                                when (pembaca.nextName()) {
                                                    "name" -> nama = pembaca.teksAtauKosong()
                                                    "grade" -> nilai = pembaca.teksAtauKosong()
                                                    else -> pembaca.skipValue()
                                                }
                                            }
                                            pembaca.endObject()
                                            if (nilai.isNotBlank()) derajat.add(if (nama.isBlank()) nilai else nilai + " (" + nama + ")")
                                        }
                                        pembaca.endArray()
                                    }
                                    "reference" -> {
                                        if (pembaca.peek() != JsonToken.BEGIN_OBJECT) { pembaca.skipValue(); continue }
                                        pembaca.beginObject()
                                        while (pembaca.hasNext()) {
                                            if (pembaca.nextName() == "book") buku = pembaca.teksAtauKosong().toDoubleOrNull()?.toInt() ?: 0
                                            else pembaca.skipValue()
                                        }
                                        pembaca.endObject()
                                    }
                                    else -> pembaca.skipValue()
                                }
                            }
                            pembaca.endObject()
                            if (nomor.isEmpty() || !cocok(nomor, buku)) continue
                            if (dilewati < lewati) { dilewati++; continue }
                            if (item.size >= batas) { adaLagi = true; return Hasil(bagian, item, true) }
                            item.add(Hadis(nomor, teks.trim(), buku, derajat.joinToString("; ")))
                        }
                        pembaca.endArray()
                    }
                    else -> pembaca.skipValue()
                }
            }
        } catch (_: Exception) {
            // Berkas rusak atau terpotong: kembalikan apa yang sudah terbaca.
        } finally {
            try { pembaca.close() } catch (_: Exception) { }
        }
        return Hasil(bagian, item, adaLagi)
    }

    /** Ambil teks terjemahan untuk himpunan nomor tertentu dari satu berkas edisi. */
    fun terjemahan(file: File, nomor: Set<String>): Map<String, String> {
        val hasil = HashMap<String, String>()
        if (nomor.isEmpty()) return hasil
        val pembaca = JsonReader(InputStreamReader(FileInputStream(file), Charsets.UTF_8).buffered())
        try {
            pembaca.beginObject()
            while (pembaca.hasNext()) {
                if (pembaca.nextName() != "hadiths" || pembaca.peek() != JsonToken.BEGIN_ARRAY) { pembaca.skipValue(); continue }
                pembaca.beginArray()
                while (pembaca.hasNext()) {
                    var no = ""
                    var teks = ""
                    pembaca.beginObject()
                    while (pembaca.hasNext()) {
                        when (pembaca.nextName()) {
                            "hadithnumber" -> no = rapikanNomor(pembaca.teksAtauKosong())
                            "text" -> teks = pembaca.teksAtauKosong()
                            else -> pembaca.skipValue()
                        }
                    }
                    pembaca.endObject()
                    if (no in nomor && teks.isNotBlank()) {
                        hasil[no] = teks.trim()
                        if (hasil.size >= nomor.size) return hasil
                    }
                }
                pembaca.endArray()
            }
        } catch (_: Exception) {
        } finally {
            try { pembaca.close() } catch (_: Exception) { }
        }
        return hasil
    }
}
