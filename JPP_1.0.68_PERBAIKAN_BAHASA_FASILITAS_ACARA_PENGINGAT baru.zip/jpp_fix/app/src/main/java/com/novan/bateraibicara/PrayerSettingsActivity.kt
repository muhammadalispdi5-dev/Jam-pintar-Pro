package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Semua pilihan jadwal, pengingat, metode, penyesuaian menit, dan sumber suara azan. */
class PrayerSettingsActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private val prayerNames = listOf(
        "Imsak" to "imsak", "Subuh" to "subuh", "Matahari terbit" to "terbit", "Dhuha" to "dhuha", "Tahajud" to "tahajud",
        "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya"
    )
    private lateinit var alarmPermissionStatus: TextView
    private var tombolTesRef: android.widget.Button? = null
    private fun segarkanLabelTes() {
        val b = tombolTesRef ?: return
        val label = labelTombolTes()
        val localized = ui(label)
        if (b.text.toString() != localized) { b.text = localized; b.contentDescription = localized }
    }
    private val requestGlobal = 50
    private val requestSahurSound = 90
    private val requestBerbukaSound = 91
    private fun requestPrayer(key: String) = 51 + prayerNames.indexOfFirst { it.second == key }
    private val advancePrayerNames = listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
    private fun requestAdvancePrayer(key: String) = 80 + advancePrayerNames.indexOfFirst { it.second == key }

    override fun onResume() {
        super.onResume()
        PrayerAlarm.scheduleAll(this)
        if (::alarmPermissionStatus.isInitialized) segarkanStatusIzinAlarm()
        segarkanLabelTes()
        // Android 12+ memerlukan akses khusus SCHEDULE_EXACT_ALARM. Versi kunci
        // dinaikkan agar pengguna yang pernah melihat halaman izin terkunci mendapat
        // satu kesempatan lagi setelah pembaruan aplikasi.
        if (Build.VERSION.SDK_INT >= 31) {
            val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
            if (!PrayerPrefs(this).dndEnabled) {
                state.edit().remove("prayer_dnd_exact_prompted_v2").apply()
            } else {
                val am = getSystemService(android.app.AlarmManager::class.java)
                if (am != null && am.canScheduleExactAlarms()) {
                    state.edit().remove("prayer_dnd_exact_prompted_v2").apply()
                } else if (!state.getBoolean("prayer_dnd_exact_prompted_v2", false)) {
                    state.edit().putBoolean("prayer_dnd_exact_prompted_v2", true).apply()
                    try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse(("package:" + (packageName))))) }
                    catch (_: Exception) { toast("Buka Pengaturan Android, lalu aktifkan Izinkan alarm dan pengingat agar Mode Jangan Ganggu dapat dipulihkan sesuai durasi.") }
                }
            }
        }
    }

    /**
     * Halaman ini dipecah menjadi daftar kelompok pendek agar pengguna pembaca layar tidak perlu
     * menelusuri ratusan elemen sekaligus. Setiap kelompok dibuka di halaman terpisah; tombol
     * Kembali membawa pengguna ke daftar kelompok.
     */
    override fun bangun() {
        when (intent.getStringExtra("kelompok")) {
            "jadwal" -> grupJadwal()
            "pengingat" -> grupPengingat()
            "puasa" -> grupPuasa()
            "awal" -> grupAwal()
            "dnd" -> grupDnd()
            "suara" -> grupSuara()
            "kiblat" -> grupKiblat()
            else -> menuUtama()
        }
    }

    private fun bukaKelompok(nama: String, kode: String) {
        startActivity(Intent(this, PrayerSettingsActivity::class.java).putExtra("kelompok", kode))
    }

    private fun judulKelompok(nama: String) {
        title = nama
        bagian(nama, 22f)
    }

    private fun menuUtama() {
        bagian("Pengaturan Jadwal Sholat dan Pengingat")
        info("Semua fitur jadwal sholat dan pengingat dinonaktifkan pada pengaturan awal. Aktifkan hanya yang Anda perlukan. Penghitungan waktu tetap dapat dilihat pada halaman Jadwal Sholat tanpa mengaktifkan pengingat.")
        saklar("Aktifkan pengingat waktu sholat", pp.enabled) { pp.enabled = it; PrayerAlarm.scheduleAll(this); if (it) mintaIzinNotifikasi() }
        info("Pilih satu kelompok pengaturan. Setiap kelompok dibuka di halaman tersendiri; tombol Kembali membawa Anda ke daftar ini.")
        tombol("Jadwal dan lokasi") { bukaKelompok("Jadwal dan lokasi", "jadwal") }
        tombol("Pengingat waktu sholat") { bukaKelompok("Pengingat waktu sholat", "pengingat") }
        tombol("Pengingat Waktu Sahur dan Berbuka") { bukaKelompok("Pengingat Waktu Sahur dan Berbuka", "puasa") }
        tombol("Pengingat sebelum sholat") { bukaKelompok("Pengingat sebelum sholat", "awal") }
        tombol("Mode Jangan Ganggu saat sholat") { bukaKelompok("Mode Jangan Ganggu saat sholat", "dnd") }
        tombol("Suara azan dan tes suara") { bukaKelompok("Suara azan dan tes suara", "suara") }
        tombol("Arah kiblat dan kompas") { bukaKelompok("Arah kiblat dan kompas", "kiblat") }
    }

    private fun grupJadwal() {
        judulKelompok("Jadwal dan lokasi")
        bagian("Pembaruan otomatis jadwal melalui internet")
        info("Pada instalasi baru, pembaruan online aktif agar jadwal mengikuti koordinat dan metode perhitungan yang dipilih. Koordinat dikirim ke layanan AlAdhan hanya untuk mengambil jadwal salat. Jika internet tidak tersedia atau layanan gagal, aplikasi memakai perhitungan lokal. Anda dapat menonaktifkan opsi ini kapan saja.")
        saklar("Perbarui jadwal sholat otomatis melalui internet", pp.autoOnline) { aktif ->
            pp.autoOnline = aktif
            if (aktif) {
                PrayerOnlineTimes.sync(this) { _, msg ->
                    runOnUiThread {
                        toast(msg)
                        if (pp.enabled) PrayerAlarm.scheduleAll(this)
                        // Segarkan label "Pembaruan terakhir" setelah hasil sinkronisasi tersedia.
                        if (!isFinishing && !isDestroyed) recreate()
                    }
                }
            } else {
                recreate()
            }
        }
        info(PrayerOnlineTimes.lastSyncLabel(this))
        tombol("Perbarui jadwal sekarang melalui internet") { PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); recreate(); PrayerAlarm.scheduleAll(this) } } }

        bagian("Lokasi dan perhitungan")
        info(if (pp.locationSet) ("Lokasi: " + (when (pp.place.trim()) { "Lokasi GPS" -> "GPS"; "Lokasi jaringan" -> "jaringan"; "Lokasi perangkat" -> "perangkat"; "Lokasi tersimpan" -> "tersimpan"; "Lokasi manual" -> "diatur secara manual"; else -> pp.place.trim().ifEmpty { "belum diketahui" } }) + ". Koordinat lokasi sudah tersimpan.") else "Lokasi belum diatur. Gunakan GPS atau isi lintang dan bujur pada halaman Jadwal Sholat.")
        tombol("Buka halaman lokasi") { startActivity(Intent(this, PrayerActivity::class.java)) }
        pilihan("Metode perhitungan", PrayerCalc.methodNames, pp.method) {
            pp.method = it
            if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); PrayerAlarm.scheduleAll(this); recreate() } }
            else PrayerAlarm.scheduleAll(this)
        }
        pilihan("Perhitungan Ashar", listOf("Mazhab Syafi'i, Maliki, Hanbali (bayangan 1x)", "Mazhab Hanafi (bayangan 2x)"), pp.asrFactor - 1) {
            pp.asrFactor = it + 1
            if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); PrayerAlarm.scheduleAll(this); recreate() } }
            else PrayerAlarm.scheduleAll(this)
        }
        pilihan("Format waktu", listOf("24 jam", "12 jam"), if (pp.use24) 0 else 1) { pp.use24 = it == 0 }

        bagian("Waktu khusus Dhuha dan Tahajud")
        info("Secara bawaan, Dhuha dan Tahajud tetap mengikuti waktu standar hasil perhitungan jadwal. Jika ingin azan/pengingat berbunyi pada jam pilihan sendiri, aktifkan waktu khusus, lalu pilih jamnya. Pengaturan ini memengaruhi jadwal dan alarm pengingat.")
        saklar("Gunakan waktu khusus Dhuha", pp.dhuhaCustomEnabled) { enabled ->
            pp.dhuhaCustomEnabled = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) ("Pengingat Dhuha menggunakan waktu pilihan: " + (formatJam(pp.dhuhaCustomMinute))) else "Waktu Dhuha kembali mengikuti perhitungan standar")
        }
        tombol(("Pilih waktu khusus Dhuha, saat ini " + (formatJam(pp.dhuhaCustomMinute)))) {
            TimePickerDialog(this, { _, hour, minute ->
                pp.dhuhaCustomMinute = hour * 60 + minute
                PrayerAlarm.scheduleAll(this); recreate()
                toast(("Waktu khusus Dhuha disimpan: " + (formatJam(pp.dhuhaCustomMinute))))
            }, pp.dhuhaCustomMinute / 60, pp.dhuhaCustomMinute % 60, pp.use24).show()
        }
        saklar("Gunakan waktu khusus Tahajud", pp.tahajudCustomEnabled) { enabled ->
            pp.tahajudCustomEnabled = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) ("Pengingat Tahajud menggunakan waktu pilihan: " + (formatJam(pp.tahajudCustomMinute))) else "Waktu Tahajud kembali mengikuti perhitungan standar")
        }
        tombol(("Pilih waktu khusus Tahajud, saat ini " + (formatJam(pp.tahajudCustomMinute)))) {
            TimePickerDialog(this, { _, hour, minute ->
                pp.tahajudCustomMinute = hour * 60 + minute
                PrayerAlarm.scheduleAll(this); recreate()
                toast(("Waktu khusus Tahajud disimpan: " + (formatJam(pp.tahajudCustomMinute))))
            }, pp.tahajudCustomMinute / 60, pp.tahajudCustomMinute % 60, pp.use24).show()
        }

        bagian("Tambah atau kurangi menit")
        info("Sesuaikan setiap waktu jika jadwal setempat berbeda. Anda dapat memajukan atau memundurkan waktu hingga 30 menit.")
        val adjust = listOf("Imsak" to "imsak", "Subuh" to "subuh", "Terbit" to "terbit", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        for ((label, key) in adjust) {
            val field = isian(("Penyesuaian " + (label) + " (menit)"), pp.adjustment(key).toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED) { raw ->
                raw.toIntOrNull()?.let { pp.setAdjustment(key, it) }
            }
            field.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) PrayerAlarm.scheduleAll(this) }
        }

    }

    private fun grupPengingat() {
        judulKelompok("Pengingat waktu sholat")
        bagian("Pengingat setiap waktu sholat")
        info("Aktifkan pengingat matahari terbit secara terpisah melalui sakelar Ingatkan waktu Matahari terbit.")
        for ((name, key) in prayerNames.filter { it.second != "imsak" }) {
            saklar(("Ingatkan waktu " + (name)), pp.reminder(key)) { pp.setReminder(key, it); PrayerAlarm.scheduleAll(this) }
        }
    }

    private fun grupPuasa() {
        judulKelompok("Pengingat Waktu Sahur dan Berbuka")
        info("Pilih satu jenis puasa. Pengingat sahur, Imsak, dan berbuka hanya dijadwalkan pada tanggal yang sesuai dengan jenis puasa tersebut. Seluruh sakelar pengingat tetap nonaktif sampai Anda mengaktifkannya.")
        val types = listOf("Tidak dipilih — pengingat puasa nonaktif", "Puasa Ramadan", "Puasa sunah Senin dan Kamis", "Puasa sunah Nabi Dawud", "Puasa sunah Syawal")
        val keys = listOf(FastingSchedule.NONE, FastingSchedule.RAMADAN, FastingSchedule.MON_THU, FastingSchedule.DAWUD, FastingSchedule.SHAWWAL)
        pilihan("Jenis puasa yang sedang diikuti", types, keys.indexOf(pp.fastingType).coerceAtLeast(0)) { idx ->
            pp.fastingType = keys[idx]
            PrayerAlarm.scheduleAll(this)
            toast("Jenis puasa: " + types[idx] + ". Jenis lain otomatis dinonaktifkan.")
            recreate()
        }
        when (pp.fastingType) {
            FastingSchedule.DAWUD -> {
                val startLabel = pp.dawudStartDate.takeIf { it.isNotBlank() }?.let { "Tanggal awal puasa Dawud: $it" } ?: "Tanggal awal puasa Dawud belum dipilih"
                info("Pilih tanggal yang benar-benar menjadi hari pertama berpuasa. Aplikasi akan menghitung pola selang-seling: puasa pada tanggal awal, tidak puasa keesokan harinya, lalu berpuasa lagi.")
                tombol(startLabel) {
                    val current = runCatching { java.time.LocalDate.parse(pp.dawudStartDate) }.getOrElse { java.time.LocalDate.now() }
                    android.app.DatePickerDialog(this, { _, year, month, day ->
                        pp.dawudStartDate = java.time.LocalDate.of(year, month + 1, day).toString()
                        PrayerAlarm.scheduleAll(this); recreate()
                        toast("Tanggal awal puasa Dawud disimpan: ${pp.dawudStartDate}")
                    }, current.year, current.monthValue - 1, current.dayOfMonth).show()
                }
            }
            FastingSchedule.SHAWWAL -> {
                val dates = pp.shawwalSelectedDates
                info("Pilih tanggal-tanggal puasa Syawal pada kalender Hijriah yang ditampilkan. Setiap tanggal juga dilengkapi tanggal Masehi hasil konversi kalender perangkat. Periksa kembali kesesuaian tanggal dengan kalender Hijriah resmi setempat.")
                tombol("Pilih tanggal puasa Syawal pada kalender Hijriah; ${dates.size} tanggal dipilih") {
                    pilihTanggalSyawal()
                }
            }
            FastingSchedule.RAMADAN -> info("Pengingat hanya berjalan selama bulan Ramadan menurut kalender Hijriah perangkat.")
            FastingSchedule.MON_THU -> info("Pengingat hanya berjalan setiap hari Senin dan Kamis.")
            else -> info("Pilih jenis puasa di atas untuk mengatur tanggal pengingat.")
        }

        bagian("Pengingat waktu sahur", 17f)
        info("Pengingat sahur dihitung mundur dari waktu Imsak dan hanya berbunyi pada tanggal puasa yang cocok dengan pilihan di atas.")
        saklar("Aktifkan pengingat waktu sahur", pp.sahurReminderEnabled) {
            pp.sahurReminderEnabled = it
            PrayerAlarm.scheduleAll(this)
            toast(if (it) "Pengingat sahur diaktifkan" else "Pengingat sahur dinonaktifkan")
        }
        val pilihanSahur = listOf("15 menit sebelum Imsak", "30 menit sebelum Imsak", "45 menit sebelum Imsak", "60 menit sebelum Imsak")
        val nilaiSahur = listOf(15, 30, 45, 60)
        pilihan("Waktu pengingat sahur", pilihanSahur, nilaiSahur.indexOf(pp.sahurReminderMinutes).coerceAtLeast(0)) { idx ->
            pp.sahurReminderMinutes = nilaiSahur[idx]
            PrayerAlarm.scheduleAll(this)
            toast("Pengingat sahur dijadwalkan ${nilaiSahur[idx]} menit sebelum Imsak")
        }
        bagian("Pengingat waktu Imsak", 17f)
        info("Pengingat Imsak mengikuti waktu Imsak lokal dan hanya dijadwalkan pada tanggal puasa yang dipilih. Suara Imsak tetap diatur melalui menu Suara azan dan tes suara.")
        saklar("Aktifkan pengingat waktu Imsak pada hari puasa", pp.reminder("imsak")) {
            pp.setReminder("imsak", it)
            PrayerAlarm.scheduleAll(this)
            toast(if (it) "Pengingat Imsak pada hari puasa diaktifkan" else "Pengingat Imsak dinonaktifkan")
        }
        bagian("Pengingat waktu berbuka puasa", 17f)
        info("Pengingat berbuka mengikuti jadwal Maghrib lokasi Anda, hanya pada tanggal puasa yang dipilih. Suara tetap memakai pilihan yang sudah tersedia.")
        saklar("Aktifkan pengingat waktu berbuka puasa", pp.berbukaReminderEnabled) { aktif ->
            pp.berbukaReminderEnabled = aktif
            PrayerAlarm.scheduleAll(this)
            toast(if (aktif) "Pengingat berbuka puasa diaktifkan" else "Pengingat berbuka puasa dinonaktifkan")
        }
        val offsetBerbuka = listOf(-30, -15, -10, -5, 0, 5, 10)
        val labelBerbuka = listOf("30 menit sebelum Maghrib", "15 menit sebelum Maghrib", "10 menit sebelum Maghrib", "5 menit sebelum Maghrib", "Tepat saat Maghrib", "5 menit setelah Maghrib", "10 menit setelah Maghrib")
        pilihan("Waktu pemutaran pengingat berbuka", labelBerbuka, offsetBerbuka.indexOf(pp.berbukaOffsetMinutes).coerceAtLeast(0)) { idx ->
            pp.berbukaOffsetMinutes = offsetBerbuka[idx]
            PrayerAlarm.scheduleAll(this)
            toast("Waktu pengingat berbuka: " + labelBerbuka[idx])
        }
    }

    private fun pilihTanggalSyawal() {
        val hijriYear = FastingSchedule.upcomingShawwalYear()
        val options = FastingSchedule.shawwalDates(hijriYear)
        if (options.isEmpty()) {
            toast("Tanggal Syawal belum dapat disiapkan pada kalender perangkat")
            return
        }
        val stored = pp.shawwalSelectedDates
        val labels = options.map { (hijriDay, date) -> "$hijriDay Syawal ${hijriYear} Hijriah — ${date.dayOfMonth}/${date.monthValue}/${date.year}" }.toTypedArray()
        val checked = BooleanArray(options.size) { options[it].second.toString() in stored }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.judul_pilih_tanggal_puasa_syawal, hijriYear))
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Simpan tanggal") { _, _ ->
                pp.shawwalSelectedDates = options.indices.filter { checked[it] }.map { options[it].second.toString() }.toSet()
                PrayerAlarm.scheduleAll(this)
                toast("Tanggal puasa Syawal disimpan: ${pp.shawwalSelectedDates.size} tanggal")
                recreate()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun grupAwal() {
        judulKelompok("Pengingat sebelum sholat")
        bagian("Pengingat sebelum salat lima waktu")
        info("Aktifkan pengingat pendahuluan untuk Subuh, Dzuhur, Ashar, Maghrib, dan Isya. Pilih apakah pengingat berbunyi 5, 10, 15, atau 30 menit sebelum waktu salat. Pengingat ini terpisah dari pengingat/azan pada waktu salat.")
        val sholatWajib = listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        val pilihanMenit = listOf("5 menit", "10 menit", "15 menit", "30 menit")
        val nilaiMenit = listOf(5, 10, 15, 30)
        for ((name, key) in sholatWajib) {
            bagian(("Pengingat sebelum " + (name)), 17f)
            saklar(("Aktifkan pengingat sebelum " + (name)), pp.advanceReminder(key)) {
                pp.setAdvanceReminder(key, it)
                PrayerAlarm.scheduleAll(this)
                toast(if (it) ("Pengingat sebelum " + (name) + " aktif, " + (pp.advanceMinutes(key)) + " menit sebelumnya") else ("Pengingat sebelum " + (name) + " dinonaktifkan"))
            }
            pilihan(("Waktu pengingat sebelum " + (name)), pilihanMenit, nilaiMenit.indexOf(pp.advanceMinutes(key)).coerceAtLeast(0)) { selected ->
                pp.setAdvanceMinutes(key, nilaiMenit[selected])
                PrayerAlarm.scheduleAll(this)
                toast(("Pengingat " + (name) + " akan berbunyi " + (nilaiMenit[selected]) + " menit sebelum waktu salat"))
            }
            val modeSuaraAwal = pp.advanceSoundMode(key)
            val labelSuaraAwal = when (modeSuaraAwal) {
                1 -> "audio pemberitahuan bawaan aplikasi"
                2 -> "suara pilihan pengguna"
                else -> "suara bicara standar Android"
            }
            info(("Jenis suara pengingat sebelum " + (name) + ": " + (labelSuaraAwal)))
            tombol(("Pilih jenis suara pengingat sebelum " + (name))) {
                val opsi = arrayOf("Suara standar Android", "Suara pemberitahuan bawaan aplikasi", "Pilih berkas suara sendiri")
                AlertDialog.Builder(this)
                    .setTitle(("Jenis suara pengingat sebelum " + (name)))
                    .setSingleChoiceItems(opsi, modeSuaraAwal) { dialog, which ->
                        when (which) {
                            0 -> {
                                pp.setAdvanceSoundMode(key, 0)
                                pp.setAdvanceSound(key, "")
                                toast(("Pengingat sebelum " + (name) + " memakai suara standar Android"))
                                dialog.dismiss(); recreate()
                            }
                            1 -> {
                                pp.setAdvanceSoundMode(key, 1)
                                toast(("Pengingat sebelum " + (name) + " memakai audio pemberitahuan bawaan aplikasi"))
                                dialog.dismiss(); recreate()
                            }
                            2 -> {
                                dialog.dismiss()
                                pilihBerkas(requestAdvancePrayer(key))
                            }
                        }
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }
            tombol(("Tes suara pengingat sebelum " + (name))) { tesPengingatAwal(key) }
            tombol(("Kembalikan suara standar Android untuk pengingat sebelum " + (name))) {
                pp.setAdvanceSoundMode(key, 0)
                pp.setAdvanceSound(key, "")
                toast(("Suara pengingat sebelum " + (name) + " dikembalikan ke suara standar Android"))
                recreate()
            }
        }

    }

    private fun grupDnd() {
        judulKelompok("Mode Jangan Ganggu saat sholat")
        bagian("Mode Jangan Ganggu otomatis saat salat")
        info("Aplikasi dapat mengaktifkan Mode Jangan Ganggu saat waktu salat dan mengembalikan mode ponsel ke keadaan sebelumnya setelah durasi pilihan. Android meminta izin khusus sebelum aplikasi boleh mengubah Mode Jangan Ganggu.")
        saklar("Aktifkan Mode Jangan Ganggu otomatis saat waktu salat", pp.dndEnabled) { enabled ->
            pp.dndEnabled = enabled
            PrayerAlarm.scheduleAll(this)
            if (enabled) mintaAksesJanganGanggu()
            toast(if (enabled) "Mode Jangan Ganggu otomatis diaktifkan untuk salat yang dipilih" else "Mode Jangan Ganggu otomatis dinonaktifkan")
        }
        pilihan("Durasi Mode Jangan Ganggu", listOf("5 menit", "10 menit", "15 menit", "30 menit"), listOf(5,10,15,30).indexOf(pp.dndDuration).coerceAtLeast(0)) { selected ->
            pp.dndDuration = listOf(5,10,15,30)[selected]
            PrayerAlarm.scheduleAll(this)
            toast(("Mode Jangan Ganggu akan berlangsung " + (pp.dndDuration) + " menit"))
        }
        tombol("Izinkan aplikasi mengatur Mode Jangan Ganggu") { mintaAksesJanganGanggu() }
        tombol("Periksa atau izinkan alarm tepat waktu") { bukaIzinAlarm() }
        alarmPermissionStatus = info("")
        segarkanStatusIzinAlarm()
        for ((name, key) in listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")) {
            saklar(("Mode Jangan Ganggu saat " + (name)), pp.dndPrayer(key)) { enabled ->
                pp.setDndPrayer(key, enabled); PrayerAlarm.scheduleAll(this)
                toast(if (enabled) ("Mode Jangan Ganggu saat " + (name) + " aktif") else ("Mode Jangan Ganggu saat " + (name) + " dinonaktifkan"))
            }
        }

    }

    private fun grupSuara() {
        judulKelompok("Suara azan dan tes suara")
        bagian("Cara cepat menghentikan suara azan")
        info("Aktifkan fitur ini agar azan yang sedang berbunyi dapat dihentikan dengan menelungkupkan HP di permukaan datar. Cara ini berlaku untuk azan terjadwal, bukan tes suara di pengaturan. Tombol Hentikan suara azan pada notifikasi tetap tersedia.")
        saklar("Hentikan azan dengan menelungkupkan HP", pp.stopAzanFaceDown) { enabled ->
            pp.stopAzanFaceDown = enabled
            toast(if (enabled) "Menelungkupkan HP akan menghentikan azan" else "Penghentian azan dengan gerakan dinonaktifkan")
        }

        bagian("Sumber suara pengingat dan azan")
        info("Pilih berkas audio dari penyimpanan internal untuk semua waktu atau atur suara berbeda bagi Imsak, Subuh, Terbit, Dhuha, Tahajud, Dzuhur, Ashar, Maghrib, dan Isya. Saat tes sedang diputar, gunakan tombol Jeda tes suara azan, Lanjutkan tes suara azan, atau Hentikan tes suara azan di bawah. Tombol-tombol ini hanya untuk tes di pengaturan, bukan azan normal.")
        bagian("Kontrol tes suara azan", 17f)
        info("Gunakan satu tombol ini saja. Ketuk pertama untuk memutar tes; ketika suara berjalan, ketuk lagi untuk menjeda; ketuk sekali lagi untuk melanjutkan dari posisi terakhir. Ketuk lama tidak diperlukan. Untuk menghentikan tes, gunakan tombol Hentikan tes di bagian bawah atau tindakan pada notifikasi.")
        val tombolTes = tombol(labelTombolTes()) { toggleTesAzan() }
        tombolTes.contentDescription = labelTombolTes()
        tombolTesRef = tombolTes
        // Layanan memperbarui status tes secara asinkron; baca ulang label setelah jeda singkat
        // agar tombol tidak menyebut keadaan sebelumnya (mis. tetap "Putar" padahal sudah diputar).
        tombolTes.setOnClickListener {
            toggleTesAzan()
            for (tunda in longArrayOf(400L, 1200L)) tombolTes.postDelayed({ segarkanLabelTes() }, tunda)
        }
        tombol("Pilih berkas azan cadangan untuk semua waktu") { pilihBerkas(requestGlobal) }
        info(("Berkas semua waktu: " + (if (pp.globalSound.isBlank()) "azan bawaan" else pp.globalSound)))
        tombol("Hapus berkas azan semua waktu") { pp.globalSound = ""; ulangiTesAktifJikaAda(); toast("Berkas semua waktu dihapus"); recreate() }
        tombol("Hapus semua berkas azan pilihan") {
            pp.globalSound = ""
            for ((_, key) in prayerNames) pp.setSound(key, "")
            ulangiTesAktifJikaAda()
            toast("Semua berkas azan pilihan dihapus"); recreate()
        }
        info("Pilih kelompok volume yang mengatur keras-lembutnya suara azan dan seluruh suara pengingat. Pilihan ini mengikuti pola Keluaran suara pada fitur Baterai, Jam, dan Nama Pemanggil.")
        pilihan("Jenis volume azan / Keluaran suara", larik(R.array.keluaran), pp.volumeMode) { pp.volumeMode = it }
        for ((name, key) in prayerNames) {
            bagian(("Suara pengingat " + (name)), 17f)
            if (key == "imsak" || key == "terbit" || key == "dhuha") {
                val mode = pp.reminderSoundMode(key)
                val modeLabel = when (mode) {
                    1 -> ("suara pengingat " + (name) + " bawaan aplikasi")
                    2 -> "berkas suara mandiri pilihan pengguna"
                    3 -> ("audio " + (name) + " bawaan aplikasi")
                    else -> if (pp.globalSound.isBlank()) "suara azan bawaan aplikasi" else "berkas suara umum pilihan pengguna"
                }
                info(("Jenis suara saat " + (name) + ": " + (modeLabel)))
                tombol(("Pilih jenis suara untuk " + (name))) {
                    val pilihanSuara = arrayOf("Suara azan bawaan atau suara umum", ("Suara pengingat " + (name) + " bawaan aplikasi"), "Pilih berkas suara sendiri dari penyimpanan")
                    AlertDialog.Builder(this)
                        .setTitle(("Jenis suara pengingat " + (name)))
                        .setSingleChoiceItems(pilihanSuara, mode.coerceIn(0, 2)) { dialog, which ->
                            when (which) {
                                0 -> {
                                    pp.setReminderSoundMode(key, 0)
                                    toast(("" + (name) + " memakai suara azan bawaan atau suara umum"))
                                    dialog.dismiss(); recreate()
                                }
                                1 -> {
                                    pp.setReminderSoundMode(key, 1)
                                    toast(("" + (name) + " memakai suara pengingat bawaan aplikasi"))
                                    dialog.dismiss(); recreate()
                                }
                                2 -> {
                                    dialog.dismiss()
                                    pilihBerkas(requestPrayer(key))
                                }
                            }
                        }.setNegativeButton("Batal", null).show()
                }
                info(("Berkas mandiri tersimpan: " + (if (pp.sound(key).isBlank()) "belum dipilih" else pp.sound(key))))
            } else {
                info(("Sumber suara: " + (if (pp.sound(key).isBlank()) if (pp.globalSound.isBlank()) if (key == "subuh") "azan Subuh bawaan" else "azan umum bawaan" else "berkas semua waktu" else pp.sound(key))))
            }
            tombol(("Pilih berkas suara " + (name))) { pilihBerkas(requestPrayer(key)) }
            tombol(if (key == "dhuha") "Putar atau jeda tes suara pengingat Dhuha" else ("Putar atau jeda tes suara azan " + (name))) { tesAzan(key) }
            tombol(("Gunakan suara umum atau bawaan untuk " + (name))) {
                pp.setSound(key, "")
                if (key == "imsak" || key == "terbit") pp.setReminderSoundMode(key, 0)
                if (key == "dhuha") pp.setReminderSoundMode(key, 1)
                if ((getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getString("test_playback_key", "subuh") ?: "subuh") == key) ulangiTesAktifJikaAda()
                recreate()
            }
        }
        bagian("Suara pemberitahuan sahur", 17f)
        val modeSahur = pp.reminderSoundMode("sahur")
        info("Jenis suara sahur: " + when (modeSahur) {
            1 -> "ucapan pemberitahuan sahur melalui mesin TTS"
            2 -> "berkas suara mandiri pilihan pengguna"
            3 -> "audio pemberitahuan sahur bawaan aplikasi"
            else -> if (pp.globalSound.isBlank()) "suara azan bawaan aplikasi" else "berkas suara umum pilihan pengguna"
        })
        tombol("Pilih jenis suara pemberitahuan sahur") {
            val opsi = arrayOf("Suara azan bawaan atau suara umum", "Ucapan pemberitahuan sahur melalui TTS", "Pilih berkas suara sendiri dari penyimpanan", "Audio pemberitahuan sahur bawaan aplikasi")
            AlertDialog.Builder(this).setTitle(getString(R.string.judul_suara_pemberitahuan_sahur))
                .setSingleChoiceItems(opsi, modeSahur) { dialog, which ->
                    when (which) {
                        0 -> { pp.setReminderSoundMode("sahur", 0); dialog.dismiss(); recreate() }
                        1 -> { pp.setReminderSoundMode("sahur", 1); dialog.dismiss(); recreate() }
                        2 -> { dialog.dismiss(); pilihBerkas(requestSahurSound) }
                        3 -> { pp.setReminderSoundMode("sahur", 3); pp.setSound("sahur", ""); dialog.dismiss(); recreate() }
                    }
                }.setNegativeButton("Batal", null).show()
        }
        info("Berkas suara sahur tersimpan: " + if (pp.sound("sahur").isBlank()) "belum dipilih" else pp.sound("sahur"))
        tombol("Pilih berkas suara pemberitahuan sahur") { pilihBerkas(requestSahurSound) }
        tombol("Putar atau jeda tes suara pemberitahuan sahur") { tesAzan("sahur") }
        tombol("Gunakan suara umum atau bawaan untuk pemberitahuan sahur") { pp.setSound("sahur", ""); pp.setReminderSoundMode("sahur", 0); recreate() }
        bagian("Suara pemberitahuan berbuka puasa", 17f)
        info("Jenis suara berbuka puasa: " + when (pp.reminderSoundMode("berbuka")) {
            1, 3 -> "audio pengingat berbuka puasa bawaan aplikasi"
            2 -> "berkas suara pilihan pengguna"
            else -> if (pp.globalSound.isBlank()) "suara azan bawaan aplikasi" else "berkas suara umum pilihan pengguna"
        })
        tombol("Pilih jenis suara pemberitahuan berbuka puasa") {
            val modeBerbuka = pp.reminderSoundMode("berbuka")
            val opsi = arrayOf("Suara azan bawaan atau suara umum", "Audio berbuka puasa bawaan aplikasi", "Pilih berkas suara sendiri dari penyimpanan")
            AlertDialog.Builder(this).setTitle(getString(R.string.judul_suara_pemberitahuan_berbuka))
                .setSingleChoiceItems(opsi, when (modeBerbuka) { 1, 3 -> 1; 2 -> 2; else -> 0 }) { dialog, which ->
                    when (which) {
                        0 -> { pp.setReminderSoundMode("berbuka", 0); dialog.dismiss(); recreate() }
                        1 -> { pp.setReminderSoundMode("berbuka", 3); pp.setSound("berbuka", ""); dialog.dismiss(); recreate() }
                        2 -> { dialog.dismiss(); pilihBerkas(requestBerbukaSound) }
                    }
                }.setNegativeButton("Batal", null).show()
        }
        info("Berkas suara berbuka tersimpan: " + if (pp.sound("berbuka").isBlank()) "belum dipilih" else pp.sound("berbuka"))
        tombol("Pilih berkas suara pemberitahuan berbuka puasa") { pilihBerkas(requestBerbukaSound) }
        tombol("Putar atau jeda tes suara pemberitahuan berbuka puasa") { tesAzan("berbuka") }
        tombol("Gunakan audio berbuka puasa bawaan aplikasi") { pp.setSound("berbuka", ""); pp.setReminderSoundMode("berbuka", 3); recreate() }
        tombol("Tes suara azan Subuh") { tesAzan("subuh") }
        tombol("Hentikan tes suara azan") { kontrolTes("STOP_TEST_PLAYBACK"); recreate() }

    }

    private fun grupKiblat() {
        judulKelompok("Arah kiblat dan kompas")
        bagian("Arah kiblat")
        saklar("Ucapan arah otomatis setiap 1,5 detik", pp.voiceQibla) { pp.voiceQibla = it }
        saklar("Getar panjang saat menghadap kiblat (selisih kurang dari 5 derajat)", pp.qiblaHaptic) { pp.qiblaHaptic = it }
        bagian("Panduan kompas saat layar mati")
        info("Sakelar ini hanya mengatur apakah panduan suara/nada boleh diteruskan saat layar mati. Sakelar tidak membuka atau menjalankan kompas. Untuk memulai panduan, buka halaman arah kiblat dan jarum kompas; jika opsi ini aktif, layanan latar belakang akan mulai saat halaman kompas dibuka.")
        val qiblaBgState = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        saklar("Izinkan panduan kompas tetap berjalan saat layar mati", qiblaBgState.getBoolean("qibla_screen_off_enabled", false)) { enabled ->
            qiblaBgState.edit().putBoolean("qibla_screen_off_enabled", enabled).apply()
            if (!enabled) {
                stopService(Intent(this, QiblaGuidanceService::class.java))
                qiblaBgState.edit().putBoolean("qibla_background_active", false).apply()
                toast("Panduan kompas tidak akan diteruskan saat layar mati.")
            } else {
                toast("Pengaturan disimpan. Buka halaman arah kiblat dan jarum kompas untuk memulai panduan.")
            }
        }
        tombol("Buka halaman arah kiblat dan jarum kompas") { startActivity(Intent(this, QiblaActivity::class.java)) }
    }

    private fun formatJam(total: Int): String {
        val h = (total.coerceIn(0, 1439) / 60).toString().padStart(2, '0')
        val m = (total.coerceIn(0, 1439) % 60).toString().padStart(2, '0')
        return if (pp.use24) ("" + (h) + ":" + (m)) else { val hour = total / 60; "%02d:%02d %s".format(if (hour % 12 == 0) 12 else hour % 12, total % 60, if (hour < 12) "AM" else "PM") }
    }

    private fun pilihBerkas(request: Int) {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i, request)
        } catch (e: Exception) { toast("Pemilih berkas tidak dapat dibuka pada perangkat ini.") }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        when (requestCode) {
            requestGlobal -> pp.globalSound = uri.toString()
            requestSahurSound -> { pp.setSound("sahur", uri.toString()); pp.setReminderSoundMode("sahur", 2) }
            requestBerbukaSound -> { pp.setSound("berbuka", uri.toString()); pp.setReminderSoundMode("berbuka", 2) }
            in 80..84 -> {
                val idx = requestCode - 80
                if (idx in advancePrayerNames.indices) {
                    val key = advancePrayerNames[idx].second
                    pp.setAdvanceSound(key, uri.toString())
                    pp.setAdvanceSoundMode(key, 2)
                }
            }
            else -> {
                val idx = requestCode - 51
                if (idx in prayerNames.indices) {
                    val key = prayerNames[idx].second
                    pp.setSound(key, uri.toString())
                    if (key == "imsak" || key == "terbit" || key == "dhuha") pp.setReminderSoundMode(key, 2)
                }
            }
        }
        toast("Sumber suara disimpan")
        ulangiTesAktifJikaAda()
        recreate()
    }

    private fun labelTombolTes(): String {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        return when {
            !state.getBoolean("test_playback_active", false) -> "Putar tes suara azan"
            state.getBoolean("test_playback_paused", false) -> "Lanjutkan tes suara azan"
            else -> "Jeda tes suara azan"
        }
    }
    private fun toggleTesAzan() {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!state.getBoolean("test_playback_active", false)) tesAzan("subuh")
        else kontrolTes("TOGGLE_TEST_PLAYBACK")
    }

    private fun tesAzan(key: String) {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        val active = state.getBoolean("test_playback_active", false)
        val currentKey = state.getString("test_playback_key", "subuh") ?: "subuh"
        // Ketuk tes pada waktu sholat lain berarti pilih dan putar berkasnya yang baru,
        // bukan menjeda pemutar lama. Jika kuncinya sama, tombol tetap berfungsi sebagai jeda/lanjut.
        val i = if (active && currentKey == key) {
            Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        } else {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true).apply {
                if (key == "sahur") putExtra("sahur_reminder", true)
                if (key == "berbuka") putExtra("berbuka_reminder", true)
            }
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Tidak dapat memutar atau menjeda suara. Periksa izin dan berkas audio.") }
    }


    private fun tesPengingatAwal(key: String) {
        val i = Intent(this, PrayerAlarmService::class.java)
            .putExtra("prayer_key", key)
            .putExtra("advance_reminder", true)
            .putExtra("test", true)
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Tes suara pengingat tidak dapat dijalankan. Periksa berkas suara dan izin notifikasi.") }
    }

    private fun ulangiTesAktifJikaAda() {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!state.getBoolean("test_playback_active", false)) return
        val key = state.getString("test_playback_key", "subuh") ?: "subuh"
        val i = Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true).apply {
            if (key == "sahur") putExtra("sahur_reminder", true)
            if (key == "berbuka") putExtra("berbuka_reminder", true)
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Berkas tersimpan, tetapi tes audio aktif tidak dapat dimulai ulang.") }
    }
    private fun kontrolTes(action: String) {
        val i = Intent(this, PrayerAlarmService::class.java).setAction(("com.novan.jambicarapro." + (action)))
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Kontrol tes suara tidak dapat dijalankan. Mulai tes suara terlebih dahulu.") }
    }

    private fun mintaAksesJanganGanggu() {
        if (Build.VERSION.SDK_INT >= 23) {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) { toast("Izin Mode Jangan Ganggu sudah diberikan"); return }
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Buka Pengaturan Android, lalu beri akses Jangan Ganggu untuk Jam Pintar Pro") }
        } else toast("Mode Jangan Ganggu otomatis memerlukan Android 6.0 atau lebih baru")
    }

    private fun mintaIzinNotifikasi() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 405)
    }
    private fun segarkanStatusIzinAlarm() {
        val status = if (Build.VERSION.SDK_INT < 31) {
            "Status izin alarm tepat waktu: dikelola otomatis oleh Android pada versi ini."
        } else {
            val am = getSystemService(android.app.AlarmManager::class.java)
            if (am?.canScheduleExactAlarms() == true) {
                "Status izin alarm tepat waktu: SUDAH DIIZINKAN. Android mengizinkan aplikasi menjadwalkan alarm tepat waktu."
            } else {
                "Status izin alarm tepat waktu: BELUM DIIZINKAN. Ketuk tombol Periksa atau izinkan alarm tepat waktu, lalu aktifkan izinnya di halaman Android jika sakelar tersedia. Kembali ke aplikasi untuk memeriksa status lagi."
            }
        }
        alarmPermissionStatus.text = ui(status)
        alarmPermissionStatus.contentDescription = ui(status)
    }

    private fun bukaIzinAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse(("package:" + (packageName))))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(("package:" + (packageName))))) }
        } else toast("Pada versi Android ini, izin alarm tepat waktu dikelola otomatis.")
    }
    private fun bukaNotifikasi() {
        try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(("package:" + (packageName))))) }
    }
}
