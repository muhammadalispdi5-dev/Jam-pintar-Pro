# FIX293 – Kalender Hijriah resmi Kemenag dan lokasi otomatis

## 1. Kalender Hijriah
- Sebelumnya: AlAdhan (bukan Kemenag) + hitungan perangkat; pergantian hari pukul 18.00 sudah ada.
- Tidak ditemukan API publik Kemenag yang stabil. Maka penetapan resmi diterbitkan pengembang sebagai `updates/hijriah_resmi.json` di repositori GitHub (cabang main) dan diambil otomatis (HijriahResmi.kt, tiap ≥6 jam, ?t= anti-cache). Data ini SELALU didahulukan di atas AlAdhan dan hitungan perangkat; bila tidak ada, perilaku lama berlaku.
- Format: {"sumber":"Kemenag RI","awal_bulan":[{"hijriah":"TAHUN-BULAN","masehi":"YYYY-MM-DD"}, ...]} — "masehi" = tanggal Masehi hari pertama bulan itu. Bulan wajib berurutan tanpa celah dan jarak antar awal bulan 28..31 hari, jika tidak berkas ditolak (data lama dipakai).
- Isi setelah Kemenag menetapkan (sidang isbat Ramadan, Syawal, Zulhijah, atau kalender resmi tahunan). Jangan salin angka contoh; isi sesuai keputusan resmi. Alamat lain dapat diatur di AppKonfigurasi.URL_HIJRIAH_RESMI.
- Pergantian hari Hijriah tetap pukul 18.00 lokal (sama dengan sebutan "malam").

## 2. Lokasi otomatis (LokasiOtomatis.kt)
- Saklar baru "Ikuti lokasi saya otomatis" (bawaan aktif) di pengaturan jadwal salat. Bila posisi baru ≥5 km dari lokasi tersimpan: lokasi, nama tempat, jadwal online, dan alarm salat diperbarui.
- Dipicu: membuka layar utama / jadwal salat, layanan latar tiap ≥5 menit (dibatasi 10 menit), dan perubahan zona waktu. Syarat: izin lokasi diberikan dan layanan lokasi perangkat menyala; memakai lokasi terakhir sistem (hemat baterai) atau satu permintaan singkat.
- Di latar belakang Android 10+ perlu izin lokasi "Sepanjang waktu": ACCESS_BACKGROUND_LOCATION ditambahkan dan tombol menuju pengaturan izin ditampilkan. Tanpa itu, lokasi diperbarui saat aplikasi dibuka.
- Lokasi yang diatur manual mematikan pengikut (dapat dinyalakan lagi).
- Uji: tools/uji_hijriah_resmi_lokasi.py. Petunjuk ID 63 / EN 60.
