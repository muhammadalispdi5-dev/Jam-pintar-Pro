#!/usr/bin/env python3
import sys
B='app/src/main/java/com/novan/bateraibicara/'
r=lambda f:open(B+f,encoding='utf-8').read()
kh,pa,ps,pp,sv,pq,gd=r('KhatamActivity.kt'),r('PemutarAudio.kt'),r('PrayerSettingsActivity.kt'),r('PrayerPrefs.kt'),r('PrayerAlarmService.kt'),r('PemutarQuranService.kt'),r('GemaDsp.kt')
gagal=[]
def cek(n,c):
    if not c: gagal.append(n)
cek("pudar akhir PemutarMono","frPudar" in pa and "Math.cos" in pa)
cek("pudar akhir pengumuman","Math.cos" in gd)
cek("dialog batal unduhan + konfirmasi","konfirmasiBatalUnduh" in kh and "Ya, batalkan semua" in kh and "unduhDibatalkan = true" in kh)
cek("tidak lagi ProgressDialog di unduhan Khatam","ProgressDialog" not in kh)
cek("kemajuan 5 persen diumumkan","langkah = p / 5" in kh and "announceForAccessibility(tr(\"Mengunduh \"" in kh)
cek("salin cek batal","salinDenganKemajuan" in kh and "cekBatalUnduh()" in kh)
cek("multi juz","setMultiChoiceItems" in kh and "Tandai semua juz" in kh and "nilai: Set<Int>" in kh)
cek("tarhim berkas prefs","tarhimBerkas" in pp)
cek("tarhim berkas UI","Pilih berkas audio Tarhim sendiri" in ps and "in 100..104" in ps)
cek("tarhim berkas service","pp.tarhimBerkas(key)" in sv)
cek("asisten mode online","daringSaja" in pq and "offlineSaja" in pq)
if gagal: print("UJI FIX315: GAGAL"); [print("-",g) for g in gagal]; sys.exit(1)
print("UJI FIX315: ok")
