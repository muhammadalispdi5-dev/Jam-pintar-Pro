#!/usr/bin/env python3
"""Uji FIX217: perintah suara informasi BMKG (port logika klasifikasi + kontrak sumber). Bukan hasil kompilasi Kotlin dan
bukan uji terhadap server BMKG sungguhan; contoh data mengikuti kolom yang didokumentasikan BMKG."""
from pathlib import Path
import re, sys, json
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
src = (R / "InfoBmkg.kt").read_text(encoding="utf-8")
act = (R / "PerintahSuaraActivity.kt").read_text(encoding="utf-8")
gagal = []
def cek(nama, ok):
    print(("LULUS" if ok else "GAGAL") + " - " + nama)
    if not ok: gagal.append(nama)

def token(u): return [x for x in re.sub(r"[^\w]+", " ", u.lower()).split() if x]
GEMPA = {"gempa","gempabumi","gempaan","earthquake","earthquakes","quake","quakes","lindu"}
def jenis(t):
    teks = " " + " ".join(t) + " "
    gempa = any(x in GEMPA for x in t) or " gempa bumi " in teks or " earth quake " in teks
    if any(x in ("tsunami","tsunamis") for x in t): return "TSUNAMI"
    if gempa:
        if any(x in {"dirasakan","dirasa","terasa","dirasakannya","felt"} for x in t): return "DIRASAKAN"
        lima = ("5" in t or "lima" in t) and any(x in {"lebih","atas","above","plus","mulai"} for x in t)
        minta = any(x in {"daftar","list","beberapa","semua","m5","magnitudo5"} for x in t)
        return "M5" if lima or minta else "TERBARU"
    per = ("peringatan" in t and "dini" in t) or " cuaca ekstrem " in teks or "nowcast" in t or ("early" in t and "warning" in t) \
        or ("severe" in t and "weather" in t) or ("waspada" in t and any(x in {"hujan","petir","angin","cuaca","banjir","puting"} for x in t))
    if per: return "PERINGATAN"
    if "bmkg" in t and not any(x in {"cuaca","weather","prakiraan","forecast","suhu","hujan"} for x in t): return "RINGKASAN"
    return None

kasus = {
 "gempa terbaru": "TERBARU", "info gempa terkini": "TERBARU", "gempa terakhir di mana": "TERBARU", "latest earthquake": "TERBARU",
 "ada gempa barusan": "TERBARU", "gempa bumi hari ini": "TERBARU",
 "gempa yang dirasakan": "DIRASAKAN", "felt earthquakes": "DIRASAKAN",
 "daftar gempa magnitudo 5 atau lebih": "M5", "gempa lima ke atas": "M5", "list of earthquakes": "M5",
 "apakah gempa tadi berpotensi tsunami": "TSUNAMI", "potensi tsunami": "TSUNAMI", "tsunami warning": "TSUNAMI",
 "peringatan dini cuaca": "PERINGATAN", "peringatan dini hujan lebat": "PERINGATAN", "cuaca ekstrem hari ini": "PERINGATAN",
 "weather early warning": "PERINGATAN", "waspada hujan lebat petir": "PERINGATAN",
 "informasi bmkg": "RINGKASAN", "info dari bmkg": "RINGKASAN",
 "cuaca hari ini": None, "apakah akan hujan": None, "cuaca menurut bmkg": None, "info baterai": None, "jam berapa sekarang": None,
 "putar surah al zalzalah": None,
}
for u, harap in kasus.items():
    cek("%s -> %s" % (u, harap), jenis(token(u)) == harap)

def wilayah(t):
    penanda = {"di","untuk","wilayah","provinsi","kota","kabupaten","in","for"}
    henti = {"saat","ini","sekarang","hari","terkini","terbaru","bmkg","dong","ya","tolong","please","now","today","yang","aktif","ada"}
    i = next((k for k, x in enumerate(t) if x in penanda), -1)
    if i < 0: return None
    sisa = [x for x in t[i+1:] if x not in penanda]
    out = []
    for x in sisa:
        if x in henti: break
        out.append(x)
    return " ".join(out) or None
cek("wilayah dari ucapan: jawa barat", wilayah(token("peringatan dini cuaca di jawa barat")) == "jawa barat")
cek("wilayah dari ucapan: kota bandung sekarang", wilayah(token("peringatan dini untuk kota bandung sekarang")) == "bandung")
cek("tanpa wilayah", wilayah(token("peringatan dini cuaca")) is None)

# parsing RSS dan pencocokan wilayah (data contoh sesuai elemen yang didokumentasikan BMKG)
rss = """<rss><channel><lastBuildDate>Sun, 08 Nov 2026 03:00:00 +0000</lastBuildDate>
<item><title><![CDATA[Hujan Lebat disertai Petir di Jawa Barat]]></title><link>https://www.bmkg.go.id/alerts/nowcast/id/CJB_alert.xml</link>
<description>Hujan lebat di Kota Bandung, Kabupaten Bandung Barat</description><author>x</author><pubDate>Sun, 08 Nov 2026 09:55:00 +0700</pubDate></item>
<item><title>Hujan Petir di Aceh</title><link>https://www.bmkg.go.id/alerts/nowcast/id/CAC_alert.xml</link><description>Banda Aceh</description></item></channel></rss>"""
items = re.findall(r"<item>(.*?)</item>", rss, re.S)
cek("RSS memuat dua item", len(items) == 2)
def tag(x, n):
    m = re.search(r"<%s(?:\s[^>]*)?>(.*?)</%s>" % (n, n), x, re.S)
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", re.sub(r"^\s*<!\[CDATA\[|\]\]>\s*$", "", m.group(1)))).strip() if m else ""
cek("judul CDATA dibersihkan", tag(items[0], "title") == "Hujan Lebat disertai Petir di Jawa Barat")
def bagian(w):
    umum = {"kota","kabupaten","kab","provinsi","prov","kecamatan","kelurahan","desa","daerah","kec","kel"}
    out = []
    for b in w.lower().split(","):
        b = " ".join(x for x in b.split(" ") if x.strip() and x not in umum).strip()
        if len(b) >= 4 and b not in out: out.append(b)
    return out
def cocok(item, w): 
    t = (tag(item,"title") + " " + tag(item,"description")).lower()
    return any(b in t for b in bagian(w))
cek("lokasi Bandung cocok item Jawa Barat saja", [cocok(i, "Cibeunying, Kota Bandung, Jawa Barat") for i in items] == [True, False])
cek("lokasi Surabaya tidak cocok", not any(cocok(i, "Gubeng, Kota Surabaya, Jawa Timur") for i in items))

# kontrak sumber
cek("data tanpa cache (cache-buster dan no-cache)", "useCaches = false" in src and "no-cache" in src and "System.currentTimeMillis()" in src)
cek("sumber BMKG selalu disebut", src.count("sumber(") >= 6 and "Sumber: BMKG" in src)
cek("tiga endpoint gempa dan nowcast resmi", all(u in src for u in ("data.bmkg.go.id/DataMKG/TEWS/autogempa.json","gempaterkini.json","gempadirasakan.json","www.bmkg.go.id/alerts/nowcast/id")))
cek("tsunami hanya mengutip kolom Potensi BMKG", "BMKG menyatakan potensinya" in src and "ikuti arahan BMKG" in src)
cek("BMKG diperiksa sebelum fitur cuaca", act.index("InfoBmkg.jenisDari(t) != null") < act.index('it in setOf("cuaca", "cuacanya", "weather"'))
cek("dispatch BMKG ada", "Jenis.BMKG -> bacakanBmkg(kandidat)" in act)
if gagal: print("UJI BMKG: GAGAL"); sys.exit(1)
print("UJI BMKG: LULUS (port logika + kontrak sumber)")
