#!/usr/bin/env python3
import sys
B='app/src/main/java/com/novan/bateraibicara/'
r=lambda f:open(B+f,encoding='utf-8').read()
pq,ps=r('PemutarQuranService.kt'),r('PerintahSuaraActivity.kt')
g=[]
def c(n,x):
    if not x: g.append(n)
c("rentang juz di parser","juzAkhir" in pq and "rentangJuzAtauRentang" in pq)
c("rentang juz diputar","p.juzAkhir" in pq)
c("perintah ganda","private fun perintahGanda" in ps and "if (perintahGanda(kandidat)) return" in ps)
c("telegram","SaluranPanggilan.TELEGRAM" in ps and "tg://resolve?phone=" in ps and "com.whatsapp.w4b" in ps)
c("jeda sementara","hentikan sementara" in ps)
if g: print("UJI FIX316: GAGAL"); [print("-",x) for x in g]; sys.exit(1)
print("UJI FIX316: ok")
