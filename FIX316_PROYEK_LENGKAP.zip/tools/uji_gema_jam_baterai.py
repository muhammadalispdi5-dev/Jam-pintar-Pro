b='app/src/main/java/com/novan/bateraibicara/'
g=0
def cek(c,m):
    global g
    if not c: print("GAGAL",m); g+=1
p=open(b+'Pembicara.kt').read(); h=open(b+'Halaman.kt').read(); pr=open(b+'Prefs.kt').read(); ps=open(b+'PerintahSuaraActivity.kt').read()
cek('GemaAudio.daftarKunci.getOrElse(i)' in p,'jam/baterai memakai daftar gema lengkap')
cek('suara.gemaPersen' in p and ', 80)' not in p,'kekuatan gema dari pengaturan')
cek('tambahSenyapWav' in p and 'ekorMs' in p,'ekor gema disisipkan')
cek('gemaPersen' in pr and '+ gemaPersen +' in pr,'pref kekuatan')
cek('pakaiGemaLengkap' in h and 'Kekuatan gema' in h and 'gemaDraf' in h and 'ui(tr("Simpan"' in h and 'Putar contoh gema' in h,'dialog gema: draf, simpan, contoh terpisah')
for k in ['PEMANGGIL_IZIN','PEMANGGIL_JENIS','PEMANGGIL_PESAN','PEMANGGIL_MELODI','PEMANGGIL_VOLUME','PEMANGGIL_SUARA']:
    cek(ps.count(k)>=4,'asisten '+k)
cek('kendaliSakelarPemanggil' in ps and 'BACA_NOTIF_SEMUA' in ps and 'NAMA_PEMANGGIL' in ps,'sakelar asisten')
print("selesai",g)
k=open(b+'KhatamActivity.kt').read()
cek('modeDraf' in k and 'kuatDraf' in k and 'CHOICE_MODE_SINGLE' in k and 'tr("Simpan"' in k,'gema khatam: draf + simpan')
print("selesai khatam",g)
d=open(b+'GemaDsp.kt').read(); c=open(b+'ContohGema.kt').read()
cek('object GemaDsp' in d and 'fun proses(' in d and 'class Pemroses' in d,'DSP gema')
cek('GemaDsp.proses' in p and 'idDsp' in p,'Pembicara memakai DSP')
cek('suara.profil == "jam"' not in p.split('private fun gemaAktif')[1].split('\n')[0],'gema untuk semua profil')
cek('synthesizeToFile' in c and 'catch (_: Throwable)' in c and 'MediaPlayer' in c,'contoh gema TTS aman')
for f_ in ['Halaman.kt','PrayerSettingsActivity.kt','KhatamActivity.kt']:
    cek('ContohGema.putar' in open(b+f_).read(),'contoh gema di '+f_)
print("selesai dsp",g)

pa=open(b+'PemutarAudio.kt').read(); sv=open(b+'PrayerAlarmService.kt').read(); ps2=open(b+'PrayerSettingsActivity.kt').read()
cek('gemaKunci' in pa and 'GemaDsp.Pemroses' in pa and 'ekorFrame' in pa,'pemutar mono: DSP + ekor')
cek(sv.count('mulaiGema(')>=4 and 'pemutarGema' in sv,'azan/pengingat memakai gema nyata')
cek('Ini adalah contoh suara gema yang Anda pilih' in c,'kalimat contoh')
cek('simpanDraf' in ps2 and 'Simpan lalu tes suara lengkap' in ps2,'jadwal salat: simpan terpisah dari contoh')
print("selesai pemutar",g)
