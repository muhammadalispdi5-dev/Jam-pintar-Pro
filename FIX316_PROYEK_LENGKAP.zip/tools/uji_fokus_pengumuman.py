#!/usr/bin/env python3
"""Uji FIX154: pengumuman otomatis (jam, baterai, pemberitahuan) hanya menurunkan volume audio aplikasi lain (ducking),
bukan menjedanya. Kontrak sumber; bukan hasil kompilasi dan bukan uji perangkat."""
import sys
from pathlib import Path
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
gagal = []
def cek(nama, ok):
    if not ok: gagal.append(nama)
pem = (R / "Pembicara.kt").read_text(encoding="utf-8")
bat = (R / "BatteryTalkService.kt").read_text(encoding="utf-8")
cal = (R / "CallerListener.kt").read_text(encoding="utf-8")
cek("Pembicara punya sakelar hanyaKecilkanAudioLain bawaan false", "var hanyaKecilkanAudioLain = false" in pem)
cek("fokus MAY_DUCK dipilih bila sakelar aktif",
    "if (hanyaKecilkanAudioLain) AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT" in pem)
cek("ucapan asisten tetap fokus sementara penuh (bawaan)", "else AudioManager.AUDIOFOCUS_GAIN_TRANSIENT\n" in pem)
cek("pemutar lain tidak dijeda saat diturunkan", ".setWillPauseWhenDucked(false)" in pem)
cek("jalur Android lama memakai jenis fokus yang sama", "am.requestAudioFocus(pendengarFokus, suara.streamType(), jenisFokus)" in pem)
cek("fokus tetap dilepas setelah bicara", "lepasFokus()" in pem and "private fun lepasFokus()" in pem)
cek("jam bicara dan baterai memakai ducking", "baru.hanyaKecilkanAudioLain = true" in bat)
cek("pembacaan pemberitahuan masuk memakai ducking", "baru.hanyaKecilkanAudioLain = true" in cal)
if gagal:
    print("UJI FOKUS PENGUMUMAN: GAGAL"); [print("-", g) for g in gagal]; sys.exit(1)
print("UJI FOKUS PENGUMUMAN: LULUS (kontrak sumber)")
