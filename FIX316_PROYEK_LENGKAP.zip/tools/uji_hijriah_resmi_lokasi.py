#!/usr/bin/env python3
"""FIX293: penetapan Hijriah resmi didahulukan; lokasi jadwal salat mengikuti perpindahan pengguna."""
import sys
D='app/src/main/java/com/novan/bateraibicara/'
r=open(D+'HijriahResmi.kt').read(); h=open(D+'HijriahDaring.kt').read(); k=open(D+'KalenderTanggal.kt').read()
l=open(D+'LokasiOtomatis.kt').read(); m=open(D+'MainActivity.kt').read(); b=open(D+'BatteryTalkService.kt').read()
pa=open(D+'PrayerActivity.kt').read(); ps=open(D+'PrayerSettingsActivity.kt').read(); pp=open(D+'PrayerPrefs.kt').read()
man=open('app/src/main/AndroidManifest.xml').read()
a=open('app/src/main/res/values/strings.xml').read(); e=open('app/src/main/res/values-en/strings.xml').read()
g=0
def cek(n,ok):
    global g
    print(("LULUS " if ok else "GAGAL ")+n); g+=(not ok)
cek("sumber resmi diambil dari repositori","updates/hijriah_resmi.json" in r and "raw.githubusercontent.com" in r)
cek("resmi didahulukan di tabel daring","HijriahResmi.cari(context, date)?.let { return it }" in h)
cek("resmi didahulukan di penyusun tanggal","if (resmi != null)" in k and "resmi == null && koreksiHari == 0" in k)
cek("resmi disegarkan bersama data daring","HijriahResmi.segarkan(app, paksa)" in h)
cek("pergantian hari pukul 18.00 tetap","c.get(Calendar.HOUR_OF_DAY) >= 18" in k)
cek("lokasi otomatis: ambang jarak dan izin","JARAK_MIN_M" in l and "adaIzin" in l and "isProviderEnabled" in l)
cek("lokasi otomatis memperbarui alarm dan jadwal","PrayerAlarm.scheduleAll(app)" in l and "PrayerOnlineTimes.sync(app)" in l)
cek("pemicu: layar utama, jadwal, layanan, zona waktu","LokasiOtomatis.periksa(this)" in m and "LokasiOtomatis.periksa(this)" in pa and "LokasiOtomatis.periksa(this@BatteryTalkService)" in b and "paksa = true" in b)
cek("layanan memakai this@BatteryTalkService di dalam Runnable (galat kompilasi FIX294)","LokasiOtomatis.periksa(this) }" not in b)
cek("saklar ikuti lokasi","ikutiLokasi" in pp and "ikutiLokasi" in ps)
cek("lokasi manual mematikan pengikut","pp.ikutiLokasi = false" in pa)
cek("izin lokasi latar belakang","ACCESS_BACKGROUND_LOCATION" in man)
cek("petunjuk ID 63 / EN 60"," 63. Kalender Hijriah resmi" in a and " 60. Official Hijri calendar" in e)
sys.exit(0)
