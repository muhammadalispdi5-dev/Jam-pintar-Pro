#!/usr/bin/env python3
"""Uji statis FIX164: efek gema Khatam terhubung ke UI, pemutar latar belakang, reset, dan dua bahasa."""
from pathlib import Path
import re, sys
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/novan/bateraibicara"
g = (R / "GemaAudio.kt").read_text(encoding="utf-8")
k = (R / "KhatamActivity.kt").read_text(encoding="utf-8")
e = (R / "EfekAudioLatar.kt").read_text(encoding="utf-8")
gagal = []
kunci = re.search(r"daftarKunci = listOf\((.*?)\)", g, re.S).group(1)
kunci = re.findall(r'"(\w+)"', kunci)
for x in kunci:
    if f'"{x}" ->' not in g and x != "normal" and f'"{x}"' not in g: gagal.append("kunci tanpa data " + x)
    if x != "normal" and not re.search(r'"%s"[^\n]*->\s*tr\(' % x, g): gagal.append("label belum dua bahasa: " + x)
for nama in ("echo", "karaoke", "studio", "panggung", "aula"):
    if nama not in kunci: gagal.append("mode hilang: " + nama)
if "pm.gemaKunci" not in k or "buatPemutar(this, keluaranMono, gemaAudio.mode" not in k: gagal.append("Khatam tidak menerapkan gema")
if "dialogGema()" not in k: gagal.append("dialog gema tidak terhubung")
if "gema.lepas" not in e: gagal.append("pemutar latar tanpa gema")
if "efek_gema_mode" not in k: gagal.append("reset pengaturan tidak memuat gema")
print("UJI FIX164 EFEK GEMA:", "GAGAL" if gagal else "LULUS", *gagal, sep="\n- " if gagal else " ")
sys.exit(1 if gagal else 0)
