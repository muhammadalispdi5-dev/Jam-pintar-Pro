import sys
m=open('app/src/main/java/com/novan/bateraibicara/MainActivity.kt').read()
ok=True
def cek(n,c):
    global ok
    print(("LULUS " if c else "GAGAL ")+n); ok&=c
cek("cek pertama tiap proses tanpa jeda 12 jam",'!cekPembaruanAwalSelesai || UpdateManager.sudahWaktunyaCek(this)' in m and 'private var cekPembaruanAwalSelesai' in m)
cek("izin pasang diminta sebelum unduh",'canRequestPackageInstalls()) mintaIzinPasangLaluUnduh(info) else mulaiUnduh(info)' in m)
cek("unduh dimulai setelah kembali dari izin",'infoMenungguIzinPasang?.let' in m and 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' in m)
cek("manifest izin pasang",'REQUEST_INSTALL_PACKAGES' in open('app/src/main/AndroidManifest.xml').read())
sys.exit(0 if ok else 1)
