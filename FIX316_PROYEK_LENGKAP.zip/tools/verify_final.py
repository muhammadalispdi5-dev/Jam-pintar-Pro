#!/usr/bin/env python3
"""Audit akhir statis Jam Pintar Pro untuk tahap 30; bukan pengganti build/perangkat."""
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(condition, message):
    if not condition:
        errors.append(message)

# Jalankan pemeriksaan struktur/version/manifest yang sudah ada.
result = subprocess.run([sys.executable, str(ROOT / "tools/verify_project.py")],
                        cwd=ROOT, capture_output=True, text=True)
print(result.stdout, end="")
if result.returncode != 0:
    print(result.stderr, end="")
    errors.append("Pemeriksaan proyek dasar gagal")

_wf = ROOT / ".github/workflows"
if not (_wf / "build.yml").is_file() or not (_wf / "rilis.yml").is_file():
    print("CATATAN: folder workflow GitHub tidak ada di salinan proyek ini; pemeriksaan workflow dilewati")
else:
    build = (ROOT / ".github/workflows/build.yml").read_text(encoding="utf-8")
    release = (ROOT / ".github/workflows/rilis.yml").read_text(encoding="utf-8")
    require("secrets.KEYSTORE_BASE64" in build and "KEYSTORE_PATH=$KS" in build,
            "Workflow build tidak mengonfigurasi keystore dari secret dengan benar")
    require("kunci debug sementara" in build,
            "Workflow build harus memberi peringatan bila hanya menghasilkan APK uji")
    require("secrets.KEYSTORE_BASE64" in release and "exit 1" in release and "Rilis publik dibatalkan" in release,
            "Workflow rilis harus berhenti jika keystore tetap belum dikonfigurasi")
    require("bateraibicara\"" not in build and "bateraibicara\"" not in release,
            "Ditemukan kredensial keystore tetap yang tertanam dalam workflow")
    require("KEYSTORE_BASE64" in release and "KEYSTORE_PASSWORD" in release and "KEY_ALIAS" in release,
            "Workflow rilis tidak memeriksa secret tanda tangan wajib")

# Audit dasar fitur Khatam Al-Qur'an; pemeriksaan ini tidak menggantikan build/perangkat nyata.
khatam = (ROOT / "app/src/main/java/com/novan/bateraibicara/KhatamActivity.kt").read_text(encoding="utf-8")
receiver = (ROOT / "app/src/main/java/com/novan/bateraibicara/KhatamReminderReceiver.kt").read_text(encoding="utf-8")
manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
require("quran-uthmani" in khatam and "id.indonesian" in khatam and "en.sahih" in khatam,
        "Pembaca Khatam tidak menyediakan sumber teks Arab dan terjemahan dua bahasa")
require("6236" in khatam and "114" in khatam and "quran_ar.json" in khatam,
        "Validasi jumlah ayat/surah atau cache offline teks tidak ditemukan")
require("ayat_selesai" in khatam and "target_hari" in khatam and "pengingat_aktif" in khatam,
        "Penyimpanan kemajuan, target, atau pengingat Khatam tidak ditemukan")
require("audio-surah/128/" in khatam and "ar.alafasy" in khatam and "jedaUntukMikrofon" in khatam and "lanjutSetelahMikrofon" in khatam,
        "Kontrol streaming murattal dan jeda/lanjutkan tidak ditemukan")
require(".KhatamActivity" in manifest and ".KhatamReminderReceiver" in manifest and "class KhatamReminderReceiver" in receiver,
        "Aktivitas atau penerima pengingat Khatam belum didaftarkan")
require("CATATAN_FITUR_KHATAM_ALQURAN_1.0.69_FIX24.md" in str(ROOT / "CATATAN_FITUR_KHATAM_ALQURAN_1.0.69_FIX24.md"),
        "Catatan fitur Khatam tidak ditemukan")

if errors:
    print("AUDIT AKHIR TAHAP 30: GAGAL")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("AUDIT AKHIR TAHAP 30 + KHATAM: LULUS")
print("- APK uji dapat dibangun tanpa menganggap kunci sementara sebagai kunci rilis")
print("- Workflow rilis menolak penerbitan tanpa keystore tetap dari GitHub Secrets")
print("- Tidak ditemukan kata sandi keystore tetap yang tertanam di workflow")
print("- Struktur fitur Khatam, cache teks offline, target, statistik, pengingat, dan streaming audio ditemukan")
print("- Pemeriksaan ini bersifat statis; kompilasi Android dan uji perangkat tetap diperlukan")
