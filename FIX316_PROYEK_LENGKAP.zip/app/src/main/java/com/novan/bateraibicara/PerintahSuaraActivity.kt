package com.novan.bateraibicara

import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.content.IntentFilter
import android.os.Build
import com.novan.bateraibicara.PerintahSuara.TopikPerangkat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Calendar
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/**
 * FIX84: perintah suara Beritahu Saya.
 * Dibuka dengan ketuk tahan pada ikon Beritahu Saya (pintasan aplikasi) atau ketuk tahan pada saklar
 * pemicu Beritahu Saya di layar utama aplikasi. Layar pengenalan suara sistem dibuka (tanpa izin
 * mikrofon aplikasi), lalu perintah dijalankan: waktu, tanggal, atau memutar Al-Qur'an.
 * Bahasa pengenalan, teks, dan pesan mengikuti bahasa tampilan utama yang aktif.
 */
class PerintahSuaraActivity : Activity() {
    private var pembicara: Pembicara? = null
    private var pembicaraTanggal: Pembicara? = null
    private val handler = Handler(Looper.getMainLooper())
    private var selesai = false
    private val batasWaktu = Runnable { tutupDanLanjutAudio() }
    private var permintaanFokusMik: AudioFocusRequest? = null
    private var fokusMikDiminta = false
    // FIX121: status menunggu pengenalan, supaya pemicu baru dapat memulai ulang pengenalan yang macet.
    private var menungguPengenalan = false
    private var waktuMulai = 0L
    private var waktuBukaSistem = 0L
    private var percobaanUlangMic = 0
    private var generasiPengenalan = 0
    // FIX122: tombol volume dan telungkup menghentikan jawaban suara; layar ditutup bila itu terjadi.
    private var volumeDikonsumsi = false
    private var generasiBungkamAwal = 0
    private val pantauBungkam = object : Runnable {
        override fun run() {
            if (selesai || isFinishing) return
            if (PembungkamTelungkup.generasi != generasiBungkamAwal) { tutupDanLanjutAudio(); return }
            handler.postDelayed(this, 400L)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) volumeDikonsumsi = false
                if (volumeDikonsumsi) return true
                if (PembungkamTelungkup.bungkamDariTombolVolume(this)) {
                    volumeDikonsumsi = true
                    tutupDanLanjutAudio()
                    return true
                }
            } else if (event.action == KeyEvent.ACTION_UP && volumeDikonsumsi) {
                volumeDikonsumsi = false
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }
    private var pengenal: SpeechRecognizer? = null
    private var sudahFallback = false
    private var pakaiPengenalUmum = false
    private var pengenalanSistemDaring = false
    private var percobaanSibuk = 0
    private var dipicuGoncanganSaatIni = false
    // Mode dua tahap: "telepon" diikuti nama kontak atau nomor.
    private var menungguNamaKontak = false
    private var ucapanKontakTertunda = ""
    // Saluran panggilan dipilih dari ucapan eksplisit pengguna.
    private enum class SaluranPanggilan { SELULER, WHATSAPP, WHATSAPP_BUSINESS, TELEGRAM }
    /** FIX316: perintah ganda "buka WhatsApp dan kirim pesan ke ...": hanya membuka obrolan, tanpa memulai panggilan. */
    private var aksiObrolanGanda = false
    private var saluranPanggilan = SaluranPanggilan.SELULER
    private var nomorPanggilanTertunda = ""
    private var jenisPanggilanWhatsApp: String? = null
    private var menungguJenisPanggilanWhatsApp = false

    private fun tr(id: String, en: String): String = if (BahasaAplikasi.tampilan(this) == 1) en else id

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FIX182: halaman perintah suara juga mengikuti mode hemat daya global.
        PenghematDaya.terapkan(this)
        val prefs = Prefs(applicationContext)
        val dipicuGoncangan = intent.getBooleanExtra(EXTRA_PEMICU_GONCANGAN, false)
        val ujiPaketOffline = intent.getBooleanExtra(EXTRA_UJI_PAKET_OFFLINE, false)
        dipicuGoncanganSaatIni = dipicuGoncangan
        if (dipicuGoncangan) {
            // FIX95: notifikasi "Perintah suara siap" sudah tidak diperlukan setelah layar ini terbuka.
            try { getSystemService(NotificationManager::class.java).cancel(GoncanganSuaraService.NOTIFIKASI_SIAP_ID) } catch (_: Exception) { }
            try { getSystemService(NotificationManager::class.java).cancel(PemicuSuara.NOTIFIKASI_ID) } catch (_: Exception) { }
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
            }
        }
        if (!dipicuGoncangan && !ujiPaketOffline && !prefs.beritahuSayaOn) {
            Toast.makeText(this, getString(R.string.beritahu_saya_nonaktif_petunjuk), Toast.LENGTH_LONG).show()
            selesai = true
            finish()
            return
        }
        // FIX123: serialkan kepemilikan mikrofon. Instance lama ditutup dan diberi waktu melepas
        // SpeechRecognizer/audio focus sebelum sesi baru dimulai; jangan mulai dua sesi bersamaan.
        val lama = aktif
        aktif = this
        if (lama != null && lama !== this) {
            lama.tutupPaksa()
            if (savedInstanceState == null) {
                handler.postDelayed({ if (!isFinishing && aktif === this) mulai() }, 650L)
            }
        } else if (savedInstanceState == null) {
            mulai()
        }
    }

    private fun terkunci(): Boolean =
        try { (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked } catch (_: Exception) { false }

    /** Pengenal langsung untuk layar terkunci/goncangan; dukung layanan standar pada HP lama juga. */
    private fun bisaPengenalanDalam(): Boolean {
        if (!(dipicuGoncanganSaatIni || terkunci())) return false
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
    }

    /** Bila "Suara TalkBack saat mikrofon dipakai" dimatikan (Khatam), senyapkan TalkBack, beri getar, lalu buka mikrofon. */
    private fun mulai() {
        // FIX120: audio Khatam tidak menangani fokus audio sendiri, jadi dijeda secara eksplisit selama mikrofon dibuka
        // (dilanjutkan setelah jawaban selesai bila perintahnya tidak mengatur audio). Fokus sementara membuat pemutar latar
        // belakang ikut berhenti sebentar. Batas waktu mencegah layar ini tertahan selamanya bila pengenal tidak menjawab.
        KhatamActivity.jedakanUntukMikrofon()
        menungguPengenalan = true
        waktuMulai = SystemClock.elapsedRealtime()
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 45_000L)
        val senyap = getSharedPreferences("khatam_quran", MODE_PRIVATE).getBoolean("senyap_talkback_pergantian_audio", false)
        pakaiPengenalUmum = false
        pengenalanSistemDaring = false
        val dalam = bisaPengenalanDalam()
        if (senyap || dalam) {
            // Potong ucapan aksesibilitas sebelum mikrofon on-device dibuka.
            hentikanUjaranTalkBack()
            getar(150L)
            handler.postDelayed({
                if (isFinishing) return@postDelayed
                if (senyap || dalam) hentikanUjaranTalkBack()
                if (dalam && bukaPengenalanDalam()) return@postDelayed
                // Lepaskan fokus jika recognizer on-device tidak tersedia.
                lepasFokusMikrofon()
                bukaPengenalan(false)
            }, if (dalam) 700L else 800L)
        } else {
            bukaPengenalan(true)
        }
    }

    private fun tagBahasaPengenalan(): String = when (BahasaAplikasi.tampilan(this)) {
        1 -> "en-US"
        2 -> "ar-SA"
        3 -> "jv-ID"
        4 -> "su-ID"
        else -> "id-ID"
    }

    private fun nadaSiap() {
        getar(90L)
        try {
            val nada = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            nada.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
            handler.postDelayed({ try { nada.release() } catch (_: Exception) { } }, 400L)
        } catch (_: Exception) { }
    }

    private fun lepasPengenal() {
        try { pengenal?.cancel() } catch (_: Exception) { }
        try { pengenal?.destroy() } catch (_: Exception) { }
        pengenal = null
    }

    private fun keCadangan() {
        // Dipakai hanya jika pengenal internal dan jalur sistem tidak dapat dijalankan.
        lepasPengenal()
        lepasFokusMikrofon()
        if (isFinishing || selesai) return
        Toast.makeText(this, pesanPengenalOfflineTidakTersedia(), Toast.LENGTH_LONG).show()
        tutupDanLanjutAudio()
    }

    private fun pesanPengenalOfflineTidakTersedia(): String = tr(
        "Layanan pengenalan suara tidak tersedia. Pastikan layanan Google atau layanan pengenalan suara bawaan HP aktif, lalu periksa koneksi internet atau unduh paket bahasa untuk penggunaan offline.",
        "Speech recognition is unavailable. Make sure Google or the phone's speech recognition service is enabled, then check the internet connection or download a language pack for offline use."
    )

    /** Gunakan pengenal on-device bila ada; jika tidak, coba layanan pengenal standar perangkat. */
    private fun bukaPengenalanDalam(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return false
            // Jika pengguna memilih mesin terpasang melalui Pengelola Paket Bahasa,
            // gunakan komponen layanan itu secara eksplisit. Jika tidak, prioritaskan
            // pengenal on-device Android lalu jatuh kembali ke mesin standar sistem.
            val mesinPilihan = PengenalSuaraTerpasang.dipilih(this)
            if (mesinPilihan != null && !PengenalSuaraTerpasang.pilihanMasihTersedia(this)) {
                Toast.makeText(this, tr(
                    "Mesin pengenal suara pilihan sudah tidak terpasang atau dinonaktifkan. Buka Paket Bahasa Pengenal Suara Offline untuk memilih mesin lain.",
                    "The selected speech recognition engine is no longer installed or is disabled. Open Offline Speech Language Packs to choose another engine."
                ), Toast.LENGTH_LONG).show()
                return false
            }
            val onDevice = mesinPilihan == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !pakaiPengenalUmum &&
                try { SpeechRecognizer.isOnDeviceRecognitionAvailable(this) } catch (_: Exception) { false }
            if (!onDevice) pakaiPengenalUmum = true
            val sr = when {
                mesinPilihan != null -> SpeechRecognizer.createSpeechRecognizer(this, mesinPilihan)
                onDevice -> SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                else -> SpeechRecognizer.createSpeechRecognizer(this)
            }
            pengenal = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { nadaSiap() }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
                override fun onResults(results: Bundle?) {
                    val kandidat = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    lepasPengenal()
                    if (kandidat.isEmpty()) { tutupDanLanjutAudio(); return }
                    terimaHasilSuara(kandidat)
                }
                override fun onError(error: Int) {
                    val perluDaring = error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ||
                        error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT || error == SpeechRecognizer.ERROR_SERVER
                    if (!pakaiPengenalUmum && perluDaring) {
                        lepasPengenal(); pakaiPengenalUmum = true
                        handler.postDelayed({ if (!isFinishing && !selesai && !bukaPengenalanDalam()) bukaPengenalanSistem(false) }, 450L)
                        return
                    }
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                            lepasPengenal(); getar(300L)
                            Toast.makeText(this@PerintahSuaraActivity, getString(R.string.perintah_suara_tidak_terdengar), Toast.LENGTH_LONG).show()
                            tutupDanLanjutAudio()
                        }
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                            if (percobaanSibuk++ < 1) {
                                lepasPengenal()
                                handler.postDelayed({ if (!isFinishing && !bukaPengenalanDalam()) bukaPengenalanSistem(false) }, 600L)
                            } else keCadangan()
                        }
                        else -> {
                            lepasPengenal()
                            if (!pakaiPengenalUmum) {
                                pakaiPengenalUmum = true
                                handler.postDelayed({ if (!isFinishing && !bukaPengenalanDalam()) bukaPengenalanSistem(false) }, 450L)
                            } else if (!terkunci() && !dipicuGoncanganSaatIni) {
                                bukaPengenalanSistem(false)
                            } else keCadangan()
                        }
                    }
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !pakaiPengenalUmum)
            }
            ambilFokusMikrofon(); sr.startListening(i); true
        } catch (_: Exception) { lepasPengenal(); false }
    }

    /** Jalur sistem untuk HP yang belum memberikan izin mikrofon langsung kepada aplikasi. */
    private fun bukaPengenalanSistem(denganPetunjuk: Boolean, petunjukKhusus: String? = null) {
        if (isFinishing || selesai) return
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tagBahasaPengenalan())
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !pengenalanSistemDaring)
                if (denganPetunjuk && !petunjukKhusus.isNullOrBlank()) putExtra(RecognizerIntent.EXTRA_PROMPT, petunjukKhusus)
            }
            waktuBukaSistem = SystemClock.elapsedRealtime()
            startActivityForResult(i, kodePengenalan())
        } catch (_: Exception) {
            Toast.makeText(this, pesanPengenalOfflineTidakTersedia(), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
        }
    }

    /** FIX95: perintah yang membuka aplikasi lain, memanggil, atau membacakan pesan pribadi meminta pengguna membuka kunci layar lebih dulu. */
    private fun denganBukaKunci(aksi: () -> Unit) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (km == null || !km.isKeyguardLocked || Build.VERSION.SDK_INT < 26) { aksi(); return }
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { handler.removeCallbacks(batasWaktu); aksi() }
            override fun onDismissCancelled() { tutup() }
            override fun onDismissError() { tutup() }
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // FIX123: ketukan widget adalah permintaan pengguna baru dan selalu memulai sesi baru.
        // Pemicu ganda dari layanan goncangan/notifikasi dalam rentang pendek tetap diabaikan.
        val manual = intent.getBooleanExtra(EXTRA_PEMICU_MANUAL, false)
        if (!selesai && manual) {
            // Ketukan widget yang disengaja selalu dapat meminta sesi mikrofon baru,
            // termasuk saat sesi sebelumnya sedang membacakan jawaban.
            hentikanSuara()
            mulaiUlangPengenalan()
        } else if (!selesai && menungguPengenalan &&
            SystemClock.elapsedRealtime() - waktuMulai > 6_000L
        ) {
            mulaiUlangPengenalan()
        }
    }

    private fun mulaiUlangPengenalan() {
        // Hentikan layar pengenal sistem lama sebelum mengubah kode hasilnya, agar sesi lama
        // tidak terus memegang mikrofon dan hasil terlambatnya tidak masuk ke sesi yang baru.
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        generasiPengenalan++
        lepasPengenal()
        lepasFokusMikrofon()
        handler.removeCallbacksAndMessages(null)
        menungguPengenalan = false
        sudahFallback = false
        pakaiPengenalUmum = false
        pengenalanSistemDaring = false
        percobaanSibuk = 0
        percobaanUlangMic = 0
        handler.postDelayed({ if (!isFinishing && !selesai && aktif === this) mulai() }, 350L)
    }

    private fun kodePengenalan(): Int = KODE_PENGENALAN + generasiPengenalan

    private fun pengenalDalamTersedia(): Boolean {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try { SpeechRecognizer.isRecognitionAvailable(this) } catch (_: Exception) { false }
    }

    /** Percobaan ulang menggunakan mode pengenal yang saat ini tersedia pada perangkat. */
    private fun ulangiPengenalanMikrofon() {
        if (isFinishing || selesai) return
        if (percobaanUlangMic++ < 1) {
            getar(120L)
            handler.postDelayed({
                if (isFinishing || selesai) return@postDelayed
                if (pengenalDalamTersedia() && bukaPengenalanDalam()) return@postDelayed
                keCadangan()
            }, 900L)
        } else {
            getar(300L)
            Toast.makeText(this, getString(R.string.perintah_suara_mikrofon_gagal), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
        }
    }

    private fun bukaPengenalan(denganPetunjuk: Boolean, petunjukKhusus: String? = null) {
        lepasFokusMikrofon()
        if (pengenalDalamTersedia() && bukaPengenalanDalam()) return
        if (terkunci() || dipicuGoncanganSaatIni) { keCadangan(); return }
        bukaPengenalanSistem(denganPetunjuk, petunjukKhusus)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != kodePengenalan()) return
        val kandidat = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty() else emptyList<String>()
        if (kandidat.isEmpty()) {
            val galatMikrofon = resultCode == RecognizerIntent.RESULT_AUDIO_ERROR || resultCode == RecognizerIntent.RESULT_CLIENT_ERROR ||
                resultCode == RecognizerIntent.RESULT_SERVER_ERROR || resultCode == RecognizerIntent.RESULT_NETWORK_ERROR ||
                (resultCode == RESULT_CANCELED && SystemClock.elapsedRealtime() - waktuBukaSistem < 1_500L)
            if (galatMikrofon && !pengenalanSistemDaring) {
                pengenalanSistemDaring = true
                handler.postDelayed({ if (!isFinishing && !selesai) bukaPengenalanSistem(false) }, 350L)
                return
            }
            if (galatMikrofon) { ulangiPengenalanMikrofon(); return }
            tutupDanLanjutAudio(); return
        }
        terimaHasilSuara(kandidat)
    }

    /** Hasil pengenalan pertama bisa berisi "telepon" saja; hasil berikutnya menjadi nama/nomor tujuan. */
    private fun terimaHasilSuara(kandidat: List<String>) {
        if (menungguJenisPanggilanWhatsApp) {
            menungguJenisPanggilanWhatsApp = false
            val ucapanJenis = kandidat.maxByOrNull { it.length }.orEmpty().lowercase()
            jenisPanggilanWhatsApp = when {
                listOf("video", "vidio", "visual").any { ucapanJenis.contains(it) } -> "video"
                listOf("suara", "voice", "audio").any { ucapanJenis.contains(it) } -> "voice"
                else -> null
            }
            if (jenisPanggilanWhatsApp == null) {
                menungguJenisPanggilanWhatsApp = true
                Toast.makeText(this, petunjukJenisPanggilanWhatsApp(), Toast.LENGTH_LONG).show()
                bukaPengenalan(false, petunjukJenisPanggilanWhatsApp())
            } else {
                lepasFokusMikrofon()
                jalankanSaluranPanggilan(nomorPanggilanTertunda)
            }
            return
        }
        if (menungguNamaKontak) {
            menungguNamaKontak = false
            lepasFokusMikrofon()
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, 90_000L)
            prosesTujuanPanggilan(kandidat)
        } else {
            jalankan(kandidat)
        }
    }

    private fun jalankan(kandidat: List<String>) {
        // FIX120: pengenalan selesai; lepas fokus mikrofon agar pemutar latar belakang lanjut sebelum perintah diproses,
        // dan beri batas waktu longgar untuk perintah apa pun.
        menungguPengenalan = false
        lepasFokusMikrofon()
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 120_000L)
        generasiBungkamAwal = PembungkamTelungkup.generasi
        handler.removeCallbacks(pantauBungkam)
        handler.postDelayed(pantauBungkam, 400L)
        // Sapaan dan ungkapan sosial diproses lebih dahulu agar tidak dianggap sebagai
        // perintah yang tidak dikenal. Respons memakai profil suara jam (mesin suara pilihan
        // pengguna), tetapi bahasa pengucapannya dipaksa mengikuti bahasa tampilan aplikasi.
        if (tanganiUcapanSosial(kandidat)) return

        if (perintahGanda(kandidat)) return
        when (PerintahSuara.tafsir(kandidat)) {
            PerintahSuara.Jenis.KONTROL_PERANGKAT -> bukaPengaturanPerangkat(PerintahSuara.kontrolPerangkat(kandidat))
            PerintahSuara.Jenis.BUKA_PENGATURAN_PERANGKAT -> bukaHalamanPengaturan(PerintahSuara.pengaturanPerangkat(kandidat))
            PerintahSuara.Jenis.MESIN_SUARA_TALKBACK -> gantiMesinSuaraTalkBack(kandidat)
            PerintahSuara.Jenis.BMKG -> bacakanBmkg(kandidat)
            PerintahSuara.Jenis.TIMER -> kendaliTimer(kandidat)
            PerintahSuara.Jenis.BATERAI_INFO -> bacakanBaterai()
            PerintahSuara.Jenis.WAKTU -> bacakan(waktu = true, tanggal = false)
            PerintahSuara.Jenis.TANGGAL -> bacakan(waktu = false, tanggal = true)
            PerintahSuara.Jenis.WAKTU_TANGGAL -> bacakan(waktu = true, tanggal = true)
            PerintahSuara.Jenis.SEMUA -> bacakan(waktu = true, tanggal = true, lengkap = true)
            PerintahSuara.Jenis.PASARAN -> bacakanKhusus { p, c -> KalenderTanggal.pasaran(c, p.kalenderPasaranKoreksi, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_MASEHI -> bacakanKhusus(PerintahSuara.geserHari(kandidat)) { p, c -> KalenderTanggal.masehi(c, p.bahasaAktif) }
            PerintahSuara.Jenis.TANGGAL_HIJRIAH -> bacakanKhusus(PerintahSuara.geserHari(kandidat)) { p, c ->
                KalenderTanggal.hijriah(c,
                    if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                    if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null,
                    p.bahasaAktif,
                    if (p.kalenderHijriAuto) p.appContext else null)
            }
            PerintahSuara.Jenis.LIBUR -> bacakanKhusus { p, _ ->
                val nasional = HariLibur.ringkasan(applicationContext, p, "national").drop(1)
                val cuti = HariLibur.ringkasan(applicationContext, p, "joint").drop(1)
                (nasional + cuti).joinToString(" ").ifBlank { pesanKosong(p, "holiday") }
            }
            PerintahSuara.Jenis.SHOLAT_BERIKUTNYA -> {
                val diminta = PerintahSuara.sholatDiminta(kandidat)
                bacakanKhusus { p, c ->
                    if (diminta != null) InfoSholat.waktuSpesifik(p, c, diminta.first, diminta.second) ?: pesanKosong(p, "prayer")
                    else InfoSholat.segmen(p, c, abaikanSakelar = true).firstOrNull() ?: pesanKosong(p, "prayer")
                }
            }
            PerintahSuara.Jenis.CUACA -> bacakanCuaca(kandidat)
            PerintahSuara.Jenis.MODE_ACARA_KONTROL -> kendaliModeAcara(kandidat)
            PerintahSuara.Jenis.LOKASI_SEBUT -> sebutLokasiTerkini()
            PerintahSuara.Jenis.LOKASI_PERBARUI -> perbaruiLokasiSholat()
            PerintahSuara.Jenis.SAKELAR_FITUR -> kendaliSakelarFitur(kandidat)
            PerintahSuara.Jenis.INFO_PERANGKAT -> bacakanInfoPerangkat(kandidat)
            PerintahSuara.Jenis.QURAN -> {
                // FIX142: semua perintah putar Quran (termasuk memilih qari) dijalankan layanan latar belakang.
                // Tidak ada layar aplikasi yang dibuka, baik saat terkunci maupun tidak, sehingga TalkBack tidak pernah terganggu.
                putarQuranLatarBelakang(kandidat)
            }
            PerintahSuara.Jenis.BERHENTI_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_BERHENTI)
            PerintahSuara.Jenis.JEDA_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_JEDA)
            PerintahSuara.Jenis.LANJUT_AUDIO -> kendaliQuran(PemutarQuranService.ACTION_LANJUT)
            PerintahSuara.Jenis.BUKA_FITUR -> denganBukaKunci { bukaFitur(PerintahSuara.fitur(kandidat), kandidat) }
            PerintahSuara.Jenis.PANGGIL -> denganBukaKunci { panggilKontak(kandidat) }
            PerintahSuara.Jenis.PESAN -> denganBukaKunci { bukaPesan(kandidat, baca = false) }
            PerintahSuara.Jenis.BACA_PESAN -> denganBukaKunci { bacaPesanTersimpan(kandidat) }
            PerintahSuara.Jenis.CARI_PESAN -> denganBukaKunci { cariPesanKontak(kandidat) }
            PerintahSuara.Jenis.BUKA_APLIKASI -> denganBukaKunci { bukaAplikasiDisebut(kandidat) }
            PerintahSuara.Jenis.LIBUR_SPESIFIK -> bacakanKhusus { p, c -> HariLibur.jawabanKhusus(applicationContext, p, PerintahSuara.kategoriLibur(kandidat), PerintahSuara.periodeLibur(kandidat), c) }
            PerintahSuara.Jenis.TIDAK_DIKENAL -> {
                val didengar = kandidat.firstOrNull().orEmpty()
                getar(300L)
                Toast.makeText(
                    this,
                    getString(R.string.perintah_suara_tidak_dikenal) + (if (didengar.isNotBlank()) " (\"" + didengar + "\")" else ""),
                    Toast.LENGTH_LONG
                ).show()
                tutupDanLanjutAudio()
            }
        }
    }

    /** Mengenali salam, sapaan, ucapan terima kasih, dan perpisahan dalam bahasa aktif. */
    private fun tanganiUcapanSosial(kandidat: List<String>): Boolean {
        val teks = kandidat.map { ucapan ->
            ucapan.lowercase(java.util.Locale.ROOT)
                .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
                .replace(Regex("\\s+"), " ").trim()
        }.filter { it.isNotBlank() }
        if (teks.isEmpty()) return false

        val salamIslam = teks.any { u ->
            u.contains("assalamualaikum") || u.contains("assalamu alaikum") ||
                u.contains("asalamualaikum") || u.contains("assalamuallaikum") ||
                u.contains("السلام عليكم") || u.contains("salamualaikum") ||
                u == "salam" || u.startsWith("salam ")
        }
        val sapaanPagi = teks.any { it.contains("selamat pagi") || it.contains("good morning") }
        val sapaanSiang = teks.any { it.contains("selamat siang") || it.contains("good afternoon") }
        val sapaanSore = teks.any { it.contains("selamat sore") || it.contains("good evening") }
        val sapaanMalam = teks.any { it.contains("selamat malam") || it.contains("good night") }
        val sapaanUmum = teks.any { u ->
            u == "halo" || u.startsWith("halo ") || u == "hai" || u.startsWith("hai ") ||
                u == "hello" || u.startsWith("hello ") || u == "hey" || u.startsWith("hey ") ||
                (u.contains("jam pintar") && !Regex("\\b(buka|bukakan|tampilkan|masuk|jalankan|open|launch|show|go|akses)\\b").containsMatchIn(u)) || u.contains("apa kabar") || u.contains("how are you")
        }
        val terimaKasih = teks.any { u ->
            u.contains("terima kasih") || u.contains("makasih") || u.contains("thanks") ||
                u.contains("thank you") || u.contains("jazakallah") || u.contains("syukran")
        }
        val perpisahan = teks.any { u ->
            u.contains("selamat tinggal") || u.contains("sampai jumpa") || u.contains("dadah") ||
                u == "bye" || u.startsWith("goodbye") || u.contains("see you")
        }
        if (!salamIslam && !sapaanPagi && !sapaanSiang && !sapaanSore && !sapaanMalam &&
            !sapaanUmum && !terimaKasih && !perpisahan) return false

        val sambutanPertama = (salamIslam || sapaanPagi || sapaanSiang || sapaanSore || sapaanMalam || sapaanUmum) &&
            !getSharedPreferences("asisten_suara", MODE_PRIVATE).getBoolean("perkenalan_sudah_disampaikan", false)
        val kalimat = when {
            terimaKasih -> listOf(tr("Sama-sama.", "You're very welcome."), tr("Dengan senang hati saya membantu Anda.", "I'm happy to help you."))
            perpisahan -> listOf(tr("Selamat beraktivitas.", "Goodbye."), tr("Semoga hari Anda menyenangkan. Sampai jumpa kembali.", "May your day be pleasant. See you again."))
            else -> {
                val hasil = mutableListOf<String>()
                if (salamIslam) {
                    hasil += tr("Wa'alaikumussalam warahmatullahi wabarakatuh.", "Wa alaikum assalam wa rahmatullahi wa barakatuh.")
                } else if (sapaanPagi) {
                    hasil += tr("Selamat pagi. Semoga Anda sehat dan bersemangat hari ini.", "Good morning. I hope you are doing well.")
                } else if (sapaanSiang) {
                    hasil += tr("Selamat siang. Semoga aktivitas Anda berjalan lancar.", "Good afternoon. I hope you are doing well.")
                } else if (sapaanSore) {
                    hasil += tr("Selamat sore. Semoga hari Anda menyenangkan.", "Good afternoon. I hope your day is going well.")
                } else if (sapaanMalam) {
                    hasil += tr("Selamat malam. Semoga malam Anda tenang dan menyenangkan.", "Good evening. I hope you can relax and enjoy your evening.")
                } else {
                    hasil += tr("Halo. Selamat datang.", "Hello. Welcome.")
                }
                if (sambutanPertama) {
                    hasil += tr("Selamat datang di Jam Pintar Pro.", "Welcome to Jam Pintar Pro.")
                    hasil += tr("Perkenalkan, saya adalah asisten suara Jam Pintar Pro yang insya Allah selalu siap membantu Anda.",
                        "Allow me to introduce myself. I am the Jam Pintar Pro voice assistant, and God willing, I am always ready to help you.")
                    hasil += tr("Silakan sampaikan perintah atau pertanyaan Anda. Saya akan berusaha membantu menjalankan berbagai fitur yang tersedia di aplikasi ini.",
                        "Please tell me your commands or questions. I will do my best to help you use the features available in this application.")
                    hasil += tr("Ada yang bisa saya bantu?", "How may I help you today?")
                } else {
                    hasil += tr("Ada yang bisa saya bantu?", "How may I help you?")
                }
                hasil
            }
        }
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        try {
            val prefs = Prefs(applicationContext)
            val suara = Pembicara(applicationContext, prefs.suara("jam"))
                .also { it.bisaDibungkam = true; it.paksaBahasaTampilan = true }
            pembicaraTanggal = suara
            suara.ucapkanRangkaian(kalimat, 420L) {
                if (sambutanPertama) {
                    getSharedPreferences("asisten_suara", MODE_PRIVATE).edit()
                        .putBoolean("perkenalan_sudah_disampaikan", true).apply()
                }
                tutupDanLanjutAudio()
            }
        } catch (_: Exception) {
            tutupDanLanjutAudio()
        }
        return true
    }

    /** Membaca status baterai terkini atas permintaan langsung pengguna. */
    private fun bacakanBaterai() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = (intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        if (level < 0) {
            bacakanBateraiDenganSuara(tr("Status baterai saat ini belum tersedia.", "Battery status is currently unavailable."))
            return
        }
        val persen = (level * 100 / scale).coerceIn(0, 100)
        val mengisi = (intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val bahasa = BahasaAplikasi.tampilan(this)
        // FIX221: kalimat lengkap dan berurutan: "Status baterai", angka (dieja untuk bahasa Indonesia dan Inggris), kata persen,
        // lalu keadaan pengisian sebagai kalimat tersendiri. Tidak memakai kata "tersisa".
        val teks = when (bahasa) {
            1 -> "Battery status: " + ejaInggris(persen) + " percent. " + (if (mengisi) "Charging." else "Not charging.")
            2 -> "حالة البطارية: $persen بالمئة. " + (if (mengisi) "قيد الشحن." else "ليست قيد الشحن.")
            3 -> "Status baterei: $persen persen. " + (if (mengisi) "Lagi diisi." else "Ora lagi diisi.")
            4 -> "Status batré: $persen persén. " + (if (mengisi) "Keur dieusi." else "Henteu keur dieusi.")
            else -> tr("Status baterai: ", "Battery status: ") + ejaIndonesia(persen) + tr(" persen. ", " percent. ") + (if (mengisi) tr("Sedang diisi daya.", "Charging.") else tr("Tidak sedang diisi daya.", "Not charging."))
        }
        bacakanBateraiDenganSuara(teks)
    }

    private fun ejaIndonesia(n: Int): String {
        val satuan = listOf("nol", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan")
        return when {
            n >= 100 -> "seratus"
            n < 10 -> satuan[n]
            n == 10 -> "sepuluh"
            n == 11 -> "sebelas"
            n < 20 -> satuan[n - 10] + " belas"
            n % 10 == 0 -> satuan[n / 10] + " puluh"
            else -> satuan[n / 10] + " puluh " + satuan[n % 10]
        }
    }

    private fun ejaInggris(n: Int): String {
        val kecil = listOf("zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
            "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen")
        val puluhan = listOf("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety")
        return when {
            n >= 100 -> "one hundred"
            n < 20 -> kecil[n]
            n % 10 == 0 -> puluhan[n / 10]
            else -> puluhan[n / 10] + " " + kecil[n % 10]
        }
    }

    private fun bacakanBateraiDenganSuara(teks: String) {
        try {
            val p = Prefs(applicationContext)
            val suara = Pembicara(applicationContext, p.suara("bat")).also {
                it.bisaDibungkam = true
                it.paksaBahasaTampilan = true
            }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    private fun pesanKosong(p: Prefs, jenis: String): String = when (p.bahasaAktif) {
        1 -> if (jenis == "holiday") "No holiday information is available." else "Prayer time information is unavailable. Check your prayer location and schedule."
        2 -> if (jenis == "holiday") "لا تتوفر معلومات عن العطلات." else "معلومات أوقات الصلاة غير متاحة. تحقق من الموقع والجدول."
        3 -> if (jenis == "holiday") "Informasi preinan dereng cumawis." else "Informasi wekdal salat dereng cumawis. Priksa lokasi lan jadwal salat."
        4 -> if (jenis == "holiday") "Inpormasi libur teu sayogi." else "Inpormasi waktos salat teu sayogi. Pariksa lokasi sareng jadwal salat."
        else -> if (jenis == "holiday") getString(R.string.perintah_kosong_libur) else getString(R.string.perintah_kosong_sholat)
    }

    /** Mengambil lokasi perangkat terkini; koordinat Jadwal Sholat menjadi cadangan bila lokasi langsung tidak tersedia. */
    private fun ambilLokasiUntukCuaca(akurat: Boolean = false, selesaiLokasi: (android.location.Location?) -> Unit) {
        val izinFine = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val izinCoarse = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!izinFine && !izinCoarse) { selesaiLokasi(null); return }

        val manager = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (manager == null) { selesaiLokasi(null); return }
        val penyedia = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { manager.isProviderEnabled(it) } catch (_: Exception) { false } }
        val sekarang = System.currentTimeMillis()
        // FIX297: perintah lokasi kembali mengejar ketelitian terbaik (sekitar 2 sampai 3 meter): GPS segar, berhenti langsung saat <= 3 m,
        // bila belum tercapai terus mengumpulkan bacaan dan merata-ratakannya hingga 35 detik (berhenti pada 18 detik hanya jika sudah <= 5 m). Cuaca cukup 2 kilometer.
        val batasAkurasi = if (akurat) 3f else 2_000f
        val sampelGps = ArrayList<android.location.Location>()
        var cache: android.location.Location? = null
        try {
            for (provider in penyedia) {
                val kandidat = try { manager.getLastKnownLocation(provider) } catch (_: Exception) { null }
                if (kandidat != null && kandidat.accuracy > 0f &&
                    sekarang - kandidat.time in 0L..(if (akurat) 15_000L else 300_000L) &&
                    (cache == null || kandidat.accuracy < cache!!.accuracy)) cache = kandidat
            }
        } catch (_: SecurityException) { }
        if (cache != null && cache!!.accuracy <= batasAkurasi) { selesaiLokasi(cache); return }
        if (penyedia.isEmpty()) { selesaiLokasi(cache); return }

        var terbaik = cache
        var sudahSelesai = false
        lateinit var listener: android.location.LocationListener
        val timeout = Runnable {
            if (sudahSelesai) return@Runnable
            sudahSelesai = true
            try { manager.removeUpdates(listener) } catch (_: Exception) { }
            selesaiLokasi(if (akurat) rataRataSampel(sampelGps) ?: terbaik else terbaik)
        }
        val lunak = Runnable {
            if (sudahSelesai) return@Runnable
            val t = terbaik
            if (t != null && t.accuracy <= 5f) {
                sudahSelesai = true
                handler.removeCallbacks(timeout)
                try { manager.removeUpdates(listener) } catch (_: Exception) { }
                selesaiLokasi(rataRataSampel(sampelGps)?.takeIf { it.accuracy <= t.accuracy + 5f } ?: t)
            }
        }
        listener = object : android.location.LocationListener {
            override fun onLocationChanged(location: android.location.Location) {
                if (sudahSelesai || location.accuracy <= 0f) return
                if (akurat && location.provider == LocationManager.GPS_PROVIDER) sampelGps.add(location)
                val lama = terbaik
                if (lama == null || location.accuracy < lama.accuracy ||
                    (location.accuracy <= lama.accuracy + 2f && location.time > lama.time)) terbaik = location
                // Satu pembacaan langsung yang wajar sudah cukup untuk permintaan cuaca.
                val cukup = location.accuracy <= batasAkurasi
                if (cukup) {
                    sudahSelesai = true
                    handler.removeCallbacks(timeout)
                    handler.removeCallbacks(lunak)
                    try { manager.removeUpdates(this) } catch (_: Exception) { }
                    selesaiLokasi(if (akurat) rataRataSampel(sampelGps) ?: location else location)
                }
            }
            @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            var diminta = false
            for (provider in penyedia) {
                if (sudahSelesai) break
                try {
                    manager.requestLocationUpdates(provider, 1_000L, 0f, listener, Looper.getMainLooper())
                    diminta = true
                } catch (_: Exception) { }
            }
            if (!diminta) { selesaiLokasi(terbaik); return }
            handler.postDelayed(timeout, if (akurat) 35_000L else 12_000L)
            if (akurat) handler.postDelayed(lunak, 18_000L)
        } catch (_: SecurityException) {
            selesaiLokasi(terbaik)
        }
    }

    /**
     * FIX258: merata-ratakan beberapa bacaan GPS (bobot 1 per akurasi kuadrat) dari bacaan terbaik saja; galat acak mengecil,
     * tetapi bias satelit tidak hilang. Akurasi yang dilaporkan tetap yang terbaik dari satu bacaan (tidak dilebih-lebihkan).
     */
    private fun rataRataSampel(sampel: List<android.location.Location>): android.location.Location? {
        val valid = sampel.filter { it.accuracy > 0f }
        if (valid.isEmpty()) return null
        val terbaik = valid.minOf { it.accuracy }
        val dipakai = valid.filter { it.accuracy <= terbaik * 1.5f + 1f }.takeLast(12)
        var sw = 0.0; var sl = 0.0; var so = 0.0
        for (l in dipakai) { val w = 1.0 / (l.accuracy.toDouble() * l.accuracy); sw += w; sl += l.latitude * w; so += l.longitude * w }
        val hasil = android.location.Location(dipakai.last())
        hasil.latitude = sl / sw; hasil.longitude = so / sw; hasil.accuracy = terbaik
        return hasil
    }

    /** Sumber cadangan cuaca tanpa kunci API. Dipakai bila host Open-Meteo tidak dapat dijangkau. */
    private fun cobaCuacaCadanganWttr(
        lat: Double,
        lon: Double,
        bahasa: Int,
        namaTempat: String?
    ): String? {
        var koneksi: HttpURLConnection? = null
        return try {
            val alamat = "https://wttr.in/$lat,$lon?format=j1"
            val conn = (URL(alamat).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 10_000
                useCaches = false
                instanceFollowRedirects = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) JamPintarPro/1.0.89")
            }
            koneksi = conn
            val status = conn.responseCode
            if (status !in 200..299) return null
            val json = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            val kondisi = json.optJSONArray("current_condition")?.optJSONObject(0) ?: return null
            val suhu = kondisi.optString("temp_C").toDoubleOrNull() ?: return null
            val terasa = kondisi.optString("FeelsLikeC").toDoubleOrNull()
            val lembap = kondisi.optString("humidity").toIntOrNull()
            val angin = kondisi.optString("windspeedKmph").toIntOrNull()
            val deskripsi = kondisi.optJSONArray("weatherDesc")?.optJSONObject(0)?.optString("value")?.trim().orEmpty()
            // Nama daerah sebenarnya (kelurahan/kecamatan/kota); bila belum diperoleh, pakai nama area dari wttr.in.
            val areaWttr = json.optJSONArray("nearest_area")?.optJSONObject(0)?.optJSONArray("areaName")?.optJSONObject(0)?.optString("value")?.trim().orEmpty()
            val namaLokasi = namaTempat?.takeIf { it.isNotBlank() } ?: areaWttr.ifBlank { tr("lokasi Anda saat ini", "your current location") }
            val deskripsiTampil = deskripsi.ifBlank { tr("kondisi cuaca saat ini", "current conditions") }
            buildString {
                // Kalimat disusun dengan penyambungan teks (tanpa templat dolar) agar tidak pernah terbaca sebagai simbol dolar.
                append(tr("Cuaca terkini di " + namaLokasi + ": " + deskripsiTampil + ". Suhu " + suhu.toInt() + " derajat Celsius.",
                    "Current weather for " + namaLokasi + ": " + deskripsiTampil + ". Temperature " + suhu.toInt() + " degrees Celsius."))
                if (terasa != null) append(tr(" Terasa seperti " + terasa.toInt() + " derajat.", " Feels like " + terasa.toInt() + " degrees."))
                if (lembap != null) append(tr(" Kelembapan " + lembap + " persen.", " Humidity " + lembap + " percent."))
                if (angin != null) append(tr(" Kecepatan angin " + angin + " kilometer per jam.", " Wind speed " + angin + " kilometers per hour."))
                append(tr(" Data cadangan dari wttr.in.", " Backup weather data provided by wttr.in."))
            }
        } catch (_: Exception) {
            null
        } finally {
            try { koneksi?.disconnect() } catch (_: Exception) { }
        }
    }

    /**
     * Nama daerah untuk diucapkan pada informasi cuaca (kelurahan/kecamatan, kota, provinsi) menurut bahasa aktif.
     * Blokir: panggil dari thread latar. Urutan: nama tersimpan yang spesifik (untuk lokasi tersimpan), Geocoder perangkat,
     * lalu layanan geokode cadangan BigDataCloud. Null bila semuanya gagal; pemanggil memakai kalimat umum.
     */
    private fun namaTempatCuaca(lat: Double, lon: Double, lokasiLangsung: Boolean, pp: PrayerPrefs, bahasa: Int): String? {
        val kode = if (bahasa == 1) "en" else "id"
        if (!lokasiLangsung && pp.locationSet && !NamaLokasi.belumSpesifik(pp.place)) {
            val tersimpan = NamaLokasi.nama(applicationContext, pp, if (bahasa == 1) 1 else 0)
            if (tersimpan.isNotBlank()) return tersimpan
        }
        NamaLokasi.cari(applicationContext, lat, lon, kode)?.takeIf { it.isNotBlank() }?.let { return it }
        var koneksi: HttpURLConnection? = null
        return try {
            val alamat = "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=" + lat + "&longitude=" + lon + "&localityLanguage=" + kode
            val c = (URL(alamat).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 6_000; readTimeout = 8_000; useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            koneksi = c
            if (c.responseCode !in 200..299) return null
            val o = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            listOf(o.optString("locality"), o.optString("city"), o.optString("principalSubdivision"))
                .map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(3)
                .joinToString(", ").ifBlank { null }
        } catch (_: Exception) {
            null
        } finally {
            try { koneksi?.disconnect() } catch (_: Exception) { }
        }
    }

    /**
     * FIX217: informasi BMKG (gempa terbaru, gempa M5.0+, gempa dirasakan, tsunami, peringatan dini cuaca) selalu diunduh langsung
     * dari BMKG saat diminta. Peringatan dini memakai wilayah yang disebut pengguna atau lokasi aktif perangkat.
     */
    private fun bacakanBmkg(kandidat: List<String>) {
        val daftarToken = kandidat.map { InfoBmkg.token(it) }
        val idx = daftarToken.indexOfFirst { InfoBmkg.jenisDari(it) != null }
        if (idx < 0) { tutup(); return }
        val jenis = InfoBmkg.jenisDari(daftarToken[idx])!!
        val en = BahasaAplikasi.tampilan(this) == 1
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        fun jalankan(wilayah: String?) {
            Thread {
                val teks = InfoBmkg.laporan(jenis, wilayah, en)
                runOnUiThread { if (!isFinishing && !selesai) bacakanTeksBahasaTampilan(teks) }
            }.start()
        }
        if (jenis != InfoBmkg.Jenis.PERINGATAN_DINI && jenis != InfoBmkg.Jenis.RINGKASAN) { jalankan(null); return }
        val disebut = InfoBmkg.wilayahDariUcapan(daftarToken[idx])
        if (disebut != null) { jalankan(disebut); return }
        val pp = PrayerPrefs(applicationContext)
        val tersimpanValid = pp.locationSet && pp.lat in -90.0..90.0 && pp.lon in -180.0..180.0 && !(pp.lat == 0.0 && pp.lon == 0.0)
        ambilLokasiUntukCuaca { lokasiLangsung ->
            if (selesai || isFinishing) return@ambilLokasiUntukCuaca
            val lat = lokasiLangsung?.latitude ?: if (tersimpanValid) pp.lat else Double.NaN
            val lon = lokasiLangsung?.longitude ?: if (tersimpanValid) pp.lon else Double.NaN
            if (!lat.isFinite() || !lon.isFinite()) { jalankan(null); return@ambilLokasiUntukCuaca }
            Thread {
                // Nama wilayah dalam bahasa Indonesia agar cocok dengan teks peringatan BMKG, apa pun bahasa tampilan.
                val nama = try { namaTempatCuaca(lat, lon, lokasiLangsung != null, pp, 0) } catch (_: Exception) { null }
                val teks = InfoBmkg.laporan(jenis, nama, en)
                runOnUiThread { if (!isFinishing && !selesai) bacakanTeksBahasaTampilan(teks) }
            }.start()
        }
    }

    /** Membacakan cuaca terkini; Open-Meteo menjadi sumber utama dan wttr.in sumber cadangan. */
    private fun bacakanCuaca(kandidat: List<String> = emptyList()) {
        // FIX225: fokus (hujan, angin, suhu, kelembapan, UV) dan hari (hari ini, besok, lusa) dibaca dari ucapan.
        val daftarMinta = kandidat.map { InfoCuaca.permintaanDari(InfoBmkg.token(it)) }
        val mintaCuaca = daftarMinta.firstOrNull { it.fokus != InfoCuaca.Fokus.UMUM || it.hari > 0 || it.bagian >= 0 || it.rinci } ?: InfoCuaca.Permintaan(InfoCuaca.Fokus.UMUM, 0)
        val bahasa = BahasaAplikasi.tampilan(this)
        val tempatLain = kandidat.firstNotNullOfOrNull { TempatDisebut.ekstrak(InfoBmkg.token(it)) }
        if (tempatLain != null) { cuacaTempatLain(tempatLain, mintaCuaca, bahasa, kandidat.any { "bmkg" in InfoBmkg.token(it) }); return }
        val pp = PrayerPrefs(applicationContext)
        val lokasiTersimpanValid = pp.locationSet && pp.lat in -90.0..90.0 && pp.lon in -180.0..180.0 && !(pp.lat == 0.0 && pp.lon == 0.0)
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        ambilLokasiUntukCuaca { lokasiLangsung ->
            if (selesai || isFinishing) return@ambilLokasiUntukCuaca
            val lat = lokasiLangsung?.latitude ?: if (lokasiTersimpanValid) pp.lat else Double.NaN
            val lon = lokasiLangsung?.longitude ?: if (lokasiTersimpanValid) pp.lon else Double.NaN
            if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) {
                val pesan = tr(
                    "Lokasi perangkat belum berhasil diperoleh. Pastikan izin dan layanan lokasi aktif, atau atur lokasi pada Pengaturan Jadwal Sholat, lalu coba lagi.",
                    "The device location could not be obtained. Make sure location permission and location services are enabled, or set a location in Prayer Schedule Settings, then try again."
                )
                bacakanTeksBahasaTampilan(pesan)
                return@ambilLokasiUntukCuaca
            }
            Thread {
                // Nama daerah dicari dari koordinat yang dipakai (lokasi aktif); gagal mencari tidak menggagalkan cuaca.
                val namaTempat: String? = try { namaTempatCuaca(lat, lon, lokasiLangsung != null, pp, bahasa) } catch (_: Exception) { null }
                // Peringatan dini BMKG untuk wilayah ini (nama wilayah dalam bahasa Indonesia agar cocok dengan teks BMKG); gagal tidak menggagalkan cuaca.
                val peringatanBmkg: String? = if (mintaCuaca.hari == 0) try {
                    val namaId = if (bahasa == 0) namaTempat else namaTempatCuaca(lat, lon, lokasiLangsung != null, pp, 0)
                    InfoBmkg.peringatanSingkat(namaId, bahasa == 1)
                } catch (_: Exception) { null } else null
                val hasilBaru = OpenMeteo.laporan(lat, lon, namaTempat, bahasa == 1, mintaCuaca, peringatanBmkg)
                val hasil = hasilBaru ?: try {
                    val alamat = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto"
                    val koneksi = (URL(alamat).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 15_000
                        readTimeout = 20_000
                        useCaches = false
                        instanceFollowRedirects = true
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("Cache-Control", "no-cache")
                        setRequestProperty("User-Agent", "JamPintarPro/1.0.89 (Android)")
                    }
                    try {
                        val kodeHttp = koneksi.responseCode
                        if (kodeHttp !in 200..299) {
                            // Bedakan penolakan server (mis. 429/5xx) dari gangguan jaringan perangkat.
                            throw java.io.IOException("HTTP_STATUS:$kodeHttp")
                        }
                        val isi = koneksi.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val json = JSONObject(isi)
                        val now = json.optJSONObject("current")
                            ?: throw org.json.JSONException("Missing current data")
                        val suhu = now.optDouble("temperature_2m", Double.NaN)
                        val terasa = now.optDouble("apparent_temperature", Double.NaN)
                        val lembap = now.optInt("relative_humidity_2m", -1)
                        val angin = now.optDouble("wind_speed_10m", Double.NaN)
                        val kode = now.optInt("weather_code", -1)
                        if (!suhu.isFinite()) throw org.json.JSONException("Invalid temperature")
                        val lokasiNama = namaTempat?.takeIf { it.isNotBlank() } ?: tr("lokasi Anda saat ini", "your current location")
                        buildString {
                            val kondisiTeks = kondisiCuaca(kode, bahasa)
                            append(tr("Cuaca terkini di " + lokasiNama + ": " + kondisiTeks + ". Suhu " + suhu.toInt() + " derajat Celsius.",
                                "Current weather for " + lokasiNama + ": " + kondisiTeks + ". Temperature " + suhu.toInt() + " degrees Celsius."))
                            if (terasa.isFinite()) append(tr(" Terasa seperti " + terasa.toInt() + " derajat.", " Feels like " + terasa.toInt() + " degrees."))
                            if (lembap in 0..100) append(tr(" Kelembapan " + lembap + " persen.", " Humidity " + lembap + " percent."))
                            if (angin.isFinite()) append(tr(" Kecepatan angin " + angin.toInt() + " kilometer per jam.", " Wind speed " + angin.toInt() + " kilometers per hour."))
                            append(tr(" Data cuaca dari Open-Meteo.", " Weather data provided by Open-Meteo."))
                        }
                    } finally { koneksi.disconnect() }
                } catch (e: java.net.SocketTimeoutException) {
                    cobaCuacaCadanganWttr(lat, lon, bahasa, namaTempat)
                        ?: tr("Permintaan data cuaca utama melewati batas waktu dan sumber cadangan belum dapat dijangkau. Coba kembali beberapa saat lagi.", "The primary weather request timed out and the backup source could not be reached. Please try again shortly.")
                } catch (e: java.io.IOException) {
                    cobaCuacaCadanganWttr(lat, lon, bahasa, namaTempat) ?: run {
                    val detail = e.message.orEmpty()
                    when {
                        detail.startsWith("HTTP_STATUS:") -> {
                            val status = detail.substringAfter(':').toIntOrNull() ?: -1
                            when {
                                status == 429 -> tr("Layanan cuaca sedang membatasi jumlah permintaan. Tunggu sebentar, lalu coba kembali.", "The weather service is rate-limiting requests. Wait briefly, then try again.")
                                status in 500..599 -> tr("Server penyedia cuaca sedang mengalami gangguan. Koneksi internet ponsel Anda belum tentu bermasalah. Silakan coba kembali nanti.", "The weather provider's server is temporarily unavailable. Your phone's internet connection may be working normally. Please try again later.")
                                status in 400..499 -> tr("Permintaan cuaca ditolak oleh server (kode " + status + "). Periksa versi aplikasi atau coba kembali nanti.", "The weather request was rejected by the server (code " + status + "). Check the app version or try again later.")
                                else -> tr("Server cuaca memberikan respons yang tidak berhasil. Silakan coba kembali nanti.", "The weather server returned an unsuccessful response. Please try again later.")
                            }
                        }
                        e is java.net.UnknownHostException -> tr("Nama server cuaca tidak dapat ditemukan. Ini dapat disebabkan DNS atau pemblokiran alamat layanan, bukan selalu karena koneksi internet terputus.", "The weather server address could not be resolved. This may be caused by DNS or service-address blocking, not necessarily a disconnected internet connection.")
                        e is javax.net.ssl.SSLException -> tr("Sambungan aman ke layanan cuaca gagal dibuat. Periksa tanggal dan waktu perangkat, lalu coba kembali.", "A secure connection to the weather service could not be established. Check the device date and time, then try again.")
                        e is java.net.SocketException -> tr("Sambungan ke server cuaca terputus sebelum data diterima. Internet ponsel mungkin tetap aktif; coba kembali.", "The connection to the weather server was interrupted before data arrived. Your phone's internet may still be active; please try again.")
                        else -> tr("Sumber cuaca utama dan cadangan tidak dapat dijangkau. Koneksi internet ponsel belum tentu bermasalah; layanan cuaca mungkin sedang membatasi atau menolak permintaan.", "Neither the primary nor backup weather source could be reached. Your phone's internet may still be working; the weather services may be limiting or rejecting requests.")
                    }
                    }
                } catch (_: Exception) {
                    cobaCuacaCadanganWttr(lat, lon, bahasa, namaTempat)
                        ?: tr("Data dari sumber cuaca utama tidak dapat dibaca dan sumber cadangan belum tersedia. Silakan coba kembali nanti.", "The primary weather data could not be read and the backup source is unavailable. Please try again later.")
                }
                runOnUiThread { if (!isFinishing && !selesai) bacakanTeksBahasaTampilan(hasil) }
            }.start()
        }
    }

    /** FIX254: cuaca di tempat lain yang disebut pengguna (misalnya Mekkah atau Bandung); peringatan BMKG hanya untuk wilayah Indonesia. */
    private fun cuacaTempatLain(nama: String, minta: InfoCuaca.Permintaan, bahasa: Int, sebutBmkg: Boolean) {
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        Thread {
            val en = bahasa == 1
            val tempat = try { TempatDisebut.cari(applicationContext, nama, en) } catch (_: Exception) { null }
            val pesan: String = if (tempat == null) {
                tr("Tempat bernama " + nama + " tidak ditemukan. Coba sebutkan nama kota yang lebih jelas.", "A place named " + nama + " was not found. Try saying a clearer city name.")
            } else {
                val diIndonesia = tempat.kodeNegara == "ID"
                val peringatan: String? = if (diIndonesia && minta.hari == 0) try { InfoBmkg.peringatanSingkat(nama, en) } catch (_: Exception) { null } else null
                val inti = OpenMeteo.laporan(tempat.lat, tempat.lon, tempat.nama, en, minta, peringatan)
                    ?: cobaCuacaCadanganWttr(tempat.lat, tempat.lon, bahasa, tempat.nama)
                    ?: tr("Data cuaca untuk " + tempat.nama + " belum dapat diambil. Periksa koneksi internet, lalu coba lagi.", "Weather data for " + tempat.nama + " could not be fetched. Check your internet connection and try again.")
                val catatan = if (sebutBmkg && !diIndonesia) tr("BMKG hanya mencakup wilayah Indonesia, jadi prakiraan ini memakai Open-Meteo. ", "BMKG only covers Indonesia, so this forecast uses Open-Meteo. ") else ""
                catatan + inti
            }
            runOnUiThread { if (!isFinishing && !selesai) bacakanTeksBahasaTampilan(pesan) }
        }.start()
    }

    // ---------- FIX250: kendali suara untuk mode acara, lokasi terkini, dan sakelar fitur ----------

    private fun kendaliModeAcara(kandidat: List<String>) {
        val aksi = kandidat.mapNotNull { PerintahSuara.kendaliModeAcara(listOf(it)) }.firstOrNull() ?: 0
        val ctx = applicationContext
        val pesan: String = when (aksi) {
            1 -> {
                val menit = PerintahSuara.menitModeAcara(kandidat).let { if (it > 0) it else 60 }
                val lama = if (menit % 60 == 0) tr((menit / 60).toString() + " jam", (menit / 60).toString() + " hours") else tr(menit.toString() + " menit", menit.toString() + " minutes")
                val cakupan = ModeAcara.cakupan(ctx)
                if (ModeAcara.mulai(ctx, menit, cakupan)) tr("Mode acara diaktifkan selama " + lama + ".", "Event mode turned on for " + lama + ".")
                else if (ModeAcara.mulai(ctx, menit, ModeAcara.CAKUPAN_JAM_PINTAR))
                    tr("Mode acara diaktifkan selama " + lama + ", hanya menahan pengumuman Jam Pintar Pro karena izin Jangan Ganggu belum diberikan.",
                       "Event mode turned on for " + lama + ", holding only Jam Pintar Pro announcements because Do Not Disturb access has not been granted.")
                else tr("Mode acara gagal diaktifkan.", "Event mode could not be turned on.")
            }
            -1 -> {
                if (ModeAcara.aktif(ctx)) { ModeAcara.selesai(ctx); tr("Mode acara dimatikan.", "Event mode turned off.") }
                else tr("Mode acara memang sedang tidak aktif.", "Event mode is already off.")
            }
            else -> if (ModeAcara.aktif(ctx)) tr("Mode acara sedang aktif.", "Event mode is on.") else tr("Mode acara sedang tidak aktif.", "Event mode is off.")
        }
        bacakanTeksBahasaTampilan(pesan)
    }

    /** FIX253: menjawab pertanyaan kondisi perangkat (RAM, memori internal, 32 atau 64 bit, model, Android, layar, dan sebagainya). */
    private fun bacakanInfoPerangkat(kandidat: List<String>) {
        val topik = kandidat.map { PerintahSuara.infoPerangkat(listOf(it)) }.firstOrNull { it.isNotEmpty() } ?: run { tutup(); return }
        val indonesia = tr("1", "0") == "1"
        fun angka(v: Double): String { val x = String.format(java.util.Locale.US, if (v >= 10) "%.0f" else "%.1f", v); return if (indonesia) x.replace('.', ',') else x }
        fun gb(b: Long): String = angka(b / 1073741824.0)
        val minta = if (TopikPerangkat.SEMUA in topik) listOf(TopikPerangkat.MODEL, TopikPerangkat.ANDROID, TopikPerangkat.ARSITEKTUR, TopikPerangkat.PROSESOR, TopikPerangkat.RAM, TopikPerangkat.MEMORI_INTERNAL, TopikPerangkat.LAYAR, TopikPerangkat.UPTIME) else topik.toList()
        val kalimat = ArrayList<String>()
        for (k in minta) {
            try {
                when (k) {
                    TopikPerangkat.RAM -> {
                        val mi = android.app.ActivityManager.MemoryInfo()
                        (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
                        val persen = if (mi.totalMem > 0) (mi.availMem * 100 / mi.totalMem).toInt() else 0
                        kalimat.add(tr("RAM perangkat Anda total " + gb(mi.totalMem) + " gigabyte, saat ini tersedia " + gb(mi.availMem) + " gigabyte atau " + persen + " persen.",
                            "Your device has " + gb(mi.totalMem) + " gigabytes of RAM in total, with " + gb(mi.availMem) + " gigabytes, or " + persen + " percent, available now."))
                    }
                    TopikPerangkat.MEMORI_INTERNAL -> {
                        val sf = android.os.StatFs(android.os.Environment.getDataDirectory().path)
                        val total = sf.blockCountLong * sf.blockSizeLong
                        val bebas = sf.availableBlocksLong * sf.blockSizeLong
                        val terpakai = if (total > 0) ((total - bebas) * 100 / total).toInt() else 0
                        var kal = tr("Memori internal tersisa " + gb(bebas) + " gigabyte dari total " + gb(total) + " gigabyte, terpakai " + terpakai + " persen.",
                            "Internal storage has " + gb(bebas) + " gigabytes free out of " + gb(total) + " gigabytes, " + terpakai + " percent used.")
                        try {
                            val luar = getExternalFilesDirs(null)
                            for (i in 1 until luar.size) {
                                val d = luar[i] ?: continue
                                val s2 = android.os.StatFs(d.path)
                                kal += " " + tr("Kartu memori tersisa " + gb(s2.availableBlocksLong * s2.blockSizeLong) + " gigabyte dari " + gb(s2.blockCountLong * s2.blockSizeLong) + " gigabyte.",
                                    "The memory card has " + gb(s2.availableBlocksLong * s2.blockSizeLong) + " gigabytes free out of " + gb(s2.blockCountLong * s2.blockSizeLong) + " gigabytes.")
                            }
                        } catch (_: Exception) { }
                        kalimat.add(kal)
                    }
                    TopikPerangkat.ARSITEKTUR -> {
                        val cpu64 = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
                        val app64 = if (Build.VERSION.SDK_INT >= 23) android.os.Process.is64Bit() else false
                        kalimat.add(
                            if (cpu64) tr("Perangkat Anda 64-bit. Aplikasi ini berjalan dalam mode " + (if (app64) "64-bit." else "32-bit."),
                                "Your device is 64-bit. This app runs in " + (if (app64) "64-bit" else "32-bit") + " mode.")
                            else tr("Perangkat Anda 32-bit.", "Your device is 32-bit."))
                    }
                    TopikPerangkat.PROSESOR -> {
                        val soc = if (Build.VERSION.SDK_INT >= 31) (Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL).trim() else Build.HARDWARE
                        val inti = Runtime.getRuntime().availableProcessors()
                        kalimat.add(tr("Prosesor " + soc + ", " + inti + " inti, arsitektur " + (Build.SUPPORTED_ABIS.firstOrNull() ?: "tidak diketahui") + ".",
                            "Processor " + soc + ", " + inti + " cores, architecture " + (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown") + "."))
                    }
                    TopikPerangkat.MODEL -> kalimat.add(tr("Perangkat Anda " + Build.MANUFACTURER + " " + Build.MODEL + ".", "Your device is a " + Build.MANUFACTURER + " " + Build.MODEL + "."))
                    TopikPerangkat.ANDROID -> kalimat.add(tr("Versi Android " + Build.VERSION.RELEASE + ", level API " + Build.VERSION.SDK_INT + (if (Build.VERSION.SDK_INT >= 23) ", patch keamanan " + Build.VERSION.SECURITY_PATCH else "") + ".",
                        "Android version " + Build.VERSION.RELEASE + ", API level " + Build.VERSION.SDK_INT + (if (Build.VERSION.SDK_INT >= 23) ", security patch " + Build.VERSION.SECURITY_PATCH else "") + "."))
                    TopikPerangkat.LAYAR -> {
                        val dm = resources.displayMetrics
                        val hz = try { (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.refreshRate } catch (_: Exception) { 0f }
                        kalimat.add(tr("Layar " + dm.widthPixels + " kali " + dm.heightPixels + " piksel, kepadatan " + dm.densityDpi + " dpi" + (if (hz > 0f) ", kecepatan penyegaran " + angka(hz.toDouble()) + " hertz" else "") + ".",
                            "Screen " + dm.widthPixels + " by " + dm.heightPixels + " pixels, " + dm.densityDpi + " dpi" + (if (hz > 0f) ", refresh rate " + angka(hz.toDouble()) + " hertz" else "") + "."))
                    }
                    TopikPerangkat.SINYAL -> kalimat.add(laporanSinyal())
                    TopikPerangkat.UPTIME -> {
                        val menit = android.os.SystemClock.elapsedRealtime() / 60000L
                        val jam = menit / 60; val sisa = menit % 60
                        kalimat.add(tr("Perangkat sudah menyala " + (if (jam >= 24) (jam / 24).toString() + " hari " else "") + (jam % 24) + " jam " + sisa + " menit sejak terakhir dihidupkan ulang.",
                            "The device has been on for " + (if (jam >= 24) (jam / 24).toString() + " days " else "") + (jam % 24) + " hours " + sisa + " minutes since the last restart."))
                    }
                    TopikPerangkat.VERSI_APLIKASI -> {
                        val v = packageManager.getPackageInfo(packageName, 0).versionName ?: ""
                        kalimat.add(tr("Jam Pintar Pro versi " + v + ".", "Jam Pintar Pro version " + v + "."))
                    }
                    TopikPerangkat.SEMUA -> { }
                }
            } catch (_: Exception) { }
        }
        if (kalimat.isEmpty()) kalimat.add(tr("Informasi perangkat tidak dapat dibaca.", "Device information could not be read."))
        bacakanTeksBahasaTampilan(kalimat.joinToString(" "))
    }

    private fun generasiJaringan(tipe: Int): String? = when (tipe) {
        20 -> "5G"; 13, 19 -> "4G"
        3, 8, 9, 10, 15, 17, 5, 6, 12 -> "3G"
        1, 2, 4, 7, 11 -> "2G"
        else -> null
    }

    /** FIX301: satu kartu SIM: operator, generasi, kekuatan sinyal, roaming, dan perannya sebagai SIM data. */
    private fun ringkasSatuSim(nomor: String, tmx: android.telephony.TelephonyManager, namaCadangan: String?, simData: Boolean?, izin: Boolean, selulerAktif: Boolean): String {
        if (tmx.simState != android.telephony.TelephonyManager.SIM_STATE_READY)
            return tr(nomor + " belum siap atau tidak terdeteksi.", nomor + " is not ready or not detected.")
        val operator = tmx.networkOperatorName?.takeIf { it.isNotBlank() } ?: namaCadangan?.takeIf { it.isNotBlank() }
        var generasi: String? = null
        if (izin) try { generasi = generasiJaringan(tmx.dataNetworkType) } catch (_: Exception) { }
        var level = -1; var dbm = Int.MIN_VALUE
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                val ss = tmx.signalStrength
                if (ss != null) {
                    level = ss.level
                    if (Build.VERSION.SDK_INT >= 29) ss.cellSignalStrengths.firstOrNull { it.dbm != Int.MAX_VALUE }?.let { dbm = it.dbm }
                }
            }
        } catch (_: Exception) { }
        val dataMenyala: Boolean? = try { if (izin && simData != false) tmx.isDataEnabled else null } catch (_: Exception) { null }
        val sinyal = if (level >= 0) tr("sinyal " + labelSinyal(level) + (if (dbm != Int.MIN_VALUE) ", " + dbm + " dBm" else ""),
            "signal " + labelSinyal(level) + (if (dbm != Int.MIN_VALUE) ", " + dbm + " dBm" else "")) else tr("kekuatan sinyal tidak terbaca", "signal strength could not be read")
        val roaming = try { tmx.isNetworkRoaming } catch (_: Exception) { false }
        val peran: String = when (simData) {
            true -> tr(", SIM untuk data seluler", ", the mobile data SIM") +
                (if (dataMenyala == false) tr(" (data dimatikan)", " (data is off)") else if (dataMenyala == true && !selulerAktif) tr(" (data menyala)", " (data is on)") else "")
            false -> tr(", bukan SIM data", ", not the data SIM")
            null -> ""
        }
        val depan = nomor + (if (operator != null) " " + operator else "") + (if (generasi != null) " " + generasi else "") + ", " + sinyal
        return tr(depan + (if (roaming) ", sedang roaming" else "") + peran + ".", depan + (if (roaming) ", roaming" else "") + peran + ".")
    }

    /** FIX301: jaringan seluler untuk semua SIM aktif (SIM 1, SIM 2, dan seterusnya), bukan hanya SIM bawaan. */
    private fun laporanSeluler(pesawat: Boolean, selulerAktif: Boolean, bagian: MutableList<String>) {
        if (pesawat) return
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as? android.telephony.TelephonyManager ?: return
        val izin = checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        var daftar: List<android.telephony.SubscriptionInfo> = emptyList()
        if (izin) try {
            val sm = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? android.telephony.SubscriptionManager
            daftar = (sm?.activeSubscriptionInfoList ?: emptyList()).sortedBy { it.simSlotIndex }
        } catch (_: Exception) { }
        if (daftar.isEmpty()) {
            bagian.add(ringkasSatuSim(tr("Jaringan seluler", "Mobile network"), tm, null, null, izin, selulerAktif))
            return
        }
        val idData = try { android.telephony.SubscriptionManager.getDefaultDataSubscriptionId() } catch (_: Throwable) { -1 }
        for (info in daftar) {
            val tmx = try { tm.createForSubscriptionId(info.subscriptionId) } catch (_: Throwable) { tm }
            val nomor = "SIM " + (info.simSlotIndex + 1)
            val simData: Boolean? = if (daftar.size > 1 && idData >= 0) info.subscriptionId == idData else null
            bagian.add(ringkasSatuSim(nomor, tmx, info.carrierName?.toString(), simData, izin, selulerAktif))
        }
        val slot = try { tm.phoneCount } catch (_: Throwable) { daftar.size }
        if (slot > daftar.size) bagian.add(tr("Slot SIM lainnya kosong atau tidak aktif.", "The other SIM slot is empty or inactive."))
    }

    private fun labelSinyal(level: Int): String = when (level.coerceIn(0, 4)) {
        0 -> tr("sangat lemah", "very weak"); 1 -> tr("lemah", "weak"); 2 -> tr("sedang", "fair"); 3 -> tr("kuat", "strong"); else -> tr("sangat kuat", "very strong")
    }

    /** FIX297: ringkasan kekuatan jaringan: koneksi aktif, Wi-Fi, data seluler (generasi, operator, sinyal), mode pesawat, dan Bluetooth. */
    private fun laporanSinyal(): String {
        val bagian = ArrayList<String>()
        val pesawat = try { android.provider.Settings.Global.getInt(contentResolver, android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (_: Exception) { false }
        if (pesawat) bagian.add(tr("Mode pesawat sedang aktif.", "Airplane mode is on."))
        var wifiAktifKoneksi = false
        var selulerAktifKoneksi = false
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            val n = cm?.activeNetwork
            val caps = if (n != null) cm.getNetworkCapabilities(n) else null
            if (caps == null) bagian.add(tr("Saat ini tidak ada koneksi internet aktif.", "There is currently no active internet connection."))
            else {
                wifiAktifKoneksi = caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
                selulerAktifKoneksi = caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)
                val lewat = when {
                    wifiAktifKoneksi -> tr("Wi-Fi", "Wi-Fi")
                    selulerAktifKoneksi -> tr("data seluler", "mobile data")
                    caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) -> tr("kabel Ethernet", "Ethernet")
                    caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_BLUETOOTH) -> tr("tethering Bluetooth", "Bluetooth tethering")
                    else -> tr("jaringan lain", "another network")
                }
                val berfungsi = caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                bagian.add(tr("Koneksi aktif lewat " + lewat + (if (berfungsi) ", internet berfungsi." else ", tetapi internet belum terverifikasi atau tidak dapat dipakai."),
                    "The active connection is through " + lewat + (if (berfungsi) ", and the internet is working." else ", but the internet is not verified or cannot be used.")))
            }
        } catch (_: Exception) { }
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
            if (wm != null) {
                if (!wm.isWifiEnabled) bagian.add(tr("Wi-Fi mati.", "Wi-Fi is off."))
                else {
                    @Suppress("DEPRECATION") val info = wm.connectionInfo
                    val rssi = info?.rssi ?: -127
                    val terhubung = info != null && (wifiAktifKoneksi || (info.networkId != -1 && rssi in -126..0))
                    if (!terhubung) bagian.add(tr("Wi-Fi menyala tetapi belum terhubung ke jaringan.", "Wi-Fi is on but not connected to a network."))
                    else {
                        val level = when { rssi >= -50 -> 4; rssi >= -60 -> 3; rssi >= -70 -> 2; rssi >= -80 -> 1; else -> 0 }
                        val ssid = (info.ssid ?: "").replace("\"", "").trim().takeIf { it.isNotBlank() && !it.contains("unknown ssid", true) }
                        val pita = info.frequency.let { if (it <= 0) "" else if (it < 3000) tr("2,4", "2.4") else if (it < 5925) "5" else "6" }
                        bagian.add(tr("Wi-Fi" + (if (ssid != null) " " + ssid else "") + " terhubung, sinyal " + labelSinyal(level) + ", " + rssi + " dBm" +
                            (if (pita.isNotEmpty()) ", pita " + pita + " gigahertz" else "") + (if (info.linkSpeed > 0) ", kecepatan tautan " + info.linkSpeed + " megabit per detik" else "") + ".",
                            "Wi-Fi" + (if (ssid != null) " " + ssid else "") + " is connected, signal " + labelSinyal(level) + ", " + rssi + " dBm" +
                            (if (pita.isNotEmpty()) ", " + pita + " gigahertz band" else "") + (if (info.linkSpeed > 0) ", link speed " + info.linkSpeed + " megabits per second" else "") + "."))
                    }
                }
            }
        } catch (_: Exception) { }
        try { laporanSeluler(pesawat, selulerAktifKoneksi, bagian) } catch (_: Exception) { }
        try {
            val bt = (getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter
            if (bt != null) bagian.add(if (bt.isEnabled) tr("Bluetooth menyala.", "Bluetooth is on.") else tr("Bluetooth mati.", "Bluetooth is off."))
        } catch (_: Exception) { }
        if (bagian.isEmpty()) bagian.add(tr("Informasi jaringan tidak dapat dibaca.", "Network information could not be read."))
        return bagian.joinToString(" ")
    }

    private fun kendaliSakelarFitur(kandidat: List<String>) {
        val (sakelar, nilai) = kandidat.mapNotNull { PerintahSuara.sakelarFitur(listOf(it)) }.firstOrNull() ?: run { tutup(); return }
        val pesan: String = when (sakelar) {
            PerintahSuara.Sakelar.JADWAL_SHOLAT -> {
                val pp = PrayerPrefs(applicationContext)
                pp.enabled = nilai
                try { PrayerAlarm.scheduleAll(applicationContext) } catch (_: Exception) { }
                if (nilai) {
                    if (pp.locationSet) tr("Jadwal sholat diaktifkan.", "Prayer schedule turned on.")
                    else tr("Jadwal sholat diaktifkan, tetapi lokasi belum diatur. Ucapkan perbarui lokasi agar alarm terpasang.", "Prayer schedule turned on, but no location is set. Say update location so alarms can be scheduled.")
                } else tr("Jadwal sholat dimatikan.", "Prayer schedule turned off.")
            }
            PerintahSuara.Sakelar.PENGUMUMAN -> {
                val pr = Prefs(applicationContext)
                pr.enabled = nilai
                try { if (nilai) BatteryTalkService.start(applicationContext) else BatteryTalkService.stop(applicationContext) } catch (_: Exception) { }
                if (nilai) tr("Pengumuman otomatis diaktifkan.", "Automatic announcements turned on.") else tr("Pengumuman otomatis dimatikan.", "Automatic announcements turned off.")
            }
            else -> kendaliSakelarPemanggil(sakelar, nilai)
        }
        bacakanTeksBahasaTampilan(pesan)
    }

    /** FIX308: sakelar Nama Panggilan dan Pembacaan Notifikasi dengan suara. */
    private fun kendaliSakelarPemanggil(sakelar: PerintahSuara.Sakelar, nilai: Boolean): String {
        val pr = Prefs(applicationContext)
        val nama: String
        when (sakelar) {
            PerintahSuara.Sakelar.NAMA_PEMANGGIL -> { pr.pemOn = nilai; nama = tr("Pengumuman nama pemanggil", "Caller name announcement") }
            PerintahSuara.Sakelar.NAMA_PANGGILAN_KONTAK -> { pr.pemNamaPanggilan = nilai; nama = tr("Pemakaian nama panggilan kontak", "Using the contact nickname") }
            PerintahSuara.Sakelar.BACA_SMS -> { pr.bacaPesanSeluler = nilai; nama = tr("Pembacaan notifikasi SMS", "SMS notification reading") }
            PerintahSuara.Sakelar.BACA_WB -> {
                pr.bacaChatWbPribadi = nilai; pr.bacaChatWbGrup = nilai; pr.bacaSuaraWbPribadi = nilai; pr.bacaSuaraWbGrup = nilai
                nama = tr("Pembacaan notifikasi WhatsApp Business", "WhatsApp Business notification reading")
            }
            PerintahSuara.Sakelar.BACA_WA -> {
                pr.bacaChatWaPribadi = nilai; pr.bacaChatWaGrup = nilai; pr.bacaSuaraWaPribadi = nilai; pr.bacaSuaraWaGrup = nilai
                nama = tr("Pembacaan notifikasi WhatsApp Messenger", "WhatsApp Messenger notification reading")
            }
            PerintahSuara.Sakelar.BACA_EMAIL -> { pr.bacaNotifEmail = nilai; nama = tr("Pembacaan notifikasi email", "Email notification reading") }
            PerintahSuara.Sakelar.BACA_GOJEK -> { pr.bacaNotifGojek = nilai; nama = tr("Pembacaan notifikasi Gojek", "Gojek notification reading") }
            PerintahSuara.Sakelar.BACA_GRAB -> { pr.bacaNotifGrab = nilai; nama = tr("Pembacaan notifikasi Grab", "Grab notification reading") }
            PerintahSuara.Sakelar.BACA_INDRIVE -> { pr.bacaNotifInDrive = nilai; nama = tr("Pembacaan notifikasi inDrive", "inDrive notification reading") }
            PerintahSuara.Sakelar.BACA_MAXIM -> { pr.bacaNotifMaxim = nilai; nama = tr("Pembacaan notifikasi Maxim", "Maxim notification reading") }
            PerintahSuara.Sakelar.ANTRIAN_NOTIF -> { pr.antrianNotifOn = nilai; nama = tr("Antrian pembacaan notifikasi", "Notification reading queue") }
            else -> {
                pr.bacaPesanSeluler = nilai; pr.bacaChatWbPribadi = nilai; pr.bacaChatWbGrup = nilai; pr.bacaSuaraWbPribadi = nilai; pr.bacaSuaraWbGrup = nilai
                pr.bacaChatWaPribadi = nilai; pr.bacaChatWaGrup = nilai; pr.bacaSuaraWaPribadi = nilai; pr.bacaSuaraWaGrup = nilai
                pr.bacaNotifEmail = nilai; pr.bacaNotifGojek = nilai; pr.bacaNotifGrab = nilai; pr.bacaNotifInDrive = nilai; pr.bacaNotifMaxim = nilai
                nama = tr("Pembacaan semua notifikasi pesan dan aplikasi bawaan", "Reading of all built-in message and app notifications")
            }
        }
        val izin = if (nilai && !izinAksesNotifikasiAda()) tr(" Akses notifikasi belum diberikan. Ucapkan buka akses notifikasi untuk memberikannya.", " Notification access has not been granted. Say open notification access to grant it.") else ""
        return nama + tr(if (nilai) " diaktifkan." else " dimatikan.", if (nilai) " turned on." else " turned off.") + izin
    }

    private fun izinAksesNotifikasiAda(): Boolean = try {
        android.provider.Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
    } catch (_: Throwable) { false }

    private fun sebutLokasiTerkini() {
        val bahasa = BahasaAplikasi.tampilan(this)
        val pp = PrayerPrefs(applicationContext)
        val tersimpan = pp.locationSet && pp.lat in -90.0..90.0 && pp.lon in -180.0..180.0 && !(pp.lat == 0.0 && pp.lon == 0.0)
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        ambilLokasiUntukCuaca(true) { langsung ->
            if (selesai || isFinishing) return@ambilLokasiUntukCuaca
            val lat = langsung?.latitude ?: if (tersimpan) pp.lat else Double.NaN
            val lon = langsung?.longitude ?: if (tersimpan) pp.lon else Double.NaN
            if (!lat.isFinite() || !lon.isFinite()) {
                bacakanTeksBahasaTampilan(tr("Lokasi perangkat belum berhasil diperoleh. Pastikan izin dan layanan lokasi aktif, lalu coba lagi.",
                    "The device location could not be obtained. Make sure location permission and location services are on, then try again."))
                return@ambilLokasiUntukCuaca
            }
            Thread {
                val rinci: String? = if (langsung != null) try { NamaLokasi.rinci(applicationContext, lat, lon, if (bahasa == 1) "en" else "id") } catch (_: Exception) { null } else null
                val nama: String? = (rinci ?: try { namaTempatCuaca(lat, lon, langsung != null, pp, bahasa) } catch (_: Exception) { null })?.let { NamaLokasi.bersihBagian(it) }
                val akurasi = if (langsung != null && langsung.accuracy > 0f) langsung.accuracy.toInt() else 0
                val ketelitian = if (akurasi == 0) "" else if (akurasi <= 50) tr(" Ketelitian terbaik yang dicapai sekitar " + akurasi + " meter" + (if (akurasi > 5) ". GPS ponsel paling baik sekitar 3 sampai 5 meter di tempat terbuka." else "."), " Best accuracy reached is about " + akurasi + " meters" + (if (akurasi > 5) ". Phone GPS is at best about 3 to 5 meters in the open." else "."))
                    else tr(" Ketelitian kurang baik, sekitar " + akurasi + " meter. Untuk hasil lebih tepat, aktifkan GPS atau pindah ke tempat terbuka, lalu tanyakan lagi.",
                        " Accuracy is poor, about " + akurasi + " meters. For a better result, turn on GPS or move to an open area, then ask again.")
                val koordinat = tr("lintang " + String.format(java.util.Locale.US, "%.4f", lat) + ", bujur " + String.format(java.util.Locale.US, "%.4f", lon),
                    "latitude " + String.format(java.util.Locale.US, "%.4f", lat) + ", longitude " + String.format(java.util.Locale.US, "%.4f", lon))
                val pesan = if (langsung != null) {
                    if (!nama.isNullOrBlank()) tr("Saat ini Anda berada di " + nama + "." + ketelitian, "You are currently in " + nama + "." + ketelitian)
                    else tr("Saat ini Anda berada di koordinat " + koordinat + ".", "You are currently at " + koordinat + ".")
                } else {
                    if (!nama.isNullOrBlank()) tr("Lokasi langsung belum berhasil diperoleh. Lokasi tersimpan Anda: " + nama + ".", "The live location could not be obtained. Your saved location: " + nama + ".")
                    else tr("Lokasi langsung belum berhasil diperoleh. Koordinat lokasi tersimpan: " + koordinat + ".", "The live location could not be obtained. Saved location coordinates: " + koordinat + ".")
                }
                runOnUiThread { if (!selesai && !isFinishing) bacakanTeksBahasaTampilan(pesan) }
            }.start()
        }
    }

    private fun perbaruiLokasiSholat() {
        val bahasa = BahasaAplikasi.tampilan(this)
        val pp = PrayerPrefs(applicationContext)
        handler.removeCallbacks(batasWaktu)
        handler.postDelayed(batasWaktu, 90_000L)
        ambilLokasiUntukCuaca(true) { langsung ->
            if (selesai || isFinishing) return@ambilLokasiUntukCuaca
            if (langsung == null) {
                bacakanTeksBahasaTampilan(tr("Lokasi belum berhasil diperbarui. Pastikan izin dan layanan lokasi aktif, lalu coba lagi.",
                    "The location could not be updated. Make sure location permission and location services are on, then try again."))
                return@ambilLokasiUntukCuaca
            }
            Thread {
                val nama: String? = try { namaTempatCuaca(langsung.latitude, langsung.longitude, true, pp, bahasa) } catch (_: Exception) { null }
                runOnUiThread {
                    pp.lat = langsung.latitude; pp.lon = langsung.longitude
                    pp.place = nama?.takeIf { it.isNotBlank() } ?: "Lokasi perangkat"
                    pp.locationSet = true
                    try { PrayerAlarm.scheduleAll(applicationContext) } catch (_: Exception) { }
                    if (NamaLokasi.belumSpesifik(pp.place)) NamaLokasi.perbaruiAsinkron(applicationContext, pp)
                    if (!selesai && !isFinishing) bacakanTeksBahasaTampilan(
                        if (!nama.isNullOrBlank()) tr("Lokasi diperbarui ke " + nama + ". Jadwal sholat disesuaikan dengan lokasi ini.", "Location updated to " + nama + ". The prayer schedule now follows this location.")
                        else tr("Lokasi diperbarui. Jadwal sholat disesuaikan dengan lokasi ini.", "Location updated. The prayer schedule now follows this location.")
                    )
                }
            }.start()
        }
    }

    /** FIX270: batas waktu layar asisten mengikuti panjang teks yang dibacakan (paling singkat 60 detik), agar bacaan panjang tidak terpotong. */
    private fun batasBaca(teks: String): Long = (teks.length * 150L + 30_000L).coerceIn(60_000L, 900_000L)

    private fun bacakanTeksBahasaTampilan(teks: String) {
        try {
            val prefs = Prefs(applicationContext)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, batasBaca(teks))
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also {
                it.bisaDibungkam = true
                it.paksaBahasaTampilan = true
            }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    private fun kondisiCuaca(kode: Int, bahasa: Int): String {
        val id = when (kode) {
            0 -> "cerah"; 1 -> "umumnya cerah"; 2 -> "cerah berawan"; 3 -> "berawan"; 45, 48 -> "berkabut"
            51, 53, 55 -> "gerimis"; 56, 57 -> "gerimis membeku"; 61, 63, 65 -> "hujan"; 66, 67 -> "hujan membeku"
            71, 73, 75, 77 -> "salju"; 80, 81, 82 -> "hujan lokal"; 85, 86 -> "hujan salju"; 95, 96, 99 -> "badai petir"
            else -> tr("kondisi cuaca tidak diketahui", "unknown weather conditions")
        }
        if (bahasa != 1) return id
        return when (kode) {
            0 -> "clear sky"; 1 -> "mainly clear"; 2 -> "partly cloudy"; 3 -> "overcast"; 45, 48 -> "foggy"
            51, 53, 55 -> "drizzle"; 56, 57 -> "freezing drizzle"; 61, 63, 65 -> "rain"; 66, 67 -> "freezing rain"
            71, 73, 75, 77 -> "snow"; 80, 81, 82 -> "rain showers"; 85, 86 -> "snow showers"; 95, 96, 99 -> "thunderstorm"
            else -> "unknown weather conditions"
        }
    }

    /** Satu perintah spesifik menghasilkan satu jawaban saja; tidak menambahkan rangkaian tanggal/libur/sholat lain. */
    /** FIX299: label hari bergeser menurut bahasa aplikasi (0 Indonesia, 1 Inggris, 2 Arab, 3 Jawa, 4 Sunda). */
    private fun labelGeser(g: Int, bahasa: Int): String = when (bahasa) {
        1 -> if (g < 0) "Yesterday" else if (g == 1) "Tomorrow" else "The day after tomorrow"
        2 -> if (g < 0) "أمس" else if (g == 1) "غدًا" else "بعد غد"
        3 -> if (g < 0) "Wingi" else if (g == 1) "Mbenjing" else "Pasca mbenjing"
        4 -> if (g < 0) "Kamari" else if (g == 1) "Isukan" else "Pageto"
        else -> if (g < 0) "Kemarin" else if (g == 1) "Besok" else "Lusa"
    }

    private fun bacakanKhusus(geser: List<Int> = emptyList(), penyusun: (Prefs, Calendar) -> String) {
        try {
            val prefs = Prefs(applicationContext)
            val teks = if (geser.isEmpty()) penyusun(prefs, Calendar.getInstance()).trim()
                else geser.joinToString(". ") { g ->
                    val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, g) }
                    labelGeser(g, prefs.bahasaAktif) + ": " + penyusun(prefs, c).trim()
                }
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, batasBaca(teks))
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true; it.paksaBahasaTampilan = true }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    /** Waktu dibacakan suara jam; tanggal umum mengikuti pengaturan rangkaian pengguna. */
    /** [lengkap] false: hanya waktu dan/atau tanggal kalender yang diminta; true: seluruh rangkaian (termasuk libur dan salat). */
    private fun bacakan(waktu: Boolean, tanggal: Boolean, lengkap: Boolean = false) {
        try {
            val prefs = Prefs(applicationContext)
            val c = Calendar.getInstance()
            val teksWaktu = if (waktu) JamWaktu.ucapan(prefs, c) else ""
            val segmenTanggal = if (!tanggal) emptyList() else if (lengkap) JamWaktu.segmenTanggal(prefs, c) else JamWaktu.segmenKalender(prefs, c)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, batasBaca(teksWaktu + segmenTanggal.joinToString(" ")))
            fun bacaTanggal() {
                if (segmenTanggal.isEmpty()) { tutupDanLanjutAudio(); return }
                val pt = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
                pembicaraTanggal = pt
                pt.ucapkanRangkaian(segmenTanggal, 300L) { tutupDanLanjutAudio() }
            }
            if (teksWaktu.isBlank()) {
                bacaTanggal()
            } else {
                val p = Pembicara(applicationContext, prefs.suara("jam")).also { it.bisaDibungkam = true }
                pembicara = p
                p.ucapkan(teksWaktu, true) { bacaTanggal() }
            }
        } catch (_: Exception) {
            tutup()
        }
    }

    /**
     * Menjalankan kontrol perangkat yang diminta melalui panel/halaman resmi Android.
     * Jika layanan aksesibilitas aktif, layanan menekan dan memverifikasi sakelar yang
     * cocok dengan perangkat serta status yang diminta. Tanpa layanan, halaman sistem
     * tetap dibuka dan pengguna dapat mengubah sakelar secara manual.
     */
    private fun kendaliTimer(kandidat: List<String>) {
        val teks = kandidat.joinToString(" ").lowercase(java.util.Locale.ROOT)
        val p = Prefs(applicationContext)
        fun jawab(kalimat: String) {
            try {
                val suara = Pembicara(applicationContext, p.suara("jam")).also { it.bisaDibungkam = true }
                pembicaraTanggal = suara
                suara.ucapkan(kalimat, true) { tutupDanLanjutAudio() }
            } catch (_: Exception) { tutupDanLanjutAudio() }
        }
        when {
            teks.contains("jeda") || teks.contains("pause") -> {
                if (TimerJamService.status(this) == TimerJamService.STATE_RUNNING) {
                    TimerJamService.kirim(this, TimerJamService.ACTION_JEDA)
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer paused." else "Timer dijeda.")
                } else jawab(if (BahasaAplikasi.tampilan(this) == 1) "There is no running timer to pause." else "Tidak ada timer yang sedang berjalan untuk dijeda.")
            }
            teks.contains("lanjut") || teks.contains("resume") || teks.contains("continue") -> {
                if (TimerJamService.status(this) == TimerJamService.STATE_PAUSED) {
                    TimerJamService.kirim(this, TimerJamService.ACTION_LANJUT)
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer resumed." else "Timer dilanjutkan.")
                } else jawab(if (BahasaAplikasi.tampilan(this) == 1) "There is no paused timer." else "Tidak ada timer yang sedang dijeda.")
            }
            teks.contains("sisa") || teks.contains("remaining") || teks.contains("berapa") || teks.contains("how much") -> {
                if (TimerJamService.status(this) == TimerJamService.STATE_IDLE) {
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "There is no active timer." else "Tidak ada timer yang sedang aktif.")
                    return
                }
                val s = (TimerJamService.sisa(this) + 999L) / 1000L
                val h = s / 3600L; val m = s % 3600L / 60L; val d = s % 60L
                val durasi = buildList { if (h > 0) add("$h " + if (BahasaAplikasi.tampilan(this@PerintahSuaraActivity) == 1) "hours" else "jam"); if (m > 0) add("$m " + if (BahasaAplikasi.tampilan(this@PerintahSuaraActivity) == 1) "minutes" else "menit"); if (d > 0 || isEmpty()) add("$d " + if (BahasaAplikasi.tampilan(this@PerintahSuaraActivity) == 1) "seconds" else "detik") }.joinToString(" ")
                jawab(if (BahasaAplikasi.tampilan(this) == 1) "Time remaining: $durasi." else "Sisa waktu timer: $durasi.")
            }
            teks.contains("reset") || teks.contains("ulang") || teks.contains("hentikan") || teks.contains("matikan") || teks.contains("stop") -> {
                TimerJamService.kirim(this, if (TimerJamService.status(this) == TimerJamService.STATE_ALARM) TimerJamService.ACTION_STOP_ALARM else TimerJamService.ACTION_RESET)
                jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer stopped and reset." else "Timer dihentikan dan direset.")
            }
            else -> {
                val durasi = PerintahSuara.durasiTimerDetik(kandidat)
                if (durasi <= 0L) {
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Please say a duration, for example: set a timer for five minutes." else "Sebutkan durasinya, misalnya: pasang timer lima menit.")
                } else {
                    val pengaturan = getSharedPreferences("timer_jam", MODE_PRIVATE)
                    TimerJamService.kirim(this, TimerJamService.ACTION_MULAI, durasi * 1000L, pengaturan.getInt("mode", 2), pengaturan.getBoolean("pengumuman", true))
                    val jam = durasi / 3600L; val menit = durasi % 3600L / 60L; val detik = durasi % 60L
                    val inggris = BahasaAplikasi.tampilan(this) == 1
                    val lama = (if (jam > 0) "$jam " + if (inggris) "hours " else "jam " else "") +
                        (if (menit > 0) "$menit " + if (inggris) "minutes " else "menit " else "") +
                        (if (detik > 0) "$detik " + if (inggris) "seconds" else "detik" else "")
                    jawab(if (BahasaAplikasi.tampilan(this) == 1) "Timer started for $lama." else "Timer dimulai selama $lama.")
                }
            }
        }
    }

    private fun bukaPengaturanPerangkat(kontrolAwal: PerintahSuara.KontrolPerangkat?) {
        var kontrol = kontrolAwal
        // FIX213: "ubah/ganti Wi-Fi" tanpa hidup/mati: baca status sekarang lalu balikkan.
        if (kontrol != null && kontrol.alih) {
            val kini = statusPerangkatSekarang(kontrol.jenis)
            if (kini == null) {
                ucapkanLalu(tr("Status " + namaPerangkat213(kontrol.jenis) + " tidak dapat dibaca. Ucapkan aktifkan atau matikan.",
                    "I cannot read the current status of " + namaPerangkat213(kontrol.jenis) + ". Say turn on or turn off."))
                return
            }
            kontrol = kontrol.copy(aktif = !kini, alih = false)
        }
        if (kontrol != null && kontrol.jenis == PerintahSuara.JenisPerangkat.TALKBACK) { kendaliTalkBack(kontrol.aktif); return }
        if (kontrol == null) {
            Toast.makeText(this, getString(R.string.perintah_perangkat_tidak_dikenal), Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
            return
        }
        // FIX298: jalur paksa. Urutan: (1) langsung lewat izin khusus atau akses root bila ada, (2) layanan aksesibilitas yang diaktifkan
        // otomatis bila izin WRITE_SECURE_SETTINGS tersedia, lalu menggulir dan mencoba halaman pengaturan alternatif sampai sakelar ketemu.
        val tetap: PerintahSuara.KontrolPerangkat = kontrol
        Thread {
            val hasil = try { paksaLangsung(tetap) } catch (_: Throwable) { 0 }
            runOnUiThread {
                if (selesai || isFinishing) return@runOnUiThread
                val nama = namaPerangkat213(tetap.jenis)
                when (hasil) {
                    1 -> ucapkanLalu(tr(nama + (if (tetap.aktif) " dinyalakan." else " dimatikan."), nama + (if (tetap.aktif) " turned on." else " turned off.")))
                    2 -> ucapkanLalu(tr(nama + (if (tetap.aktif) " sudah menyala." else " sudah mati."), nama + (if (tetap.aktif) " is already on." else " is already off.")))
                    else -> lanjutBukaPengaturan(tetap)
                }
            }
        }.start()
    }

    /** FIX298: status sakelar yang dapat dibaca; true bila sama dengan yang diminta, menunggu sampai 3,5 detik. */
    private fun tungguStatus(j: PerintahSuara.JenisPerangkat, mau: Boolean): Boolean {
        for (i in 0 until 9) {
            val s = statusPerangkatSekarang(j)
            if (s == null) return true
            if (s == mau) return true
            SystemClock.sleep(400)
        }
        return false
    }

    private fun jalankanSu(perintah: String): Boolean = try {
        val p = ProcessBuilder("su", "-c", perintah).redirectErrorStream(true).start()
        var kode = -1
        val t = Thread { try { kode = p.waitFor() } catch (_: Exception) { } }
        t.start(); t.join(4_000L)
        if (t.isAlive) { p.destroy(); false } else kode == 0
    } catch (_: Throwable) { false }

    private fun perintahRoot(j: PerintahSuara.JenisPerangkat, mau: Boolean): String? {
        val e = if (mau) "enable" else "disable"
        return when (j) {
            PerintahSuara.JenisPerangkat.WIFI -> "svc wifi $e"
            PerintahSuara.JenisPerangkat.BLUETOOTH -> "svc bluetooth $e || cmd bluetooth_manager $e"
            PerintahSuara.JenisPerangkat.DATA_SELULER -> "svc data $e"
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> "cmd connectivity airplane-mode $e || { settings put global airplane_mode_on ${if (mau) 1 else 0}; am broadcast -a android.intent.action.AIRPLANE_MODE; }"
            PerintahSuara.JenisPerangkat.LOKASI -> "cmd location set-location-enabled ${mau} || settings put secure location_mode ${if (mau) 3 else 0}"
            PerintahSuara.JenisPerangkat.NFC -> "svc nfc $e"
            else -> null
        }
    }

    /** FIX298: 1 = diubah langsung, 2 = sudah sesuai, 0 = tidak bisa langsung (lanjut ke layar Pengaturan). Dipanggil dari thread latar. */
    private fun paksaLangsung(k: PerintahSuara.KontrolPerangkat): Int {
        val mau = k.aktif
        val andal = k.jenis == PerintahSuara.JenisPerangkat.WIFI || k.jenis == PerintahSuara.JenisPerangkat.BLUETOOTH ||
            k.jenis == PerintahSuara.JenisPerangkat.MODE_PESAWAT || k.jenis == PerintahSuara.JenisPerangkat.LOKASI
        if (andal && statusPerangkatSekarang(k.jenis) == mau) return 2
        if (k.jenis == PerintahSuara.JenisPerangkat.LOKASI && checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED) {
            try {
                @Suppress("DEPRECATION") Settings.Secure.putInt(contentResolver, Settings.Secure.LOCATION_MODE, if (mau) 3 else 0)
                if (tungguStatus(k.jenis, mau)) return 1
            } catch (_: Throwable) { }
        }
        val perintah = perintahRoot(k.jenis, mau) ?: return 0
        if (!jalankanSu(perintah)) return 0
        return if (tungguStatus(k.jenis, mau)) 1 else 0
    }

    /** FIX298: bila izin WRITE_SECURE_SETTINGS sudah diberikan lewat ADB, layanan aksesibilitas Jam Pintar Pro dinyalakan sendiri. */
    private fun aktifkanLayananAksesibilitasSendiri(): Boolean {
        if (checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val id = ComponentName(this, PanggilanWhatsAppAccessibilityService::class.java).flattenToString()
            val semua = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty().split(':').filter { it.isNotBlank() }
            if (semua.none { it.equals(id, true) || ComponentName.unflattenFromString(it.trim())?.equals(ComponentName.unflattenFromString(id)) == true }) {
                Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, (semua + id).joinToString(":"))
                Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            }
            true
        } catch (_: Throwable) { false }
    }

    private fun lanjutBukaPengaturan(kontrol: PerintahSuara.KontrolPerangkat) {
        if (!layananAksesibilitasPanggilanAktif()) aktifkanLayananAksesibilitasSendiri()
        val namaRes = when (kontrol.jenis) {
            PerintahSuara.JenisPerangkat.BLUETOOTH -> R.string.perintah_perangkat_bluetooth
            PerintahSuara.JenisPerangkat.WIFI -> R.string.perintah_perangkat_wifi
            PerintahSuara.JenisPerangkat.HOTSPOT -> R.string.perintah_perangkat_hotspot
            PerintahSuara.JenisPerangkat.DATA_SELULER -> R.string.perintah_perangkat_data
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> R.string.perintah_perangkat_pesawat
            PerintahSuara.JenisPerangkat.LOKASI -> R.string.perintah_perangkat_lokasi
            PerintahSuara.JenisPerangkat.NFC -> R.string.perintah_perangkat_nfc
            PerintahSuara.JenisPerangkat.TALKBACK -> R.string.perintah_perangkat_talkback
        }
        val aksiRes = if (kontrol.aktif) R.string.perintah_perangkat_aktifkan else R.string.perintah_perangkat_matikan
        // FIX138: semua sakelar yang didukung dioperasikan melalui layanan aksesibilitas
        // setelah pengguna mengucapkan perintah secara eksplisit. Android modern membatasi
        // perubahan langsung melalui API aplikasi biasa; gunakan panel/halaman resmi sistem.
        val dapatOtomatis = layananAksesibilitasPanggilanAktif()
        val intent = when (kontrol.jenis) {
            PerintahSuara.JenisPerangkat.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            PerintahSuara.JenisPerangkat.WIFI -> if (!dapatOtomatis && Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
            PerintahSuara.JenisPerangkat.HOTSPOT -> Intent("android.settings.TETHER_SETTINGS")
            PerintahSuara.JenisPerangkat.DATA_SELULER -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_DATA_USAGE_SETTINGS)
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            PerintahSuara.JenisPerangkat.LOKASI -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            PerintahSuara.JenisPerangkat.NFC -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_NFC) else Intent("android.settings.NFC_SETTINGS")
            PerintahSuara.JenisPerangkat.TALKBACK -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (dapatOtomatis) siapkanKontrolOtomatis(kontrol)
            startActivity(intent)
            if (dapatOtomatis) {
                Toast.makeText(this, getString(R.string.perintah_perangkat_otomatis, getString(aksiRes), getString(namaRes)), Toast.LENGTH_LONG).show()
            } else {
                var pesan = getString(R.string.perintah_perangkat_selesai, getString(aksiRes), getString(namaRes))
                pesan += " " + getString(R.string.perintah_perangkat_aksesibilitas)
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
                // FIX215: pesan Toast mudah terlewat; ucapkan juga bahwa layanan aksesibilitas belum aktif, itulah sebab sakelar tidak berubah otomatis.
                try {
                    val suara = Pembicara(applicationContext, Prefs(applicationContext).suara("jam")).also { it.bisaDibungkam = true }
                    pembicaraTanggal = suara
                    suara.ucapkan(tr("Layanan aksesibilitas Jam Pintar Pro belum aktif, jadi sakelar tidak dapat diubah otomatis. Aktifkan layanan itu di Pengaturan, Aksesibilitas, atau ubah sakelarnya sendiri di halaman ini.",
                        "The Jam Pintar Pro accessibility service is not active, so the switch cannot be changed automatically. Turn that service on in Settings, Accessibility, or change the switch yourself on this page."), true) { }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) {
            getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS_PERANGKAT, MODE_PRIVATE).edit().clear().apply()
            try {
                val cadangan = if (kontrol.jenis == PerintahSuara.JenisPerangkat.HOTSPOT) Intent(Settings.ACTION_WIRELESS_SETTINGS) else Intent(Settings.ACTION_SETTINGS)
                startActivity(cadangan.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Toast.makeText(this, getString(R.string.perintah_perangkat_pengaturan_umum), Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            }
        }
        tutupDanLanjutAudio()
    }

    /** FIX299: membuka halaman pengaturan Bluetooth, Wi-Fi, hotspot, data seluler, mode pesawat, lokasi, NFC, atau Aksesibilitas tanpa menekan sakelar. */
    private fun bukaHalamanPengaturan(jenis: PerintahSuara.JenisPerangkat?) {
        if (jenis == null) { tutupDanLanjutAudio(); return }
        val daftar: List<Intent> = when (jenis) {
            PerintahSuara.JenisPerangkat.BLUETOOTH -> listOf(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            PerintahSuara.JenisPerangkat.WIFI -> listOf(Intent(Settings.ACTION_WIFI_SETTINGS))
            PerintahSuara.JenisPerangkat.HOTSPOT -> listOf(Intent("android.settings.TETHER_SETTINGS"), Intent(Settings.ACTION_WIRELESS_SETTINGS))
            PerintahSuara.JenisPerangkat.DATA_SELULER -> listOf(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS), Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS))
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> listOf(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            PerintahSuara.JenisPerangkat.LOKASI -> listOf(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            PerintahSuara.JenisPerangkat.NFC -> listOf(Intent("android.settings.NFC_SETTINGS"), Intent(Settings.ACTION_WIRELESS_SETTINGS))
            PerintahSuara.JenisPerangkat.TALKBACK -> listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        var berhasil = false
        for (i in daftar + Intent(Settings.ACTION_SETTINGS)) {
            try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); berhasil = true; break } catch (_: Exception) { }
        }
        val nama = namaPerangkat213(jenis)
        ucapkanLalu(if (berhasil) tr("Membuka pengaturan " + nama + ".", "Opening " + nama + " settings.")
            else tr("Pengaturan " + nama + " tidak dapat dibuka.", nama + " settings could not be opened."))
    }

    private fun namaPerangkat213(j: PerintahSuara.JenisPerangkat): String = when (j) {
        PerintahSuara.JenisPerangkat.BLUETOOTH -> getString(R.string.perintah_perangkat_bluetooth)
        PerintahSuara.JenisPerangkat.WIFI -> getString(R.string.perintah_perangkat_wifi)
        PerintahSuara.JenisPerangkat.HOTSPOT -> getString(R.string.perintah_perangkat_hotspot)
        PerintahSuara.JenisPerangkat.DATA_SELULER -> getString(R.string.perintah_perangkat_data)
        PerintahSuara.JenisPerangkat.MODE_PESAWAT -> getString(R.string.perintah_perangkat_pesawat)
        PerintahSuara.JenisPerangkat.LOKASI -> getString(R.string.perintah_perangkat_lokasi)
        PerintahSuara.JenisPerangkat.NFC -> getString(R.string.perintah_perangkat_nfc)
        PerintahSuara.JenisPerangkat.TALKBACK -> getString(R.string.perintah_perangkat_talkback)
    }

    /** Ucapkan kalimat dengan suara jam (tetap terdengar walau TalkBack dimatikan), lalu tutup. */
    private fun ucapkanLalu(kalimat: String) {
        try {
            val suara = Pembicara(applicationContext, Prefs(applicationContext).suara("jam")).also { it.bisaDibungkam = true }
            pembicaraTanggal = suara
            suara.ucapkan(kalimat, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) {
            Toast.makeText(this, kalimat, Toast.LENGTH_LONG).show()
            tutupDanLanjutAudio()
        }
    }

    /** FIX213: status sakelar saat ini bila dapat dibaca tanpa izin khusus; null bila tidak dapat dibaca. */
    private fun statusPerangkatSekarang(j: PerintahSuara.JenisPerangkat): Boolean? = try {
        val cr = contentResolver
        when (j) {
            PerintahSuara.JenisPerangkat.WIFI -> Settings.Global.getInt(cr, "wifi_on", -1).let { if (it < 0) null else it != 0 }
            PerintahSuara.JenisPerangkat.BLUETOOTH -> Settings.Global.getInt(cr, "bluetooth_on", -1).let { if (it < 0) null else it != 0 }
            PerintahSuara.JenisPerangkat.MODE_PESAWAT -> Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
            PerintahSuara.JenisPerangkat.DATA_SELULER -> Settings.Global.getInt(cr, "mobile_data", -1).let { if (it < 0) null else it != 0 }
            PerintahSuara.JenisPerangkat.LOKASI ->
                if (Build.VERSION.SDK_INT >= 28) (getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled else null
            PerintahSuara.JenisPerangkat.NFC -> android.nfc.NfcAdapter.getDefaultAdapter(this)?.isEnabled
            PerintahSuara.JenisPerangkat.HOTSPOT -> {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                wm.javaClass.getMethod("isWifiApEnabled").invoke(wm) as? Boolean
            }
            PerintahSuara.JenisPerangkat.TALKBACK -> statusTalkBack()
        }
    } catch (_: Throwable) { null }

    private fun idLayananTalkBack(): String? = try {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        am.installedAccessibilityServiceList.map { it.id }.firstOrNull { it.lowercase().contains("talkback") }
    } catch (_: Throwable) { null }

    private fun statusTalkBack(): Boolean {
        val daftar = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        return Settings.Secure.getInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1 && daftar.lowercase().contains("talkback")
    }

    /**
     * FIX213: hidup/matikan TalkBack. Menulis pengaturan aksesibilitas sistem butuh izin WRITE_SECURE_SETTINGS, yang hanya dapat
     * diberikan lewat ADB: pm grant com.novan.bateraibicara android.permission.WRITE_SECURE_SETTINGS. Tanpa izin itu, halaman
     * Aksesibilitas Android dibuka (Android melarang aplikasi biasa mengubahnya sendiri).
     */
    private fun kendaliTalkBack(aktif: Boolean) {
        val nama = getString(R.string.perintah_perangkat_talkback)
        if (statusTalkBack() == aktif) {
            ucapkanLalu(tr(nama + " sudah " + (if (aktif) "aktif." else "mati."), nama + " is already " + (if (aktif) "on." else "off.")))
            return
        }
        val punyaIzin = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        val id = idLayananTalkBack()
        if (punyaIzin && id != null) {
            try {
                val semua = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                    .split(':').filter { it.isNotBlank() }
                val baru = if (aktif) (if (semua.any { it.equals(id, true) }) semua else semua + id)
                    else semua.filterNot { it.lowercase().contains("talkback") }
                Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, baru.joinToString(":"))
                Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, if (baru.isEmpty()) 0 else 1)
                ucapkanLalu(tr(nama + (if (aktif) " diaktifkan." else " dimatikan."), nama + (if (aktif) " turned on." else " turned off.")))
                return
            } catch (_: Throwable) { }
        }
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        Toast.makeText(this, tr(
            "Halaman Aksesibilitas dibuka. Android tidak mengizinkan aplikasi biasa " + (if (aktif) "menyalakan" else "mematikan") +
                " TalkBack sendiri; pilih TalkBack lalu ketuk sakelarnya. Untuk perintah suara langsung, beri izin WRITE_SECURE_SETTINGS lewat ADB.",
            "Accessibility settings opened. Android does not let ordinary apps turn TalkBack " + (if (aktif) "on" else "off") +
                " by themselves; choose TalkBack and tap its switch. For fully voice-controlled switching, grant WRITE_SECURE_SETTINGS through ADB."
        ), Toast.LENGTH_LONG).show()
        tutupDanLanjutAudio()
    }

    /**
     * FIX213: ganti mesin suara (TTS) utama yang dipakai TalkBack. Dengan izin WRITE_SECURE_SETTINGS dan nama mesin yang
     * disebut ("ke Google", "ke Samsung", "ke eSpeak"), mesin bawaan sistem diganti langsung; TalkBack mengikutinya bila
     * pilihan mesinnya "bawaan sistem". Selain itu halaman pengaturan Teks-ke-ucapan dibuka.
     */
    private fun gantiMesinSuaraTalkBack(kandidat: List<String>) {
        val noise = setOf("ganti", "gantilah", "ubah", "ubahlah", "pilih", "pilihkan", "atur", "gunakan", "pakai", "mesin", "mesinnya", "suara", "utama",
            "talkback", "talk", "back", "ke", "menjadi", "jadi", "pada", "di", "dengan", "engine", "tts", "change", "switch", "set", "choose", "select",
            "use", "to", "the", "main", "default", "voice", "preferred", "text", "speech", "teks", "ucapan", "sintesis", "synthesizer", "synth", "for", "of", "and", "dan")
        val kataDicari = kandidat.flatMap { u -> u.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(' ') }
            .filter { it.length >= 3 && it !in noise }.distinct()
        val mesin = try {
            packageManager.queryIntentServices(Intent("android.intent.action.TTS_SERVICE"), 0)
                .map { it.serviceInfo.packageName to it.loadLabel(packageManager).toString() }.distinctBy { it.first }
        } catch (_: Throwable) { emptyList() }
        val alias = mapOf("gugel" to "google", "samsung" to "samsung", "smt" to "samsung", "rhvoice" to "rhvoice", "espeak" to "espeak", "speak" to "espeak")
        val cocok = mesin.firstOrNull { (paket, label) ->
            val gabung = (paket + " " + label).lowercase()
            kataDicari.any { k -> gabung.contains(alias[k] ?: k) }
        }
        val punyaIzin = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        if (cocok != null && punyaIzin) {
            try {
                Settings.Secure.putString(contentResolver, "tts_default_synth", cocok.first)
                ucapkanLalu(tr("Mesin suara utama diganti ke " + cocok.second + ". TalkBack memakainya bila pilihan mesin TalkBack adalah bawaan sistem.",
                    "Main speech engine changed to " + cocok.second + ". TalkBack uses it when its engine choice is the system default."))
                return
            } catch (_: Throwable) { }
        }
        val intent = Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        }
        val daftar = if (mesin.isEmpty()) "" else tr(" Mesin terpasang: ", " Installed engines: ") + mesin.joinToString(", ") { it.second } + "."
        val sebab = if (cocok != null) tr(" Ganti otomatis butuh izin WRITE_SECURE_SETTINGS lewat ADB.", " Automatic switching needs the WRITE_SECURE_SETTINGS permission through ADB.")
            else if (kataDicari.isNotEmpty()) tr(" Mesin yang Anda sebut tidak ditemukan.", " The engine you named was not found.") else ""
        Toast.makeText(this, tr("Pengaturan Teks-ke-ucapan dibuka. Pilih mesin utama di sini; di pengaturan TalkBack, pilih Teks-ke-ucapan lalu mesin yang sama.",
            "Text-to-speech settings opened. Choose the main engine here; in TalkBack settings, open Text-to-speech and pick the same engine.") + sebab + daftar, Toast.LENGTH_LONG).show()
        tutupDanLanjutAudio()
    }

    /** FIX138: catat permintaan agar layanan aksesibilitas menekan sakelar perangkat yang diminta. */
    private fun siapkanKontrolOtomatis(kontrol: PerintahSuara.KontrolPerangkat) {
        getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS_PERANGKAT, MODE_PRIVATE).edit().clear()
            .putString(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_JENIS, when (kontrol.jenis) {
                PerintahSuara.JenisPerangkat.BLUETOOTH -> "bluetooth"
                PerintahSuara.JenisPerangkat.LOKASI -> "lokasi"
                PerintahSuara.JenisPerangkat.HOTSPOT -> "hotspot"
                PerintahSuara.JenisPerangkat.DATA_SELULER -> "data_seluler"
                PerintahSuara.JenisPerangkat.MODE_PESAWAT -> "pesawat"
                PerintahSuara.JenisPerangkat.NFC -> "nfc"
                PerintahSuara.JenisPerangkat.WIFI -> "wifi"
                PerintahSuara.JenisPerangkat.TALKBACK -> "talkback"
            })
            .putInt(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_TAHAP, 0)
            .putBoolean(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_AKTIF, kontrol.aktif)
            .putLong(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_DIBUAT, System.currentTimeMillis())
            .putInt(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_PERCOBAAN, 0)
            .putBoolean(PanggilanWhatsAppAccessibilityService.KEY_PERANGKAT_PENDING, true)
            .apply()
    }

    /** Membuka halaman fitur yang diminta secara langsung, tanpa menebak fitur lain. */
    private fun bukaFitur(fitur: PerintahSuara.Fitur?, kandidat: List<String> = emptyList()) {
        val tujuan = when (fitur) {
            PerintahSuara.Fitur.BATERAI -> BateraiActivity::class.java
            PerintahSuara.Fitur.JAM -> JamActivity::class.java
            PerintahSuara.Fitur.KALENDER -> KalenderActivity::class.java
            PerintahSuara.Fitur.PEMANGGIL, PerintahSuara.Fitur.PEMANGGIL_IZIN, PerintahSuara.Fitur.PEMANGGIL_JENIS, PerintahSuara.Fitur.PEMANGGIL_PESAN,
            PerintahSuara.Fitur.PEMANGGIL_MELODI, PerintahSuara.Fitur.PEMANGGIL_VOLUME, PerintahSuara.Fitur.PEMANGGIL_SUARA -> PemanggilActivity::class.java
            PerintahSuara.Fitur.SHOLAT -> PrayerActivity::class.java
            PerintahSuara.Fitur.LOKASI -> LokasiTerkiniActivity::class.java
            PerintahSuara.Fitur.PEMANDU_JALAN -> PemanduJalanActivity::class.java
            PerintahSuara.Fitur.KIBLAT -> QiblaActivity::class.java
            PerintahSuara.Fitur.KOMPAS_ARAH -> KompasActivity::class.java
            PerintahSuara.Fitur.FASILITAS -> FasilitasTerdekatActivity::class.java
            PerintahSuara.Fitur.DOA -> TaarufDoaActivity::class.java
            PerintahSuara.Fitur.KHATAM -> KhatamActivity::class.java
            PerintahSuara.Fitur.MODE_ACARA -> ModeAcaraActivity::class.java
            PerintahSuara.Fitur.BAHASA -> BahasaActivity::class.java
            PerintahSuara.Fitur.HADITS -> HaditsActivity::class.java
            PerintahSuara.Fitur.KHUTBAH -> KhutbahJumatActivity::class.java
            PerintahSuara.Fitur.MANASIK_HAJI -> ManasikHajiActivity::class.java
            PerintahSuara.Fitur.PANDUAN_IBADAH -> PanduanIbadahActivity::class.java
            PerintahSuara.Fitur.KALKULATOR_ZAKAT -> KalkulatorZakatActivity::class.java
            PerintahSuara.Fitur.DOA_HARIAN -> DoaHarianActivity::class.java
            PerintahSuara.Fitur.ASMAUL_HUSNA -> AsmaulHusnaActivity::class.java
            PerintahSuara.Fitur.PENGATURAN_SHOLAT -> PrayerSettingsActivity::class.java
            PerintahSuara.Fitur.JADWAL_BULANAN -> PrayerThirtyActivity::class.java
            PerintahSuara.Fitur.PENGHEMAT_DAYA -> PenghematDayaActivity::class.java
            PerintahSuara.Fitur.PEMICU_ASISTEN -> PemicuAsistenActivity::class.java
            PerintahSuara.Fitur.PENGATURAN_GONCANGAN -> PengaturanGoncanganActivity::class.java
            PerintahSuara.Fitur.IZIN_PERANGKAT -> IzinPerangkatActivity::class.java
            PerintahSuara.Fitur.PAKET_BAHASA -> PaketBahasaOfflineActivity::class.java
            PerintahSuara.Fitur.HUBUNGI_PENGEMBANG -> KeluhanActivity::class.java
            PerintahSuara.Fitur.BERANDA -> MainActivity::class.java
            PerintahSuara.Fitur.AKSI_PETUNJUK, PerintahSuara.Fitur.AKSI_CADANGKAN, PerintahSuara.Fitur.AKSI_PULIHKAN,
            PerintahSuara.Fitur.AKSI_RESET, PerintahSuara.Fitur.AKSI_INFO_APP, PerintahSuara.Fitur.AKSI_PERIKSA_UPDATE -> MainActivity::class.java
            null -> null
        }
        if (tujuan == null) {
            val bahasa = Prefs(applicationContext).bahasaAktif
            val pesan = when (bahasa) {
                1 -> "I couldn't identify which app feature you meant. Please say the feature name."
                2 -> "لم أتمكن من تحديد الميزة المطلوبة. يرجى ذكر اسم الميزة."
                3 -> "Fitur ingkang dipun kersakaken dereng saged dipun mangertosi. Sebutaken nami fituripun."
                4 -> "Fitur anu dimaksud teu kahartos. Sebutkeun nami fiturna."
                else -> getString(R.string.perintah_fitur_tidak_dikenal)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            tutup()
            return
        }
        try {
            val buka = Intent(this, tujuan)
            // FIX226: "doa sebelum makan" langsung membuka doa yang dimaksud; "doa harian" membuka beranda doa.
            // FIX308: kelompok pengaturan Nama Panggilan dan Pembacaan Notifikasi dibuka langsung.
            when (fitur) {
                PerintahSuara.Fitur.PEMANGGIL_IZIN -> buka.putExtra("kelompok", "izin")
                PerintahSuara.Fitur.PEMANGGIL_JENIS -> buka.putExtra("kelompok", "jenis")
                PerintahSuara.Fitur.PEMANGGIL_PESAN -> buka.putExtra("kelompok", "pesan")
                PerintahSuara.Fitur.PEMANGGIL_MELODI -> buka.putExtra("kelompok", "melodi")
                PerintahSuara.Fitur.PEMANGGIL_VOLUME -> buka.putExtra("kelompok", "volume")
                PerintahSuara.Fitur.PEMANGGIL_SUARA -> buka.putExtra("kelompok", "suara")
                else -> { }
            }
            if (fitur == PerintahSuara.Fitur.ASMAUL_HUSNA) {
                val nomor = kandidat.map { AsmaulHusnaData.cari(it) }.firstOrNull { it >= 0 } ?: -1
                if (nomor >= 0) buka.putExtra("nomor", nomor)
            }
            if (fitur == PerintahSuara.Fitur.DOA_HARIAN) {
                val nomor = DoaHarianData.cari(kandidat)
                if (nomor >= 0) buka.putExtra("doa", nomor)
            }
            // FIX250: aksi menu beranda dijalankan MainActivity lewat extra aksi_suara.
            val aksiBeranda = when (fitur) {
                PerintahSuara.Fitur.AKSI_PETUNJUK -> "petunjuk"
                PerintahSuara.Fitur.AKSI_CADANGKAN -> "cadangkan"
                PerintahSuara.Fitur.AKSI_PULIHKAN -> "pulihkan"
                PerintahSuara.Fitur.AKSI_RESET -> "reset"
                PerintahSuara.Fitur.AKSI_INFO_APP -> "info_app"
                PerintahSuara.Fitur.AKSI_PERIKSA_UPDATE -> "periksa_update"
                else -> null
            }
            if (aksiBeranda != null) buka.putExtra("aksi_suara", aksiBeranda).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (fitur == PerintahSuara.Fitur.BERANDA) buka.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(buka)
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }


    /**
     * Menafsirkan tujuan dan kanal panggilan dari perintah yang diucapkan.
     * Telepon seluler dapat langsung dimulai setelah izin CALL_PHONE diberikan;
     * WhatsApp diarahkan ke chat kontak karena WhatsApp tidak menyediakan API publik
     * untuk memulai panggilan suara/video dari aplikasi pihak ketiga.
     */
    private fun panggilKontak(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty()
        aturSaluranPanggilan(ucapan)
        aturJenisPanggilanWhatsApp(ucapan)
        val tujuan = ekstrakTujuanPanggilan(ucapan)
        if (tujuan.isBlank()) {
            menungguNamaKontak = true
            Toast.makeText(this, petunjukNamaKontak(), Toast.LENGTH_LONG).show()
            handler.postDelayed({
                if (!isFinishing && !selesai && menungguNamaKontak) bukaPengenalan(false, petunjukNamaKontak())
            }, 350L)
            return
        }
        prosesTujuanPanggilan(listOf(tujuan))
    }

    private fun aturSaluranPanggilan(ucapan: String) {
        val t = ucapan.lowercase()
        saluranPanggilan = when {
            t.contains("whatsapp business") || t.contains("wa bisnis") || t.contains("whatsapp bisnis") -> SaluranPanggilan.WHATSAPP_BUSINESS
            t.contains("whatsapp") || Regex("\\bwa\\b").containsMatchIn(t) -> SaluranPanggilan.WHATSAPP
            t.contains("telegram") -> SaluranPanggilan.TELEGRAM
            else -> saluranPanggilan
        }
    }

    private fun aturJenisPanggilanWhatsApp(ucapan: String) {
        val t = ucapan.lowercase()
        jenisPanggilanWhatsApp = when {
            listOf("video", "vidio", "video call", "panggilan video").any { t.contains(it) } -> "video"
            listOf("suara", "voice", "audio", "panggilan suara").any { t.contains(it) } -> "voice"
            else -> jenisPanggilanWhatsApp
        }
    }

    private fun petunjukJenisPanggilanWhatsApp(): String = when (Prefs(applicationContext).bahasaAktif) {
        1 -> "Say 'voice call' or 'video call'."
        2 -> "قل: مكالمة صوتية أو مكالمة فيديو."
        3 -> "Sebutna 'telpon swara' utawa 'telpon video'."
        4 -> "Ucapkeun 'telepon sora' atanapi 'telepon vidéo'."
        else -> getString(R.string.perintah_panggilan_jenis)
    }

    private fun petunjukNamaKontak(): String = when (Prefs(applicationContext).bahasaAktif) {
        1 -> "Say the contact name or phone number."
        2 -> "اذكر اسم جهة الاتصال أو رقم الهاتف."
        3 -> "Sebutna asma kontak utawa nomer telpon."
        4 -> "Sebutkeun nami kontak atanapi nomer telepon."
        else -> getString(R.string.perintah_panggilan_kontak)
    }

    private fun ekstrakTujuanPanggilan(ucapan: String): String {
        return ucapan.trim().replace(
            Regex("(?i)\\b(tolong|silakan|please|call|telepon|telpon|panggil|hubungi|kontak|nomor|nomer|saya|aku|ke|untuk|via|melalui|lewat|whatsapp|telegram|business|bisnis|wa|suara|video|vidio|voice|audio)\\b"),
            " "
        ).replace(Regex("\\s+"), " ").trim()
    }

    private data class TujuanKontak(val nama: String, val nomor: String)

    private fun cariPilihanKontak(kataKunci: String): List<TujuanKontak> {
        val hasil = mutableListOf<TujuanKontak>()
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val proyeksi = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        try {
            contentResolver.query(uri, proyeksi, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
                val idxNama = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val idxNomor = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext() && hasil.size < 30) {
                    val nama = if (idxNama >= 0) c.getString(idxNama).orEmpty() else ""
                    val nomor = if (idxNomor >= 0) c.getString(idxNomor).orEmpty() else ""
                    if (nama.contains(kataKunci, ignoreCase = true) && nomor.isNotBlank() && hasil.none { it.nomor == nomor }) hasil += TujuanKontak(nama, nomor)
                }
            }
        } catch (_: SecurityException) { }
        return hasil
    }

    private fun tampilkanPilihanKontak(pilihan: List<TujuanKontak>) {
        val label = pilihan.map { it.nama + ", " + it.nomor }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.perintah_panggilan_pilih_kontak))
            .setItems(label) { _, which -> if (which in pilihan.indices) jalankanSaluranPanggilan(pilihan[which].nomor) }
            .setOnCancelListener { tutup() }
            .show()
    }

    private fun prosesTujuanPanggilan(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty()
        aturSaluranPanggilan(ucapan)
        aturJenisPanggilanWhatsApp(ucapan)
        val tujuan = ekstrakTujuanPanggilan(ucapan)
        val nomorLangsung = tujuan.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
        if (nomorLangsung.count { it.isDigit() } >= 3) {
            jalankanSaluranPanggilan(nomorLangsung)
            return
        }
        if (tujuan.isBlank()) {
            Toast.makeText(this, petunjukNamaKontak(), Toast.LENGTH_LONG).show()
            tutup()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            ucapanKontakTertunda = tujuan
            requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), PERMINTAAN_KONTAK)
            return
        }
        val cocok = cariPilihanKontak(tujuan)
        when (cocok.size) {
            0 -> {
                val pesan = when (Prefs(applicationContext).bahasaAktif) {
                    1 -> "Contact not found. Check the name or say the phone number."
                    2 -> "لم يتم العثور على جهة الاتصال. تحقق من الاسم أو اذكر رقم الهاتف."
                    3 -> "Kontak ora ditemokake. Priksa jeneng utawa sebutna nomer telpon."
                    4 -> "Kontak teu kapendak. Pariksa nami atanapi sebutkeun nomor telepon."
                    else -> getString(R.string.perintah_panggilan_kontak_tidak_ditemukan)
                }
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
                tutup()
            }
            1 -> jalankanSaluranPanggilan(cocok.first().nomor)
            else -> tampilkanPilihanKontak(cocok)
        }
    }

    /** FIX316: membuka obrolan WhatsApp/WhatsApp Business/Telegram dengan nomor tujuan (aplikasi-aplikasi itu tidak mengizinkan panggilan dimulai dari luar). */
    private fun bukaObrolanAplikasi(nomor: String) {
        var digit = nomor.filter { it.isDigit() }
        if (digit.startsWith("0")) digit = "62" + digit.drop(1) else if (digit.startsWith("8")) digit = "62" + digit
        val telegram = saluranPanggilan == SaluranPanggilan.TELEGRAM
        aksiObrolanGanda = false
        if (digit.isBlank()) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show(); tutup(); return }
        try {
            val uri = if (telegram) Uri.parse("tg://resolve?phone=" + digit) else Uri.parse("https://wa.me/" + digit)
            val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            when (saluranPanggilan) {
                SaluranPanggilan.WHATSAPP_BUSINESS -> i.setPackage("com.whatsapp.w4b")
                SaluranPanggilan.WHATSAPP -> i.setPackage("com.whatsapp")
                else -> { }
            }
            startActivity(i)
            Toast.makeText(this, if (telegram) tr("Obrolan Telegram dibuka. Telegram tidak mengizinkan panggilan dimulai dari aplikasi lain; ketuk ikon telepon di obrolan.", "The Telegram chat is open. Telegram does not allow calls to be started from another app; tap the phone icon in the chat.")
                else tr("Obrolan dibuka.", "The chat is open."), Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, tr("Aplikasi tujuan tidak ditemukan atau tidak dapat membuka obrolan.", "The target app was not found or could not open the chat."), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    /**
     * FIX316: perintah ganda "buka WhatsApp dan hubungi Budi", "buka WA Business lalu kirim pesan ke Ani", "buka Telegram dan chat Dewi".
     * Klausa pertama menentukan aplikasi (kanal), klausa kedua menentukan tindakan dan tujuan. Mengembalikan true bila dikenali dan dijalankan.
     */
    private fun perintahGanda(kandidat: List<String>): Boolean {
        val u = kandidat.maxByOrNull { it.length }.orEmpty().lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
        val m = Regex("^(?:tolong |silakan |please )?(?:buka|bukakan|jalankan|open|launch|start)(?: aplikasi| app)? (.+?) (?:dan|lalu|kemudian|terus|lantas|then|and then|and) (?:tolong |silakan |please )?((?:hubungi|telepon|telpon|panggil|call|video call|vidio call|chat|kirim|kirimkan|ketik|pesan|message|text).*)$").find(u) ?: return false
        val app = m.groupValues[1]
        val sisa = m.groupValues[2]
        val saluran = when {
            app.contains("business") || app.contains("bisnis") || app.contains("w4b") -> SaluranPanggilan.WHATSAPP_BUSINESS
            app.contains("whatsapp") || Regex("\\bwa\\b").containsMatchIn(app) -> SaluranPanggilan.WHATSAPP
            app.contains("telegram") -> SaluranPanggilan.TELEGRAM
            else -> return false
        }
        val kataChat = Regex("\\b(chat|pesan|message|text|kirim|kirimkan|ketik)\\b").containsMatchIn(sisa)
        val kataTelepon = Regex("\\b(hubungi|telepon|telpon|panggil|call|video|vidio)\\b").containsMatchIn(sisa)
        val obrolan = saluran == SaluranPanggilan.TELEGRAM || (kataChat && !kataTelepon)
        val tujuan = sisa.replace(Regex("\\b(hubungi|telepon|telpon|panggil|call|chat|kirim|kirimkan|pesan|message|text|ketik|ke|kepada|untuk|dengan|via|melalui|lewat|di|tolong|video|vidio|suara|voice|audio|whatsapp|business|bisnis|wa|telegram|panggilan|siapa)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        val kataSaluran = when (saluran) { SaluranPanggilan.WHATSAPP_BUSINESS -> "whatsapp business"; SaluranPanggilan.TELEGRAM -> "telegram"; else -> "whatsapp" }
        val jenisKata = when { Regex("\\b(video|vidio)\\b").containsMatchIn(sisa) -> "video"; Regex("\\b(suara|voice|audio)\\b").containsMatchIn(sisa) -> "suara"; else -> "" }
        aksiObrolanGanda = obrolan
        jenisPanggilanWhatsApp = null
        saluranPanggilan = saluran
        denganBukaKunci { panggilKontak(listOf("hubungi " + tujuan + " " + jenisKata + " " + kataSaluran)) }
        return true
    }

    private fun jalankanSaluranPanggilan(nomor: String) {
        if (aksiObrolanGanda || saluranPanggilan == SaluranPanggilan.TELEGRAM) { bukaObrolanAplikasi(nomor); return }
        when (saluranPanggilan) {
            SaluranPanggilan.TELEGRAM -> bukaObrolanAplikasi(nomor)
            SaluranPanggilan.SELULER -> mulaiPanggilanSeluler(nomor)
            SaluranPanggilan.WHATSAPP, SaluranPanggilan.WHATSAPP_BUSINESS -> {
                if (jenisPanggilanWhatsApp.isNullOrBlank()) {
                    nomorPanggilanTertunda = nomor
                    menungguJenisPanggilanWhatsApp = true
                    Toast.makeText(this, petunjukJenisPanggilanWhatsApp(), Toast.LENGTH_LONG).show()
                    bukaPengenalan(false, petunjukJenisPanggilanWhatsApp())
                } else {
                    val paket = if (saluranPanggilan == SaluranPanggilan.WHATSAPP_BUSINESS) "com.whatsapp.w4b" else "com.whatsapp"
                    bukaChatWhatsApp(nomor, paket, jenisPanggilanWhatsApp!!)
                }
            }
        }
    }

    private fun layananAksesibilitasPanggilanAktif(): Boolean {
        // FIX214: Android menyimpan daftar layanan dalam bentuk pendek ("paket/.NamaKelas") di banyak ponsel, sedangkan kode lama hanya
        // membandingkan bentuk panjang. Akibatnya layanan yang sebenarnya aktif dianggap mati, sakelar tidak pernah ditekan otomatis,
        // dan hanya halaman Pengaturan yang terbuka. Kini komponen dibandingkan setelah diurai, dan daftar layanan resmi
        // AccessibilityManager dipakai sebagai pemeriksa kedua.
        val komponen = ComponentName(this, PanggilanWhatsAppAccessibilityService::class.java)
        val aktif = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val dariPengaturan = aktif.split(':').any { entri ->
            entri.isNotBlank() && (ComponentName.unflattenFromString(entri.trim())?.equals(komponen) == true ||
                entri.trim().equals(komponen.flattenToString(), true) || entri.trim().equals(komponen.flattenToShortString(), true))
        }
        if (dariPengaturan) return true
        return try {
            val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
            am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
                it.resolveInfo?.serviceInfo?.let { si -> si.packageName == packageName && si.name == komponen.className } == true
            }
        } catch (_: Throwable) { false }
    }

    private fun bukaChatWhatsApp(nomor: String, paket: String, jenis: String) {
        if (!layananAksesibilitasPanggilanAktif()) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Enable Jam Pintar Pro call assistance in Android Accessibility settings, then repeat the voice command. This is needed to operate WhatsApp's call controls."
                2 -> "فعّل خدمة مساعدة المكالمات في إعدادات إمكانية الوصول بنظام Android، ثم أعد الأمر الصوتي."
                3 -> "Aktifna layanan pitulungan panggilan Jam Pintar Pro ing setelan Aksesibilitas Android, banjur baleni printah swara."
                4 -> "Aktipkeun jasa bantuan telepon Jam Pintar Pro dina setélan Aksesibilitas Android, teras ucapkeun deui paréntahna."
                else -> getString(R.string.perintah_panggilan_aksesibilitas)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) { }
            tutup()
            return
        }
        var digit = nomor.filter { it.isDigit() }
        if (digit.startsWith("0")) digit = "62" + digit.drop(1)
        else if (digit.startsWith("8")) digit = "62" + digit
        if (digit.isBlank()) {
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
            tutup(); return
        }
        try {
            // Intent eksplisit dibatasi pada aplikasi yang diminta. Layanan aksesibilitas hanya
            // bertindak setelah pengguna menyebutkan jenis panggilan (suara/video).
            getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS, MODE_PRIVATE).edit()
                .putString(PanggilanWhatsAppAccessibilityService.KEY_PACKAGE, paket)
                .putString(PanggilanWhatsAppAccessibilityService.KEY_TYPE, jenis)
                .putLong(PanggilanWhatsAppAccessibilityService.KEY_CREATED, System.currentTimeMillis())
                .putInt(PanggilanWhatsAppAccessibilityService.KEY_STAGE, 0)
                .putBoolean(PanggilanWhatsAppAccessibilityService.KEY_PENDING, true)
                .apply()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digit)).setPackage(paket)
            startActivity(intent)
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Opening the selected WhatsApp chat. Call assistance will select the requested " + jenis + " call if WhatsApp exposes the matching control."
                2 -> "يتم فتح محادثة واتساب المحددة وتنفيذ نوع الاتصال المطلوب إذا أتاح واتساب زر التحكم المطابق."
                3 -> "Chat WhatsApp ingkang dipilih dipunbikak. Bantuan panggilan badhe milih jinis telpon menawi tombolipun kasedhiya."
                4 -> "Obrolan WhatsApp anu dipilih nuju dibuka. Bantuan telepon bakal milih jinis telepon upami tombolna sayogi."
                else -> getString(R.string.perintah_panggilan_whatsapp_dibuka, jenis)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            getSharedPreferences(PanggilanWhatsAppAccessibilityService.PREFS, MODE_PRIVATE).edit().clear().apply()
            Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    private fun mulaiPanggilanSeluler(nomor: String) {
        nomorPanggilanTertunda = nomor
        if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.CALL_PHONE), PERMINTAAN_PANGGILAN)
            return
        }
        lakukanPanggilanSeluler(nomor)
    }

    private fun lakukanPanggilanSeluler(nomor: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", nomor, null))
            startActivity(intent)
        } catch (_: SecurityException) {
            // Jika izin ditolak/dicabut oleh sistem, jangan gagal total: tampilkan dialer biasa.
            try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) } catch (_: Exception) { }
        } catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) } catch (_: Exception) { }
        }
        tutup()
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the project's minSdk")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMINTAAN_PANGGILAN) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                lakukanPanggilanSeluler(nomorPanggilanTertunda)
            } else {
                val nomor = nomorPanggilanTertunda
                try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", nomor, null))) } catch (_: Exception) { }
                tutup()
            }
            return
        }
        if (requestCode != PERMINTAAN_KONTAK) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prosesTujuanPanggilan(listOf(ucapanKontakTertunda))
        } else {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Contact access is needed to find a person by name. You can say the phone number instead."
                2 -> "يلزم إذن جهات الاتصال للبحث بالاسم. يمكنك ذكر رقم الهاتف بدلاً من ذلك."
                3 -> "Idin kontak dibutuhake kanggo nggoleki jeneng. Sampeyan bisa nyebutake nomer telpon."
                4 -> "Idin kontak diperlukeun pikeun milarian nami. Anjeun tiasa nyebatkeun nomer telepon."
                else -> getString(R.string.perintah_kontak_izin)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            tutup()
        }
    }


    /** Membacakan pesan masuk terakhir yang tersimpan dari notifikasi, bukan mengakses chat privat secara diam-diam. */
    private fun bacaPesanTersimpan(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        val isi = if (nama.isNotBlank()) RiwayatPesanSuara.cari(this, nama) else RiwayatPesanSuara.terbaru(this)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> "No recent incoming message is available in the notification history."
            2 -> "لا توجد رسالة واردة حديثة في سجل الإشعارات."
            3 -> "Pesen mlebet enggal dereng wonten ing riwayat notifikasi."
            4 -> "Teu aya talatah asup panganyarna dina riwayat béwara."
            else -> getString(R.string.perintah_pesan_tidak_ada)
        }
        bacakanTeksLokal(teks)
    }

    private fun cariPesanKontak(kandidat: List<String>) {
        val nama = PerintahSuara.namaKontakPesan(kandidat)
        if (nama.isBlank()) { bukaPesan(kandidat, baca = false); return }
        val isi = RiwayatPesanSuara.cari(this, nama)
        val bahasa = Prefs(applicationContext).bahasaAktif
        val teks = isi ?: when (bahasa) {
            1 -> ("No recent incoming message from " + (nama) + " was found in notification history.")
            2 -> ("لم يتم العثور على رسالة واردة حديثة من " + (nama) + " في سجل الإشعارات.")
            3 -> ("Pesen mlebet enggal saking " + (nama) + " boten kapanggih ing riwayat notifikasi.")
            4 -> ("Teu kapanggih talatah asup panganyarna ti " + (nama) + " dina riwayat béwara.")
            else -> getString(R.string.perintah_pesan_kontak_tidak_ada, nama)
        }
        bacakanTeksLokal(teks)
    }

    private fun bacakanTeksLokal(teks: String) {
        try {
            val prefs = Prefs(applicationContext)
            handler.removeCallbacks(batasWaktu)
            handler.postDelayed(batasWaktu, batasBaca(teks))
            val suara = Pembicara(applicationContext, prefs.suara("tgl")).also { it.bisaDibungkam = true }
            pembicaraTanggal = suara
            suara.ucapkan(teks, true) { tutupDanLanjutAudio() }
        } catch (_: Exception) { tutup() }
    }

    /** Membuka aplikasi pesan. Pembacaan otomatis tetap mengikuti izin Notification Listener. */
    private fun bukaPesan(kandidat: List<String>, baca: Boolean) {
        val ucapan = kandidat.joinToString(" ").lowercase()
        try {
            val paket = when {
                ucapan.contains("whatsapp business") -> "com.whatsapp.w4b"
                ucapan.contains("whatsapp") || ucapan.contains("wa ") -> "com.whatsapp"
                else -> null
            }
            val intent = if (paket != null) packageManager.getLaunchIntentForPackage(paket)
                else Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            if (intent != null) startActivity(intent) else startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        if (baca) {
            val pesan = when (Prefs(applicationContext).bahasaAktif) {
                1 -> "Opened your messaging app. Incoming messages can be read aloud when notification access and message announcements are enabled."
                2 -> "تم فتح تطبيق الرسائل. يمكن قراءة الرسائل الواردة عند تفعيل الوصول إلى الإشعارات وإعلان الرسائل."
                3 -> "Aplikasi pesen sampun kabikak. Pesen mlebet saged dipunwaos nalika akses notifikasi lan pawartos pesen sampun aktif."
                4 -> "Aplikasi pesen parantos dibuka. Talatah asup tiasa dibacakeun upami aksés béwara sareng fitur maca talatah diaktipkeun."
                else -> getString(R.string.perintah_pesan_aplikasi_dibuka)
            }
            Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
        }
        tutup()
    }

    /** Mencocokkan nama aplikasi dengan label launcher yang terpasang. */
    private fun bukaAplikasiDisebut(kandidat: List<String>) {
        val ucapan = kandidat.maxByOrNull { it.length }.orEmpty().lowercase()
            .replace(Regex("(?i)\\b(buka|bukakan|jalankan|open|launch|aplikasi|app|tolong|please)\\b"), " ").trim()
        if (ucapan.isBlank()) { tutup(); return }
        try {
            val daftar = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val cocok = daftar.firstOrNull { it.loadLabel(packageManager).toString().equals(ucapan, true) }
                ?: daftar.firstOrNull { it.loadLabel(packageManager).toString().contains(ucapan, true) }
            val launch = cocok?.let { packageManager.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (launch != null) startActivity(launch) else {
                val pesan = when (Prefs(applicationContext).bahasaAktif) {
                    1 -> "App not found. Say its name as shown on the home screen."
                    2 -> "لم يتم العثور على التطبيق. قل اسمه كما يظهر على الشاشة الرئيسية."
                    3 -> "Aplikasi boten kapanggih. Sebataken nami kados ingkang katingal ing layar utama."
                    4 -> "Aplikasi teu kapanggih. Sebutkeun nami sapertos dina layar utama."
                    else -> getString(R.string.perintah_aplikasi_tidak_ditemukan)
                }
                Toast.makeText(this, pesan, Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun putarQuranLatarBelakang(kandidat: List<String>) {
        try { PemutarQuranService.kirim(this, PemutarQuranService.ACTION_PUTAR, kandidat) }
        catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        tutup()
    }

    private fun kendaliQuran(aksi: String) {
        // FIX119: audio dari perintah putar bisa berada di pemutar Khatam ATAU di layanan latar belakang. Sebelumnya perintah
        // berhenti/jeda/lanjut hanya dikirim ke layanan, sehingga audio Khatam tetap berbunyi walau ada jawaban "dihentikan".
        val kendaliKhatam = when (aksi) {
            PemutarQuranService.ACTION_BERHENTI -> KhatamActivity.KENDALI_BERHENTI
            PemutarQuranService.ACTION_JEDA -> KhatamActivity.KENDALI_JEDA
            PemutarQuranService.ACTION_LANJUT -> KhatamActivity.KENDALI_LANJUT
            else -> null
        }
        val ditanganiKhatam = kendaliKhatam != null && KhatamActivity.kendaliLatar(kendaliKhatam)
        // Berhenti selalu juga dikirim ke layanan agar pemutar mana pun yang aktif berhenti.
        // Jeda/lanjut hanya diteruskan ke layanan bila Khatam tidak memegang audionya.
        if (aksi == PemutarQuranService.ACTION_BERHENTI || !ditanganiKhatam) {
            try { PemutarQuranService.kirim(this, aksi) }
            catch (_: Exception) { Toast.makeText(this, getString(R.string.perintah_suara_tidak_tersedia), Toast.LENGTH_LONG).show() }
        }
        tutup()
    }

    private fun getar(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (v?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            }
        } catch (_: Exception) { }
    }

    private fun hentikanSuara() {
        handler.removeCallbacks(batasWaktu)
        try { pembicara?.matikan() } catch (_: Exception) { }
        try { pembicaraTanggal?.matikan() } catch (_: Exception) { }
        pembicara = null
        pembicaraTanggal = null
    }

    private fun tutup() {
        if (selesai) return
        selesai = true
        menungguPengenalan = false
        // Tutup layar pengenal sistem bila masih terbuka di atas layar ini.
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        finish()
    }

    /** Perintah hanya memberi informasi atau tidak dipahami: audio Khatam yang kita jeda untuk mikrofon dilanjutkan. */
    private fun tutupDanLanjutAudio() {
        KhatamActivity.lanjutkanSetelahMikrofon()
        tutup()
    }

    /** Dipanggil instance baru: lepaskan mikrofon, pengenal, dan fokus milik instance lama tanpa memicu pelanjutan audio. */
    private fun tutupPaksa() {
        selesai = true
        menungguPengenalan = false
        handler.removeCallbacksAndMessages(null)
        try { finishActivity(kodePengenalan()) } catch (_: Exception) { }
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        finish()
    }

    private fun hentikanUjaranTalkBack() {
        try { (getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager).interrupt() } catch (_: Exception) { }
    }

    private fun ambilFokusMikrofon() {
        if (fokusMikDiminta) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) {
                val atribut = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(atribut)
                    .setOnAudioFocusChangeListener({ }, handler)
                    .setWillPauseWhenDucked(true)
                    .setAcceptsDelayedFocusGain(false)
                    .build()
                permintaanFokusMik = req
                fokusMikDiminta = am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                fokusMikDiminta = am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
        } catch (_: Exception) { fokusMikDiminta = false }
    }

    private fun lepasFokusMikrofon() {
        if (!fokusMikDiminta) return
        fokusMikDiminta = false
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) permintaanFokusMik?.let { am.abandonAudioFocusRequest(it) }
            else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) { }
        permintaanFokusMik = null
    }

    override fun onDestroy() {
        if (aktif === this) aktif = null
        selesai = true
        menungguPengenalan = false
        handler.removeCallbacksAndMessages(null)
        // Lepaskan semua resource sesi pada setiap jalur penghancuran Activity.
        lepasPengenal()
        lepasFokusMikrofon()
        hentikanSuara()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PEMICU_GONCANGAN = "pemicu_dari_goncangan"
        const val EXTRA_PEMICU_MANUAL = "pemicu_manual_widget"
        private const val KODE_PENGENALAN = 6911
        private const val PERMINTAAN_KONTAK = 6912
        private const val PERMINTAAN_PANGGILAN = 6913
        @Volatile
        private var aktif: PerintahSuaraActivity? = null
        /** FIX87: diisi true oleh pemanggil di dalam aplikasi agar pengguna tidak dikirim ke layar depan. */
        const val EXTRA_DARI_APLIKASI = "perintah_suara_dari_aplikasi"
        const val EXTRA_UJI_PAKET_OFFLINE = "perintah_suara_uji_paket_offline"
    }
}

/** Penafsir perintah suara: menilai SEMUA alternatif pengenalan, lalu memilih maksud paling spesifik. */
object PerintahSuara {
    enum class Jenis { TIMER, BATERAI_INFO, CUACA, WAKTU, TANGGAL, WAKTU_TANGGAL, SEMUA, PASARAN, TANGGAL_MASEHI, TANGGAL_HIJRIAH, LIBUR, LIBUR_SPESIFIK, SHOLAT_BERIKUTNYA, CARI_PESAN, QURAN, BERHENTI_AUDIO, JEDA_AUDIO, LANJUT_AUDIO, KONTROL_PERANGKAT, BUKA_FITUR, PANGGIL, PESAN, BACA_PESAN, BUKA_APLIKASI, MESIN_SUARA_TALKBACK, BMKG, MODE_ACARA_KONTROL, LOKASI_SEBUT, LOKASI_PERBARUI, SAKELAR_FITUR, INFO_PERANGKAT, BUKA_PENGATURAN_PERANGKAT, TIDAK_DIKENAL }
    enum class JenisPerangkat { BLUETOOTH, WIFI, HOTSPOT, DATA_SELULER, MODE_PESAWAT, LOKASI, NFC, TALKBACK }
    /** alih = true bila pengguna berkata "ubah/ganti/alihkan" tanpa menyebut hidup atau mati: status dibalik dari keadaan sekarang. */
    data class KontrolPerangkat(val jenis: JenisPerangkat, val aktif: Boolean, val alih: Boolean = false)
    enum class Fitur { BATERAI, JAM, KALENDER, PEMANGGIL, SHOLAT, LOKASI, PEMANDU_JALAN, KIBLAT, FASILITAS, DOA, KHATAM, MODE_ACARA, BAHASA, HADITS, KHUTBAH, MANASIK_HAJI, PANDUAN_IBADAH, KOMPAS_ARAH, KALKULATOR_ZAKAT, DOA_HARIAN, ASMAUL_HUSNA,
        PENGATURAN_SHOLAT, JADWAL_BULANAN, PENGHEMAT_DAYA, PEMICU_ASISTEN, PENGATURAN_GONCANGAN, IZIN_PERANGKAT, PAKET_BAHASA, HUBUNGI_PENGEMBANG,
        AKSI_PETUNJUK, AKSI_CADANGKAN, AKSI_PULIHKAN, AKSI_RESET, AKSI_INFO_APP, AKSI_PERIKSA_UPDATE, BERANDA,
        PEMANGGIL_IZIN, PEMANGGIL_JENIS, PEMANGGIL_PESAN, PEMANGGIL_MELODI, PEMANGGIL_VOLUME, PEMANGGIL_SUARA }

    private val kataWaktu = setOf("waktu", "jam", "pukul", "time", "clock", "jamnya")
    private val kataTanggal = setOf("tanggal", "hari", "tgl", "date", "today", "day", "kalender", "calendar", "pasaran")
    private val kataSemua = setOf("semua", "lengkap", "semuanya", "everything", "all", "both")
    private val kataKerjaInfo = setOf("informasikan", "informasi", "info", "beritahu", "beritahukan", "sebutkan", "katakan", "bacakan", "baca", "tolong", "tell", "say", "give", "what", "whats", "read", "announce", "saya", "me")
    private val kataQuran = setOf("surah", "surat", "sura", "ayat", "ayah", "aya", "verse", "juz", "jus", "juzz", "murattal", "mushaf", "alquran", "quran", "quranul")
    private val kataQariPasti = setOf("qari", "qori", "qaari", "qory", "reciter", "reciters")
    private val kataQariMirip = setOf("kari", "kori")
    private val kataKerjaQari = setOf("pilih", "pilihkan", "ganti", "gantilah", "ubah", "gunakan", "pakai", "pakailah", "atur", "set", "choose", "select", "switch", "change", "use")
    private val kataKerjaBuka = setOf("buka", "bukakan", "tampilkan", "tunjukkan", "lihat", "masuk", "jalankan", "open", "launch", "show", "display", "go", "navigate", "akses")

    fun tafsir(kandidat: List<String>): Jenis {
        // Alternatif pertama dari mesin ASR sering terlalu umum. Prioritas numerik memastikan
        // tanggal Hijriah/shalat/libur dan aksi fitur selalu menang dari kata "tanggal" atau "waktu" umum.
        return kandidat.mapNotNull { tafsirSatu(it) }
            .maxByOrNull { prioritas(it) } ?: Jenis.TIDAK_DIKENAL
    }

    private fun prioritas(j: Jenis): Int = when (j) {
        Jenis.TANGGAL_HIJRIAH, Jenis.TANGGAL_MASEHI, Jenis.PASARAN, Jenis.SHOLAT_BERIKUTNYA, Jenis.LIBUR, Jenis.LIBUR_SPESIFIK, Jenis.PANGGIL, Jenis.PESAN, Jenis.BACA_PESAN, Jenis.CARI_PESAN -> 110
        Jenis.BERHENTI_AUDIO, Jenis.JEDA_AUDIO, Jenis.LANJUT_AUDIO, Jenis.KONTROL_PERANGKAT, Jenis.BUKA_PENGATURAN_PERANGKAT, Jenis.MESIN_SUARA_TALKBACK, Jenis.BMKG, Jenis.TIMER -> 130
        Jenis.QURAN, Jenis.MODE_ACARA_KONTROL, Jenis.LOKASI_SEBUT, Jenis.LOKASI_PERBARUI, Jenis.SAKELAR_FITUR, Jenis.INFO_PERANGKAT -> 95
        Jenis.BUKA_FITUR -> 90
        Jenis.WAKTU_TANGGAL, Jenis.SEMUA -> 40
        Jenis.WAKTU, Jenis.TANGGAL -> 30
        else -> 0
    }

    private fun token(ucapan: String): List<String> = ucapan.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private val kataAlih = setOf("ubah", "ubahlah", "ganti", "gantilah", "alihkan", "balik", "balikkan", "tukar", "toggle", "switch", "change", "flip")

    private fun sebutTalkBack(t: List<String>): Boolean =
        t.any { it in setOf("talkback", "talkbek", "tokback", "tolkback") } || (t.contains("talk") && t.contains("back")) ||
            (t.contains("talk") && t.any { it.startsWith("bac") })

    /** FIX213: "ganti mesin suara utama TalkBack (ke Google)", "change TalkBack text-to-speech engine". */
    fun mintaMesinTalkBack(t: List<String>): Boolean {
        if (!sebutTalkBack(t)) return false
        val kataMesin = t.any { it in setOf("mesin", "engine", "mesinnya", "sintesis", "synthesizer", "tts", "synth") } ||
            (t.contains("text") && t.contains("speech")) || (t.contains("teks") && t.any { it.startsWith("ucap") })
        val kataUbah = t.any { it in kataAlih || it in setOf("pilih", "pilihkan", "atur", "set", "choose", "select", "gunakan", "pakai", "use") }
        return kataMesin && kataUbah
    }

    /** Memahami perintah pengaturan perangkat dalam Indonesia maupun English. */
    /** FIX299: perintah "buka pengaturan <perangkat>" (tanpa kata nyalakan/matikan). Pengaturan milik fitur aplikasi tidak dibajak. */
    fun pengaturanPerangkat(kandidat: List<String>): JenisPerangkat? {
        for (u in kandidat) {
            val t = token(u)
            if (t.none { it in setOf("pengaturan", "pengaturannya", "setelan", "setelannya", "setting", "settings", "seting", "settingan", "halaman") }) continue
            if (t.any { it in setOf("sholat", "salat", "shalat", "solat", "jadwal", "prayer", "jam", "aplikasi", "app", "pintar", "baterai", "battery", "suara", "tampilan") }) continue
            if (kontrolPerangkat(listOf(u)) != null) continue
            val jenis = kontrolPerangkat(listOf(u + " aktifkan"))?.jenis ?: continue
            if (jenis == JenisPerangkat.LOKASI && t.none { it in setOf("perangkat", "hp", "ponsel", "gps", "sistem", "android", "device", "phone", "layanan") }) continue
            return jenis
        }
        return null
    }

    /** FIX299: pergeseran hari untuk "tanggal hijriah/masehi kemarin / besok / lusa"; kosong bila tidak disebut. Kemarin dan besok sekaligus menghasilkan keduanya. */
    fun geserHari(kandidat: List<String>): List<Int> {
        for (u in kandidat) {
            val t = token(u)
            val f = t.joinToString(" ")
            val mundur = t.any { it in setOf("kemarin", "sebelumnya", "sebelum", "yesterday", "previous", "prior", "wingi", "kamari", "أمس") } || f.contains("hari sebelum")
            val maju = t.any { it in setOf("besok", "esok", "berikutnya", "selanjutnya", "tomorrow", "next", "mbenjing", "isukan", "غدا", "بعد") } || f.contains("hari berikut")
            val lusa = t.any { it in setOf("lusa") } && !f.contains("kemarin lusa")
            val hasil = ArrayList<Int>()
            if (mundur) hasil.add(-1)
            if (maju) hasil.add(1)
            if (lusa && !maju) hasil.add(2)
            if (hasil.isNotEmpty()) return hasil
        }
        return emptyList()
    }

    fun kontrolPerangkat(kandidat: List<String>): KontrolPerangkat? {
        val t = token(kandidat.joinToString(" "))
        if (t.isEmpty()) return null
        // Kata kerja disediakan untuk seluruh bahasa utama aplikasi: Indonesia, English,
        // Arab, Jawa, dan Sunda. Nama teknologi tetap menerima istilah internasional.
        val aktif = when {
            t.contains("off") || t.contains("disable") || t.containsAll(listOf("turn", "off")) ||
                t.any { it in setOf("matikan", "nonaktifkan", "nonaktif", "putuskan", "mati", "pateni", "mateni", "pareuman", "paehkeun", "أوقف", "اوقف", "عطل", "عطّل", "إيقاف", "اغلق", "أغلق") } -> false
            t.contains("on") || t.contains("enable") || t.containsAll(listOf("turn", "on")) ||
                t.any { it in setOf("aktifkan", "nyalakan", "hidupkan", "sambungkan", "nyala", "hidup", "uripna", "uripke", "uripno", "aktifna", "aktifke", "hurungkeun", "aktipkeun", "شغل", "فعّل", "فعل", "تشغيل", "تفعيل", "افتح") } -> true
            else -> null
        }
        // FIX213: "ubah/ganti/alihkan/toggle" tanpa hidup atau mati membalik status saat ini.
        val alih = aktif == null && t.any { it in kataAlih } && t.none { it in setOf("terkini", "current", "mesin", "engine") }
        if (aktif == null && !alih) return null
        // Perintah memilih mesin suara TalkBack ditangani tersendiri (lihat mintaMesinTalkBack).
        if (mintaMesinTalkBack(t)) return null
        val jenis = when {
            sebutTalkBack(t) -> JenisPerangkat.TALKBACK
            t.any { it in setOf("bluetooth", "bluetoothnya", "بلوتوث") } -> JenisPerangkat.BLUETOOTH
            t.any { it in setOf("wifi", "wi-fi", "wireless", "wlan") } || t.containsAll(listOf("wi", "fi")) || t.containsAll(listOf("واي", "فاي")) -> JenisPerangkat.WIFI
            t.any { it in setOf("hotspot", "tethering", "penambatan") } || t.containsAll(listOf("نقطة", "اتصال")) -> JenisPerangkat.HOTSPOT
            t.any { it in setOf("seluler", "mobile", "cellular", "internet", "بيانات", "الجوال", "الهاتف") } || (t.contains("data") && t.any { it in setOf("seluler", "mobile", "cellular") }) -> JenisPerangkat.DATA_SELULER
            t.any { it in setOf("pesawat", "airplane", "flight", "الطيران") } || t.containsAll(listOf("وضع", "الطيران")) -> JenisPerangkat.MODE_PESAWAT
            t.any { it in setOf("lokasi", "location", "gps", "الموقع") } -> JenisPerangkat.LOKASI
            t.any { it in setOf("nfc") } -> JenisPerangkat.NFC
            else -> null
        } ?: return null
        return KontrolPerangkat(jenis, aktif ?: true, alih)
    }

    private fun tafsirSatu(ucapan: String): Jenis? {
        val t = token(ucapan)
        if (t.isEmpty()) return null
        val frasa = t.joinToString(" ")
        val gabung = t.joinToString("")
        val kerjaBuka = t.any { it in kataKerjaBuka }
        val panggil = t.any { it in setOf("telepon", "telpon", "panggil", "hubungi", "call", "phone", "dial") }
        val pesan = t.any { it in setOf("pesan", "sms", "message", "messages", "whatsapp", "wa", "chat", "inbox", "kotak") }
        val baca = t.any { it in setOf("baca", "bacakan", "read", "listen", "dengarkan") }
        if (mintaMesinTalkBack(t)) return Jenis.MESIN_SUARA_TALKBACK
        // FIX217: gempa, tsunami, dan peringatan dini cuaca BMKG diperiksa sebelum fitur cuaca ("hujan" ada pada peringatan dini).
        if (InfoBmkg.jenisDari(t) != null) return Jenis.BMKG
        // Perintah perangkat harus diperiksa sebelum kata "matikan" dianggap sebagai stop audio.
        if (infoPerangkat(listOf(ucapan)).contains(TopikPerangkat.SINYAL)) return Jenis.INFO_PERANGKAT
        // FIX299: "buka pengaturan Bluetooth/Wi-Fi/data seluler..." membuka halaman pengaturannya saja, tanpa menekan sakelar.
        if (pengaturanPerangkat(listOf(ucapan)) != null) return Jenis.BUKA_PENGATURAN_PERANGKAT
        if (kontrolPerangkat(listOf(ucapan)) != null) return Jenis.KONTROL_PERANGKAT
        // FIX250: mode acara, lokasi terkini, dan sakelar fitur dapat dikendalikan lewat suara.
        if (kendaliModeAcara(listOf(ucapan)) != null) return Jenis.MODE_ACARA_KONTROL
        when (perintahLokasi(listOf(ucapan))) { 1 -> return Jenis.LOKASI_SEBUT; 2 -> return Jenis.LOKASI_PERBARUI }
        if (sakelarFitur(listOf(ucapan)) != null) return Jenis.SAKELAR_FITUR
        if (infoPerangkat(listOf(ucapan)).isNotEmpty()) return Jenis.INFO_PERANGKAT
        // FIX259: "putar terjemahnya" atau "lanjutkan terjemahnya" memutar terjemahan bagian Al-Qur'an yang terakhir diputar.
        if (t.any { it in setOf("terjemah", "terjemahan", "terjemahnya", "terjemahannya", "translation") } &&
            t.any { it in setOf("putar", "putarkan", "mainkan", "play", "lanjut", "lanjutkan", "teruskan", "continue", "dengarkan", "bacakan", "lagi") } &&
            t.none { it in setOf("hadits", "hadith", "doa", "khutbah", "pesan", "kitab", "buku", "artikel", "teks") }) return Jenis.QURAN
        // Kendali audio hanya dikenali bila pengguna menyebut audio/pemutar/Quran atau perintah stop pendek yang jelas.
        run {
            val konteksAudio = t.any { it in setOf("audio", "suara", "quran", "qur an", "pemutar", "player", "murattal", "bacaan", "tilawah", "juz", "surah", "surat") }
            // FIX316: jeda dan lanjut juga dikenali dalam kalimat agak panjang bila menyebut audio atau Al-Qur'an, serta "hentikan sementara".
            if (frasa.contains("hentikan sementara") || frasa.contains("berhenti sebentar") || frasa.contains("stop sebentar") || frasa.contains("tahan dulu")) return Jenis.JEDA_AUDIO
            if (t.size > 4 && !(t.size <= 7 && konteksAudio)) return@run
            // "putar juz berikutnya", "lanjutkan juz 3": itu perintah memutar bagian tertentu, bukan sekadar melanjutkan yang dijeda.
            if (t.any { it in setOf("berikutnya", "selanjutnya", "sebelumnya", "next", "previous") } ||
                (t.any { it in setOf("juz", "surah", "surat", "ayat") } && t.any { it.toIntOrNull() != null })) return@run
            if (("timer" !in t && "countdown" !in t && t.any { it in setOf("berhenti", "hentikan", "stop", "henti") }) || (konteksAudio && t.any { it in setOf("matikan", "turnoff", "off") })) return Jenis.BERHENTI_AUDIO
            if (t.any { it in setOf("jeda", "pause", "jedakan") }) return Jenis.JEDA_AUDIO
            if (t.any { it in setOf("lanjut", "lanjutkan", "resume", "teruskan", "continue") }) return Jenis.LANJUT_AUDIO
        }
        if (panggil) return Jenis.PANGGIL
        if (t.any { it in setOf("timer", "countdown", "countdown-timer") }) return Jenis.TIMER
        if (t.any { it in setOf("baterai", "battery", "baterei", "batré") } &&
            (t.any { it in setOf("berapa", "persen", "sisa", "status", "cek", "periksa", "informasikan", "bacakan", "how", "much", "level", "remaining", "charge") } || t.size <= 3)) return Jenis.BATERAI_INFO
        if (t.any { it in setOf("cuaca", "cuacanya", "weather", "forecast", "prakiraan", "prakiraannya", "prediksi", "prediksinya", "perkiraan", "perkiraannya", "ramalan", "hujan", "الطقس", "طقس", "الجو") }) return Jenis.CUACA
        // FIX225: pertanyaan cuaca spesifik tanpa kata "cuaca"; kata suhu dan angin dikecualikan bila yang dimaksud perangkat.
        val kataPerangkat = setOf("baterai", "battery", "baterei", "hp", "ponsel", "phone", "charger", "cpu", "perangkat", "device", "ruangan", "kulkas")
        if (t.none { it in kataPerangkat }) {
            if (t.any { it in setOf("payung", "gerimis", "umbrella", "rain", "raining", "berangin", "windy", "uv", "ultraviolet", "kelembapan", "kelembaban", "humidity") }) return Jenis.CUACA
            if (t.any { it in setOf("suhu", "temperature", "angin", "wind") } && t.any { it in setOf("hari", "ini", "sekarang", "sini", "besok", "lusa", "today", "now", "tomorrow", "luar", "outside", "berapa", "how", "what", "bagaimana", "kota", "daerah") }) return Jenis.CUACA
        }
        val cari = t.any { it in setOf("cari", "temukan", "search", "find", "from", "dari") }
        if (pesan && cari && t.any { it in setOf("ali", "bima") }) return Jenis.CARI_PESAN
        if (pesan && baca) return Jenis.BACA_PESAN
        if (pesan && (t.any { it in setOf("buka", "open", "lihat", "tampilkan", "cek", "periksa") } || t.size <= 3)) return Jenis.PESAN
        if (kerjaBuka && fiturDariToken(t) == null && t.any { it !in kataKerjaBuka && it !in setOf("aplikasi", "app", "tolong", "please") }) return Jenis.BUKA_APLIKASI
        // Aksi membuka fitur harus dibedakan dari pertanyaan informasi ("jam berapa", "tanggal apa").
        if (kerjaBuka && (t.any { it in kataQuran } || gabung.contains("quran"))) return Jenis.BUKA_FITUR
        if (kerjaBuka && fiturDariToken(t) != null) return Jenis.BUKA_FITUR
        // FIX212: sebut nama fitur pustaka Islami saja ("kalkulator zakat", "kitab hadits shahih") juga membuka fiturnya.
        if (t.size <= 6 && fiturDariToken(t) in setOf(Fitur.HADITS, Fitur.KHUTBAH, Fitur.MANASIK_HAJI, Fitur.PANDUAN_IBADAH, Fitur.KOMPAS_ARAH, Fitur.KALKULATOR_ZAKAT, Fitur.DOA_HARIAN, Fitur.ASMAUL_HUSNA,
                Fitur.PENGATURAN_SHOLAT, Fitur.JADWAL_BULANAN, Fitur.PENGHEMAT_DAYA, Fitur.PEMICU_ASISTEN, Fitur.PENGATURAN_GONCANGAN, Fitur.IZIN_PERANGKAT, Fitur.PAKET_BAHASA,
                Fitur.HUBUNGI_PENGEMBANG, Fitur.AKSI_PETUNJUK, Fitur.AKSI_CADANGKAN, Fitur.AKSI_PULIHKAN, Fitur.AKSI_RESET, Fitur.AKSI_INFO_APP, Fitur.AKSI_PERIKSA_UPDATE, Fitur.BERANDA,
                Fitur.PEMANGGIL_IZIN, Fitur.PEMANGGIL_JENIS, Fitur.PEMANGGIL_PESAN, Fitur.PEMANGGIL_MELODI, Fitur.PEMANGGIL_VOLUME, Fitur.PEMANGGIL_SUARA, Fitur.PEMANGGIL)) return Jenis.BUKA_FITUR
        val quran = t.any { it in kataQuran } || gabung.contains("quran")
        if (quran) return Jenis.QURAN
        // FIX98: "ulangi 3 kali", "putar lagi", dan "putar Yasin 5 kali" (nama surah tanpa kata "surah").
        val kataUlangPendek = t.any { it in setOf("ulangi", "ulang", "diulang", "mengulang", "repeat") } ||
            (t.size <= 4 && t.any { it in setOf("lagi", "again") } && t.any { it in setOf("putar", "play", "mainkan", "baca") })
        if (kataUlangPendek && t.size <= 7 && "tahun" !in t && !pesan && !panggil) return Jenis.QURAN
        if (t.any { it in setOf("putar", "putarkan", "mainkan", "play") } &&
            PenafsirQuran.tafsir(listOf(ucapan))?.let { it.surah != null || it.juz != null || it.relatif != 0 } == true) return Jenis.QURAN
        val qari = t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
        if (qari) return Jenis.QURAN
        // Pasaran Jawa diminta sendiri: jawab pasarannya saja, bukan rangkaian tanggal, libur, dan salat.
        if (t.any { it in setOf("pasaran", "pasarannya", "weton") }) return Jenis.PASARAN
        if (t.any { it in setOf("masehi", "gregorian") } || frasa.contains("tanggal masehi") || frasa.contains("gregorian date")) return Jenis.TANGGAL_MASEHI
        val kataLibur = t.any { it in setOf("libur", "liburan", "holiday", "holidays", "cuti", "vacation") } || frasa.contains("day off")
        if (kataLibur && (t.any { it in setOf("nasional", "national", "bersama", "joint", "today", "hari", "ini", "kemarin", "yesterday", "besok", "berikutnya", "mendatang", "upcoming", "next", "past", "terakhir", "lalu", "akan", "datang") })) return Jenis.LIBUR_SPESIFIK
        if (kataLibur) return Jenis.LIBUR
        if (t.any { it in setOf("hijriah", "hijriyah", "hijri", "islamic") } || frasa.contains("islamic date")) return Jenis.TANGGAL_HIJRIAH
        if (t.any { it in setOf("salat", "shalat", "sholat", "solat", "prayer", "prayers", "fajr", "subuh", "shubuh", "dzuhur", "zuhur", "dhuhr", "duhur", "ashar", "asar", "asr", "maghrib", "magrib", "isya", "isyak", "isha", "imsak", "dhuha", "duha") } || frasa.contains("prayer time") || frasa.contains("matahari terbit") || frasa.contains("sunrise")) return Jenis.SHOLAT_BERIKUTNYA
        val waktu = t.any { it in kataWaktu }
        val tanggal = t.any { it in kataTanggal }
        val semua = t.any { it in kataSemua }
        return when {
            waktu && tanggal -> Jenis.WAKTU_TANGGAL
            waktu && semua -> Jenis.SEMUA
            tanggal && semua -> Jenis.SEMUA
            waktu -> Jenis.WAKTU
            tanggal -> Jenis.TANGGAL
            semua -> Jenis.SEMUA
            t.any { it in kataKerjaInfo } && t.size <= 3 -> Jenis.SEMUA
            else -> null
        }
    }

    /** Membaca durasi timer dari angka atau bilangan umum yang sering dipakai secara lisan. */
    fun durasiTimerDetik(kandidat: List<String>): Long {
        val t = token(kandidat.joinToString(" "))
        val angka = mapOf("nol" to 0L, "satu" to 1L, "se" to 1L, "dua" to 2L, "tiga" to 3L, "empat" to 4L, "lima" to 5L, "enam" to 6L, "tujuh" to 7L, "delapan" to 8L, "sembilan" to 9L, "sepuluh" to 10L, "sebelas" to 11L, "dua belas" to 12L, "lima belas" to 15L, "dua puluh" to 20L, "tiga puluh" to 30L, "empat puluh" to 40L, "lima puluh" to 50L, "sixty" to 60L, "thirty" to 30L, "twenty" to 20L, "fifteen" to 15L, "ten" to 10L, "five" to 5L, "four" to 4L, "three" to 3L, "two" to 2L, "one" to 1L, "half" to 30L)
        var total = 0L
        var i = 0
        while (i < t.size) {
            val unit = when (t[i]) { "jam", "hours", "hour", "hrs" -> 3600L; "menit", "minute", "minutes", "mins" -> 60L; "detik", "second", "seconds", "secs" -> 1L; else -> 0L }
            if (unit > 0) {
                var n = 0L
                if (i > 0) {
                    val dua = if (i >= 2) t[i - 2] + " " + t[i - 1] else ""
                    n = angka[dua] ?: angka[t[i - 1]] ?: t[i - 1].toLongOrNull() ?: 0L
                }
                if (n == 0L && t[i].startsWith("menit") && i > 0 && t[i - 1] == "setengah") n = 30L
                total += n * unit
            }
            i++
        }
        if (total == 0L) {
            val num = t.firstOrNull { it.toLongOrNull() != null }?.toLongOrNull()
            if (num != null && t.any { it in setOf("timer", "countdown") }) total = num * 60L
        }
        return total.coerceIn(0L, 359999L)
    }

    /** True bila ucapan memuat klausa memilih qari ("pilih qari ..."); itu hanya dapat ditangani Khatam. */
    fun adaKlausaQari(kandidat: List<String>): Boolean = kandidat.any { u ->
        val t = token(u)
        t.any { it in kataQariPasti } || (t.any { it in kataQariMirip } && t.any { it in kataKerjaQari })
    }

    fun namaKontakPesan(kandidat: List<String>): String {
        val gabung = kandidat.joinToString(" ").lowercase()
        return if (gabung.contains("ali") && gabung.contains("bima")) "Ali Bima" else ""
    }

    fun kategoriLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return if (t.any { it in setOf("cuti", "bersama", "joint") }) "joint" else "national"
    }
    fun periodeLibur(kandidat: List<String>): String {
        val t = token(kandidat.joinToString(" "))
        return when {
            t.any { it in setOf("kemarin", "kemarinnya", "yesterday", "lampau", "lalu", "past", "terakhir") } -> "past"
            t.any { it in setOf("besok", "mendatang", "berikutnya", "selanjutnya", "upcoming", "next") } || (t.contains("akan") && t.contains("datang")) -> "next"
            else -> "today"
        }
    }

    // ---------- FIX250: kendali suara untuk mode acara, lokasi, dan sakelar fitur ----------

    private val kataNyala = setOf("aktifkan", "aktifkanlah", "nyalakan", "hidupkan", "mulai", "mulailah", "mulaikan", "jalankan", "aktif", "enable", "activate", "start", "begin")
    private val kataMati = setOf("matikan", "nonaktifkan", "nonaktif", "hentikan", "akhiri", "akhirilah", "selesaikan", "batalkan", "stop", "disable", "deactivate", "end", "cancel")
    private val kataStatus = setOf("apakah", "status", "cek", "periksa", "sedang", "masih", "sudah", "check", "is", "whether")

    /** true = hidupkan, false = matikan, null = tidak jelas. */
    fun nyalaMati(t: List<String>): Boolean? {
        if (t.contains("off") || t.any { it in kataMati } || (t.contains("turn") && t.contains("off"))) return false
        if (t.contains("on") || t.any { it in kataNyala } || (t.contains("turn") && t.contains("on"))) return true
        return null
    }

    /** 1 = aktifkan, -1 = matikan, 0 = tanyakan status, null = bukan perintah mode acara. */
    fun kendaliModeAcara(kandidat: List<String>): Int? {
        for (u in kandidat) {
            val t = token(u)
            val f = t.joinToString(" ")
            if (!(f.contains("mode acara") || (t.contains("event") && t.contains("mode")))) continue
            if (t.any { it in kataStatus }) return 0
            return when (nyalaMati(t)) { true -> 1; false -> -1; null -> null }
        }
        return null
    }

    /** Lama mode acara yang disebut dalam menit; 0 bila tidak disebut. */
    fun menitModeAcara(kandidat: List<String>): Int = (durasiTimerDetik(kandidat) / 60L).toInt()

    private val kataBukanLokasiSaya = setOf("cuaca", "weather", "forecast", "prakiraan", "hujan", "gempa", "tsunami", "bmkg", "kiblat", "qibla", "masjid", "mosque",
        "restoran", "toilet", "spbu", "atm", "terdekat", "nearby", "kontak", "pesan", "timer", "jadwal", "sholat", "shalat", "salat", "solat", "prayer", "azan", "adzan",
        "baterai", "battery", "wifi", "bluetooth", "hotspot", "gps", "nfc", "talkback", "rute", "route", "navigasi")

    /** 1 = sebutkan lokasi terkini, 2 = perbarui lokasi otomatis, null = bukan perintah lokasi. */
    fun perintahLokasi(kandidat: List<String>): Int? {
        for (u in kandidat) {
            val t = token(u)
            if (t.isEmpty() || t.any { it in kataBukanLokasiSaya } && !t.any { it == "jadwal" || it == "sholat" || it == "salat" || it == "shalat" || it == "prayer" }) continue
            val nomina = t.any { it in setOf("lokasi", "lokasinya", "location", "posisi", "position", "koordinat", "coordinates", "alamat", "address") }
            val perbarui = t.any { it in setOf("perbarui", "perbaharui", "update", "refresh", "segarkan", "mutakhirkan", "sinkronkan", "sinkron", "deteksi", "detect", "sync", "otomatis", "automatic", "automatically", "auto", "temukan") }
            if (nomina && perbarui) {
                // "update lokasi" harus tidak berisi kata fitur lain kecuali jadwal sholat.
                if (t.any { it in setOf("cuaca", "weather", "gempa", "kiblat", "timer", "baterai", "battery") }) continue
                return 2
            }
            if (t.any { it in kataBukanLokasiSaya }) continue
            val diri = t.any { it in setOf("saya", "aku", "ku", "kita", "kami", "i", "me", "my", "am", "we", "ini", "sini") }
            val tanyaDi = t.contains("dimana") || t.contains("where") || (t.contains("di") && t.contains("mana")) || t.contains("mana")
            val kini = t.any { it in setOf("saat", "sekarang", "terkini", "ini", "saya", "now", "current", "currently", "my", "aku") }
            val bukaSaja = t.any { it in kataKerjaBuka } && !tanyaDi
            if (tanyaDi && (diri || kini)) return 1
            if (t.any { it in setOf("alamat", "address", "jalan", "street") } && (diri || kini) && !bukaSaja) return 1
            if (nomina && kini && !bukaSaja) return 1
        }
        return null
    }

    /**
     * FIX261: sholat tertentu yang ditanyakan beserta apakah yang dimaksud besok. Null bila tidak menyebut nama sholat
     * (tetap "sholat berikutnya"). "jadwal sholat" atau "semua sholat" memberi kelima waktu wajib.
     */
    fun sholatDiminta(kandidat: List<String>): Pair<List<String>, Boolean>? {
        val peta = mapOf("subuh" to "subuh", "shubuh" to "subuh", "fajr" to "subuh", "dzuhur" to "dzuhur", "zuhur" to "dzuhur", "dhuhr" to "dzuhur", "duhur" to "dzuhur",
            "ashar" to "ashar", "asar" to "ashar", "asr" to "ashar", "maghrib" to "maghrib", "magrib" to "maghrib", "isya" to "isya", "isyak" to "isya", "isha" to "isya",
            "imsak" to "imsak", "dhuha" to "dhuha", "duha" to "dhuha", "terbit" to "terbit", "sunrise" to "terbit")
        for (u in kandidat) {
            val t = token(u)
            val besok = t.any { it in setOf("besok", "esok", "tomorrow") }
            val hasil = LinkedHashSet<String>()
            for (k in t) peta[k]?.let { hasil.add(it) }
            if (hasil.isEmpty() && (u.lowercase().contains("sunrise") || u.lowercase().contains("matahari terbit"))) hasil.add("terbit")
            if (hasil.isNotEmpty()) return hasil.toList() to besok
            val semua = t.any { it in setOf("jadwal", "semua", "seluruh", "schedule", "all", "lima", "five", "times") } &&
                t.any { it in setOf("salat", "shalat", "sholat", "solat", "prayer", "prayers", "waktu") }
            if (semua) return listOf("subuh", "dzuhur", "ashar", "maghrib", "isya") to besok
        }
        return null
    }

    enum class TopikPerangkat { SEMUA, SINYAL, RAM, MEMORI_INTERNAL, ARSITEKTUR, PROSESOR, MODEL, ANDROID, LAYAR, UPTIME, VERSI_APLIKASI }

    /** FIX253: topik informasi perangkat yang ditanyakan (RAM, memori internal, 32/64 bit, model, dan sebagainya); kosong bila bukan pertanyaan perangkat. */
    fun infoPerangkat(kandidat: List<String>): Set<TopikPerangkat> {
        for (u in kandidat) {
            val t = token(u)
            if (t.isEmpty()) continue
            val f = t.joinToString(" ")
            if (t.any { it in setOf("baterai", "battery", "cuaca", "weather", "timer", "hadits", "hadith", "quran") }) continue
            val h = LinkedHashSet<TopikPerangkat>()
            // FIX297: kekuatan sinyal dan jaringan (Wi-Fi, data seluler, Bluetooth); kata nyala/mati diserahkan ke kendali perangkat.
            val kataJaringan = t.any { it in setOf("sinyal", "signal", "jaringan", "network", "wifi", "wi", "fi", "internet", "koneksi", "connection", "seluler", "cellular", "operator", "kuota") }
            val kataTanya = t.any { it in setOf("kekuatan", "kuat", "lemah", "strength", "strong", "weak", "berapa", "bagaimana", "gimana", "apa", "status", "cek", "periksa", "informasikan", "bacakan", "info", "informasi", "kondisi", "kualitas", "quality", "how", "what", "check", "tell", "terhubung", "connected", "bar") }
            val kataKendali = t.any { it in setOf("nyalakan", "hidupkan", "aktifkan", "matikan", "nonaktifkan", "putuskan", "sambungkan", "hubungkan", "enable", "disable", "on", "off", "turn", "connect", "disconnect", "toggle", "ubah", "ganti") }
            if (kataJaringan && kataTanya && !kataKendali) { h.add(TopikPerangkat.SINYAL); return h }
            val adaRam = t.contains("ram")
            if (adaRam) h.add(TopikPerangkat.RAM)
            val nomaPenyimpanan = t.any { it in setOf("memori", "memory", "penyimpanan", "storage", "ruang", "kapasitas", "space", "disk") }
            val tanyaSisa = t.any { it in setOf("internal", "sisa", "tersisa", "kosong", "free", "tersedia", "available", "penuh", "terpakai", "used", "left", "remaining", "berapa", "how", "much") }
            if (nomaPenyimpanan && tanyaSisa && (!adaRam || t.any { it == "internal" || it == "penyimpanan" || it == "storage" })) h.add(TopikPerangkat.MEMORI_INTERNAL)
            val bit = t.any { Regex("(32|64)(bit)?").matches(it) } && (t.contains("bit") || t.any { it.endsWith("bit") })
            if (bit || t.any { it == "arsitektur" || it == "architecture" }) h.add(TopikPerangkat.ARSITEKTUR)
            if (t.any { it in setOf("prosesor", "processor", "cpu", "chipset", "soc", "core", "cores") }) h.add(TopikPerangkat.PROSESOR)
            val perangkat = t.any { it in setOf("hp", "ponsel", "perangkat", "handphone", "smartphone", "phone", "device", "gawai", "telepon") }
            if ((t.any { it in setOf("model", "merek", "merk", "brand", "tipe", "type", "seri") } && perangkat) || f.contains("hp saya apa") || f.contains("ini hp apa") || f.contains("what phone")) h.add(TopikPerangkat.MODEL)
            if ((t.contains("android") && t.any { it in setOf("versi", "version", "berapa", "apa", "what", "patch") }) || f.contains("patch keamanan") || f.contains("security patch")) h.add(TopikPerangkat.ANDROID)
            if (t.any { it in setOf("layar", "screen", "display", "resolusi", "resolution") } && t.any { it in setOf("berapa", "ukuran", "resolusi", "resolution", "refresh", "kepadatan", "density", "size", "what", "how", "spesifikasi") } ||
                f.contains("refresh rate") || f.contains("kecepatan penyegaran")) h.add(TopikPerangkat.LAYAR)
            if (f.contains("uptime") || f.contains("menyala sejak") || (t.contains("menyala") && t.contains("berapa")) || (t.contains("berapa") && t.contains("lama") && t.any { it in setOf("restart", "booting", "hidup", "dihidupkan", "dinyalakan") })) h.add(TopikPerangkat.UPTIME)
            if (t.any { it == "versi" || it == "version" } && t.any { it in setOf("aplikasi", "app", "pintar", "pro") } && !t.contains("android")) h.add(TopikPerangkat.VERSI_APLIKASI)
            val semua = listOf("informasi perangkat", "info perangkat", "spesifikasi", "kondisi perangkat", "kondisi hp", "tentang perangkat", "tentang hp", "informasi hp", "info hp", "device info", "device specs", "specs", "about this phone", "about my device", "spek ")
                .any { f.contains(it) || (f + " ").contains(it) }
            if (semua) { h.clear(); h.add(TopikPerangkat.SEMUA) }
            if (h.isNotEmpty()) return h
        }
        return emptySet()
    }

    enum class Sakelar { JADWAL_SHOLAT, PENGUMUMAN, NAMA_PEMANGGIL, NAMA_PANGGILAN_KONTAK, BACA_NOTIF_SEMUA, BACA_SMS, BACA_WB, BACA_WA, BACA_EMAIL, BACA_GOJEK, BACA_GRAB, BACA_INDRIVE, BACA_MAXIM, ANTRIAN_NOTIF }

    /** Pasangan sakelar dan nilai baru (true = aktif), atau null. */
    fun sakelarFitur(kandidat: List<String>): Pair<Sakelar, Boolean>? {
        for (u in kandidat) {
            val t = token(u)
            val f = t.joinToString(" ")
            if (t.any { it in kataStatus }) continue
            val nilai = nyalaMati(t) ?: continue
            // FIX308: Nama Panggilan dan Pembacaan Notifikasi. Diperiksa lebih dulu karena lebih khusus.
            val notif = f.contains("notifikasi") || f.contains("notification") || f.contains("pembacaan") || t.any { it in setOf("baca", "bacakan", "read", "membaca") }
            if (f.contains("antrian") || f.contains("antrean") || f.contains("queue")) { if (notif || f.contains("pembacaan")) return Pair(Sakelar.ANTRIAN_NOTIF, nilai) }
            if (notif) {
                if (f.contains("business") || f.contains("bisnis") || f.contains("wa bisnis") || f.contains("wb")) return Pair(Sakelar.BACA_WB, nilai)
                if (f.contains("whatsapp") || f.contains("messenger") || t.contains("wa")) return Pair(Sakelar.BACA_WA, nilai)
                if (f.contains("sms") || f.contains("pesan seluler") || f.contains("text message")) return Pair(Sakelar.BACA_SMS, nilai)
                if (f.contains("email") || f.contains("surel") || f.contains("gmail")) return Pair(Sakelar.BACA_EMAIL, nilai)
                if (f.contains("gojek")) return Pair(Sakelar.BACA_GOJEK, nilai)
                if (f.contains("grab")) return Pair(Sakelar.BACA_GRAB, nilai)
                if (f.contains("indrive")) return Pair(Sakelar.BACA_INDRIVE, nilai)
                if (f.contains("maxim")) return Pair(Sakelar.BACA_MAXIM, nilai)
                if (f.contains("pembacaan notifikasi") || f.contains("baca notifikasi") || f.contains("bacakan notifikasi") || f.contains("notification reading") || f.contains("read notifications") || f.contains("read notification")) return Pair(Sakelar.BACA_NOTIF_SEMUA, nilai)
            }
            if (f.contains("nickname") || f.contains("panggilan kontak") || f.contains("nama panggilan kontak") || f.contains("nama kontak")) return Pair(Sakelar.NAMA_PANGGILAN_KONTAK, nilai)
            if (f.contains("nama panggilan") || f.contains("nama pemanggil") || f.contains("pengumuman penelepon") || f.contains("pengumuman pemanggil") || f.contains("caller name") || f.contains("caller announcement") || f.contains("announce caller")) return Pair(Sakelar.NAMA_PEMANGGIL, nilai)
            val sholat = f.contains("jadwal sholat") || f.contains("jadwal salat") || f.contains("jadwal shalat") || f.contains("jadwal solat") ||
                f.contains("pengingat sholat") || f.contains("pengingat salat") || f.contains("pengingat shalat") || f.contains("prayer schedule") || f.contains("prayer times") || f.contains("prayer reminders")
            if (sholat) return Pair(Sakelar.JADWAL_SHOLAT, nilai)
            val umum = f.contains("pengumuman otomatis") || f.contains("pengumuman suara") || f.contains("automatic announcements") || f.contains("auto announcements") || f.contains("announcements")
            if (umum) return Pair(Sakelar.PENGUMUMAN, nilai)
        }
        return null
    }

    fun fitur(kandidat: List<String>): Fitur? = kandidat.asSequence().mapNotNull { fiturDariToken(token(it)) }.firstOrNull()

    private fun fiturDariToken(t: List<String>): Fitur? {
        val f = t.joinToString(" ")
        fun ada(vararg kata: String) = kata.any { k -> f.contains(k) || t.contains(k) }
        return when {
            // FIX289: "buka Jam Pintar Pro" / "menu utama" membuka beranda aplikasi; diperiksa paling awal agar kata "jam" tidak dianggap fitur Jam.
            ada("jam pintar", "smart clock", "beranda", "halaman utama", "menu utama", "layar utama aplikasi", "main menu", "home screen", "app home") -> Fitur.BERANDA
            // FIX212: fitur pustaka Islami. Diperiksa paling awal agar "panduan manasik haji dan doa-doanya" tidak dianggap fitur Doa,
            // dan "kitab hadits" tidak dianggap fitur lain.
            ada("zakat", "zakah", "zakaat", "zakāt", "waris", "warisan", "mawaris", "faraid", "faraidh", "fara'id", "inheritance", "inherit") -> Fitur.KALKULATOR_ZAKAT
            ada("manasik", "manasek", "haji", "hajj", "umrah", "umroh") -> Fitur.MANASIK_HAJI
            // FIX243: Panduan Ibadah Praktis; diperiksa sebelum fitur Doa agar "panduan ibadah" atau "tata cara shalat" tidak dianggap fitur lain.
            ada("panduan ibadah", "tuntunan ibadah", "ibadah praktis", "tata cara", "tuntunan shalat", "tuntunan sholat", "tuntunan salat", "worship guide", "prayer guide", "how to pray") -> Fitur.PANDUAN_IBADAH
            ada("khutbah", "khutbat", "khotbah", "kutbah", "kotbah", "khutba", "sermon") -> Fitur.KHUTBAH
            ada("hadits", "hadist", "hadis", "hadith", "bukhari", "bukhori", "arbain", "arbain", "arba in", "arbaiin", "nawawi", "nawawy",
                "riyadhus", "riyadus", "riyadlus", "riyadh us", "shalihin", "sholihin", "salihin", "shalihiin", "sahih muslim", "shahih muslim") -> Fitur.HADITS
            // FIX250: seluruh layar dan aksi menu beranda dapat disebut dengan suara.
            ada("pengaturan jadwal sholat", "pengaturan jadwal salat", "pengaturan jadwal shalat", "pengaturan sholat", "pengaturan salat", "pengaturan shalat", "pengaturan azan", "pengaturan adzan", "prayer settings", "prayer schedule settings", "adhan settings") -> Fitur.PENGATURAN_SHOLAT
            ada("jadwal bulanan", "jadwal sebulan", "jadwal 30", "jadwal tiga puluh", "monthly schedule", "monthly prayer", "30 day schedule", "30-day schedule") -> Fitur.JADWAL_BULANAN
            ada("penghemat daya", "hemat daya", "hemat baterai", "power saving", "battery saver", "power saver") -> Fitur.PENGHEMAT_DAYA
            ada("pemicu asisten", "pemicu suara", "pemicu tombol", "beritahu saya", "tombol fisik", "tombol volume", "tombol aksesibilitas", "assistant trigger", "voice trigger", "accessibility button") -> Fitur.PEMICU_ASISTEN
            ada("goncang", "goncangan", "shake", "shaking") -> Fitur.PENGATURAN_GONCANGAN
            ada("izin perangkat", "izin aplikasi", "perizinan", "permissions", "device permissions", "permission settings") -> Fitur.IZIN_PERANGKAT
            ada("paket bahasa", "bahasa offline", "offline language", "language pack") -> Fitur.PAKET_BAHASA
            ada("hubungi pengembang", "kontak pengembang", "hubungi developer", "kirim keluhan", "keluhan", "saran masukan", "contact developer", "feedback") -> Fitur.HUBUNGI_PENGEMBANG
            ada("petunjuk penggunaan", "panduan penggunaan", "cara pakai aplikasi", "user guide", "how to use the app", "bantuan aplikasi") -> Fitur.AKSI_PETUNJUK
            ada("cadangkan pengaturan", "cadangkan", "backup pengaturan", "buat cadangan", "backup settings", "back up settings", "backup") -> Fitur.AKSI_CADANGKAN
            ada("pulihkan pengaturan", "pulihkan", "restore settings", "restore from backup", "restore backup", "pemulihan pengaturan") -> Fitur.AKSI_PULIHKAN
            ada("reset aplikasi", "reset pengaturan", "setel ulang", "atur ulang aplikasi", "factory reset", "reset app", "reset settings") -> Fitur.AKSI_RESET
            ada("info aplikasi", "informasi aplikasi", "app info", "application info") -> Fitur.AKSI_INFO_APP
            ada("periksa pembaruan", "cek pembaruan", "periksa update", "cek update", "update aplikasi", "pembaruan aplikasi", "check for updates", "check updates", "app update") -> Fitur.AKSI_PERIKSA_UPDATE
            // FIX308: Nama Panggilan dan Pembacaan Notifikasi beserta kelompok pengaturannya; diperiksa sebelum fitur lain agar kata "volume", "suara", "notifikasi" tidak salah arah.
            ada("volume pengumuman", "volume nama panggilan", "volume pembacaan notifikasi", "announcement volume", "caller volume") -> Fitur.PEMANGGIL_VOLUME
            ada("melodi pengumuman", "melodi nama panggilan", "melodi pemanggil", "announcement melody", "caller melody") -> Fitur.PEMANGGIL_MELODI
            ada("suara pengumuman", "suara nama panggilan", "suara pembacaan notifikasi", "suara pemanggil", "announcement voice", "caller voice") -> Fitur.PEMANGGIL_SUARA
            ada("akses notifikasi", "izin notifikasi", "izin nama panggilan", "izin pemanggil", "notification access", "notification permission") -> Fitur.PEMANGGIL_IZIN
            ada("jenis panggilan", "pengulangan panggilan", "panggilan masuk", "call types", "incoming call settings") -> Fitur.PEMANGGIL_JENIS
            ada("pembacaan notifikasi", "baca notifikasi", "bacakan notifikasi", "pembacaan pesan", "notifikasi masuk", "notifikasi whatsapp", "notifikasi sms", "notifikasi email", "pengulangan notifikasi", "antrian notifikasi", "antrian pembacaan",
                "notification reading", "read notifications", "incoming notifications") -> Fitur.PEMANGGIL_PESAN
            ada("nama panggilan", "nama pemanggil", "pengumuman penelepon", "pengumuman pemanggil", "caller name", "caller announcement") -> Fitur.PEMANGGIL
            ada("baterai", "battery") -> Fitur.BATERAI
            ada("kalender", "calendar") -> Fitur.KALENDER
            ada("pemanggil", "penelepon", "caller", "penelpon") -> Fitur.PEMANGGIL
            ada("jadwal sholat", "jadwal salat", "pengaturan sholat", "pengaturan salat", "prayer schedule", "waktu salat", "waktu sholat") -> Fitur.SHOLAT
            ada("pemandu jalan", "navigasi", "petunjuk jalan", "route guide", "road guide") -> Fitur.PEMANDU_JALAN
            ada("lokasi terkini", "lokasi saya", "current location", "my location") -> Fitur.LOKASI
            ada("kiblat", "qibla", "arah kiblat") -> Fitur.KIBLAT
            ada("kompas", "compass", "mata angin", "cari arah", "arah utara", "arah timur", "arah selatan", "arah barat", "where is north") -> Fitur.KOMPAS_ARAH
            ada("fasilitas terdekat", "nearby facilities", "tempat terdekat") -> Fitur.FASILITAS
            // FIX272: Asmaul Husna; diperiksa sebelum fitur Doa.
            AsmaulHusnaData.dikenali(f) -> Fitur.ASMAUL_HUSNA
            // FIX226: doa sehari-hari sesuai sunnah ("doa sebelum makan", "doa naik kendaraan", "doa harian").
            DoaHarianData.dikenali(f) -> Fitur.DOA_HARIAN
            ada("taaruf doa", "doa", "daily prayer", "supplication") -> Fitur.DOA
            ada("khatam", "hafalan", "quran", "alquran", "surah", "surat", "ayat", "juz") -> Fitur.KHATAM
            ada("mode acara", "event mode") -> Fitur.MODE_ACARA
            ada("bahasa", "language settings", "pengaturan bahasa") -> Fitur.BAHASA
            ada("jam", "clock") -> Fitur.JAM
            else -> null
        }
    }
}
