package com.novan.bateraibicara

import android.app.DownloadManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Pembaruan aplikasi tanpa Play Store: periksa berkas JSON versi terbaru, unduh APK lewat
 * DownloadManager, lalu pasang lewat PackageInstaller. Android tidak mengizinkan aplikasi biasa
 * memasang pembaruan secara diam-diam, jadi pengguna tetap mengetuk konfirmasi pemasangan sistem
 * (dan mengizinkan "pasang aplikasi dari sumber ini" sekali saja). APK baru HARUS ditandatangani
 * dengan kunci yang sama dengan aplikasi terpasang.
 *
 * Format JSON: {"versionCode":64,"versionName":"1.0.64","apkUrl":"https://.../JamPintarPro.apk","catatan":"...","tanggal":"2026-11-15","ukuran":"28 MB"}
 * FIX290 (mengikuti alur pembaruan Apktool M): nama kunci alternatif build/name/url/changes/date/size diterima; "apkUrl" boleh berupa objek
 * per arsitektur CPU {"arm64-v8a":"...","armeabi-v7a":"..."}; "catatan" boleh objek per bahasa {"id":"...","en":"..."}. Alamat JSON diberi
 * penanda waktu (?t=) agar tidak memakai salinan lama dari cache, dan versi tertentu dapat dilewati pengguna.
 */
object UpdateManager {
    class Info(val versionCode: Int, val versionName: String, val apkUrl: String, val catatan: String, val tanggal: String = "", val ukuran: String = "")

    const val STATUS_GAGAL = 0
    const val STATUS_TERBARU = 1
    const val STATUS_ADA = 2

    const val PASANG_MULAI = 0
    const val PASANG_BERKAS_TIDAK_ADA = 1
    const val PASANG_BERKAS_TIDAK_VALID = 2
    const val PASANG_BUTUH_IZIN = 3
    const val PASANG_GAGAL = 4

    const val AKSI_HASIL_PASANG = "com.novan.bateraibicara.HASIL_PASANG_PEMBARUAN"

    private const val PREF = "pengaturan"
    private const val NAMA_APK = "JamPintarPro-pembaruan.apk"
    private const val JEDA_CEK_MS = 12L * 60 * 60 * 1000
    private const val BATAS_JSON = 256 * 1024

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun repoAda(): Boolean = BuildConfig.GITHUB_REPO.contains("/")

    /** Dasar berkas repositori GitHub (pola Apktool M): https://raw.githubusercontent.com/<pemilik>/<repo>/main/ */
    private fun dasarRepo(): String = "https://raw.githubusercontent.com/" + BuildConfig.GITHUB_REPO + "/main/"

    /**
     * FIX291: urutan sumber mengikuti Apktool M. (1) URL_INFO_UPDATE bila diisi; (2) updates/update_<bahasa>.json di repositori GitHub
     * (bahasa aplikasi lebih dulu, lalu "en"), masing-masing dengan penanda waktu ?t= agar tidak memakai cache; (3) cadangan terakhir:
     * rilis terbaru GitHub (releases/latest).
     */
    private fun daftarAlamat(c: Context): List<String> {
        val t = System.currentTimeMillis()
        val hasil = ArrayList<String>()
        if (AppKonfigurasi.URL_INFO_UPDATE.startsWith("https://"))
            hasil.add(AppKonfigurasi.URL_INFO_UPDATE + (if (AppKonfigurasi.URL_INFO_UPDATE.contains("?")) "&" else "?") + "t=" + t)
        if (repoAda()) {
            val bahasa = if (BahasaAplikasi.tampilan(c) == 1) "en" else "id"
            for (b in listOf(bahasa, "en").distinct()) hasil.add(dasarRepo() + "updates/update_" + b + ".json?t=" + t)
            hasil.add("https://api.github.com/repos/" + BuildConfig.GITHUB_REPO + "/releases/latest")
        }
        return hasil
    }

    fun terkonfigurasi(): Boolean = AppKonfigurasi.URL_INFO_UPDATE.startsWith("https://") || repoAda()

    private fun ambilTeks(alamat: String): String? {
        val conn = URL(alamat).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.useCaches = false
        conn.requestMethod = "GET"
        conn.setRequestProperty("Accept", "application/vnd.github+json, application/json")
        conn.setRequestProperty("User-Agent", "JamPintarPro-Pembaruan")
        conn.setRequestProperty("Cache-Control", "no-cache")
        return try {
            if (conn.responseCode != 200) null
            else conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.takeIf { it.length <= BATAS_JSON }
        } finally { conn.disconnect() }
    }

    private fun bagianVersi(v: String): List<Int> =
        v.trim().removePrefix("v").removePrefix("V").split(".", "-", "+").take(4)
            .map { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }

    /** True bila nama versi [baru] lebih tinggi daripada [lama] (mis. 1.0.64 > 1.0.63). */
    private fun lebihBaruNama(baru: String, lama: String): Boolean {
        val a = bagianVersi(baru)
        val b = bagianVersi(lama)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /**
     * Mengubah JSON rilis GitHub (tag_name, assets, body) menjadi format yang dipakai pemeriksa
     * (versionCode, versionName, apkUrl, catatan). Rilis GitHub tidak memuat versionCode, jadi bila tag-nya
     * lebih tinggi daripada versi terpasang dipakai versionCode terpasang + 1 sebagai penanda "lebih baru";
     * kecocokan sebenarnya tetap diperiksa pada APK yang diunduh (harus punya versionCode lebih tinggi).
     */
    private fun normalisasi(c: Context, j: JSONObject): JSONObject {
        if (!j.has("tag_name")) return normalisasiJson(c, j)
        val tag = j.optString("tag_name").removePrefix("v").removePrefix("V")
        val sekarang = versiSaatIni(c)
        var apk = ""
        val aset = j.optJSONArray("assets")
        if (aset != null) {
            for (i in 0 until aset.length()) {
                val a = aset.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    val nama = a.optString("name")
                    val cocok = abiPerangkat().any { nama.contains(it, ignoreCase = true) }
                    if (apk.isEmpty() || cocok) apk = a.optString("browser_download_url")
                    if (cocok) break
                }
            }
        }
        // FIX304: tag berupa angka saja (mis. V819 = nomor putaran GitHub) dibandingkan dengan nomor build (versionCode) terpasang,
        // bukan dengan nama versi 1.0.89; tag bertitik (1.0.90) tetap dibandingkan sebagai nama versi.
        val angkaTag = if (!tag.contains('.')) tag.filter { it.isDigit() }.toIntOrNull() else null
        val baru = tag.isNotEmpty() &&
            apk.startsWith("https://github.com/" + BuildConfig.GITHUB_REPO + "/") &&
            (if (angkaTag != null) angkaTag > sekarang else lebihBaruNama(tag, namaVersi(c)))
        return JSONObject()
            .put("versionCode", if (baru) (angkaTag ?: (sekarang + 1)) else sekarang)
            .put("versionName", tag)
            .put("apkUrl", apk)
            .put("catatan", j.optString("body", ""))
    }

    @Suppress("DEPRECATION")
    private fun abiPerangkat(): List<String> =
        if (Build.VERSION.SDK_INT >= 21) Build.SUPPORTED_ABIS.toList() else listOf(Build.CPU_ABI)

    /** Mengubah JSON mandiri (kunci versionCode/build, versionName/name, apkUrl/url, catatan/changes, tanggal/date, ukuran/size) ke format baku. */
    private fun normalisasiJson(c: Context, j: JSONObject): JSONObject {
        fun pilihTeks(o: Any?): String = when (o) {
            is JSONObject -> {
                val kunci = if (BahasaAplikasi.tampilan(c) == 1) listOf("en", "id") else listOf("id", "en")
                kunci.map { o.optString(it, "") }.firstOrNull { it.isNotBlank() }
                    ?: o.keys().asSequence().map { o.optString(it, "") }.firstOrNull { it.isNotBlank() } ?: ""
            }
            null -> ""
            else -> o.toString()
        }
        fun pilihApk(o: Any?): String = when (o) {
            is JSONObject -> abiPerangkat().map { o.optString(it, "") }.firstOrNull { it.isNotBlank() }
                ?: o.optString("default", "")
            null -> ""
            else -> o.toString()
        }
        val kode = if (j.has("versionCode")) j.optInt("versionCode", 0) else j.optInt("build", 0)
        val nama = j.optString("versionName", j.optString("name", kode.toString()))
        val apk = pilihApk(if (j.has("apkUrl")) j.opt("apkUrl") else j.opt("url"))
        val catatan = pilihTeks(if (j.has("catatan")) j.opt("catatan") else j.opt("changes"))
        return JSONObject().put("versionCode", kode).put("versionName", nama).put("apkUrl", apk).put("catatan", catatan)
            .put("tanggal", pilihTeks(if (j.has("tanggal")) j.opt("tanggal") else j.opt("date")))
            .put("ukuran", pilihTeks(if (j.has("ukuran")) j.opt("ukuran") else j.opt("size")))
    }

    /** Pengguna memilih "Lewati versi ini": pemeriksaan otomatis tidak menawarkan versi [kode] lagi (pemeriksaan manual tetap menawarkan). */
    fun lewati(c: Context, kode: Int) { sp(c).edit().putInt("update_lewati", kode).apply() }
    fun dilewati(c: Context, kode: Int): Boolean = sp(c).getInt("update_lewati", 0) == kode

    fun otomatisAktif(c: Context): Boolean = sp(c).getBoolean("update_otomatis", true)
    fun setOtomatis(c: Context, v: Boolean) { sp(c).edit().putBoolean("update_otomatis", v).apply() }

    fun sudahWaktunyaCek(c: Context): Boolean =
        System.currentTimeMillis() - sp(c).getLong("update_terakhir_cek", 0L) >= JEDA_CEK_MS

    fun catatCek(c: Context) { sp(c).edit().putLong("update_terakhir_cek", System.currentTimeMillis()).apply() }

    @Suppress("DEPRECATION")
    fun versiSaatIni(c: Context): Int = try {
        val pi = c.packageManager.getPackageInfo(c.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (_: Exception) { 0 }

    fun namaVersi(c: Context): String = try {
        c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** Memeriksa versi terbaru di latar belakang; [hasil] dipanggil di thread utama. */
    fun periksa(c: Context, hasil: (Int, Info?) -> Unit) {
        val app = c.applicationContext
        if (!terkonfigurasi()) { hasil(STATUS_GAGAL, null); return }
        Thread {
            var status = STATUS_GAGAL
            var info: Info? = null
            for (alamat in daftarAlamat(app)) {
                try {
                    val teks = ambilTeks(alamat) ?: continue
                    val j = normalisasi(app, JSONObject(teks))
                    val kode = j.getInt("versionCode")
                    // FIX305: versi yang sudah pernah dipasang lewat pembaruan dianggap terbaru walau nomor tag/JSON tidak sama dengan nomor build APK-nya.
                    val namaRilis = j.optString("versionName", "")
                    if (kode <= versiSaatIni(app) || kode <= sp(app).getInt("update_diterima_kode", 0) ||
                        (namaRilis.isNotBlank() && namaRilis.equals(sp(app).getString("update_diterima_nama", ""), ignoreCase = true))) { status = STATUS_TERBARU; break }
                    var apk = j.optString("apkUrl")
                    // JSON repositori tanpa apkUrl: berkas APK berada di folder files/ repositori yang sama.
                    if (apk.isBlank() && alamat.startsWith(dasarRepo())) apk = dasarRepo() + "files/JamPintarPro.apk?t=" + System.currentTimeMillis()
                    // Hanya HTTPS agar berkas tidak bisa disusupi di jalan.
                    if (apk.startsWith("https://")) {
                        info = Info(kode, j.optString("versionName", kode.toString()), apk, j.optString("catatan"), j.optString("tanggal"), j.optString("ukuran"))
                        status = STATUS_ADA
                        break
                    }
                } catch (_: Exception) { }
            }
            Handler(Looper.getMainLooper()).post { hasil(status, info) }
        }.start()
    }

    private fun berkasApk(c: Context): File? {
        val dir = c.applicationContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return null
        return File(dir, NAMA_APK)
    }

    /** Memulai unduhan APK; mengembalikan id unduhan, atau -1 bila gagal dimulai. */
    fun unduh(c: Context, info: Info): Long {
        val app = c.applicationContext
        val tujuan = berkasApk(app) ?: return -1L
        try { tujuan.delete() } catch (_: Exception) { }
        val dm = app.getSystemService(DownloadManager::class.java) ?: return -1L
        val req = DownloadManager.Request(Uri.parse(info.apkUrl))
            .setTitle(app.getString(R.string.update_judul_unduhan, info.versionName))
            .setDescription(app.getString(R.string.update_deskripsi_unduhan))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setMimeType("application/vnd.android.package-archive")
            .setDestinationInExternalFilesDir(app, Environment.DIRECTORY_DOWNLOADS, NAMA_APK)
        val id = dm.enqueue(req)
        sp(app).edit()
            .putLong("update_unduhan_id", id)
            .putInt("update_target_versi", info.versionCode)
            .putString("update_target_nama", info.versionName)
            .apply()
        return id
    }

    fun batalkan(c: Context, id: Long) {
        try { c.applicationContext.getSystemService(DownloadManager::class.java)?.remove(id) } catch (_: Exception) { }
    }

    /** Mengembalikan [status DownloadManager atau -1, persen 0..100]. */
    fun progres(c: Context, id: Long): IntArray {
        try {
            val dm = c.applicationContext.getSystemService(DownloadManager::class.java) ?: return intArrayOf(-1, 0)
            dm.query(DownloadManager.Query().setFilterById(id)).use { k ->
                if (!k.moveToFirst()) return intArrayOf(-1, 0)
                val status = k.getInt(k.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val unduh = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = k.getLong(k.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val persen = if (total > 0) (unduh * 100 / total).toInt().coerceIn(0, 100) else 0
                return intArrayOf(status, persen)
            }
        } catch (_: Exception) { }
        return intArrayOf(-1, 0)
    }

    fun idUnduhan(c: Context): Long = sp(c).getLong("update_unduhan_id", -1L)

    /** True bila ada APK pembaruan yang sudah selesai diunduh, lebih baru dari versi terpasang, dan belum dipasang. */
    fun siapDipasang(c: Context): Boolean {
        val id = idUnduhan(c)
        if (id < 0) return false
        if (sp(c).getInt("update_target_versi", 0) <= versiSaatIni(c)) return false
        if (berkasApk(c)?.exists() != true) return false
        return progres(c, id)[0] == DownloadManager.STATUS_SUCCESSFUL
    }

    /**
     * FIX305: dipanggil setiap aplikasi dibuka. Bila aplikasi sudah diperbarui sesudah pemasangan dimulai (atau sesudah APK diunduh),
     * versi target dicatat sebagai "diterima" sehingga tidak ditawarkan lagi, lalu APK dan catatan unduhan dibersihkan.
     */
    fun sinkronkanSetelahPembaruan(c: Context) {
        try {
            val app = c.applicationContext
            val s = sp(app)
            val target = s.getInt("update_target_versi", 0)
            if (target <= 0) return
            @Suppress("DEPRECATION")
            val terakhir = app.packageManager.getPackageInfo(app.packageName, 0).lastUpdateTime
            val mulai = s.getLong("update_waktu_pasang", 0L)
            val berkas = berkasApk(app)
            val sesudahBerkas = berkas != null && berkas.exists() && terakhir > berkas.lastModified()
            if ((mulai > 0L && terakhir >= mulai) || sesudahBerkas) {
                s.edit().putInt("update_diterima_kode", maxOf(target, s.getInt("update_diterima_kode", 0)))
                    .putString("update_diterima_nama", s.getString("update_target_nama", "") ?: "")
                    .remove("update_unduhan_id").remove("update_target_versi").remove("update_target_nama").remove("update_waktu_pasang").apply()
                try { berkas?.delete() } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    /** Menghapus APK pembaruan lama setelah aplikasi sudah berada di versi tersebut atau lebih baru. */
    fun bersihkan(c: Context) {
        try {
            if (sp(c).getInt("update_target_versi", 0) in 1..versiSaatIni(c)) {
                berkasApk(c)?.delete()
                sp(c).edit().remove("update_unduhan_id").remove("update_target_versi").apply()
            }
        } catch (_: Exception) { }
    }

    /** Nomor build APK yang terakhir diperiksa saat memasang; -1 bila berkas bukan APK aplikasi ini. */
    fun kodeArsipTerakhir(c: Context): Int = sp(c).getInt("update_kode_arsip", -1)

    @Suppress("DEPRECATION")
    fun pasang(c: Context): Int {
        val app = c.applicationContext
        val f = berkasApk(app)
        if (f == null || !f.exists()) return PASANG_BERKAS_TIDAK_ADA
        // FIX304: izin "pasang dari sumber ini" diperiksa lebih dulu agar layar izin selalu muncul, sebelum pemeriksaan isi berkas.
        if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) return PASANG_BUTUH_IZIN
        // Pastikan berkas benar-benar APK aplikasi ini dan lebih baru dari yang terpasang.
        sp(app).edit().putInt("update_kode_arsip", -1).apply()
        val arsip = try { app.packageManager.getPackageArchiveInfo(f.absolutePath, 0) } catch (_: Exception) { null }
        if (arsip == null || arsip.packageName != app.packageName) return PASANG_BERKAS_TIDAK_VALID
        val kodeArsip = if (Build.VERSION.SDK_INT >= 28) arsip.longVersionCode.toInt() else arsip.versionCode
        sp(app).edit().putInt("update_kode_arsip", kodeArsip).apply()
        if (kodeArsip <= versiSaatIni(app)) return PASANG_BERKAS_TIDAK_VALID
        return try {
            val installer = app.packageManager.packageInstaller
            val sesi = installer.openSession(installer.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)))
            sesi.use { s ->
                FileInputStream(f).use { masuk ->
                    s.openWrite("pembaruan.apk", 0, f.length()).use { keluar ->
                        masuk.copyTo(keluar)
                        s.fsync(keluar)
                    }
                }
                val i = Intent(app, UpdateInstallReceiver::class.java).setAction(AKSI_HASIL_PASANG)
                val flag = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                s.commit(PendingIntent.getBroadcast(app, 0, i, flag).intentSender)
            }
            sp(app).edit().putLong("update_waktu_pasang", System.currentTimeMillis()).apply()
            PASANG_MULAI
        } catch (_: Exception) {
            PASANG_GAGAL
        }
    }
}
