package com.novan.bateraibicara

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.AudioAttributes
import android.os.Bundle
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/** Pemutar pengingat azan yang berjalan dari alarm meski layar mati. */
class PrayerAlarmService : Service() {

    override fun attachBaseContext(newBase: Context) {
        // FIX70: teks notifikasi layanan ini mengikuti bahasa tampilan utama aplikasi, bukan bahasa sistem HP.
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    private var player: MediaPlayer? = null
    @Volatile private var kunciMandiri: String = ""
    private val gemaMandiri by lazy { GemaAudio(this) }

    /** FIX300: terapkan volume mandiri (pengali) dan efek gema pilihan pengguna pada pemutar yang baru siap, sebelum diputar. */
    private fun terapkanSuaraMandiri(mp: MediaPlayer) {
        val k = kunciMandiri
        if (k.isBlank()) return
        val pp = PrayerPrefs(this)
        try { val v = pp.volumeMandiri(k) / 100f; mp.setVolume(v, v) } catch (_: Exception) { }
        try { gemaMandiri.terapkanKunci(mp.audioSessionId, pp.gemaMandiri(k), pp.gemaKekuatan(k)) } catch (_: Exception) { }
    }
    /** FIX311: pemutar gema nyata (MediaCodec + AudioTrack + DSP pada data suara), dipakai bila pengguna memilih efek gema untuk suara ini. */
    private var pemutarGema: PemutarAudio? = null

    private fun gemaMandiriAktif(): Pair<String, Int>? {
        val k = kunciMandiri
        if (k.isBlank()) return null
        val pp = PrayerPrefs(this)
        val g = pp.gemaMandiri(k); val kuat = pp.gemaKekuatan(k)
        return if (g != "normal" && kuat > 0) Pair(g, kuat) else null
    }

    /**
     * Coba putar [uri] dengan gema nyata. Mengembalikan true bila pemutar gema dijalankan (selesai dilaporkan lewat [selesai]);
     * [cadangan] dipanggil bila pemutar gagal sebelum sempat berbunyi, agar azan tetap terdengar lewat jalur biasa.
     */
    private fun mulaiGema(uri: Uri, attrs: AudioAttributes, selesai: () -> Unit, cadangan: () -> Unit, siap: (PemutarAudio) -> Unit = { }): Boolean {
        val g = gemaMandiriAktif() ?: return false
        return try {
            val k = kunciMandiri
            val pp = PrayerPrefs(this)
            var terdengar = false
            val pm = PemutarMono(true, g.first, g.second)
            pm.setAudioAttributes(attrs)
            pm.setDataSource(this, uri, emptyMap())
            pm.setOnCompletionListener { selesai() }
            pm.setOnErrorListener { _, _, _ -> if (terdengar) selesai() else { try { pemutarGema?.release() } catch (_: Exception) { }; pemutarGema = null; cadangan() }; true }
            pm.setOnPreparedListener { x ->
                try {
                    val v = pp.volumeMandiri(k) / 100f
                    x.setVolume(v, v)
                    x.start()
                    terdengar = true
                    siap(x)
                } catch (_: Exception) { if (terdengar) selesai() else { pemutarGema = null; cadangan() } }
            }
            pemutarGema = pm
            pm.prepareAsync()
            true
        } catch (_: Throwable) { pemutarGema = null; false }
    }

    private fun sedangBunyiSemua(): Boolean = try { player?.isPlaying == true || pemutarGema?.isPlaying == true } catch (_: Exception) { false }
    private fun adaPemutar(): Boolean = player != null || pemutarGema != null
    private fun jedaPemutar() { try { player?.let { if (it.isPlaying) it.pause() } } catch (_: Exception) { }; try { pemutarGema?.let { if (it.isPlaying) it.pause() } } catch (_: Exception) { } }
    private fun lanjutPemutar() { try { player?.let { if (!it.isPlaying) it.start() } } catch (_: Exception) { }; try { pemutarGema?.let { if (!it.isPlaying) it.start() } } catch (_: Exception) { } }
    private fun durasiPemutar(): Int = try { player?.duration ?: pemutarGema?.durasiMs ?: -1 } catch (_: Exception) { -1 }
    private fun posisiPemutar(): Int = try { player?.currentPosition ?: pemutarGema?.posisiMs ?: 0 } catch (_: Exception) { 0 }

    private var isTestPlayback = false
    private var reminderTts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var serviceAktif = true
    /** FIX242: true hanya selama tes suara benar-benar berjalan di layanan ini (status prefs bisa basi bila proses mati). */
    @Volatile private var tesDijeda = false

    companion object {
        @Volatile var tesBerjalan = false
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action.orEmpty()
        if (action == "com.novan.jambicarapro.PAUSE_TEST_PLAYBACK" || action == "com.novan.jambicarapro.RESUME_TEST_PLAYBACK" || action == "com.novan.jambicarapro.STOP_TEST_PLAYBACK" || action == "com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK") {
            val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
            if (!state.getBoolean("test_playback_active", false) || !tesBerjalan) {
                // FIX242: status tes basi (proses pernah mati) atau tes sudah selesai; bersihkan dan jangan berpura-pura menjeda.
                state.edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply()
                if (!tesBerjalan) { stopSelf(startId) }
                return START_NOT_STICKY
            }
            val kunciTes = state.getString("test_playback_key", "") ?: ""
            when (action) {
                "com.novan.jambicarapro.PAUSE_TEST_PLAYBACK" -> {
                    try {
                        jedaTes(kunciTes, startId)
                        state.edit().putBoolean("test_playback_paused", true).apply()
                    } catch (_: Exception) { }
                }
                "com.novan.jambicarapro.RESUME_TEST_PLAYBACK" -> {
                    try {
                        lanjutTes(kunciTes, startId)
                        state.edit().putBoolean("test_playback_paused", false).apply()
                    } catch (_: Exception) { }
                }
                "com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK" -> {
                    try {
                        if (tesDijeda) {
                            lanjutTes(kunciTes, startId)
                            state.edit().putBoolean("test_playback_paused", false).apply()
                        } else {
                            jedaTes(kunciTes, startId)
                            state.edit().putBoolean("test_playback_paused", true).apply()
                        }
                    } catch (_: Exception) { }
                }
                else -> { state.edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply(); stopPlayback(); try { reminderTts?.stop() } catch (_: Exception) { }; if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true); stopSelf(startId); return START_NOT_STICKY }
            }
            updateTestNotification(state.getBoolean("test_playback_paused", false))
            return START_NOT_STICKY
        }
        if (action == "com.novan.jambicarapro.STOP_PRAYER_SOUND") {
            stopPlayback()
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (action == "com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK") {
            try {
                if (adaPemutar()) {
                    handler.removeCallbacksAndMessages(null)
                    if (sedangBunyiSemua()) { jedaPemutar(); handler.postDelayed({ stopSelf() }, 600_000L) }
                    else {
                        lanjutPemutar()
                        val sisa = (durasiPemutar() - posisiPemutar()).coerceAtLeast(0) + 5000L
                        handler.postDelayed({ stopSelf() }, sisa)
                    }
                }
            } catch (_: Exception) { }
            return START_NOT_STICKY
        }
        val key = intent?.getStringExtra("prayer_key") ?: "subuh"
        val test = intent?.getBooleanExtra("test", false) ?: false
        jagaHandler.removeCallbacks(jagaLayanan); jagaHandler.postDelayed(jagaLayanan, 90_000L)
        if (ModeAcara.aktif(this)) { stopSelf(startId); return START_NOT_STICKY }
        val pp = PrayerPrefs(this)
        // FIX288: semua pengingat/azan/tarhim/sahur/berbuka hanya dibunyikan satu kali. Sebagian HP menembakkan alarm yang sama dua kali
        // (atau menjadwalkan ulang sebelum waktunya); permintaan kembar dalam 2 menit diabaikan. Iqomah punya penjaga sendiri (10 menit).
        if (!test && !(intent?.getBooleanExtra("iqomah_reminder", false) ?: false)) {
            val jenis = when {
                intent?.getBooleanExtra("advance_reminder", false) == true -> "advance_" + key
                intent?.getBooleanExtra("tarhim_reminder", false) == true -> "tarhim_" + key
                intent?.getBooleanExtra("sahur_reminder", false) == true -> "sahur"
                intent?.getBooleanExtra("berbuka_reminder", false) == true -> "berbuka"
                else -> "azan_" + key
            }
            val spKembar = getSharedPreferences("pengingat_sekali", MODE_PRIVATE)
            val kini = System.currentTimeMillis()
            if (kini - spKembar.getLong(jenis, 0L) in 0 until 120_000L) return START_NOT_STICKY
            spKembar.edit().putLong(jenis, kini).apply()
        }
        isTestPlayback = test
        // FIX300: kunci pengaturan volume mandiri dan gema untuk suara yang akan diputar.
        kunciMandiri = when {
            intent?.getBooleanExtra("advance_reminder", false) == true -> "advance_" + key
            intent?.getBooleanExtra("tarhim_reminder", false) == true -> "tarhim_" + key
            intent?.getBooleanExtra("iqomah_reminder", false) == true -> "iqomah_" + key
            intent?.getBooleanExtra("sahur_reminder", false) == true -> "sahur"
            intent?.getBooleanExtra("berbuka_reminder", false) == true -> "berbuka"
            else -> "azan_" + key
        }
        if (test) {
            // FIX242: tes baru selalu membersihkan sisa tes sebelumnya (pemutar, melodi, ucapan, penutup) agar jeda/lanjut hanya menyasar tes ini.
            tesBerjalan = true
            tesDijeda = false
            Melodi.hentikanSemua()
            stopPlayback()
            batalkanPenutupTts()
            kunciMelodiPengingatPuasa = null
            try { reminderTts?.stop() } catch (_: Exception) { }
        }
        val berbukaReminder = intent?.getBooleanExtra("berbuka_reminder", false) ?: false
        if (berbukaReminder) {
            val testBerbuka = intent?.getBooleanExtra("test", false) ?: false
            if (!testBerbuka && (!pp.enabled || !pp.berbukaReminderEnabled || !pp.locationSet)) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val offset = intent?.getIntExtra("berbuka_offset", pp.berbukaOffsetMinutes) ?: pp.berbukaOffsetMinutes
            val waktu = when {
                offset < 0 -> ("" + (-offset) + " menit sebelum Maghrib")
                offset > 0 -> ("" + (offset) + " menit setelah Maghrib")
                else -> "tepat saat Maghrib"
            }
            val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
            val message = FastingSchedule.berbukaMessage(pp.fastingType, offset, bahasaAktif, testBerbuka)
            val notificationMessage = FastingSchedule.berbukaMessage(pp.fastingType, offset, if (BahasaAplikasi.tampilan(this) == 1) 1 else 0, testBerbuka)
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(BahasaAplikasi.teks(this, if (testBerbuka) "Tes suara pengingat berbuka puasa" else "Pengingat waktu berbuka puasa"))
                .setContentText(notificationMessage).setContentIntent(open).setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            pasangBungkam(testBerbuka)
            if (testBerbuka) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false).putString("test_playback_key", "berbuka").apply()
            mulaiDenganMelodiPuasa("berbuka", startId, testBerbuka) {
                when (pp.reminderSoundMode("berbuka")) {
                    1, 3 -> playEmbeddedBerbukaSound(startId, testBerbuka)
                    2 -> {
                        val custom = pp.sound("berbuka")
                        if (custom.isNotBlank()) playSound(custom, pp.volumeMode, startId, "berbuka", testBerbuka)
                        else playEmbeddedBerbukaSound(startId, testBerbuka)
                    }
                    else -> playSound(pp.globalSound, pp.volumeMode, startId, "berbuka", testBerbuka)
                }
            }
            return START_NOT_STICKY
        }
        val sahurReminder = intent?.getBooleanExtra("sahur_reminder", false) ?: false
        if (sahurReminder) {
            val testSahur = intent?.getBooleanExtra("test", false) ?: false
            if (!testSahur && (!pp.enabled || !pp.sahurReminderEnabled || !pp.locationSet)) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val lead = intent?.getIntExtra("sahur_minutes", pp.sahurReminderMinutes) ?: pp.sahurReminderMinutes
            val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
            val message = FastingSchedule.sahurMessage(pp.fastingType, lead, bahasaAktif, testSahur)
            val notificationMessage = FastingSchedule.sahurMessage(pp.fastingType, lead, if (BahasaAplikasi.tampilan(this) == 1) 1 else 0, testSahur)
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(BahasaAplikasi.teks(this, if (testSahur) "Tes suara pemberitahuan sahur" else "Pengingat waktu sahur")).setContentText(notificationMessage)
                .setContentIntent(open).setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            pasangBungkam(testSahur)
            if (testSahur) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false).putString("test_playback_key", "sahur").apply()
            mulaiDenganMelodiPuasa("sahur", startId, testSahur) {
                when (pp.reminderSoundMode("sahur")) {
                    1 -> ucapkanPengingatAwal(message, startId, testSahur, UcapanSholat.locale(bahasaAktif))
                    2 -> {
                        val custom = pp.sound("sahur")
                        if (custom.isNotBlank()) playSound(custom, pp.volumeMode, startId, "sahur", testSahur)
                        else playEmbeddedSahurSound(startId, testSahur)
                    }
                    3 -> playEmbeddedSahurSound(startId, testSahur)
                    else -> playSound(pp.globalSound, pp.volumeMode, startId, "sahur", testSahur)
                }
            }
            return START_NOT_STICKY
        }
        val tarhimReminder = intent?.getBooleanExtra("tarhim_reminder", false) ?: false
        if (tarhimReminder) {
            if (!test && (!pp.enabled || !pp.tarhimAktif(key))) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val inggris = BahasaAplikasi.tampilan(this) == 1
            val labelTarhim = if (inggris) UcapanSholat.nama(key, 1) else PrayerAlarm.label(key)
            val judulTarhim = if (inggris) (if (test) "Tarhim test: " else "Tarhim before prayer: ") + labelTarhim
                else (if (test) "Tes Tarhim sebelum salat " else "Tarhim sebelum salat ") + labelTarhim
            val bukaTarhim = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notifTarhim = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(judulTarhim)
                .setContentIntent(bukaTarhim).setAutoCancel(true).setOngoing(false).also { tambahKendaliPutar(it, test) }.build()
            startForeground(809, notifTarhim)
            pasangBungkam(test, 480_000L)
            if (test) {
                batalkanPenutupTts()
                getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                    .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false)
                    .putString("test_playback_key", "tarhim_" + key).apply()
                updateTestNotification(false)
            }
            stopPlayback()
            // FIX315: berkas Tarhim pilihan pengguna dipakai bila masih terbaca; bila tidak, Tarhim bawaan.
            val berkasTarhim = pp.tarhimBerkas(key)
            val bisaDibuka = berkasTarhim.isNotBlank() && try { contentResolver.openFileDescriptor(Uri.parse(berkasTarhim), "r")?.use { true } ?: false } catch (_: Throwable) { false }
            if (bisaDibuka) playSound(berkasTarhim, pp.volumeMode, startId, "tarhim_" + key, test)
            else playRawSound(R.raw.tarhim_sebelum_sholat, startId, test, batasMs = 480_000L)
            return START_NOT_STICKY
        }
        // FIX277: Iqomah setelah azan, audio iqomah Masjidil Haram (sekitar 40 detik).
        val iqomahReminder = intent?.getBooleanExtra("iqomah_reminder", false) ?: false
        if (iqomahReminder) {
            if (!test && (!pp.enabled || !pp.iqomahAktif(key))) { stopSelf(startId); return START_NOT_STICKY }
            // FIX282: iqomah hanya diputar satu kali. Sebagian HP (bukan Samsung) menembakkan alarm dua kali atau menjadwalkan ulang
            // sebelum waktunya, sehingga alarm yang sama datang lagi; permintaan kedua dalam 10 menit diabaikan.
            if (!test) {
                val sp = getSharedPreferences("iqomah_sekali", MODE_PRIVATE)
                val sekarang = System.currentTimeMillis()
                val terakhir = sp.getLong(key, 0L)
                val sedangBunyi = sedangBunyiSemua()
                if (sedangBunyi || (sekarang - terakhir in 0 until 10 * 60_000L)) { if (!sedangBunyi) stopSelf(startId); return START_NOT_STICKY }
                sp.edit().putLong(key, sekarang).apply()
            }
            createChannel()
            val inggrisIq = BahasaAplikasi.tampilan(this) == 1
            val labelIq = if (inggrisIq) UcapanSholat.nama(key, 1) else PrayerAlarm.label(key)
            val judulIq = if (inggrisIq) (if (test) "Iqomah test: " else "Iqomah: ") + labelIq
                else (if (test) "Tes iqomah " else "Iqomah ") + labelIq
            val bukaIq = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notifIq = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(judulIq)
                .setContentIntent(bukaIq).setAutoCancel(true).setOngoing(false).also { tambahKendaliPutar(it, test) }.build()
            // FIX279: id 809 sama dengan notifikasi tes; dahulu 810 membuat notifikasi tes 809 tertinggal setelah iqomah selesai.
            startForeground(809, notifIq)
            pasangBungkam(test, 120_000L)
            if (test) {
                batalkanPenutupTts()
                getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                    .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false)
                    .putString("test_playback_key", "iqomah_" + key).apply()
                updateTestNotification(false)
            }
            stopPlayback()
            playRawSound(R.raw.iqomah_masjidil_haram, startId, test, batasMs = 120_000L)
            return START_NOT_STICKY
        }
        val advanceReminder = intent?.getBooleanExtra("advance_reminder", false) ?: false
        if (advanceReminder) {
            if (!test && (!pp.enabled || !pp.advanceReminder(key))) { stopSelf(startId); return START_NOT_STICKY }
            createChannel()
            val lead = pp.advanceMinutes(key)
            // Notifikasi dan TTS pengingat mengikuti bahasa tampilan utama aplikasi.
            val bahasaTampilanInggris = BahasaAplikasi.tampilan(this) == 1
            val labelNotifikasi = if (bahasaTampilanInggris) UcapanSholat.nama(key, 1) else PrayerAlarm.label(key)
            val title = if (bahasaTampilanInggris) {
                if (test) ("Tes pengingat sebelum salat: " + (labelNotifikasi)) else ("Pengingat sebelum salat: " + (labelNotifikasi))
            } else {
                if (test) ("Tes suara pengingat sebelum salat " + (labelNotifikasi)) else ("Pengingat sebelum salat " + (labelNotifikasi))
            }
            val message = if (bahasaTampilanInggris) {
                ("Waktu salat " + (labelNotifikasi) + " tinggal " + (lead) + " menit lagi.")
            } else {
                ("Waktu salat " + (labelNotifikasi) + " tinggal " + (lead) + " menit lagi.")
            }
            val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
            val pesanSuara = UcapanSholat.pengingatAwal(key, lead, bahasaAktif)
            val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this))
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title).setContentText(message).setContentIntent(open)
                .setAutoCancel(true).setOngoing(false).build()
            startForeground(809, notification)
            pasangBungkam(test)
            if (test) {
                // Tes baru: bersihkan sisa ucapan/penutup tes sebelumnya agar jeda dan lanjut selalu menyasar tes ini saja.
                batalkanPenutupTts()
                try { reminderTts?.stop() } catch (_: Exception) { }
                getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
                    .putBoolean("test_playback_active", true).putBoolean("test_playback_paused", false)
                    .putString("test_playback_key", ("advance_" + (key))).apply()
                updateTestNotification(false)
            }
            mulaiDenganMelodiPuasa("advance_" + key, startId, test) {
                when (pp.advanceSoundMode(key)) {
                    1 -> playEmbeddedAdvanceSound(key, startId, test)
                    2 -> {
                        val customSound = pp.advanceSound(key)
                        if (customSound.isNotBlank()) playSound(customSound, pp.volumeMode, startId, "advance_custom", test)
                        else ucapkanPengingatAwal(pesanSuara, startId, test, UcapanSholat.locale(bahasaAktif))
                    }
                    else -> ucapkanPengingatAwal(pesanSuara, startId, test, UcapanSholat.locale(bahasaAktif))
                }
            }
            return START_NOT_STICKY
        }
        if (test) getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit()
            .putBoolean("test_playback_active", true)
            .putBoolean("test_playback_paused", false)
            .putString("test_playback_key", key)
            .apply()
        if (!test && (!pp.enabled || !pp.reminder(key))) { stopSelf(startId); return START_NOT_STICKY }
        createChannel()
        val title = BahasaAplikasi.teks(this, if (test) ("Tes suara azan " + PrayerAlarm.label(key)) else ("Saatnya menunaikan sholat " + PrayerAlarm.label(key)))
        val open = PendingIntent.getActivity(this, 800, Intent(this, PrayerActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND")
        val stopPi = PendingIntent.getService(this, 810, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = n.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(BahasaAplikasi.teks(this, if (pp.notifyOnly && !test) "Pengingat waktu sholat" else "Pengingat waktu sholat dan suara azan"))
            .setContentIntent(open).setAutoCancel(false).setOngoing(true)
        val toggleIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK")
        val togglePi = PendingIntent.getService(this, 811, toggleIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        if (test) {
            val pauseIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.PAUSE_TEST_PLAYBACK")
            val resumeIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.RESUME_TEST_PLAYBACK")
            val pausePi = PendingIntent.getService(this, 812, pauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            val resumePi = PendingIntent.getService(this, 813, resumeIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(android.R.drawable.ic_media_pause, BahasaAplikasi.teks(this, "Jeda tes suara azan"), pausePi)
            builder.addAction(android.R.drawable.ic_media_play, BahasaAplikasi.teks(this, "Lanjutkan tes suara azan"), resumePi)
            val stopTestIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_TEST_PLAYBACK")
            val stopTestPi = PendingIntent.getService(this, 814, stopTestIntent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan tes suara azan"), stopTestPi)
        } else {
            builder.addAction(android.R.drawable.ic_media_play, BahasaAplikasi.teks(this, "Jeda atau lanjutkan suara azan"), togglePi)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan suara azan"), stopPi)
        }
        val notification = builder.build()
        startForeground(809, notification)
        if (pp.notifyOnly && !test) { handler.postDelayed({ stopSelf(startId) }, 2500); return START_NOT_STICKY }
        // FIX306: DND salat tidak boleh membisukan azan (HP non-Samsung tanpa pengecualian aplikasi).
        if (!test) {
            val usageAzan = usageUntukVolume(pp.volumeMode)
            DndAzan.izinkanSuaraAzan(this, usageAzan)
            handler.postDelayed({ DndAzan.izinkanSuaraAzan(this@PrayerAlarmService, usageAzan) }, 3_000L)
            handler.postDelayed({ DndAzan.izinkanSuaraAzan(this@PrayerAlarmService, usageAzan) }, 8_000L)
        }
        val putarSuaraPengingat = {
            if (key == "imsak" || key == "terbit" || key == "dhuha" || key == "tahajud") {
                val modeSuara = pp.reminderSoundMode(key)
                // FIX238: bila audio bawaan Tahajud belum ada di aplikasi, jatuh ke suara azan/umum.
                val bawaanTidakAda = key == "tahajud" && (modeSuara == 1 || modeSuara == 3) && AudioBawaanPengingat.id(this, key) <= 0
                when (if (bawaanTidakAda) 0 else modeSuara) {
                    1 -> playEmbeddedReminderSound(key, startId, test)
                    3 -> playEmbeddedReminderSound(key, startId, test)
                    2 -> {
                        val ownSound = pp.sound(key)
                        if (ownSound.isNotBlank()) playSound(ownSound, pp.volumeMode, startId, key, test)
                        else playSound(pp.globalSound, pp.volumeMode, startId, key, test)
                    }
                    else -> playSound(pp.globalSound, pp.volumeMode, startId, key, test)
                }
            } else {
                playSound(pp.sound(key).ifBlank { pp.globalSound }, pp.volumeMode, startId, key, test)
            }
        }
        if (key in setOf("imsak", "terbit", "dhuha", "tahajud")) {
            mulaiDenganMelodiPuasa(key, startId, test, putarSuaraPengingat)
        } else putarSuaraPengingat()
        pasangBungkam(test)
        return START_NOT_STICKY
    }

    /**
     * Memutar audio bawaan (res/raw) lewat saluran volume pilihan pengguna.
     * Atribut audio HARUS dipasang pada MediaPlayer() sebelum sumber data/prepare; MediaPlayer.create()
     * sudah memanggil prepare sehingga setAudioAttributes sesudahnya ditolak sistem dan suara jatuh
     * ke volume media.
     */
    private fun playRawSound(resource: Int, startId: Int, test: Boolean, batasMs: Long = 180_000L, afterCompletion: (() -> Unit)? = null) {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(usageUntukVolume(PrayerPrefs(this).volumeMode))
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            val aksiSelesai = {
                if (afterCompletion != null) afterCompletion()
                else if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test)
                else { if (test) clearTestState(); stopSelf(startId) }
            }
            val jalurBiasa = {
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    val afd = this@PrayerAlarmService.resources.openRawResourceFd(resource)
                    try { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                    setOnCompletionListener { aksiSelesai() }
                    setOnErrorListener { _, _, _ -> aksiSelesai(); true }
                    prepare(); terapkanSuaraMandiri(this); start()
                }
            }
            // FIX311: bila gema dipilih, putar lewat pemutar gema nyata (DSP pada data suara); gagal -> jalur biasa.
            if (!mulaiGema(Uri.parse("android.resource://" + packageName + "/" + resource), attrs, { aksiSelesai() }, { try { jalurBiasa() } catch (_: Exception) { aksiSelesai() } })) jalurBiasa()
            handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, batasMs)
        } catch (_: Exception) {
            if (test) clearTestState()
            stopSelf(startId)
        }
    }

    private fun playEmbeddedReminderSound(key: String, startId: Int, test: Boolean) {
        stopPlayback()
        val resource = AudioBawaanPengingat.id(this, key)
        if (resource <= 0) { playSound(PrayerPrefs(this).globalSound, PrayerPrefs(this).volumeMode, startId, key, test); return }
        playRawSound(resource, startId, test)
    }

    private fun playEmbeddedBerbukaSound(startId: Int, test: Boolean) {
        stopPlayback()
        val pp = PrayerPrefs(this)
        val bahasa = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
        val message = FastingSchedule.berbukaMessage(pp.fastingType, pp.berbukaOffsetMinutes, bahasa, test)
        // Audio bawaan tetap diputar, kemudian TTS menyebutkan jenis puasa yang dipilih.
        playRawSound(R.raw.pemberitahuan_berbuka_puasa, startId, test) {
            ucapkanPengingatAwal(message, startId, test, UcapanSholat.locale(bahasa))
        }
    }

    private fun playEmbeddedSahurSound(startId: Int, test: Boolean) {
        stopPlayback()
        val pp = PrayerPrefs(this)
        val bahasa = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
        val message = FastingSchedule.sahurMessage(pp.fastingType, pp.sahurReminderMinutes, bahasa, test)
        // Audio bawaan tetap diputar, kemudian TTS menyebutkan jenis puasa yang dipilih.
        playRawSound(R.raw.pemberitahuan_sahur, startId, test) {
            ucapkanPengingatAwal(message, startId, test, UcapanSholat.locale(bahasa))
        }
    }

    private fun playEmbeddedAdvanceSound(key: String, startId: Int, test: Boolean) {
        stopPlayback()
        val resource = when (key) {
            "subuh" -> R.raw.pengingat_sebelum_subuh
            "dzuhur" -> R.raw.pengingat_sebelum_dzuhur
            "ashar" -> R.raw.pengingat_sebelum_ashar
            "maghrib" -> R.raw.pengingat_sebelum_maghrib
            "isya" -> R.raw.pengingat_sebelum_isya
            else -> R.raw.pengingat_sebelum_subuh
        }
        playRawSound(resource, startId, test)
    }

    /** Padanan jenis stream lama; beberapa mesin suara (TTS) hanya menaati parameter stream ini. */
    private fun streamUntukVolume(mode: Int): Int = when (mode) {
        0 -> AudioManager.STREAM_MUSIC
        1 -> AudioManager.STREAM_ALARM
        2 -> AudioManager.STREAM_NOTIFICATION
        3 -> AudioManager.STREAM_RING
        4 -> if (Build.VERSION.SDK_INT >= 26) 10 else AudioManager.STREAM_MUSIC // STREAM_ACCESSIBILITY
        5 -> AudioManager.STREAM_VOICE_CALL
        6 -> AudioManager.STREAM_SYSTEM
        else -> AudioManager.STREAM_ALARM
    }

    private fun usageUntukVolume(mode: Int): Int = when (mode) {
        0 -> AudioAttributes.USAGE_MEDIA
        1 -> AudioAttributes.USAGE_ALARM
        2 -> AudioAttributes.USAGE_NOTIFICATION
        3 -> AudioAttributes.USAGE_NOTIFICATION_RINGTONE
        4 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
        5 -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        6 -> AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
        else -> AudioAttributes.USAGE_ALARM
    }

    private fun playSound(uriString: String, volumeMode: Int, startId: Int, key: String, test: Boolean) {
        stopPlayback()
        try {
            val usage = usageUntukVolume(volumeMode)
            val attrs = AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            if (uriString.isNotBlank()) {
                val aksiSelesaiB = { if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) } }
                val jalurBiasaB = {
                    player = MediaPlayer().apply {
                        setAudioAttributes(attrs)
                        setDataSource(this@PrayerAlarmService, Uri.parse(uriString))
                        setOnCompletionListener { aksiSelesaiB() }
                        setOnErrorListener { _, _, _ -> aksiSelesaiB(); true }
                        prepare(); terapkanSuaraMandiri(this); start()
                    }
                }
                // FIX311: gema nyata untuk berkas mandiri; pengaman durasi dipasang setelah pemutar siap (durasi dibaca dari berkas).
                val gemaJalan = mulaiGema(Uri.parse(uriString), attrs, { aksiSelesaiB() }, {
                    try { jalurBiasaB(); val d = durasiPemutar(); handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, if (d > 0) (d + 15_000L).coerceAtMost(5_400_000L) else 1_800_000L) } catch (_: Exception) { aksiSelesaiB() }
                }) { pm ->
                    val d = pm.durasiMs
                    handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, if (d > 0) (d + 15_000L + ((GemaDsp.ekorMs(gemaMandiriAktif()?.first ?: "normal")).toLong())).coerceAtMost(5_400_000L) else 1_800_000L)
                }
                if (!gemaJalan) jalurBiasaB()
                if (gemaJalan) return
                // FIX299: dulu berkas mandiri dipotong paksa pada menit ke-3 walau audionya lebih panjang. Kini pemutus pengaman
                // mengikuti durasi berkas (ditambah 15 detik cadangan, paling lama 90 menit); bila durasi tak terbaca, 30 menit.
                val durasi = try { player?.duration ?: -1 } catch (_: Exception) { -1 }
                val batas = if (durasi > 0) (durasi + 15_000L).coerceAtMost(5_400_000L) else 1_800_000L
                handler.postDelayed({ if (test) clearTestState(); stopSelf(startId) }, batas)
            } else {
                // Audio azan bawaan dibawa dari APK referensi: azan Subuh dan azan umum.
                val resource = if (key == "subuh") R.raw.azan_subuh else R.raw.azan_biasa
                val aksiSelesaiC = { if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) } }
                val jalurBiasaC = {
                    player = MediaPlayer().apply {
                        setAudioAttributes(attrs)
                        val afd = this@PrayerAlarmService.resources.openRawResourceFd(resource)
                        try { setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
                        setOnCompletionListener { aksiSelesaiC() }
                        setOnErrorListener { _, _, _ -> aksiSelesaiC(); true }
                        prepare(); terapkanSuaraMandiri(this); start()
                    }
                }
                // FIX311: azan bawaan dengan gema nyata; gagal -> jalur biasa.
                if (!mulaiGema(Uri.parse("android.resource://" + packageName + "/" + resource), attrs, { aksiSelesaiC() }, { try { jalurBiasaC() } catch (_: Exception) { aksiSelesaiC() } })) jalurBiasaC()
                handler.postDelayed({ stopSelf(startId) }, 300_000L)
            }
        } catch (_: Exception) {
            // Berkas suara kustom bisa hilang atau izin aksesnya dicabut; azan bawaan tetap diputar
            // agar pengguna tunanetra tidak kehilangan pengingat waktu sholat.
            if (uriString.isNotBlank() && key != "advance_custom") playSound("", volumeMode, startId, key, test) else stopSelf(startId)
        }
    }

    /**
     * FIX74: menelungkupkan HP menghentikan azan, semua pengingat (awal, sahur, berbuka, Imsak, Terbit, Dhuha, dll.)
     * dan ucapan pengingat. Tes suara dikecualikan. Pendeteksian gerakan dikelola PembungkamTelungkup.
     */
    private fun pasangBungkam(test: Boolean, batasMs: Long = 330_000L) {
        if (test) return
        PembungkamTelungkup.mulai(this, "alarm_sholat", batasMs) {
            stopPlayback()
            try { reminderTts?.stop() } catch (_: Exception) { }
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
            stopSelf()
        }
    }

    private fun ucapkanPengingatAwal(teks: String, startId: Int, test: Boolean = false, bahasa: Locale? = null) {
        try {
            reminderTts?.shutdown()
            reminderTts = TextToSpeech(applicationContext) { status ->
                val engine = reminderTts
                if (status == TextToSpeech.SUCCESS && engine != null) {
                    // Ikuti pilihan "volume keluaran" pengguna agar pengingat terdengar sama keras dengan azan.
                    try {
                        engine.setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(usageUntukVolume(PrayerPrefs(this@PrayerAlarmService).volumeMode))
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    } catch (_: Exception) { }
                    val bahasaAktif = bahasa ?: if (BahasaAplikasi.tampilan(this@PrayerAlarmService) == 1) Locale.ENGLISH else Locale("id", "ID")
                    val languageResult = engine.setLanguage(bahasaAktif)
                    if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        // Keep the selected app language as the fallback rather than forcing Indonesian.
                        engine.language = bahasaAktif
                    }
                    if (Build.VERSION.SDK_INT >= 21) {
                        // Pengingat (sebelum azan, imsak, matahari terbit) memakai stream pilihan pengguna
                        // (bawaan: alarm) sehingga tidak ikut berubah saat tombol volume media ditekan.
                        val parameter = Bundle()
                        parameter.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, streamUntukVolume(PrayerPrefs(this@PrayerAlarmService).volumeMode))
                        engine.speak(teks, TextToSpeech.QUEUE_FLUSH, parameter, ("pengingat_awal_" + (startId)))
                    } else {
                        @Suppress("DEPRECATION")
                        engine.speak(teks, TextToSpeech.QUEUE_FLUSH, null)
                    }
                    jadwalkanPenutupTts(test, startId, 15000L)
                } else {
                    jadwalkanPenutupTts(test, startId, 5000L)
                }
            }
        } catch (_: Exception) {
            jadwalkanPenutupTts(test, startId, 5000L)
        }
    }

    private var penutupTts: Runnable? = null
    @Volatile private var kunciMelodiPengingatPuasa: String? = null

    private fun mulaiDenganMelodiPuasa(key: String, startId: Int, test: Boolean, aksi: () -> Unit) {
        kunciMelodiPengingatPuasa = key
        val pp = PrayerPrefs(this)
        val melodi = when {
            key == "sahur" -> pp.sahurMelodiAwal
            key == "berbuka" -> pp.berbukaMelodiAwal
            key.startsWith("advance_") -> pp.advanceMelodyBefore(key.removePrefix("advance_"))
            key in setOf("imsak", "terbit", "dhuha", "tahajud") -> pp.reminderMelodyBefore(key)
            else -> 0
        }
        if (melodi > 0) Melodi.putar(this, melodi, volume = 1f) { if (serviceAktif) aksi() }
        else aksi()
    }

    private fun akhiriPengingatPuasa(startId: Int, test: Boolean) {
        val key = kunciMelodiPengingatPuasa
        if (key == null) { if (test) clearTestState(); stopSelf(startId); return }
        kunciMelodiPengingatPuasa = null
        val pp = PrayerPrefs(this)
        val melodi = when {
            key == "sahur" -> pp.sahurMelodiAkhir
            key == "berbuka" -> pp.berbukaMelodiAkhir
            key.startsWith("advance_") -> pp.advanceMelodyAfter(key.removePrefix("advance_"))
            key in setOf("imsak", "terbit", "dhuha", "tahajud") -> pp.reminderMelodyAfter(key)
            else -> 0
        }
        val selesai = { if (test) clearTestState(); stopSelf(startId) }
        if (melodi > 0) Melodi.putar(this, melodi, volume = 1f, selesai = selesai) else selesai()
    }

    private fun batalkanPenutupTts() {
        penutupTts?.let { handler.removeCallbacks(it) }
        penutupTts = null
    }

    /** Penutup otomatis tes/pengingat berbasis TTS; satu penutup aktif pada satu waktu agar jeda tidak dipotong oleh penutup lama. */
    private fun jadwalkanPenutupTts(test: Boolean, startId: Int, tundaMs: Long) {
        batalkanPenutupTts()
        val r = Runnable { if (kunciMelodiPengingatPuasa != null) akhiriPengingatPuasa(startId, test) else { if (test) clearTestState(); stopSelf(startId) } }
        penutupTts = r
        handler.postDelayed(r, tundaMs)
    }

    /** Tes yang sedang aktif berbunyi lewat mesin TTS (bukan MediaPlayer)? */
    private fun tesPakaiTts(kunci: String): Boolean {
        val pp = PrayerPrefs(this)
        if (kunci == "sahur") return pp.reminderSoundMode("sahur") == 1
        if (kunci.startsWith("advance_")) {
            val k = kunci.removePrefix("advance_")
            return when (pp.advanceSoundMode(k)) {
                1 -> false
                2 -> pp.advanceSound(k).isBlank()
                else -> true
            }
        }
        return false
    }

    /**
     * Jeda tes: pemutar berkas dan melodi dijeda di tempat; TTS tidak bisa dijeda di tengah kalimat sehingga dihentikan
     * (dan diucapkan ulang saat dilanjutkan). Pengatur waktu pengaman dibatalkan selama jeda agar tes tidak berakhir sendiri.
     */
    private fun jedaTes(kunci: String, startId: Int) {
        tesDijeda = true
        handler.removeCallbacksAndMessages(null)
        Melodi.jedaSemua()
        jedaPemutar()
        if (tesPakaiTts(kunci)) {
            try { reminderTts?.stop() } catch (_: Exception) { }
            jadwalkanPenutupTts(true, startId, 600_000L)
        } else {
            jadwalkanPengamanTes(startId, 600_000L)
        }
    }

    private fun lanjutTes(kunci: String, startId: Int) {
        tesDijeda = false
        handler.removeCallbacksAndMessages(null)
        penutupTts = null
        Melodi.lanjutSemua()
        lanjutPemutar()
        if (tesPakaiTts(kunci)) mulaiUlangTesTts(kunci, startId) else jadwalkanPengamanTes(startId, sisaPutar(if (kunci.startsWith("tarhim_")) 480_000L else 300_000L))
    }

    /** FIX299: sisa durasi pemutar ditambah cadangan; bila tak terbaca, pakai batas bawaan. */
    private fun sisaPutar(bawaan: Long): Long = try {
        val dur = durasiPemutar()
        if (adaPemutar() && dur > 0) maxOf(bawaan, (dur - posisiPemutar()).toLong() + 15_000L).coerceAtMost(5_400_000L) else bawaan
    } catch (_: Exception) { bawaan }

    private fun jadwalkanPengamanTes(startId: Int, tundaMs: Long) {
        handler.postDelayed({ clearTestState(); stopSelf(startId) }, tundaMs)
    }

    /** Ucapan tes yang sama seperti saat tes dimulai. */
    private fun mulaiUlangTesTts(kunci: String, startId: Int) {
        val pp = PrayerPrefs(this)
        val bahasaAktif = if (BahasaAplikasi.tampilan(this) == 1) 1 else 0
        if (kunci == "sahur") {
            ucapkanPengingatAwal(BahasaAplikasi.teks(this, ("Tes suara pemberitahuan sahur. Waktu sahur tinggal " + (pp.sahurReminderMinutes) + " menit sebelum Imsak.")), startId, true, if (BahasaAplikasi.tampilan(this@PrayerAlarmService) == 1) Locale.ENGLISH else Locale("id", "ID"))
        } else if (kunci.startsWith("advance_")) {
            val k = kunci.removePrefix("advance_")
            ucapkanPengingatAwal(UcapanSholat.pengingatAwal(k, pp.advanceMinutes(k), bahasaAktif), startId, true, UcapanSholat.locale(bahasaAktif))
        }
    }

    private fun updateTestNotification(paused: Boolean) {
        val pp = PrayerPrefs(this)
        val key = getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getString("test_playback_key", "subuh") ?: "subuh"
        val judulTes = BahasaAplikasi.teks(this, when {
            key == "sahur" -> "Tes suara pemberitahuan sahur"
            key.startsWith("advance_") -> "Tes suara pengingat sebelum salat " + PrayerAlarm.label(key.removePrefix("advance_"))
            key.startsWith("tarhim_") -> "Tes Tarhim sebelum salat " + PrayerAlarm.label(key.removePrefix("tarhim_"))
            key.startsWith("iqomah_") -> "Tes iqomah " + PrayerAlarm.label(key.removePrefix("iqomah_"))
            else -> "Tes suara azan — " + (PrayerAlarm.label(key))
        })
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "jadwal_sholat") else Notification.Builder(this)
        val toggleIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        val stopIntent = Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_TEST_PLAYBACK")
        fun pi(req: Int, i: Intent) = PendingIntent.getService(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(BahasaAplikasi.teks(this, judulTes + " — " + (if (paused) "dijeda" else "sedang diputar")))
            .setContentText(getString(R.string.notif_kontrol_pemutar_audio))
            .setOngoing(true).setAutoCancel(false)
            .addAction(if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause, BahasaAplikasi.teks(this, if (paused) "Lanjutkan tes suara" else "Jeda tes suara"), pi(812, toggleIntent))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan tes suara"), pi(814, stopIntent))
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(809, builder.build())
    }

    private fun clearTestState() {
        tesBerjalan = false
        tesDijeda = false
        getSharedPreferences("jadwal_sholat", MODE_PRIVATE).edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            val namaKanal = if (BahasaAplikasi.tampilan(this) == 1) "Prayer Schedule Reminders" else "Pengingat Jadwal Sholat"
            if (manager.getNotificationChannel("jadwal_sholat") == null) {
                val channel = NotificationChannel("jadwal_sholat", namaKanal, NotificationManager.IMPORTANCE_HIGH)
                channel.setSound(null, null)
                manager.createNotificationChannel(channel)
            } else {
                // Nama kanal diperbarui mengikuti bahasa aktif; pengaturan suara/prioritas kanal tidak berubah.
                manager.createNotificationChannel(NotificationChannel("jadwal_sholat", namaKanal, manager.getNotificationChannel("jadwal_sholat").importance))
            }
        }
    }
    /** FIX279: tombol Jeda/Lanjutkan dan Hentikan pada notifikasi Tarhim dan Iqomah nyata (bukan tes). */
    private fun tambahKendaliPutar(b: Notification.Builder, test: Boolean) {
        if (test) return
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val toggle = PendingIntent.getService(this, 811, Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_PRAYER_PLAYBACK"), fl)
        val stop = PendingIntent.getService(this, 810, Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.STOP_PRAYER_SOUND"), fl)
        b.addAction(android.R.drawable.ic_media_play, BahasaAplikasi.teks(this, "Jeda atau lanjutkan suara"), toggle)
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, BahasaAplikasi.teks(this, "Hentikan suara"), stop)
    }

    /** FIX279: pengaman; layanan selesai sendiri bila tidak ada suara yang berjalan, tidak ada tes, dan tidak sedang dijeda. */
    private val jagaHandler = Handler(Looper.getMainLooper())
    private val jagaLayanan = object : Runnable {
        override fun run() {
            val bunyi = sedangBunyiSemua()
            val bicara = try { reminderTts?.isSpeaking == true } catch (_: Exception) { false }
            val dijeda = adaPemutar() && !bunyi
            if (!bunyi && !bicara && !tesBerjalan && !dijeda && !Melodi.sedangMemutar()) {
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
                stopSelf()
                return
            }
            jagaHandler.postDelayed(this, 20_000L)
        }
    }

    private fun stopPlayback() {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        try { pemutarGema?.stop() } catch (_: Exception) { }
        try { pemutarGema?.release() } catch (_: Exception) { }
        pemutarGema = null
        try { gemaMandiri.lepas() } catch (_: Exception) { }
    }
    override fun onDestroy() {
        serviceAktif = false
        jagaHandler.removeCallbacksAndMessages(null)
        try { (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).let { it.cancel(809); it.cancel(810) } } catch (_: Exception) { }
        handler.removeCallbacksAndMessages(null)
        if (isTestPlayback || tesBerjalan) { clearTestState(); Melodi.hentikanSemua() }
        stopPlayback()
        PembungkamTelungkup.selesai("alarm_sholat")
        try { DndAzan.pasangKembaliSetelahAzan(this) } catch (_: Exception) { }
        try { reminderTts?.stop(); reminderTts?.shutdown() } catch (_: Exception) { }
        reminderTts = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
}
