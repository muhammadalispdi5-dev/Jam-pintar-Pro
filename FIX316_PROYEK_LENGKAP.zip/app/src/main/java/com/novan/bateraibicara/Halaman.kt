package com.novan.bateraibicara

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Dasar semua halaman: pembangun tampilan sederhana dan blok pengaturan suara. */
abstract class Halaman : Activity() {

    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    protected fun ui(teks: String): String = BahasaAplikasi.teks(this, teks)

    /** Pemilih melodi bertahap: pratinjau tidak menutup daftar dan nilai baru disimpan hanya lewat tombol Simpan. */
    protected fun pilihMelodiBertahap(
        tajuk: String,
        terpilihSaatIni: Int,
        atribut: android.media.AudioAttributes? = null,
        volume: Float = 1f,
        simpan: (Int) -> Unit
    ) {
        val nama = resources.getStringArray(R.array.jam_melodi)
        var sementara = terpilihSaatIni.coerceIn(0, nama.lastIndex)
        val dialog = AlertDialog.Builder(this)
            .setTitle(ui(tajuk))
            .setSingleChoiceItems(nama.map { ui(it) }.toTypedArray(), sementara) { _, which ->
                sementara = which
                Melodi.hentikanSemua()
                if (which > 0) Melodi.putar(this, which, atribut, volume)
            }
            .setPositiveButton(ui("Simpan")) { _, _ ->
                Melodi.hentikanSemua()
                simpan(sementara)
                toast("Pilihan melodi disimpan")
            }
            .setNegativeButton(ui("Batal")) { _, _ -> Melodi.hentikanSemua() }
            .create()
        dialog.setOnCancelListener { Melodi.hentikanSemua() }
        dialog.setOnDismissListener { Melodi.hentikanSemua() }
        dialog.show()
    }

    /** Teks dwibahasa mengikuti bahasa tampilan aplikasi yang sedang aktif. */
    protected fun tr(indonesia: String, english: String): String =
        if (BahasaAplikasi.tampilan(this) == 1) english else indonesia

    protected lateinit var prefs: Prefs
    protected lateinit var root: LinearLayout
    private var pembicaraTes: Pembicara? = null
    private lateinit var halamanScroll: ScrollView
    private val namaEngine = ArrayList<String>()
    private val paketEngine = ArrayList<String>()

    protected abstract val judulHalaman: Int
    protected abstract fun bangun()

    private var volumeDikonsumsi = false

    /**
     * FIX76: selama ada suara notifikasi aplikasi yang berbunyi (azan, alarm jam, pengingat, pengumuman baterai/jam,
     * nama pemanggil), menekan volume atas atau bawah menghentikannya dan tidak mengubah volume.
     * Bila tidak ada suara yang berbunyi, tombol volume bekerja seperti biasa.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val kode = event.keyCode
        if (kode == KeyEvent.KEYCODE_VOLUME_UP || kode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                // FIX122: tekanan baru (repeatCount 0) selalu dinilai ulang. Dahulu status "dikonsumsi" yang ACTION_UP-nya tidak pernah
                // sampai (halaman berpindah/jeda saat tombol dilepas) menelan SEMUA tekanan volume berikutnya, termasuk volume biasa.
                if (event.repeatCount == 0) volumeDikonsumsi = false
                if (volumeDikonsumsi) return true // tekan-tahan: jangan teruskan pengulangan ke pengatur volume
                if (PembungkamTelungkup.bungkamDariTombolVolume(this)) { volumeDikonsumsi = true; return true }
            } else if (event.action == KeyEvent.ACTION_UP && volumeDikonsumsi) {
                volumeDikonsumsi = false
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        // FIX182: mode hemat daya diterapkan pada jendela setiap halaman aplikasi,
        // bukan hanya pada halaman pengaturannya.
        PenghematDaya.terapkan(this)
    }

    override fun onPause() {
        volumeDikonsumsi = false
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        if (!hasFocus) volumeDikonsumsi = false
        super.onWindowFocusChanged(hasFocus)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        muatEngine()
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(24))
        // Identitas visual Zamrud Islami Premium: zamrud, gading, dan aksen emas lembut.
        root.setBackgroundColor(warnaLatar()) // gading terang / hijau gelap saat mode malam
        window.statusBarColor = if (modeGelap()) Color.rgb(20, 29, 28) else Color.rgb(7, 94, 84)
        window.navigationBarColor = if (modeGelap()) Color.rgb(20, 29, 28) else Color.rgb(7, 94, 84)
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = 0
        }
        halamanScroll = ScrollView(this)
        halamanScroll.clipToPadding = false
        halamanScroll.isFillViewport = false
        halamanScroll.addView(root)
        halamanScroll.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            }
            insets
        }
        setContentView(halamanScroll)
        // Navigasi konsisten: setiap halaman fitur memiliki tombol Kembali sebagai
        // elemen fokus pertama, sehingga pengguna TalkBack tidak perlu menyusuri
        // seluruh isi halaman untuk kembali ke tingkat sebelumnya.
        if (this !is MainActivity) {
            val tombolKembali = tombol("Kembali ke halaman sebelumnya") { finish() }
            tombolKembali.contentDescription = ui("Kembali ke halaman sebelumnya")
        }
        setTitle(ui(getString(judulHalaman)))
        bagian(getString(judulHalaman), 26f)
        bangun()
        val posisiSimpan = savedInstanceState?.getInt("halaman_scroll_y", 0) ?: 0
        halamanScroll.post { halamanScroll.scrollTo(0, posisiSimpan.coerceAtLeast(0)) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::halamanScroll.isInitialized) outState.putInt("halaman_scroll_y", halamanScroll.scrollY)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        pembicaraTes?.matikan()
        pembicaraTes = null
        super.onDestroy()
    }

    // ---------- Pembangun tampilan ----------

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    protected fun modeGelap(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    protected fun warnaAksen(): Int = if (modeGelap()) Color.rgb(75, 181, 158) else Color.rgb(7, 94, 84)
    protected fun warnaLatar(): Int = if (modeGelap()) Color.rgb(20, 29, 28) else Color.rgb(247, 244, 234)
    protected fun warnaTeks(): Int = if (modeGelap()) Color.rgb(237, 241, 235) else Color.rgb(39, 50, 45)
    protected fun warnaTeksIsian(): Int = if (modeGelap()) Color.rgb(237, 241, 235) else Color.rgb(30, 45, 40)
    protected fun warnaPetunjuk(): Int = if (modeGelap()) Color.rgb(180, 193, 184) else Color.rgb(105, 112, 103)

    protected fun larik(id: Int): List<String> = resources.getStringArray(id).toList()

    /** Kode kelompok yang sedang dibuka (null = halaman daftar utama). */
    protected fun kodeKelompok(): String? = intent.getStringExtra("kelompok")

    /** Tombol yang membuka kelompok pengaturan di halaman tersendiri (tombol Kembali kembali ke daftar). */
    protected fun tombolKelompok(label: String, kode: String): Button =
        tombol(label) { startActivity(Intent(this, javaClass).putExtra("kelompok", kode)) }

    /** Judul jendela dan judul utama (heading) sebuah kelompok. */
    protected fun judulGrup(nama: String) {
        title = ui(nama)
        bagian(nama, 22f)
    }

    protected fun bagian(teks: String, ukuran: Float = 20f) {
        val tv = TextView(this)
        tv.text = ui(teks)
        tv.textSize = ukuran
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(24), 0, dp(8))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
        val aksen = View(this)
        aksen.contentDescription = null
        aksen.setBackgroundColor(Color.rgb(214, 181, 109)) // #D6B56D
        root.addView(aksen, LinearLayout.LayoutParams(dp(44), dp(3)).apply {
            topMargin = dp(2)
            bottomMargin = dp(4)
        })
    }

    protected fun info(teks: String): TextView {
        val tv = TextView(this)
        tv.text = ui(teks)
        tv.textSize = 16f
        tv.setTextColor(warnaTeks())
        tv.setPadding(0, dp(6), 0, dp(6))
        root.addView(tv)
        return tv
    }

    protected fun saklar(teks: String, nilai: Boolean, onUbah: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = ui(teks)
        s.textSize = 16f
        s.setTextColor(warnaTeks())
        s.isChecked = nilai
        if (Build.VERSION.SDK_INT >= 21) {
            s.thumbTintList = android.content.res.ColorStateList.valueOf(warnaAksen())
            // Trek sakelar dibedakan menurut tema agar tetap terlihat pada latar terang maupun gelap.
            val warnaTrek = if (modeGelap()) Color.rgb(100, 124, 115) else Color.rgb(170, 183, 173)
            s.trackTintList = android.content.res.ColorStateList.valueOf(warnaTrek)
        }
        s.setPadding(0, dp(12), 0, dp(12))
        s.setOnCheckedChangeListener { _, c -> onUbah(c) }
        root.addView(s)
        return s
    }

    protected fun tombol(teks: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = ui(teks)
        b.isAllCaps = false
        b.textSize = 16f
        b.minimumHeight = dp(52)
        b.setTextColor(Color.WHITE)
        val bentuk = GradientDrawable().apply {
            setColor(warnaAksen())
            cornerRadius = dp(14).toFloat()
        }
        if (Build.VERSION.SDK_INT >= 21) {
            b.background = bentuk
            b.elevation = dp(2).toFloat()
        } else {
            b.background = bentuk
        }
        b.setPadding(dp(16), dp(10), dp(16), dp(10))
        b.contentDescription = ui(teks)
        b.setOnClickListener { aksi() }
        root.addView(b, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(5)
            bottomMargin = dp(5)
        })
        return b
    }

    protected fun pilihan(judul: String, items: List<String>, terpilih: Int, onPilih: (Int) -> Unit) {
        val tv = TextView(this)
        tv.text = ui(judul)
        tv.textSize = 16f
        tv.setPadding(0, dp(12), 0, 0)
        val sp = Spinner(this)
        sp.id = View.generateViewId()
        tv.labelFor = sp.id
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items.map { ui(it) })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setSelection(terpilih, false)
        var terakhir = terpilih
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != terakhir) {
                    terakhir = pos
                    onPilih(pos)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(tv)
        root.addView(sp)
    }

    protected fun EditText.ubah(aksi: (String) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { aksi(s?.toString() ?: "") }
        })
    }

    /** Kolom isian dengan label yang terbaca TalkBack. */
    protected fun isian(label: String, nilai: String, tipe: Int, onUbah: (String) -> Unit): EditText {
        val tv = TextView(this)
        tv.text = ui(label)
        tv.textSize = 16f
        tv.setTextColor(warnaTeks())
        tv.setPadding(0, dp(12), 0, 0)
        val et = EditText(this)
        et.id = View.generateViewId()
        tv.labelFor = et.id
        et.inputType = tipe
        et.hint = ui(label)
        et.setTextColor(warnaTeksIsian())
        et.setHintTextColor(warnaPetunjuk())
        et.setText(nilai)
        et.ubah(onUbah)
        root.addView(tv)
        root.addView(et)
        return et
    }

    protected fun tombolJam(formatRes: Int, get: () -> Int, set: (Int) -> Unit) {
        val b = Button(this)
        b.isAllCaps = false
        fun segarkan() { b.text = getString(formatRes, JamWaktu.format(get())) }
        segarkan()
        b.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                set(h * 60 + m)
                segarkan()
            }, get() / 60, get() % 60, true).show()
        }
        root.addView(b)
    }

    protected fun toast(id: Int) = Toast.makeText(this, ui(getString(id)), Toast.LENGTH_LONG).show()
    protected fun toast(teks: String) = Toast.makeText(this, ui(teks), Toast.LENGTH_LONG).show()

    /**
     * Tombol reset hanya ditampilkan pada fitur yang mempunyai pengaturan mandiri.
     * Konfirmasi dan teks mengikuti bahasa tampilan aktif melalui ui().
     */
    protected fun tombolResetPengaturan(keterangan: String, aksiReset: () -> Unit) {
        tombol(ui("Reset pengaturan fitur ini")) {
            android.app.AlertDialog.Builder(this)
                .setTitle(ui("Reset pengaturan"))
                .setMessage(ui("Kembalikan pengaturan fitur ini ke nilai bawaan? Pengaturan fitur lain tidak akan diubah."))
                .setNegativeButton(ui("Batal"), null)
                .setPositiveButton(ui("Reset")) { _, _ ->
                    aksiReset()
                    toast(ui("Pengaturan berhasil dikembalikan ke nilai bawaan."))
                    recreate()
                }
                .show()
        }
    }

    protected fun hapusKunciPengaturan(nama: String, cocok: (String) -> Boolean) {
        val sp = getSharedPreferences(nama, MODE_PRIVATE)
        val editor = sp.edit()
        sp.all.keys.filter(cocok).forEach { editor.remove(it) }
        editor.apply()
    }

    /** Simpan perubahan ke layanan yang sedang berjalan (jadwal jam dipasang ulang). */
    protected fun muatUlang() {
        if (prefs.enabled) BatteryTalkService.reload(this)
    }

    // ---------- Blok pengaturan suara ----------

    @Suppress("DEPRECATION")
    private fun muatEngine() {
        paketEngine.add("")
        namaEngine.add(getString(R.string.mesin_bawaan))
        val daftar = packageManager.queryIntentServices(
            Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE), 0
        )
        for (ri in daftar) {
            val si = ri.serviceInfo ?: continue
            if (paketEngine.contains(si.packageName)) continue
            paketEngine.add(si.packageName)
            namaEngine.add(ri.loadLabel(packageManager).toString())
        }
    }

    /** Mesin suara, kecepatan, nada, keluaran volume, dan tombol tes untuk satu profil. */
    protected fun blokSuara(profil: String, contoh: () -> String) {
        val s = prefs.suara(profil)
        bagian(getString(R.string.bagian_suara))
        pilihan(
            getString(R.string.mesin_suara), namaEngine,
            paketEngine.indexOf(s.engine).coerceAtLeast(0)
        ) { s.engine = paketEngine[it] }
        pilihan(getString(R.string.kecepatan), larik(R.array.kecepatan), s.rateIdx) { s.rateIdx = it }
        pilihan(getString(R.string.nada), larik(R.array.nada), s.pitchIdx) { s.pitchIdx = it }
        pilihan(getString(R.string.keluaran), larik(R.array.keluaran), s.streamIdx) { s.streamIdx = it }
        tombol(if (profil == "pem") tr("⚙ Efek vokal", "⚙ Vocal effects") else tr("⚙ Volume mandiri dan efek vokal", "⚙ Independent volume and vocal effects")) {
            dialogVolumeDanEfek(s)
        }
        if (profil == "pem") info(tr("Volume pengumuman Nama Panggilan tidak diatur di sini lagi. Atur di Pengaturan volume pengumuman pada halaman utama Nama Panggilan; volume itu mengatur saluran yang dipilih pada Keluaran suara di atas.", "Caller Name announcement volume is no longer set here. Set it in Announcement volume settings on the main Caller Name page; that volume controls the channel chosen under Audio Output above."))
        info(getString(R.string.contoh_hasil, contoh()))
        tombol(getString(R.string.tombol_tes)) { tesSuara(profil, contoh()) }
        tombol(getString(R.string.tombol_pengaturan_tts)) { bukaPengaturanTts() }
    }

    private fun dialogVolumeDanEfek(s: Prefs.Suara) {
        // FIX311: semua perubahan ditampung dulu sebagai draf. "Putar contoh gema" hanya mendengarkan; yang tersimpan hanya setelah menekan Simpan.
        var volDraf = s.volumePersen
        var efekDraf = s.efekRuang
        var gemaDraf = s.gemaPersen
        var turunkanDraf = s.turunkanAudioLain
        val isi = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        val label = TextView(this).apply { textSize = 16f; setTextColor(warnaTeks()) }
        val bar = android.widget.SeekBar(this).apply { max = 100; progress = s.volumePersen }
        fun perbarui() { label.text = ui(tr("Volume mandiri: ", "Independent volume: ")) + bar.progress + "%"; bar.contentDescription = label.text }
        perbarui()
        bar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) { volDraf = progress; perbarui() }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) { seekBar?.announceForAccessibility(label.text) }
        })
        if (s.profil != "pem") { isi.addView(label); isi.addView(bar) }
        val labelEfek = TextView(this).apply { text = ui(tr("Efek vokal / ruang suara", "Vocal / room sound effect")); textSize = 16f; setTextColor(warnaTeks()); setPadding(0, dp(14), 0, dp(4)) }
        isi.addView(TextView(this).apply {
            text = ui(tr("Perubahan di sini baru tersimpan setelah Anda menekan tombol Simpan. Tombol Putar contoh gema hanya untuk mendengarkan, tidak menyimpan apa pun.", "Changes here are saved only after you press Save. Play echo sample is only for listening and saves nothing."))
            textSize = 14f; setTextColor(warnaTeks()); setPadding(0, dp(4), 0, dp(4))
        })
        isi.addView(labelEfek)
        val pilihanEfek = Spinner(this)
        val pakaiGemaLengkap = true
        val gemaLengkap = GemaAudio(this)
        val opsiLengkap = GemaAudio.daftarKunci.map { if (it == "normal") tr("Normal (tanpa gema)", "Normal (no echo)") else gemaLengkap.label(it) }
        val opsi = if (pakaiGemaLengkap) opsiLengkap else listOf(
            tr("Normal (tanpa gema)", "Normal (no reverb)"),
            tr("Ruang kecil", "Small room"),
            tr("Ruang sedang", "Medium room"),
            tr("Ruang besar", "Large room"),
            tr("Aula sedang", "Medium hall"),
            tr("Aula besar", "Large hall"),
            tr("Studio / Plate", "Studio / Plate"),
            tr("Gema lembut (echo-like)", "Soft echo (echo-like)"),
            tr("Studio vokal", "Vocal studio"),
            tr("Karaoke", "Karaoke"),
            tr("Panggung konser", "Concert stage")
        )
        pilihanEfek.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opsi)
        pilihanEfek.setSelection(s.efekRuang)
        pilihanEfek.contentDescription = ui(tr("Pilih efek vokal ruang atau aula", "Choose vocal room or hall effect"))
        pilihanEfek.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) { }
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { efekDraf = position }
        }
        isi.addView(pilihanEfek)
        if (pakaiGemaLengkap) {
            val labelKuat = TextView(this).apply { textSize = 16f; setTextColor(warnaTeks()); setPadding(0, dp(14), 0, dp(4)) }
            val barKuat = android.widget.SeekBar(this).apply { max = 100; progress = s.gemaPersen }
            fun perbaruiKuat() { labelKuat.text = ui(tr("Kekuatan gema: ", "Echo strength: ")) + barKuat.progress + "%"; barKuat.contentDescription = labelKuat.text }
            perbaruiKuat()
            barKuat.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) { gemaDraf = progress; perbaruiKuat() }
                override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
                override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) { seekBar?.announceForAccessibility(labelKuat.text) }
            })
            isi.addView(labelKuat); isi.addView(barKuat)
            val deskripsi = TextView(this).apply {
                text = ui(tr("Gema dihitung langsung pada suara, sehingga terdengar sama di semua HP. Kekuatan 0 mematikan gema. Tekan Putar contoh gema untuk mendengarkan pilihan Anda sebelum menyimpan.",
                    "The echo is computed directly on the sound, so it is heard the same on every phone. Strength 0 turns the echo off. Press Play echo sample to listen to your choice before saving."))
                textSize = 13f; setTextColor(warnaTeks()); setPadding(0, dp(8), 0, 0)
            }
            isi.addView(deskripsi)
        }
        val catatanEfek = TextView(this).apply {
            visibility = if (pakaiGemaLengkap) View.GONE else View.VISIBLE
            text = ui(tr(
                "Efek menggunakan preset gema/ruang yang tersedia pada Android. Gema lembut dan Studio vokal memakai karakter Plate; Karaoke memakai ruang sedang; Panggung konser memakai aula besar. Hasil dapat berbeda menurut mesin TTS dan perangkat.",
                "Effects use the reverb/room presets available on Android. Soft echo and Vocal studio use the Plate character; Karaoke uses a medium room; Concert stage uses a large hall. Results may vary by TTS engine and device."
            ))
            textSize = 13f
            setTextColor(warnaTeks())
            setPadding(0, dp(10), 0, 0)
        }
        isi.addView(catatanEfek)
        val turunkan = android.widget.CheckBox(this).apply {
            text = ui(tr("Turunkan audio lain saat berbicara", "Lower other audio while speaking"))
            isChecked = s.turunkanAudioLain
            textSize = 16f
            setTextColor(warnaTeks())
            setPadding(0, dp(14), 0, dp(2))
            contentDescription = text
            setOnCheckedChangeListener { _, v -> turunkanDraf = v }
        }
        isi.addView(turunkan)
        isi.addView(TextView(this).apply {
            text = ui(tr(
                "Bila aktif, audio lain seperti nada dering atau pemutar musik diminta turun sementara lewat Android selama suara ini berbicara, lalu kembali normal sendiri. Volume dan nada milik HP atau aplikasi lain tidak diubah. Sebagian aplikasi mungkin tidak mau menurun.",
                "When on, other audio such as the ringtone or a music player is asked to lower temporarily through Android while this voice speaks, then returns to normal by itself. The volume and tones of the phone or other apps are not changed. Some apps may not lower."
            ))
            textSize = 13f; setTextColor(warnaTeks()); setPadding(0, dp(4), 0, 0)
        })
        AlertDialog.Builder(this).setTitle(ui(if (s.profil == "pem") tr("⚙ Efek vokal dan audio lain", "⚙ Vocal effects and other audio") else tr("⚙ Volume, efek vokal, dan audio lain", "⚙ Volume, vocal effects, and other audio")))
            .setView(android.widget.ScrollView(this).apply { addView(isi) })
            .setPositiveButton(ui(tr("Simpan", "Save"))) { _, _ ->
                s.volumePersen = volDraf; s.efekRuang = efekDraf; s.gemaPersen = gemaDraf; s.turunkanAudioLain = turunkanDraf
                toast(tr("Pengaturan suara disimpan.", "Sound settings saved."))
            }
            .setNegativeButton(ui(tr("Batal", "Cancel"))) { _, _ -> toast(tr("Perubahan tidak disimpan.", "Changes were not saved.")) }
            .setNeutralButton(ui(tr("Putar contoh gema", "Play echo sample")), null)
            .show().also { dlg ->
                // FIX311: contoh hanya mendengarkan draf (tidak menyimpan), memakai suara TTS saja, dan dialog tetap terbuka.
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    try { ContohGema.putar(this, GemaAudio.daftarKunci.getOrElse(efekDraf) { "normal" }, gemaDraf, s.engine) { m -> toast(m) } } catch (_: Throwable) { }
                }
                dlg.setOnDismissListener { try { ContohGema.berhenti() } catch (_: Throwable) { } }
            }
    }

    protected fun tesSuara(profil: String, teks: String) {
        pembicaraTes?.matikan()
        val p = Pembicara(this, prefs.suara(profil)) { toast(it) }
        pembicaraTes = p
        p.ucapkan(teks, true)
    }

    private companion object {
        const val KODE_BERKAS_SENDIRI = 9164
    }
    private var slotBerkasMenunggu: String? = null

    /** FIX264: nama berkas yang ramah pengguna dari URI tersimpan. */
    protected fun namaBerkasSendiri(uriText: String): String {
        if (uriText.isBlank()) return tr("belum dipilih", "not chosen")
        return try {
            val uri = Uri.parse(uriText)
            val nama = if (uri.scheme == "content") {
                contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            } else uri.lastPathSegment
            nama?.takeIf { it.isNotBlank() } ?: uriText.substringAfterLast('/')
        } catch (_: Exception) { uriText.substringAfterLast('/') }
    }

    /**
     * FIX264: tombol pengaturan berkas audio sendiri untuk satu [slot]. Dialog menawarkan memilih berkas, tes putar, dan hapus.
     * Berkas yang dipilih memutar volume dan saluran sesuai profil suara [profil].
     */
    protected fun tombolBerkasSendiri(judul: String, slot: String, profil: String) {
        val berkas = prefs.berkasSendiri(slot)
        tombol(judul + ": " + namaBerkasSendiri(berkas)) {
            val sekarang = prefs.berkasSendiri(slot)
            val opsi = ArrayList<String>(); val aksi = ArrayList<() -> Unit>()
            opsi.add(tr("Pilih berkas audio dari perangkat", "Choose an audio file from the device")); aksi.add { pilihBerkasSendiri(slot) }
            if (sekarang.isNotBlank()) {
                opsi.add(tr("Tes putar berkas ini", "Play this file as a test")); aksi.add {
                    Melodi.hentikanSemua()
                    val s = prefs.suara(profil)
                    Melodi.putarUri(this, sekarang, s.audioAttributes(), s.volumePersen / 100f, null) { toast(tr("Berkas tidak dapat diputar. Pilih ulang berkas.", "The file cannot be played. Choose it again.")) }
                }
                opsi.add(tr("Hapus berkas (kembali ke bawaan)", "Remove file (back to default)")); aksi.add { prefs.setBerkasSendiri(slot, ""); toast(tr("Berkas dihapus", "File removed")); recreate() }
            }
            AlertDialog.Builder(this).setTitle(judul)
                .setItems(opsi.toTypedArray()) { _, i -> aksi[i]() }
                .setNegativeButton(tr("Batal", "Cancel"), null).show()
        }
    }

    private fun pilihBerkasSendiri(slot: String) {
        slotBerkasMenunggu = slot
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i, KODE_BERKAS_SENDIRI)
        } catch (e: Exception) { toast(tr("Pemilih berkas tidak dapat dibuka pada perangkat ini.", "The file picker cannot be opened on this device.")) }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != KODE_BERKAS_SENDIRI || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val slot = slotBerkasMenunggu ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        prefs.setBerkasSendiri(slot, uri.toString())
        toast(tr("Berkas audio disimpan", "Audio file saved"))
        recreate()
    }

    /** FIX264: tes suara dengan volume mandiri khusus (0..100). */
    protected fun tesSuaraVolume(profil: String, teks: String, volume: Int) {
        pembicaraTes?.matikan()
        val p = Pembicara(this, prefs.suara(profil)) { toast(it) }
        p.volumeKhusus = volume
        p.volumeSaluran = volume
        pembicaraTes = p
        p.ucapkan(teks, true)
    }

    private fun bukaPengaturanTts() {
        try {
            startActivity(Intent("com.android.settings.TTS_SETTINGS"))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    protected fun bukaInfoApp() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(("package:" + (packageName))))
            )
        } catch (e: Exception) { }
    }
}
