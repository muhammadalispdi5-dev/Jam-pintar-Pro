package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import java.util.Locale

/**
 * FIX96: pemutar Al-Qur'an latar belakang untuk perintah suara, termasuk saat layar terkunci.
 * Layanan foreground (mediaPlayback) memutar audio tanpa membuka layar apa pun, sehingga pengguna tetap di layar
 * kunci atau layar depan. Mengikuti qari dan kecepatan yang disimpan di Khatam. Dikendalikan dengan perintah suara
 * (berhenti, jeda, lanjut) atau tombol pada notifikasi.
 */
class PemutarQuranService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var daftarUrl: List<String> = emptyList()
    private var indeks = 0
    private var percobaan = 0
    private var gagalBerturut = 0
    private var generasi = 0
    private var dijeda = false
    private var dijedaOlehFokus = false
    private var siap = false
    private var label = ""
    private var kecepatan = 1.0f
    private var fokus: AudioManager.OnAudioFocusChangeListener? = null
    private var permintaanFokus: AudioFocusRequest? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var penerimaTerdaftar = false
    private val penerimaBising = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) jeda()
        }
    }
    private val batasMuat = Runnable { gagalMuat() }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id
    private fun toast(teks: String) { try { Toast.makeText(applicationContext, teks, Toast.LENGTH_LONG).show() } catch (_: Exception) { } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        buatSaluran()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val aksi = intent?.action
        // Layanan foreground wajib memanggil startForeground secepatnya setelah startForegroundService.
        mulaiForeground(if (siap || mp != null) label else tr("Menyiapkan audio…", "Preparing audio…"))
        when (aksi) {
            ACTION_PUTAR -> putar(intent?.getStringArrayListExtra(EXTRA_KANDIDAT).orEmpty())
            ACTION_JEDA -> if (mp == null) tidakAdaAudio() else jeda()
            ACTION_LANJUT -> if (mp == null) tidakAdaAudio() else lanjut()
            ACTION_BERHENTI -> selesai(true)
            else -> if (mp == null) selesai(false)
        }
        return START_NOT_STICKY
    }

    private fun tidakAdaAudio() {
        toast(tr("Tidak ada audio Al-Qur'an yang sedang diputar oleh perintah suara.", "No Qur'an audio is currently playing from a voice command."))
        selesai(false)
    }

    // ---------- Perintah ----------

    private fun putar(kandidat: List<String>) {
        val kh = getSharedPreferences("khatam_quran", MODE_PRIVATE)
        if (!kh.getBoolean("perintah_suara_putar_aktif", true)) {
            toast(tr("Perintah suara untuk memutar dinonaktifkan. Aktifkan di Pengaturan Pemutaran Audio Khatam.", "Voice command for playback is turned off. Turn it on in Khatam Audio Playback Settings."))
            if (mp == null) selesai(false)
            return
        }
        val perintah = PenafsirQuran.tafsir(kandidat)
        if (perintah == null) {
            val didengar = kandidat.firstOrNull().orEmpty()
            toast(tr("Perintah belum dikenali", "Command not recognized") + (if (didengar.isNotBlank()) ": \"" + didengar + "\"" else "") +
                tr(". Coba ucapkan: putar surah Al Baqarah, putar surah 36 ayat 5, atau putar juz 30.", ". Try saying: play surah Al Baqarah, play surah 36 verse 5, or play juz 30."))
            if (mp == null) selesai(false)
            return
        }
        val surah = perintah.surah ?: kh.getInt("terakhir_surah", 1).coerceIn(1, 114)
        var qari = kh.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        qari = when (qari) {
            "ar.sudais" -> "ar.abdurrahmaansudais"
            "ar.shuraim" -> "ar.saoodshuraym"
            "ar.abdulbasit" -> "ar.abdulbasitmurattal"
            "ar.ajamy" -> "ar.ahmedajamy"
            "ar.muhammadayoub" -> "ar.muhammadayyoub"
            else -> qari
        }
        val perSurahSaja = qari.startsWith("mp3quran|")
        val qariAyat = if (perSurahSaja) "ar.alafasy" else qari
        val urls = ArrayList<String>()
        var teksLabel: String
        var catatan = ""
        if (perintah.juz != null) {
            val juz: Int = perintah.juz
            val rentang = PenafsirQuran.rentangJuz(juz)
            if (rentang == null) { toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); if (mp == null) selesai(false); return }
            for (g in rentang) urls.add(urlAyat(qariAyat, g))
            teksLabel = tr("Juz ", "Juz ") + juz
            if (perSurahSaja) catatan = tr("Qari pilihan hanya punya audio per surah; juz diputar dengan Alafasy.", "The selected reciter only has whole-surah audio; the juz plays with Alafasy.")
        } else {
            val total = PenafsirQuran.jumlahAyat(surah)
            if (total == 0) { toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); if (mp == null) selesai(false); return }
            val awal = perintah.ayat
            if (awal == null) {
                urls.add(urlSurah(qari, surah) ?: urlSurah("ar.alafasy", surah)!!)
                if (perSurahSaja && urlSurah(qari, surah) == null) catatan = tr("Surah ini tidak ada pada qari pilihan; diputar dengan Alafasy.", "This surah is not available for the selected reciter; it plays with Alafasy.")
                teksLabel = tr("Surah ", "Surah ") + surah
            } else {
                val akhirDiminta = perintah.ayatAkhir
                val dari = if (akhirDiminta != null) minOf(awal, akhirDiminta) else awal
                val sampai = if (akhirDiminta != null) maxOf(awal, akhirDiminta) else
                    (if (kh.getString("target_pemutaran_audio", "ayat") == "ayat") awal else total)
                if (dari < 1 || sampai > total) {
                    toast(tr("Rentang ayat tidak sesuai (surah ini punya ", "Verse range is not valid (this surah has ") + total + tr(" ayat).", " verses)."))
                    if (mp == null) selesai(false)
                    return
                }
                val g0 = PenafsirQuran.global(surah, dari)
                for (k in 0..(sampai - dari)) urls.add(urlAyat(qariAyat, g0 + k))
                teksLabel = tr("Surah ", "Surah ") + surah + tr(" ayat ", " verse ") + dari + (if (sampai != dari) (tr(" sampai ", " to ") + sampai) else "")
                if (perSurahSaja) catatan = tr("Qari pilihan hanya punya audio per surah; ayat diputar dengan Alafasy.", "The selected reciter only has whole-surah audio; verses play with Alafasy.")
            }
        }
        kecepatan = kh.getFloat("kecepatan_audio", 1.0f).let { if (it in listOf(0.75f, 1.0f, 1.25f, 1.5f)) it else 1.0f }
        kh.edit().putInt("terakhir_surah", surah).apply()
        label = teksLabel
        toast(tr("Perintah suara: putar ", "Voice command: play ") + teksLabel + (if (catatan.isNotBlank()) ". " + catatan else ""))
        daftarUrl = urls
        indeks = 0
        gagalBerturut = 0
        mulaiIndeks(0, 0)
    }

    private fun urlAyat(qari: String, global: Int) = "https://cdn.islamic.network/quran/audio/128/" + qari + "/" + global + ".mp3"

    /** Null bila qari per-surah (MP3Quran) tidak memuat surah tersebut. */
    private fun urlSurah(qari: String, surah: Int): String? {
        if (qari.startsWith("mp3quran|")) {
            val bagian = qari.split("|")
            val server = bagian.getOrNull(1).orEmpty()
            val tersedia = bagian.getOrNull(2)?.split(",")?.mapNotNull { it.trim().toIntOrNull() }?.toSet() ?: emptySet()
            if (server.isBlank() || surah !in tersedia) return null
            return server + String.format(Locale.ROOT, "%03d", surah) + ".mp3"
        }
        return "https://cdn.islamic.network/quran/audio-surah/128/" + qari + "/" + surah + ".mp3"
    }

    /** Percobaan ulang untuk CDN memakai bitrate lain, seperti pemutar di Khatam. */
    private fun varianUrl(url: String, percobaan: Int): String {
        if (!url.startsWith("https://cdn.islamic.network/")) return url
        return when (percobaan) {
            1 -> url.replace("/128/", "/64/")
            2 -> url.replace("/128/", "/192/")
            else -> url
        }
    }

    // ---------- Pemutaran ----------

    private fun mulaiIndeks(i: Int, percobaanKe: Int) {
        if (i >= daftarUrl.size) { selesai(false); return }
        indeks = i
        percobaan = percobaanKe
        siap = false
        dijeda = false
        dijedaOlehFokus = false
        val gen = ++generasi
        handler.removeCallbacks(batasMuat)
        lepasPemutar()
        if (!mintaFokus()) {
            toast(tr("Audio sedang dipakai aplikasi lain (misalnya panggilan).", "Audio is being used by another app (for example a call)."))
            selesai(false)
            return
        }
        ambilKunci()
        try {
            val p = MediaPlayer()
            mp = p
            p.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(varianUrl(daftarUrl[i], percobaanKe))
            p.setOnPreparedListener { pemutar ->
                if (gen != generasi) return@setOnPreparedListener
                handler.removeCallbacks(batasMuat)
                siap = true
                gagalBerturut = 0
                if (!dijeda) {
                    pemutar.start()
                    terapkanKecepatan(pemutar)
                }
                perbaruiNotifikasi()
            }
            p.setOnCompletionListener {
                if (gen != generasi) return@setOnCompletionListener
                mulaiIndeks(indeks + 1, 0)
            }
            p.setOnErrorListener { _, _, _ ->
                if (gen == generasi) gagalMuat()
                true
            }
            handler.postDelayed(batasMuat, 30_000L)
            p.prepareAsync()
            perbaruiNotifikasi()
        } catch (_: Exception) {
            gagalMuat()
        }
    }

    private fun terapkanKecepatan(p: MediaPlayer) {
        if (kecepatan == 1.0f || Build.VERSION.SDK_INT < 23) return
        try { p.playbackParams = p.playbackParams.setSpeed(kecepatan) } catch (_: Exception) { }
    }

    private fun gagalMuat() {
        handler.removeCallbacks(batasMuat)
        generasi++
        lepasPemutar()
        if (percobaan < 2) { mulaiIndeks(indeks, percobaan + 1); return }
        if (daftarUrl.size > 1 && gagalBerturut < 4) {
            gagalBerturut++
            mulaiIndeks(indeks + 1, 0)
            return
        }
        toast(tr("Audio tidak dapat dimuat. Periksa koneksi internet lalu ulangi perintah.", "The audio could not be loaded. Check your internet connection and repeat the command."))
        selesai(false)
    }

    private fun jeda() {
        val p = mp ?: return
        try { if (p.isPlaying) p.pause() } catch (_: Exception) { }
        dijeda = true
        perbaruiNotifikasi()
    }

    private fun lanjut() {
        val p = mp ?: return
        dijeda = false
        dijedaOlehFokus = false
        if (siap) {
            if (!mintaFokus()) return
            try { p.start(); terapkanKecepatan(p) } catch (_: Exception) { }
        }
        perbaruiNotifikasi()
    }

    private fun lepasPemutar() {
        val p = mp
        mp = null
        try { p?.setOnCompletionListener(null); p?.setOnErrorListener(null); p?.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p?.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
    }

    private fun selesai(denganPesan: Boolean) {
        generasi++
        handler.removeCallbacks(batasMuat)
        lepasPemutar()
        lepasFokus()
        lepasKunci()
        if (denganPesan) toast(tr("Audio Al-Qur'an dihentikan.", "Qur'an audio stopped."))
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    // ---------- Fokus audio dan kunci daya ----------

    private fun mintaFokus(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val pendengar = fokus ?: AudioManager.OnAudioFocusChangeListener { perubahan ->
            when (perubahan) {
                AudioManager.AUDIOFOCUS_LOSS -> handler.post { selesai(false) }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> handler.post {
                    val p = mp
                    if (p != null && siap && !dijeda) { dijedaOlehFokus = true; jeda() }
                }
                AudioManager.AUDIOFOCUS_GAIN -> handler.post {
                    try { mp?.setVolume(1f, 1f) } catch (_: Exception) { }
                    if (dijedaOlehFokus) { dijedaOlehFokus = false; lanjut() }
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> handler.post { try { mp?.setVolume(0.3f, 0.3f) } catch (_: Exception) { } }
            }
        }.also { fokus = it }
        val hasil = if (Build.VERSION.SDK_INT >= 26) {
            val req = permintaanFokus ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
                .setOnAudioFocusChangeListener(pendengar, handler)
                .build().also { permintaanFokus = it }
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(pendengar, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return hasil == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun lepasFokus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) permintaanFokus?.let { am.abandonAudioFocusRequest(it) }
            else {
                @Suppress("DEPRECATION")
                fokus?.let { am.abandonAudioFocus(it) }
            }
        } catch (_: Exception) { }
        permintaanFokus = null
    }

    private fun ambilKunci() {
        try {
            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "$packageName:QuranSuara").apply { setReferenceCounted(false) }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        } catch (_: Exception) { }
        if (!penerimaTerdaftar) {
            try { registerReceiver(penerimaBising, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)); penerimaTerdaftar = true } catch (_: Exception) { }
        }
    }

    private fun lepasKunci() {
        try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Exception) { }
        wifiLock = null
        if (penerimaTerdaftar) { try { unregisterReceiver(penerimaBising) } catch (_: Exception) { }; penerimaTerdaftar = false }
    }

    // ---------- Notifikasi ----------

    private fun buatSaluran() {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(SALURAN, tr("Pemutar Al-Qur'an (perintah suara)", "Qur'an player (voice command)"), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun aksiPending(kode: Int, aksi: String): PendingIntent = PendingIntent.getService(
        this, kode, Intent(this, PemutarQuranService::class.java).setAction(aksi), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun bangunNotifikasi(isi: String): Notification {
        val buka = PendingIntent.getActivity(this, 9611, Intent(this, KhatamActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, SALURAN) else Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(tr("Memutar Al-Qur'an", "Playing the Qur'an"))
            .setContentText(isi)
            .setContentIntent(buka)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                if (dijeda) tr("Lanjut", "Resume") else tr("Jeda", "Pause"),
                aksiPending(9612, if (dijeda) ACTION_LANJUT else ACTION_JEDA)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                tr("Berhenti", "Stop"), aksiPending(9613, ACTION_BERHENTI)).build())
        return b.build()
    }

    private fun mulaiForeground(isi: String) {
        val n = bangunNotifikasi(isi)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
        } catch (_: Exception) {
            // Android menolak layanan foreground dimulai dari latar belakang (mis. perintah kendali tanpa audio berjalan).
            stopSelf()
        }
    }

    private fun perbaruiNotifikasi() {
        val status = if (dijeda) tr(" · dijeda", " · paused") else ""
        val posisi = if (daftarUrl.size > 1) " · " + (indeks + 1) + "/" + daftarUrl.size else ""
        try { getSystemService(NotificationManager::class.java).notify(NOTIF_ID, bangunNotifikasi(label + posisi + status)) } catch (_: Exception) { }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        generasi++
        lepasPemutar()
        lepasFokus()
        lepasKunci()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PUTAR = "com.novan.bateraibicara.action.QURAN_PUTAR"
        const val ACTION_JEDA = "com.novan.bateraibicara.action.QURAN_JEDA"
        const val ACTION_LANJUT = "com.novan.bateraibicara.action.QURAN_LANJUT"
        const val ACTION_BERHENTI = "com.novan.bateraibicara.action.QURAN_BERHENTI"
        const val EXTRA_KANDIDAT = "kandidat_perintah_quran"
        private const val SALURAN = "pemutar_quran_suara"
        private const val NOTIF_ID = 9610

        fun kirim(context: Context, aksi: String, kandidat: List<String>? = null) {
            val i = Intent(context, PemutarQuranService::class.java).setAction(aksi)
            if (kandidat != null) i.putStringArrayListExtra(EXTRA_KANDIDAT, ArrayList(kandidat))
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
}

/** Penafsir perintah putar Al-Qur'an yang berdiri sendiri (tanpa teks Al-Qur'an/Khatam): nama surah, nomor surah, ayat, rentang ayat, juz. */
object PenafsirQuran {
    data class Perintah(val juz: Int?, val surah: Int?, val ayat: Int?, val ayatAkhir: Int?)

    private val jumlahAyatSurah = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135, 112, 78, 118, 64, 77, 227,
        93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96,
        29, 22, 24, 13, 14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17,
        19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )

    /** Awal tiap juz (surah, ayat) menurut mushaf Madinah. */
    private val awalJuz = arrayOf(
        1 to 1, 2 to 142, 2 to 253, 3 to 93, 4 to 24, 4 to 148, 5 to 82, 6 to 111, 7 to 88, 8 to 41,
        9 to 93, 11 to 6, 12 to 53, 15 to 1, 17 to 1, 18 to 75, 21 to 1, 23 to 1, 25 to 21, 27 to 56,
        29 to 46, 33 to 31, 36 to 28, 39 to 32, 41 to 47, 46 to 1, 51 to 31, 58 to 1, 67 to 1, 78 to 1
    )

    private val namaLatin = listOf(
        "AlFaatihah", "AlBaqarah", "AliImran", "AnNisaa", "AlMaaidah", "AlAnaam",
        "AlAaraaf", "AlAnfaal", "AtTaubah", "Yunus", "Huud", "Yusuf",
        "ArRaad", "Ibrahim", "AlHijr", "AnNahl", "AlIsraa", "AlKahfi",
        "Maryam", "Thaahaa2", "AlAnbiyaa", "AlHajj", "AlMuminuun", "AnNuur",
        "AlFurqaan", "AsySyuaaraa", "AnNaml", "AlQashash", "AlAnkabuut", "ArRuum",
        "Luqman", "AsSajdah", "AlAhzab", "Sabaa", "Faathir", "Yaasiin",
        "AshShaaffaat", "Shaad", "AzZumar", "AlMuumin", "Fushshilat", "AsySyuura",
        "AzZukhruf", "AdDukhaan", "AlJaatsiyah", "AlAhqaaf", "Muhammad", "AlFath",
        "AlHujuraat", "Qaaf", "AdzDzaariyaat", "AthThuur", "AnNajm", "AlQamar",
        "ArRahmaan", "AlWaqiah", "AlHadiid", "AlMujaadilah", "AlHasyr", "AlMumtahanah",
        "AshShaff", "AlJumuah", "AlMunaafiquun", "AtTaghaabun", "AthThalaaq", "AtTahrim",
        "AlMulk", "AlQalam", "AlHaaqqah", "AlMaaarij", "Nuh", "AlJin",
        "AlMuzzammil", "AlMuddatstsir", "AlQiyaamah", "AlInsaan", "AlMursalaat", "AnNaba",
        "AnNaaziaat", "Abasa", "AtTakwiir", "AlInfithaar", "AlMuthaffifin", "AlInsyiqaaq",
        "AlBuruuj", "AthThaariq", "AlAalaa", "AlGhaasyiyah", "AlFajr", "AlBalad",
        "AsySyams", "AlLail", "AdhDhuhaa", "AlamNasyrah", "AtTiin", "AlAlaq",
        "AlQadr", "AlBayyinah", "AlZalzalah", "AlAadiyaat", "AlQaariah", "AtTakaatsur",
        "AlAshr", "AlHumazah", "AlFiil", "Quraisy", "AlMaauun", "AlKautsar",
        "AlKaafiruun", "AnNashr", "AlLahab", "AlIkhlash", "AlFalaq", "AnNaas"
    )

    fun jumlahAyat(surah: Int): Int = if (surah in 1..114) jumlahAyatSurah[surah - 1] else 0

    fun global(surah: Int, ayat: Int): Int {
        var g = ayat
        for (i in 1 until surah) g += jumlahAyatSurah[i - 1]
        return g
    }

    fun rentangJuz(juz: Int): IntRange? {
        if (juz !in 1..30) return null
        val (s, a) = awalJuz[juz - 1]
        val awal = global(s, a)
        val akhir = if (juz < 30) { val (s2, a2) = awalJuz[juz]; global(s2, a2) - 1 } else 6236
        return awal..akhir
    }

    private fun kolapsHuruf(teks: String): String {
        val sb = StringBuilder()
        for (c in teks.lowercase()) {
            if (c in 'a'..'z' && (sb.isEmpty() || sb[sb.length - 1] != c)) sb.append(c)
        }
        return sb.toString()
    }

    private fun gantiKataAngka(tokens: List<String>): List<String> {
        val dasar = mapOf(
            "nol" to 0, "satu" to 1, "dua" to 2, "tiga" to 3, "empat" to 4, "lima" to 5, "enam" to 6, "tujuh" to 7,
            "delapan" to 8, "sembilan" to 9, "sepuluh" to 10, "sebelas" to 11,
            "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
            "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
            "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19,
            "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
        )
        val hasil = mutableListOf<String>()
        var total = 0; var seg = 0; var ada = false
        fun tutup() { if (ada) hasil.add((total + seg).toString()); total = 0; seg = 0; ada = false }
        for (t in tokens) {
            val v = dasar[t]
            when {
                v != null -> { seg += v; ada = true }
                t == "belas" && ada -> seg += 10
                t == "puluh" && ada -> seg *= 10
                (t == "ratus" || t == "hundred") && ada -> { total += (if (seg == 0) 1 else seg) * 100; seg = 0 }
                t == "seratus" -> { total += 100; ada = true }
                (t == "dan" || t == "and") && ada -> { }
                else -> { tutup(); hasil.add(t) }
            }
        }
        tutup()
        return hasil
    }

    private fun cocokkanNamaSurah(sisa: String): Int? {
        val teks = kolapsHuruf(sisa)
        if (teks.isEmpty()) return null
        val awalan = listOf("asy", "ash", "adh", "adz", "ath", "al", "an", "ar", "as", "at", "ad", "az")
        var terbaik: Int? = null; var panjangTerbaik = 0
        fun coba(kandidat: String, nomor: Int) {
            if (kandidat.length < 2) return
            val cocok = if (kandidat.length <= 3) teks == kandidat else teks.contains(kandidat)
            if (cocok && kandidat.length > panjangTerbaik) { terbaik = nomor; panjangTerbaik = kandidat.length }
        }
        for (i in 0 until 114) {
            val lengkap = kolapsHuruf(namaLatin.getOrNull(i).orEmpty())
            coba(lengkap, i + 1)
            awalan.firstOrNull { lengkap.startsWith(it) && lengkap.length - it.length >= 4 }?.let { coba(lengkap.substring(it.length), i + 1) }
        }
        return terbaik
    }

    fun tafsir(kandidat: List<String>): Perintah? {
        val kataPerintah = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "please", "tolong", "nomor", "number",
            "ke", "dari", "the", "of", "di", "yang", "dengan", "lalu", "alquran", "quran")
        val kunciJuz = setOf("juz", "jus", "juzz")
        val kunciAyat = setOf("ayat", "ayah", "verse", "aya")
        val kunciSurah = setOf("surah", "surat", "sura")
        val penghubungRentang = setOf("sampai", "hingga", "dengan", "sd", "s", "d", "to", "through", "until", "till", "ke", "and", "dan", "sampe")
        for (ucapan in kandidat) {
            val tokens = gantiKataAngka(ucapan.lowercase().replace(Regex("[^\p{L}\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() })
            var juz: Int? = null; var surah: Int? = null; var ayat: Int? = null; var ayatAkhir: Int? = null
            val sisa = mutableListOf<String>()
            val angkaLepas = mutableListOf<Int>()
            var i = 0
            while (i < tokens.size) {
                val t = tokens[i]
                val berikut = tokens.getOrNull(i + 1)?.toIntOrNull()
                when {
                    t in kunciJuz && berikut != null -> { juz = berikut; i += 2; continue }
                    t in kunciAyat && berikut != null -> {
                        if (ayat == null) {
                            ayat = berikut
                            var k = i + 2
                            val awalK = k
                            while (k < tokens.size && tokens[k] in penghubungRentang) k++
                            if (k > awalK && k < tokens.size && tokens[k] in kunciAyat) k++
                            val angkaAkhir = tokens.getOrNull(k)?.toIntOrNull()
                            if (angkaAkhir != null) { ayatAkhir = angkaAkhir; k++ }
                            i = k
                        } else { ayatAkhir = berikut; i += 2 }
                        continue
                    }
                    t in kunciSurah && berikut != null -> { surah = berikut; i += 2; continue }
                    t in kunciJuz || t in kunciAyat || t in kunciSurah || t in kataPerintah -> { }
                    t.toIntOrNull() != null -> angkaLepas.add(t.toInt())
                    else -> sisa.add(t)
                }
                i++
            }
            val dariNama = cocokkanNamaSurah(sisa.joinToString(" "))
            if (surah == null && dariNama != null) {
                surah = dariNama
                if (ayat == null && juz == null && angkaLepas.isNotEmpty()) {
                    ayat = angkaLepas[0]
                    if (angkaLepas.size >= 2) ayatAkhir = angkaLepas[1]
                }
            } else if (surah == null && ayat == null && juz == null && angkaLepas.size >= 2) {
                surah = angkaLepas[0]; ayat = angkaLepas[1]
            } else if (surah == null && ayat == null && juz == null && angkaLepas.size == 1 && sisa.isEmpty()) {
                surah = angkaLepas[0]
            }
            if (juz == null && surah == null && ayat == null) continue
            return Perintah(juz, surah, ayat, ayatAkhir)
        }
        return null
    }
}
