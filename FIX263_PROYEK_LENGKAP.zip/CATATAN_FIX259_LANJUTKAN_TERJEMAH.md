# FIX259 - "putar/lanjutkan terjemahnya" setelah memutar ayat

Penyebab: kata "terjemahnya" tanpa nama surah tidak menghasilkan perintah, dan "lanjutkan ..." pendek dibaca sebagai perintah lanjut-putar (resume).
Perbaikan: (1) perintah putar/lanjutkan + terjemah dialihkan ke Al-Qur'an (bukan resume); (2) PenafsirQuran: terjemah tanpa surah = terjemahan saja (mode 2) dari perintah terakhir (surah dan rentang ayat tersimpan); terjemah ikut pada "ayat berikutnya" dan "ulangi"; (3) indeks lokal dibangun untuk surah perintah terakhir; (4) pesan bila terjemah per ayat tidak ditemukan kini menjelaskan cara menaruh berkas terjemah (nama memuat terjemah dan nomor ayat).
Catatan jujur: terjemah per ayat butuh berkas terjemah terpisah di folder surah (FIX257); terjemahan online hanya satu surah penuh. Belum dikompilasi/diuji di perangkat.
