# FIX256 - Lokasi suara lebih akurat dan tidak diawali angka

1. Kalimat lokasi tidak lagi diawali angka: NamaLokasi.bersihBagian membuang angka di depan, kode plus (mis. 6PH5+JX), dan bagian yang hanya angka; nomor rumah ditaruh setelah nama jalan ("Jalan X nomor 12"). Geocoder meminta 5 hasil dan memilih yang punya nama jalan.
2. Akurasi: ambilLokasiUntukCuaca(akurat = true) untuk "saya di mana" dan "perbarui lokasi": cache maksimal 15 detik, menunggu bacaan langsung hingga 20 meter, batas waktu 30 detik (cuaca tetap 2 km/12 detik). Ketelitian kurang dari 50 meter disebut apa adanya; bila lebih buruk, asisten menyarankan mengaktifkan GPS atau ke tempat terbuka.
3. Petunjuk penggunaan butir 38 / EN 35 diperbarui.
Catatan jujur: akurasi nyata tergantung GPS, cuaca, dan bangunan di sekitar; belum dikompilasi dengan Gradle dan belum diuji di perangkat. Uji kotlinc untuk bersihBagian lulus.
