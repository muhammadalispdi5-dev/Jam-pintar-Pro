# FIX258 - Akurasi lokasi suara ditingkatkan

Perintah lokasi kini menunggu bacaan GPS hingga 3 meter (maks 35 detik), mengumpulkan bacaan GPS, lalu merata-ratakan bacaan terbaik (bobot 1/akurasi kuadrat, maks 12) untuk menekan galat acak. Akurasi yang dilaporkan tetap yang terbaik dari satu bacaan. Kalimat jawaban menjelaskan batas GPS ponsel (sekitar 3-5 m di tempat terbuka).
Batas jujur: 1 meter tidak dapat dijamin dengan GPS ponsel biasa; itu butuh GPS khusus (RTK/GNSS eksternal). Hasil terbaik: GPS aktif mode akurasi tinggi, di luar ruangan, ponsel dengan GPS dua frekuensi (L1+L5), tunggu sampai bacaan stabil.
Petunjuk butir 38/35 diperbarui. Belum dikompilasi/diuji di perangkat.
