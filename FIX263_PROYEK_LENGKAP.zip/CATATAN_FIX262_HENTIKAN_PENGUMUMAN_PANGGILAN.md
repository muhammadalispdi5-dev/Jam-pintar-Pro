# FIX262 - Telungkup/tombol volume untuk pengumuman panggilan dan pesan

Peninjauan: pengumuman panggilan (seluler dan WhatsApp) serta notifikasi pesan sudah terdaftar di PembungkamTelungkup, tetapi ada tiga celah.
1. Tombol volume hanya terdeteksi lewat perubahan nilai volume; pada volume maksimal/minimal, atau saat HP berdering, tidak ada perubahan sehingga tidak terdeteksi. Perbaikan: TombolSuaraAccessibilityService.onKeyEvent kini menghentikan pengumuman lebih dulu bila ada suara terdaftar (andal saat layar mati/volume maksimal). Saat HP berdering atau dalam panggilan, tombol tetap diteruskan ke sistem.
2. Pendaftaran kedaluwarsa (90 dan 180 detik) walau pengumuman masih berulang. Perbaikan: diperbarui pada setiap pengulangan (CallerListener.ucapUlang dan ucapUlangNotif).
3. Jalur lama (Halaman.dispatchKeyEvent, siaran volume, poll volume, sensor telungkup) tetap berlaku sebagai cadangan bila layanan aksesibilitas tombol suara belum aktif.
Petunjuk ID butir 43, EN butir 40. Catatan jujur: belum dikompilasi/diuji di perangkat; jalur tombol andal memerlukan layanan aksesibilitas tombol suara aktif.
