package com.novan.bateraibicara

import android.content.Context
import android.location.Geocoder
import java.util.Locale

/**
 * Nama lokasi yang spesifik (kelurahan/desa, kecamatan atau kota, provinsi) dari koordinat tersimpan,
 * dipakai pada info sholat berikutnya. Nama otomatis disimpan dalam tiga bahasa (Indonesia, English,
 * Arab) agar sesuai bahasa pengucapan yang aktif; bahasa Jawa memakai nama Indonesia. Nama yang
 * diketik pengguna sendiri dipakai apa adanya dan tidak pernah ditimpa. Membutuhkan layanan geocoder
 * perangkat dan internet; bila tidak tersedia, pencarian diulang pada kesempatan berikutnya.
 */
object NamaLokasi {
    private val umum = setOf("Lokasi GPS", "Lokasi manual", "Lokasi jaringan", "Lokasi perangkat", "Lokasi tersimpan")

    private fun sp(context: Context) =
        context.applicationContext.getSharedPreferences("nama_lokasi", Context.MODE_PRIVATE)

    private fun koordinat(pp: PrayerPrefs): String =
        String.format(Locale.US, "%.5f|%.5f", pp.lat, pp.lon)

    /** Nama bawaan seperti "Lokasi GPS" belum menyebut tempat yang sebenarnya. */
    fun belumSpesifik(nama: String): Boolean = nama.isBlank() || nama.trim() in umum

    /** Nama pada pengaturan berasal dari pencarian otomatis (bukan ketikan pengguna) untuk koordinat sekarang. */
    fun otomatis(context: Context, pp: PrayerPrefs): Boolean {
        val s = sp(context)
        val nama = s.getString("auto_place", "") ?: ""
        return nama.isNotEmpty() && nama == pp.place && s.getString("auto_koord", "") == koordinat(pp)
    }

    /** Nama diketik pengguna sendiri: dipakai apa adanya, tidak dicari ulang. */
    fun diisiPengguna(context: Context, pp: PrayerPrefs): Boolean =
        pp.locationSet && !belumSpesifik(pp.place) && !otomatis(context, pp)

    /** Blokir: panggil dari thread latar. [kode] adalah "id", "en", atau "ar". Null bila tidak ditemukan. */
    fun cari(context: Context, lat: Double, lon: Double, kode: String = "id"): String? {
        return try {
            if (!Geocoder.isPresent()) return null
            val locale = if (kode == "id") Locale("id", "ID") else Locale(kode)
            val g = Geocoder(context.applicationContext, locale)
            @Suppress("DEPRECATION")
            val alamat = g.getFromLocation(lat, lon, 1)?.firstOrNull() ?: return null
            val bagian = listOfNotNull(alamat.subLocality, alamat.locality, alamat.subAdminArea, alamat.adminArea)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
            if (bagian.isEmpty()) null else bagian.take(4).joinToString(if (kode == "ar") "، " else ", ")
        } catch (e: Exception) {
            null
        }
    }

    /**
     * FIX254: alamat serinci mungkin untuk perintah suara "saya berada di mana": jalan, kelurahan/desa, kecamatan/kota,
     * kabupaten, provinsi, dan negara. Blokir: panggil dari thread latar. Null bila semua sumber gagal.
     */
    /** FIX256: membuang angka di awal, kode plus (misalnya 6PH5+JX), dan bagian yang hanya angka agar kalimat lokasi tidak diawali angka. */
    fun bersihBagian(teks: String?): String? {
        var t = teks?.trim() ?: return null
        if (Regex("^[0-9A-Za-z]{4,8}\\+[0-9A-Za-z]{2,}.*").matches(t)) return null
        t = t.replace(Regex("^[\\d\\s,./\\-]+"), "").trim()
        if (t.length < 3 || t.none { it.isLetter() }) return null
        return t
    }

    fun rinci(context: Context, lat: Double, lon: Double, kode: String = "id"): String? {
        val pemisah = if (kode == "ar") "، " else ", "
        try {
            if (Geocoder.isPresent()) {
                val g = Geocoder(context.applicationContext, if (kode == "id") Locale("id", "ID") else Locale(kode))
                @Suppress("DEPRECATION")
                val daftar = g.getFromLocation(lat, lon, 5).orEmpty()
                val a = daftar.firstOrNull { !bersihBagian(it.thoroughfare).isNullOrBlank() } ?: daftar.firstOrNull()
                if (a != null) {
                    val nama = bersihBagian(a.thoroughfare)
                    val nomor = a.subThoroughfare?.trim()?.takeIf { it.isNotEmpty() && it.length <= 6 }
                    val jalan = if (nama != null && nomor != null) nama + (if (kode == "id") " nomor " else " number ") + nomor else nama
                    val bangunan = bersihBagian(a.featureName)?.takeIf { jalan == null || !jalan.contains(it) }
                    val bagian = listOfNotNull(bangunan, jalan, bersihBagian(a.subLocality), bersihBagian(a.locality), bersihBagian(a.subAdminArea), bersihBagian(a.adminArea), bersihBagian(a.countryName))
                        .map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                    if (bagian.size >= 2) return bagian.take(7).joinToString(pemisah)
                }
            }
        } catch (_: Exception) { }
        var k: java.net.HttpURLConnection? = null
        return try {
            val u = "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=" + lat + "&longitude=" + lon + "&localityLanguage=" + (if (kode == "ar") "ar" else kode)
            val c = (java.net.URL(u).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 6_000; readTimeout = 8_000; useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            k = c
            if (c.responseCode !in 200..299) return null
            val o = org.json.JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            listOf(o.optString("locality"), o.optString("city"), o.optString("principalSubdivision"), o.optString("countryName"))
                .map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString(pemisah).ifBlank { null }
        } catch (_: Exception) { null } finally { try { k?.disconnect() } catch (_: Exception) { } }
    }

    /**
     * Cari nama lokasi (Indonesia, English, Arab) di latar belakang dan simpan bila nama sekarang
     * bukan ketikan pengguna. [selesai] dipanggil di thread latar dengan nama Indonesia (atau null).
     */
    fun perbaruiAsinkron(context: Context, pp: PrayerPrefs, selesai: ((String?) -> Unit)? = null) {
        val app = context.applicationContext
        val lat = pp.lat
        val lon = pp.lon
        Thread {
            val id = cari(app, lat, lon, "id")
            if (id != null && pp.lat == lat && pp.lon == lon && !diisiPengguna(app, pp)) {
                val en = cari(app, lat, lon, "en")
                val ar = cari(app, lat, lon, "ar")
                sp(app).edit()
                    .putString("n_en", en ?: "")
                    .putString("n_ar", ar ?: "")
                    .putString("auto_place", id)
                    .putString("auto_koord", koordinat(pp))
                    .apply()
                pp.place = id
            }
            selesai?.invoke(id)
        }.start()
    }

    /** Nama untuk diucapkan menurut bahasa pengucapan aktif (0 Indonesia, 1 English, 2 Arab, 3 Jawa). */
    fun nama(context: Context, pp: PrayerPrefs, bahasa: Int): String {
        if (!pp.locationSet) return ""
        if (diisiPengguna(context, pp)) return pp.place.trim()
        if (belumSpesifik(pp.place)) {
            cobaBilaBelumSpesifik(context, pp)
            return ""
        }
        val s = sp(context)
        val khusus = when (bahasa) {
            1 -> s.getString("n_en", "") ?: ""
            2 -> s.getString("n_ar", "") ?: ""
            else -> ""
        }
        return khusus.ifEmpty { pp.place.trim() }
    }

    /** Coba lagi paling sering sekali per jam, tanpa menahan pengucapan. */
    fun cobaBilaBelumSpesifik(context: Context, pp: PrayerPrefs) {
        if (!pp.locationSet || !belumSpesifik(pp.place)) return
        val s = sp(context)
        val sekarang = System.currentTimeMillis()
        if (sekarang - s.getLong("coba_terakhir", 0L) < 3_600_000L) return
        s.edit().putLong("coba_terakhir", sekarang).apply()
        perbaruiAsinkron(context, pp)
    }
}
