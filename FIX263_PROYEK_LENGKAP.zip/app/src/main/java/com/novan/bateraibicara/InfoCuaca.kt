package com.novan.bateraibicara

import java.util.Locale

/**
 * FIX225: penyusun laporan cuaca lengkap untuk perintah suara. Bagian ini murni logika (tanpa Android) agar dapat diuji.
 * Data diambil dari Open-Meteo (model prakiraan) oleh [OpenMeteo]; peringatan resmi dari BMKG ditambahkan oleh pemanggil.
 */
object InfoCuaca {
    enum class Fokus { UMUM, HUJAN, ANGIN, SUHU, KELEMBAPAN, UV }

    class Hari(
        val tanggal: String, val kode: Int, val maks: Double, val min: Double, val curah: Double,
        val peluang: Int, val uv: Double, val terbit: String, val terbenam: String, val anginMaks: Double
    )

    class Data(
        val waktu: String, val suhu: Double, val terasa: Double, val lembap: Int, val curahSaatIni: Double, val kode: Int,
        val awan: Int, val angin: Double, val arahAngin: Double, val embusan: Double, val siang: Boolean,
        val jam: List<String>, val jamPeluang: List<Int>, val jamCurah: List<Double>,
        val hari: List<Hari>,
        val jamSuhu: List<Double> = emptyList(), val jamKode: List<Int> = emptyList(), val jamAngin: List<Double> = emptyList()
    )

    /** [bagian]: -1 tanpa, 0 dini hari, 1 pagi, 2 siang, 3 sore, 4 malam; [rinci]: minta rincian seluruh bagian hari. */
    class Permintaan(val fokus: Fokus, val hari: Int, val bagian: Int = -1, val rinci: Boolean = false)

    private fun tr(english: Boolean, id: String, en: String) = if (english) en else id

    /** Mengenali fokus dan hari (0 hari ini, 1 besok, 2 lusa) dari ucapan yang sudah dipecah menjadi kata. */
    fun permintaanDari(t: List<String>): Permintaan {
        val s = t.toSet()
        val hari = when {
            s.contains("lusa") || (s.contains("day") && s.contains("after") && s.contains("tomorrow")) -> 2
            s.contains("besok") || s.contains("tomorrow") -> 1
            else -> 0
        }
        val fokus = when {
            s.any { it in setOf("hujan", "gerimis", "payung", "rain", "umbrella", "raining", "drizzle") } -> Fokus.HUJAN
            s.any { it in setOf("angin", "berangin", "wind", "windy") } -> Fokus.ANGIN
            s.any { it in setOf("uv", "ultraviolet") } || s.contains("sunburn") -> Fokus.UV
            s.any { it in setOf("kelembapan", "kelembaban", "lembap", "lembab", "humidity", "humid") } -> Fokus.KELEMBAPAN
            s.any { it in setOf("suhu", "temperature", "derajat", "panas", "dingin", "hot", "cold") } -> Fokus.SUHU
            else -> Fokus.UMUM
        }
        val bagian = when {
            s.contains("dini") && (s.contains("hari") || s.contains("pagi")) && !s.contains("peringatan") -> 0
            s.any { it in setOf("pagi", "morning") } -> 1
            s.any { it in setOf("siang", "afternoon", "midday", "noon") } -> 2
            s.any { it in setOf("sore", "petang", "evening") } -> 3
            s.any { it in setOf("malam", "night", "tonight") } -> 4
            else -> -1
        }
        val rinci = s.any { it in setOf("rinci", "terperinci", "detail", "detailnya", "detailed", "lengkap", "kompleks", "seluruh", "semua", "hourly", "breakdown", "seharian", "sepanjang", "complete", "perjam", "bagian") }
        return Permintaan(fokus, hari, bagian, rinci)
    }

    private fun bulat(x: Double) = Math.round(x).toInt()

    private fun desimal(x: Double, english: Boolean): String =
        String.format(if (english) Locale.US else Locale("id", "ID"), "%.1f", x)

    private fun jamDari(iso: String): String {
        val i = iso.indexOf('T')
        if (i < 0 || iso.length < i + 6) return iso
        return iso.substring(i + 1, i + 3) + "." + iso.substring(i + 4, i + 6)
    }

    fun kondisi(kode: Int, english: Boolean): String = if (english) when (kode) {
        0 -> "clear sky"; 1 -> "mainly clear"; 2 -> "partly cloudy"; 3 -> "overcast"; 45, 48 -> "foggy"
        51, 53, 55 -> "drizzle"; 56, 57 -> "freezing drizzle"; 61 -> "light rain"; 63 -> "moderate rain"; 65 -> "heavy rain"
        66, 67 -> "freezing rain"; 71, 73, 75, 77 -> "snow"; 80 -> "light rain showers"; 81 -> "moderate rain showers"; 82 -> "violent rain showers"
        85, 86 -> "snow showers"; 95 -> "thunderstorm"; 96, 99 -> "thunderstorm with hail"
        else -> "unknown weather conditions"
    } else when (kode) {
        0 -> "cerah"; 1 -> "umumnya cerah"; 2 -> "cerah berawan"; 3 -> "berawan tebal"; 45, 48 -> "berkabut"
        51, 53, 55 -> "gerimis"; 56, 57 -> "gerimis membeku"; 61 -> "hujan ringan"; 63 -> tr(false, "hujan sedang", "moderate rain"); 65 -> "hujan lebat"
        66, 67 -> "hujan membeku"; 71, 73, 75, 77 -> "salju"; 80 -> "hujan lokal ringan"; 81 -> tr(false, "hujan lokal sedang", "moderate rain showers"); 82 -> "hujan lokal sangat lebat"
        85, 86 -> "hujan salju"; 95 -> "badai petir"; 96, 99 -> "badai petir disertai es"
        else -> tr(false, "kondisi cuaca tidak diketahui", "unknown weather conditions")
    }

    private fun adaHujan(kode: Int) = kode in 51..67 || kode in 80..82 || kode in 95..99

    fun arahAngin(derajat: Double, english: Boolean): String {
        val idx = (((derajat % 360.0) + 360.0) % 360.0 / 45.0 + 0.5).toInt() % 8
        val id = listOf("utara", "timur laut", "timur", "tenggara", "selatan", "barat daya", "barat", "barat laut")
        val en = listOf("north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest")
        return if (english) en[idx] else id[idx]
    }

    fun kategoriAngin(kmh: Double, english: Boolean): String = when {
        kmh < 12 -> tr(english, "lemah", "light")
        kmh < 29 -> tr(english, "sedang", "moderate")
        kmh < 50 -> tr(english, "kencang", "strong")
        kmh < 75 -> tr(english, "sangat kencang", "very strong")
        else -> tr(english, "sangat kencang dan berbahaya", "dangerously strong")
    }

    fun kategoriUv(uv: Double, english: Boolean): String = when {
        uv < 3 -> tr(english, "rendah", "low")
        uv < 6 -> tr(english, "sedang", "moderate")
        uv < 8 -> tr(english, "tinggi", "high")
        uv < 11 -> tr(english, "sangat tinggi", "very high")
        else -> tr(english, "ekstrem", "extreme")
    }

    private fun saranUv(uv: Double, english: Boolean): String = when {
        uv < 3 -> ""
        uv < 8 -> tr(english, " Gunakan pelindung matahari bila lama di luar ruangan.", " Use sun protection if outdoors for long.")
        else -> tr(english, " Hindari paparan matahari langsung pada siang hari dan gunakan pelindung matahari.", " Avoid direct midday sun and use sun protection.")
    }

    private fun namaHari(hari: Int, english: Boolean) = when (hari) {
        0 -> tr(english, "hari ini", "today"); 1 -> tr(english, "besok", "tomorrow"); else -> tr(english, "lusa", "the day after tomorrow")
    }

    /** Indeks jam pertama pada data per jam yang tidak lebih awal dari jam sekarang. */
    private fun indeksJam(d: Data): Int {
        val awal = d.waktu.take(13)
        val i = d.jam.indexOfFirst { it.take(13) >= awal }
        return if (i < 0) 0 else i
    }

    private fun ringkasHujanEnamJam(d: Data, english: Boolean): String {
        val a = indeksJam(d)
        val b = minOf(d.jam.size, a + 6)
        if (a >= b) return ""
        var maks = 0
        var jamMulai: String? = null
        var total = 0.0
        for (i in a until b) {
            val p = d.jamPeluang.getOrElse(i) { 0 }.coerceAtLeast(0)
            val c = d.jamCurah.getOrElse(i) { 0.0 }
            if (p > maks) maks = p
            total += c
            if (jamMulai == null && (p >= 50 || c >= 0.3)) jamMulai = jamDari(d.jam[i])
        }
        return when {
            jamMulai != null -> tr(english,
                " Dalam enam jam ke depan peluang hujan mencapai " + maks + " persen, kemungkinan mulai sekitar pukul " + jamMulai + ", dengan perkiraan curah " + desimal(total, false) + " milimeter.",
                " In the next six hours the chance of rain reaches " + maks + " percent, possibly starting around " + jamMulai + ", with about " + desimal(total, true) + " millimeters expected.")
            maks >= 20 -> tr(english,
                " Dalam enam jam ke depan peluang hujan sampai " + maks + " persen, belum diperkirakan hujan berarti.",
                " In the next six hours the chance of rain is up to " + maks + " percent, with no significant rain expected.")
            else -> tr(english, " Dalam enam jam ke depan hujan tidak diperkirakan turun.", " No rain is expected in the next six hours.")
        }
    }

    private fun kalimatAngin(d: Data, english: Boolean): String {
        val sb = StringBuilder()
        sb.append(tr(english,
            " Angin dari arah " + arahAngin(d.arahAngin, false) + " dengan kecepatan " + bulat(d.angin) + " kilometer per jam, tergolong " + kategoriAngin(d.angin, false) + ".",
            " Wind from the " + arahAngin(d.arahAngin, true) + " at " + bulat(d.angin) + " kilometers per hour, " + kategoriAngin(d.angin, true) + "."))
        if (d.embusan.isFinite() && d.embusan >= d.angin + 10) {
            sb.append(tr(english, " Embusan sesaat hingga " + bulat(d.embusan) + " kilometer per jam.", " Gusts up to " + bulat(d.embusan) + " kilometers per hour."))
        }
        return sb.toString()
    }

    private fun kalimatHari(d: Data, h: Hari, hari: Int, english: Boolean): String {
        val nama = namaHari(hari, english)
        val sb = StringBuilder()
        sb.append(tr(english,
            "Prakiraan cuaca " + nama + ": " + kondisi(h.kode, false) + ". Suhu antara " + bulat(h.min) + " dan " + bulat(h.maks) + " derajat Celsius.",
            "Forecast for " + nama + ": " + kondisi(h.kode, true) + ". Temperature between " + bulat(h.min) + " and " + bulat(h.maks) + " degrees Celsius."))
        sb.append(tr(english,
            " Peluang hujan " + h.peluang + " persen, dengan perkiraan curah " + desimal(h.curah, false) + " milimeter.",
            " Chance of rain " + h.peluang + " percent, with about " + desimal(h.curah, true) + " millimeters expected."))
        if (h.anginMaks.isFinite()) sb.append(tr(english,
            " Angin paling kencang sekitar " + bulat(h.anginMaks) + " kilometer per jam.",
            " Strongest wind about " + bulat(h.anginMaks) + " kilometers per hour."))
        if (h.uv.isFinite()) sb.append(tr(english,
            " Indeks UV tertinggi " + bulat(h.uv) + ", tergolong " + kategoriUv(h.uv, false) + ".",
            " Peak UV index " + bulat(h.uv) + ", " + kategoriUv(h.uv, true) + "."))
        if (h.terbit.isNotBlank() && h.terbenam.isNotBlank()) sb.append(tr(english,
            " Matahari terbit pukul " + jamDari(h.terbit) + " dan terbenam pukul " + jamDari(h.terbenam) + ".",
            " Sunrise at " + jamDari(h.terbit) + " and sunset at " + jamDari(h.terbenam) + "."))
        return sb.toString()
    }

    private val awalBagian = intArrayOf(0, 5, 11, 15, 18)
    private val akhirBagian = intArrayOf(5, 11, 15, 18, 24)

    private fun namaBagian(b: Int, english: Boolean): String = if (english) arrayOf("early morning", "morning", "afternoon", "evening", "night")[b]
        else arrayOf("dini hari", "pagi", "siang", "sore", "malam")[b]

    private fun jamKe(iso: String): Int = iso.substringAfter('T', "").take(2).toIntOrNull() ?: -1

    /** Ringkasan satu bagian hari pada [tanggal] dari data per jam; null bila datanya tidak ada. */
    fun ringkasBagian(d: Data, tanggal: String, b: Int, dariJam: Int, english: Boolean): String? {
        val awal = maxOf(awalBagian[b], dariJam)
        val akhir = akhirBagian[b]
        val idx = d.jam.indices.filter { d.jam[it].startsWith(tanggal) && jamKe(d.jam[it]) in awal until akhir }
        if (idx.isEmpty()) return null
        val suhu = idx.mapNotNull { d.jamSuhu.getOrNull(it) }.filter { it.isFinite() }
        val peluang = idx.maxOf { d.jamPeluang.getOrElse(it) { 0 }.coerceAtLeast(0) }
        val curah = idx.sumOf { d.jamCurah.getOrElse(it) { 0.0 }.let { c -> if (c.isFinite()) c else 0.0 } }
        val angin = idx.mapNotNull { d.jamAngin.getOrNull(it) }.filter { it.isFinite() }.maxOrNull()
        val kode = idx.mapNotNull { d.jamKode.getOrNull(it) }.filter { it >= 0 }
        val hujan = kode.filter { adaHujan(it) }
        val pilih: Int? = if (hujan.isNotEmpty() && (peluang >= 40 || curah >= 0.2)) hujan.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            else kode.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        val sb = StringBuilder()
        val nama = namaBagian(b, english)
        sb.append(tr(english, nama.replaceFirstChar { it.uppercase() } + " pukul " + String.format("%02d", awal) + " sampai " + String.format("%02d", akhir) + ": ",
            nama.replaceFirstChar { it.uppercase() } + " from " + String.format("%02d", awal) + " to " + String.format("%02d", akhir) + ": "))
        sb.append(if (pilih != null) kondisi(pilih, english) else tr(english, "kondisi belum tersedia", "conditions unavailable"))
        if (suhu.isNotEmpty()) {
            val a = bulat(suhu.min()); val z = bulat(suhu.max())
            sb.append(if (a == z) tr(english, ", suhu " + a + " derajat", ", temperature " + a + " degrees") else tr(english, ", suhu " + a + " sampai " + z + " derajat", ", temperature " + a + " to " + z + " degrees"))
        }
        sb.append(tr(english, ", peluang hujan " + peluang + " persen", ", chance of rain " + peluang + " percent"))
        if (curah >= 0.1) sb.append(tr(english, ", curah sekitar " + desimal(curah, false) + " milimeter", ", about " + desimal(curah, true) + " millimeters of rain"))
        if (angin != null && angin >= 25) sb.append(tr(english, ", angin hingga " + bulat(angin) + " kilometer per jam", ", wind up to " + bulat(angin) + " kilometers per hour"))
        sb.append(".")
        return sb.toString()
    }

    /** Rincian bagian hari (satu bagian bila [bagian] >= 0, selain itu semua yang tersisa) untuk hari ke-[hariKe]. */
    fun rincianBagian(d: Data, hariKe: Int, bagian: Int, english: Boolean): String {
        val h = d.hari.getOrNull(minOf(hariKe, d.hari.size - 1)) ?: return ""
        val sekarangJam = if (hariKe == 0) jamKe(d.waktu).coerceAtLeast(0) else 0
        val tanggal = h.tanggal
        val sb = StringBuilder()
        if (bagian >= 0) {
            if (hariKe == 0 && akhirBagian[bagian] <= sekarangJam) {
                sb.append(tr(english, " Bagian " + namaBagian(bagian, false) + " hari ini sudah lewat.", " The " + namaBagian(bagian, true) + " part of today has already passed."))
                val lanjut = rincianBagian(d, 0, -1, english)
                if (lanjut.isNotBlank()) sb.append(tr(english, " Perkiraan sisa hari ini:", " Forecast for the rest of today:")).append(lanjut)
                return sb.toString()
            }
            ringkasBagian(d, tanggal, bagian, sekarangJam, english)?.let { sb.append(' ').append(it) }
            return sb.toString()
        }
        for (b in 0..4) {
            if (hariKe == 0 && akhirBagian[b] <= sekarangJam) continue
            ringkasBagian(d, tanggal, b, sekarangJam, english)?.let { sb.append(' ').append(it) }
        }
        return sb.toString()
    }

    /**
     * Menyusun jawaban. [tempat] nama daerah (boleh kosong), [peringatan] kalimat peringatan BMKG (boleh kosong).
     * Nama hari pada [Permintaan.hari] yang lebih besar dari data yang tersedia dipangkas ke hari terakhir.
     */
    fun susun(d: Data, tempat: String?, english: Boolean, minta: Permintaan, peringatan: String?): String {
        val lokasi = tempat?.takeIf { it.isNotBlank() } ?: tr(english, "lokasi Anda saat ini", "your current location")
        val sb = StringBuilder()
        val hariIni = d.hari.getOrNull(0)
        if (minta.hari > 0) {
            val h = d.hari.getOrNull(minOf(minta.hari, d.hari.size - 1))
            if (h != null) {
                sb.append(tr(english, "Untuk ", "For ")).append(lokasi).append(". ")
                if (minta.bagian >= 0) {
                    sb.append(namaHari(minta.hari, english).replaceFirstChar { it.uppercase() }).append('.').append(rincianBagian(d, minta.hari, minta.bagian, english))
                } else {
                    sb.append(kalimatHari(d, h, minta.hari, english))
                    sb.append(tr(english, " Rincian per bagian hari:", " Breakdown by part of day:")).append(rincianBagian(d, minta.hari, -1, english))
                }
            }
        } else if (minta.bagian >= 0) {
            sb.append(tr(english, "Untuk ", "For ")).append(lokasi).append(". ")
            sb.append(rincianBagian(d, 0, minta.bagian, english).trim())
        } else when (minta.fokus) {
            Fokus.UMUM -> {
                sb.append(tr(english,
                    "Cuaca terkini di " + lokasi + ", pembaruan pukul " + jamDari(d.waktu) + ": " + kondisi(d.kode, false) + ". Suhu " + bulat(d.suhu) + " derajat Celsius, terasa seperti " + bulat(d.terasa) + " derajat.",
                    "Current weather for " + lokasi + ", updated at " + jamDari(d.waktu) + ": " + kondisi(d.kode, true) + ". Temperature " + bulat(d.suhu) + " degrees Celsius, feels like " + bulat(d.terasa) + " degrees."))
                if (d.lembap in 0..100) sb.append(tr(english, " Kelembapan " + d.lembap + " persen.", " Humidity " + d.lembap + " percent."))
                if (d.angin.isFinite()) sb.append(kalimatAngin(d, english))
                if (d.curahSaatIni >= 0.1) sb.append(tr(english, " Saat ini ada curah hujan " + desimal(d.curahSaatIni, false) + " milimeter.", " Current rainfall is " + desimal(d.curahSaatIni, true) + " millimeters."))
                sb.append(ringkasHujanEnamJam(d, english))
                val sisaBagian = rincianBagian(d, 0, -1, english)
                if (sisaBagian.isNotBlank()) sb.append(tr(english, " Perkiraan per bagian hari:", " Forecast by part of day:")).append(sisaBagian)
                if (hariIni != null) {
                    sb.append(tr(english,
                        " Hari ini suhu antara " + bulat(hariIni.min) + " dan " + bulat(hariIni.maks) + " derajat, peluang hujan sampai " + hariIni.peluang + " persen.",
                        " Today temperatures range from " + bulat(hariIni.min) + " to " + bulat(hariIni.maks) + " degrees, with up to " + hariIni.peluang + " percent chance of rain."))
                    if (hariIni.uv.isFinite() && hariIni.uv >= 3) sb.append(tr(english,
                        " Indeks UV tertinggi hari ini " + bulat(hariIni.uv) + ", tergolong " + kategoriUv(hariIni.uv, false) + ".",
                        " Today's peak UV index is " + bulat(hariIni.uv) + ", " + kategoriUv(hariIni.uv, true) + "."))
                }
            }
            Fokus.HUJAN -> {
                val hujanSekarang = d.curahSaatIni >= 0.1 || adaHujan(d.kode)
                sb.append(tr(english, "Informasi hujan untuk " + lokasi + ". ", "Rain information for " + lokasi + ". "))
                sb.append(if (hujanSekarang) tr(english, "Saat ini sedang " + kondisi(d.kode, false) + ", curah " + desimal(d.curahSaatIni, false) + " milimeter.", "Right now it is " + kondisi(d.kode, true) + ", with " + desimal(d.curahSaatIni, true) + " millimeters.")
                    else tr(english, "Saat ini tidak sedang hujan.", "It is not raining right now."))
                sb.append(ringkasHujanEnamJam(d, english))
                if (hariIni != null) sb.append(tr(english,
                    " Sepanjang hari ini peluang hujan sampai " + hariIni.peluang + " persen dengan total sekitar " + desimal(hariIni.curah, false) + " milimeter.",
                    " Across today the chance of rain is up to " + hariIni.peluang + " percent with about " + desimal(hariIni.curah, true) + " millimeters in total."))
                d.hari.getOrNull(1)?.let { sb.append(tr(english, " Besok peluang hujan " + it.peluang + " persen.", " Tomorrow the chance of rain is " + it.peluang + " percent.")) }
                val perluPayung = d.jamPeluang.drop(indeksJam(d)).take(6).any { it >= 50 } || hujanSekarang
                sb.append(if (perluPayung) tr(english, " Sebaiknya membawa payung.", " It is wise to carry an umbrella.")
                    else tr(english, " Payung belum diperlukan dalam waktu dekat.", " An umbrella is not needed in the near term."))
            }
            Fokus.ANGIN -> {
                sb.append(tr(english, "Informasi angin untuk " + lokasi + ".", "Wind information for " + lokasi + "."))
                sb.append(kalimatAngin(d, english))
                if (hariIni != null && hariIni.anginMaks.isFinite()) sb.append(tr(english,
                    " Hari ini angin paling kencang sekitar " + bulat(hariIni.anginMaks) + " kilometer per jam.",
                    " Today the strongest wind is about " + bulat(hariIni.anginMaks) + " kilometers per hour."))
            }
            Fokus.SUHU -> {
                sb.append(tr(english,
                    "Suhu di " + lokasi + " saat ini " + bulat(d.suhu) + " derajat Celsius, terasa seperti " + bulat(d.terasa) + " derajat.",
                    "Temperature for " + lokasi + " is now " + bulat(d.suhu) + " degrees Celsius, feels like " + bulat(d.terasa) + " degrees."))
                if (hariIni != null) sb.append(tr(english,
                    " Hari ini terendah " + bulat(hariIni.min) + " dan tertinggi " + bulat(hariIni.maks) + " derajat.",
                    " Today's low is " + bulat(hariIni.min) + " and the high is " + bulat(hariIni.maks) + " degrees."))
            }
            Fokus.KELEMBAPAN -> {
                sb.append(tr(english, "Kelembapan di " + lokasi + " saat ini " + d.lembap + " persen.", "Humidity for " + lokasi + " is now " + d.lembap + " percent."))
                sb.append(when {
                    d.lembap >= 80 -> tr(english, " Udara sangat lembap sehingga terasa gerah.", " The air is very humid and feels muggy.")
                    d.lembap >= 60 -> tr(english, " Udara cukup lembap.", " The air is fairly humid.")
                    d.lembap >= 0 -> tr(english, " Udara relatif kering.", " The air is relatively dry.")
                    else -> ""
                })
                sb.append(tr(english, " Suhu " + bulat(d.suhu) + " derajat, terasa seperti " + bulat(d.terasa) + " derajat.", " Temperature " + bulat(d.suhu) + " degrees, feels like " + bulat(d.terasa) + " degrees."))
            }
            Fokus.UV -> {
                sb.append(tr(english, "Informasi sinar ultraviolet untuk " + lokasi + ". ", "Ultraviolet information for " + lokasi + ". "))
                if (hariIni != null && hariIni.uv.isFinite()) {
                    sb.append(tr(english,
                        "Indeks UV tertinggi hari ini " + bulat(hariIni.uv) + ", tergolong " + kategoriUv(hariIni.uv, false) + ".",
                        "Today's peak UV index is " + bulat(hariIni.uv) + ", " + kategoriUv(hariIni.uv, true) + "."))
                    sb.append(saranUv(hariIni.uv, english))
                } else sb.append(tr(english, "Data indeks UV belum tersedia.", "UV index data is unavailable."))
                if (!d.siang) sb.append(tr(english, " Saat ini malam hari sehingga paparan UV hampir nol.", " It is night now, so UV exposure is almost zero."))
            }
        }
        if (!peringatan.isNullOrBlank()) sb.append(' ').append(peringatan)
        sb.append(tr(english,
            " Data prakiraan dari Open-Meteo, bukan peringatan resmi. Untuk peringatan resmi, ucapkan peringatan dini BMKG.",
            " Forecast data from Open-Meteo, not an official warning. For official warnings, say BMKG early warning."))
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }
}
