package com.novan.bateraibicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.Toast
import java.util.Locale
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * FIX96: pemutar Al-Qur'an latar belakang untuk perintah suara, termasuk saat layar terkunci.
 * Layanan foreground (mediaPlayback) memutar audio tanpa membuka layar apa pun, sehingga pengguna tetap di layar
 * kunci atau layar depan. Mengikuti qari dan kecepatan yang disimpan di Khatam. Dikendalikan dengan perintah suara
 * (berhenti, jeda, lanjut) atau tombol pada notifikasi.
 */
class PemutarQuranService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var mp: PemutarAudio? = null
    private var daftarUrl: List<String> = emptyList()
    private var indeks = 0
    private var percobaan = 0
    private var gagalBerturut = 0
    private var generasi = 0
    // Cadangan CDN Alafasy bila URL qari utama gagal; audio lokal tetap selalu dicoba lebih dahulu.
    private var daftarUrlCadangan: List<String?> = emptyList()
    private var pakaiUrlCadangan = false
    // FIX191: qari yang tidak ada di daftar offline dan ditemukan lewat pencarian online (diisi pekerja latar, dipakai putar()).
    @Volatile private var qariOnlineHasil: Pair<String, String>? = null
    private var dijeda = false
    private var dijedaOlehFokus = false
    private var siap = false
    private var label = ""
    private var kecepatan = 1.0f
    // FIX98: pengulangan, jeda antarbagian, dan pelacakan posisi.
    private var ulangN = 1                 // jumlah putaran; 0 = tanpa batas
    private var perAyatMode = false        // true: tiap bagian diulang berturut-turut; false: seluruh daftar diulang
    private var jedaMs = 0L
    private var terakhirHangat = 0L // FIX206
    // FIX207: pemuat awal bagian berikutnya (hanya sumber internet, keluaran stereo)
    private var pramuat: PemutarAudio? = null
    private var pramuatIndeks = -1
    private var pramuatUrl = ""
    private var pramuatSiap = false
    private var globalDasar: IntArray? = null
    private var surahBerkas = 0
    private var menungguJeda = false
    private var lanjutSetelahJeda = false
    private var berikutSetelahJeda = 0
    private val penyambungJeda = Runnable {
        menungguJeda = false
        if (dijeda) { lanjutSetelahJeda = true } else mulaiIndeks(berikutSetelahJeda, 0)
    }
    private var fokus: AudioManager.OnAudioFocusChangeListener? = null
    private var permintaanFokus: AudioFocusRequest? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var cpuLock: PowerManager.WakeLock? = null
    private var penerimaTerdaftar = false
    private val penerimaBising = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) jeda()
        }
    }
    private val batasMuat = Runnable { gagalMuat() }
    // Indeks audio per surah: satu kali pemindaian, lalu seluruh ayat diambil dari memori.
    // Cache statis agar tetap tersedia ketika service selesai lalu dibuat ulang.
    private val indeksAudioLokal: MutableMap<Int, Map<Int?, Uri>> get() = cacheAudioQuran
    private val kunciIndeksAudio: Any get() = kunciCacheAudioQuran
    private var identitasQariIndeks: String
        get() = identitasCacheAudioQuran
        set(value) { identitasCacheAudioQuran = value }
    // FIX180: pemindaian penyimpanan tidak boleh berjalan pada thread utama Android.
    private val pekerjaIndeksAudio = Executors.newSingleThreadExecutor { r ->
        Thread(r, "JamPintar-QuranIndex").apply { isDaemon = true }
    }
    private val nomorPermintaanPutar = AtomicInteger(0)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(BahasaAplikasi.bungkus(newBase))
    }

    private fun tr(id: String, en: String) = if (BahasaAplikasi.tampilan(this) == 1) en else id
    private val efek by lazy { EfekAudioLatar(applicationContext) }
    private fun toast(teks: String) { try { Toast.makeText(applicationContext, teks, Toast.LENGTH_LONG).show() } catch (_: Exception) { } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        buatSaluran()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val aksi = intent?.action
        // Layanan foreground wajib memanggil startForeground secepatnya setelah startForegroundService.
        mulaiForeground(if (siap || mp != null) label else tr("Menyiapkan audio…", "Preparing audio…"))
        when (aksi) {
            ACTION_PUTAR -> jadwalkanPutar(intent?.getStringArrayListExtra(EXTRA_KANDIDAT).orEmpty())
            ACTION_JEDA -> { nomorPermintaanPutar.incrementAndGet(); if (mp == null) tidakAdaAudio() else jeda() }
            ACTION_LANJUT -> { nomorPermintaanPutar.incrementAndGet(); if (mp == null) tidakAdaAudio() else lanjut() }
            ACTION_BERHENTI -> { nomorPermintaanPutar.incrementAndGet(); selesai(true) }
            else -> if (mp == null) selesai(false)
        }
        return START_NOT_STICKY
    }

    private fun tidakAdaAudio() {
        toast(tr("Tidak ada audio Al-Qur'an yang sedang diputar oleh perintah suara.", "No Qur'an audio is currently playing from a voice command."))
        selesai(false)
    }

    // ---------- Perintah ----------

    /**
     * FIX180: persiapkan indeks audio di thread khusus. onStartCommand dan seluruh
     * pengelolaan MediaPlayer tetap berjalan pada main thread; hanya akses penyimpanan
     * (File, MediaStore, dan SAF) yang dipindahkan ke pekerja latar.
     */
    private fun jadwalkanPutar(kandidat: List<String>) {
        val nomor = nomorPermintaanPutar.incrementAndGet()
        val salinan = kandidat.toList()
        hangatkanJaringan()
        pekerjaIndeksAudio.execute {
            try {
                val kh = getSharedPreferences("khatam_quran", MODE_PRIVATE)
                // Bila pengguna menyebut nama qari dalam kalimat, siapkan indeks lokal untuk qari itu,
                // bukan untuk qari yang sebelumnya tersimpan.
                val klausaQari = salinan.mapNotNull { QariSuara.pisah(it) }.firstOrNull()
                if (klausaQari != null && klausaQari.first.isNotBlank()) {
                    val aktif = kh.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
                    var pilihan = QariSuara.cari(this, klausaQari.first, aktif)
                    qariOnlineHasil = null
                    if (pilihan == null && adaInternet()) {
                        // FIX191: qari belum ada di daftar offline; cari di katalog online lalu putar secara online.
                        handler.post { toast(tr("Qari belum ada di daftar offline; mencari secara online.", "The reciter is not in the offline list; searching online.")) }
                        pilihan = QariSuara.cariOnline(this, klausaQari.first, aktif)
                        qariOnlineHasil = pilihan
                    }
                    if (pilihan != null) {
                        kh.edit().putString("qari_audio_id", pilihan.first).putString("qari_audio_nama", pilihan.second).commit()
                    }
                }
                val identitas = identitasIndeks(kh)
                synchronized(kunciIndeksAudio) {
                    if (identitas != identitasQariIndeks) {
                        indeksAudioLokal.clear()
                        identitasQariIndeks = identitas
                    }
                }
                // Bangun indeks audio lokal sebelum menyusun playlist suara. Selain satu surah,
                // dukung pula seluruh surah yang tercakup dalam perintah juz.
                val tafsir = PenafsirQuran.tafsirLengkap(salinan).first
                val teks = salinan.joinToString(" ").lowercase(Locale.ROOT)
                    .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
                val seluruh = listOf("seluruh quran", "seluruh al quran", "seluruh alquran", "semua quran", "semua al quran", "semua alquran",
                    "alquran lengkap", "quran lengkap", "alquran keseluruhan", "alquran secara keseluruhan", "alquran seluruhnya",
                    "full quran", "whole quran", "entire quran", "all quran", "complete quran", "quran secara keseluruhan",
                    "al quran secara keseluruhan", "quran dari awal sampai akhir", "al quran dari awal sampai akhir").any { teks.contains(it) }
                val targetSurah = linkedSetOf<Int>()
                // FIX260: folder pustaka pengguna hanya dipindai bila terjemah diminta atau mode offline, agar pemutaran biasa tetap cepat.
                val perluPustaka = (tafsir?.terjemah ?: 0) != 0 || listOf("offline", "luring", "penyimpanan", "folder", "memori", "ponsel", "tersimpan", "lokal", "terjemah").any { teks.contains(it) } || Regex("\\bhp\\b").containsMatchIn(teks)
                if (seluruh) {
                    targetSurah.addAll(1..114)
                } else if (tafsir?.juz != null) {
                    PenafsirQuran.rentangJuz(tafsir.juz)?.forEach { global ->
                        PenafsirQuran.posisiDariGlobal(global)?.first?.let { targetSurah.add(it) }
                    }
                } else if (tafsir?.halaman != null) {
                    try {
                        val cached = org.json.JSONObject(File(filesDir, "quran_ar.json").readText(Charsets.UTF_8))
                        val surahs = cached.optJSONObject("data")?.optJSONArray("surahs")
                        var global = 0
                        if (surahs != null) for (si in 0 until surahs.length()) {
                            val ayahs = surahs.optJSONObject(si)?.optJSONArray("ayahs") ?: continue
                            for (ai in 0 until ayahs.length()) {
                                global++
                                if (ayahs.optJSONObject(ai)?.optInt("page", -1) == tafsir.halaman) {
                                    PenafsirQuran.posisiDariGlobal(global)?.first?.let { targetSurah.add(it) }
                                }
                            }
                        }
                    } catch (_: Exception) { }
                } else {
                    var surahTarget = tafsir?.surah
                    // FIX259: perintah tanpa surah ("ulangi", "putar terjemahnya") memakai surah pada perintah terakhir.
                    if (surahTarget == null && tafsir != null && tafsir.relatif == 0 && tafsir.juz == null && tafsir.halaman == null) surahTarget = muatPerintahTerakhir(kh)?.surah
                    if (tafsir != null && tafsir.relatif != 0) {
                        val s = kh.getInt("terakhir_surah", 1).coerceIn(1, 114)
                        val a = kh.getInt("terakhir_ayat", 1).coerceIn(1, PenafsirQuran.jumlahAyat(s))
                        if (tafsir.relatifSatuan == 2) {
                            val juzTujuan = (PenafsirQuran.juzDari(s, a) + tafsir.relatif).takeIf { it in 1..30 }
                            juzTujuan?.let { PenafsirQuran.rentangJuz(it)?.forEach { global -> PenafsirQuran.posisiDariGlobal(global)?.first?.let(targetSurah::add) } }
                            surahTarget = null
                        } else {
                            surahTarget = if (tafsir.relatifSatuan == 1) (s + tafsir.relatif).takeIf { it in 1..114 }
                                else PenafsirQuran.posisiDariGlobal(PenafsirQuran.global(s, a) + tafsir.relatif)?.first
                        }
                    }
                    if (surahTarget != null && surahTarget in 1..114) targetSurah.add(surahTarget)
                }
                if (nomor != nomorPermintaanPutar.get()) return@execute
                // FIX206: surah pertama selalu diindeks; surah berikutnya (perintah juz/seluruh Al-Qur'an) dibatasi sekitar 2,5 detik bila ada internet
                // agar pemutaran tidak menunggu pemindaian penyimpanan yang lama. Surah yang belum terindeks diputar dari internet.
                val batasWaktu = if (adaInternet()) android.os.SystemClock.elapsedRealtime() + 2_500L else Long.MAX_VALUE // tanpa internet: semua diindeks
                var pertama = true
                for (target in targetSurah) {
                    if (nomor != nomorPermintaanPutar.get()) return@execute
                    if (!pertama && android.os.SystemClock.elapsedRealtime() > batasWaktu) break
                    pertama = false
                    if (perluPustaka) {
                        try { PustakaAudio.cariBercache(this, target, PenafsirQuran.namaTampil(target), PenafsirQuran.jumlahAyat(target), kh.getString("folder_audio_tree_uri", null)) } catch (_: Exception) { }
                    }
                    val sudahAda = synchronized(kunciIndeksAudio) { indeksAudioLokal.containsKey(target) }
                    if (!sudahAda) {
                        val hasil = bangunIndeksAudioLokal(target)
                        synchronized(kunciIndeksAudio) { indeksAudioLokal[target] = hasil }
                    }
                }
            } catch (_: Exception) {
                // Bila indeks gagal, pemutar tetap boleh memakai URL streaming.
            }
            handler.post {
                if (nomor == nomorPermintaanPutar.get()) putar(salinan)
            }
        }
    }

    /**
     * FIX206: pemanasan jaringan. Sambil indeks audio lokal disusun, nama server audio diterjemahkan ke alamat IP di
     * utas terpisah (DNS tersimpan di sistem), sehingga saat MediaPlayer membuka sambungan, tahap pencarian server
     * sudah selesai. Semua kegagalan diabaikan; ini hanya mempercepat, tidak mengubah hasil.
     */
    private fun hangatkanJaringan() {
        if (!adaInternet()) return
        val sekarang = android.os.SystemClock.elapsedRealtime()
        if (sekarang - terakhirHangat < 120_000L) return
        terakhirHangat = sekarang
        for (host in listOf("cdn.islamic.network", "archive.org", "download.mp3quran.net")) {
            Thread {
                try { java.net.InetAddress.getAllByName(host) } catch (_: Exception) { }
            }.also { it.isDaemon = true }.start()
        }
    }

    /** Identitas indeks audio lokal: qari + mode pencocokan (S = ketat saat ada internet, L = longgar tanpa internet). */
    private fun identitasIndeks(kh: android.content.SharedPreferences): String =
        (kh.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy") + "|" + (kh.getString("qari_audio_nama", "") ?: "") + "|" +
            (if (adaInternet()) "S" else "L") + "|" + (System.currentTimeMillis() / 300_000L) + "|p257"

    /** Ada jaringan yang berkemampuan internet. Bila status jaringan tidak dapat dibaca, dianggap ada agar pemutaran online tidak diblokir. */
    private fun adaInternet(): Boolean = try {
        // FIX222: pada HP tertentu (mis. Samsung dengan penghemat data atau pembatasan latar belakang) activeNetwork bisa kosong
        // ketika layanan dipanggil dari asisten suara, padahal internet berfungsi. Karena itu beberapa penanda diperiksa dan
        // hanya bila semuanya jelas menyatakan tidak ada jaringan, hasilnya false.
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val aktif = cm.activeNetwork
        var ada = aktif != null && (cm.getNetworkCapabilities(aktif)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) != false)
        if (!ada) {
            for (n in cm.allNetworks) {
                if (cm.getNetworkCapabilities(n)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true) { ada = true; break }
            }
        }
        if (!ada) {
            @Suppress("DEPRECATION")
            ada = cm.activeNetworkInfo?.isConnectedOrConnecting == true
        }
        ada
    } catch (_: Exception) { true }

    private fun putar(kandidatAsli: List<String>) {
        var kandidat = kandidatAsli
        val kh = getSharedPreferences("khatam_quran", MODE_PRIVATE)
        if (!kh.getBoolean("perintah_suara_putar_aktif", true)) {
            toast(tr("Perintah suara untuk memutar dinonaktifkan. Aktifkan di Pengaturan Pemutaran Audio Khatam.", "Voice command for playback is turned off. Turn it on in Khatam Audio Playback Settings."))
            if (mp == null) selesai(false)
            return
        }
        // FIX142: klausa pemilihan qari ("pilih qari Alafasy", "putar surah Yasin dengan qari Sudais") ditangani di sini,
        // sehingga layar Khatam tidak perlu dibuka.
        val klausa = kandidat.mapNotNull { u -> QariSuara.pisah(u)?.let { u to it } }.firstOrNull()
        if (klausa != null) {
            val namaDiminta = klausa.second.first
            val sisa = klausa.second.second
            val qariAktif = kh.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
            val ketemu = if (namaDiminta.isBlank()) null else (QariSuara.cari(this, namaDiminta, qariAktif) ?: qariOnlineHasil)
            qariOnlineHasil = null
            if (ketemu == null) {
                if (namaDiminta.isNotBlank() && !adaInternet()) {
                    toast(tr("Qari \"" + namaDiminta + "\" tidak ada di daftar offline dan tidak dapat dicari online karena tidak ada koneksi internet.",
                        "Reciter \"" + namaDiminta + "\" is not in the offline list and could not be searched online because there is no internet connection."))
                } else toast(tr("Qari \"" + namaDiminta + "\" tidak dikenali, baik di daftar offline maupun online. Ucapkan misalnya: pilih qari Alafasy, Sudais, Husary, atau qari anak.",
                    "Reciter \"" + namaDiminta + "\" was not recognized in the offline or online list. Say for example: choose reciter Alafasy, Sudais, Husary, or kids reciter."))
                if (mp == null) selesai(false)
                return
            }
            kh.edit().putString("qari_audio_id", ketemu.first).putString("qari_audio_nama", ketemu.second).apply()
            if (QariSuara.sisaHanyaPengisi(sisa)) {
                toast(tr("Qari dipilih: ", "Reciter selected: ") + ketemu.second)
                if (mp == null) selesai(false)
                return
            }
            toast(tr("Qari dipilih: ", "Reciter selected: ") + ketemu.second)
            kandidat = kandidat.map { u -> QariSuara.pisah(u)?.second ?: u }
        }
        // Pertahankan indeks antarperintah agar perintah berikutnya tidak memindai ulang penyimpanan.
        // Indeks hanya dibuang jika pengguna mengganti qari.
        val identitasQari = identitasIndeks(kh)
        synchronized(kunciIndeksAudio) {
            if (identitasQari != identitasQariIndeks) {
                indeksAudioLokal.clear()
                identitasQariIndeks = identitasQari
            }
        }
        val teksPerintah = kandidat.joinToString(" ").lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()
        val seluruhQuran = listOf("seluruh quran", "seluruh al quran", "seluruh alquran", "semua quran", "semua al quran", "semua alquran",
            "alquran lengkap", "quran lengkap", "alquran keseluruhan", "alquran secara keseluruhan", "alquran seluruhnya",
            "full quran", "whole quran", "entire quran", "all quran", "complete quran", "quran secara keseluruhan",
            "al quran secara keseluruhan", "quran dari awal sampai akhir", "al quran dari awal sampai akhir").any { teksPerintah.contains(it) }
        val tafsirLengkap = PenafsirQuran.tafsirLengkap(kandidat)
        val hasilTafsir = tafsirLengkap.first
        val namaTakDikenal = tafsirLengkap.second
        if (!seluruhQuran && hasilTafsir == null && namaTakDikenal != null) {
            // FIX100: nama surah yang diucapkan tidak dikenali. Tidak memutar apa pun (jangan menebak atau memakai surah terakhir).
            toast(tr("Nama surah \"" + namaTakDikenal + "\" tidak dikenali, jadi tidak ada audio yang diputar. Ucapkan nomor surah, misalnya: putar surah 112 ayat 1.",
                "The surah name \"" + namaTakDikenal + "\" was not recognized, so nothing was played. Say the surah number, for example: play surah 112 verse 1."))
            if (mp == null) selesai(false)
            return
        }
        if (!seluruhQuran && hasilTafsir == null) {
            val didengar = kandidat.firstOrNull().orEmpty()
            toast(tr("Perintah belum dikenali", "Command not recognized") + (if (didengar.isNotBlank()) ": \"" + didengar + "\"" else "") +
                tr(". Coba ucapkan: putar surah Al Fatihah ayat 7 sebanyak 5 kali, putar halaman 12 tiga kali, putar surah 36 ayat 1 sampai 10, putar juz 30, atau ayat berikutnya.",
                    ". Try saying: play surah Al Fatihah verse 7 five times, play page 12 three times, play surah 36 verses 1 to 10, play juz 30, or next verse."))
            if (mp == null) selesai(false)
            return
        }
        var perintah: PenafsirQuran.Perintah = hasilTafsir ?: PenafsirQuran.Perintah(null, 1, 1, 7)
        if (!seluruhQuran && perintah.ulangiTerakhir) {
            val dasar = muatPerintahTerakhir(kh)
            if (dasar == null) {
                toast(tr("Belum ada perintah putar sebelumnya yang dapat diulang.", "There is no previous play command to repeat."))
                if (mp == null) selesai(false)
                return
            }
            perintah = dasar.copy(ulang = perintah.ulang, perAyat = perintah.perAyat, kecepatan = perintah.kecepatan, jedaDetik = perintah.jedaDetik, terjemah = perintah.terjemah)
        } else if (!seluruhQuran && perintah.relatif != 0) {
            val hitung = hitungRelatif(kh, perintah)
            if (hitung == null) {
                if (mp == null) selesai(false)
                return
            }
            perintah = hitung
        }
        val p = perintah
        val surah = p.surah ?: kh.getInt("terakhir_surah", 1).coerceIn(1, 114)
        var qari = kh.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        qari = when (qari) {
            "ar.sudais" -> "ar.abdurrahmaansudais"
            "ar.shuraim" -> "ar.saoodshuraym"
            "ar.abdulbasit" -> "ar.abdulbasitmurattal"
            "ar.ajamy" -> "ar.ahmedajamy"
            "ar.muhammadayoub" -> "ar.muhammadayyoub"
            else -> qari
        }
        val perSurahSaja = qari.startsWith("mp3quran|")
        val qariAyat = if (perSurahSaja) "ar.alafasy" else qari
        // FIX142: pengaturan bawaan Khatam (pengulangan per ayat, jeda antar ayat) berlaku bila perintah tidak menyebutnya.
        val ulangBawaan = kh.getInt("pengulangan_audio_ayat", 1).let { if (it in 0..10) it else 1 }
        val pakaiBawaanUlang = p.ulang == 1 && !p.perAyat && !perintah.ulangiTerakhir && p.relatif == 0 && ulangBawaan != 1 && p.ayat != null
        val ulang = if (pakaiBawaanUlang) ulangBawaan else p.ulang
        val perAyatEfektif = p.perAyat || pakaiBawaanUlang
        val jedaBawaan = kh.getInt("jeda_antar_ayat_detik", 2).let { if (it in listOf(0, 2, 5, 10)) it else 2 }
        val urls = ArrayList<String>()
        var globalList: IntArray? = null
        var berkasSurah = 0
        // FIX205: audio terjemahan Indonesia hanya ada per surah penuh.
        val terjemahDiminta = p.terjemah
        var urlTerjemah: String? = null
        // FIX257: terjemahan dari berkas terpisah milik pengguna (per ayat atau satu surah) di penyimpanan.
        var terjAyatPengguna: Map<Int, Uri> = emptyMap()
        var terjSurahPengguna: Uri? = null
        var surahPustaka = 0
        var pustakaAktif = false
        var teksLabel: String
        var catatan = ""
        var simpanJuz = -1
        var simpanSurah = -1
        var simpanDari = -1
        var simpanSampai = -1
        val juzDiminta = p.juz
        val halamanDiminta = p.halaman
        if (seluruhQuran) {
            // Seluruh mushaf diputar berurutan dari Al-Fatihah ayat 1 hingga An-Nas ayat 6.
            // Gunakan endpoint audio per ayat agar daftar lengkap tetap dapat dijeda/dilanjutkan.
            for (g in 1..6236) urls.add(urlAyat(qariAyat, g))
            globalList = IntArray(6236) { it + 1 }
            teksLabel = tr("Seluruh Al-Qur'an · 114 surah · 30 juz", "The complete Qur'an · 114 surahs · 30 juz")
            simpanSurah = 1; simpanDari = 1; simpanSampai = 7
            if (perSurahSaja) catatan = tr("Qari pilihan hanya menyediakan audio per surah; pemutaran lengkap memakai Alafasy agar semua ayat dapat diputar berurutan.",
                "The selected reciter only provides whole-surah audio; full playback uses Alafasy so every verse can play in sequence.")
        } else if (halamanDiminta != null) {
            if (halamanDiminta !in 1..604) {
                toast(tr("Nomor halaman mushaf harus 1 sampai 604.", "Mushaf page number must be from 1 to 604."))
                if (mp == null) selesai(false)
                return
            }
            // Gunakan metadata halaman dari cache mushaf yang sama dengan halaman Khatam.
            // Dengan demikian batas halaman mengikuti mushaf Madinah, bukan perkiraan jumlah ayat.
            try {
                val cache = File(filesDir, "quran_ar.json")
                if (!cache.isFile) throw IllegalStateException("cache")
                val rootJson = org.json.JSONObject(cache.readText(Charsets.UTF_8))
                val surahs = rootJson.optJSONObject("data")?.optJSONArray("surahs")
                    ?: throw IllegalStateException("surahs")
                var global = 0
                for (si in 0 until surahs.length()) {
                    val surahObj = surahs.optJSONObject(si) ?: continue
                    val ayahs = surahObj.optJSONArray("ayahs") ?: continue
                    for (ai in 0 until ayahs.length()) {
                        global++
                        val ayahObj = ayahs.optJSONObject(ai) ?: continue
                        if (ayahObj.optInt("page", -1) == halamanDiminta) {
                            urls.add(urlAyat(qariAyat, global))
                            val current = global
                            globalList = (globalList ?: IntArray(0)) + current
                        }
                    }
                }
                if (urls.isEmpty()) throw IllegalStateException("empty")
                teksLabel = tr("Halaman mushaf ", "Mushaf page ") + halamanDiminta
                val first = globalList!!.first()
                val pos = PenafsirQuran.posisiDariGlobal(first)
                if (pos != null) { simpanSurah = pos.first; simpanDari = pos.second }
                val last = PenafsirQuran.posisiDariGlobal(globalList!!.last())
                if (last != null) simpanSampai = last.second
            } catch (_: Exception) {
                toast(tr("Metadata halaman belum tersedia. Unduh teks lengkap Al-Qur'an di fitur Khatam terlebih dahulu.", "Page metadata is unavailable. Download the complete Qur'an text in Khatam first."))
                if (mp == null) selesai(false)
                return
            }
        } else if (juzDiminta != null) {
            val rentang = PenafsirQuran.rentangJuz(juzDiminta)
            if (rentang == null) { toast(tr("Nomor juz harus 1 sampai 30.", "Juz number must be between 1 and 30.")); if (mp == null) selesai(false); return }
            for (g in rentang) urls.add(urlAyat(qariAyat, g))
            globalList = IntArray(rentang.last - rentang.first + 1) { rentang.first + it }
            teksLabel = tr("Juz ", "Juz ") + juzDiminta
            simpanJuz = juzDiminta
            if (perSurahSaja) catatan = tr("Qari pilihan hanya punya audio per surah; juz diputar dengan Alafasy.", "The selected reciter only has whole-surah audio; the juz plays with Alafasy.")
        } else {
            val total = PenafsirQuran.jumlahAyat(surah)
            if (total == 0) { toast(tr("Nomor surah harus 1 sampai 114.", "Surah number must be between 1 and 114.")); if (mp == null) selesai(false); return }
            if (terjemahDiminta != 0) {
                terjAyatPengguna = (1..total).mapNotNull { a -> cariAudioLokal(surah, 1000 + a)?.let { a to it } }.toMap()
                terjSurahPengguna = cariAudioLokal(surah, 2000)
                pustakaAktif = terjAyatPengguna.isNotEmpty() || terjSurahPengguna != null
                surahPustaka = surah
            }
            // Tiap ayat diulang pada seluruh surah ("surah Al Ikhlas setiap ayat 3 kali") memerlukan audio per ayat.
            val awal: Int? = p.ayat ?: (if ((p.perAyat && ulang != 1) || pustakaAktif) 1 else null)
            if (terjemahDiminta != 0 && awal == null) urlTerjemah = PenafsirQuran.urlTerjemahanId(surah)
            if (awal == null && terjemahDiminta != 0 && urlTerjemah != null) {
                // FIX209: berkas terjemahan per surah sudah memuat bacaan Arab beserta terjemahannya. Dulu perintah
                // "surah X dan terjemahan" memutar murattal surah lebih dulu lalu berkas ini, sehingga surah terdengar dua kali.
                // Kini langsung diputar satu berkas saja, sesuai yang diminta.
                urls.add(urlTerjemah)
                berkasSurah = surah
                teksLabel = if (terjemahDiminta == 2)
                    tr("Terjemahan Indonesia surah ", "Indonesian translation of surah ") + surah + " (" + PenafsirQuran.namaTampil(surah) + ")"
                else
                    tr("Surah ", "Surah ") + surah + " (" + PenafsirQuran.namaTampil(surah) + ")" + tr(" dengan terjemahan Indonesia", " with Indonesian translation")
                simpanSurah = surah
            } else if (awal == null) {
                // FIX175: untuk perintah satu surah, utamakan audio surah utuh. Jika pengguna hanya
                // mengunduh audio per ayat, susun seluruh ayat lokal sesuai urutan mushaf.
                val audioSurahLokal = cariAudioLokal(surah, null)
                if (audioSurahLokal != null) {
                    urls.add(audioSurahLokal.toString())
                    berkasSurah = surah
                } else {
                    val audioAyatLokal = (1..total).map { cariAudioLokal(surah, it) }
                    if (audioAyatLokal.all { it != null }) {
                        urls.addAll(audioAyatLokal.map { it!!.toString() })
                        globalList = IntArray(total) { PenafsirQuran.global(surah, it + 1) }
                    } else {
                        urls.add(urlSurah(qari, surah) ?: urlSurah("ar.alafasy", surah)!!)
                        berkasSurah = surah
                    }
                }
                if (perSurahSaja && urlSurah(qari, surah) == null && berkasSurah != 0) catatan = tr("Surah ini tidak ada pada qari pilihan; diputar dengan Alafasy.", "This surah is not available for the selected reciter; it plays with Alafasy.")
                if (urlTerjemah != null) urls.add(urlTerjemah)
                teksLabel = tr("Surah ", "Surah ") + surah + " (" + PenafsirQuran.namaTampil(surah) + ")" +
                    (if (urlTerjemah != null) tr(" dan terjemahan Indonesia", " and Indonesian translation") else "")
                simpanSurah = surah
            } else {
                val akhirDiminta = p.ayatAkhir
                val dari = if (akhirDiminta != null) minOf(awal, akhirDiminta) else awal
                val sampai = when {
                    akhirDiminta != null -> maxOf(awal, akhirDiminta)
                    p.sampaiAkhir -> total
                    p.ayat == null -> total
                    ulang != 1 || p.perAyat -> awal
                    kh.getString("target_pemutaran_audio", "ayat") == "ayat" -> awal
                    else -> total
                }
                if (dari < 1 || sampai > total) {
                    toast(tr("Rentang ayat tidak sesuai (surah ini punya ", "Verse range is not valid (this surah has ") + total + tr(" ayat).", " verses)."))
                    if (mp == null) selesai(false)
                    return
                }
                val g0 = PenafsirQuran.global(surah, dari)
                for (k in 0..(sampai - dari)) urls.add(urlAyat(qariAyat, g0 + k))
                globalList = IntArray(sampai - dari + 1) { g0 + it }
                teksLabel = tr("Surah ", "Surah ") + surah + " (" + PenafsirQuran.namaTampil(surah) + ")" + tr(" ayat ", " verse ") + dari + (if (sampai != dari) (tr(" sampai ", " to ") + sampai) else "")
                simpanSurah = surah; simpanDari = dari; simpanSampai = sampai
                if (perSurahSaja) catatan = tr("Qari pilihan hanya punya audio per surah; ayat diputar dengan Alafasy.", "The selected reciter only has whole-surah audio; verses play with Alafasy.")
            }
        }
        if (terjemahDiminta != 0 && urlTerjemah == null && !pustakaAktif) {
            catatan = (if (catatan.isBlank()) "" else catatan + " ") + tr("Terjemahan per ayat tidak ditemukan. Untuk ayat dan terjemah dari berkas Anda sendiri, taruh berkas terjemah di folder surah dalam Jam Pintar Pro (nama berkas memuat kata terjemah dan nomor ayat). Terjemahan online hanya satu surah penuh; coba ucapkan: putar surah Al Fatihah dan terjemahan Indonesia.",
                "No per-verse translation was found. For verses and translation from your own files, put the translation files in the surah folder inside Jam Pintar Pro (file names containing the word terjemah and the verse number). Online translation is only a whole surah; try saying: play surah Al Fatihah and Indonesian translation.")
        }
        if (terjemahDiminta == 2 && !pustakaAktif && urlTerjemah == null) {
            // FIX260: terjemahan saja diminta tetapi tidak ada: jangan memutar ulang bacaan Arab; biarkan audio yang sedang berjalan.
            toast(catatan.ifBlank { tr("Berkas terjemahan tidak ditemukan.", "No translation file was found.") })
            if (mp == null) selesai(false)
            return
        }
        kecepatan = p.kecepatan ?: kh.getFloat("kecepatan_audio", 1.0f).let { if (it in listOf(0.75f, 1.0f, 1.25f, 1.5f)) it else 1.0f }
        ulangN = ulang
        perAyatMode = perAyatEfektif && ulang > 1 && urls.size > 1
        jedaMs = (if (p.jedaDetik > 0) p.jedaDetik else if (globalList != null && urls.size > 1) jedaBawaan else 0) * 1000L
        if (urlTerjemah != null && jedaMs == 0L && urls.size > 1) jedaMs = 1500L
        globalDasar = globalList
        surahBerkas = berkasSurah
        val keterangan = keteranganUlang(p.copy(ulang = ulang, perAyat = perAyatEfektif), urls.size)
        label = teksLabel + keterangan
        kh.edit().putString("quran_perintah_terakhir", listOf(simpanJuz, simpanSurah, simpanDari, simpanSampai).joinToString(",")).apply()
        toast(tr("Perintah suara: putar ", "Voice command: play ") + teksLabel + keterangan + (if (catatan.isNotBlank()) ". " + catatan else ""))
        // FIX173: utamakan berkas murattal yang sudah diunduh. Sebelumnya layanan perintah suara
        // selalu mengirim URL CDN ke MediaPlayer, sehingga audio lokal yang ada di folder Khatam
        // tidak pernah diperiksa dan aplikasi tampak mencari audio di internet.
        // FIX252: mode offline ("offline", "tanpa internet", "dari penyimpanan"): hanya berkas yang sudah tersimpan di HP yang diputar.
        val teksOffline = kandidatAsli.joinToString(" ").lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        val offlineSaja = listOf("offline", "luring", "tanpa internet", "tanpa jaringan", "tanpa kuota", "penyimpanan", "folder", "memori", "ponsel",
            "tersimpan", "lokal", "no internet", "without internet", "stored", "local files", "from storage", "from folder").any { teksOffline.contains(it) } || Regex("\\bhp\\b").containsMatchIn(teksOffline)
        var ditemukanLokal = 0
        val posisiTerjemahan = urls.indices.filter { urlTerjemah != null && urls[it] == urlTerjemah }.toSet()
        daftarUrl = urls.mapIndexed { posisi, url ->
            if (urlTerjemah != null && url == urlTerjemah) {
                // FIX223: pakai terjemahan yang sudah diunduh bila ada; bila tidak, tetap diputar online.
                val nomorTerjemahan = Regex("quraninindonesia/(\\d{3})").find(url)?.groupValues?.getOrNull(1)?.toIntOrNull()
                val berkasLokal = if (nomorTerjemahan != null) cariAudioLokal(nomorTerjemahan, 0) else null
                if (berkasLokal != null) ditemukanLokal++
                return@mapIndexed berkasLokal?.toString() ?: url
            }
            val surahAyat = globalList?.getOrNull(posisi)?.let { PenafsirQuran.posisiDariGlobal(it) }
            val surahLokal = if (surahAyat != null) surahAyat.first else berkasSurah
            val ayatLokal = surahAyat?.second
            // FIX257: bila terjemahan berasal dari pustaka pengguna, ayatnya juga diambil dari folder yang sama; mode offline memakai pustaka itu bila qari berbeda.
            val dariPustaka = if (ayatLokal != null && surahLokal == surahPustaka && (pustakaAktif || offlineSaja)) cariAudioLokal(surahLokal, 3000 + ayatLokal) else null
            val lokal = if (pustakaAktif && dariPustaka != null) dariPustaka
                else (if (surahLokal in 1..114) cariAudioLokal(surahLokal, ayatLokal) else null) ?: dariPustaka
            if (lokal != null) {
                ditemukanLokal++
                lokal.toString()
            } else url
        }
        // FIX257: sisipkan terjemahan terpisah: ayat 1, terjemah 1, ayat 2, terjemah 2, dan seterusnya.
        val posTerjPengguna = HashSet<Int>()
        if (pustakaAktif) {
            val gl = globalList
            val baru = ArrayList<String>()
            val gBaru = ArrayList<Int>()
            if (terjAyatPengguna.isNotEmpty() && gl != null) {
                for (k in daftarUrl.indices) {
                    val g = gl.getOrNull(k) ?: continue
                    val terj = PenafsirQuran.posisiDariGlobal(g)?.let { terjAyatPengguna[it.second] }
                    if (terjemahDiminta != 2 || terj == null) { baru.add(daftarUrl[k]); gBaru.add(g) }
                    if (terj != null) { posTerjPengguna.add(baru.size); baru.add(terj.toString()); gBaru.add(g) }
                }
                if (baru.isNotEmpty()) {
                    daftarUrl = baru
                    globalList = gBaru.toIntArray()
                    globalDasar = globalList
                    toast(tr("Memutar ayat dan terjemahannya dari berkas terpisah di penyimpanan.", "Playing each verse followed by its translation from separate stored files."))
                }
            } else if (terjSurahPengguna != null && p.ayat == null) {
                // Terjemahan hanya satu berkas per surah: diputar setelah seluruh ayat (atau sendirian bila hanya terjemahan yang diminta).
                val t = terjSurahPengguna.toString()
                daftarUrl = if (terjemahDiminta == 2) listOf(t) else daftarUrl + t
                if (terjemahDiminta == 2) globalList = null
                globalDasar = globalList
                posTerjPengguna.add(daftarUrl.size - 1)
                toast(tr("Terjemahan surah ini satu berkas; diputar setelah ayat selesai.", "This surah's translation is a single file; it plays after the verses."))
            }
        }
        if (offlineSaja) {
            val posisiLokal = daftarUrl.indices.filter { !daftarUrl[it].startsWith("http://") && !daftarUrl[it].startsWith("https://") }
            if (posisiLokal.isEmpty()) {
                toast(tr("Berkas audio offline untuk " + teksLabel + " belum ditemukan di penyimpanan. Unduh lewat menu Khatam, atau letakkan berkasnya di folder Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an pada penyimpanan Anda.",
                    "No offline audio file for " + teksLabel + " was found in storage. Download it in the Khatam menu, or place the files in the Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an folder on your storage."))
                if (mp == null) selesai(false)
                return
            }
            if (posisiLokal.size < daftarUrl.size) {
                toast(tr("Mode offline: " + (daftarUrl.size - posisiLokal.size) + " bagian yang belum tersimpan di HP dilewati.", "Offline mode: " + (daftarUrl.size - posisiLokal.size) + " part(s) not stored on this phone were skipped."))
                val globalLama = globalList
                daftarUrl = posisiLokal.map { daftarUrl[it] }
                globalDasar = if (globalLama != null) IntArray(posisiLokal.size) { globalLama[posisiLokal[it]] } else null
            }
        }
        if (ditemukanLokal > 0) {
            toast(tr("Menggunakan ", "Using ") + ditemukanLokal +
                tr(" berkas audio Al-Qur'an yang sudah tersimpan di HP.", " Qur'an audio file(s) already stored on this phone."))
        }
        // FIX191: bagian yang belum tersimpan di HP untuk qari yang diminta diputar secara online; tanpa internet, beri tahu dengan jelas.
        val jumlahDaring = daftarUrl.count { it.startsWith("http://") || it.startsWith("https://") }
        if (jumlahDaring > 0) {
            if (!adaInternet() && jumlahDaring == daftarUrl.size) {
                // FIX222: status jaringan dapat keliru; tetap dicoba diputar. Bila benar-benar gagal, pemutar melaporkan kesalahan.
                toast(tr("Status jaringan belum terbaca. Tetap mencoba memutar secara online. Jika gagal, unduh audionya di menu Khatam.",
                    "Network status could not be read. Still trying to play online. If it fails, download the audio in the Khatam menu."))
            }
            toast(tr("Audio untuk qari ini belum tersimpan di HP; memutar secara online.", "Audio for this reciter is not stored on this phone; playing online."))
        }
        // Bila audio qari pilihan tidak tersedia, siapkan sumber CDN Alafasy sebagai cadangan.
        // Daftar ini tidak mengganti berkas lokal; ia hanya dipakai setelah sumber utama gagal.
        daftarUrlCadangan = if (offlineSaja) daftarUrl.map { null } else daftarUrl.mapIndexed { posisi, url ->
            val global = globalList?.getOrNull(posisi)
            if (posisi in posTerjPengguna) return@mapIndexed null
            if (posisi in posisiTerjemahan) return@mapIndexed (if (url != urlTerjemah) urlTerjemah else null)
            when {
                global != null && (url.startsWith("file:") || url.startsWith("content:") || !url.contains("ar.alafasy")) -> urlAyat("ar.alafasy", global)
                berkasSurah in 1..114 && (url.startsWith("file:") || url.startsWith("content:") || (!url.contains("ar.alafasy") && !url.contains("/ar.alafasy/"))) -> urlSurah("ar.alafasy", berkasSurah)
                else -> null
            }
        }
        indeks = 0
        gagalBerturut = 0
        pakaiUrlCadangan = false
        lepasPramuat()
        mulaiIndeks(0, 0)
    }

    /** Teks ringkas pengulangan/kecepatan/jeda untuk notifikasi dan konfirmasi, mis. ", diulang 5 kali". */
    private fun keteranganUlang(p: PenafsirQuran.Perintah, jumlahBagian: Int): String {
        val sb = StringBuilder()
        if (p.ulang == 0) sb.append(tr(", berulang terus-menerus", ", repeating continuously"))
        else if (p.ulang > 1) {
            if (p.perAyat && jumlahBagian > 1) sb.append(tr(", tiap ayat ", ", each verse ") + p.ulang + tr(" kali", " times"))
            else sb.append(tr(", diulang ", ", repeated ") + p.ulang + tr(" kali", " times"))
        }
        if (p.jedaDetik > 0) sb.append(tr(", jeda ", ", pause ") + p.jedaDetik + tr(" detik", " s"))
        val k = p.kecepatan
        if (k != null && k != 1.0f) sb.append(tr(", kecepatan ", ", speed ") + k + "x")
        return sb.toString()
    }

    /** "ayat berikutnya", "surah sebelumnya", "juz berikutnya": dihitung dari posisi terakhir yang diputar atau dibaca. */
    private fun hitungRelatif(kh: android.content.SharedPreferences, p: PenafsirQuran.Perintah): PenafsirQuran.Perintah? {
        val s = kh.getInt("terakhir_surah", 1).coerceIn(1, 114)
        val a = kh.getInt("terakhir_ayat", 1).coerceIn(1, PenafsirQuran.jumlahAyat(s))
        when (p.relatifSatuan) {
            1 -> {
                val tujuan = s + p.relatif
                if (tujuan !in 1..114) {
                    toast(tr("Tidak ada surah ", "There is no ") + (if (p.relatif > 0) tr("berikutnya setelah surah ", "next surah after surah ") else tr("sebelum surah ", "surah before surah ")) + s + ".")
                    return null
                }
                return p.copy(surah = tujuan, relatif = 0)
            }
            2 -> {
                val tujuan = PenafsirQuran.juzDari(s, a) + p.relatif
                if (tujuan !in 1..30) {
                    toast(tr("Tidak ada juz di luar 1 sampai 30.", "There is no juz outside 1 to 30."))
                    return null
                }
                return p.copy(juz = tujuan, relatif = 0)
            }
            else -> {
                val pos = PenafsirQuran.posisiDariGlobal(PenafsirQuran.global(s, a) + p.relatif)
                if (pos == null) {
                    toast(tr("Tidak ada ayat di luar awal dan akhir Al-Qur'an.", "There is no verse beyond the start or end of the Qur'an."))
                    return null
                }
                return p.copy(surah = pos.first, ayat = pos.second, ayatAkhir = null, relatif = 0)
            }
        }
    }

    /** Perintah putar terakhir (tanpa pengulangan), dipakai oleh "ulangi" dan "putar lagi". */
    private fun muatPerintahTerakhir(kh: android.content.SharedPreferences): PenafsirQuran.Perintah? {
        val bagian = (kh.getString("quran_perintah_terakhir", null) ?: return null).split(",").mapNotNull { it.trim().toIntOrNull() }
        if (bagian.size < 4) return null
        fun nilai(i: Int): Int? = bagian[i].takeIf { it > 0 }
        val juz = nilai(0); val surah = nilai(1); val ayat = nilai(2); val akhir = nilai(3)
        if (juz == null && surah == null) return null
        return PenafsirQuran.Perintah(juz, surah, ayat, akhir)
    }

    /**
     * Cari audio yang diunduh melalui menu Khatam sebelum memakai URL streaming.
     * Lokasi mengikuti mekanisme unduhan yang sudah ada:
     * - /Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an/<Qari>/... (struktur baru)
     * - folder audio lama tetap didukung agar unduhan sebelumnya tetap bisa diputar.
     * - folder khusus yang dipilih pengguna melalui Storage Access Framework.
     */
    private fun cariAudioLokal(surah: Int, ayat: Int?): Uri? {
        if (surah !in 1..114 || (ayat != null && ayat !in 0..3300)) return null // kunci 0 = audio terjemahan (FIX223)
        // FIX180: fungsi ini dipanggil saat menyusun playlist pada main thread.
        // Jangan pernah memindai disk/MediaStore/SAF dari sini; hanya baca cache.
        if (ayat != null && ayat >= 1000) {
            // FIX257/260: pustaka pengguna dibaca dari cache khusus (dibangun di thread latar hanya bila terjemah/offline diminta).
            val h = PustakaAudio.dariCache(surah) ?: return null
            val u = when { ayat >= 3000 -> h.ayat[ayat - 3000]; ayat == 2000 -> h.terjemahSurah; else -> h.terjemahAyat[ayat - 1000] }
            return u?.let { Uri.parse(it) }
        }
        val indeks = synchronized(kunciIndeksAudio) { indeksAudioLokal[surah] }
        return indeks?.get(ayat)
    }

    /**
     * Memindai seluruh sumber penyimpanan hanya SEKALI untuk satu surah.
     * Hasilnya memetakan null = audio satu surah, angka = audio ayat.
     * Ini menghindari pemindaian direktori/MediaStore ratusan kali saat menyusun satu surah.
     */
    private fun bangunIndeksAudioLokal(surah: Int): Map<Int?, Uri> {
        val dasar = bangunIndeksAudioQari(surah)
        // FIX223: audio terjemahan Indonesia yang diunduh disimpan di indeks pada kunci 0 (kunci null = surah penuh, 1 dan seterusnya = ayat).
        val gabung = HashMap<Int?, Uri>(dasar)
        cariBerkasTerjemahanLokal(surah)?.let { gabung[0] = it }
        return gabung
    }

    /** FIX252: anak folder dengan nama yang sama tanpa membedakan huruf besar atau kecil. */
    private fun anakFolder(induk: File, nama: String): File? =
        induk.listFiles()?.firstOrNull { it.isDirectory && it.name.equals(nama, true) }

    /** FIX252: folder satu surah dikenali dari awalan nomor tiga angka ("002 - Al-Baqarah", "002 Al-Baqarah", "002_Al-Baqarah", atau "2"). */
    private fun cocokFolderSurah(nama: String, surah: Int): Boolean =
        Regex("^0*" + surah + "(?!\\d)").containsMatchIn(nama.trim())

    /** FIX252: nomor ayat dari nama berkas bebas pola: "001.mp3", "002001.mp3" (surah+ayat), "Ayat_005.mp3"; null bila tidak terbaca. */
    private fun ayatDariNamaBerkas(nama: String, surah: Int): Int? {
        val inti = nama.substringBeforeLast(".")
        Regex("^0*(\\d{1,3})0*(\\d{3})$").matchEntire(inti)?.let { m ->
            if (inti.length == 6 && m.groupValues[1].toIntOrNull() == surah) return m.groupValues[2].toIntOrNull()?.takeIf { it in 1..286 }
        }
        val angka = Regex("(\\d{1,3})(?!.*\\d)").find(inti)?.groupValues?.getOrNull(1)?.toIntOrNull()
        return angka?.takeIf { it in 1..286 }
    }

    private fun cariBerkasTerjemahanLokal(surah: Int): Uri? {
        val nama = "Terjemahan_Indonesia_Surah_" + String.format(Locale.ROOT, "%03d", surah) + ".mp3"
        val akar = listOf(
            File(Environment.getExternalStorageDirectory(), "Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an"),
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir, "Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an")
        )
        // FIX252: nama folder terjemahan buatan pengguna ("Terjemah Bahasa Indonesia") dan nama berkas bebas pola ikut dikenali.
        val namaFolder = listOf("Terjemahan Indonesia", "Indonesian Translation", "Terjemah Bahasa Indonesia", "Terjemahan Bahasa Indonesia", "Terjemah Indonesia")
        for (a in akar) for (f in namaFolder) {
            try { val b = File(File(a, f), nama); if (b.isFile && b.length() > 0L && b.canRead()) return Uri.fromFile(b) } catch (_: Exception) { }
        }
        for (a in akar) {
            try {
                val folder = a.listFiles()?.firstOrNull { d -> d.isDirectory && namaFolder.any { it.equals(d.name, true) } } ?: continue
                val pola = Regex("(?<![0-9])0*" + surah + "(?![0-9])")
                val cocok = folder.listFiles()?.filter { it.isFile && it.name.endsWith(".mp3", true) && it.length() > 0L && it.canRead() && pola.containsMatchIn(it.name) }
                    ?.minByOrNull { it.name.length }
                if (cocok != null) return Uri.fromFile(cocok)
            } catch (_: Exception) { }
        }
        return null
    }

    private fun bangunIndeksAudioQari(surah: Int): Map<Int?, Uri> {
        val prefs = getSharedPreferences("khatam_quran", MODE_PRIVATE)
        // FIX191: bila nama qari belum tersimpan (qari bawaan), ambil labelnya dari katalog agar cocok dengan nama berkas unduhan.
        val idQari = prefs.getString("qari_audio_id", "ar.alafasy") ?: "ar.alafasy"
        val namaQari = (prefs.getString("qari_audio_nama", null).orEmpty().trim().ifBlank { QariSuara.labelDariId(this, idQari) ?: idQari }).trim().ifBlank { "Qari" }
        fun aman(v: String) = v.replace(Regex("[\\\\/:*?\\\"<>|]"), "_")
            .replace(Regex("\\s+"), " ").trim()
        val folderQari = aman(namaQari).take(80)
        val namaQariPokok = aman(namaQari.substringBefore(" · ").substringBefore(" - "))
        val awalanBerkas = "Qari_" + namaQariPokok.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val hasil = mutableMapOf<Int?, Pair<Uri, Int>>()

        // FIX191: saat ada internet, hanya berkas qari yang diminta yang dipakai secara offline; bila qari itu belum tersimpan, audio
        // diputar online. Tanpa internet, berkas qari lain tetap dipakai agar pemutaran offline tidak hilang.
        val ketat = adaInternet()
        val intiQari = aman(namaQari.removePrefix("Anak · ").removePrefix("Children · ").removePrefix("MP3Quran · ").removePrefix("Perempuan · ")
            .substringBefore(" · ").substringBefore(" - "))
        val intiBerkas = intiQari.replace(Regex("[^A-Za-z0-9_-]"), "_")
        fun sesuaiQari(nama: String, lokasi: String): Boolean =
            (intiBerkas.length >= 3 && nama.contains(intiBerkas, true)) || lokasi.contains(folderQari, true) ||
                (intiQari.length >= 3 && lokasi.contains(intiQari, true))

        fun skor(nama: String, lokasi: String): Int {
            var nilai = 0
            if (nama.startsWith(awalanBerkas, true)) nilai += 100
            if (lokasi.contains(folderQari, true) || lokasi.contains(namaQariPokok, true)) nilai += 40
            if (lokasi.contains("Jam Pintar Pro", true)) nilai += 20
            return nilai
        }
        fun catat(namaMentah: String, uri: Uri, lokasi: String) {
            val nama = namaMentah.trim()
            if (!nama.endsWith(".mp3", true)) return
            val nilai = skor(nama, lokasi)
            val cocokQari = nama.startsWith("Qari_", true) || lokasi.contains("Jam Pintar Pro", true)
            if (!cocokQari) return
            if (ketat && !sesuaiQari(nama, lokasi)) return

            val polaAyat = Regex("(?:^|_)S0*(\\d{1,3})[_-]?A0*(\\d{1,3})(?:_|\\.mp3$)", RegexOption.IGNORE_CASE)
            val bagianAyat = polaAyat.find(nama)
            if (bagianAyat != null) {
                val nomorSurah = bagianAyat.groupValues[1].toIntOrNull()
                val nomorAyat = bagianAyat.groupValues[2].toIntOrNull()
                if (nomorSurah == surah && nomorAyat != null && nomorAyat in 1..286) {
                    val lama = hasil[nomorAyat]
                    if (lama == null || nilai > lama.second) hasil[nomorAyat] = uri to nilai
                }
                return
            }

            val polaSurah = Regex("(?:^|_)Surah_0*(\\d{1,3})(?:_|\\.mp3$)", RegexOption.IGNORE_CASE)
            val nomorSurah = polaSurah.find(nama)?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (nomorSurah == surah) {
                val lama = hasil[null]
                if (lama == null || nilai > lama.second) hasil[null] = uri to nilai
            }
        }

        // 1. Folder bawaan pada memori internal, folder Download, dan lokasi khusus aplikasi.
        val indukKandidat = listOf(
            File(Environment.getExternalStorageDirectory(), "Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an"),
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir, "Jam Pintar Pro/Al-Qur'an/Audio Al-Qur'an"),
            File(Environment.getExternalStorageDirectory(), "Jam Pintar Pro/Al-Qur'an/simpan folder audio"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Jam Pintar Pro/Al-Qur'an/simpan folder audio"),
            File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir, "Jam Pintar Pro/Al-Qur'an/simpan folder audio")
        )
        val nomorFolderAyat = String.format(Locale.ROOT, "%03d", surah)
        for (induk in indukKandidat) {
            try {
                if (!induk.exists() || !induk.canRead()) continue
                // Bentuk folder mengikuti Khatam: <akar>/<Qari>/Audio Per Surah
                // dan <akar>/<Qari>/Audio Per Ayat/<NNN - Nama Surah>.
                // FIX252: nama folder qari dicocokkan longgar (huruf besar/kecil dan ejaan, mis. Ayman Suwaid = Ayman Sowaid).
                var qariDir = File(induk, folderQari)
                if (!qariDir.isDirectory) {
                    qariDir = induk.listFiles()?.firstOrNull { it.isDirectory && (it.name.equals(folderQari, true) || QariSuara.mirip(it.name, namaQari)) } ?: qariDir
                }
                val dasar = if (qariDir.isDirectory) qariDir else induk
                val kandidatBerkas = LinkedHashSet<File>()
                kandidatBerkas.addAll(dasar.listFiles()?.filter { it.isFile && it.name.endsWith(".mp3", true) }.orEmpty())
                // Khatam menamai folder menurut bahasa aktif saat mengunduh, jadi nama Indonesia dan English sama-sama dicari.
                // FIX252: folder Murattal per surah/per ayat buatan pengguna juga dikenali, tanpa membedakan huruf besar atau kecil.
                val namaFolderSurah = listOf(tr("Audio Per Surah", "Audio by Surah"), tr("Audio by Surah", "Audio Per Surah"),
                    tr("Murattal Per Surah", "Murattal by Surah"), tr("Murattal by Surah", "Murattal Per Surah"))
                val namaFolderAyat = listOf(tr("Audio Per Ayat", "Audio by Verse"), tr("Audio by Verse", "Audio Per Ayat"),
                    tr("Murattal Per Ayat", "Murattal by Verse"), tr("Murattal by Verse", "Murattal Per Ayat"))
                for (nama in namaFolderSurah) {
                    kandidatBerkas.addAll(anakFolder(dasar, nama)?.listFiles()?.filter { it.isFile && it.name.endsWith(".mp3", true) }.orEmpty())
                }
                val berkasFolderAyat = ArrayList<File>()
                for (nama in namaFolderAyat) {
                    val folderTarget = anakFolder(dasar, nama)?.listFiles()?.firstOrNull { it.isDirectory && cocokFolderSurah(it.name, surah) }
                    val isi = folderTarget?.listFiles()?.filter { it.isFile && it.name.endsWith(".mp3", true) }.orEmpty()
                    kandidatBerkas.addAll(isi)
                    berkasFolderAyat.addAll(isi)
                }
                kandidatBerkas.forEach { file -> if (file.canRead()) catat(file.name, Uri.fromFile(file), file.parent.orEmpty()) }
                // FIX252: berkas dalam folder satu surah yang namanya tidak memakai pola S002_A001 (mis. 001.mp3 atau 002001.mp3).
                for (file in berkasFolderAyat) {
                    if (!file.canRead()) continue
                    val a = ayatDariNamaBerkas(file.name, surah) ?: continue
                    if (!hasil.containsKey(a)) hasil[a] = Uri.fromFile(file) to 150
                }
            } catch (_: Exception) { }
        }

        // Jika audio surah utuh sudah ditemukan, pencarian tidak perlu diteruskan.
        if (hasil.containsKey(null)) return hasil.mapValues { it.value.first }

        // 2. MediaStore: unduhan Khatam Android 10+ disimpan di Downloads.
        // Koleksi Audio/Files hanya menjadi cadangan bila Downloads tidak menemukan apa pun.
        if (Build.VERSION.SDK_INT >= 29) {
            val projection = arrayOf(MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH)
            val koleksiUtama = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val koleksiCadangan = listOf(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, MediaStore.Files.getContentUri("external"))
            for (koleksiUri in listOf(koleksiUtama)) {
                try {
                    val nomorPadded = surah.toString().padStart(3, '0')
                    val selection = MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? OR " +
                        MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? OR " +
                        MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? OR " +
                        MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?"
                    val selectionArgs = arrayOf(
                        "%_S${nomorPadded}_A%", "%_S${surah}_A%",
                        "%_Surah_${nomorPadded}%", "%_Surah_${surah}_%"
                    )
                    contentResolver.query(koleksiUri, projection, selection, selectionArgs,
                        MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.MediaColumns._ID)
                        val nameCol = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                        val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                        while (cursor.moveToNext()) {
                            if (idCol < 0 || nameCol < 0) continue
                            val nama = cursor.getString(nameCol).orEmpty()
                            // Filter cepat sebelum membentuk Uri; hanya pola nama audio unduhan aplikasi.
                            if (!nama.startsWith("Qari_", true)) continue
                            val path = if (pathCol >= 0) cursor.getString(pathCol).orEmpty() else ""
                            val uri = android.content.ContentUris.withAppendedId(koleksiUri, cursor.getLong(idCol))
                            catat(nama, uri, path)
                        }
                    }
                } catch (_: Exception) { }
            }
            if (hasil.isEmpty()) {
                for (koleksiUri in koleksiCadangan) {
                    try {
                        val nomorPadded = surah.toString().padStart(3, '0')
                        val selection = MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? OR " +
                            MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? OR " +
                            MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? OR " +
                            MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?"
                        val args = arrayOf("%_S${nomorPadded}_A%", "%_S${surah}_A%", "%_Surah_${nomorPadded}%", "%_Surah_${surah}_%")
                        contentResolver.query(koleksiUri, projection, selection, args, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { cursor ->
                            val idCol = cursor.getColumnIndex(MediaStore.MediaColumns._ID)
                            val nameCol = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                            val pathCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                            while (cursor.moveToNext()) {
                                if (idCol < 0 || nameCol < 0) continue
                                val nama = cursor.getString(nameCol).orEmpty()
                                if (!nama.startsWith("Qari_", true)) continue
                                val path = if (pathCol >= 0) cursor.getString(pathCol).orEmpty() else ""
                                val uri = android.content.ContentUris.withAppendedId(koleksiUri, cursor.getLong(idCol))
                                catat(nama, uri, path)
                            }
                        }
                    } catch (_: Exception) { }
                    if (hasil.isNotEmpty()) break
                }
            }
        }
        if (hasil.containsKey(null) || (1..PenafsirQuran.jumlahAyat(surah)).all { hasil.containsKey(it) }) {
            return hasil.mapValues { it.value.first }
        }

        // 3. SAF bila pengguna pernah memilih folder sendiri. Pemindaian juga hanya satu kali per surah.
        try {
            val rawTree = prefs.getString("folder_audio_tree_uri", null)
            if (!rawTree.isNullOrBlank()) {
                val tree = Uri.parse(rawTree)
                val rootId = DocumentsContract.getTreeDocumentId(tree)
                val root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
                val antrean = java.util.ArrayDeque<Pair<Uri, Int>>()
                antrean.add(root to 0)
                var jumlah = 0
                while (antrean.isNotEmpty() && jumlah++ < 2500) {
                    val (parent, depth) = antrean.removeFirst()
                    if (depth > 10) continue
                    val children = DocumentsContract.buildChildDocumentsUriUsingTree(
                        tree, DocumentsContract.getDocumentId(parent))
                    contentResolver.query(children, arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { cursor ->
                        val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                        val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                        val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                        while (cursor.moveToNext()) {
                            if (idCol < 0 || nameCol < 0) continue
                            val id = cursor.getString(idCol) ?: continue
                            val nama = cursor.getString(nameCol).orEmpty()
                            val mime = if (mimeCol >= 0) cursor.getString(mimeCol).orEmpty() else ""
                            val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                antrean.add(uri to (depth + 1))
                            } else if (nama.startsWith("Qari_", true)) {
                                catat(nama, uri, DocumentsContract.getDocumentId(parent))
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) { }

        return hasil.mapValues { it.value.first }
    }

    private fun urlAyat(qari: String, global: Int) = "https://cdn.islamic.network/quran/audio/128/" + qari + "/" + global + ".mp3"

    /** Null bila qari per-surah (MP3Quran) tidak memuat surah tersebut. */
    private fun urlSurah(qari: String, surah: Int): String? {
        if (qari.startsWith("mp3quran|")) {
            val bagian = qari.split("|")
            val server = bagian.getOrNull(1).orEmpty()
            val tersedia = bagian.getOrNull(2)?.split(",")?.mapNotNull { it.trim().toIntOrNull() }?.toSet() ?: emptySet()
            if (server.isBlank() || surah !in tersedia) return null
            return server + String.format(Locale.ROOT, "%03d", surah) + ".mp3"
        }
        return "https://cdn.islamic.network/quran/audio-surah/128/" + qari + "/" + surah + ".mp3"
    }

    /** Percobaan ulang untuk CDN memakai bitrate lain, seperti pemutar di Khatam. */
    private fun varianUrl(url: String, percobaan: Int): String {
        if (!url.startsWith("https://cdn.islamic.network/")) return url
        val bitrate = listOf("128", "64", "48", "40", "32", "192").getOrElse(percobaan) { "128" }
        return url.replace(Regex("/audio(-surah)?/\\d+/")) { match ->
            val jenis = if (match.value.contains("audio-surah")) "/audio-surah/" else "/audio/"
            jenis + bitrate + "/"
        }
    }

    // ---------- Pemutaran ----------

    private fun mulaiIndeks(i: Int, percobaanKe: Int) {
        if (i >= totalItem()) { selesai(false); return }
        if (i != indeks) pakaiUrlCadangan = false
        indeks = i
        simpanPosisi(i)
        percobaan = percobaanKe
        siap = false
        dijeda = false
        dijedaOlehFokus = false
        val gen = ++generasi
        handler.removeCallbacks(batasMuat)
        handler.removeCallbacks(penyambungJeda)
        menungguJeda = false
        lanjutSetelahJeda = false
        lepasPemutar()
        if (!mintaFokus()) {
            toast(tr("Audio sedang dipakai aplikasi lain (misalnya panggilan).", "Audio is being used by another app (for example a call)."))
            selesai(false)
            return
        }
        ambilKunci()
        try {
            val urlDasar = if (pakaiUrlCadangan) daftarUrlCadangan.getOrNull(indeksDasar(i)) ?: daftarUrl[indeksDasar(i)] else daftarUrl[indeksDasar(i)]
            val saatSiap: (PemutarAudio) -> Unit = { pemutar ->
                if (gen == generasi) {
                    handler.removeCallbacks(batasMuat)
                    siap = true
                    gagalBerturut = 0
                    try { efek.pasang(pemutar.audioSessionId) } catch (_: Exception) { }
                    if (!dijeda) {
                        try { val v = getSharedPreferences("khatam_quran", MODE_PRIVATE).getInt("volume_audio_persen", 100).coerceIn(0, 100) / 100f; pemutar.setVolume(v, v) } catch (_: Exception) { }
                        pemutar.start()
                        terapkanKecepatan(pemutar)
                    }
                    perbaruiNotifikasi()
                    pramuatBerikut(i)
                }
            }
            val selesaiMain: (PemutarAudio) -> Unit = { if (gen == generasi) lanjutKeBerikut() }
            val galat: (PemutarAudio, Int, Int) -> Boolean = { _, _, _ -> if (gen == generasi) gagalMuat(); true }
            // FIX207: bagian ini sudah dimuat lebih dulu saat bagian sebelumnya diputar; pakai langsung agar tanpa jeda tunggu.
            val awal = pramuat
            if (awal != null && pramuatIndeks == i && percobaanKe == 0 && !pakaiUrlCadangan && pramuatUrl == urlDasar) {
                val sudahSiap = pramuatSiap
                pramuat = null; pramuatIndeks = -1; pramuatUrl = ""; pramuatSiap = false
                mp = awal
                awal.setOnCompletionListener(selesaiMain)
                awal.setOnErrorListener(galat)
                if (sudahSiap) {
                    awal.setOnPreparedListener(null)
                    saatSiap(awal)
                } else {
                    awal.setOnPreparedListener(saatSiap)
                    handler.postDelayed(batasMuat, 12_000L)
                }
                perbaruiNotifikasi()
                return
            }
            lepasPramuat()
            // FIX143: keluaran Stereo/Mono mengikuti pengaturan Khatam ("keluaran_suara_audio"), sama seperti pemutar di layar Khatam.
            val mono = getSharedPreferences("khatam_quran", MODE_PRIVATE).getString("keluaran_suara_audio", "stereo") == "mono"
            val p: PemutarAudio = SaluranAudioKhatam.buatPemutar(applicationContext, mono)
            mp = p
            p.setAudioAttributes(SaluranAudioKhatam.atribut(applicationContext))
            p.setDataSource(applicationContext, android.net.Uri.parse(varianUrl(urlDasar, percobaanKe)), headerAudio())
            p.setOnPreparedListener(saatSiap)
            p.setOnCompletionListener(selesaiMain)
            p.setOnErrorListener(galat)
            // FIX206: sumber internet yang tidak menjawab tidak ditunggu 30 detik; percobaan pertama 12 detik, berikutnya 20 detik.
            val daring = urlDasar.startsWith("http://") || urlDasar.startsWith("https://")
            handler.postDelayed(batasMuat, if (!daring) 30_000L else if (percobaanKe == 0) 12_000L else 20_000L)
            p.prepareAsync()
            perbaruiNotifikasi()
        } catch (_: Exception) {
            gagalMuat()
        }
    }

    private fun headerAudio() = mapOf(
        "User-Agent" to ("Mozilla/5.0 (Linux; Android " + Build.VERSION.RELEASE + ") AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"),
        "Accept" to "audio/mpeg,audio/*;q=0.9,*/*;q=0.8"
    )

    /** FIX207: siapkan (tanpa memutar) bagian berikutnya selama bagian sekarang diputar, bila bagian itu berasal dari internet. */
    private fun pramuatBerikut(i: Int) {
        lepasPramuat()
        try {
            val berikut = i + 1
            if (berikut >= totalItem()) return
            val dasar = indeksDasar(berikut)
            if (dasar == indeksDasar(i)) return
            val url = daftarUrl.getOrNull(dasar) ?: return
            if (!url.startsWith("http://") && !url.startsWith("https://")) return
            if (getSharedPreferences("khatam_quran", MODE_PRIVATE).getString("keluaran_suara_audio", "stereo") == "mono") return
            val p: PemutarAudio = SaluranAudioKhatam.buatPemutar(applicationContext, false)
            p.setAudioAttributes(SaluranAudioKhatam.atribut(applicationContext))
            p.setDataSource(applicationContext, android.net.Uri.parse(varianUrl(url, 0)), headerAudio())
            p.setOnPreparedListener { if (pramuat === p) pramuatSiap = true }
            p.setOnErrorListener { _, _, _ -> if (pramuat === p) lepasPramuat(); true }
            pramuat = p; pramuatIndeks = berikut; pramuatUrl = url; pramuatSiap = false
            p.prepareAsync()
        } catch (_: Exception) { lepasPramuat() }
    }

    private fun lepasPramuat() {
        val p = pramuat
        pramuat = null; pramuatIndeks = -1; pramuatUrl = ""; pramuatSiap = false
        if (p == null) return
        try { p.setOnCompletionListener(null); p.setOnErrorListener(null); p.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p.release() } catch (_: Exception) { }
    }

    /** Jumlah bagian yang akan diputar seluruhnya (Int.MAX_VALUE bila tanpa batas). */
    private fun totalItem(): Int = if (ulangN == 0) Int.MAX_VALUE else daftarUrl.size * ulangN

    /** Indeks pada daftar dasar untuk urutan pemutaran ke-i (memperhitungkan pengulangan). */
    private fun indeksDasar(i: Int): Int {
        if (daftarUrl.isEmpty()) return 0
        return if (perAyatMode && ulangN > 0) i / ulangN else i % daftarUrl.size
    }

    private fun lanjutKeBerikut() {
        val berikut = indeks + 1
        if (berikut >= totalItem()) { selesai(false); return }
        if (jedaMs <= 0L) { mulaiIndeks(berikut, 0); return }
        berikutSetelahJeda = berikut
        menungguJeda = true
        perbaruiNotifikasi()
        handler.postDelayed(penyambungJeda, jedaMs)
    }

    /** Simpan posisi bacaan terakhir (dipakai Khatam dan perintah "ayat berikutnya"). */
    private fun simpanPosisi(i: Int) {
        val kh = getSharedPreferences("khatam_quran", MODE_PRIVATE)
        val g = globalDasar?.getOrNull(indeksDasar(i))
        if (g != null) {
            val pos = PenafsirQuran.posisiDariGlobal(g) ?: return
            kh.edit().putInt("terakhir_surah", pos.first).putInt("terakhir_ayat", pos.second).apply()
        } else if (surahBerkas in 1..114) {
            kh.edit().putInt("terakhir_surah", surahBerkas).putInt("terakhir_ayat", 1).apply()
        }
    }

    private fun terapkanKecepatan(p: PemutarAudio) {
        if (kecepatan == 1.0f || Build.VERSION.SDK_INT < 23) return
        try { p.playbackParams = p.playbackParams.setSpeed(kecepatan) } catch (_: Exception) { }
    }

    private fun gagalMuat() {
        handler.removeCallbacks(batasMuat)
        generasi++
        lepasPemutar()
        val urlSaatIni = if (pakaiUrlCadangan) daftarUrlCadangan.getOrNull(indeksDasar(indeks)) ?: daftarUrl.getOrNull(indeksDasar(indeks)) else daftarUrl.getOrNull(indeksDasar(indeks))
        val sumberDaring = urlSaatIni?.startsWith("http://") == true || urlSaatIni?.startsWith("https://") == true
        // FIX206: hanya CDN yang punya varian bitrate dicoba sampai 5 kali; sumber lain (mis. audio terjemahan) 2 kali, lalu cadangan/berikutnya.
        val maksCoba = if (urlSaatIni?.startsWith("https://cdn.islamic.network/") == true) 5 else 2
        if (sumberDaring && percobaan < maksCoba) { mulaiIndeks(indeks, percobaan + 1); return }
        val cadangan = daftarUrlCadangan.getOrNull(indeksDasar(indeks))
        if (!pakaiUrlCadangan && !cadangan.isNullOrBlank() && cadangan != daftarUrl.getOrNull(indeksDasar(indeks))) {
            pakaiUrlCadangan = true
            mulaiIndeks(indeks, 0)
            return
        }
        if (totalItem() > 1 && gagalBerturut < 4) {
            gagalBerturut++
            mulaiIndeks(indeks + 1, 0)
            return
        }
        toast(tr("Audio Al-Qur'an tidak dapat diputar. Periksa apakah berkas audio tersedia dan folder penyimpanannya dapat diakses. Jika memakai audio daring, periksa koneksi internet.", "Qur'an audio could not be played. Check that the audio file exists and its storage folder is accessible. If using online audio, check the internet connection."))
        selesai(false)
    }

    private fun jeda() {
        val p = mp ?: return
        try { if (p.isPlaying) p.pause() } catch (_: Exception) { }
        dijeda = true
        perbaruiNotifikasi()
    }

    private fun lanjut() {
        val p = mp ?: return
        dijeda = false
        dijedaOlehFokus = false
        if (lanjutSetelahJeda) { lanjutSetelahJeda = false; mulaiIndeks(berikutSetelahJeda, 0); return }
        if (menungguJeda) { perbaruiNotifikasi(); return }
        if (siap) {
            if (!mintaFokus()) return
            try { p.start(); terapkanKecepatan(p) } catch (_: Exception) { }
        }
        perbaruiNotifikasi()
    }

    private fun lepasPemutar() {
        val p = mp
        mp = null
        try { efek.lepas() } catch (_: Exception) { }
        try { p?.setOnCompletionListener(null); p?.setOnErrorListener(null); p?.setOnPreparedListener(null) } catch (_: Exception) { }
        try { p?.stop() } catch (_: Exception) { }
        try { p?.release() } catch (_: Exception) { }
    }

    private fun selesai(denganPesan: Boolean) {
        generasi++
        handler.removeCallbacks(batasMuat)
        handler.removeCallbacks(penyambungJeda)
        menungguJeda = false
        lanjutSetelahJeda = false
        lepasPemutar()
        lepasPramuat()
        lepasFokus()
        lepasKunci()
        if (denganPesan) toast(tr("Audio Al-Qur'an dihentikan.", "Qur'an audio stopped."))
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    // ---------- Fokus audio dan kunci daya ----------

    private fun mintaFokus(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val pendengar = fokus ?: AudioManager.OnAudioFocusChangeListener { perubahan ->
            when (perubahan) {
                AudioManager.AUDIOFOCUS_LOSS -> handler.post { selesai(false) }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> handler.post {
                    val p = mp
                    if (p != null && siap && !dijeda) { dijedaOlehFokus = true; jeda() }
                }
                AudioManager.AUDIOFOCUS_GAIN -> handler.post {
                    try { val v = getSharedPreferences("khatam_quran", MODE_PRIVATE).getInt("volume_audio_persen", 100).coerceIn(0, 100) / 100f; mp?.setVolume(v, v) } catch (_: Exception) { }
                    if (dijedaOlehFokus) { dijedaOlehFokus = false; lanjut() }
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> handler.post {
                    // Jangan biarkan volume audio Al-Qur'an tertahan pada level ducking.
                    // Fokus TTS aplikasi memakai GAIN_TRANSIENT agar audio dijeda, bukan dikecilkan.
                    try { val v = getSharedPreferences("khatam_quran", MODE_PRIVATE).getInt("volume_audio_persen", 100).coerceIn(0, 100) / 100f; mp?.setVolume(v, v) } catch (_: Exception) { }
                }
            }
        }.also { fokus = it }
        val hasil = if (Build.VERSION.SDK_INT >= 26) {
            val req = permintaanFokus ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
                .setOnAudioFocusChangeListener(pendengar, handler)
                .build().also { permintaanFokus = it }
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(pendengar, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        return hasil == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun lepasFokus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) permintaanFokus?.let { am.abandonAudioFocusRequest(it) }
            else {
                @Suppress("DEPRECATION")
                fokus?.let { am.abandonAudioFocus(it) }
            }
        } catch (_: Exception) { }
        permintaanFokus = null
    }

    private fun ambilKunci() {
        try {
            if (wifiLock == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, ("" + (packageName) + ":QuranSuara")).apply { setReferenceCounted(false) }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        } catch (_: Exception) { }
        // FIX143: pemutar mono mendekode di thread sendiri, jadi CPU harus tetap aktif saat layar mati.
        try {
            if (cpuLock == null) {
                val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
                cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, ("" + (packageName) + ":QuranSuaraCpu")).apply { setReferenceCounted(false) }
            }
            if (cpuLock?.isHeld == false) cpuLock?.acquire(6 * 60 * 60 * 1000L)
        } catch (_: Exception) { }
        if (!penerimaTerdaftar) {
            try { registerReceiver(penerimaBising, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)); penerimaTerdaftar = true } catch (_: Exception) { }
        }
    }

    private fun lepasKunci() {
        try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (_: Exception) { }
        wifiLock = null
        try { if (cpuLock?.isHeld == true) cpuLock?.release() } catch (_: Exception) { }
        cpuLock = null
        if (penerimaTerdaftar) { try { unregisterReceiver(penerimaBising) } catch (_: Exception) { }; penerimaTerdaftar = false }
    }

    // ---------- Notifikasi ----------

    private fun buatSaluran() {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(SALURAN, tr("Pemutar Al-Qur'an (perintah suara)", "Qur'an player (voice command)"), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun aksiPending(kode: Int, aksi: String): PendingIntent = PendingIntent.getService(
        this, kode, Intent(this, PemutarQuranService::class.java).setAction(aksi), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun bangunNotifikasi(isi: String): Notification {
        val buka = PendingIntent.getActivity(this, 9611, Intent(this, KhatamActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, SALURAN) else Notification.Builder(this)
        b.setSmallIcon(R.drawable.ic_stat_baterai)
            .setContentTitle(tr("Memutar Al-Qur'an", "Playing the Qur'an"))
            .setContentText(isi)
            .setContentIntent(buka)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                if (dijeda) tr("Lanjut", "Resume") else tr("Jeda", "Pause"),
                aksiPending(9612, if (dijeda) ACTION_LANJUT else ACTION_JEDA)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_baterai),
                tr("Berhenti", "Stop"), aksiPending(9613, ACTION_BERHENTI)).build())
        return b.build()
    }

    private fun mulaiForeground(isi: String) {
        val n = bangunNotifikasi(isi)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
        } catch (_: Exception) {
            // Android menolak layanan foreground dimulai dari latar belakang (mis. perintah kendali tanpa audio berjalan).
            stopSelf()
        }
    }

    /** Posisi bacaan yang ramah TalkBack pada notifikasi, tanpa mengubah alur pemutaran. */
    private fun keteranganPosisiBacaan(): String {
        val global = globalDasar?.getOrNull(indeksDasar(indeks))
        val posisiGlobal = global?.let { PenafsirQuran.posisiDariGlobal(it) }
        if (posisiGlobal != null) {
            return tr(" · Surah ", " · Surah ") + PenafsirQuran.namaTampil(posisiGlobal.first) +
                tr(" ayat ", " verse ") + posisiGlobal.second
        }
        if (surahBerkas in 1..114) {
            return tr(" · Surah ", " · Surah ") + PenafsirQuran.namaTampil(surahBerkas)
        }
        return ""
    }

    private fun perbaruiNotifikasi() {
        val status = when {
            dijeda -> tr(" · dijeda", " · paused")
            menungguJeda -> tr(" · jeda", " · pause")
            !siap -> tr(" · menyiapkan", " · preparing")
            else -> tr(" · sedang diputar", " · playing")
        }
        val total = totalItem()
        val posisi = when {
            ulangN == 0 && daftarUrl.isNotEmpty() -> " · " + tr("putaran ", "round ") + (indeks / daftarUrl.size + 1)
            total > 1 -> " · " + (indeks + 1) + "/" + total
            else -> ""
        }
        val bacaan = keteranganPosisiBacaan()
        try {
            getSystemService(NotificationManager::class.java).notify(
                NOTIF_ID, bangunNotifikasi(label + bacaan + posisi + status)
            )
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        nomorPermintaanPutar.incrementAndGet()
        pekerjaIndeksAudio.shutdownNow()
        handler.removeCallbacksAndMessages(null)
        generasi++
        lepasPemutar()
        lepasPramuat()
        lepasFokus()
        lepasKunci()
        super.onDestroy()
    }

    companion object {
        const val ACTION_PUTAR = "com.novan.bateraibicara.action.QURAN_PUTAR"
        const val ACTION_JEDA = "com.novan.bateraibicara.action.QURAN_JEDA"
        const val ACTION_LANJUT = "com.novan.bateraibicara.action.QURAN_LANJUT"
        const val ACTION_BERHENTI = "com.novan.bateraibicara.action.QURAN_BERHENTI"
        const val EXTRA_KANDIDAT = "kandidat_perintah_quran"
        private const val SALURAN = "pemutar_quran_suara"
        private const val NOTIF_ID = 9610
        private val kunciCacheAudioQuran = Any()
        private val cacheAudioQuran = mutableMapOf<Int, Map<Int?, Uri>>()
        @Volatile private var identitasCacheAudioQuran = ""

        fun kirim(context: Context, aksi: String, kandidat: List<String>? = null) {
            val i = Intent(context, PemutarQuranService::class.java).setAction(aksi)
            if (kandidat != null) i.putStringArrayListExtra(EXTRA_KANDIDAT, ArrayList(kandidat))
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
}

/** Penafsir perintah putar Al-Qur'an yang berdiri sendiri (tanpa teks Al-Qur'an/Khatam): nama surah, nomor surah, ayat, rentang ayat, juz. */
object PenafsirQuran {
    data class Perintah(
        val juz: Int?, val surah: Int?, val ayat: Int?, val ayatAkhir: Int?,
        val ulang: Int = 1,              // jumlah putaran; 0 = tanpa batas
        val perAyat: Boolean = false,    // true: tiap ayat diulang; false: seluruh bagian diulang
        val sampaiAkhir: Boolean = false,
        val relatif: Int = 0,            // +1 berikutnya, -1 sebelumnya (tanpa acuan surah/ayat/juz)
        val relatifSatuan: Int = 0,      // 0 ayat, 1 surah, 2 juz
        val ulangiTerakhir: Boolean = false,
        val kecepatan: Float? = null,
        val jedaDetik: Int = 0,
        val terjemah: Int = 0,           // FIX205: 0 tanpa; 1 bacaan Arab lalu terjemahan Indonesia; 2 terjemahan Indonesia saja
        val halaman: Int? = null         // Nomor halaman mushaf Madinah 1..604
    ) {
        /** Ada permintaan di luar "putar X" biasa; hanya pemutar latar belakang yang memahaminya. */
        val adaDirektif: Boolean
            get() = ulang != 1 || perAyat || sampaiAkhir || relatif != 0 || ulangiTerakhir || kecepatan != null || jedaDetik > 0 || terjemah != 0 || halaman != null
    }

    private val jumlahAyatSurah = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135, 112, 78, 118, 64, 77, 227,
        93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96,
        29, 22, 24, 13, 14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17,
        19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )

    /** Awal tiap juz (surah, ayat) menurut mushaf Madinah. */
    private val awalJuz = arrayOf(
        1 to 1, 2 to 142, 2 to 253, 3 to 93, 4 to 24, 4 to 148, 5 to 82, 6 to 111, 7 to 88, 8 to 41,
        9 to 93, 11 to 6, 12 to 53, 15 to 1, 17 to 1, 18 to 75, 21 to 1, 23 to 1, 25 to 21, 27 to 56,
        29 to 46, 33 to 31, 36 to 28, 39 to 32, 41 to 47, 46 to 1, 51 to 31, 58 to 1, 67 to 1, 78 to 1
    )

    private val namaLatin = listOf(
        "AlFaatihah", "AlBaqarah", "AliImran", "AnNisaa", "AlMaaidah", "AlAnaam",
        "AlAaraaf", "AlAnfaal", "AtTaubah", "Yunus", "Huud", "Yusuf",
        "ArRaad", "Ibrahim", "AlHijr", "AnNahl", "AlIsraa", "AlKahfi",
        "Maryam", "Thaahaa2", "AlAnbiyaa", "AlHajj", "AlMuminuun", "AnNuur",
        "AlFurqaan", "AsySyuaaraa", "AnNaml", "AlQashash", "AlAnkabuut", "ArRuum",
        "Luqman", "AsSajdah", "AlAhzab", "Sabaa", "Faathir", "Yaasiin",
        "AshShaaffaat", "Shaad", "AzZumar", "AlMuumin", "Fushshilat", "AsySyuura",
        "AzZukhruf", "AdDukhaan", "AlJaatsiyah", "AlAhqaaf", "Muhammad", "AlFath",
        "AlHujuraat", "Qaaf", "AdzDzaariyaat", "AthThuur", "AnNajm", "AlQamar",
        "ArRahmaan", "AlWaqiah", "AlHadiid", "AlMujaadilah", "AlHasyr", "AlMumtahanah",
        "AshShaff", "AlJumuah", "AlMunaafiquun", "AtTaghaabun", "AthThalaaq", "AtTahrim",
        "AlMulk", "AlQalam", "AlHaaqqah", "AlMaaarij", "Nuh", "AlJin",
        "AlMuzzammil", "AlMuddatstsir", "AlQiyaamah", "AlInsaan", "AlMursalaat", "AnNaba",
        "AnNaaziaat", "Abasa", "AtTakwiir", "AlInfithaar", "AlMuthaffifin", "AlInsyiqaaq",
        "AlBuruuj", "AthThaariq", "AlAalaa", "AlGhaasyiyah", "AlFajr", "AlBalad",
        "AsySyams", "AlLail", "AdhDhuhaa", "AlamNasyrah", "AtTiin", "AlAlaq",
        "AlQadr", "AlBayyinah", "AlZalzalah", "AlAadiyaat", "AlQaariah", "AtTakaatsur",
        "AlAshr", "AlHumazah", "AlFiil", "Quraisy", "AlMaauun", "AlKautsar",
        "AlKaafiruun", "AnNashr", "AlLahab", "AlIkhlash", "AlFalaq", "AnNaas"
    )

    fun jumlahAyat(surah: Int): Int = if (surah in 1..114) jumlahAyatSurah[surah - 1] else 0

    fun global(surah: Int, ayat: Int): Int {
        var g = ayat
        for (i in 1 until surah) g += jumlahAyatSurah[i - 1]
        return g
    }

    fun rentangJuz(juz: Int): IntRange? {
        if (juz !in 1..30) return null
        val (s, a) = awalJuz[juz - 1]
        val awal = global(s, a)
        val akhir = if (juz < 30) { val (s2, a2) = awalJuz[juz]; global(s2, a2) - 1 } else 6236
        return awal..akhir
    }

    private fun gantiKataAngka(tokens: List<String>): List<String> {
        val dasar = mapOf(
            "nol" to 0, "satu" to 1, "dua" to 2, "tiga" to 3, "empat" to 4, "lima" to 5, "enam" to 6, "tujuh" to 7,
            "delapan" to 8, "sembilan" to 9, "sepuluh" to 10, "sebelas" to 11,
            "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
            "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
            "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19,
            "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
        )
        val hasil = mutableListOf<String>()
        var total = 0; var seg = 0; var ada = false
        fun tutup() { if (ada) hasil.add((total + seg).toString()); total = 0; seg = 0; ada = false }
        for (t in tokens) {
            val v = dasar[t]
            when {
                v != null -> { seg += v; ada = true }
                t == "belas" && ada -> seg += 10
                t == "puluh" && ada -> seg *= 10
                (t == "ratus" || t == "hundred") && ada -> { total += (if (seg == 0) 1 else seg) * 100; seg = 0 }
                t == "seratus" -> { total += 100; ada = true }
                (t == "dan" || t == "and") && ada -> { }
                else -> { tutup(); hasil.add(t) }
            }
        }
        tutup()
        return hasil
    }

    /** Nama surah untuk ditampilkan pada toast dan notifikasi, agar pengguna dapat memeriksa apa yang dipahami. */
    private val daftarNamaTampil = listOf(
        "Al-Fatihah", "Al-Baqarah", "Ali 'Imran", "An-Nisa'", "Al-Ma'idah", "Al-An'am", "Al-A'raf", "Al-Anfal", "At-Taubah", "Yunus",
        "Hud", "Yusuf", "Ar-Ra'd", "Ibrahim", "Al-Hijr", "An-Nahl", "Al-Isra'", "Al-Kahfi", "Maryam", "Taha",
        "Al-Anbiya'", "Al-Hajj", "Al-Mu'minun", "An-Nur", "Al-Furqan", "Asy-Syu'ara'", "An-Naml", "Al-Qasas", "Al-'Ankabut", "Ar-Rum",
        "Luqman", "As-Sajdah", "Al-Ahzab", "Saba'", "Fatir", "Yasin", "As-Saffat", "Sad", "Az-Zumar", "Gafir",
        "Fussilat", "Asy-Syura", "Az-Zukhruf", "Ad-Dukhan", "Al-Jasiyah", "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf",
        "Az-Zariyat", "At-Tur", "An-Najm", "Al-Qamar", "Ar-Rahman", "Al-Waqi'ah", "Al-Hadid", "Al-Mujadilah", "Al-Hasyr", "Al-Mumtahanah",
        "As-Saff", "Al-Jumu'ah", "Al-Munafiqun", "At-Tagabun", "At-Talaq", "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Ma'arij",
        "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddassir", "Al-Qiyamah", "Al-Insan", "Al-Mursalat", "An-Naba'", "An-Nazi'at", "'Abasa",
        "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Insyiqaq", "Al-Buruj", "At-Tariq", "Al-A'la", "Al-Gasyiyah", "Al-Fajr", "Al-Balad",
        "Asy-Syams", "Al-Lail", "Ad-Duha", "Al-Insyirah", "At-Tin", "Al-'Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-'Adiyat",
        "Al-Qari'ah", "At-Takasur", "Al-'Asr", "Al-Humazah", "Al-Fil", "Quraisy", "Al-Ma'un", "Al-Kausar", "Al-Kafirun", "An-Nasr",
        "Al-Lahab", "Al-Ikhlas", "Al-Falaq", "An-Nas"
    )

    fun namaTampil(surah: Int): String = daftarNamaTampil.getOrNull(surah - 1).orEmpty()

    /**
     * Ejaan lain yang lazim muncul dari pengenalan suara, di luar daftar nama dasar (FIX100). Pengenal suara memakai ejaan
     * bebas ("Al Ikhlas" bukan "Al Ikhlash", "Kausar" bukan "Kautsar"), sehingga nama yang diucapkan benar bisa tidak cocok.
     */
    private val aliasNama: Map<Int, List<String>> = mapOf(
        1 to listOf("fatihah", "fatiha", "fatehah", "alfatihah"), 2 to listOf("baqarah", "bakarah", "baqoroh", "albaqarah"),
        18 to listOf("kahfi", "kahf", "alkahfi"), 36 to listOf("yasin", "yasiin", "yaasiin"),
        55 to listOf("rahman", "arrahman", "rohman"), 56 to listOf("waqiah", "wakiah"), 67 to listOf("mulk", "almulk"),
        78 to listOf("naba", "annaba"), 86 to listOf("tariq", "thariq", "tarik", "attariq"),
        87 to listOf("ala", "aala", "alaa", "alaala", "alala"),
        88 to listOf("ghasyiyah", "gasiyah", "ghashiyah", "ghosyiyah", "alghasyiyah"), 89 to listOf("fajr", "fajar", "alfajr"),
        91 to listOf("syams", "shams", "assyams"), 92 to listOf("lail", "layl", "laili", "allail"),
        93 to listOf("duha", "dhuha", "dhuhaa", "adduha", "adhdhuha"),
        94 to listOf("insyirah", "insyiroh", "alamnasyrah", "nasyrah", "syarh", "sharh", "alamnasrah"),
        95 to listOf("tin", "tiin", "attin", "attiin"), 96 to listOf("alaq", "alak", "iqra", "iqro"),
        97 to listOf("qadr", "qodar", "kadar", "alqadr"), 98 to listOf("bayyinah", "bayinah", "bayyina"),
        99 to listOf("zalzalah", "zilzal", "zalzala", "zilzalah"), 100 to listOf("adiyat", "adiyaat", "aadiyat"),
        101 to listOf("qariah", "qaria", "kariah", "alqariah"), 102 to listOf("takatsur", "takasur", "takatur"),
        103 to listOf("asr", "ashr", "ashar", "alasr"), 104 to listOf("humazah", "humaza"), 105 to listOf("fil", "fiil", "alfil"),
        106 to listOf("quraisy", "quraish", "quraysh", "kuraisy", "kuraish"), 107 to listOf("maun", "maaun", "almaun"),
        108 to listOf("kautsar", "kausar", "kausor", "alkautsar"),
        109 to listOf("kafirun", "kafiruun", "kafirin", "kafiron", "alkafirun"), 110 to listOf("nasr", "annasr", "nashr", "annashr"),
        111 to listOf("lahab", "masad", "tabbat", "allahab"), 112 to listOf("ikhlas", "ikhlash", "alikhlas"),
        113 to listOf("falaq", "falak", "alfalaq"), 114 to listOf("nas", "nass", "annas", "annaas")
    )

    /**
     * Kunci fonetik: menyamakan ejaan yang berbeda tetapi terdengar sama (sh/sy, kh/k, th/t, ts/s, q/k, e/i, o/u, huruf kembar).
     * Contoh: "Ikhlash", "Ikhlas", "Iklas" menjadi sama.
     */
    private fun fonetik(s: String): String {
        var t = s.lowercase().filter { it in 'a'..'z' }
        for ((a, b) in listOf("sy" to "s", "sh" to "s", "kh" to "k", "gh" to "g", "dh" to "d", "dz" to "d", "th" to "t", "ts" to "s",
            "ph" to "f", "ck" to "k", "ay" to "ai", "ey" to "ei", "ou" to "u")) t = t.replace(a, b)
        t = t.replace('q', 'k').replace('c', 'k').replace('v', 'f').replace('e', 'i').replace('o', 'u')
        val sb = StringBuilder()
        for (c in t) if (sb.isEmpty() || sb[sb.length - 1] != c) sb.append(c)
        return sb.toString()
    }

    private fun jarakEdit(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var sebelum = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val kini = IntArray(b.length + 1)
            kini[0] = i
            for (j in 1..b.length) {
                val biaya = if (a[i - 1] == b[j - 1]) 0 else 1
                kini[j] = minOf(kini[j - 1] + 1, sebelum[j] + 1, sebelum[j - 1] + biaya)
            }
            sebelum = kini
        }
        return sebelum[b.length]
    }

    /** Semua bentuk fonetik nama tiap surah: nama dasar, alias, dan masing-masing tanpa awalan "Al/An/Ar/As...". */
    private val bentukNama: List<Set<String>> by lazy {
        val awalan = listOf("asy", "ash", "adh", "adz", "ath", "al", "an", "ar", "as", "at", "ad", "az").map { fonetik(it) }
        (0 until 114).map { i ->
            val hasil = HashSet<String>()
            for (nama in listOf(namaLatin[i]) + (aliasNama[i + 1] ?: emptyList())) {
                val k = fonetik(nama)
                if (k.length >= 2) hasil.add(k)
                for (a in awalan) if (k.startsWith(a) && k.length - a.length >= 4) hasil.add(k.substring(a.length))
            }
            hasil
        }
    }

    /**
     * Mencari nomor surah dari kata-kata sisa ucapan. Tahap 1: cocok persis atau mengandung nama (yang terpanjang menang;
     * nama sependek 3 huruf harus sama persis). Tahap 2, hanya bila tahap 1 gagal: toleransi satu atau dua salah huruf pada
     * jendela 1 sampai 3 kata, dengan huruf pertama yang sama dan panjang minimal 6, agar salah dengar kecil tetap terbaca
     * tetapi kata sehari-hari tidak mudah salah dikira nama surah.
     */
    private fun cocokkanNamaSurah(tokens: List<String>): Int? {
        val teks = fonetik(tokens.joinToString(""))
        if (teks.isEmpty()) return null
        var terbaik: Int? = null
        var panjangTerbaik = 0
        for (i in 0 until 114) {
            for (k in bentukNama[i]) {
                val cocok = if (k.length <= 3) teks == k else teks.contains(k)
                if (cocok && k.length > panjangTerbaik) { terbaik = i + 1; panjangTerbaik = k.length }
            }
        }
        if (terbaik != null) return terbaik
        var jarakTerbaik = 99
        var panjangForm = 0
        for (a in tokens.indices) {
            for (b in (a + 1)..minOf(tokens.size, a + 3)) {
                val w = fonetik(tokens.subList(a, b).joinToString(""))
                if (w.length < 6) continue
                for (i in 0 until 114) {
                    for (k in bentukNama[i]) {
                        if (k.length < 6 || k[0] != w[0]) continue
                        val batas = if (k.length < 10) 1 else 2
                        val d = jarakEdit(w, k)
                        if (d <= batas && (d < jarakTerbaik || (d == jarakTerbaik && k.length > panjangForm))) {
                            terbaik = i + 1; jarakTerbaik = d; panjangForm = k.length
                        }
                    }
                }
            }
        }
        return terbaik
    }

    private const val MAKS_ULANG = 999
    private val kunciSurahSet = setOf("surah", "surat", "sura")
    private val kunciAyatSet = setOf("ayat", "ayah", "verse", "aya")
    private val kunciJuzSet = setOf("juz", "jus", "juzz")
    private val kataKali = setOf("kali", "times", "time", "x")

    /** Isyarat tambahan dalam ucapan di luar "putar X": pengulangan, kecepatan, jeda, rentang sampai akhir, ayat berikutnya, ulangi. */
    private class Direktif {
        var ulang = 1          // 0 = tanpa batas
        var perAyat = false
        var sampaiAkhir = false
        var relatif = 0
        var satuan = 0         // 0 ayat, 1 surah, 2 juz
        var kataUlang = false
        var kecepatan: Float? = null
        var jeda = 0
        var terjemah = 0       // FIX205
        var halaman: Int? = null
    }


    // FIX205: audio terjemahan Indonesia (satu berkas MP3 per surah penuh) dari Internet Archive "quraninindonesia".
    // Sengaja val biasa (bukan const): hanya dipakai saat berjalan, dan sama dengan KhatamActivity.
    private val URL_DASAR_TERJEMAHAN_ID = "https://archive.org/download/quraninindonesia/"
    val berkasTerjemahanId: List<String> = listOf(
        "AlFaatihah", "AlBaqarah", "AliImran", "AnNisaa", "AlMaaidah", "AlAnaam",
        "AlAaraaf", "AlAnfaal", "AtTaubah", "Yunus", "Huud", "Yusuf",
        "ArRaad", "Ibrahim", "AlHijr", "AnNahl", "AlIsraa", "AlKahfi",
        "Maryam", "Thaahaa2", "AlAnbiyaa", "AlHajj", "AlMuminuun", "AnNuur",
        "AlFurqaan", "AsySyuaaraa", "AnNaml", "AlQashash", "AlAnkabuut", "ArRuum",
        "Luqman", "AsSajdah", "AlAhzab", "Sabaa", "Faathir", "Yaasiin",
        "AshShaaffaat", "Shaad", "AzZumar", "AlMuumin", "Fushshilat", "AsySyuura",
        "AzZukhruf", "AdDukhaan", "AlJaatsiyah", "AlAhqaaf", "Muhammad", "AlFath",
        "AlHujuraat", "Qaaf", "AdzDzaariyaat", "AthThuur", "AnNajm", "AlQamar",
        "ArRahmaan", "AlWaqiah", "AlHadiid", "AlMujaadilah", "AlHasyr", "AlMumtahanah",
        "AshShaff", "AlJumuah", "AlMunaafiquun", "AtTaghaabun", "AthThalaaq", "AtTahrim",
        "AlMulk", "AlQalam", "AlHaaqqah", "AlMaaarij", "Nuh", "AlJin",
        "AlMuzzammil", "AlMuddatstsir", "AlQiyaamah", "AlInsaan", "AlMursalaat", "AnNaba",
        "AnNaaziaat", "Abasa", "AtTakwiir", "AlInfithaar", "AlMuthaffifin", "AlInsyiqaaq",
        "AlBuruuj", "AthThaariq", "AlAalaa", "AlGhaasyiyah", "AlFajr", "AlBalad",
        "AsySyams", "AlLail", "AdhDhuhaa", "AlamNasyrah", "AtTiin", "AlAlaq",
        "AlQadr", "AlBayyinah", "AlZalzalah", "AlAadiyaat", "AlQaariah", "AtTakaatsur",
        "AlAshr", "AlHumazah", "AlFiil", "Quraisy", "AlMaauun", "AlKautsar",
        "AlKaafiruun", "AnNashr", "AlLahab", "AlIkhlash", "AlFalaq", "AnNaas"
    )

    /** Alamat audio terjemahan Indonesia satu surah penuh, atau null bila nomor surah tidak sah. */
    fun urlTerjemahanId(surah: Int): String? {
        val nama = berkasTerjemahanId.getOrNull(surah - 1) ?: return null
        return URL_DASAR_TERJEMAHAN_ID + String.format(java.util.Locale.ROOT, "%03d", surah) + nama + ".mp3"
    }

    private val kataTerjemah = setOf("terjemah", "terjemahan", "terjemahnya", "terjemahannya", "translation", "translations", "translated", "artinya", "arti")
    private val kataHanya = setOf("saja", "aja", "only", "hanya", "doang")
    private val kataGabung = setOf("dan", "dengan", "beserta", "serta", "and", "with", "plus", "sama", "lalu", "kemudian", "then")
    private val kataBahasaId = setOf("indonesia", "indonesian", "bahasa", "indo", "in", "dalam", "language")

    /** Mengeluarkan kata "terjemahan (Indonesia)" dari token dan mengisi d.terjemah; token lain tidak diubah. */
    private fun ekstrakTerjemah(tokens: List<String>, d: Direktif): List<String> {
        if (tokens.none { it in kataTerjemah }) return tokens
        val hapus = BooleanArray(tokens.size)
        var hanya = false
        for (i in tokens.indices) {
            if (tokens[i] !in kataTerjemah) continue
            hapus[i] = true
            var k = i + 1
            while (k < tokens.size && tokens[k] in kataBahasaId) { hapus[k] = true; k++ }
            if (k < tokens.size && tokens[k] in kataHanya) { hapus[k] = true; hanya = true }
            var b = i - 1
            while (b >= 0 && tokens[b] in kataBahasaId) { hapus[b] = true; b-- }
            if (b >= 0 && tokens[b] in kataGabung) hapus[b] = true
            if (b >= 0 && tokens[b] in kataHanya) { hapus[b] = true; hanya = true }
            // "hanya terjemahan", "terjemahan saja"
            if (i >= 1 && tokens[i - 1] in kataHanya) { hapus[i - 1] = true; hanya = true }
        }
        d.terjemah = if (hanya) 2 else 1
        return tokens.filterIndexed { idx, _ -> !hapus[idx] }
    }

    private fun hapusTerakhir(daftar: ArrayList<String>) { if (daftar.isNotEmpty()) daftar.removeAt(daftar.size - 1) }

    /**
     * Mengeluarkan isyarat tambahan dari token ucapan dan mengembalikan token sisanya untuk ditafsirkan sebagai acuan
     * (surah/ayat/juz). Contoh: "putar surah 1 ayat 7 sebanyak 5 kali" menghasilkan ulang=5 dan sisa "putar surah 1 ayat 7".
     */
    private fun ekstrakDirektif(tokensAsli: List<String>, d: Direktif): List<String> {
        val tokens = ekstrakTerjemah(tokensAsli, d)
        val keluar = ArrayList<String>()
        val polaAngkaX = Regex("^(\\d{1,3})x$")
        val polaXAngka = Regex("^x(\\d{1,3})$")
        val kataPengisi = setOf("sebanyak", "selama", "sebesar", "sebanyaknya", "diulang", "ulangi", "ulang", "mengulang", "repeat", "repeated", "for")
        val kataUlangSemua = setOf("ulangi", "ulang", "diulang", "mengulang", "repeat", "repeated", "again", "lagi", "berulang")
        val penghubung = setOf("sampai", "hingga", "sd", "s", "d", "to", "until", "till", "through", "ke")
        val kataAkhir = setOf("akhir", "selesai", "habis", "tamat", "end", "finish")
        val kataPerAyat = setOf("setiap", "tiap", "masing", "each", "every")
        val kataBerikut = setOf("berikutnya", "selanjutnya", "next", "sesudahnya", "setelahnya")
        val kataSebelum = setOf("sebelumnya", "previous", "prev")
        val kataJeda = setOf("jeda", "selang", "jarak", "interval", "gap", "delay")
        val kataDetik = setOf("detik", "second", "seconds", "sec", "secs")
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            val n = t.toIntOrNull()
            val berikut = tokens.getOrNull(i + 1)
            if (t in setOf("halaman", "page", "mushaf")) {
                val angkaHalaman = when {
                    berikut?.toIntOrNull() != null -> berikut.toInt()
                    berikut in setOf("ke", "nomor", "number") -> tokens.getOrNull(i + 2)?.toIntOrNull()
                    else -> null
                }
                if (angkaHalaman != null) {
                    d.halaman = angkaHalaman
                    i += if (berikut in setOf("ke", "nomor", "number")) 3 else 2
                    continue
                }
            }
            // "5 kali", "lima kali" (sudah menjadi angka), "5 times"
            if (n != null && berikut != null && berikut in kataKali) {
                d.ulang = n.coerceIn(1, MAKS_ULANG)
                val pengisi = keluar.lastOrNull()
                if (pengisi != null && pengisi in kataPengisi) { if (pengisi in kataUlangSemua) d.kataUlang = true; hapusTerakhir(keluar) }
                i += 2
                continue
            }
            // "5x" atau "x5"
            val mAx = polaAngkaX.matchEntire(t) ?: polaXAngka.matchEntire(t)
            if (mAx != null) {
                d.ulang = mAx.groupValues[1].toInt().coerceIn(1, MAKS_ULANG)
                val pengisi = keluar.lastOrNull()
                if (pengisi != null && pengisi in kataPengisi) { if (pengisi in kataUlangSemua) d.kataUlang = true; hapusTerakhir(keluar) }
                i++
                continue
            }
            if (t == "sekali") { i++; continue }
            // tanpa batas: "terus menerus", "selamanya", "tanpa batas", "tak terbatas", "forever", "loop"
            if (t == "menerus" || t == "selamanya" || t == "forever" || t == "loop") {
                if (t == "menerus" && keluar.lastOrNull() == "terus") hapusTerakhir(keluar)
                d.ulang = 0; i++; continue
            }
            if (t == "batas" && keluar.lastOrNull() == "tanpa") { hapusTerakhir(keluar); d.ulang = 0; i++; continue }
            if (t == "terbatas" && (keluar.lastOrNull() == "tak" || keluar.lastOrNull() == "tidak")) { hapusTerakhir(keluar); d.ulang = 0; i++; continue }
            if (t in kataPerAyat) { d.perAyat = true; i++; continue }
            // kecepatan
            if (t == "pelan" || t == "lambat" || t == "slow" || t == "slowly" || t == "perlahan") { d.kecepatan = 0.75f; i++; continue }
            if (t == "cepat" || t == "fast" || t == "quick" || t == "quickly") {
                val k = d.kecepatan
                d.kecepatan = if (k != null && k > 1.0f) 1.5f else 1.25f
                i++; continue
            }
            if (t == "normal") { d.kecepatan = 1.0f; i++; continue }
            if (t in kataUlangSemua) { d.kataUlang = true; i++; continue }
            if (t == "mulai" || t == "mulailah" || t == "dimulai" || t == "start" || t == "begin") { i++; continue }
            // "sampai akhir", "hingga selesai", "ke akhir", "sampai ayat terakhir"
            if (t in kataAkhir && keluar.lastOrNull()?.let { it in penghubung } == true) {
                hapusTerakhir(keluar); d.sampaiAkhir = true; i++; continue
            }
            if (t == "terakhir") {
                val a = keluar.lastOrNull()
                val b = if (keluar.size >= 2) keluar[keluar.size - 2] else null
                if (a != null && a in penghubung) { hapusTerakhir(keluar); d.sampaiAkhir = true; i++; continue }
                if (a != null && a in kunciAyatSet && b != null && b in penghubung) { hapusTerakhir(keluar); hapusTerakhir(keluar); d.sampaiAkhir = true; i++; continue }
            }
            // "ayat berikutnya", "surah sebelumnya", "juz selanjutnya", "next verse"
            if (t in kataBerikut || t in kataSebelum) {
                d.relatif = if (t in kataBerikut) 1 else -1
                val terakhir = keluar.lastOrNull()
                if (terakhir != null && terakhir in kunciSurahSet) { d.satuan = 1; hapusTerakhir(keluar) }
                else if (terakhir != null && terakhir in kunciJuzSet) { d.satuan = 2; hapusTerakhir(keluar) }
                else if (terakhir != null && terakhir in kunciAyatSet) { d.satuan = 0; hapusTerakhir(keluar) }
                else if (berikut != null && berikut in kunciSurahSet) { d.satuan = 1; i++ }
                else if (berikut != null && berikut in kunciJuzSet) { d.satuan = 2; i++ }
                else if (berikut != null && berikut in kunciAyatSet) { d.satuan = 0; i++ }
                i++; continue
            }
            // jeda: "jeda 3 detik"
            if (t in kataJeda) {
                val angka = tokens.getOrNull(i + 1)?.toIntOrNull()
                val satuanWaktu = tokens.getOrNull(i + 2)
                if (angka != null && satuanWaktu != null && satuanWaktu in kataDetik) {
                    d.jeda = angka.coerceIn(0, 60)
                    val sebelum = keluar.lastOrNull()
                    if (sebelum != null && (sebelum == "dengan" || sebelum == "beri" || sebelum == "with")) hapusTerakhir(keluar)
                    i += 3
                    continue
                }
            }
            keluar.add(t)
            i++
        }
        return keluar
    }

    private fun tokenUcapan(ucapan: String): List<String> =
        gantiKataAngka(ucapan.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() })

    /** Ada isyarat tambahan (pengulangan dan lain-lain) yang hanya dipahami pemutar latar belakang. */
    fun adaDirektif(kandidat: List<String>): Boolean = tafsir(kandidat)?.adaDirektif == true

    /** Ucapan tanpa isyarat tambahan, untuk penafsir lain (Khatam) yang tidak memahaminya. */
    fun bersihkanDirektif(kandidat: List<String>): List<String> =
        kandidat.map { ekstrakDirektif(tokenUcapan(it), Direktif()).joinToString(" ") }

    /** Nomor juz (1..30) tempat ayat berada. */
    fun juzDari(surah: Int, ayat: Int): Int {
        var hasil = 1
        for (j in awalJuz.indices) {
            val (s, a) = awalJuz[j]
            if (surah > s || (surah == s && ayat >= a)) hasil = j + 1
        }
        return hasil
    }

    fun posisiDariGlobal(global: Int): Pair<Int, Int>? {
        if (global !in 1..6236) return null
        var sisa = global
        for (i in jumlahAyatSurah.indices) {
            if (sisa <= jumlahAyatSurah[i]) return (i + 1) to sisa
            sisa -= jumlahAyatSurah[i]
        }
        return null
    }

    /** Hasil penafsiran satu ucapan: perintah (bila ada), apakah surah/juz disebut jelas, atau nama yang tidak dikenali. */
    private class HasilSatu(val perintah: Perintah?, val eksplisit: Boolean, val takDikenal: String?)

    /** Kata pengisi yang tidak dianggap sebagai nama surah yang gagal dikenali. */
    private val kataIsian = setOf("tolong", "dong", "yah", "deh", "saja", "aja", "nih", "itu", "ini", "lah", "kah", "sekarang", "now",
        "please", "lagi", "aku", "saya", "mau", "ingin", "pengen", "untuk", "for", "pada", "dalam", "bagian", "nomor", "number",
        "ayatnya", "surahnya", "suratnya", "alquran", "quran", "murattal", "audio", "suara", "bacaan", "tilawah", "sama", "oleh", "dengan")

    private fun tafsirSatu(ucapan: String): HasilSatu {
        val kataPerintah = setOf("putar", "putarkan", "mainkan", "bacakan", "baca", "play", "please", "tolong", "nomor", "number",
            "ke", "dari", "the", "of", "di", "yang", "dengan", "lalu", "alquran", "quran")
        val kunciJuz = kunciJuzSet
        val kunciAyat = kunciAyatSet
        val kunciSurah = kunciSurahSet
        val penghubungRentang = setOf("sampai", "hingga", "dengan", "sd", "s", "d", "to", "through", "until", "till", "ke", "and", "dan", "sampe")
        val d = Direktif()
        val tokens = ekstrakDirektif(tokenUcapan(ucapan), d)
        var juz: Int? = null; var surah: Int? = null; var ayat: Int? = null; var ayatAkhir: Int? = null
        val sisa = mutableListOf<String>()
        val angkaLepas = mutableListOf<Int>()
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            val berikut = tokens.getOrNull(i + 1)?.toIntOrNull()
            when {
                t in kunciJuz && berikut != null -> { juz = berikut; i += 2; continue }
                t in kunciAyat && berikut != null -> {
                    if (ayat == null) {
                        ayat = berikut
                        var k = i + 2
                        val awalK = k
                        while (k < tokens.size && tokens[k] in penghubungRentang) k++
                        if (k > awalK && k < tokens.size && tokens[k] in kunciAyat) k++
                        val angkaAkhir = tokens.getOrNull(k)?.toIntOrNull()
                        if (angkaAkhir != null) { ayatAkhir = angkaAkhir; k++ }
                        i = k
                    } else { ayatAkhir = berikut; i += 2 }
                    continue
                }
                t in kunciSurah && berikut != null -> { surah = berikut; i += 2; continue }
                t in kunciJuz || t in kunciAyat || t in kunciSurah || t in kataPerintah -> { }
                t.toIntOrNull() != null -> angkaLepas.add(t.toInt())
                else -> sisa.add(t)
            }
            i++
        }
        val dariNama = cocokkanNamaSurah(sisa)
        var surahDariNama = false
        if (surah == null && dariNama != null) {
            surah = dariNama
            surahDariNama = true
            if (ayat == null && juz == null && angkaLepas.isNotEmpty()) {
                ayat = angkaLepas[0]
                if (angkaLepas.size >= 2) ayatAkhir = angkaLepas[1]
            }
        } else if (surah == null && ayat == null && juz == null && angkaLepas.size >= 2) {
            surah = angkaLepas[0]; ayat = angkaLepas[1]
        } else if (surah == null && ayat == null && juz == null && angkaLepas.size == 1 && sisa.isEmpty()) {
            surah = angkaLepas[0]
        }
        // Kata yang tersisa dan bukan nama surah yang dikenali: mungkin nama surah yang salah dengar atau tidak dikenal.
        val sisaBermakna = if (surahDariNama) emptyList<String>() else sisa.filter { it.length >= 3 && it !in kataIsian }
        val adaKataSurah = tokens.any { it in kunciSurah }
        if (juz == null && surah == null && ayat != null && sisaBermakna.isNotEmpty()) {
            // "putar surah <nama tak dikenal> ayat 1": jangan diam-diam memakai surah terakhir (FIX100).
            return HasilSatu(null, false, sisaBermakna.joinToString(" "))
        }
        if (juz == null && surah == null && ayat == null && d.halaman == null) {
            // Tanpa acuan: "ayat berikutnya", "surah sebelumnya", "ulangi 3 kali", "putar lagi".
            if (d.relatif != 0) return HasilSatu(Perintah(null, null, null, null, d.ulang, d.perAyat, false, d.relatif, d.satuan, false, d.kecepatan, d.jeda, d.terjemah), true, null)
            if (d.kataUlang) return HasilSatu(Perintah(null, null, null, null, d.ulang, d.perAyat, false, 0, 0, true, d.kecepatan, d.jeda, d.terjemah), true, null)
            // FIX259: "putar terjemahnya", "lanjutkan terjemahnya": terjemahan dari bagian yang terakhir diputar.
            if (d.terjemah != 0) return HasilSatu(Perintah(null, null, null, null, d.ulang, d.perAyat, false, 0, 0, true, d.kecepatan, d.jeda, 2), true, null)
            if (adaKataSurah && sisaBermakna.isNotEmpty()) return HasilSatu(null, false, sisaBermakna.joinToString(" "))
            return HasilSatu(null, false, null)
        }
        val p = Perintah(juz, surah, ayat, ayatAkhir, d.ulang, d.perAyat, d.sampaiAkhir, 0, 0, false, d.kecepatan, d.jeda, d.terjemah, d.halaman)
        return HasilSatu(p, surah != null || juz != null || d.halaman != null, null)
    }

    /**
     * Menafsirkan semua kandidat hasil pengenalan suara. Urutan prioritas (FIX100): (1) kandidat yang menyebut surah atau juz
     * dengan jelas; (2) bila ada kandidat dengan nama surah yang tidak dikenali, tolak dan laporkan nama itu, jangan memakai
     * kandidat lain yang tanpa nama; (3) kandidat yang hanya menyebut ayat (memakai surah terakhir).
     * Pasangan hasil: perintah (atau null) dan nama yang tidak dikenali (atau null).
     */
    fun tafsirLengkap(kandidat: List<String>): Pair<Perintah?, String?> {
        var hanyaAyat: Perintah? = null
        var takDikenal: String? = null
        for (u in kandidat) {
            val h = tafsirSatu(u)
            val p = h.perintah
            if (p != null) {
                if (h.eksplisit) return p to null
                if (hanyaAyat == null) hanyaAyat = p
            } else if (takDikenal == null && h.takDikenal != null) {
                takDikenal = h.takDikenal
            }
        }
        if (takDikenal != null) return null to takDikenal
        return hanyaAyat to null
    }

    fun tafsir(kandidat: List<String>): Perintah? = tafsirLengkap(kandidat).first

    /** Dipakai penafsir Khatam sebagai cadangan pencocokan nama surah (ejaan bebas dari pengenal suara). */
    fun nomorSurahDariNama(tokens: List<String>): Int? = cocokkanNamaSurah(tokens)
}
