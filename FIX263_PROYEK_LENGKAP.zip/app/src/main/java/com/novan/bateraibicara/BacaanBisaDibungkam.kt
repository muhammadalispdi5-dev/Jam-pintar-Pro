package com.novan.bateraibicara

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech

/**
 * FIX261: pembacaan isi (hadits, doa, khutbah, manasik, panduan ibadah) ikut dapat dihentikan dengan menelungkupkan HP
 * atau menekan tombol volume (sesuai sakelar di pengaturan), seperti suara notifikasi aplikasi. Pendaftaran dilepas sendiri
 * begitu mesin ucapan selesai, sehingga tombol volume kembali berfungsi biasa setelah pembacaan berakhir.
 */
object BacaanBisaDibungkam {
    private val handler = Handler(Looper.getMainLooper())
    private val generasi = HashMap<String, Int>()

    fun mulai(context: Context, mesin: TextToSpeech, kunci: String, panjangTeks: Int, henti: () -> Unit) {
        val batas = (panjangTeks * 90L).coerceIn(60_000L, 1_800_000L)
        PembungkamTelungkup.mulai(context, kunci, batas, henti)
        val gen = (generasi[kunci] ?: 0) + 1
        generasi[kunci] = gen
        val mulaiMs = System.currentTimeMillis()
        var pernahBicara = false
        val pantau = object : Runnable {
            override fun run() {
                if (generasi[kunci] != gen) return
                val bicara = try { mesin.isSpeaking } catch (_: Exception) { false }
                if (bicara) pernahBicara = true
                if (!bicara && (pernahBicara || System.currentTimeMillis() - mulaiMs > 8_000L)) {
                    PembungkamTelungkup.selesai(kunci)
                    return
                }
                handler.postDelayed(this, 600L)
            }
        }
        handler.postDelayed(pantau, 1_200L)
    }

    /** Dipanggil saat halaman berhenti atau tombol "Hentikan suara" ditekan. */
    fun lepas(kunci: String) {
        generasi[kunci] = (generasi[kunci] ?: 0) + 1
        PembungkamTelungkup.selesai(kunci)
    }
}
