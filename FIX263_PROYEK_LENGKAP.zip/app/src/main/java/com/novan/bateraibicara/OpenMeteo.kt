package com.novan.bateraibicara

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** FIX225: pengambil dan pengurai data Open-Meteo untuk [InfoCuaca]. Selalu mengunduh data baru (tanpa cache). */
object OpenMeteo {

    fun alamat(lat: Double, lon: Double): String =
        "https://api.open-meteo.com/v1/forecast?latitude=" + String.format(Locale.US, "%.4f", lat) + "&longitude=" + String.format(Locale.US, "%.4f", lon) +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m,is_day" +
            "&hourly=precipitation_probability,precipitation,temperature_2m,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,uv_index_max,sunrise,sunset,wind_speed_10m_max" +
            "&forecast_days=3&timezone=auto&wind_speed_unit=kmh"

    private fun unduh(url: String): String {
        val k = URL(url).openConnection() as HttpURLConnection
        try {
            k.requestMethod = "GET"; k.connectTimeout = 12_000; k.readTimeout = 15_000; k.useCaches = false
            k.setRequestProperty("Accept", "application/json"); k.setRequestProperty("Cache-Control", "no-cache")
            k.setRequestProperty("User-Agent", "JamPintarPro/1.0.88 (Android)")
            val kode = k.responseCode
            if (kode !in 200..299) throw java.io.IOException("HTTP_STATUS:" + kode)
            return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { k.disconnect() }
    }

    private fun doubles(a: JSONArray?, awal: Double = Double.NaN): List<Double> =
        if (a == null) emptyList() else (0 until a.length()).map { if (a.isNull(it)) awal else a.optDouble(it, awal) }

    private fun ints(a: JSONArray?, awal: Int = -1): List<Int> =
        if (a == null) emptyList() else (0 until a.length()).map { if (a.isNull(it)) awal else a.optInt(it, awal) }

    private fun teks(a: JSONArray?): List<String> =
        if (a == null) emptyList() else (0 until a.length()).map { a.optString(it, "") }

    fun uraikan(isi: String): InfoCuaca.Data {
        val json = JSONObject(isi)
        val now = json.optJSONObject("current") ?: throw org.json.JSONException("Missing current data")
        val suhu = now.optDouble("temperature_2m", Double.NaN)
        if (!suhu.isFinite()) throw org.json.JSONException("Invalid temperature")
        val per = json.optJSONObject("hourly")
        val dh = json.optJSONObject("daily")
        val tgl = teks(dh?.optJSONArray("time"))
        val kode = ints(dh?.optJSONArray("weather_code"))
        val maks = doubles(dh?.optJSONArray("temperature_2m_max"))
        val min = doubles(dh?.optJSONArray("temperature_2m_min"))
        val curah = doubles(dh?.optJSONArray("precipitation_sum"), 0.0)
        val peluang = ints(dh?.optJSONArray("precipitation_probability_max"), 0)
        val uv = doubles(dh?.optJSONArray("uv_index_max"))
        val terbit = teks(dh?.optJSONArray("sunrise"))
        val terbenam = teks(dh?.optJSONArray("sunset"))
        val anginMaks = doubles(dh?.optJSONArray("wind_speed_10m_max"))
        val hari = tgl.indices.map { i ->
            InfoCuaca.Hari(tgl[i], kode.getOrElse(i) { -1 }, maks.getOrElse(i) { Double.NaN }, min.getOrElse(i) { Double.NaN },
                curah.getOrElse(i) { 0.0 }, peluang.getOrElse(i) { 0 }, uv.getOrElse(i) { Double.NaN },
                terbit.getOrElse(i) { "" }, terbenam.getOrElse(i) { "" }, anginMaks.getOrElse(i) { Double.NaN })
        }
        return InfoCuaca.Data(
            now.optString("time", ""), suhu, now.optDouble("apparent_temperature", suhu), now.optInt("relative_humidity_2m", -1),
            now.optDouble("precipitation", 0.0), now.optInt("weather_code", -1), now.optInt("cloud_cover", -1),
            now.optDouble("wind_speed_10m", Double.NaN), now.optDouble("wind_direction_10m", 0.0), now.optDouble("wind_gusts_10m", Double.NaN),
            now.optInt("is_day", 1) == 1,
            teks(per?.optJSONArray("time")), ints(per?.optJSONArray("precipitation_probability"), 0), doubles(per?.optJSONArray("precipitation"), 0.0),
            hari,
            doubles(per?.optJSONArray("temperature_2m")), ints(per?.optJSONArray("weather_code")), doubles(per?.optJSONArray("wind_speed_10m"))
        )
    }

    /** Null bila gagal untuk alasan apa pun; pemanggil memakai jalur lama sebagai cadangan. */
    fun laporan(lat: Double, lon: Double, tempat: String?, english: Boolean, minta: InfoCuaca.Permintaan, peringatan: String?): String? = try {
        InfoCuaca.susun(uraikan(unduh(alamat(lat, lon))), tempat, english, minta, peringatan)
    } catch (_: Exception) { null }
}
