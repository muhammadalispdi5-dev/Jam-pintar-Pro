# FIX260 - Pemutaran lebih cepat dan terjemah tidak mengulang ayat

Penyebab lambat: pemindaian pohon Jam Pintar Pro (FIX257) dijalankan pada setiap pemutaran. Sekarang hanya dijalankan bila terjemah diminta atau mode offline, hasilnya di-cache 5 menit, dan folder induk surah diingat sehingga surah berikutnya tidak menelusuri ulang pohon.
Penyebab mengulang ayat 1: "putar terjemahnya" memakai indeks yang dibangun tanpa pustaka, lalu jatuh ke bacaan Arab. Sekarang indeks pustaka dibangun untuk surah perintah terakhir saat terjemah diminta, dan bila terjemah saja diminta tetapi tidak ditemukan, audio Arab tidak diputar ulang; hanya muncul pesan petunjuk.
Catatan: belum dikompilasi/diuji di perangkat.
