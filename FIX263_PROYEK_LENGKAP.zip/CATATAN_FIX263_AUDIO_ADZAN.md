# FIX263 - Audio adzan sesuai fungsinya

- `res/raw/azan_biasa.mp3`: adzan Muamar ZA (254 detik) untuk Dzuhur, Ashar, Maghrib, Isya.
- `res/raw/azan_subuh.mp3`: adzan Subuh (225 detik) khusus Subuh.
- Gambar sampul dan metadata dibuang (ffmpeg -c copy, tanpa encode ulang) agar APK tidak membengkak.
- `PrayerAlarmService.kt`: penghenti otomatis adzan bawaan 240 dtk -> 300 dtk; pendaftaran PembungkamTelungkup 240 dtk -> 330 dtk agar adzan tidak terpotong.
- Pemilihan: key == "subuh" -> azan_subuh, selain itu azan_biasa (tidak berubah). Berkas suara pilihan pengguna tetap diutamakan.
- Petunjuk penggunaan: butir 44 (ID) / 41 (EN).
- Belum dikompilasi dengan Gradle, belum diuji di perangkat. Versi tetap 1.0.88.
