b='app/src/main/java/com/novan/bateraibicara/'
g=0
def cek(c,m):
    global g
    if not c: print("GAGAL",m); g+=1
p=open(b+'Pembicara.kt').read(); h=open(b+'Halaman.kt').read(); pr=open(b+'Prefs.kt').read(); ps=open(b+'PerintahSuaraActivity.kt').read()
cek('GemaAudio.daftarKunci.getOrElse(i)' in p,'jam/baterai memakai daftar gema lengkap')
cek('suara.gemaPersen' in p and ', 80)' not in p,'kekuatan gema dari pengaturan')
cek('tambahSenyapWav' in p and 'ekorMs' in p,'ekor gema disisipkan')
cek('gemaPersen' in pr and '+ gemaPersen +' in pr,'pref kekuatan')
cek('pakaiGemaLengkap' in h and 'Kekuatan gema' in h and 'Tes suara' in h,'dialog gema lengkap')
for k in ['PEMANGGIL_IZIN','PEMANGGIL_JENIS','PEMANGGIL_PESAN','PEMANGGIL_MELODI','PEMANGGIL_VOLUME','PEMANGGIL_SUARA']:
    cek(ps.count(k)>=4,'asisten '+k)
cek('kendaliSakelarPemanggil' in ps and 'BACA_NOTIF_SEMUA' in ps and 'NAMA_PEMANGGIL' in ps,'sakelar asisten')
print("selesai",g)
k=open(b+'KhatamActivity.kt').read()
cek('Matikan gema' in k and 'CHOICE_MODE_SINGLE' in k and 'progress * 5' in k,'gema khatam: dialog gabungan + kekuatan')
print("selesai khatam",g)
