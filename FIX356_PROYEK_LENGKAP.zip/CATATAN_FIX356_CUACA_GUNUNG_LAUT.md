# FIX356–357 (belum dikompilasi dengan Gradle / belum diuji di perangkat)
- GunungDunia.kt: ±120 gunung dunia (koordinat+tinggi manual), cuaca puncak via Open-Meteo `elevation=` dengan zona waktu setempat, pagi/siang/sore/malam/dini hari, hari ini/besok/lusa; gunung lain dicari lewat geocoding Open-Meteo (hanya jenis gunung/puncak/vulkan).
- Kondisi terkini gunung (Jenis.KONDISI_GUNUNG): cuaca puncak + peringatan dini BMKG Yogyakarta (Merapi/Merbabu) + gempa terbaru BMKG; status level resmi (PVMBG/BPPTKG) TIDAK dibaca — tidak ada sumber terverifikasi, dijawab jujur.
- LautDunia.kt (Jenis.LAUT): Open-Meteo Marine API, kategori tinggi gelombang BMKG, arah, periode, swell; laut/selat/samudra dari tabel, pantai/kota lewat geocoder (titik laut terdekat).
- Jenis.CONTOH_KALIMAT: "contoh kalimat" membacakan kalimat pembuka yang dikenali; pembuka dialog diperluas (mulai percakapan, dll).
- Petunjuk ID 127–128 / EN 124–125; "Yang baru" 1.0.93 ditambah (versi belum dinaikkan).
