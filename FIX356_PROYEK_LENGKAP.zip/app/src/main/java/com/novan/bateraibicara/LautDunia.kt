package com.novan.bateraibicara

import org.json.JSONObject
import java.util.Locale

/**
 * FIX357: kondisi laut (tinggi gelombang, arah, periode, swell) di perairan Indonesia dan dunia. Data dari Open-Meteo Marine API,
 * prakiraan model gelombang per jam dengan zona waktu setempat. Kategori tinggi gelombang mengikuti pembagian BMKG. Ini bukan
 * peringatan resmi pelayaran; pengguna diarahkan ke prakiraan maritim BMKG untuk keputusan berlayar.
 */
object LautDunia {
    class Laut(val namaId: String, val namaEn: String, val lat: Double, val lon: Double, val kunci: List<String>)

    private fun tr(id: String, en: String, eng: Boolean) = if (eng) en else id
    private fun l(id: String, en: String, lat: Double, lon: Double, kunci: String) =
        Laut(id, en, lat, lon, kunci.split(",").map { it.trim() }.filter { it.isNotEmpty() })

    val daftar: List<Laut> = listOf(
        l("Laut Jawa", "Java Sea", -5.0, 110.0, "laut jawa,java sea"),
        l("Laut Banda", "Banda Sea", -5.5, 127.5, "laut banda,banda sea"),
        l("Laut Flores", "Flores Sea", -7.5, 121.0, "laut flores,flores sea"),
        l("Laut Arafura", "Arafura Sea", -8.5, 135.0, "laut arafura,arafura sea,laut arafuru"),
        l("Laut Natuna Utara", "North Natuna Sea", 4.0, 111.0, "laut natuna,natuna,laut natuna utara"),
        l("Laut Cina Selatan", "South China Sea", 12.0, 114.0, "laut cina selatan,laut china selatan,south china sea"),
        l("Selat Sunda", "Sunda Strait", -6.0, 105.8, "selat sunda,sunda strait"),
        l("Selat Bali", "Bali Strait", -8.3, 114.43, "selat bali,bali strait"),
        l("Selat Lombok", "Lombok Strait", -8.6, 115.9, "selat lombok,lombok strait"),
        l("Selat Makassar", "Makassar Strait", -2.0, 118.0, "selat makassar,makassar strait"),
        l("Selat Malaka", "Malacca Strait", 3.5, 100.5, "selat malaka,malacca strait,strait of malacca"),
        l("Laut Sulawesi", "Celebes Sea", 3.0, 122.0, "laut sulawesi,celebes sea"),
        l("Laut Maluku", "Molucca Sea", 0.5, 126.5, "laut maluku,molucca sea"),
        l("Laut Timor", "Timor Sea", -11.5, 127.0, "laut timor,timor sea"),
        l("Laut Sawu", "Savu Sea", -9.8, 121.8, "laut sawu,savu sea"),
        l("Laut Andaman", "Andaman Sea", 10.0, 96.0, "laut andaman,andaman sea"),
        l("Teluk Jakarta", "Jakarta Bay", -6.05, 106.8, "teluk jakarta,jakarta bay"),
        l("Samudra Hindia selatan Jawa", "Indian Ocean south of Java", -10.0, 110.0, "samudra hindia selatan jawa,laut selatan,pantai selatan,selatan jawa,south of java"),
        l("Samudra Hindia", "Indian Ocean", -20.0, 80.0, "samudra hindia,indian ocean,samudera hindia"),
        l("Samudra Pasifik", "Pacific Ocean", 0.0, -140.0, "samudra pasifik,pacific ocean,samudera pasifik,laut pasifik"),
        l("Samudra Atlantik", "Atlantic Ocean", 30.0, -40.0, "samudra atlantik,atlantic ocean,samudera atlantik,laut atlantik"),
        l("Laut Merah", "Red Sea", 20.0, 38.0, "laut merah,red sea"),
        l("Laut Arab", "Arabian Sea", 15.0, 65.0, "laut arab,arabian sea"),
        l("Teluk Persia", "Persian Gulf", 27.0, 51.0, "teluk persia,teluk arab,persian gulf,arabian gulf"),
        l("Laut Tengah (Mediterania)", "Mediterranean Sea", 35.0, 18.0, "laut tengah,mediterania,mediterranean,laut mediterania"),
        l("Laut Utara", "North Sea", 56.0, 3.0, "laut utara,north sea"),
        l("Laut Jepang", "Sea of Japan", 40.0, 135.0, "laut jepang,sea of japan"),
        l("Laut Karibia", "Caribbean Sea", 15.0, -75.0, "laut karibia,caribbean"),
        l("Laut Hitam", "Black Sea", 43.0, 35.0, "laut hitam,black sea"),
        l("Laut Baltik", "Baltic Sea", 58.0, 20.0, "laut baltik,baltic sea"),
        l("Teluk Meksiko", "Gulf of Mexico", 25.0, -90.0, "teluk meksiko,gulf of mexico"),
        l("Selat Inggris", "English Channel", 50.0, -1.0, "selat inggris,english channel")
    )

    private fun token(u: String): List<String> =
        u.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private val kataLaut = setOf("laut", "ombak", "gelombang", "samudra", "samudera", "selat", "perairan", "maritim", "sea", "ocean", "wave", "waves", "swell", "surf", "marine", "teluk", "bay")
    private val kataTanyaLaut = setOf("ombak", "gelombang", "wave", "waves", "swell", "surf", "kondisi", "keadaan", "cuaca", "tinggi", "weather", "condition", "conditions", "maritim", "marine", "terkini", "bagaimana", "berombak", "tenang", "calm", "rough", "height", "perairan")
    private val kecuali = setOf("surah", "ayat", "tafsir", "hadits", "hadis", "doa", "sholat", "salat", "baterai", "battery", "gempa", "tsunami", "jam", "pukul", "gunung", "mount", "puncak", "quran", "alquran", "nabi", "musa", "firaun")

    fun cariLaut(ucapan: String): Laut? {
        val padded = " " + token(ucapan).joinToString(" ") + " "
        var best: Laut? = null; var panjang = 0
        for (x in daftar) for (k in x.kunci) if (padded.contains(" $k ") && k.length > panjang) { panjang = k.length; best = x }
        return best
    }

    /** Nama tempat (pantai/kota) setelah penanda seperti "di" atau "pantai"; null bila tidak ada. */
    fun namaTempat(ucapan: String): String? {
        val t = token(ucapan)
        val henti = setOf("hari", "ini", "sekarang", "besok", "lusa", "nanti", "pagi", "siang", "sore", "malam", "dini", "today", "tomorrow", "now", "tonight", "morning", "afternoon", "evening", "night", "bagaimana", "gimana", "apa", "berapa", "ya", "dong", "tolong", "dan", "atau", "yang", "pada", "saat", "ketika", "kah", "lagi", "seperti", "tinggi", "kondisi", "keadaan", "cuaca", "ombak", "gelombang", "is", "how", "what", "like", "at", "tinggi")
        for (i in t.indices) {
            if (t[i] in setOf("di", "in", "at", "pantai", "pelabuhan", "beach", "port", "sekitar", "dekat", "near", "off")) {
                val sisa = t.drop(i + (if (t[i] in setOf("pantai", "pelabuhan", "beach", "port")) 0 else 1))
                val k = sisa.takeWhile { it !in henti }.take(4)
                if (k.isNotEmpty() && k.none { it in kataLaut } || (k.isNotEmpty() && t[i] in setOf("pantai", "pelabuhan", "beach", "port"))) return k.joinToString(" ")
            }
        }
        return null
    }

    fun permintaan(ucapan: String): Boolean {
        val t = token(ucapan)
        if (t.isEmpty() || t.size > 20) return false
        if (t.any { it in kecuali }) return false
        if (t.none { it in kataLaut }) return false
        if (t.none { it in kataTanyaLaut }) return false
        return cariLaut(ucapan) != null || namaTempat(ucapan) != null || t.any { it in setOf("ombak", "gelombang", "wave", "waves", "swell") }
    }

    private val awalB = intArrayOf(0, 5, 11, 15, 18)
    private val akhirB = intArrayOf(5, 11, 15, 18, 24)
    private fun namaB(b: Int, eng: Boolean) = if (eng) arrayOf("early morning", "morning", "afternoon", "evening", "night")[b] else arrayOf("dini hari", "pagi", "siang", "sore", "malam")[b] // data kata, bukan teks tampilan: contains(

    private fun kategori(h: Double, eng: Boolean): String = when {
        h < 0.5 -> tr("tenang", "calm", eng)
        h < 1.25 -> tr("rendah", "slight", eng)
        h < 2.5 -> tr("sedang", "moderate", eng)
        h < 4.0 -> tr("tinggi", "rough", eng)
        h < 6.0 -> tr("sangat tinggi", "very rough", eng)
        else -> tr("ekstrem", "extreme", eng)
    }

    private fun arah(d: Double, eng: Boolean): String {
        val id = arrayOf("utara", "timur laut", "timur", "tenggara", "selatan", "barat daya", "barat", "barat laut")
        val en = arrayOf("north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest")
        val i = (Math.round(((d % 360 + 360) % 360) / 45.0).toInt()) % 8
        return if (eng) en[i] else id[i]
    }

    private fun angka(x: Double, eng: Boolean): String { val s = String.format(Locale.US, "%.1f", x); return if (eng) s else s.replace('.', ',') }

    private fun doubles(a: org.json.JSONArray?): List<Double> = if (a == null) emptyList() else (0 until a.length()).map { if (a.isNull(it)) Double.NaN else a.optDouble(it, Double.NaN) }
    private fun strs(a: org.json.JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it, "") }

    private fun saran(h: Double, eng: Boolean): String = when {
        h >= 4.0 -> tr(" Gelombang setinggi ini berbahaya bagi perahu kecil dan kapal nelayan; hindari berlayar dan menjauh dari bibir pantai.", " Waves this high are dangerous for small boats and fishing vessels; avoid sailing and stay away from the shoreline.", eng)
        h >= 2.5 -> tr(" Gelombang tinggi; berbahaya bagi perahu kecil dan tongkang. Berhati-hatilah di pantai.", " Rough seas; dangerous for small boats and barges. Take care at the beach.", eng)
        h >= 1.25 -> tr(" Gelombang sedang; perahu kecil perlu waspada.", " Moderate seas; small boats should be careful.", eng)
        else -> ""
    }

    /** Jawaban kondisi laut; berjalan di thread latar. [ctx] dipakai untuk pencarian nama tempat. */
    fun jawab(ctx: android.content.Context, ucapanSemua: List<String>, eng: Boolean, minta: InfoCuaca.Permintaan): String {
        var nama: String; var lat: Double; var lon: Double
        val laut = ucapanSemua.firstNotNullOfOrNull { cariLaut(it) }
        var dariTempat = false
        if (laut != null) { nama = if (eng) laut.namaEn else laut.namaId; lat = laut.lat; lon = laut.lon }
        else {
            val n = ucapanSemua.firstNotNullOfOrNull { namaTempat(it) }
                ?: return tr("Laut atau pantai mana yang Anda maksud? Contoh: ombak di Selat Bali besok pagi.", "Which sea or beach do you mean? Example: waves in the Bali Strait tomorrow morning.", eng)
            val tp = try { TempatDisebut.cari(ctx, n, eng) } catch (_: Exception) { null }
                ?: return tr("Tempat bernama " + n + " tidak ditemukan. Sebutkan nama laut, selat, atau pantai yang lebih jelas.", "A place named " + n + " was not found. Say a clearer sea, strait, or beach name.", eng)
            nama = tp.nama; lat = tp.lat; lon = tp.lon; dariTempat = true
        }
        val url = "https://marine-api.open-meteo.com/v1/marine?latitude=" + String.format(Locale.US, "%.3f", lat) + "&longitude=" + String.format(Locale.US, "%.3f", lon) +
            "&current=wave_height,wave_direction,wave_period,swell_wave_height&hourly=wave_height,wave_direction,wave_period,swell_wave_height&forecast_days=3&timezone=auto"
        val js = try { JSONObject(OpenMeteo.ambilTeks(url)) } catch (_: Exception) { null }
            ?: return tr("Data gelombang untuk " + nama + " belum dapat diambil. Periksa koneksi internet, lalu coba lagi.", "Wave data for " + nama + " could not be fetched. Check your internet connection and try again.", eng)
        val cur = js.optJSONObject("current")
        val per = js.optJSONObject("hourly")
        val jam = strs(per?.optJSONArray("time")); val tinggi = doubles(per?.optJSONArray("wave_height"))
        val arahH = doubles(per?.optJSONArray("wave_direction")); val periode = doubles(per?.optJSONArray("wave_period")); val swellH = doubles(per?.optJSONArray("swell_wave_height"))
        if (tinggi.none { it.isFinite() } && !(cur?.optDouble("wave_height", Double.NaN)?.isFinite() ?: false))
            return tr("Tidak ada data gelombang laut di sekitar " + nama + ". Kemungkinan lokasinya di daratan atau terlalu jauh dari laut terbuka.", "There is no ocean wave data near " + nama + ". The place may be inland or too far from open sea.", eng)
        val sb = StringBuilder()
        sb.append(tr("Kondisi laut di " + nama + ". ", "Sea conditions at " + nama + ". ", eng))
        fun satu(h: Double, a: Double, p: Double, sw: Double): String {
            val x = StringBuilder(tr("tinggi gelombang " + angka(h, false) + " meter, kategori " + kategori(h, false), "wave height " + angka(h, true) + " meters, " + kategori(h, true) + " seas", eng).let { if (eng) it else it })
            if (a.isFinite()) x.append(tr(", datang dari arah " + arah(a, false), ", coming from the " + arah(a, true), eng))
            if (p.isFinite()) x.append(tr(", periode " + angka(p, false) + " detik", ", period " + angka(p, true) + " seconds", eng))
            if (sw.isFinite() && sw >= 0.3) x.append(tr(", gelombang swell " + angka(sw, false) + " meter", ", swell " + angka(sw, true) + " meters", eng))
            return x.toString()
        }
        val tanggalSkrg = cur?.optString("time", "")?.take(10).orEmpty()
        val jamSkrg = cur?.optString("time", "")?.substringAfter('T', "")?.take(2)?.toIntOrNull() ?: 0
        val hariKe = minta.hari.coerceIn(0, 2)
        val tanggal = (jam.map { it.take(10) }.distinct().getOrNull(hariKe)) ?: tanggalSkrg
        if (minta.bagian < 0 && !minta.rinci && hariKe == 0 && cur != null && cur.optDouble("wave_height", Double.NaN).isFinite()) {
            val h = cur.optDouble("wave_height")
            sb.append(tr("Saat ini ", "Right now ", eng)).append(satu(h, cur.optDouble("wave_direction", Double.NaN), cur.optDouble("wave_period", Double.NaN), cur.optDouble("swell_wave_height", Double.NaN))).append('.')
            val ke = jam.indices.filter { jam[it].startsWith(tanggal) && (jam[it].substringAfter('T').take(2).toIntOrNull() ?: -1) in jamSkrg until minOf(jamSkrg + 12, 24) }.mapNotNull { tinggi.getOrNull(it) }.filter { it.isFinite() }
            if (ke.isNotEmpty()) sb.append(tr(" Dalam 12 jam ke depan tinggi gelombang berkisar " + angka(ke.min(), false) + " sampai " + angka(ke.max(), false) + " meter.", " Over the next 12 hours wave height ranges from " + angka(ke.min(), true) + " to " + angka(ke.max(), true) + " meters.", eng))
            sb.append(saran(maxOf(h, ke.maxOrNull() ?: 0.0), eng))
        } else {
            val bagian = if (minta.bagian >= 0) listOf(minta.bagian) else (0..4).toList()
            var ada = false
            for (b in bagian) {
                val dari = if (hariKe == 0) maxOf(awalB[b], jamSkrg) else awalB[b]
                if (hariKe == 0 && akhirB[b] <= jamSkrg) { if (minta.bagian >= 0) sb.append(tr("Bagian " + namaB(b, false) + " hari ini sudah lewat. ", "The " + namaB(b, true) + " part of today has already passed. ", eng)); continue }
                val idx = jam.indices.filter { jam[it].startsWith(tanggal) && (jam[it].substringAfter('T').take(2).toIntOrNull() ?: -1) in dari until akhirB[b] }
                val hs = idx.mapNotNull { tinggi.getOrNull(it) }.filter { it.isFinite() }
                if (hs.isEmpty()) continue
                ada = true
                val mx = hs.max()
                val i = idx.maxByOrNull { tinggi.getOrNull(it) ?: -1.0 } ?: idx[0]
                sb.append(namaB(b, eng).replaceFirstChar { it.uppercase() }).append(tr(" pukul ", " from ", eng)).append(String.format("%02d", dari)).append(tr(" sampai ", " to ", eng)).append(String.format("%02d", akhirB[b])).append(": ")
                sb.append(tr("tinggi gelombang " + angka(hs.min(), false) + " sampai " + angka(mx, false) + " meter, kategori " + kategori(mx, false), "wave height " + angka(hs.min(), true) + " to " + angka(mx, true) + " meters, " + kategori(mx, true) + " seas", eng))
                val p = periode.getOrNull(i) ?: Double.NaN; val a = arahH.getOrNull(i) ?: Double.NaN
                if (a.isFinite()) sb.append(tr(", dari arah " + arah(a, false), ", from the " + arah(a, true), eng))
                if (p.isFinite()) sb.append(tr(", periode " + angka(p, false) + " detik", ", period " + angka(p, true) + " seconds", eng))
                sb.append(". ")
                if (b == bagian.last() || minta.bagian >= 0) sb.append(saran(mx, eng).trimStart().let { if (it.isNotEmpty()) "$it " else "" })
            }
            if (!ada) sb.append(tr("Data gelombang untuk waktu itu belum tersedia.", "Wave data for that time is not available.", eng))
            else sb.append(tr("Waktu mengikuti waktu setempat. ", "Times follow local time. ", eng))
        }
        sb.append(' ').append(tr("Ini prakiraan model gelombang, bukan peringatan resmi pelayaran, dan resolusinya kasar di dekat pantai. Untuk berlayar, periksa prakiraan maritim BMKG atau otoritas pelayaran setempat.", "This is a wave-model forecast, not an official shipping warning, and its resolution is coarse near the coast. Before sailing, check the BMKG maritime forecast or the local maritime authority.", eng))
        if (dariTempat) sb.append(' ').append(tr("Data diambil dari titik laut terdekat dari tempat itu.", "Data is taken from the nearest sea point to that place.", eng))
        return sb.toString()
    }
}
