# FIX316 (belum dikompilasi dengan Gradle / belum diuji di perangkat)
- Rentang juz: "putar juz 1 sampai juz 5" (Perintah.juzAkhir, PenafsirQuran.rentangJuzAtauRentang, indeks audio lokal ikut rentang). Juz tunggal/berikutnya/sebelumnya sudah ada.
- Jeda/lanjut: dikenali pada kalimat lebih panjang bila menyebut audio/Quran; "hentikan sementara"; tidak lagi menimpa "putar juz berikutnya"/"lanjutkan juz 3".
- Perintah ganda: "buka WhatsApp/WA Business/Telegram dan hubungi/telepon/kirim pesan ke X" (PerintahSuaraActivity.perintahGanda). WA: panggilan suara/video via alur yang sudah ada; chat: wa.me; Telegram: tg://resolve?phone= (hanya buka obrolan).
- Petunjuk ID 86 / EN 83. Tes: tools/uji_fix316_juz_dan_perintah_ganda.py
- Batasan: perintah ganda hanya pola buka-aplikasi + hubungi/pesan; kombinasi lain (mis. buka X lalu buka Y) belum. Nomor 0xxx diubah ke 62xxx (asumsi Indonesia). Telegram butuh nomor kontak yang terdaftar di Telegram.

## FIX317 - jeda/lanjut saat Al-Qur'an berbunyi
- PemutarQuranService: ACTION_JEDA membersihkan dijedaOlehFokus (sebelumnya fokus audio yang kembali setelah mikrofon ditutup melanjutkan audio sendiri); pesan singkat jeda/lanjut.
- KhatamActivity.kendaliLatar: jeda hanya dianggap ditangani Khatam bila Khatam sedang berbunyi/dijeda mikrofon; selain itu diteruskan ke pemutar latar belakang. Pesan jeda/lanjut.
- Petunjuk ID 87 / EN 84.
