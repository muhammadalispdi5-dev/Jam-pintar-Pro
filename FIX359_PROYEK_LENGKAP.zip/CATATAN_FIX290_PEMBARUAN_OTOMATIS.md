# FIX290 – Pembaruan otomatis (mengikuti alur Apktool M)

Temuan dari APK Apktool M 2.4.0 (analisis kelas pembaruannya): (1) ambil JSON `updates/update_<bahasa>.json?t=<waktu>` dari repositori GitHub tanpa cache; (2) bandingkan `build` dengan versi terpasang, abaikan bila sama atau sudah dilewati (`update_skip`); (3) dialog berisi nama, tanggal, ukuran, `changes` per bahasa dengan cadangan "en"; (4) pilihan unduh APK sesuai arsitektur CPU (arm64-v8a, armeabi-v7a, x86, x86_64) lewat DownloadManager (MIME APK, User-Agent sendiri), pilihan buka GitHub/Telegram, atau lewati; (5) pada unduhan selesai, APK dipasang; (6) saklar pembaruan otomatis dengan `update_last_time`.

Kondisi sebelum perbaikan: UpdateManager (periksa/unduh/pasang) sudah ada, tetapi tidak pernah dipanggil; tombol hanya membuka Telegram.

Yang diterapkan:
- MainActivity: saklar "Periksa pembaruan otomatis" (12 jam), tombol "Periksa pembaruan" (dan perintah suara), dialog dengan Unduh dan pasang / Nanti / Lewati versi ini, cadangan ke kanal Telegram bila sumber gagal.
- UpdateManager: penanda waktu anti-cache, kunci JSON alternatif (build/name/url/changes/date/size), APK per arsitektur CPU, catatan per bahasa, lewati versi, rilis GitHub memilih APK sesuai arsitektur.
- Petunjuk ID 62 / EN 59. Uji: tools/uji_pembaruan_otomatis.py.

Pengembang: isi `AppKonfigurasi.URL_INFO_UPDATE` dengan alamat JSON HTTPS, mis.
{"versionCode":90,"versionName":"1.0.90","apkUrl":{"arm64-v8a":"https://.../JamPintarPro-arm64.apk","default":"https://.../JamPintarPro.apk"},"catatan":{"id":"...","en":"..."},"tanggal":"2026-11-15","ukuran":"28 MB"}
Tanpa itu, dipakai rilis terbaru GitHub (BuildConfig.GITHUB_REPO). APK baru wajib ditandatangani dengan kunci yang sama.

## FIX291 – disamakan dengan pola Apktool M
Sumber utama kini updates/update_<bahasa>.json di repositori GitHub (raw.githubusercontent.com/<repo>/main/), bahasa aplikasi lebih dulu lalu "en", dengan ?t=; APK bawaan files/JamPintarPro.apk bila JSON tidak memuat apkUrl; cadangan terakhir rilis GitHub (releases/latest). Lihat PANDUAN_PEMBARUAN_GITHUB.md dan CONTOH_REPOSITORI_PEMBARUAN/.
