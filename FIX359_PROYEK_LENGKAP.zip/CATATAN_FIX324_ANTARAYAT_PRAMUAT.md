# FIX324
- Gema tanpa ekor di antarayat (service dan Khatam); Khatam menyiapkan ayat berikutnya lebih dulu (pramuatKh) untuk mode berurutan/juz/halaman/rentang. Petunjuk ID 94 / EN 91.
