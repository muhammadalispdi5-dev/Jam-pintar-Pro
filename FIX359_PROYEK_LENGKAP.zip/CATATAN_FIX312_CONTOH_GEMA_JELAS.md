# FIX312 - Contoh gema mencerminkan pilihan
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
- ContohGema: menyebut nama efek terpilih + kalimat + "Halo, halo, halo."; menunggu berkas TTS stabil sebelum DSP; memeriksa bahwa berkas benar-benar bertambah (ekor gema); peringatan jika kekuatan 0% atau DSP gagal.
- GemaDsp: mendukung WAV float 32-bit selain PCM 16-bit.
- Petunjuk ID 82 / EN 79.
