# FIX301 - Info jaringan mencakup SIM 1 dan SIM 2
- Sebab: laporanSinyal hanya memakai TelephonyManager bawaan (satu SIM). Kini laporanSeluler memakai SubscriptionManager.activeSubscriptionInfoList; tiap langganan dibaca lewat createForSubscriptionId: operator, generasi 2G-5G, level dan dBm sinyal, roaming.
- Bila ada dua SIM aktif, disebutkan juga SIM mana yang dipakai untuk data seluler (getDefaultDataSubscriptionId) dan status data; slot kosong disebut.
- Tanpa izin telepon atau daftar kosong: kembali ke laporan SIM bawaan.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat. Petunjuk ID 66 / EN 63 diperbarui.
