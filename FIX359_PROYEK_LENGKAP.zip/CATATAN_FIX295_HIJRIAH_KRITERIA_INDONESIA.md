# FIX295 - Kriteria Hijriah Indonesia (MABIMS/Kemenag) + sinkron saat aplikasi dibuka
- Baru: HijriImkanur.kt, hitung awal bulan lokal (tinggi hilal >= 3 derajat, elongasi >= 6,4 derajat saat magrib acuan Banda Aceh, jika tidak digenapkan 30 hari). Jangkar 1 Muharram 1447 = 27 Jun 2025.
- Urutan: HijriahResmi (JSON isbat) -> HijriImkanur (jika kriteria = Indonesia) -> AlAdhan/ICU.
- Prefs.kalenderHijriKriteria (0 Indonesia bawaan, 1 Umm al-Qura/daring); pilihan di Kalender.
- MainActivity.onResume menyinkronkan tanggal Hijriah (diadopsi dari berkas lampiran).
- Termasuk perbaikan kompilasi FIX294 (BatteryTalkService this@BatteryTalkService).
- Perhitungan adalah estimasi; ketetapan sidang isbat lewat updates/hijriah_resmi.json selalu menang.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat. Petunjuk ID 64 / EN 61.
