# FIX323
- Jeda antarayat (layanan perintah suara): pramuat ayat berikutnya kini juga untuk berkas offline dan keluaran Mono. Petunjuk ID 93 / EN 90.
