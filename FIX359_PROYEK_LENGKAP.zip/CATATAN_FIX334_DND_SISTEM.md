# FIX334 (versi 1.0.91)
DndSistem: suara tidak esensial (baterai/jam, Khatam, Hafalan, pemanggil) senyap saat filter Jangan Ganggu perangkat aktif. Alarm/azan/timer, tombol volume, dan telungkup tidak terpengaruh. Belum dikompilasi / diuji di perangkat.
