# FIX327
- Notifikasi salat berlalu: 30 menit (setTimeoutAfter), diutamakan atas hitung mundur salat berikutnya; awal mengikuti menit pengingat.
- Azan ganda: dedupe 20 menit di PrayerAlarmReceiver (sudahDipicu) dan PrayerAlarmService.
- Jeda ayat: sesi audio bersama, efek setelah start, serah terima awal, PemutarMono.posisiMs. Penyebab pasti belum terbukti; belum diukur di perangkat.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
