FIX358 (belum dikompilasi dengan Gradle / belum diuji di perangkat)
- DND salat Jumat: saklar dan durasi sendiri (15-120 menit, bawaan 45); dipakai pada Dzuhur hari Jumat (PrayerAlarm penjadwalan + PrayerAlarmReceiver).
- Pengingat sahur: 15..120 menit sebelum Imsak (PrayerPrefs.PILIHAN_SAHUR_MENIT).
- LautDunia: 9 lintas penyeberangan Indonesia + jawabBanyak (semua lintas bila hanya "penyeberangan"), angin ikut disebut; tanganiFakta tidak lagi mencegat pertanyaan gunung/laut; batas panjang ucapan gunung 40 kata.
