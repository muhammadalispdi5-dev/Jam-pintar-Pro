# FIX296 - Jawaban lokasi asisten lebih cepat, tetap akurat
- Sebab lambat: ambilLokasiUntukCuaca(akurat) menunggu akurasi 3 m (hampir tak tercapai) hingga 35 detik.
- Kini: cache segar (<=30 dtk) dan <=15 m langsung dipakai; fix GPS <=10 m langsung; <=25 m setelah 3 sampel; pada 9 dtk hasil terbaik <=150 m dipakai (dirata-rata bila wajar); batas keras 25 dtk. Ketelitian tetap diucapkan jujur.
- Berlaku juga untuk perintah perbarui lokasi sholat. Petunjuk ID 65 / EN 62. Tes: tools/uji_lokasi_cepat.py.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
