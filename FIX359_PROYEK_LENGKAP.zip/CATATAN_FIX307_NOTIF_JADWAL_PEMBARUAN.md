FIX307 (versi 1.0.90 / build 90): pesan 'versi terbaru sudah terpasang' pada cek manual; pemasangan lanjut otomatis setelah izin; notifikasi jadwal salat (JadwalNotifikasi.kt, saklar di Pengaturan Jadwal Sholat); petunjuk ID 75-76 / EN 72-73. Tes: tools/uji_jadwal_notifikasi.py. Belum dikompilasi/diuji di perangkat.

Tambahan: 6 pemeriksa lama diperbarui agar sesuai kode saat ini (uji_bmkg, uji_mikrofon_perintah_suara, uji_putar_tanpa_layar, uji_volume_dan_efek_audio_mandiri, verify_final, verify_project); pemeriksaan workflow dilewati bila folder .github tidak ada. Kode aplikasi tidak diubah untuk ini.

Revisi: notifikasi hanya menampilkan salat terdekat — muncul sebanyak menit pengingat sebelum salat (advanceMinutes: 5/10/15/30), hitung mundur, lalu 30 menit sesudah waktu tiba (hitung maju), lalu hilang.
Tambahan: waktu matahari terbit tampil tepat saat terbit selama 15 menit (PASCA_TERBIT_MENIT).
