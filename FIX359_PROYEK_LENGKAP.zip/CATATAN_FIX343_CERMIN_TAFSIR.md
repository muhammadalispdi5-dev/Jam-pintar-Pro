FIX343: tambah 5 cermin unduhan tafsir (github raw, statically, jsdelivr fastly/gcore), pesan galat per-server, perbaiki teks 'HTTP kode'. Belum dikompilasi/diuji.
