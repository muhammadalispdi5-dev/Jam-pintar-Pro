# FIX331
- Tarhim: pilihan menit 0 = otomatis (durasi + 45 dtk), bawaan; pengingat sebelum salat tidak memotong Tarhim (flag tarhim_hingga). Dugaan penyebab terpotong: pengingat sebelum salat 10 menit bertabrakan dengan Tarhim 10 menit; belum terbukti di perangkat.
- Tombol volume: gerbang saklar utama FIX328 dipindah ke setelah pembungkaman suara (regresi dari FIX328).
- Perintah "putar surah X ayat Y dengan terjemahan suara TTS": TerjemahTts.pisahPerintah + terjemahTtsPaksa di PemutarQuranService; teks diunduh bila belum ada.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
