FIX349: Kemenag dipindah ke urutan pertama (pilihan tersimpan 0 kini = Kemenag ringkas); Jalalayn Indonesia diberi label belum ada sumber unduhan. Belum dikompilasi/diuji.
