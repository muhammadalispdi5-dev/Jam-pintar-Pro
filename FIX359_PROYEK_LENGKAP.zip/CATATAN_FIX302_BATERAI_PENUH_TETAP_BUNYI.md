# FIX302 - Alarm baterai penuh tetap berbunyi walau di-stop
- Sebab: pasangBungkam (telungkup/stop) pada BatteryTalkService menolkan penuhUlangSisa, menaikkan token, dan membatalkan alarm ulang, sehingga satu kali stop membatalkan semua pengulangan (bahkan stop pengumuman jam ikut membatalkannya).
- Kini stop hanya menghentikan suara yang sedang berbunyi. Pengulangan berlanjut sesuai Jumlah (1/3/5/10/20) dan Jeda yang diatur, selama pengisi daya tersambung. Berhenti bila dicabut, jumlah habis, pengulangan dimatikan, atau layanan dihentikan.
- Setiap pengulangan memasang pasangBungkam sendiri sehingga masing-masing bisa dihentikan.
- Tes: tools/uji_baterai_tetap_bunyi.py; uji_baterai_ulang.py disesuaikan. Petunjuk ID 70 / EN 67.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
