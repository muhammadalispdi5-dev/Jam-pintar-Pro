# FIX299
1. "Buka pengaturan Bluetooth/Wi-Fi/hotspot/data seluler/mode pesawat/lokasi/NFC/TalkBack": Jenis baru BUKA_PENGATURAN_PERANGKAT, membuka halaman pengaturan saja tanpa menekan sakelar (PerintahSuara.pengaturanPerangkat, bukaHalamanPengaturan). Pengaturan milik fitur aplikasi (sholat, jam, baterai, suara...) tidak dibajak; "lokasi" butuh kata perangkat/gps/hp. Perintah nyalakan/matikan tetap ada.
2. Tanggal Hijriah dan Masehi kemarin/besok/lusa (PerintahSuara.geserHari + bacakanKhusus(geser)); kemarin dan besok sekaligus dibacakan keduanya; label mengikuti bahasa aplikasi.
3. Azan berkas mandiri terpotong: PrayerAlarmService.playSound memutus paksa pada 180 dtk untuk berkas pilihan pengguna. Kini pemutus pengaman = durasi berkas + 15 dtk (maks 90 mnt; 30 mnt bila durasi tak terbaca); lanjut tes setelah jeda memakai sisa durasi (sisaPutar). Pemutaran tetap berhenti oleh onCompletion.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat. Petunjuk ID 68 / EN 65.
