# FIX326
- Seluruh Al-Qur'an: pilihan audio per surah (114 berkas) atau per ayat (6236, bawaan) lewat ucapan. Petunjuk ID 96 / EN 93.
