# FIX315 (belum dikompilasi dengan Gradle / belum diuji di perangkat)
- Pudar akhir gema: PemutarMono (azan, pengingat, murattal Khatam) ekor memudar cosinus; pengumuman TTS sudah (FIX314).
- Tarhim: PrayerPrefs.tarhimBerkas; UI pilih/kembalikan per salat; PrayerAlarmService memutar berkas bila terbaca.
- Asisten: mode online ("online/daring/streaming") di PemutarQuranService, melengkapi mode offline yang sudah ada.
- Unduhan Khatam (teks & audio): dialog kustom dengan Batalkan + konfirmasi, kemajuan persen diumumkan tiap 5%.
- Unduh per juz: tandai banyak juz / tandai semua.
- Petunjuk ID 85 / EN 82. Tes: tools/uji_fix315_unduh_tarhim_pudar.py
- Batasan: pembatalan menjaga berkas yang sudah selesai; unduhan di Asmaul Husna/layar lain tidak diubah; azan berkas lewat jalur MediaPlayer cadangan tidak memudar.
