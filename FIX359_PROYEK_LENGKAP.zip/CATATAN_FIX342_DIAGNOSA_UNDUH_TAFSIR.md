# FIX342
Unduhan tafsir 0 dari 114 tanpa hasil: penyebab sebenarnya belum diketahui (nama kitab dan alamat sudah cocok dengan dokumentasi repo spa5k/tafsir_api, bentuk JSON tidak bisa diperiksa dari sini).
Perubahan: ikuti pengalihan HTTP, User-Agent browser, timeout lebih longgar, pembaca JSON lebih longgar (ambil string terpanjang bila kunci teks tak dikenal), berhenti setelah 4 kegagalan beruntun dan menampilkan dialog berisi penyebab (kode HTTP / jenis galat / potongan format data), status diperbarui tiap surah.
Belum dikompilasi dengan Gradle / belum diuji di perangkat.
