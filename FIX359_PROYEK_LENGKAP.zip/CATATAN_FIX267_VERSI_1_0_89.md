# FIX267 - Versi 1.0.89 dan kelengkapan petunjuk
- Versi dinaikkan 1.0.88/88 -> 1.0.89/89 (app/build.gradle.kts, User-Agent jaringan, README, pemeriksa tools/*).
- Petunjuk penggunaan (ID butir 37-48, EN 34-45) diperiksa: informasi perangkat, lokasi rinci, cuaca tempat lain/bagian hari, waktu sholat tertentu, ayat+terjemah terpisah, penghentian pembacaan dan pengumuman, azan bawaan, volume Nama Panggilan (kelompok volume), berkas audio sendiri baterai/jam, Tarhim sebelum sholat. Ditambah butir ringkasan "Yang baru di versi 1.0.89" (ID 48 / EN 45).
- Teks mengikuti bahasa aktif (strings.xml ID dan values-en).
Belum dikompilasi dengan Gradle, belum diuji di perangkat.
