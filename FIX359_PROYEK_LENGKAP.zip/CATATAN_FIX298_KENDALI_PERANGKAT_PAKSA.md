# FIX298 - Kendali Wi-Fi/Bluetooth/data/pesawat/lokasi/NFC lebih memaksa
- Gejala: asisten hanya membuka Pengaturan lalu berhenti di posisi paling atas. Sebab: layanan aksesibilitas tidak pernah menggulir; bila sakelar tidak terlihat ia hanya menunggu sampai batas waktu 25 dtk. targetSdk 36 sehingga API langsung (setWifiEnabled, BluetoothAdapter.enable) tidak berlaku.
- Jalur baru (PerintahSuaraActivity.paksaLangsung): cek status (sudah sesuai -> katakan saja); lokasi lewat WRITE_SECURE_SETTINGS; akses root (su -c svc wifi/bluetooth/data/nfc, cmd connectivity airplane-mode, cmd location) dengan verifikasi status.
- Bila tidak bisa: layar Pengaturan + layanan aksesibilitas, yang kini menggulir daftar (gulir 2-7), lalu membuka halaman alternatif (intentCadangan) setelah 11 siklus, batas waktu 45 dtk.
- WRITE_SECURE_SETTINGS (adb shell pm grant com.novan.bateraibicara android.permission.WRITE_SECURE_SETTINGS) membuat layanan aksesibilitas menyala sendiri.
- Batas jujur: tanpa root dan tanpa layanan aksesibilitas, Android 10+ tidak mengizinkan aplikasi biasa menyalakan Wi-Fi/Bluetooth/data. Belum dikompilasi dengan Gradle / belum diuji di perangkat. Petunjuk ID 67 / EN 64.
- FIX298b: perbaikan kompilasi laporanSinyal (info.linkSpeed, ssid tanpa literal karakter petik).
