package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper

/**
 * FIX293: lokasi jadwal salat mengikuti perpindahan pengguna selama izin lokasi diberikan dan layanan lokasi perangkat menyala.
 * Memakai lokasi terakhir yang diketahui sistem (hemat baterai); bila tidak ada yang cukup baru, meminta satu pembaruan singkat.
 * Bila posisi baru berjarak minimal [JARAK_MIN_M] dari lokasi tersimpan, lokasi, nama tempat, jadwal salat, dan alarm diperbarui otomatis.
 * Dipanggil dari layar utama, layar jadwal salat, layanan latar (tiap beberapa menit), dan saat zona waktu berubah.
 * Di latar belakang Android 10+ hanya bekerja bila izin lokasi "Sepanjang waktu" diberikan; tanpa itu pembaruan terjadi saat aplikasi dibuka.
 */
object LokasiOtomatis {
    private const val PREF = "lokasi_otomatis"
    private const val JEDA_MS = 10L * 60 * 1000
    private const val USIA_MAKS_MS = 3L * 60 * 60 * 1000
    private const val JARAK_MIN_M = 5_000f
    private const val AKURASI_MAKS_M = 10_000f
    @Volatile private var berjalan = false

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun adaIzin(c: Context): Boolean =
        c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun izinLatarBelakang(c: Context): Boolean =
        Build.VERSION.SDK_INT < 29 || c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun layananMenyala(lm: LocationManager): Boolean = try {
        lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
    } catch (_: Exception) { false }

    /** [selesai](true) di thread utama bila lokasi berubah dan jadwal diperbarui. */
    fun periksa(c: Context, paksa: Boolean = false, selesai: ((Boolean) -> Unit)? = null) {
        val app = c.applicationContext
        val pp = PrayerPrefs(app)
        if (!pp.ikutiLokasi || !pp.enabled || !adaIzin(app)) { selesai?.invoke(false); return }
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm == null || !layananMenyala(lm)) { selesai?.invoke(false); return }
        val s = sp(app)
        val kini = System.currentTimeMillis()
        if (!paksa && kini - s.getLong("percobaan", 0L) < JEDA_MS) { selesai?.invoke(false); return }
        synchronized(this) { if (berjalan) { selesai?.invoke(false); return }; berjalan = true }
        s.edit().putLong("percobaan", kini).apply()
        val main = Handler(Looper.getMainLooper())
        val akhir: (Location?) -> Unit = { lokasi ->
            main.post {
                var berubah = false
                try { if (lokasi != null) berubah = terapkan(app, pp, lokasi) } catch (_: Exception) { }
                synchronized(this) { berjalan = false }
                selesai?.invoke(berubah)
            }
        }
        val terakhir = terbaruTersimpan(lm)
        if (terakhir != null) { akhir(terakhir); return }
        mintaSekali(lm, main, akhir)
    }

    private fun terbaruTersimpan(lm: LocationManager): Location? {
        var terbaik: Location? = null
        val sekarang = System.currentTimeMillis()
        val daftar = try { lm.getProviders(true) } catch (_: Exception) { emptyList<String>() }
        for (p in daftar) {
            val l = try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } catch (_: Exception) { null } ?: continue
            if (sekarang - l.time > USIA_MAKS_MS) continue
            if (l.hasAccuracy() && l.accuracy > AKURASI_MAKS_M) continue
            if (terbaik == null || l.time > terbaik.time) terbaik = l
        }
        return terbaik
    }

    @Suppress("DEPRECATION")
    private fun mintaSekali(lm: LocationManager, main: Handler, akhir: (Location?) -> Unit) {
        val penyedia = when {
            try { lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { false } -> LocationManager.NETWORK_PROVIDER
            try { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (_: Exception) { false } -> LocationManager.GPS_PROVIDER
            else -> { akhir(null); return }
        }
        var selesaiSekali = false
        val tutup: (Location?) -> Unit = { l -> if (!selesaiSekali) { selesaiSekali = true; akhir(l) } }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val batal = CancellationSignal()
                main.postDelayed({ if (!selesaiSekali) { try { batal.cancel() } catch (_: Exception) { }; tutup(null) } }, 25_000L)
                lm.getCurrentLocation(penyedia, batal, java.util.concurrent.Executor { r -> main.post(r) }) { l -> tutup(l) }
            } else {
                val dengar = object : LocationListener {
                    override fun onLocationChanged(l: Location) { try { lm.removeUpdates(this) } catch (_: Exception) { }; tutup(l) }
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                    @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
                }
                lm.requestSingleUpdate(penyedia, dengar, Looper.getMainLooper())
                main.postDelayed({ if (!selesaiSekali) { try { lm.removeUpdates(dengar) } catch (_: Exception) { }; tutup(null) } }, 25_000L)
            }
        } catch (_: Exception) { tutup(null) }
    }

    /** True bila lokasi tersimpan diubah. */
    private fun terapkan(app: Context, pp: PrayerPrefs, l: Location): Boolean {
        if (l.hasAccuracy() && l.accuracy > AKURASI_MAKS_M) return false
        val jarak = if (pp.locationSet) FloatArray(1).also { Location.distanceBetween(pp.lat, pp.lon, l.latitude, l.longitude, it) }[0] else Float.MAX_VALUE
        if (jarak < JARAK_MIN_M) return false
        pp.lat = l.latitude; pp.lon = l.longitude
        pp.place = if (l.provider == LocationManager.GPS_PROVIDER) "Lokasi GPS" else "Lokasi jaringan"
        pp.locationSet = true
        sp(app).edit().putLong("pindah_terakhir", System.currentTimeMillis()).apply()
        PrayerAlarm.scheduleAll(app)
        if (pp.autoOnline) PrayerOnlineTimes.sync(app) { _, _ -> PrayerAlarm.scheduleAll(app) }
        NamaLokasi.perbaruiAsinkron(app, pp) { }
        return true
    }
}
