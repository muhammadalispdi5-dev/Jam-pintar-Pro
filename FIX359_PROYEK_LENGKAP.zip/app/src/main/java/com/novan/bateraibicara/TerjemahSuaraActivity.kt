package com.novan.bateraibicara

/** FIX329: saklar dan suara TTS untuk pembacaan terjemahan Al-Qur'an sesudah tiap ayat. */
class TerjemahSuaraActivity : Halaman() {
    override val judulHalaman = R.string.judul_terjemah_suara

    override fun bangun() {
        info(getString(R.string.info_terjemah_suara))
        saklar(getString(R.string.sw_terjemah_suara), TerjemahTts.aktif(this)) { TerjemahTts.setAktif(this, it) }
        blokSuara(TerjemahTts.PROFIL) { tr("Dengan menyebut nama Allah Yang Maha Pengasih lagi Maha Penyayang", "In the name of Allah, the Most Gracious, the Most Merciful") }
    }
}
