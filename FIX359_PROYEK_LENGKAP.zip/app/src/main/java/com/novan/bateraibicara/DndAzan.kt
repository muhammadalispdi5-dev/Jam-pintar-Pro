package com.novan.bateraibicara

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.os.Build

/**
 * FIX306: Mode Jangan Ganggu saat salat tetap berjalan, tetapi suara azan tidak ikut dibisukan.
 * Tidak bergantung pada fitur "pengecualian aplikasi" milik Samsung.
 *
 * Lapis 1: saat DND salat dimulai, kebijakan DND diubah menjadi "Prioritas" yang mengizinkan
 *          alarm, media, dan suara sistem (kebijakan semula disimpan lalu dipulihkan).
 * Lapis 2: bila nada azan memakai jalur yang tetap dibisukan oleh DND (notifikasi, dering,
 *          panggilan), filter diangkat sementara selama azan berbunyi dan dipasang kembali sesudahnya
 *          selama jendela DND masih berlaku.
 */
object DndAzan {
    private const val PREF = "jadwal_sholat"
    private const val K_AKTIF_SAMPAI = "prayer_dnd_active_until"
    private const val K_DIANGKAT = "prayer_dnd_lifted_for_adhan"
    private const val K_KAT = "prayer_dnd_policy_cat"
    private const val K_CALL = "prayer_dnd_policy_call"
    private const val K_MSG = "prayer_dnd_policy_msg"
    private const val K_VIS = "prayer_dnd_policy_vis"
    private const val K_ADA = "prayer_dnd_policy_saved"

    /** True bila jalur suara (usage) masih terdengar di bawah filter Prioritas yang kita pasang. */
    fun usageAmanDiDnd(usage: Int): Boolean =
        usage == AudioAttributes.USAGE_ALARM || usage == AudioAttributes.USAGE_MEDIA || usage == AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY

    /** Dipanggil receiver saat DND salat dimulai. Mengembalikan filter yang dipasang. */
    fun pasangFilterRamahAzan(context: Context, nm: NotificationManager): Int {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                val lama = nm.notificationPolicy
                if (!sp.getBoolean(K_ADA, false)) {
                    sp.edit().putInt(K_KAT, lama.priorityCategories).putInt(K_CALL, lama.priorityCallSenders)
                        .putInt(K_MSG, lama.priorityMessageSenders).putInt(K_VIS, lama.suppressedVisualEffects)
                        .putBoolean(K_ADA, true).commit()
                }
                // FIX333: alarm (azan), media, dan suara sistem selalu diizinkan, sama seperti Jangan Ganggu bawaan perangkat, agar volume media/sistem
                // tidak ikut menjadi nol. Notifikasi lain (pesan, panggilan, pengingat) tetap senyap karena jalurnya notifikasi, bukan alarm/media.
                val kat = NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS or NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA or
                    NotificationManager.Policy.PRIORITY_CATEGORY_SYSTEM
                nm.notificationPolicy = NotificationManager.Policy(kat, lama.priorityCallSenders, lama.priorityMessageSenders, lama.suppressedVisualEffects)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY) return NotificationManager.INTERRUPTION_FILTER_PRIORITY
            } catch (_: Exception) { }
        }
        try { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS) } catch (_: Exception) { }
        return NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    /** Pulihkan kebijakan DND milik pengguna (dipanggil saat DND salat berakhir). */
    fun pulihkanKebijakan(context: Context, nm: NotificationManager) {
        if (Build.VERSION.SDK_INT < 23) return
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!sp.getBoolean(K_ADA, false)) return
        try {
            nm.notificationPolicy = NotificationManager.Policy(sp.getInt(K_KAT, 0), sp.getInt(K_CALL, 1), sp.getInt(K_MSG, 1), sp.getInt(K_VIS, 0))
            sp.edit().remove(K_ADA).remove(K_KAT).remove(K_CALL).remove(K_MSG).remove(K_VIS).apply()
        } catch (_: Exception) { }
    }

    private fun jendelaAktif(context: Context): Boolean =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong(K_AKTIF_SAMPAI, 0L) > System.currentTimeMillis()

    /** Dipanggil layanan azan sebelum/selama suara berbunyi. Aman dipanggil berulang. */
    fun izinkanSuaraAzan(context: Context, usage: Int) {
        if (Build.VERSION.SDK_INT < 23 || !jendelaAktif(context) || usageAmanDiDnd(usage)) return
        try {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            if (!nm.isNotificationPolicyAccessGranted) return
            if (nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) {
                context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(K_DIANGKAT, true).commit()
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
        } catch (_: Exception) { }
    }

    /** Dipanggil saat layanan azan selesai: pasang kembali DND salat jika jendelanya masih berlaku. */
    fun pasangKembaliSetelahAzan(context: Context) {
        val sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!sp.getBoolean(K_DIANGKAT, false)) return
        sp.edit().remove(K_DIANGKAT).commit()
        if (Build.VERSION.SDK_INT < 23 || !jendelaAktif(context)) return
        try {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            if (!nm.isNotificationPolicyAccessGranted) return
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
        } catch (_: Exception) { }
    }
}
