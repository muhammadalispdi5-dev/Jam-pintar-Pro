package com.novan.bateraibicara

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

/**
 * FIX167: pilihan saluran volume untuk audio Khatam Al-Qur'an, sama seperti pilihan "Keluaran suara" pada Jam dan Baterai
 * (media, alarm, notifikasi, dering, aksesibilitas, panggilan suara, sistem). Disimpan pada SharedPreferences "khatam_quran"
 * dengan kunci "saluran_audio_idx" (0-6, awal 0 = media). Dipakai oleh pemutar di layar Khatam dan pemutar latar belakang.
 */
object SaluranAudioKhatam {
    const val KUNCI = "saluran_audio_idx"
    const val JUMLAH = 7

    fun indeks(context: Context): Int =
        context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).getInt(KUNCI, 0).coerceIn(0, JUMLAH - 1)

    fun simpan(context: Context, idx: Int) {
        context.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).edit().putInt(KUNCI, idx.coerceIn(0, JUMLAH - 1)).apply()
    }

    fun label(idx: Int, english: Boolean): String {
        fun t(id: String, en: String) = if (english) en else id
        return when (idx) {
            1 -> t("Volume alarm", "Alarm volume")
            2 -> t("Volume notifikasi", "Notification volume")
            3 -> t("Volume dering", "Ringtone volume")
            4 -> t("Volume aksesibilitas", "Accessibility volume")
            5 -> t("Volume panggilan suara", "Voice-call volume")
            6 -> t("Volume sistem", "System volume")
            else -> t("Volume media", "Media volume")
        }
    }

    private fun usage(idx: Int): Int = when (idx) {
        1 -> AudioAttributes.USAGE_ALARM
        2 -> AudioAttributes.USAGE_NOTIFICATION
        3 -> AudioAttributes.USAGE_NOTIFICATION_RINGTONE
        4 -> AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
        5 -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        6 -> AudioAttributes.USAGE_ASSISTANCE_SONIFICATION
        else -> AudioAttributes.USAGE_MEDIA
    }

    /** Atribut audio murattal (isi berupa musik/rekaman) untuk saluran terpilih. */
    fun atribut(context: Context): AudioAttributes =
        AudioAttributes.Builder().setUsage(usage(indeks(context))).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    /** Aliran volume yang dikendalikan tombol volume fisik saat layar Khatam terbuka. */
    fun streamType(context: Context): Int = when (indeks(context)) {
        1 -> AudioManager.STREAM_ALARM
        2 -> AudioManager.STREAM_NOTIFICATION
        3 -> AudioManager.STREAM_RING
        4 -> if (android.os.Build.VERSION.SDK_INT >= 26) AudioManager.STREAM_ACCESSIBILITY else AudioManager.STREAM_MUSIC
        5 -> AudioManager.STREAM_VOICE_CALL
        6 -> AudioManager.STREAM_SYSTEM
        else -> AudioManager.STREAM_MUSIC
    }

    /**
     * FIX246: pemutar sesuai pilihan Stereo/Mono dan saluran volume. Mono selalu digabung sendiri. Stereo memakai MediaPlayer pada
     * media, dering, dan aksesibilitas; pada saluran lain (alarm, notifikasi, panggilan suara, sistem) memakai AudioTrack dua kanal
     * agar kiri dan kanan tetap terpisah di semua keluaran suara.
     */
    fun buatPemutar(context: Context, mono: Boolean, gemaKunci: String = "normal", gemaKekuatan: Int = 0): PemutarAudio {
        // FIX311: bila gema dipilih, selalu pakai pemutar sendiri (MediaCodec + AudioTrack) agar gema dihitung langsung pada data suara.
        val gema = gemaKunci != "normal" && gemaKekuatan > 0
        return when {
            mono -> PemutarMono(false, gemaKunci, gemaKekuatan)
            gema -> PemutarMono(true, gemaKunci, gemaKekuatan)
            indeks(context) in intArrayOf(1, 2, 5, 6) -> PemutarMono(true)
            else -> PemutarStereo()
        }
    }
}
