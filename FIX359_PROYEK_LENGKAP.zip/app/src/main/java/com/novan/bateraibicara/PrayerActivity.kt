package com.novan.bateraibicara

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.GnssStatus
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.app.AlertDialog
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Jadwal hari ini, pembaruan lokasi, pengaturan, jadwal 30 hari dan arah kiblat. */
class PrayerActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private lateinit var status: android.widget.TextView
    private lateinit var list: android.widget.TextView
    private val dateFmt by lazy { DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", if (BahasaAplikasi.tampilan(this) == 1) Locale.ENGLISH else Locale("id", "ID")) }
    private val locationHandler = Handler(Looper.getMainLooper())
    private var activeLocationManager: LocationManager? = null
    private var activeLocationListener: LocationListener? = null
    private var activeGnssCallback: GnssStatus.Callback? = null
    private var locationTone: ToneGenerator? = null
    private var searchingPrayerLocation = false
    private var bestLiveLocation: Location? = null
    private var freshCachedLocation: Location? = null
    private var accurateFixCount = 0
    private var firstAccurateFixAt = 0L
    private var lastFixTimestamp = 0L
    private var satelliteStatusAvailable = false
    private var visibleSatellites = 0
    private var usedSatellites = 0
    private var lastSpokenSearchStatus = 0L
    private val prayerLocationBeep = object : Runnable {
        override fun run() {
            if (!searchingPrayerLocation) return
            try { locationTone?.startTone(ToneGenerator.TONE_PROP_BEEP, 130) } catch (_: Exception) { }
            locationHandler.postDelayed(this, 650L)
        }
    }
    private val prayerLocationProgress = object : Runnable {
        override fun run() {
            if (!searchingPrayerLocation) return
            val now = System.currentTimeMillis()
            if (now - lastSpokenSearchStatus >= 12_000L) {
                lastSpokenSearchStatus = now
                val loc = bestLiveLocation
                val message = if (BahasaAplikasi.tampilan(this@PrayerActivity) == 1) {
                    val accuracy = if (loc != null) " The best current position accuracy is about " + loc.accuracy.toInt() + " meters." else " The device has not returned a current position yet."
                    val sat = if (satelliteStatusAvailable) " GPS satellites detected: " + visibleSatellites + ". Satellites being used to determine the position: " + usedSatellites + "." else " GPS satellite information is not available from the device."
                    "The prayer schedule location search is still in progress. Repeated short tones mean the search is active." + accuracy + sat
                } else {
                    val accuracy = if (loc != null) " Perkiraan ketelitian posisi terbaik saat ini sekitar " + loc.accuracy.toInt() + " meter." else " Posisi terkini dari perangkat belum diterima."
                    val sat = if (satelliteStatusAvailable) " Jumlah satelit GPS yang terdeteksi sebanyak " + visibleSatellites + ". Jumlah satelit yang digunakan untuk menentukan posisi sebanyak " + usedSatellites + "." else " Informasi jumlah satelit belum tersedia dari perangkat."
                    "Pencarian lokasi jadwal sholat masih berlangsung. Nada pendek berulang menandakan pencarian masih aktif." + accuracy + sat
                }
                if (::status.isInitialized) status.text = ui(message)
                tesSuara("jam", message)
            }
            locationHandler.postDelayed(this, 2_000L)
        }
    }

    override fun bangun() {
        status = info("")
        list = info("")
        bagian("Lokasi")
        info(ui("Jadwal dihitung di HP sebagai cadangan. Jika opsi pembaruan otomatis melalui internet diaktifkan di Pengaturan Jadwal Sholat, aplikasi mengunduh jadwal berdasarkan koordinat untuk memperbarui waktu. Koordinat lokasi akan dikirim ke layanan jadwal tersebut hanya untuk meminta waktu salat."))
        tombol("Perbarui lokasi (GPS)") { perbaruiLokasiGps() }
        tombol("Atur lokasi manual") { dialogLokasiManual() }
        tombol("Pengaturan Jadwal Sholat dan Pengingat") { startActivity(Intent(this, PrayerSettingsActivity::class.java)) }
        tombol("Bacakan jadwal sholat hari ini") {
            if (!pp.locationSet) toast("Atur lokasi terlebih dahulu.") else {
                val d = LocalDate.now()
                val t = PrayerCalc.calculate(d, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
                val bahasa = prefs.bahasaAktif
                val daftar = listOf(
                    "subuh" to onlineOrLocal(d, "subuh", t.fajr), "terbit" to onlineOrLocal(d, "terbit", t.sunrise),
                    "dhuha" to onlineOrLocal(d, "dhuha", t.dhuha), "tahajud" to waktuTahajud(d),
                    "dzuhur" to onlineOrLocal(d, "dzuhur", t.dhuhr), "ashar" to onlineOrLocal(d, "ashar", t.asr),
                    "maghrib" to onlineOrLocal(d, "maghrib", t.maghrib), "isya" to onlineOrLocal(d, "isya", t.isha)
                )
                tesSuara("jam", UcapanSholat.jadwalHariIni(daftar, bahasa, pp.use24))
            }
        }
        tombol("Pilih hari dan jadwal 30 hari") { startActivity(Intent(this, PrayerThirtyActivity::class.java)) }
        tombol("Arah Kiblat") { startActivity(Intent(this, QiblaActivity::class.java)) }
        tombol("Info Jadwal Sholat") {
            AlertDialog.Builder(this).setTitle(getString(R.string.info_jadwal_sholat_title))
                .setMessage(getString(R.string.info_jadwal_sholat_message))
                .setPositiveButton(ui("Mengerti"), null).show()
        }
        segarkan()
        if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, msg ->
            runOnUiThread { if (::status.isInitialized) { segarkan(); toast(msg) }; PrayerAlarm.scheduleAll(this) }
        }
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) { LokasiOtomatis.periksa(this) { if (it) runOnUiThread { segarkan() } }; segarkan(); if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, _ -> runOnUiThread { segarkan(); PrayerAlarm.scheduleAll(this) } } } }

    private fun segarkan() {
        if (!pp.locationSet) {
            status.text = getString(R.string.info_lokasi_jadwal_belum_diatur)
            list.text = getString(R.string.info_jadwal_belum_dihitung)
            return
        }
        val date = LocalDate.now()
        val t = PrayerCalc.calculate(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments())
        status.text = (ui("Jadwal sholat tanggal ") + date.format(dateFmt) + "\n" + ui("Lokasi: ") + namaLokasiTampil(pp.place) + "\n" + ui("Metode perhitungan: ") + ui(PrayerCalc.methodNames[pp.method]) + "\n" + ui("Pengingat: ") + ui(if (pp.enabled) "aktif" else "nonaktif"))
        list.text = listOf(
            (ui("Imsak: ") + (PrayerCalc.format(onlineOrLocal(date, "imsak", t.imsak), pp.use24))),
            (ui("Subuh: ") + (PrayerCalc.format(onlineOrLocal(date, "subuh", t.fajr), pp.use24))),
            (ui("Terbit: ") + (PrayerCalc.format(onlineOrLocal(date, "terbit", t.sunrise), pp.use24))),
            (ui("Dhuha: ") + (PrayerCalc.format(onlineOrLocal(date, "dhuha", t.dhuha), pp.use24))),
            (ui("Tahajud (perkiraan): ") + (PrayerCalc.format(waktuTahajud(date), pp.use24))),
            (ui("Dzuhur: ") + (PrayerCalc.format(onlineOrLocal(date, "dzuhur", t.dhuhr), pp.use24))),
            (ui("Ashar: ") + (PrayerCalc.format(onlineOrLocal(date, "ashar", t.asr), pp.use24))),
            (ui("Maghrib: ") + (PrayerCalc.format(onlineOrLocal(date, "maghrib", t.maghrib), pp.use24))),
            (ui("Isya: ") + (PrayerCalc.format(onlineOrLocal(date, "isya", t.isha), pp.use24)))
        ).joinToString("\n")
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 401 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) perbaruiLokasiGps()
    }

    private fun perbaruiLokasiGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 401)
            return
        }
        berhentiMencariLokasiJadwal()
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        activeLocationManager = lm
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        if (providers.isEmpty()) {
            AlertDialog.Builder(this).setMessage(getString(R.string.info_layanan_lokasi_mati))
                .setPositiveButton(ui("Setelan lokasi")) { _, _ -> startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
                .setNegativeButton(ui("Batal"), null).show()
            return
        }

        searchingPrayerLocation = true
        bestLiveLocation = null
        freshCachedLocation = null
        accurateFixCount = 0
        firstAccurateFixAt = 0L
        lastFixTimestamp = 0L
        satelliteStatusAvailable = false
        visibleSatellites = 0
        usedSatellites = 0
        lastSpokenSearchStatus = System.currentTimeMillis()
        val pesanMulai = "Sedang mencari lokasi untuk jadwal sholat melalui GPS dan jaringan. Mohon tunggu hingga 45 detik. Untuk hasil lebih teliti, usahakan berada di tempat terbuka. Nada pendek berulang menandakan pencarian aktif."
        if (::status.isInitialized) status.text = pesanMulai
        tesSuara("jam", pesanMulai)
        locationTone = try { ToneGenerator(AudioManager.STREAM_MUSIC, 80) } catch (_: Exception) { null }
        locationHandler.post(prayerLocationBeep)
        locationHandler.postDelayed(prayerLocationProgress, 12_000L)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                val callback = object : GnssStatus.Callback() {
                    override fun onSatelliteStatusChanged(gnssStatus: GnssStatus) {
                        if (!searchingPrayerLocation) return
                        var visible = 0
                        var used = 0
                        for (i in 0 until gnssStatus.satelliteCount) {
                            visible++
                            if (gnssStatus.usedInFix(i)) used++
                        }
                        visibleSatellites = visible
                        usedSatellites = used
                        satelliteStatusAvailable = true
                    }
                }
                activeGnssCallback = callback
                lm.registerGnssStatusCallback(callback, locationHandler)
            } catch (_: Exception) {
                activeGnssCallback = null
                satelliteStatusAvailable = false
            }
        }

        try {
            // Simpan lokasi cache sebagai cadangan sahaja; jangan jadikan hasil lama sebagai hasil utama.
            val now = System.currentTimeMillis()
            for (provider in providers) {
                try {
                    @Suppress("MissingPermission")
                    val cached = lm.getLastKnownLocation(provider)
                    if (cached != null && now - cached.time in 0L..120_000L && cached.accuracy > 0f && cached.accuracy <= 10_000f &&
                        (freshCachedLocation == null || cached.accuracy < freshCachedLocation!!.accuracy)) freshCachedLocation = cached
                } catch (_: Exception) { }
            }

            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (!searchingPrayerLocation || !location.hasAccuracy() || location.accuracy <= 0f || location.accuracy > 10_000f) return
                    if (System.currentTimeMillis() - location.time !in 0L..120_000L) return
                    val old = bestLiveLocation
                    if (old == null || location.accuracy < old.accuracy ||
                        (location.accuracy <= old.accuracy + 2f && location.time > old.time)) bestLiveLocation = location
                    if (location.time > lastFixTimestamp) {
                        lastFixTimestamp = location.time
                        if (location.accuracy <= 8f) {
                            if (accurateFixCount == 0) firstAccurateFixAt = System.currentTimeMillis()
                            accurateFixCount++
                        } else {
                            accurateFixCount = 0
                            firstAccurateFixAt = 0L
                        }
                    }
                    // Hindari berhenti pada fix pertama; minta beberapa sampel yang teliti dan stabil.
                    if (accurateFixCount >= 3 && firstAccurateFixAt > 0L &&
                        System.currentTimeMillis() - firstAccurateFixAt >= 4_000L) {
                        bestLiveLocation?.let { akhiriPencarianLokasiJadwal(it) }
                    }
                }
                @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            activeLocationListener = listener
            var requested = 0
            for (provider in providers) {
                try {
                    @Suppress("MissingPermission")
                    lm.requestLocationUpdates(provider, 1_000L, 0f, listener, Looper.getMainLooper())
                    requested++
                } catch (_: Exception) { }
            }
            if (requested == 0) {
                akhiriPencarianLokasiJadwal(null, "Perangkat tidak mengizinkan pembaruan lokasi. Periksa izin lokasi dan coba lagi.")
                return
            }
            locationHandler.postDelayed({
                if (searchingPrayerLocation) {
                    // Utamakan lokasi langsung; gunakan cache baru hanya jika tak ada fix langsung.
                    val selected = bestLiveLocation ?: freshCachedLocation
                    akhiriPencarianLokasiJadwal(selected, "Lokasi belum berhasil ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi di tempat yang lebih terbuka atau atur lokasi manual.")
                }
            }, 45_000L)
        } catch (_: SecurityException) {
            akhiriPencarianLokasiJadwal(null, "Izin lokasi belum diberikan. Izinkan akses lokasi untuk memperbarui jadwal sholat.")
        } catch (_: Exception) {
            akhiriPencarianLokasiJadwal(null, "Lokasi belum ditemukan. Pastikan izin dan layanan lokasi aktif, lalu coba lagi atau atur lokasi manual.")
        }
    }

    private fun berhentiMencariLokasiJadwal() {
        searchingPrayerLocation = false
        locationHandler.removeCallbacksAndMessages(null)
        try { activeLocationListener?.let { activeLocationManager?.removeUpdates(it) } } catch (_: Exception) { }
        activeLocationListener = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try { activeGnssCallback?.let { activeLocationManager?.unregisterGnssStatusCallback(it) } } catch (_: Exception) { }
        }
        activeGnssCallback = null
        try { locationTone?.release() } catch (_: Exception) { }
        locationTone = null
        activeLocationManager = null
    }

    private fun akhiriPencarianLokasiJadwal(lokasi: Location?, pesanGagal: String? = null) {
        if (!searchingPrayerLocation) return
        berhentiMencariLokasiJadwal()
        if (lokasi != null && lokasi.hasAccuracy() && lokasi.accuracy > 0f && lokasi.accuracy <= 10_000f) {
            val sumber = when (lokasi.provider) {
                LocationManager.GPS_PROVIDER -> "GPS"
                LocationManager.NETWORK_PROVIDER -> "jaringan"
                else -> "perangkat"
            }
            simpanLokasi(lokasi.latitude, lokasi.longitude, if (lokasi.provider == LocationManager.GPS_PROVIDER) "Lokasi GPS" else if (lokasi.provider == LocationManager.NETWORK_PROVIDER) "Lokasi jaringan" else "Lokasi perangkat")
            val pesan = if (BahasaAplikasi.tampilan(this) == 1) {
                when {
                    lokasi.accuracy > 2_000f -> "Location saved using " + (if (sumber == "jaringan") "the network" else sumber) + ". Position accuracy is low, about " + lokasi.accuracy.toInt() + " meters. For better results, try again in an open area or set the location manually."
                    lokasi.provider == LocationManager.GPS_PROVIDER -> "Prayer schedule location updated using GPS. Estimated accuracy is " + lokasi.accuracy.toInt() + " meters."
                    else -> "Prayer schedule location updated using " + (if (sumber == "jaringan") "the network" else sumber) + ". Estimated accuracy is " + lokasi.accuracy.toInt() + " meters."
                }
            } else {
                when {
                    lokasi.accuracy > 2_000f -> "Lokasi disimpan menggunakan " + sumber + ". Ketelitian lokasi masih rendah, sekitar " + lokasi.accuracy.toInt() + " meter. Untuk hasil lebih baik, coba lagi di tempat terbuka atau atur lokasi secara manual."
                    lokasi.provider == LocationManager.GPS_PROVIDER -> "Lokasi jadwal sholat diperbarui menggunakan GPS. Perkiraan ketelitian " + lokasi.accuracy.toInt() + " meter."
                    else -> "Lokasi jadwal sholat diperbarui menggunakan " + sumber + ". Perkiraan ketelitian " + lokasi.accuracy.toInt() + " meter."
                }
            }
            if (::status.isInitialized) status.text = pesan
            tesSuara("jam", pesan)
        } else {
            val pesanIndonesia = pesanGagal ?: "Lokasi yang layak belum ditemukan. Coba lagi di tempat terbuka atau atur lokasi manual."
            val pesan = if (BahasaAplikasi.tampilan(this) == 1) {
                when {
                    pesanIndonesia.contains("izin", ignoreCase = true) -> "Location permission or location services are unavailable. Check the settings and try again in a more open area, or set the location manually."
                    else -> "A suitable location could not be found. Try again in an open area or set the location manually."
                }
            } else pesanIndonesia
            if (::status.isInitialized) status.text = ui(pesan)
            AlertDialog.Builder(this).setMessage(ui(pesan)).setPositiveButton(ui("Mengerti"), null).show()
        }
    }

    override fun onDestroy() {
        berhentiMencariLokasiJadwal()
        super.onDestroy()
    }

    private fun dialogLokasiManual() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val lat = EditText(this).apply { hint = if (BahasaAplikasi.tampilan(this@PrayerActivity) == 1) "Latitude, for example -7.797" else "Lintang, contoh -7.797"; inputType = 8194; setText(if (pp.locationSet) pp.lat.toString() else "") }
        val lon = EditText(this).apply { hint = if (BahasaAplikasi.tampilan(this@PrayerActivity) == 1) "Longitude, for example 110.370" else "Bujur, contoh 110.370"; inputType = 8194; setText(if (pp.locationSet) pp.lon.toString() else "") }
        val place = EditText(this).apply { hint = ui("Nama kota/lokasi (opsional)"); setText(if (pp.locationSet) pp.place else "") }
        box.addView(lat); box.addView(lon); box.addView(place)
        AlertDialog.Builder(this).setTitle(ui("Atur lokasi manual")).setView(box)
            .setPositiveButton(ui("Simpan")) { _, _ ->
                val a = lat.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val b = lon.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (a == null || b == null || a !in -90.0..90.0 || b !in -180.0..180.0) {
                    infoDialog("Koordinat tidak valid. Lintang harus −90 sampai 90 dan bujur −180 sampai 180.")
                } else simpanLokasi(a, b, place.text.toString().trim().ifEmpty { "Lokasi manual" })
            }.setNegativeButton(ui("Batal"), null).show()
    }

    private fun namaLokasiTampil(nama: String): String = when (nama.trim()) {
        "Lokasi GPS" -> "GPS"
        "Lokasi manual" -> if (BahasaAplikasi.tampilan(this) == 1) "manually set location" else "lokasi yang diatur secara manual"
        "Lokasi jaringan" -> if (BahasaAplikasi.tampilan(this) == 1) "network location" else "lokasi jaringan"
        "Lokasi perangkat" -> if (BahasaAplikasi.tampilan(this) == 1) "device location" else "lokasi perangkat"
        else -> nama.trim().ifEmpty { if (BahasaAplikasi.tampilan(this) == 1) "unknown" else "belum diketahui" }
    }

    private fun simpanLokasi(lat: Double, lon: Double, nama: String) {
        // Lokasi manual dipertahankan: pengikut lokasi otomatis dimatikan (dapat dinyalakan lagi di pengaturan jadwal salat).
        if (nama == "Lokasi manual" || (!nama.startsWith("Lokasi GPS") && !nama.startsWith("Lokasi jaringan") && !nama.startsWith("Lokasi perangkat"))) pp.ikutiLokasi = false
        pp.lat = lat; pp.lon = lon; pp.place = nama; pp.locationSet = true
        PrayerAlarm.scheduleAll(this)
        toast("Lokasi disimpan")
        segarkan()
        // Cari nama tempat yang spesifik (kelurahan/desa, kota, provinsi) bila nama belum diisi pengguna.
        if (NamaLokasi.belumSpesifik(nama)) NamaLokasi.perbaruiAsinkron(this, pp) { hasil ->
            runOnUiThread {
                if (::status.isInitialized) segarkan()
                if (hasil != null) toast("Nama lokasi: " + hasil)
            }
        }
    }
    private fun onlineOrLocal(date: LocalDate, key: String, fallback: Double): Double {
        if (key == "dhuha" && pp.dhuhaCustomEnabled) return pp.dhuhaCustomMinute / 60.0
        val minutes = if (pp.autoOnline) PrayerOnlineTimes.minutes(this, date, key) else null
        return (minutes?.toDouble() ?: PrayerCalc.minutes(fallback).toDouble()) / 60.0
    }

    private fun waktuTahajud(date: LocalDate): Double {
        if (pp.tahajudCustomEnabled) return pp.tahajudCustomMinute / 60.0
        return PrayerCalc.tahajud(date, pp.lat, pp.lon, java.time.ZoneId.systemDefault(), pp.method, pp.asrFactor, pp.adjustments(), 0)
    }

    private fun infoDialog(msg: String) { runOnUiThread { AlertDialog.Builder(this).setMessage(ui(msg)).setPositiveButton(ui("Mengerti"), null).show() } }
}
