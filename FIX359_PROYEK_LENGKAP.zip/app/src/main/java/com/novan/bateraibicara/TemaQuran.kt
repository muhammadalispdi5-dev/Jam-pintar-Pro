package com.novan.bateraibicara

/**
 * FIX318: pemetaan tema ke ayat Al-Qur'an untuk perintah suara "putar ayat tentang sabar". Daftar ini disusun tangan (ayat-ayat yang
 * lazim dikutip untuk tiap tema); tema di luar daftar dicari lewat teks terjemahan yang sudah diunduh (lihat PemutarQuranService).
 * Rentang berbentuk (surah, ayat awal, ayat akhir).
 */
object TemaQuran {
    class Tema(val nama: String, val namaEn: String, val kata: Set<String>, val rentang: List<Triple<Int, Int, Int>>)

    private fun t(nama: String, en: String, kata: String, vararg r: Triple<Int, Int, Int>) =
        Tema(nama, en, kata.split(' ').toSet(), r.toList())
    private fun r(s: Int, a: Int, b: Int = a) = Triple(s, a, b)

    val daftar: List<Tema> = listOf(
        t("Kesabaran", "Patience", "sabar bersabar kesabaran patience patient sabr", r(2, 153), r(2, 155, 157), r(3, 200), r(39, 10), r(94, 5, 6), r(103, 1, 3)),
        t("Syukur", "Gratitude", "syukur bersyukur nikmat gratitude grateful thankful shukr", r(14, 7), r(31, 12), r(2, 152), r(16, 78), r(55, 13)),
        t("Taubat", "Repentance", "taubat tobat ampun ampunan istighfar repentance repent forgiveness", r(39, 53), r(66, 8), r(25, 70), r(3, 135), r(4, 110), r(11, 3)),
        t("Orangtua", "Parents", "orangtua ortu ibu bapak ayah parents mother father birrul", r(17, 23, 24), r(31, 14, 15), r(46, 15), r(29, 8)),
        t("Rezeki", "Provision", "rezeki rizki rejeki sustenance provision livelihood", r(65, 2, 3), r(11, 6), r(51, 22, 23), r(67, 15), r(62, 10)),
        t("Doa", "Supplication", "doa berdoa permohonan supplication dua invocation", r(2, 186), r(40, 60), r(7, 55, 56), r(27, 62)),
        t("Shalat", "Prayer", "shalat sholat salat solat prayer", r(20, 14), r(29, 45), r(2, 238), r(4, 103), r(17, 78)),
        t("Sedekah", "Charity", "sedekah zakat infak infaq shodaqoh charity alms", r(2, 261), r(2, 274), r(57, 7), r(2, 267), r(9, 103), r(3, 92)),
        t("Ilmu", "Knowledge", "ilmu belajar pengetahuan knowledge learning ulama", r(58, 11), r(39, 9), r(96, 1, 5), r(20, 114), r(35, 28)),
        t("Tawakal", "Reliance", "tawakal tawakkal pasrah reliance", r(3, 159), r(65, 3), r(8, 2), r(9, 51), r(3, 173)),
        t("Persaudaraan", "Brotherhood", "ukhuwah persaudaraan persatuan saudara brotherhood unity", r(49, 10, 13), r(3, 103), r(9, 71)),
        t("Kematian", "Death", "kematian mati maut ajal death", r(3, 185), r(21, 35), r(62, 8), r(4, 78), r(29, 57)),
        t("Akhirat", "Hereafter", "kiamat akhirat qiyamat hereafter resurrection judgment", r(99, 1, 8), r(101, 1, 11), r(82, 1, 5), r(81, 1, 14)),
        t("Surga", "Paradise", "surga jannah paradise heaven", r(2, 25), r(3, 133), r(32, 17), r(18, 107, 108)),
        t("Neraka", "Hellfire", "neraka jahannam hell hellfire", r(66, 6), r(4, 56), r(104, 1, 9), r(2, 24)),
        t("Keadilan", "Justice", "adil keadilan justice", r(4, 135), r(5, 8), r(16, 90), r(57, 25)),
        t("Amanah", "Trust", "amanah amanat trusts", r(4, 58), r(33, 72), r(8, 27), r(23, 8)),
        t("Pernikahan", "Marriage", "nikah menikah pernikahan istri suami marriage spouse wife husband", r(30, 21), r(4, 1), r(25, 74), r(24, 32)),
        t("Anak", "Children", "anak anak-anak mendidik children", r(31, 13, 19), r(18, 46), r(64, 15), r(25, 74)),
        t("Puasa", "Fasting", "puasa shaum ramadhan ramadan fasting", r(2, 183, 185), r(2, 187)),
        t("Haji", "Pilgrimage", "haji umrah hajj kabah pilgrimage", r(2, 196, 197), r(3, 97), r(22, 27, 29)),
        t("Kejujuran", "Honesty", "jujur kejujuran honesty truthful truthfulness", r(9, 119), r(33, 70, 71), r(2, 42)),
        t("Pemaaf", "Pardon", "maaf memaafkan pemaaf pardon", r(3, 134), r(24, 22), r(42, 40), r(7, 199), r(41, 34)),
        t("Kesembuhan", "Healing", "sakit sembuh kesembuhan penyembuhan healing illness cure", r(26, 80), r(17, 82), r(10, 57), r(21, 83, 84)),
        t("Ketenangan", "Peace", "tenang ketenangan cemas khawatir galau takut anxiety peace calm worry", r(13, 28), r(2, 286), r(9, 40), r(3, 139), r(10, 62)),
        t("Ujian", "Trials", "ujian cobaan musibah trial trials hardships", r(2, 155, 157), r(2, 214), r(29, 2, 3), r(67, 2)),
        t("Kemudahan", "Ease", "kesulitan kemudahan susah kesusahan difficulty ease", r(94, 5, 6), r(65, 7), r(2, 286), r(2, 185)),
        t("Iman", "Faith", "iman beriman cinta faith belief love", r(2, 165), r(3, 31), r(49, 15), r(8, 2, 4)),
        t("Tauhid", "Oneness", "tauhid esa ikhlas oneness monotheism", r(112, 1, 4), r(2, 255), r(59, 22, 24), r(3, 18)),
        t("Alam", "Creation", "alam ciptaan langit bumi nature creation heavens", r(2, 164), r(3, 190, 191), r(30, 20, 25), r(67, 3, 4)),
        t("Kerendahan", "Humility", "sombong angkuh kesombongan tawadhu rendah arrogance humility", r(31, 18, 19), r(17, 37), r(25, 63)),
        t("Akhlak", "Character", "akhlak kebaikan ihsan morality kindness character", r(16, 90), r(41, 34), r(17, 53), r(3, 134)),
        t("Riba", "Usury", "riba utang hutang usury debt", r(2, 275, 276), r(2, 278, 279), r(3, 130), r(2, 282)),
        t("Waktu", "Time", "waktu time", r(103, 1, 3), r(91, 1, 10)),
        t("Rasulullah", "Prophet", "nabi rasul rasulullah muhammad prophet messenger", r(33, 21), r(68, 4), r(21, 107), r(9, 128)),
        t("Tahajud", "Night", "tahajud malam qiyamullail night", r(17, 79), r(73, 1, 6), r(32, 16), r(51, 17, 18)),
        t("Dzikir", "Remembrance", "dzikir zikir mengingat remembrance dhikr", r(13, 28), r(33, 41, 42), r(2, 152), r(62, 10))
    )

    private val penanda = setOf("tentang", "mengenai", "bertema", "tema", "soal", "seputar", "terkait", "about", "regarding", "concerning", "theme")
    private val kataBantu = setOf("yang", "dan", "dari", "itu", "ini", "untuk", "saya", "aku", "tolong", "please", "putar", "putarkan", "mainkan", "bacakan",
        "dengarkan", "perdengarkan", "play", "ayat", "ayatayat", "quran", "alquran", "al", "qur", "an", "surah", "surat", "verses", "verse", "the", "of", "a", "dong", "ya", "kan")

    fun cocok(kata: List<String>): Tema? {
        var terbaik: Tema? = null; var skorTerbaik = 0
        for (tm in daftar) {
            var skor = 0
            for (k in kata) {
                if (k in tm.kata) skor += 2
                else if (k.length >= 5 && tm.kata.any { it.length >= 5 && (k.contains(it) || it.contains(k)) }) skor += 1
            }
            if (skor > skorTerbaik) { skorTerbaik = skor; terbaik = tm }
        }
        return terbaik
    }

    /**
     * Mengurai kata-kata ucapan menjadi tema. Mengembalikan pasangan (nama tema, rentang ayat); rentang kosong berarti tema bebas
     * yang harus dicari lewat teks terjemahan. Null bila ucapan bukan permintaan tema.
     */
    fun deteksi(tokens: List<String>): Pair<String, List<Triple<Int, Int, Int>>>? {
        if (tokens.any { it.toIntOrNull() != null }) return null
        val adaPenanda = tokens.indexOfFirst { it in penanda }
        val adaAyat = tokens.any { it == "ayat" || it == "verses" || it == "verse" }
        val sumber = if (adaPenanda >= 0) tokens.drop(adaPenanda + 1) else tokens
        val kata = sumber.filter { it !in kataBantu && it !in penanda && it.length >= 2 }
        if (kata.isEmpty()) return null
        val tm = cocok(kata)
        if (tm != null && (adaPenanda >= 0 || adaAyat)) return tm.nama to tm.rentang
        if (adaPenanda >= 0) return kata.joinToString(" ") to emptyList()
        return null
    }
}
