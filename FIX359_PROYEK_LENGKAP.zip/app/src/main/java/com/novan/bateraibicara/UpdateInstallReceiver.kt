package com.novan.bateraibicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.widget.Toast

/** Menerima hasil pemasangan pembaruan dari PackageInstaller dan menampilkan konfirmasi sistem. */
class UpdateInstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val konfirmasi: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                if (konfirmasi != null) {
                    try {
                        konfirmasi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(konfirmasi)
                    } catch (_: Exception) {
                        Toast.makeText(context, R.string.update_gagal_pasang, Toast.LENGTH_LONG).show()
                    }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> { /* aplikasi diganti sistem; prosesnya berhenti */ }
            PackageInstaller.STATUS_FAILURE_ABORTED -> { /* pengguna membatalkan */ }
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE, PackageInstaller.STATUS_FAILURE_CONFLICT ->
                // FIX304: tanda tangan APK berbeda dari aplikasi terpasang, atau nomor build lebih rendah.
                Toast.makeText(context, R.string.update_gagal_tanda_tangan, Toast.LENGTH_LONG).show()
            else -> Toast.makeText(context, R.string.update_gagal_pasang, Toast.LENGTH_LONG).show()
        }
    }
}
