package com.novan.bateraibicara

import android.app.NotificationManager
import android.content.Context
import android.os.Build

/**
 * FIX334: mengikuti cara kerja Jangan Ganggu bawaan perangkat. Selama filter gangguan sistem tidak "semua",
 * suara otomatis yang tidak perlu (pengumuman baterai/jam, pengingat Khatam/Hafalan, pengumuman pemanggil)
 * tidak diucapkan. Alarm, azan, dan timer tetap berbunyi lewat saluran alarm. Tombol volume dan telungkup
 * tetap menghentikan suara karena tidak bergantung pada Jangan Ganggu.
 */
object DndSistem {
    /** True bila suara tidak esensial harus senyap. [panggilan] true: pengumuman pemanggil boleh bila kebijakan prioritas mengizinkan panggilan/pesan. */
    fun senyap(context: Context, panggilan: Boolean = false): Boolean {
        if (Build.VERSION.SDK_INT < 23) return false
        return try {
            val nm = context.applicationContext.getSystemService(NotificationManager::class.java) ?: return false
            when (nm.currentInterruptionFilter) {
                NotificationManager.INTERRUPTION_FILTER_NONE, NotificationManager.INTERRUPTION_FILTER_ALARMS -> true
                NotificationManager.INTERRUPTION_FILTER_PRIORITY -> {
                    if (!panggilan) true else {
                        val k = nm.notificationPolicy.priorityCategories
                        (k and (NotificationManager.Policy.PRIORITY_CATEGORY_CALLS or NotificationManager.Policy.PRIORITY_CATEGORY_MESSAGES)) == 0
                    }
                }
                else -> false
            }
        } catch (_: Throwable) { false }
    }
}
