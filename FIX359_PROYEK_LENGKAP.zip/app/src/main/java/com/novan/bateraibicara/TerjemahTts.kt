package com.novan.bateraibicara

import android.content.Context
import java.io.File
import java.util.Locale

/**
 * FIX329: pembacaan terjemahan Al-Qur'an dengan suara TTS sesudah tiap ayat (ayat, terjemahan, ayat berikutnya, terjemahan, dan seterusnya).
 * Teks terjemahan diambil dari cache teks Khatam (quran_id.json / quran_en.json) sehingga tidak butuh internet. Saklar disimpan di
 * pengaturan Khatam; suara (mesin, kecepatan, keluaran) memakai profil suara "trj".
 */
object TerjemahTts {
    const val KUNCI = "terjemah_tts_aktif"
    const val PROFIL = "trj"

    fun aktif(c: Context): Boolean = c.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).getBoolean(KUNCI, false)
    fun setAktif(c: Context, v: Boolean) { c.getSharedPreferences("khatam_quran", Context.MODE_PRIVATE).edit().putBoolean(KUNCI, v).apply() }

    private var namaBerkas = ""
    private var waktuBerkas = 0L
    private var data: Array<List<String>?> = arrayOfNulls(115)

    private fun muat(c: Context) {
        val nama = if (BahasaAplikasi.tampilan(c) == 1) "quran_en.json" else "quran_id.json"
        val f = File(c.filesDir, nama)
        if (!f.exists()) { data = arrayOfNulls(115); namaBerkas = ""; return }
        if (nama == namaBerkas && f.lastModified() == waktuBerkas) return
        val baru: Array<List<String>?> = arrayOfNulls(115)
        try {
            val surahs = org.json.JSONObject(f.readText(Charsets.UTF_8)).optJSONObject("data")?.optJSONArray("surahs")
            if (surahs != null) for (i in 0 until minOf(114, surahs.length())) {
                val ayahs = surahs.optJSONObject(i)?.optJSONArray("ayahs") ?: continue
                val daftar = ArrayList<String>(ayahs.length())
                for (j in 0 until ayahs.length()) daftar.add(ayahs.optJSONObject(j)?.optString("text").orEmpty())
                baru[i + 1] = daftar
            }
        } catch (_: Exception) { }
        data = baru; namaBerkas = nama; waktuBerkas = f.lastModified()
    }

    /** Dipanggil di thread latar agar pembacaan pertama tidak menunggu penguraian berkas. */
    @Synchronized fun panaskan(c: Context) { muat(c.applicationContext) }

    @Synchronized fun teks(c: Context, surah: Int, ayat: Int): String? {
        if (surah !in 1..114 || ayat < 1) return null
        muat(c.applicationContext)
        return data[surah]?.getOrNull(ayat - 1)?.trim()?.takeIf { it.isNotBlank() }
    }

    fun bahasa(c: Context): Locale = if (BahasaAplikasi.tampilan(c) == 1) Locale.ENGLISH else Locale("id", "ID")

    // ---------- FIX331: perintah suara "putar surah X ayat Y dengan terjemahan suara TTS" ----------
    private fun daftar(s: String) = s.replace('_', ' ')
    private val polaTts = Regex("(?i)\\b(?:(?:" + daftar("dan_|plus_|beserta_|serta_|dengan_|lalu_|kemudian_|ditambah_|sekalian_|pakai_|memakai_|menggunakan_|lewat_|via_|oleh_") +
        "))?(?:suara )?(?:tts|t t s|" + daftar("te_te_es|ti_ti_es|teh_teh_es|text_to_speech") + ")(?: nya)?\\b")
    private val polaBaca = Regex("(?i)\\b(?:bacakan|dibacakan|dibaca|baca)\\s+(?:juga\\s+|sekalian\\s+)?(?:terjemah\\w*|artinya|arti)\\b")
    private val polaTerjemah = Regex("(?i)\\b(?:(?:" + daftar("dan_|plus_|beserta_|serta_|dengan_|lalu_|kemudian_|ditambah_|sekalian_") +
        "))?(?:terjemahan|terjemahnya|terjemahannya|terjemah|translation|artinya|arti)(?: bahasa)?(?: indonesia| inggris)?\\b")

    /**
     * Bila ucapan meminta terjemahan dibacakan TTS, kata TTS dan kata terjemahan dibuang agar pengurai perintah lama (yang mengartikan terjemahan
     * sebagai berkas audio) tidak ikut bekerja, dan penanda "per ayat" ditambahkan bila ayat tidak disebut agar tiap ayat punya jeda terjemahan.
     */
    fun pisahPerintah(kandidat: List<String>, ttsAktif: Boolean = false): Pair<List<String>, Boolean> {
        // FIX337: bila saklar terjemah TTS aktif, kata "terjemah" saja (tanpa kata audio) sudah berarti dibacakan TTS, bukan berkas audio terjemahan.
        val terjemahSaja = ttsAktif && kandidat.any { polaTerjemah.containsMatchIn(it) && !it.contains("audio", ignoreCase = true) }
        if (!terjemahSaja && kandidat.none { polaTts.containsMatchIn(it) || polaBaca.containsMatchIn(it) }) return kandidat to false
        val bersih = kandidat.map { u ->
            var t = polaBaca.replace(u, " ")
            t = polaTts.replace(t, " ")
            t = polaTerjemah.replace(t, " ")
            t = t.replace(Regex("\\s+"), " ").trim()
            // FIX337: sisa kata sambung di ujung ("ayat 9 dan") dibuang agar tidak dibaca sebagai rentang atau perintah lanjutan.
            val sambung = Regex("(?i)\\s+(?:dan|plus|serta|lalu|kemudian|dengan|beserta|sekalian|juga|and|with)$")
            while (sambung.containsMatchIn(t)) t = sambung.replace(t, "").trim()
            t
        }
        val tanpaAyat = bersih.none { it.contains("ayat", ignoreCase = true) }
        return (if (tanpaAyat) bersih.map { it + daftar(" per_ayat") } else bersih) to true
    }

    /** Unduh teks terjemahan bila belum tersimpan (dipanggil di thread latar). Mengembalikan true bila teks tersedia. */
    @Synchronized fun pastikanTersedia(c: Context): Boolean {
        if (teks(c, 1, 1) != null) return true
        val inggris = BahasaAplikasi.tampilan(c) == 1
        val nama = if (inggris) "quran_en.json" else "quran_id.json"
        val alamat = if (inggris) "https://api.alquran.cloud/v1/quran/en.sahih" else "https://api.alquran.cloud/v1/quran/id.indonesian"
        return try {
            val k = java.net.URL(alamat).openConnection() as java.net.HttpURLConnection
            k.connectTimeout = 15000; k.readTimeout = 40000
            val isi = k.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
            k.disconnect()
            val surahs = org.json.JSONObject(isi).optJSONObject("data")?.optJSONArray("surahs")
            if (surahs == null || surahs.length() < 114) return false
            val sementara = File(c.filesDir, "$nama.tmp"); sementara.writeText(isi, Charsets.UTF_8)
            val tujuan = File(c.filesDir, nama)
            if (!sementara.renameTo(tujuan)) { tujuan.delete(); sementara.renameTo(tujuan) }
            teks(c, 1, 1) != null
        } catch (_: Exception) { false }
    }
}
