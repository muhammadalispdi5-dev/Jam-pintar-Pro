package com.novan.bateraibicara

import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject

/**
 * FIX338: qari tambahan dengan sumber audio buatan pengguna (mis. Muammar ZA 30 juz). Sumber harus berupa alamat folder HTTPS yang
 * memuat 114 berkas per surah bernama 001.mp3 sampai 114.mp3. Qari tampil di daftar qari per surah (Khatam) dan dapat dipilih lewat asisten
 * ("pilih qari Muammar"). Aplikasi tidak menyertakan tautan bawaan karena sumber 30 juz Muammar ZA yang lengkap dan resmi belum terverifikasi.
 */
object QariTambahan {
    private const val PREF = "qari_tambahan"
    private const val KUNCI = "daftar"

    class Item(val nama: String, val server: String)

    fun semua(c: Context): List<Item> {
        val hasil = ArrayList<Item>()
        try {
            val arr = JSONArray(c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KUNCI, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val n = o.optString("nama").trim(); val s = o.optString("server").trim()
                if (n.isNotBlank() && s.startsWith("https://")) hasil.add(Item(n, s))
            }
        } catch (_: Exception) { }
        return hasil
    }

    private fun simpanSemua(c: Context, daftar: List<Item>) {
        val arr = JSONArray()
        daftar.forEach { arr.put(JSONObject().put("nama", it.nama).put("server", it.server)) }
        c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KUNCI, arr.toString()).apply()
    }

    fun tambah(c: Context, nama: String, server: String): Boolean {
        val n = nama.trim()
        var s = server.trim()
        if (n.isBlank() || !s.startsWith("https://")) return false
        if (!s.endsWith("/")) s += "/"
        val baru = semua(c).filter { !it.nama.equals(n, ignoreCase = true) } + Item(n, s)
        simpanSemua(c, baru)
        return true
    }

    fun hapus(c: Context, nama: String) { simpanSemua(c, semua(c).filter { !it.nama.equals(nama, ignoreCase = true) }) }

    /** Pasangan (id, label) sesuai format qari per surah Khatam: mp3quran|server|1,2,...,114. */
    fun daftar(c: Context): List<Pair<String, String>> =
        semua(c).map { ("mp3quran|" + it.server + "|" + (1..114).joinToString(",")) to ("Tambahan · " + it.nama) }
}

class QariTambahanActivity : Halaman() {
    override val judulHalaman = R.string.judul_qari_tambahan
    private var tetap = 0
    private var nama = "Muammar ZA"
    private var server = ""

    override fun bangun() {
        tetap = root.childCount
        render()
    }

    private fun render() {
        while (root.childCount > tetap) root.removeViewAt(tetap)
        info(tr("Tambahkan qari dengan sumber audio Anda sendiri, misalnya Muammar ZA 30 juz. Sumbernya harus alamat folder HTTPS yang berisi 114 berkas bernama 001.mp3 sampai 114.mp3 (satu berkas per surah), contoh: https://contoh.com/muammar/. Setelah disimpan, qari muncul di daftar qari per surah pada Khatam dan dapat dipilih dengan perintah suara, misalnya: pilih qari Muammar.",
            "Add a reciter with your own audio source, for example Muammar ZA full Qur'an. The source must be an HTTPS folder address containing 114 files named 001.mp3 to 114.mp3 (one file per surah), for example: https://example.com/muammar/. After saving, the reciter appears in the Khatam per-surah reciter list and can be chosen by voice, for example: choose reciter Muammar."))
        isian(tr("Nama qari", "Reciter name"), nama, InputType.TYPE_CLASS_TEXT) { nama = it }
        isian(tr("Alamat folder audio (https://...)", "Audio folder address (https://...)"), server, InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_CLASS_TEXT) { server = it }
        tombol(tr("Simpan qari", "Save reciter")) {
            if (QariTambahan.tambah(this, nama, server)) { toast(tr("Qari disimpan.", "Reciter saved.")); server = ""; render() }
            else toast(tr("Isi nama qari dan alamat yang diawali https://", "Enter the reciter name and an address starting with https://"))
        }
        val ada = QariTambahan.semua(this)
        if (ada.isEmpty()) info(tr("Belum ada qari tambahan.", "No additional reciters yet."))
        for (q in ada) {
            tombol(tr("Hapus qari ", "Delete reciter ") + q.nama + " (" + q.server + ")") {
                AlertDialog.Builder(this).setTitle(tr("Hapus qari ini?", "Delete this reciter?")).setMessage(q.nama)
                    .setPositiveButton(tr("Hapus", "Delete")) { _, _ -> QariTambahan.hapus(this, q.nama); render() }
                    .setNegativeButton(tr("Batal", "Cancel"), null).show()
            }
        }
    }
}
