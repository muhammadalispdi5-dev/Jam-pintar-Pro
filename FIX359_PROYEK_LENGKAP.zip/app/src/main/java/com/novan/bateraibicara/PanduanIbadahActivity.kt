package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale

/**
 * FIX243: Panduan Ibadah Praktis (turunan pola ManasikHajiActivity). Daftar bagian -> halaman bagian (teks, kutipan Arab, Latin, arti),
 * dengan ukuran huruf yang dapat diatur, dengarkan (teks-ke-ucapan), salin, bagikan, serta bagian berikutnya/sebelumnya.
 */
class PanduanIbadahActivity : Halaman() {
    override val judulHalaman = R.string.judul_panduan_ibadah

    private val simpan by lazy { getSharedPreferences("panduan_ibadah", MODE_PRIVATE) }
    private var pembicara: Pembicara? = null

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun judul(b: ManasikHajiData.Bagian) = if (english) b.judul.en else b.judul.id
    private fun isi(b: ManasikHajiData.Blok) = if (english) b.en else b.id

    override fun onPause() {
        hentikanSuara()
        super.onPause()
    }

    override fun onDestroy() {
        hentikanSuara()
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("bagian", -1)
        val b = PanduanIbadahData.daftar.getOrNull(nomor)
        if (b == null) daftar() else halaman(nomor, b)
        tombolMesinBawah()
    }

    // ---------- Daftar bagian ----------

    private fun daftar() {
        info(tr(
            "Panduan ibadah praktis menurut tuntunan dan kebiasaan Rasulullah shallallahu 'alaihi wasallam: wudhu, mandi, tayammum, najis, mengusap khuf, adzan, tata cara shalat, surah-surah pendek, dzikir, shalat sunnah, tarawih, gerhana, shalat Jumat, shalat safar, shalat jenazah, shalat Id, puasa, zakat, ibadah muslimah, mendidik anak, adab harian, adab safar, adab berdoa, sakit dan ruqyah, rutinitas harian, dan tips bagi saudara tunanetra. Setiap bagian memuat bacaan Arab, Latin, arti, dan sumber haditsnya. Pada rincian yang diperselisihkan ulama, ikuti guru atau mazhab Anda.",
            "A practical worship guide following the teaching and habits of the Messenger, peace be upon him: ablution, bathing, dry ablution, impurities, wiping over footwear, the call to prayer, how to pray, short surahs, remembrance, voluntary prayers, Ramadan night prayer, eclipse prayer, Friday prayer, travel prayer, funeral prayer, Eid prayer, fasting, zakat, worship for Muslim women, teaching children, daily etiquette, travel etiquette, supplication etiquette, illness and ruqyah, a daily routine, and tips for blind brothers and sisters. Each section gives Arabic, transliteration, meaning, and the hadith source. On details scholars differ about, follow your teacher or school of thought."
        ))
        PanduanIbadahData.daftar.forEachIndexed { i, b ->
            tombol((i + 1).toString() + ". " + judul(b)) { buka(i) }
        }
    }

    private fun buka(i: Int, ganti: Boolean = false) {
        startActivity(Intent(this, PanduanIbadahActivity::class.java).putExtra("bagian", i))
        if (ganti) finish()
    }

    // ---------- Halaman bagian ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 18f)

    private fun halaman(nomor: Int, b: ManasikHajiData.Bagian) {
        bagian(judul(b), 22f)
        tombol(tr("Dengarkan bagian ini", "Listen to this section")) { ucapkan(bacaanBagian(b), false) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara(); toast(tr("Suara dihentikan.", "Audio stopped.")) }
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(34f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }

        b.blok.forEach { blok(it) }

        val semua = teksLengkap(b)
        tombol(tr("Salin bagian ini", "Copy this section")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("panduan_ibadah", semua))
                toast(tr("Teks disalin.", "Text copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan bagian ini", "Share this section")) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua)
                startActivity(Intent.createChooser(i, tr("Bagikan panduan ibadah", "Share worship guide")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan teks.", "No app is available to share this text."))
            }
        }
        if (nomor + 1 < PanduanIbadahData.daftar.size)
            tombol(tr("Bagian berikutnya: ", "Next section: ") + judul(PanduanIbadahData.daftar[nomor + 1])) { buka(nomor + 1, ganti = true) }
        if (nomor > 0)
            tombol(tr("Bagian sebelumnya: ", "Previous section: ") + judul(PanduanIbadahData.daftar[nomor - 1])) { buka(nomor - 1, ganti = true) }
    }

    private fun blok(b: ManasikHajiData.Blok) {
        if (b.arab != null) {
            val ar = TextView(this)
            ar.text = b.arab
            ar.textSize = ukuran() + 6f
            ar.setTextColor(warnaTeks())
            ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
            ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            ar.setLineSpacing(0f, 1.3f)
            ar.setPadding(0, dp(14), 0, dp(6))
            root.addView(ar)
        }
        if (b.latin != null) {
            val la = TextView(this)
            la.text = b.latin
            la.textSize = ukuran()
            la.setTypeface(la.typeface, Typeface.ITALIC)
            la.setTextColor(warnaAksen())
            la.setPadding(0, dp(2), 0, dp(6))
            root.addView(la)
        }
        val tv = TextView(this)
        tv.text = isi(b)
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(4), 0, dp(8))
        root.addView(tv)
        if (b.sumber != null) {
            val s = TextView(this)
            s.text = b.sumber
            s.textSize = 14f
            s.setTextColor(warnaPetunjuk())
            root.addView(s)
        }
        if (b.arab != null) {
            tombol(tr("Dengarkan bacaan Arab ini", "Listen to this Arabic recitation")) { ucapkan(b.arab, true) }
        }
    }

    private fun bacaanBagian(b: ManasikHajiData.Bagian): String =
        (listOf(judul(b)) + b.blok.map { isi(it) }).joinToString("\n")

    private fun teksLengkap(b: ManasikHajiData.Bagian): String = buildString {
        append(judul(b)).append("\n\n")
        b.blok.forEach { k ->
            if (k.arab != null) append(k.arab).append("\n")
            if (k.latin != null) append(k.latin).append("\n")
            append(isi(k)).append("\n\n")
        }
    }.trim()

    // ---------- Audio ----------

    private fun pecah(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        var sisa = teks.trim()
        while (sisa.length > maks) {
            var potong = sisa.lastIndexOfAny(charArrayOf('.', '\n', '،', ';', ':'), maks)
            if (potong < maks / 2) potong = sisa.lastIndexOf(' ', maks)
            if (potong <= 0) potong = maks - 1
            hasil.add(sisa.substring(0, potong + 1).trim())
            sisa = sisa.substring(potong + 1).trim()
        }
        if (sisa.isNotEmpty()) hasil.add(sisa)
        return hasil
    }

    /** FIX353: bagian Suara pembaca (mesin, kecepatan, nada, keluaran, volume mandiri, gema) di paling bawah halaman. */
    private fun tombolMesinBawah() {
        blokSuara("ibadah") { tr("Bismillahirrahmanirrahim. Ini contoh suara pembaca panduan ibadah.", "Bismillahirrahmanirrahim. This is a sample of the worship guide reading voice.") }
    }

    private fun hentikanSuara() {
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
    }

    /** [arab] true = ucapkan teks Arab dengan suara Arab; false = teks bahasa aplikasi. */
    private fun ucapkan(teks: String, arab: Boolean) {
        hentikanSuara()
        try {
            val sp = Pembicara(applicationContext, Prefs(this).suara("ibadah")) { toast(it) }
            sp.bisaDibungkam = true
            sp.paksaBahasaTampilan = true
            sp.paksaArab = arab
            pembicara = sp
            sp.ucapkanRangkaian(pecah(teks, 500), 250L)
        } catch (_: Exception) {
            toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
        }
    }
}
