package com.novan.bateraibicara

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.concurrent.Executors

/**
 * FIX293: penetapan awal bulan Hijriah RESMI (Kementerian Agama RI, hasil sidang isbat / kalender resmi).
 * Tidak ada API publik Kemenag yang stabil, jadi penetapan resmi diterbitkan pengembang sebagai berkas JSON di repositori yang sama dengan
 * pembaruan aplikasi (updates/hijriah_resmi.json) dan diambil otomatis oleh aplikasi. Data ini selalu didahulukan di atas AlAdhan dan hitungan perangkat:
 *   {"sumber":"Kemenag RI","awal_bulan":[{"hijriah":"1448-09","masehi":"2027-02-08"}, ...]}
 * "masehi" ialah tanggal Masehi hari pertama bulan itu. Tanggal Hijriah suatu hari = selisih hari dari awal bulan terdekat sebelumnya + 1
 * (bulan 29 atau 30 hari mengikuti awal bulan berikutnya). Pergantian hari tetap pukul 18.00 (lihat KalenderTanggal.tanggalHariIni).
 */
object HijriahResmi {
    private const val PREF = "hijriah_resmi"
    private const val JEDA_MS = 6L * 60 * 60 * 1000
    private const val BATAS_JSON = 256 * 1024
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var berjalan = false

    class Awal(val tahun: Int, val bulan: Int, val mulai: LocalDate)

    @Volatile private var cache: List<Awal>? = null
    @Volatile private var cacheTeks: String? = null

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Mengurai JSON; null bila tidak sah (bulan tidak urut, jarak awal bulan bukan 29..30 hari, dsb.). */
    fun urai(teks: String): List<Awal>? = try {
        val arr = JSONObject(teks).getJSONArray("awal_bulan")
        val daftar = ArrayList<Awal>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val h = o.getString("hijriah").split("-")
            daftar.add(Awal(h[0].trim().toInt(), h[1].trim().toInt(), LocalDate.parse(o.getString("masehi").trim())))
        }
        daftar.sortBy { it.mulai }
        var sah = daftar.isNotEmpty() && daftar.all { it.bulan in 1..12 && it.tahun in 1300..1600 }
        for (i in 1 until daftar.size) {
            val jarak = ChronoUnit.DAYS.between(daftar[i - 1].mulai, daftar[i].mulai)
            val urutan = (daftar[i - 1].tahun * 12 + daftar[i - 1].bulan + 1) == (daftar[i].tahun * 12 + daftar[i].bulan)
            // Jarak 28..31 hari ditoleransi bagi data resmi yang berbeda sehari dari hitungan; urutan bulan wajib berkesinambungan.
            if (jarak !in 28L..31L || !urutan) sah = false
        }
        if (sah) daftar else null
    } catch (_: Exception) { null }

    private fun muat(c: Context): List<Awal>? {
        val teks = sp(c).getString("json", null) ?: return null
        if (teks == cacheTeks) return cache
        val hasil = urai(teks)
        cache = hasil; cacheTeks = teks
        return hasil
    }

    /** Tanggal Hijriah resmi (tahun, bulan 0-based, tanggal); null bila hari itu di luar data resmi tersimpan. */
    fun cari(c: Context, date: LocalDate): Triple<Int, Int, Int>? {
        val daftar = muat(c) ?: return null
        val awal = daftar.lastOrNull { !it.mulai.isAfter(date) } ?: return null
        val selisih = ChronoUnit.DAYS.between(awal.mulai, date).toInt()
        val berikut = daftar.getOrNull(daftar.indexOf(awal) + 1)
        val batas = if (berikut != null) ChronoUnit.DAYS.between(awal.mulai, berikut.mulai).toInt() else 30
        if (selisih >= batas) return null
        return Triple(awal.tahun, awal.bulan - 1, selisih + 1)
    }

    fun adaData(c: Context): Boolean = muat(c) != null

    private fun alamat(): String {
        val t = System.currentTimeMillis()
        return when {
            AppKonfigurasi.URL_HIJRIAH_RESMI.startsWith("https://") -> AppKonfigurasi.URL_HIJRIAH_RESMI + (if (AppKonfigurasi.URL_HIJRIAH_RESMI.contains("?")) "&" else "?") + "t=" + t
            BuildConfig.GITHUB_REPO.contains("/") -> "https://raw.githubusercontent.com/" + BuildConfig.GITHUB_REPO + "/main/updates/hijriah_resmi.json?t=" + t
            else -> ""
        }
    }

    /** Mengambil penetapan resmi terbaru di latar belakang (paling sering sekali per 6 jam kecuali [paksa]). */
    fun segarkan(c: Context, paksa: Boolean = false, selesai: ((Boolean) -> Unit)? = null) {
        val app = c.applicationContext
        val s = sp(app)
        if (!paksa && System.currentTimeMillis() - s.getLong("percobaan", 0L) < JEDA_MS) { selesai?.invoke(false); return }
        val url = alamat()
        if (url.isEmpty()) { selesai?.invoke(false); return }
        synchronized(this) { if (berjalan) { selesai?.invoke(false); return }; berjalan = true }
        s.edit().putLong("percobaan", System.currentTimeMillis()).apply()
        executor.execute {
            var ok = false
            try {
                val k = URL(url).openConnection() as HttpURLConnection
                k.connectTimeout = 8000; k.readTimeout = 8000; k.useCaches = false
                k.setRequestProperty("User-Agent", "JamPintarPro-HijriahResmi")
                try {
                    if (k.responseCode == 200) {
                        val teks = k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        if (teks.length <= BATAS_JSON && urai(teks) != null) {
                            s.edit().putString("json", teks).putLong("sukses", System.currentTimeMillis()).apply()
                            cache = null; cacheTeks = null
                            ok = true
                        }
                    }
                } finally { k.disconnect() }
            } catch (_: Exception) { }
            synchronized(this) { berjalan = false }
            selesai?.invoke(ok)
        }
    }
}
