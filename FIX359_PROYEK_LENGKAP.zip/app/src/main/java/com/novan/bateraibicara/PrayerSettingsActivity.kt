package com.novan.bateraibicara

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.provider.OpenableColumns
import android.text.InputType
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Semua pilihan jadwal, pengingat, metode, penyesuaian menit, dan sumber suara azan. */
class PrayerSettingsActivity : Halaman() {
    override val judulHalaman = R.string.kategori_sholat
    private val pp by lazy { PrayerPrefs(this) }
    private val prayerNames = listOf(
        "Imsak" to "imsak", "Subuh" to "subuh", "Matahari terbit" to "terbit", "Dhuha" to "dhuha", "Tahajud" to "tahajud",
        "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya"
    )
    private lateinit var alarmPermissionStatus: TextView
    private var tombolTesRef: android.widget.Button? = null
    private fun segarkanLabelTes() {
        val b = tombolTesRef ?: return
        val label = ui(labelTombolTes())
        if (b.text.toString() != label) { b.text = label; b.contentDescription = label }
    }
    private val requestGlobal = 50
    private val requestSahurSound = 90
    private val requestBerbukaSound = 91
    private fun requestPrayer(key: String) = 51 + prayerNames.indexOfFirst { it.second == key }
    private val advancePrayerNames = listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
    private fun requestAdvancePrayer(key: String) = 80 + advancePrayerNames.indexOfFirst { it.second == key }

    override fun onResume() {
        super.onResume()
        PrayerAlarm.scheduleAll(this)
        if (::alarmPermissionStatus.isInitialized) segarkanStatusIzinAlarm()
        segarkanLabelTes()
        // Android 12+ memerlukan akses khusus SCHEDULE_EXACT_ALARM. Versi kunci
        // dinaikkan agar pengguna yang pernah melihat halaman izin terkunci mendapat
        // satu kesempatan lagi setelah pembaruan aplikasi.
        if (Build.VERSION.SDK_INT >= 31) {
            val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
            if (!PrayerPrefs(this).dndEnabled) {
                state.edit().remove("prayer_dnd_exact_prompted_v2").apply()
            } else {
                val am = getSystemService(android.app.AlarmManager::class.java)
                if (am != null && am.canScheduleExactAlarms()) {
                    state.edit().remove("prayer_dnd_exact_prompted_v2").apply()
                } else if (!state.getBoolean("prayer_dnd_exact_prompted_v2", false)) {
                    state.edit().putBoolean("prayer_dnd_exact_prompted_v2", true).apply()
                    try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse(("package:" + (packageName))))) }
                    catch (_: Exception) { toast("Buka Pengaturan Android, lalu aktifkan Izinkan alarm dan pengingat agar Mode Jangan Ganggu dapat dipulihkan sesuai durasi.") }
                }
            }
        }
    }

    /**
     * Halaman ini dipecah menjadi daftar kelompok pendek agar pengguna pembaca layar tidak perlu
     * menelusuri ratusan elemen sekaligus. Setiap kelompok dibuka di halaman terpisah; tombol
     * Kembali membawa pengguna ke daftar kelompok.
     */
    override fun bangun() {
        when (intent.getStringExtra("kelompok")) {
            "jadwal" -> grupJadwal()
            "pengingat" -> grupPengingat()
            "puasa" -> grupPuasa()
            "awal" -> grupAwal()
            "tarhim" -> grupTarhim()
            "iqomah" -> grupIqomah()
            "melodi" -> grupMelodi()
            "dnd" -> grupDnd()
            "suara" -> grupSuara()
            "mandiri" -> grupSuaraMandiri()
            "kiblat" -> grupKiblat()
            else -> menuUtama()
        }
    }

    private fun bukaKelompok(nama: String, kode: String) {
        startActivity(Intent(this, PrayerSettingsActivity::class.java).putExtra("kelompok", kode))
    }

    private fun judulKelompok(nama: String) {
        title = ui(nama)
        bagian(nama, 22f)
    }

    private fun menuUtama() {
        bagian("Pengaturan Jadwal Sholat dan Pengingat")
        info("Semua fitur jadwal sholat dan pengingat dinonaktifkan pada pengaturan awal. Aktifkan hanya yang Anda perlukan. Penghitungan waktu tetap dapat dilihat pada halaman Jadwal Sholat tanpa mengaktifkan pengingat.")
        saklar("Aktifkan pengingat waktu sholat", pp.enabled) { pp.enabled = it; PrayerAlarm.scheduleAll(this); if (it) mintaIzinNotifikasi() }
        saklar(tr("Tampilkan jadwal sholat di layar pemberitahuan", "Show prayer times in the notification shade"), pp.jadwalNotif) { pp.jadwalNotif = it; JadwalNotifikasi.perbarui(this); if (it) mintaIzinNotifikasi() }
        info("Pilih satu kelompok pengaturan. Setiap kelompok dibuka di halaman tersendiri; tombol Kembali membawa Anda ke daftar ini.")
                tombol("Jadwal dan lokasi") { bukaKelompok("Jadwal dan lokasi", "jadwal") }
        tombol("Pengingat waktu sholat") { bukaKelompok("Pengingat waktu sholat", "pengingat") }
        tombol("Pengingat Waktu Sahur dan Berbuka") { bukaKelompok("Pengingat Waktu Sahur dan Berbuka", "puasa") }
        tombol("Pengingat sebelum sholat") { bukaKelompok("Pengingat sebelum sholat", "awal") }
        tombol(tr("Tarhim sebelum sholat", "Tarhim before prayer")) { bukaKelompok(tr("Tarhim sebelum sholat", "Tarhim before prayer"), "tarhim") }
        tombol(tr("Iqomah setelah azan", "Iqomah after adhan")) { bukaKelompok(tr("Iqomah setelah azan", "Iqomah after adhan"), "iqomah") }
        tombol(tr("Pengaturan Melodi Pengingat", "Reminder Melody Settings")) { bukaKelompok("Pengaturan Melodi Pengingat", "melodi") }
        tombol("Mode Jangan Ganggu saat sholat") { bukaKelompok("Mode Jangan Ganggu saat sholat", "dnd") }
        tombol("Suara azan dan tes suara") { bukaKelompok("Suara azan dan tes suara", "suara") }
        tombol(tr("Volume mandiri dan efek gema", "Independent volume and echo effect")) { bukaKelompok(tr("Volume mandiri dan efek gema", "Independent volume and echo effect"), "mandiri") }
        tombol("Arah kiblat dan kompas") { bukaKelompok("Arah kiblat dan kompas", "kiblat") }
    
        tombolResetPengaturan("jadwal sholat dan pengingat") {
                    // Pertahankan koordinat/lokasi yang sudah dipilih; lokasi terkini adalah
                    // data terpisah dari preferensi pengingat dan jadwal salat.
                    val spJadwal = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
                    val editorReset = spJadwal.edit()
                    spJadwal.all.keys
                        .filterNot { it in setOf("location_set", "lat", "lon", "place") }
                        .forEach { editorReset.remove(it) }
                    editorReset.apply()
                    PrayerAlarm.scheduleAll(this)
                }
}

    private fun grupJadwal() {
        judulKelompok("Jadwal dan lokasi")
        bagian("Pembaruan otomatis jadwal melalui internet")
        info("Pada instalasi baru, pembaruan online aktif agar jadwal mengikuti koordinat dan metode perhitungan yang dipilih. Koordinat dikirim ke layanan AlAdhan hanya untuk mengambil jadwal salat. Jika internet tidak tersedia atau layanan gagal, aplikasi memakai perhitungan lokal. Anda dapat menonaktifkan opsi ini kapan saja.")
        saklar("Perbarui jadwal sholat otomatis melalui internet", pp.autoOnline) { aktif ->
            pp.autoOnline = aktif
            if (aktif) {
                PrayerOnlineTimes.sync(this) { _, msg ->
                    runOnUiThread {
                        toast(msg)
                        if (pp.enabled) PrayerAlarm.scheduleAll(this)
                        // Segarkan label "Pembaruan terakhir" setelah hasil sinkronisasi tersedia.
                        if (!isFinishing && !isDestroyed) recreate()
                    }
                }
            } else {
                recreate()
            }
        }
        info(PrayerOnlineTimes.lastSyncLabel(this))
        tombol("Perbarui jadwal sekarang melalui internet") { PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); recreate(); PrayerAlarm.scheduleAll(this) } } }

        bagian("Lokasi dan perhitungan")
        saklar(tr("Ikuti lokasi saya otomatis saat berpindah tempat", "Follow my location automatically when I move"), pp.ikutiLokasi) { aktif ->
            pp.ikutiLokasi = aktif
            if (aktif) LokasiOtomatis.periksa(this, paksa = true) { berubah -> if (berubah && !isFinishing && !isDestroyed) recreate() }
        }
        info(tr("Bila aktif dan izin lokasi diberikan, jadwal salat berpindah mengikuti lokasi Anda (perpindahan sekitar 5 kilometer atau lebih), tanpa perlu menekan tombol. Agar berjalan saat aplikasi di latar belakang, izinkan lokasi Sepanjang waktu di pengaturan izin aplikasi. Lokasi yang Anda atur manual mematikan pengaturan ini.", "When on and location permission is granted, prayer times move with you (about 5 kilometers or more), without pressing any button. To work while the app is in the background, allow location All the time in the app permission settings. Setting a location manually turns this off."))
        if (!LokasiOtomatis.izinLatarBelakang(this)) tombol(tr("Izinkan lokasi sepanjang waktu (agar ikut berpindah di latar belakang)", "Allow location all the time (to follow while in the background)")) {
            try { startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + packageName))) } catch (_: Exception) { }
        }
        info(if (pp.locationSet) ("Lokasi: " + (when (pp.place.trim()) { "Lokasi GPS" -> "GPS"; "Lokasi jaringan" -> "jaringan"; "Lokasi perangkat" -> "perangkat"; "Lokasi tersimpan" -> "tersimpan"; "Lokasi manual" -> "diatur secara manual"; else -> pp.place.trim().ifEmpty { "belum diketahui" } }) + ". Koordinat lokasi sudah tersimpan.") else "Lokasi belum diatur. Gunakan GPS atau isi lintang dan bujur pada halaman Jadwal Sholat.")
        tombol("Buka halaman lokasi") { startActivity(Intent(this, PrayerActivity::class.java)) }
        pilihan("Metode perhitungan", PrayerCalc.methodNames, pp.method) {
            pp.method = it
            if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); PrayerAlarm.scheduleAll(this); recreate() } }
            else PrayerAlarm.scheduleAll(this)
        }
        pilihan("Perhitungan Ashar", listOf("Mazhab Syafi'i, Maliki, Hanbali (bayangan 1x)", "Mazhab Hanafi (bayangan 2x)"), pp.asrFactor - 1) {
            pp.asrFactor = it + 1
            if (pp.autoOnline && pp.locationSet) PrayerOnlineTimes.sync(this) { _, msg -> runOnUiThread { toast(msg); PrayerAlarm.scheduleAll(this); recreate() } }
            else PrayerAlarm.scheduleAll(this)
        }
        pilihan("Format waktu", listOf("24 jam", "12 jam"), if (pp.use24) 0 else 1) { pp.use24 = it == 0 }

        bagian("Waktu khusus Dhuha dan Tahajud")
        info("Secara bawaan, Dhuha dan Tahajud tetap mengikuti waktu standar hasil perhitungan jadwal. Jika ingin azan/pengingat berbunyi pada jam pilihan sendiri, aktifkan waktu khusus, lalu pilih jamnya. Pengaturan ini memengaruhi jadwal dan alarm pengingat.")
        saklar("Gunakan waktu khusus Dhuha", pp.dhuhaCustomEnabled) { enabled ->
            pp.dhuhaCustomEnabled = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) ("Pengingat Dhuha menggunakan waktu pilihan: " + (formatJam(pp.dhuhaCustomMinute))) else "Waktu Dhuha kembali mengikuti perhitungan standar")
        }
        tombol(("Pilih waktu khusus Dhuha, saat ini " + (formatJam(pp.dhuhaCustomMinute)))) {
            TimePickerDialog(this, { _, hour, minute ->
                pp.dhuhaCustomMinute = hour * 60 + minute
                PrayerAlarm.scheduleAll(this); recreate()
                toast(("Waktu khusus Dhuha disimpan: " + (formatJam(pp.dhuhaCustomMinute))))
            }, pp.dhuhaCustomMinute / 60, pp.dhuhaCustomMinute % 60, pp.use24).show()
        }
        saklar("Gunakan waktu khusus Tahajud", pp.tahajudCustomEnabled) { enabled ->
            pp.tahajudCustomEnabled = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) ("Pengingat Tahajud menggunakan waktu pilihan: " + (formatJam(pp.tahajudCustomMinute))) else "Waktu Tahajud kembali mengikuti perhitungan standar")
        }
        tombol(("Pilih waktu khusus Tahajud, saat ini " + (formatJam(pp.tahajudCustomMinute)))) {
            TimePickerDialog(this, { _, hour, minute ->
                pp.tahajudCustomMinute = hour * 60 + minute
                PrayerAlarm.scheduleAll(this); recreate()
                toast(("Waktu khusus Tahajud disimpan: " + (formatJam(pp.tahajudCustomMinute))))
            }, pp.tahajudCustomMinute / 60, pp.tahajudCustomMinute % 60, pp.use24).show()
        }

        bagian("Tambah atau kurangi menit")
        info("Sesuaikan setiap waktu jika jadwal setempat berbeda. Anda dapat memajukan atau memundurkan waktu hingga 30 menit.")
        val adjust = listOf("Imsak" to "imsak", "Subuh" to "subuh", "Terbit" to "terbit", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        for ((label, key) in adjust) {
            val field = isian(("Penyesuaian " + (label) + " (menit)"), pp.adjustment(key).toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED) { raw ->
                raw.toIntOrNull()?.let { pp.setAdjustment(key, it) }
            }
            field.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) PrayerAlarm.scheduleAll(this) }
        }

    }

    private fun grupPengingat() {
        judulKelompok("Pengingat waktu sholat")
        bagian("Pengingat setiap waktu sholat")
        info("Aktifkan pengingat matahari terbit secara terpisah melalui sakelar Ingatkan waktu Matahari terbit.")
        for ((name, key) in prayerNames.filter { it.second != "imsak" }) {
            saklar(("Ingatkan waktu " + (name)), pp.reminder(key)) { pp.setReminder(key, it); PrayerAlarm.scheduleAll(this) }
        }
        // FIX270: sakelar azan Dzuhur hari Jumat dikembalikan ke halaman ini (sempat tidak tampil sehingga tidak dapat diatur).
        bagian(tr("Hari Jumat", "Friday"))
        saklar(tr("Matikan suara azan Dzuhur pada hari Jumat", "Turn off the Dhuhr adhan sound on Fridays"), pp.fridayDhuhrOff) {
            pp.fridayDhuhrOff = it
            PrayerAlarm.scheduleAll(this)
            toast(if (it) tr("Azan Dzuhur pada hari Jumat dimatikan", "The Dhuhr adhan on Fridays is turned off")
                else tr("Azan Dzuhur pada hari Jumat diaktifkan kembali", "The Dhuhr adhan on Fridays is turned back on"))
        }
        info(tr("Bila aktif, pada hari Jumat tidak ada suara azan, pengingat sebelum sholat, maupun Tarhim untuk waktu Dzuhur, karena waktunya dipakai untuk sholat Jumat. Hari lain tetap berbunyi seperti biasa.",
            "When on, on Fridays there is no adhan, pre-prayer reminder, or Tarhim for the Dhuhr time, because that time is used for Friday prayer. Other days sound as usual."))
    }

    /**
     * FIX237: seluruh pilihan melodi pengingat dikumpulkan di satu halaman, berurutan: sahur, berbuka, lima pengingat
     * sebelum salat, lalu Imsak, Matahari terbit, Dhuha, dan Tahajud. Tiap pengingat punya melodi sebelum dan sesudah suara.
     */
    private fun grupMelodi() {
        judulKelompok(tr("Pengaturan Melodi Pengingat", "Reminder Melody Settings"))
        info(tr("Semua melodi pengingat ada di halaman ini: sahur, berbuka, sebelum salat, Imsak, Matahari terbit, Dhuha, dan Tahajud. Setiap pengingat memiliki melodi sebelum dan melodi setelah suara pengingat. Daftar melodi tetap terbuka saat pratinjau; tekan Simpan untuk menerapkan pilihan atau Batal untuk mempertahankan pilihan sebelumnya.",
            "All reminder melodies are on this page: suhoor, iftar, before prayer, Imsak, sunrise, Dhuha, and Tahajjud. Each reminder has a melody before and a melody after its sound. The melody list stays open during preview; press Save to apply your choice or Cancel to keep the previous selection."))
        barisMelodi("sahur", "suhoor", pp.sahurMelodiAwal, pp.sahurMelodiAkhir, { pp.sahurMelodiAwal = it }, { pp.sahurMelodiAkhir = it })
        barisMelodi("berbuka", "iftar", pp.berbukaMelodiAwal, pp.berbukaMelodiAkhir, { pp.berbukaMelodiAwal = it }, { pp.berbukaMelodiAkhir = it })
        val inggrisSebelum = mapOf("subuh" to "Fajr", "dzuhur" to "Dhuhr", "ashar" to "Asr", "maghrib" to "Maghrib", "isya" to "Isha")
        for ((name, key) in advancePrayerNames) {
            barisMelodi("sebelum " + name, "before " + (inggrisSebelum[key] ?: name), pp.advanceMelodyBefore(key), pp.advanceMelodyAfter(key),
                { pp.setAdvanceMelodyBefore(key, it) }, { pp.setAdvanceMelodyAfter(key, it) })
        }
        val inggrisLain = mapOf("imsak" to "Imsak", "terbit" to "sunrise", "dhuha" to "Dhuha", "tahajud" to "Tahajjud")
        for ((label, key) in listOf("Imsak" to "imsak", "Matahari terbit" to "terbit", "Dhuha" to "dhuha", "Tahajud" to "tahajud")) {
            barisMelodi(label, inggrisLain[key] ?: label, pp.reminderMelodyBefore(key), pp.reminderMelodyAfter(key),
                { pp.setReminderMelodyBefore(key, it) }, { pp.setReminderMelodyAfter(key, it) })
        }
    }

    /** Satu pengingat: judul kecil dan dua tombol (melodi sebelum dan setelah suara pengingat). */
    private fun barisMelodi(namaId: String, namaEn: String, awal: Int, akhir: Int, simpanAwal: (Int) -> Unit, simpanAkhir: (Int) -> Unit) {
        val daftar = resources.getStringArray(R.array.jam_melodi).map { ui(it) }
        fun nama(i: Int) = daftar.getOrElse(i) { daftar.first() }
        val judulAwal = tr("Melodi sebelum suara pengingat " + namaId, "Melody before the " + namaEn + " reminder sound")
        val judulAkhir = tr("Melodi setelah suara pengingat " + namaId, "Melody after the " + namaEn + " reminder sound")
        bagian(tr("Melodi pengingat " + namaId, "Melodies for the " + namaEn + " reminder"), 15f)
        tombol(judulAwal + ": " + nama(awal)) { pilihMelodiBertahap(judulAwal, awal, simpanAwal) }
        tombol(judulAkhir + ": " + nama(akhir)) { pilihMelodiBertahap(judulAkhir, akhir, simpanAkhir) }
    }

    private fun grupPuasa() {
        judulKelompok("Pengingat Waktu Sahur dan Berbuka")
        info("Pilih satu jenis puasa. Pengingat sahur, Imsak, dan berbuka hanya dijadwalkan pada tanggal yang sesuai dengan jenis puasa tersebut. Seluruh sakelar pengingat tetap nonaktif sampai Anda mengaktifkannya.")
        val types = listOf("Tidak dipilih, pengingat puasa nonaktif", "Puasa Ramadan", "Puasa sunah Senin dan Kamis", "Puasa sunah Nabi Dawud", "Puasa sunah Syawal")
        val keys = listOf(FastingSchedule.NONE, FastingSchedule.RAMADAN, FastingSchedule.MON_THU, FastingSchedule.DAWUD, FastingSchedule.SHAWWAL)
        pilihan("Jenis puasa yang sedang diikuti", types, keys.indexOf(pp.fastingType).coerceAtLeast(0)) { idx ->
            pp.fastingType = keys[idx]
            PrayerAlarm.scheduleAll(this)
            toast("Jenis puasa: " + types[idx] + ". Jenis lain otomatis dinonaktifkan.")
            recreate()
        }
        when (pp.fastingType) {
            FastingSchedule.DAWUD -> {
                val startLabel = pp.dawudStartDate.takeIf { it.isNotBlank() }?.let { ("Tanggal awal puasa Dawud: " + (it)) } ?: "Tanggal awal puasa Dawud belum dipilih"
                info("Pilih tanggal yang benar-benar menjadi hari pertama berpuasa. Aplikasi akan menghitung pola selang-seling: puasa pada tanggal awal, tidak puasa keesokan harinya, lalu berpuasa lagi.")
                tombol(startLabel) {
                    val current = runCatching { java.time.LocalDate.parse(pp.dawudStartDate) }.getOrElse { java.time.LocalDate.now() }
                    android.app.DatePickerDialog(this, { _, year, month, day ->
                        pp.dawudStartDate = java.time.LocalDate.of(year, month + 1, day).toString()
                        PrayerAlarm.scheduleAll(this); recreate()
                        toast(("Tanggal awal puasa Dawud disimpan: " + (pp.dawudStartDate)))
                    }, current.year, current.monthValue - 1, current.dayOfMonth).show()
                }
            }
            FastingSchedule.SHAWWAL -> {
                val dates = pp.shawwalSelectedDates
                info("Pilih tanggal-tanggal puasa Syawal pada kalender Hijriah yang ditampilkan. Setiap tanggal juga dilengkapi tanggal Masehi hasil konversi kalender perangkat. Periksa kembali kesesuaian tanggal dengan kalender Hijriah resmi setempat.")
                tombol(("Pilih tanggal puasa Syawal pada kalender Hijriah; " + (dates.size) + " tanggal dipilih")) {
                    pilihTanggalSyawal()
                }
            }
            FastingSchedule.RAMADAN -> info("Pengingat hanya berjalan selama bulan Ramadan menurut kalender Hijriah perangkat.")
            FastingSchedule.MON_THU -> info("Pengingat hanya berjalan setiap hari Senin dan Kamis.")
            else -> info("Pilih jenis puasa di atas untuk mengatur tanggal pengingat.")
        }

        bagian("Pengingat waktu sahur", 17f)
        info("Pengingat sahur dihitung mundur dari waktu Imsak dan hanya berbunyi pada tanggal puasa yang cocok dengan pilihan di atas.")
        saklar("Aktifkan pengingat waktu sahur", pp.sahurReminderEnabled) {
            pp.sahurReminderEnabled = it
            PrayerAlarm.scheduleAll(this)
            toast(if (it) "Pengingat sahur diaktifkan" else "Pengingat sahur dinonaktifkan")
        }
        val nilaiSahur = PrayerPrefs.PILIHAN_SAHUR_MENIT
        val pilihanSahur = nilaiSahur.map { it.toString() + " menit sebelum Imsak" }
        pilihan("Waktu pengingat sahur", pilihanSahur, nilaiSahur.indexOf(pp.sahurReminderMinutes).coerceAtLeast(0)) { idx ->
            pp.sahurReminderMinutes = nilaiSahur[idx]
            PrayerAlarm.scheduleAll(this)
            toast(("Pengingat sahur dijadwalkan " + (nilaiSahur[idx]) + " menit sebelum Imsak"))
        }
        bagian("Pengingat waktu Imsak", 17f)
        info("Pengingat Imsak mengikuti waktu Imsak lokal dan hanya dijadwalkan pada tanggal puasa yang dipilih. Suara Imsak tetap diatur melalui menu Suara azan dan tes suara.")
        saklar("Aktifkan pengingat waktu Imsak pada hari puasa", pp.reminder("imsak")) {
            pp.setReminder("imsak", it)
            PrayerAlarm.scheduleAll(this)
            toast(if (it) "Pengingat Imsak pada hari puasa diaktifkan" else "Pengingat Imsak dinonaktifkan")
        }
        bagian("Pengingat waktu berbuka puasa", 17f)
        info("Pengingat berbuka mengikuti jadwal Maghrib lokasi Anda, hanya pada tanggal puasa yang dipilih. Suara tetap memakai pilihan yang sudah tersedia.")
        saklar("Aktifkan pengingat waktu berbuka puasa", pp.berbukaReminderEnabled) { aktif ->
            pp.berbukaReminderEnabled = aktif
            PrayerAlarm.scheduleAll(this)
            toast(if (aktif) "Pengingat berbuka puasa diaktifkan" else "Pengingat berbuka puasa dinonaktifkan")
        }
        val offsetBerbuka = listOf(-30, -15, -10, -5, 0, 5, 10)
        val labelBerbuka = listOf("30 menit sebelum Maghrib", "15 menit sebelum Maghrib", "10 menit sebelum Maghrib", "5 menit sebelum Maghrib", "Tepat saat Maghrib", "5 menit setelah Maghrib", "10 menit setelah Maghrib")
        pilihan("Waktu pemutaran pengingat berbuka", labelBerbuka, offsetBerbuka.indexOf(pp.berbukaOffsetMinutes).coerceAtLeast(0)) { idx ->
            pp.berbukaOffsetMinutes = offsetBerbuka[idx]
            PrayerAlarm.scheduleAll(this)
            toast("Waktu pengingat berbuka: " + labelBerbuka[idx])
        }

    }

    private fun pilihTanggalSyawal() {
        val hijriYear = FastingSchedule.upcomingShawwalYear(this)
        val options = FastingSchedule.shawwalDates(this, hijriYear)
        if (options.isEmpty()) {
            toast("Tanggal Syawal belum dapat disiapkan pada kalender perangkat")
            return
        }
        val stored = pp.shawwalSelectedDates
        val labels = options.map { (hijriDay, date) -> ("" + (hijriDay) + " Syawal " + (hijriYear) + " Hijriah, " + (date.dayOfMonth) + "/" + (date.monthValue) + "/" + (date.year)) }.toTypedArray()
        val checked = BooleanArray(options.size) { options[it].second.toString() in stored }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.judul_pilih_tanggal_puasa_syawal, hijriYear))
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(ui("Simpan tanggal")) { _, _ ->
                pp.shawwalSelectedDates = options.indices.filter { checked[it] }.map { options[it].second.toString() }.toSet()
                PrayerAlarm.scheduleAll(this)
                toast(if (BahasaAplikasi.tampilan(this) == 1) ("Shawwal fasting dates saved: " + pp.shawwalSelectedDates.size + " dates") else ("Tanggal puasa Syawal disimpan: " + (pp.shawwalSelectedDates.size) + " tanggal"))
                recreate()
            }
            .setNegativeButton(ui("Batal"), null)
            .show()
    }

    /** Daftar melodi tetap terbuka saat pratinjau; pilihan disimpan hanya setelah centang lalu Simpan. */
    private fun pilihMelodiBertahap(tajuk: String, terpilihSaatIni: Int, simpan: (Int) -> Unit) {
        val nama = resources.getStringArray(R.array.jam_melodi)
        var sementara = terpilihSaatIni.coerceIn(0, nama.lastIndex)
        val dialog = AlertDialog.Builder(this)
            .setTitle(ui(tajuk))
            .setSingleChoiceItems(nama.map { ui(it) }.toTypedArray(), sementara) { _, which ->
                sementara = which
                Melodi.hentikanSemua()
                if (which > 0) Melodi.putar(this, which, volume = 1f)
            }
            .setPositiveButton(ui("Simpan")) { _, _ ->
                Melodi.hentikanSemua()
                simpan(sementara)
                toast(ui("Pilihan melodi disimpan"))
                recreate()
            }
            .setNegativeButton(ui("Batal")) { _, _ -> Melodi.hentikanSemua() }
            .create()
        dialog.setOnCancelListener { Melodi.hentikanSemua() }
        dialog.setOnDismissListener { Melodi.hentikanSemua() }
        dialog.show()
    }

    private fun grupAwal() {
        judulKelompok("Pengingat sebelum sholat")
        bagian("Pengingat sebelum salat lima waktu")
        info("Aktifkan pengingat pendahuluan untuk Subuh, Dzuhur, Ashar, Maghrib, dan Isya. Pilih apakah pengingat berbunyi 5, 10, 15, atau 30 menit sebelum waktu salat. Pengingat ini terpisah dari pengingat/azan pada waktu salat.")
        val sholatWajib = listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya")
        val pilihanMenit = listOf("5 menit", "10 menit", "15 menit", "30 menit")
        val nilaiMenit = listOf(5, 10, 15, 30)
        for ((name, key) in sholatWajib) {
            bagian(("Pengingat sebelum " + (name)), 17f)
            saklar(("Aktifkan pengingat sebelum " + (name)), pp.advanceReminder(key)) {
                pp.setAdvanceReminder(key, it)
                PrayerAlarm.scheduleAll(this)
                toast(if (it) ("Pengingat sebelum " + (name) + " aktif, " + (pp.advanceMinutes(key)) + " menit sebelumnya") else ("Pengingat sebelum " + (name) + " dinonaktifkan"))
            }
            pilihan(("Waktu pengingat sebelum " + (name)), pilihanMenit, nilaiMenit.indexOf(pp.advanceMinutes(key)).coerceAtLeast(0)) { selected ->
                pp.setAdvanceMinutes(key, nilaiMenit[selected])
                PrayerAlarm.scheduleAll(this)
                toast(("Pengingat " + (name) + " akan berbunyi " + (nilaiMenit[selected]) + " menit sebelum waktu salat"))
            }
            val modeSuaraAwal = pp.advanceSoundMode(key)
            val labelSuaraAwal = when (modeSuaraAwal) {
                1 -> "audio pemberitahuan bawaan aplikasi"
                2 -> "suara pilihan pengguna"
                else -> "suara bicara standar Android"
            }
            info(("Jenis suara pengingat sebelum " + (name) + ": " + (labelSuaraAwal)))
            tombol(("Pilih jenis suara pengingat sebelum " + (name))) {
                val opsi = arrayOf("Suara standar Android", "Suara pemberitahuan bawaan aplikasi", "Pilih berkas suara sendiri")
                AlertDialog.Builder(this)
                    .setTitle(("Jenis suara pengingat sebelum " + (name)))
                    .setSingleChoiceItems(opsi.map { ui(it) }.toTypedArray(), modeSuaraAwal) { dialog, which ->
                        when (which) {
                            0 -> {
                                pp.setAdvanceSoundMode(key, 0)
                                pp.setAdvanceSound(key, "")
                                toast(("Pengingat sebelum " + (name) + " memakai suara standar Android"))
                                dialog.dismiss(); recreate()
                            }
                            1 -> {
                                pp.setAdvanceSoundMode(key, 1)
                                toast(("Pengingat sebelum " + (name) + " memakai audio pemberitahuan bawaan aplikasi"))
                                dialog.dismiss(); recreate()
                            }
                            2 -> {
                                dialog.dismiss()
                                pilihBerkas(requestAdvancePrayer(key))
                            }
                        }
                    }
                    .setNegativeButton(ui("Batal"), null)
                    .show()
            }
            tombol(("Putar atau jeda tes suara pengingat sebelum " + (name))) { tesPengingatAwal(key) }
            tombol(("Kembalikan suara standar Android untuk pengingat sebelum " + (name))) {
                pp.setAdvanceSoundMode(key, 0)
                pp.setAdvanceSound(key, "")
                toast(("Suara pengingat sebelum " + (name) + " dikembalikan ke suara standar Android"))
                recreate()
            }
        }

    }

    /** FIX264: Sholawat Tarhim diputar otomatis sebelum waktu salat; aktif/nonaktif dan waktu mulai diatur per salat. */
    private fun grupTarhim() {
        judulKelompok(tr("Tarhim sebelum sholat", "Tarhim before prayer"))
        info(tr("Sholawat Tarhim diputar otomatis sebelum azan. Aktifkan hanya untuk waktu sholat yang Anda perlukan, misalnya Subuh, lalu pilih berapa menit sebelum waktu sholat Tarhim mulai diputar. Tarhim berdurasi sekitar 6 menit, jadi pilih minimal 10 menit agar selesai sebelum azan. Fitur ini nonaktif secara bawaan, mengikuti sakelar Aktifkan pengingat waktu sholat di halaman utama, dan dapat dihentikan dengan menelungkupkan HP atau menekan tombol volume.",
            "Sholawat Tarhim plays automatically before the adhan. Turn it on only for the prayer times you need, for example Fajr, then choose how many minutes before the prayer time Tarhim starts. Tarhim lasts about 6 minutes, so choose at least 10 minutes so it finishes before the adhan. This feature is off by default, follows the Enable prayer time reminders switch on the main page, and can be stopped by placing the phone face down or pressing a volume button."))
        val inggris = mapOf("subuh" to "Fajr", "dzuhur" to "Dhuhr", "ashar" to "Asr", "maghrib" to "Maghrib", "isya" to "Isha")
        val nilaiMenit = listOf(10, 15, 20, 30, 45, 60)
        val pilihanMenit = nilaiMenit.map { tr("" + it + " menit sebelum sholat", "" + it + " minutes before prayer") }
        for ((name, key) in advancePrayerNames) {
            val nama = tr(name, inggris[key] ?: name)
            bagian(tr("Tarhim sebelum ", "Tarhim before ") + nama, 17f)
            saklar(tr("Aktifkan Tarhim sebelum ", "Turn on Tarhim before ") + nama, pp.tarhimAktif(key)) {
                pp.setTarhimAktif(key, it)
                PrayerAlarm.scheduleAll(this)
                toast(if (it) (if (pp.tarhimMenit(key) == 0) tr("Tarhim sebelum " + name + " aktif, otomatis selesai sebelum azan", "Tarhim before " + nama + " is on, automatically ending before the adhan") else tr("Tarhim sebelum " + name + " aktif, " + pp.tarhimMenit(key) + " menit sebelumnya", "Tarhim before " + nama + " is on, " + pp.tarhimMenit(key) + " minutes before"))
                    else tr("Tarhim sebelum " + name + " dinonaktifkan", "Tarhim before " + nama + " is off"))
            }
            val menitTarhim = listOf(0, 10, 15, 20, 30)
            val labelTarhim = listOf(tr("Otomatis: selesai sebelum azan", "Automatic: ends before the adhan"), tr("10 menit", "10 minutes"), tr("15 menit", "15 minutes"), tr("20 menit", "20 minutes"), tr("30 menit", "30 minutes"))
            pilihan(tr("Waktu mulai Tarhim sebelum ", "Tarhim start time before ") + nama, labelTarhim, menitTarhim.indexOf(pp.tarhimMenit(key)).coerceAtLeast(0)) { selected ->
                pp.setTarhimMenit(key, menitTarhim[selected])
                PrayerAlarm.scheduleAll(this)
                toast(if (menitTarhim[selected] == 0) tr("Tarhim " + name + " akan diputar penuh dan selesai sebelum azan", "Tarhim for " + nama + " will play in full and end before the adhan")
                    else tr("Tarhim " + name + " akan diputar " + menitTarhim[selected] + " menit sebelum waktu sholat", "Tarhim for " + nama + " will play " + menitTarhim[selected] + " minutes before the prayer time"))
            }
            // FIX315: berkas audio Tarhim sendiri per waktu salat; tanpa pilihan, Tarhim bawaan aplikasi yang diputar.
            val berkasT = pp.tarhimBerkas(key)
            info(if (berkasT.isBlank()) tr("Sumber Tarhim " + name + ": bawaan aplikasi.", "Tarhim source for " + nama + ": built into the app.")
                else tr("Sumber Tarhim " + name + ": berkas Anda, ", "Tarhim source for " + nama + ": your file, ") + namaBerkasSuara(berkasT))
            tombol(tr("Pilih berkas audio Tarhim sendiri untuk ", "Choose your own Tarhim audio file for ") + nama) { pilihBerkas(100 + advancePrayerNames.indexOfFirst { it.second == key }) }
            if (berkasT.isNotBlank()) tombol(tr("Kembalikan ke Tarhim bawaan untuk ", "Restore the built-in Tarhim for ") + nama) {
                pp.setTarhimBerkas(key, "")
                toast(tr("Tarhim " + name + " kembali memakai suara bawaan.", "Tarhim for " + nama + " uses the built-in sound again."))
                ulangiTesAktifJikaAda(); recreate()
            }
            tombol(tr("Putar atau jeda tes Tarhim ", "Play or pause Tarhim test ") + nama) { tesTarhim(key) }
        }
    }

    /** FIX277: Iqomah diputar otomatis setelah azan; aktif/nonaktif dan jarak waktunya diatur per sholat. */
    private fun grupIqomah() {
        judulKelompok(tr("Iqomah setelah azan", "Iqomah after adhan"))
        info(tr("Suara iqomah diputar otomatis setelah azan, sesuai jarak waktu yang Anda pilih untuk setiap sholat. Jarak dihitung dari waktu masuk sholat (saat azan dimulai); azan bawaan berdurasi sekitar 4 menit sehingga pilihan terkecil adalah 5 menit. Bawaan: Subuh 15 menit, Maghrib 7 menit, lainnya 10 menit. Iqomah nonaktif secara bawaan; aktifkan hanya untuk sholat yang Anda perlukan. Pada hari Jumat tidak ada iqomah untuk Dzuhur. Tombol volume atau menelungkupkan HP menghentikan iqomah yang sedang berbunyi.",
            "The iqomah sound plays automatically after the adhan, at the interval you choose for each prayer. The interval is counted from the prayer time (when the adhan starts); the built-in adhan lasts about 4 minutes, so the smallest choice is 5 minutes. Defaults: Fajr 15 minutes, Maghrib 7 minutes, others 10 minutes. Iqomah is off by default; turn it on only for the prayers you need. On Fridays there is no iqomah for Dhuhr. Pressing a volume button or placing the phone face down stops an iqomah that is playing."))
        val inggris = mapOf("subuh" to "Fajr", "dzuhur" to "Dhuhr", "ashar" to "Asr", "maghrib" to "Maghrib", "isya" to "Isha")
        val nilaiMenit = PrayerPrefs.PILIHAN_IQOMAH
        val pilihanMenit = nilaiMenit.map { tr("" + it + " menit setelah waktu sholat", "" + it + " minutes after prayer time") }
        for ((name, key) in advancePrayerNames) {
            val nama = tr(name, inggris[key] ?: name)
            bagian(tr("Iqomah ", "Iqomah ") + nama, 17f)
            saklar(tr("Aktifkan iqomah setelah azan ", "Turn on iqomah after adhan ") + nama, pp.iqomahAktif(key)) {
                pp.setIqomahAktif(key, it)
                PrayerAlarm.scheduleAll(this)
                toast(if (it) tr("Iqomah " + name + " aktif, " + pp.iqomahMenit(key) + " menit setelah waktu sholat", "Iqomah for " + nama + " is on, " + pp.iqomahMenit(key) + " minutes after prayer time")
                    else tr("Iqomah " + name + " dinonaktifkan", "Iqomah for " + nama + " is off"))
            }
            pilihan(tr("Jarak iqomah setelah waktu ", "Iqomah interval after ") + nama, pilihanMenit, nilaiMenit.indexOf(pp.iqomahMenit(key)).coerceAtLeast(0)) { selected ->
                pp.setIqomahMenit(key, nilaiMenit[selected])
                PrayerAlarm.scheduleAll(this)
                toast(tr("Iqomah " + name + " akan diputar " + nilaiMenit[selected] + " menit setelah waktu sholat", "Iqomah for " + nama + " will play " + nilaiMenit[selected] + " minutes after the prayer time"))
            }
            tombol(tr("Putar atau jeda tes iqomah ", "Play or pause iqomah test ") + nama) { tesIqomah(key) }
        }
    }

    private fun tesIqomah(key: String) {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        val aktif = tesAktifNyata()
        val kunciAktif = state.getString("test_playback_key", "") ?: ""
        val i = if (aktif && kunciAktif == "iqomah_" + key) {
            Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        } else {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("iqomah_reminder", true).putExtra("test", true)
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast(tr("Tes iqomah tidak dapat dijalankan. Periksa izin notifikasi.", "The iqomah test cannot run. Check the notification permission.")) }
        umpanBalikTes()
    }

    private fun tesTarhim(key: String) {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        val aktif = tesAktifNyata()
        val kunciAktif = state.getString("test_playback_key", "") ?: ""
        val i = if (aktif && kunciAktif == "tarhim_" + key) {
            Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        } else {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("tarhim_reminder", true).putExtra("test", true)
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast(tr("Tes Tarhim tidak dapat dijalankan. Periksa izin notifikasi.", "The Tarhim test cannot run. Check the notification permission.")) }
        umpanBalikTes()
    }

    private fun grupDnd() {
        judulKelompok("Mode Jangan Ganggu saat sholat")
        bagian("Mode Jangan Ganggu otomatis saat salat")
        info("Aplikasi dapat mengaktifkan Mode Jangan Ganggu saat waktu salat dan mengembalikan mode ponsel ke keadaan sebelumnya setelah durasi pilihan. Android meminta izin khusus sebelum aplikasi boleh mengubah Mode Jangan Ganggu.")
        saklar("Aktifkan Mode Jangan Ganggu otomatis saat waktu salat", pp.dndEnabled) { enabled ->
            pp.dndEnabled = enabled
            PrayerAlarm.scheduleAll(this)
            if (enabled) mintaAksesJanganGanggu()
            toast(if (enabled) "Mode Jangan Ganggu otomatis diaktifkan untuk salat yang dipilih" else "Mode Jangan Ganggu otomatis dinonaktifkan")
        }
        // Setiap pilihan dibaca pembaca layar apa adanya, jadi ditulis lengkap per bahasa ("45 menit" / "45 minutes"),
        // tanpa templat teks yang dapat terbaca sebagai teks mentah.
        val inggrisDnd = BahasaAplikasi.tampilan(this) == 1
        val labelDurasiDnd = PrayerPrefs.DURASI_DND_MENIT.map { it.toString() + (if (inggrisDnd) " minutes" else " menit") }
        pilihan("Durasi Mode Jangan Ganggu", labelDurasiDnd, PrayerPrefs.DURASI_DND_MENIT.indexOf(pp.dndDuration).coerceAtLeast(0)) { selected ->
            pp.dndDuration = PrayerPrefs.DURASI_DND_MENIT[selected]
            PrayerAlarm.scheduleAll(this)
            toast(if (inggrisDnd) ("Do Not Disturb mode will last " + pp.dndDuration + " minutes") else ("Mode Jangan Ganggu akan berlangsung " + pp.dndDuration + " menit"))
        }
        tombol("Izinkan aplikasi mengatur Mode Jangan Ganggu") { mintaAksesJanganGanggu() }
        tombol("Periksa atau izinkan alarm tepat waktu") { bukaIzinAlarm() }
        alarmPermissionStatus = info("")
        segarkanStatusIzinAlarm()
        for ((name, key) in listOf("Subuh" to "subuh", "Dzuhur" to "dzuhur", "Ashar" to "ashar", "Maghrib" to "maghrib", "Isya" to "isya", "Tahajud" to "tahajud", "Dhuha" to "dhuha")) {
            saklar(("Mode Jangan Ganggu saat " + (name)), pp.dndPrayer(key)) { enabled ->
                pp.setDndPrayer(key, enabled); PrayerAlarm.scheduleAll(this)
                toast(if (enabled) ("Mode Jangan Ganggu saat " + (name) + " aktif") else ("Mode Jangan Ganggu saat " + (name) + " dinonaktifkan"))
            }
        }
        // FIX358: pengaturan Jumat tersendiri, durasinya terpisah dari salat lima waktu.
        bagian("Mode Jangan Ganggu salat Jumat")
        info("Pada hari Jumat, saat waktu Dzuhur, aplikasi memakai pengaturan ini, bukan pengaturan Dzuhur di atas. Durasinya dapat dibuat lebih panjang karena khutbah dan salat Jumat lebih lama daripada salat lima waktu.")
        saklar("Mode Jangan Ganggu saat salat Jumat", pp.dndJumat) { enabled ->
            pp.dndJumat = enabled; PrayerAlarm.scheduleAll(this)
            toast(if (enabled) "Mode Jangan Ganggu salat Jumat aktif" else "Mode Jangan Ganggu salat Jumat dinonaktifkan")
        }
        val labelDurasiJumat = PrayerPrefs.DURASI_DND_JUMAT_MENIT.map { it.toString() + (if (inggrisDnd) " minutes" else " menit") }
        pilihan("Durasi Mode Jangan Ganggu salat Jumat", labelDurasiJumat, PrayerPrefs.DURASI_DND_JUMAT_MENIT.indexOf(pp.dndJumatDuration).coerceAtLeast(0)) { selected ->
            pp.dndJumatDuration = PrayerPrefs.DURASI_DND_JUMAT_MENIT[selected]
            PrayerAlarm.scheduleAll(this)
            toast(if (inggrisDnd) ("Friday prayer Do Not Disturb will last " + pp.dndJumatDuration + " minutes") else ("Mode Jangan Ganggu salat Jumat akan berlangsung " + pp.dndJumatDuration + " menit"))
        }

    }

    private fun grupSuara() {
        judulKelompok("Suara azan dan tes suara")
        bagian("Cara cepat menghentikan suara azan dan notifikasi")
        info("Aktifkan fitur ini agar azan, pengingat, pengumuman baterai dan jam, nama pemanggil, serta suara notifikasi aplikasi lainnya yang sedang berbunyi dapat dihentikan dengan menelungkupkan HP di permukaan datar. HP harus terdeteksi tidak telungkup lebih dahulu, lalu ditelungkupkan sekitar satu detik. Cara ini tidak berlaku untuk tes suara di pengaturan. Tombol Hentikan suara azan pada notifikasi tetap tersedia.")
        saklar("Hentikan azan dan semua suara notifikasi dengan menelungkupkan HP", pp.stopAzanFaceDown) { enabled ->
            pp.stopAzanFaceDown = enabled
            toast(if (enabled) "Menelungkupkan HP akan menghentikan azan dan suara notifikasi" else "Penghentian suara dengan menelungkupkan HP dinonaktifkan")
        }
        info("Selama azan, alarm, pengingat, pengumuman baterai dan jam, atau nama pemanggil sedang berbunyi, tekan tombol volume atas atau bawah untuk menghentikannya. Berlaku juga saat layar mati atau aplikasi tidak sedang dibuka. Bila tidak ada suara aplikasi yang berbunyi, tombol volume bekerja seperti biasa.")
        saklar("Hentikan azan dan semua suara notifikasi dengan tombol volume", pp.stopDenganVolume) { enabled ->
            pp.stopDenganVolume = enabled
            toast(if (enabled) "Menekan tombol volume akan menghentikan azan dan suara notifikasi" else "Penghentian suara dengan tombol volume dinonaktifkan")
        }

        bagian("Sumber suara pengingat dan azan")
        info("Pilih berkas audio dari penyimpanan internal untuk semua waktu atau atur suara berbeda bagi Imsak, Subuh, Terbit, Dhuha, Tahajud, Dzuhur, Ashar, Maghrib, dan Isya. Saat tes sedang diputar, gunakan tombol Jeda tes suara azan, Lanjutkan tes suara azan, atau Hentikan tes suara azan di bawah. Tombol-tombol ini hanya untuk tes di pengaturan, bukan azan normal.")
        bagian("Kontrol tes suara azan", 17f)
        info("Gunakan satu tombol ini saja. Ketuk pertama untuk memutar tes; ketika suara berjalan, ketuk lagi untuk menjeda; ketuk sekali lagi untuk melanjutkan dari posisi terakhir. Ketuk lama tidak diperlukan. Untuk menghentikan tes, gunakan tombol Hentikan tes di bagian bawah atau tindakan pada notifikasi.")
        val tombolTes = tombol(labelTombolTes()) { toggleTesAzan() }
        tombolTes.contentDescription = ui(labelTombolTes())
        tombolTesRef = tombolTes
        // Layanan memperbarui status tes secara asinkron; baca ulang label setelah jeda singkat
        // agar tombol tidak menyebut keadaan sebelumnya (mis. tetap "Putar" padahal sudah diputar).
        tombolTes.setOnClickListener {
            toggleTesAzan()
            for (tunda in longArrayOf(400L, 1200L)) tombolTes.postDelayed({ segarkanLabelTes() }, tunda)
        }
        tombol("Pilih berkas azan cadangan untuk semua waktu") { pilihBerkas(requestGlobal) }
        info(("Berkas semua waktu: " + (if (pp.globalSound.isBlank()) "azan bawaan" else namaBerkasSuara(pp.globalSound))))
        tombol("Hapus berkas azan semua waktu") { pp.globalSound = ""; ulangiTesAktifJikaAda(); toast("Berkas semua waktu dihapus"); recreate() }
        tombol("Hapus semua berkas azan pilihan") {
            pp.globalSound = ""
            for ((_, key) in prayerNames) pp.setSound(key, "")
            ulangiTesAktifJikaAda()
            toast("Semua berkas azan pilihan dihapus"); recreate()
        }
        info("Pilih kelompok volume yang mengatur keras-lembutnya suara azan dan seluruh suara pengingat. Pilihan ini mengikuti pola Keluaran suara pada fitur Baterai, Jam, dan Nama Pemanggil.")
        pilihan(tr("Suara azan bawaan aplikasi", "Built-in adhan sound"), listOf(tr("Azan Muamar ZA (versi baru)", "Adhan by Muamar ZA (new version)"), tr("Azan versi lama", "Old version adhan")), pp.azanBawaan) { pp.azanBawaan = it; ulangiTesAktifJikaAda() }
        pilihan("Jenis volume azan / Keluaran suara", larik(R.array.keluaran), pp.volumeMode) { pp.volumeMode = it }
        for ((name, key) in prayerNames) {
            bagian(("Suara pengingat " + (name)), 17f)
            if (key == "imsak" || key == "terbit" || key == "dhuha" || key == "tahajud") {
                val mode = pp.reminderSoundMode(key)
                // FIX238: pilihan bawaan Tahajud hanya ditawarkan bila audionya ada di aplikasi.
                val tanpaBawaan = key == "tahajud" && AudioBawaanPengingat.id(this, key) <= 0
                val urutanPilihan = if (tanpaBawaan) listOf(0, 2) else listOf(0, 1, 2)
                val modeLabel = when (mode) {
                    1 -> ("suara pengingat " + (name) + " bawaan aplikasi")
                    2 -> "berkas suara mandiri pilihan pengguna"
                    3 -> ("audio " + (name) + " bawaan aplikasi")
                    else -> if (pp.globalSound.isBlank()) "suara azan bawaan aplikasi" else "berkas suara umum pilihan pengguna"
                }
                info(("Jenis suara saat " + (name) + ": " + (modeLabel)))
                tombol(("Pilih jenis suara untuk " + (name))) {
                    val semuaPilihan = arrayOf("Suara azan bawaan atau suara umum", ("Suara pengingat " + (name) + " bawaan aplikasi"), "Pilih berkas suara sendiri dari penyimpanan")
                    val pilihanSuara = urutanPilihan.map { semuaPilihan[it] }
                    AlertDialog.Builder(this)
                        .setTitle(("Jenis suara pengingat " + (name)))
                        .setSingleChoiceItems(pilihanSuara.map { ui(it) }.toTypedArray(), urutanPilihan.indexOf(mode.coerceIn(0, 2)).coerceAtLeast(0)) { dialog, pilihanKe ->
                            when (urutanPilihan[pilihanKe]) {
                                0 -> {
                                    pp.setReminderSoundMode(key, 0)
                                    toast(("" + (name) + " memakai suara azan bawaan atau suara umum"))
                                    dialog.dismiss(); recreate()
                                }
                                1 -> {
                                    pp.setReminderSoundMode(key, 1)
                                    toast(("" + (name) + " memakai suara pengingat bawaan aplikasi"))
                                    dialog.dismiss(); recreate()
                                }
                                2 -> {
                                    dialog.dismiss()
                                    pilihBerkas(requestPrayer(key))
                                }
                            }
                        }.setNegativeButton(ui("Batal"), null).show()
                }
                info(("Berkas mandiri tersimpan: " + (if (pp.sound(key).isBlank()) "belum dipilih" else namaBerkasSuara(pp.sound(key)))))
            } else {
                info(("Sumber suara: " + (if (pp.sound(key).isBlank()) if (pp.globalSound.isBlank()) if (key == "subuh") "azan Subuh bawaan" else "azan umum bawaan" else "berkas semua waktu" else pp.sound(key))))
            }
            tombol(("Pilih berkas suara " + (name))) { pilihBerkas(requestPrayer(key)) }
            tombol(if (key == "dhuha") "Putar atau jeda tes suara pengingat Dhuha" else ("Putar atau jeda tes suara azan " + (name))) { tesAzan(key) }
            tombol(("Gunakan suara umum atau bawaan untuk " + (name))) {
                pp.setSound(key, "")
                if (key == "imsak" || key == "terbit") pp.setReminderSoundMode(key, 0)
                if (key == "dhuha") pp.setReminderSoundMode(key, 1)
                if (key == "tahajud") pp.setReminderSoundMode(key, if (AudioBawaanPengingat.id(this, key) > 0) 1 else 0)
                if ((getSharedPreferences("jadwal_sholat", MODE_PRIVATE).getString("test_playback_key", "subuh") ?: "subuh") == key) ulangiTesAktifJikaAda()
                recreate()
            }
        }
        bagian("Suara pemberitahuan sahur", 17f)
        val modeSahur = pp.reminderSoundMode("sahur")
        info("Jenis suara sahur: " + when (modeSahur) {
            1 -> "ucapan pemberitahuan sahur melalui mesin TTS"
            2 -> "berkas suara mandiri pilihan pengguna"
            3 -> "audio pemberitahuan sahur bawaan aplikasi"
            else -> if (pp.globalSound.isBlank()) "suara azan bawaan aplikasi" else "berkas suara umum pilihan pengguna"
        })
        tombol("Pilih jenis suara pemberitahuan sahur") {
            val opsi = arrayOf("Suara azan bawaan atau suara umum", "Ucapan pemberitahuan sahur melalui TTS", "Pilih berkas suara sendiri dari penyimpanan", "Audio pemberitahuan sahur bawaan aplikasi")
            AlertDialog.Builder(this).setTitle(getString(R.string.judul_suara_pemberitahuan_sahur))
                .setSingleChoiceItems(opsi.map { ui(it) }.toTypedArray(), modeSahur) { dialog, which ->
                    when (which) {
                        0 -> { pp.setReminderSoundMode("sahur", 0); dialog.dismiss(); recreate() }
                        1 -> { pp.setReminderSoundMode("sahur", 1); dialog.dismiss(); recreate() }
                        2 -> { dialog.dismiss(); pilihBerkas(requestSahurSound) }
                        3 -> { pp.setReminderSoundMode("sahur", 3); pp.setSound("sahur", ""); dialog.dismiss(); recreate() }
                    }
                }.setNegativeButton(ui("Batal"), null).show()
        }
        info("Berkas suara sahur tersimpan: " + if (pp.sound("sahur").isBlank()) "belum dipilih" else namaBerkasSuara(pp.sound("sahur")))
        tombol("Pilih berkas suara pemberitahuan sahur") { pilihBerkas(requestSahurSound) }
        tombol("Putar atau jeda tes suara pemberitahuan sahur") { tesAzan("sahur") }
        tombol("Gunakan suara umum atau bawaan untuk pemberitahuan sahur") { pp.setSound("sahur", ""); pp.setReminderSoundMode("sahur", 0); recreate() }
        bagian("Suara pemberitahuan berbuka puasa", 17f)
        info("Jenis suara berbuka puasa: " + when (pp.reminderSoundMode("berbuka")) {
            1, 3 -> "audio pengingat berbuka puasa bawaan aplikasi"
            2 -> "berkas suara pilihan pengguna"
            else -> if (pp.globalSound.isBlank()) "suara azan bawaan aplikasi" else "berkas suara umum pilihan pengguna"
        })
        tombol("Pilih jenis suara pemberitahuan berbuka puasa") {
            val modeBerbuka = pp.reminderSoundMode("berbuka")
            val opsi = arrayOf("Suara azan bawaan atau suara umum", "Audio berbuka puasa bawaan aplikasi", "Pilih berkas suara sendiri dari penyimpanan")
            AlertDialog.Builder(this).setTitle(getString(R.string.judul_suara_pemberitahuan_berbuka))
                .setSingleChoiceItems(opsi.map { ui(it) }.toTypedArray(), when (modeBerbuka) { 1, 3 -> 1; 2 -> 2; else -> 0 }) { dialog, which ->
                    when (which) {
                        0 -> { pp.setReminderSoundMode("berbuka", 0); dialog.dismiss(); recreate() }
                        1 -> { pp.setReminderSoundMode("berbuka", 3); pp.setSound("berbuka", ""); dialog.dismiss(); recreate() }
                        2 -> { dialog.dismiss(); pilihBerkas(requestBerbukaSound) }
                    }
                }.setNegativeButton(ui("Batal"), null).show()
        }
        info("Berkas suara berbuka tersimpan: " + if (pp.sound("berbuka").isBlank()) "belum dipilih" else namaBerkasSuara(pp.sound("berbuka")))
        tombol("Pilih berkas suara pemberitahuan berbuka puasa") { pilihBerkas(requestBerbukaSound) }
        tombol("Putar atau jeda tes suara pemberitahuan berbuka puasa") { tesAzan("berbuka") }
        tombol("Gunakan audio berbuka puasa bawaan aplikasi") { pp.setSound("berbuka", ""); pp.setReminderSoundMode("berbuka", 3); recreate() }
        tombol("Tes suara azan Subuh") { tesAzan("subuh") }
        tombol("Hentikan tes suara azan") { kontrolTes("STOP_TEST_PLAYBACK"); recreate() }

    }

    /** FIX300: volume mandiri dan efek gema untuk setiap fitur yang memutar suara (azan, pengingat sebelum sholat, Tarhim, Iqomah, sahur, berbuka). */
    private fun grupSuaraMandiri() {
        judulKelompok(tr("Volume mandiri dan efek gema", "Independent volume and echo effect"))
        info(tr("Atur kekerasan suara dan efek gema untuk setiap suara pengingat. Volume mandiri adalah pengali pada suara aplikasi (100 persen berarti tanpa perubahan); volume HP tetap diatur oleh tombol volume sistem sesuai saluran yang dipilih. Efek gema berlaku pada suara berkas audio; ucapan mesin suara pada pengingat sebelum sholat tidak ikut berubah.",
            "Set the loudness and echo effect for each reminder sound. Independent volume is a multiplier on the app sound (100 percent means no change); the phone volume is still set by the system volume buttons for the chosen channel. The echo effect applies to audio file sounds; speech from the voice engine in reminders before prayer is not affected."))
        val inggris = mapOf("subuh" to "Fajr", "dzuhur" to "Dhuhr", "ashar" to "Asr", "maghrib" to "Maghrib", "isya" to "Isha",
            "imsak" to "Imsak", "terbit" to "Sunrise", "dhuha" to "Duha", "tahajud" to "Tahajjud")
        bagian(tr("Suara azan dan pengingat waktu", "Adhan and time reminder sounds"), 17f)
        for ((name, key) in prayerNames) {
            val nama = tr(name, inggris[key] ?: name)
            barisSuaraMandiri(nama, "azan_" + key) { tesAzan(key) }
        }
        bagian(tr("Pengingat sebelum sholat", "Reminder before prayer"), 17f)
        for ((name, key) in advancePrayerNames) {
            val nama = tr(name, inggris[key] ?: name)
            barisSuaraMandiri(tr("Pengingat sebelum ", "Reminder before ") + nama, "advance_" + key) { tesPengingatAwal(key) }
        }
        bagian("Tarhim", 17f)
        for ((name, key) in advancePrayerNames) {
            val nama = tr(name, inggris[key] ?: name)
            barisSuaraMandiri(tr("Tarhim sebelum ", "Tarhim before ") + nama, "tarhim_" + key) { tesTarhim(key) }
        }
        bagian(tr("Iqomah", "Iqomah"), 17f)
        for ((name, key) in advancePrayerNames) {
            val nama = tr(name, inggris[key] ?: name)
            barisSuaraMandiri(tr("Iqomah ", "Iqomah ") + nama, "iqomah_" + key) { tesIqomah(key) }
        }
        bagian(tr("Sahur dan berbuka puasa", "Suhoor and iftar"), 17f)
        barisSuaraMandiri(tr("Pemberitahuan sahur", "Suhoor notification"), "sahur") { tesAzan("sahur") }
        barisSuaraMandiri(tr("Pemberitahuan berbuka puasa", "Iftar notification"), "berbuka") { tesAzan("berbuka") }
    }

    private fun ringkasSuaraMandiri(kunci: String): String {
        val g = pp.gemaMandiri(kunci)
        return tr("volume " + pp.volumeMandiri(kunci) + " persen, gema ", "volume " + pp.volumeMandiri(kunci) + " percent, echo ") +
            (if (g == "normal") tr("mati", "off") else GemaAudio(this).label(g) + " " + pp.gemaKekuatan(kunci) + "%")
    }

    private fun barisSuaraMandiri(nama: String, kunci: String, tes: () -> Unit) {
        tombol(nama + ": " + ringkasSuaraMandiri(kunci)) { dialogSuaraMandiri(nama, kunci, tes) }
    }

    private fun dialogSuaraMandiri(nama: String, kunci: String, tes: () -> Unit) {
        val isi = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8)) }
        fun teksLabel() = TextView(this).apply { textSize = 16f; setTextColor(warnaTeks()); setPadding(0, dp(10), 0, dp(2)) }
        // FIX311: perubahan ditampung sebagai draf; baru tersimpan setelah menekan Simpan. Putar contoh gema hanya mendengarkan.
        var volDraf = pp.volumeMandiri(kunci)
        var gemaDraf = pp.gemaMandiri(kunci)
        var kuatDraf = pp.gemaKekuatan(kunci)
        isi.addView(android.widget.TextView(this).apply {
            text = ui(tr("Perubahan di sini baru tersimpan setelah Anda menekan tombol Simpan. Tombol Putar contoh gema hanya untuk mendengarkan (suara TTS singkat, bukan azan), tidak menyimpan apa pun.", "Changes here are saved only after you press Save. Play echo sample is only for listening (a short TTS voice, not the adhan) and saves nothing."))
            textSize = 14f; setTextColor(warnaTeks()); setPadding(0, 0, 0, dp(4))
        })
        val labelVol = teksLabel()
        val barVol = android.widget.SeekBar(this).apply { max = 100; progress = volDraf }
        fun perbaruiVol() { labelVol.text = ui(tr("Volume mandiri: ", "Independent volume: ")) + barVol.progress + "%"; barVol.contentDescription = labelVol.text }
        perbaruiVol()
        barVol.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) { volDraf = progress; perbaruiVol() }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) { seekBar?.announceForAccessibility(labelVol.text) }
        })
        isi.addView(labelVol); isi.addView(barVol)
        val labelGema = teksLabel().apply { text = ui(tr("Efek gema", "Echo effect")) }
        isi.addView(labelGema)
        val gema = GemaAudio(this)
        val kunciGema = GemaAudio.daftarKunci
        val namaGema = kunciGema.map { if (it == "normal") tr("Normal (tanpa gema)", "Normal (no echo)") else gema.label(it) }
        val spin = android.widget.Spinner(this)
        spin.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, namaGema.map { ui(it) })
        spin.setSelection(kunciGema.indexOf(gemaDraf).coerceAtLeast(0))
        spin.contentDescription = ui(tr("Pilih efek gema", "Choose echo effect"))
        spin.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) { }
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) { gemaDraf = kunciGema[position] }
        }
        isi.addView(spin)
        val labelKuat = teksLabel()
        val barKuat = android.widget.SeekBar(this).apply { max = 100; progress = kuatDraf }
        fun perbaruiKuat() { labelKuat.text = ui(tr("Kekuatan gema: ", "Echo strength: ")) + barKuat.progress + "%"; barKuat.contentDescription = labelKuat.text }
        perbaruiKuat()
        barKuat.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) { kuatDraf = progress; perbaruiKuat() }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) { }
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) { seekBar?.announceForAccessibility(labelKuat.text) }
        })
        isi.addView(labelKuat); isi.addView(barKuat)
        val simpanDraf = { pp.setVolumeMandiri(kunci, volDraf); pp.setGemaMandiri(kunci, gemaDraf); pp.setGemaKekuatan(kunci, kuatDraf) }
        // Tombol terpisah dan jelas: menyimpan dulu, baru memutar suara asli (azan/pengingat) yang bisa panjang.
        isi.addView(android.widget.Button(this).apply {
            text = ui(tr("Simpan lalu tes suara lengkap (azan atau pengingat, bisa panjang)", "Save, then test the full sound (adhan or reminder, can be long)"))
            setOnClickListener { simpanDraf(); toast(tr("Pengaturan disimpan.", "Settings saved.")); tes() }
        })
        val sv = android.widget.ScrollView(this).apply { addView(isi) }
        AlertDialog.Builder(this).setTitle(ui(nama)).setView(sv)
            .setPositiveButton(ui(tr("Simpan", "Save"))) { _, _ -> simpanDraf(); toast(tr("Pengaturan disimpan.", "Settings saved.")); recreate() }
            .setNegativeButton(ui(tr("Batal", "Cancel"))) { _, _ -> toast(tr("Perubahan tidak disimpan.", "Changes were not saved.")) }
            .setNeutralButton(ui(tr("Putar contoh gema", "Play echo sample")), null)
            .show().also { dlg ->
                // FIX311: contoh hanya mendengarkan draf (tidak menyimpan), memakai suara TTS saja, dan dialog tetap terbuka.
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    try { ContohGema.putar(this, gemaDraf, kuatDraf) { m -> toast(m) } } catch (_: Throwable) { }
                }
                dlg.setOnDismissListener { try { ContohGema.berhenti() } catch (_: Throwable) { } }
            }
    }

    private fun grupKiblat() {
        judulKelompok("Arah kiblat dan kompas")
        bagian("Arah kiblat")
        saklar("Ucapan arah otomatis setiap 1,5 detik", pp.voiceQibla) { pp.voiceQibla = it }
        saklar("Getar panjang saat menghadap kiblat (selisih kurang dari 5 derajat)", pp.qiblaHaptic) { pp.qiblaHaptic = it }
        bagian("Panduan kompas saat layar mati")
        info("Sakelar ini hanya mengatur apakah panduan suara/nada boleh diteruskan saat layar mati. Sakelar tidak membuka atau menjalankan kompas. Untuk memulai panduan, buka halaman arah kiblat dan jarum kompas; jika opsi ini aktif, layanan latar belakang akan mulai saat halaman kompas dibuka.")
        val qiblaBgState = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        saklar("Izinkan panduan kompas tetap berjalan saat layar mati", qiblaBgState.getBoolean("qibla_screen_off_enabled", false)) { enabled ->
            qiblaBgState.edit().putBoolean("qibla_screen_off_enabled", enabled).apply()
            if (!enabled) {
                stopService(Intent(this, QiblaGuidanceService::class.java))
                qiblaBgState.edit().putBoolean("qibla_background_active", false).apply()
                toast("Panduan kompas tidak akan diteruskan saat layar mati.")
            } else {
                toast("Pengaturan disimpan. Buka halaman arah kiblat dan jarum kompas untuk memulai panduan.")
            }
        }
        tombol("Buka halaman arah kiblat dan jarum kompas") { startActivity(Intent(this, QiblaActivity::class.java)) }
    }

    private fun formatJam(total: Int): String {
        val h = (total.coerceIn(0, 1439) / 60).toString().padStart(2, '0')
        val m = (total.coerceIn(0, 1439) % 60).toString().padStart(2, '0')
        return if (pp.use24) ("" + (h) + ":" + (m)) else { val hour = total / 60; "%02d:%02d %s".format(if (hour % 12 == 0) 12 else hour % 12, total % 60, if (hour < 12) "AM" else "PM") }
    }

    /** Tampilkan nama berkas yang ramah pengguna, bukan URI content:// internal Android. */
    private fun namaBerkasSuara(uriText: String): String {
        if (uriText.isBlank()) return ui("belum dipilih")
        return try {
            val uri = Uri.parse(uriText)
            val nama = if (uri.scheme == "content") {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                }
            } else uri.lastPathSegment
            nama?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: uriText
        } catch (_: Exception) {
            uriText.substringAfterLast('/').ifBlank { uriText }
        }
    }

    private fun pilihBerkas(request: Int) {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i, request)
        } catch (e: Exception) { toast("Pemilih berkas tidak dapat dibuka pada perangkat ini.") }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        when (requestCode) {
            requestGlobal -> pp.globalSound = uri.toString()
            requestSahurSound -> { pp.setSound("sahur", uri.toString()); pp.setReminderSoundMode("sahur", 2) }
            requestBerbukaSound -> { pp.setSound("berbuka", uri.toString()); pp.setReminderSoundMode("berbuka", 2) }
            in 100..104 -> {
                val idx = requestCode - 100
                if (idx in advancePrayerNames.indices) pp.setTarhimBerkas(advancePrayerNames[idx].second, uri.toString())
                toast(tr("Berkas Tarhim disimpan.", "Tarhim file saved."))
            }
            in 80..84 -> {
                val idx = requestCode - 80
                if (idx in advancePrayerNames.indices) {
                    val key = advancePrayerNames[idx].second
                    pp.setAdvanceSound(key, uri.toString())
                    pp.setAdvanceSoundMode(key, 2)
                }
            }
            else -> {
                val idx = requestCode - 51
                if (idx in prayerNames.indices) {
                    val key = prayerNames[idx].second
                    pp.setSound(key, uri.toString())
                    if (key == "imsak" || key == "terbit" || key == "dhuha" || key == "tahajud") pp.setReminderSoundMode(key, 2)
                }
            }
        }
        toast("Sumber suara disimpan")
        ulangiTesAktifJikaAda()
        recreate()
    }

    /**
     * FIX242: tes dianggap aktif hanya bila layanan benar-benar sedang menjalankannya. Status di prefs bisa basi
     * (proses dimatikan sistem) sehingga ketukan berikutnya dulu dikira "jeda" padahal tidak ada suara yang berjalan.
     */
    private fun tesAktifNyata(): Boolean {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!state.getBoolean("test_playback_active", false)) return false
        if (PrayerAlarmService.tesBerjalan) return true
        state.edit().putBoolean("test_playback_active", false).putBoolean("test_playback_paused", false).remove("test_playback_key").apply()
        return false
    }

    /** FIX242: umpan balik jelas setelah ketukan putar/jeda, agar pengguna TalkBack tahu keadaan tes sebenarnya. */
    private fun umpanBalikTes() {
        for (tunda in longArrayOf(500L, 1300L)) window.decorView.postDelayed({
            if (isFinishing) return@postDelayed
            segarkanLabelTes()
        }, tunda)
        window.decorView.postDelayed({
            if (isFinishing) return@postDelayed
            val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
            val pesan = when {
                !tesAktifNyata() -> tr("Tes suara dihentikan atau sudah selesai", "Sound test stopped or finished")
                state.getBoolean("test_playback_paused", false) -> tr("Tes suara dijeda. Ketuk lagi untuk melanjutkan", "Sound test paused. Tap again to resume")
                else -> tr("Tes suara sedang diputar. Ketuk lagi untuk menjeda", "Sound test is playing. Tap again to pause")
            }
            toast(pesan)
        }, 700L)
    }

    private fun labelTombolTes(): String {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        return when {
            !tesAktifNyata() -> "Putar tes suara azan"
            state.getBoolean("test_playback_paused", false) -> "Lanjutkan tes suara azan"
            else -> "Jeda tes suara azan"
        }
    }
    private fun toggleTesAzan() {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!tesAktifNyata()) tesAzan("subuh")
        else { kontrolTes("TOGGLE_TEST_PLAYBACK"); umpanBalikTes() }
    }

    private fun tesAzan(key: String) {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        val active = tesAktifNyata()
        val currentKey = state.getString("test_playback_key", "subuh") ?: "subuh"
        // Ketuk tes pada waktu sholat lain berarti pilih dan putar berkasnya yang baru,
        // bukan menjeda pemutar lama. Jika kuncinya sama, tombol tetap berfungsi sebagai jeda/lanjut.
        val i = if (active && currentKey == key) {
            Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        } else {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true).apply {
                if (key == "sahur") putExtra("sahur_reminder", true)
                if (key == "berbuka") putExtra("berbuka_reminder", true)
            }
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Tidak dapat memutar atau menjeda suara. Periksa izin dan berkas audio.") }
        umpanBalikTes()
    }


    private fun tesPengingatAwal(key: String) {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        val aktif = tesAktifNyata()
        val kunciAktif = state.getString("test_playback_key", "") ?: ""
        // Pola putar/jeda sama dengan tes suara azan: mengetuk tes yang sama menjeda atau melanjutkan (bukan memutar ulang dari awal);
        // mengetuk tes lain memulai tes itu.
        val i = if (aktif && kunciAktif == "advance_" + key) {
            Intent(this, PrayerAlarmService::class.java).setAction("com.novan.jambicarapro.TOGGLE_TEST_PLAYBACK")
        } else {
            Intent(this, PrayerAlarmService::class.java)
                .putExtra("prayer_key", key)
                .putExtra("advance_reminder", true)
                .putExtra("test", true)
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Tes suara pengingat tidak dapat dijalankan. Periksa berkas suara dan izin notifikasi.") }
        umpanBalikTes()
    }

    private fun ulangiTesAktifJikaAda() {
        val state = getSharedPreferences("jadwal_sholat", MODE_PRIVATE)
        if (!tesAktifNyata()) return
        val key = state.getString("test_playback_key", "subuh") ?: "subuh"
        val i = if (key.startsWith("iqomah_")) {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key.removePrefix("iqomah_")).putExtra("iqomah_reminder", true).putExtra("test", true)
        } else if (key.startsWith("tarhim_")) {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key.removePrefix("tarhim_")).putExtra("tarhim_reminder", true).putExtra("test", true)
        } else if (key.startsWith("advance_")) {
            Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key.removePrefix("advance_")).putExtra("advance_reminder", true).putExtra("test", true)
        } else Intent(this, PrayerAlarmService::class.java).putExtra("prayer_key", key).putExtra("test", true).apply {
            if (key == "sahur") putExtra("sahur_reminder", true)
            if (key == "berbuka") putExtra("berbuka_reminder", true)
        }
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
        catch (_: Exception) { toast("Berkas tersimpan, tetapi tes audio aktif tidak dapat dimulai ulang.") }
    }
    private fun kontrolTes(action: String) {
        val i = Intent(this, PrayerAlarmService::class.java).setAction(("com.novan.jambicarapro." + (action)))
        // FIX242: perintah kontrol tidak memulai suara baru, jadi tidak memakai startForegroundService (yang mewajibkan startForeground dan bisa membuat aplikasi berhenti bila layanan sudah selesai).
        try { startService(i) }
        catch (_: Exception) { toast("Kontrol tes suara tidak dapat dijalankan. Mulai tes suara terlebih dahulu.") }
    }

    private fun mintaAksesJanganGanggu() {
        if (Build.VERSION.SDK_INT >= 23) {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) { toast("Izin Mode Jangan Ganggu sudah diberikan"); return }
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            catch (_: Exception) { toast("Buka Pengaturan Android, lalu beri akses Jangan Ganggu untuk Jam Pintar Pro") }
        } else toast("Mode Jangan Ganggu otomatis memerlukan Android 6.0 atau lebih baru")
    }

    private fun mintaIzinNotifikasi() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 405)
    }
    private fun segarkanStatusIzinAlarm() {
        val status = if (Build.VERSION.SDK_INT < 31) {
            "Status izin alarm tepat waktu: dikelola otomatis oleh Android pada versi ini."
        } else {
            val am = getSystemService(android.app.AlarmManager::class.java)
            if (am?.canScheduleExactAlarms() == true) {
                "Status izin alarm tepat waktu: SUDAH DIIZINKAN. Android mengizinkan aplikasi menjadwalkan alarm tepat waktu."
            } else {
                "Status izin alarm tepat waktu: BELUM DIIZINKAN. Ketuk tombol Periksa atau izinkan alarm tepat waktu, lalu aktifkan izinnya di halaman Android jika sakelar tersedia. Kembali ke aplikasi untuk memeriksa status lagi."
            }
        }
        alarmPermissionStatus.text = status
        alarmPermissionStatus.contentDescription = status
    }

    private fun bukaIzinAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse(("package:" + (packageName))))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(("package:" + (packageName))))) }
        } else toast("Pada versi Android ini, izin alarm tepat waktu dikelola otomatis.")
    }
    private fun bukaNotifikasi() {
        try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(("package:" + (packageName))))) }
    }
}
