package com.novan.bateraibicara

import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

/**
 * FIX295: kalender Hijriah Indonesia dihitung di perangkat (tanpa internet) dengan kriteria baru MABIMS yang dipakai Kemenag RI
 * (imkanur rukyat): hilal dianggap terlihat bila, saat matahari terbenam setelah ijtimak (konjungsi), tinggi toposentrik bulan >= 3 derajat
 * dan elongasi >= 6,4 derajat. Titik acuan Banda Aceh (ujung barat Indonesia: bila memenuhi di sana, memenuhi di wilayah Indonesia).
 * Bila belum memenuhi, bulan berjalan digenapkan 30 hari (istikmal). Posisi bulan/matahari memakai deret Meeus yang diringkas
 * (galat sekitar 0,01 derajat) sehingga ambang diberi toleransi kecil. Ini perkiraan hisab; penetapan resmi sidang isbat Kemenag
 * (HijriahResmi) selalu didahulukan. Kesesuaian dengan penetapan pemerintah 2023-2026 diuji di tools/uji_imkanur_hijriah.py.
 */
object HijriImkanur {
    private val R = Math.PI / 180.0
    private const val LAT = 5.55
    private const val LON = 95.32
    private const val TINGGI_MIN = 3.0 - 0.05
    private const val ELONGASI_MIN = 6.4 - 0.05
    private const val SINODIK = 29.530588861
    private const val JD_REF = 2451550.09766   // ijtimak 6 Januari 2000 (k = 0)
    private const val K_JUMADA = 315           // ijtimak 25 Juni 2025 = awal 1 Muharram 1447 H
    private const val HIJRI_TAHUN_JANGKAR = 1447

    private val cacheAwal = ConcurrentHashMap<Int, Long>()

    private val LT = arrayOf(
        intArrayOf(0, 0, 1, 0, 6288774),
        intArrayOf(2, 0, -1, 0, 1274027),
        intArrayOf(2, 0, 0, 0, 658314),
        intArrayOf(0, 0, 2, 0, 213618),
        intArrayOf(0, 1, 0, 0, -185116),
        intArrayOf(0, 0, 0, 2, -114332),
        intArrayOf(2, 0, -2, 0, 58793),
        intArrayOf(2, -1, -1, 0, 57066),
        intArrayOf(2, 0, 1, 0, 53322),
        intArrayOf(2, -1, 0, 0, 45758),
        intArrayOf(0, 1, -1, 0, -40923),
        intArrayOf(1, 0, 0, 0, -34720),
        intArrayOf(0, 1, 1, 0, -30383),
        intArrayOf(2, 0, 0, -2, 15327),
        intArrayOf(0, 0, 1, 2, -12528),
        intArrayOf(0, 0, 1, -2, 10980),
        intArrayOf(4, 0, -1, 0, 10675),
        intArrayOf(0, 0, 3, 0, 10034),
        intArrayOf(4, 0, -2, 0, 8548),
        intArrayOf(2, 1, -1, 0, -7888),
        intArrayOf(2, 1, 0, 0, -6766),
        intArrayOf(1, 0, -1, 0, -5163),
        intArrayOf(1, 1, 0, 0, 4987),
        intArrayOf(2, -1, 1, 0, 4036),
        intArrayOf(2, 0, 2, 0, 3994),
        intArrayOf(4, 0, 0, 0, 3861),
        intArrayOf(2, 0, -3, 0, 3665),
        intArrayOf(0, 1, -2, 0, -2689),
        intArrayOf(2, 0, -1, 2, -2602),
        intArrayOf(2, -1, -2, 0, 2390),
        intArrayOf(1, 0, 1, 0, -2348),
        intArrayOf(2, -2, 0, 0, 2236),
        intArrayOf(0, 1, 2, 0, -2120),
        intArrayOf(0, 2, 0, 0, -2069),
        intArrayOf(2, -2, -1, 0, 2048),
        intArrayOf(2, 0, 1, -2, -1773),
        intArrayOf(2, 0, 0, 2, -1595),
        intArrayOf(4, -1, -1, 0, 1215),
        intArrayOf(0, 0, 2, 2, -1110),
        intArrayOf(3, 0, -1, 0, -892),
        intArrayOf(2, 1, 1, 0, -810),
        intArrayOf(4, -1, -2, 0, 759),
        intArrayOf(0, 2, -1, 0, -713),
        intArrayOf(2, 2, -1, 0, -700),
        intArrayOf(2, 1, -2, 0, 691),
        intArrayOf(2, -1, 0, -2, 596),
        intArrayOf(4, 0, 1, 0, 549),
        intArrayOf(0, 0, 4, 0, 537),
        intArrayOf(4, -1, 0, 0, 520),
        intArrayOf(1, 0, -2, 0, -487),
        intArrayOf(2, 1, 0, -2, -399),
        intArrayOf(0, 0, 2, -2, -381),
        intArrayOf(1, 1, 1, 0, 351),
        intArrayOf(3, 0, -2, 0, -340),
        intArrayOf(4, 0, -3, 0, 330),
        intArrayOf(2, -1, 2, 0, 327),
        intArrayOf(0, 2, 1, 0, -323),
        intArrayOf(1, 1, -1, 0, 299),
        intArrayOf(2, 0, 3, 0, 294)
    )
    private val BT = arrayOf(
        intArrayOf(0, 0, 0, 1, 5128122),
        intArrayOf(0, 0, 1, 1, 280602),
        intArrayOf(0, 0, 1, -1, 277693),
        intArrayOf(2, 0, 0, -1, 173237),
        intArrayOf(2, 0, -1, 1, 55413),
        intArrayOf(2, 0, -1, -1, 46271),
        intArrayOf(2, 0, 0, 1, 32573),
        intArrayOf(0, 0, 2, 1, 17198),
        intArrayOf(2, 0, 1, -1, 9266),
        intArrayOf(0, 0, 2, -1, 8822),
        intArrayOf(2, -1, 0, -1, 8216),
        intArrayOf(2, 0, -2, -1, 4324),
        intArrayOf(2, 0, 1, 1, 4200),
        intArrayOf(2, 1, 0, -1, -3359),
        intArrayOf(2, -1, -1, 1, 2463),
        intArrayOf(2, -1, 0, 1, 2211),
        intArrayOf(2, -1, -1, -1, 2065),
        intArrayOf(0, 1, -1, -1, -1870),
        intArrayOf(4, 0, -1, -1, 1828),
        intArrayOf(0, 1, 0, 1, -1794),
        intArrayOf(0, 0, 0, 3, -1749),
        intArrayOf(0, 1, -1, 1, -1565),
        intArrayOf(1, 0, 0, 1, -1491),
        intArrayOf(0, 1, 1, 1, -1475),
        intArrayOf(0, 1, 1, -1, -1410),
        intArrayOf(0, 1, 0, -1, -1344),
        intArrayOf(1, 0, 0, -1, -1335),
        intArrayOf(0, 0, 3, 1, 1107),
        intArrayOf(4, 0, 0, -1, 1021),
        intArrayOf(4, 0, -1, 1, 833)
    )

    private fun norm(x: Double): Double { val r = x % 360.0; return if (r < 0) r + 360.0 else r }

    private fun lonMatahari(T: Double): Double {
        val l0 = norm(280.46646 + 36000.76983 * T + 0.0003032 * T * T)
        val m = norm(357.52911 + 35999.05029 * T - 0.0001537 * T * T)
        val c = (1.914602 - 0.004817 * T - 0.000014 * T * T) * sin(m * R) + (0.019993 - 0.000101 * T) * sin(2 * m * R) + 0.000289 * sin(3 * m * R)
        val om = 125.04 - 1934.136 * T
        return l0 + c - 0.00569 - 0.00478 * sin(om * R)
    }

    /** Bujur dan lintang ekliptika bulan (derajat). */
    private fun posisiBulan(T: Double): DoubleArray {
        val lp = norm(218.3164477 + 481267.88123421 * T - 0.0015786 * T * T)
        val d = norm(297.8501921 + 445267.1114034 * T - 0.0018819 * T * T)
        val m = norm(357.5291092 + 35999.0502909 * T - 0.0001536 * T * T)
        val mp = norm(134.9633964 + 477198.8675055 * T + 0.0087414 * T * T)
        val f = norm(93.2720950 + 483202.0175233 * T - 0.0036539 * T * T)
        val a1 = norm(119.75 + 131.849 * T)
        val a2 = norm(53.09 + 479264.290 * T)
        val a3 = norm(313.45 + 481266.484 * T)
        val e = 1 - 0.002516 * T - 0.0000074 * T * T
        var sl = 0.0
        for (t in LT) {
            val a = (t[0] * d + t[1] * m + t[2] * mp + t[3] * f) * R
            sl += t[4] * e.pow(abs(t[1]).toDouble()) * sin(a)
        }
        var sb = 0.0
        for (t in BT) {
            val a = (t[0] * d + t[1] * m + t[2] * mp + t[3] * f) * R
            sb += t[4] * e.pow(abs(t[1]).toDouble()) * sin(a)
        }
        sl += 3958 * sin(a1 * R) + 1962 * sin((lp - f) * R) + 318 * sin(a2 * R)
        sb += -2235 * sin(lp * R) + 382 * sin(a3 * R) + 175 * sin((a1 - f) * R) + 175 * sin((a1 + f) * R) + 127 * sin((lp - mp) * R) - 115 * sin((lp + mp) * R)
        return doubleArrayOf(norm(lp + sl / 1e6), sb / 1e6)
    }

    private fun gmst(j: Double): Double {
        val t = (j - 2451545.0) / 36525.0
        return norm(280.46061837 + 360.98564736629 * (j - 2451545.0) + 0.000387933 * t * t)
    }

    private fun tinggi(j: Double, lat: Double, lon: Double, ra: Double, dec: Double): Double {
        val h = (gmst(j) + lon) * R - ra
        val la = lat * R
        return asin(sin(la) * sin(dec) + cos(la) * cos(dec) * cos(h)) / R
    }

    private fun raDec(lon: Double, lat: Double, T: Double): DoubleArray {
        val eps = (23.439291 - 0.0130042 * T + 0.00256 * cos((125.04 - 1934.136 * T) * R)) * R
        val l = lon * R
        val b = lat * R
        var ra = atan2(sin(l) * cos(eps) - tan(b) * sin(eps), cos(l))
        ra %= (2 * Math.PI)
        if (ra < 0) ra += 2 * Math.PI
        val dec = asin(sin(b) * cos(eps) + cos(b) * sin(eps) * sin(l))
        return doubleArrayOf(ra, dec)
    }

    private fun selisihBujur(j: Double): Double {
        val t = (j - 2451545.0) / 36525.0
        return norm(posisiBulan(t)[0] - lonMatahari(t) + 180.0) - 180.0
    }

    /** Saat ijtimak (JD, UT) di sekitar [j0], dicari dengan bagi dua pada selisih bujur bulan-matahari. */
    private fun ijtimak(j0: Double): Double {
        var a = j0 - 3
        var b = j0 + 3
        repeat(60) {
            val m = (a + b) / 2
            if (selisihBujur(m) > 0) b = m else a = m
        }
        return (a + b) / 2
    }

    /** Saat matahari terbenam (JD, UT) di titik acuan pada tanggal UT dengan tengah malam [nol]. */
    private fun terbenam(nol: Double): Double {
        var a = nol + 0.20
        var b = nol + 0.60
        repeat(50) {
            val m = (a + b) / 2
            val t = (m - 2451545.0) / 36525.0
            val rd = raDec(lonMatahari(t), 0.0, t)
            if (tinggi(m, LAT, LON, rd[0], rd[1]) + 0.833 > 0) a = m else b = m
        }
        return (a + b) / 2
    }

    /** true bila hilal memenuhi kriteria saat matahari terbenam [j]. */
    private fun memenuhi(j: Double): Boolean {
        val t = (j - 2451545.0) / 36525.0
        val bulan = posisiBulan(t)
        val sl = lonMatahari(t)
        val rd = raDec(bulan[0], bulan[1], t)
        val h = tinggi(j, LAT, LON, rd[0], rd[1])
        val hTopo = h - (6378.14 / 385000.0) / R * cos(h * R)
        val el = acos(cos(bulan[1] * R) * cos((bulan[0] - sl) * R)) / R
        return hTopo >= TINGGI_MIN && el >= ELONGASI_MIN
    }

    /** Hari epoch (LocalDate.toEpochDay) 1 bulan Hijriah yang ijtimaknya ke-[k]. */
    private fun awalBulan(k: Int): Long = cacheAwal.getOrPut(k) {
        val konj = ijtimak(JD_REF + SINODIK * k)
        val lokal = floor(konj + 0.5 + 7.0 / 24.0)      // nomor hari lokal (WIB)
        val hari0 = lokal.toLong() - 2440588L
        var hasil = hari0 + 2                            // istikmal
        for (g in 0..1) {
            val ss = terbenam(lokal + g - 0.5)
            if (ss <= konj) continue
            if (memenuhi(ss)) { hasil = hari0 + g + 1; break }
        }
        hasil
    }

    /** (tahun, bulan 0-based, tanggal) Hijriah menurut kriteria Indonesia; null bila di luar rentang 1400-1600 H. */
    fun cari(date: LocalDate): Triple<Int, Int, Int>? {
        return try {
            val hari = date.toEpochDay()
            val jd = hari + 2440587.5 + 0.5
            val k0 = ((jd - JD_REF) / SINODIK).roundToLong().toInt()
            var k = k0 + 1
            while (k >= k0 - 2 && awalBulan(k) > hari) k--
            val awal = awalBulan(k)
            val selisih = (hari - awal).toInt()
            if (selisih !in 0..29) return null
            val total = HIJRI_TAHUN_JANGKAR * 12 + (k - K_JUMADA)
            val tahun = Math.floorDiv(total, 12)
            if (tahun !in 1400..1600) return null
            Triple(tahun, Math.floorMod(total, 12), selisih + 1)
        } catch (_: Exception) { null }
    }
}
