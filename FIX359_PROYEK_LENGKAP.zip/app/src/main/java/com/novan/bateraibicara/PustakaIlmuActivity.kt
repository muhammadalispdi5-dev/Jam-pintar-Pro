package com.novan.bateraibicara

import android.content.Intent

/**
 * FIX339: satu kelompok untuk sumber belajar dan panduan keislaman: Kitab Hadis, Kitab Tafsir, Pelajaran Hijaiyah dan Tajwid,
 * Panduan Ibadah Praktis, Manasik Haji dan Umrah, serta Himpunan Khutbah Jumat.
 */
class PustakaIlmuActivity : Halaman() {
    override val judulHalaman = R.string.judul_pustaka_ilmu

    override fun bangun() {
        info(tr("Kumpulan kitab dan panduan untuk belajar dan beribadah: hadis, tafsir, hijaiyah dan tajwid, ibadah praktis, haji dan umrah, serta khutbah Jumat. Anda juga dapat langsung berkata kepada asisten, misalnya: buka kitab hadis, tafsir surah Al Baqarah ayat 255, pelajaran tajwid, atau panduan haji.",
            "A collection of books and guides for learning and worship: hadith, tafsir, hijaiyah and tajwid, practical worship, hajj and umrah, and Friday sermons. You can also tell the assistant directly, for example: open the hadith book, tafsir surah Al Baqarah verse 255, tajwid lessons, or hajj guide."))
        tombol(getString(R.string.menu_hadits)) { startActivity(Intent(this, HaditsActivity::class.java)) }
        tombol(getString(R.string.menu_tafsir)) { startActivity(Intent(this, TafsirActivity::class.java)) }
        tombol(getString(R.string.menu_tajwid)) { startActivity(Intent(this, TajwidActivity::class.java)) }
        tombol(getString(R.string.menu_panduan_ibadah)) { startActivity(Intent(this, PanduanIbadahActivity::class.java)) }
        tombol(getString(R.string.menu_manasik_haji)) { startActivity(Intent(this, ManasikHajiActivity::class.java)) }
        tombol(getString(R.string.menu_khutbah)) { startActivity(Intent(this, KhutbahJumatActivity::class.java)) }
    }
}
