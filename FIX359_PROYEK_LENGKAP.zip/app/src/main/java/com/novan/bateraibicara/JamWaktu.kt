package com.novan.bateraibicara

import java.util.Calendar

/** Penyusun kalimat pengumuman waktu dalam bahasa pilihan dan penghitung jadwal berikutnya. */
object JamWaktu {

    private const val PEMISAH_INTERNAL = "\u001F"

    private val SATUAN = arrayOf(
        "nol", "satu", "dua", "tiga", "empat", "lima",
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"
    )

    fun kata(n: Int): String = when {
        n < 12 -> SATUAN[n]
        n < 20 -> SATUAN[n - 10] + " belas"
        n < 100 -> {
            val s = n % 10
            SATUAN[n / 10] + " puluh" + if (s > 0) " " + SATUAN[s] else ""
        }
        else -> n.toString()
    }

    private fun bagianHari(h: Int) = when (h) {
        in 0..3 -> "dini hari"
        in 4..9 -> "pagi"
        in 10..14 -> "siang"
        in 15..17 -> "sore"
        18 -> "petang"
        else -> "malam"
    }

    /** Sisipkan kata "tepat" sebelum kata "pukul"/"jam" pada awalan, atau di depan awalan bila tidak ada. */
    private fun awalanDenganTepat(awalan: String, sep: String): String {
        val m = Regex("(?i)\\b(pukul|jam|tabuh)\\s*\\z").find(awalan)
        return if (m != null) awalan.substring(0, m.range.first) + "tepat" + sep + " " + awalan.substring(m.range.first)
        else if (awalan.isBlank()) "Tepat" + sep else "Tepat" + sep + " " + awalan
    }

    /** FIX328: pemisah jeda khusus kata "tepat" (tepat di awal / tepat di akhir); kosong bila jedanya 0. */
    private fun sepTepat(p: Prefs): String = if (p.jamJedaTepat > 0) PEMISAH_INTERNAL else ""

    /** FIX328: jeda (ms) antara dua bagian ucapan jam: kata "tepat" memakai jeda tepat, jam-menit memakai jeda jam-menit. */
    fun jedaBagianMs(p: Prefs, c: Calendar): Long =
        (if (c.get(Calendar.MINUTE) == 0) p.jamJedaTepat else p.jamJedaJamMenit).toLong()

    private fun ucapanDenganPemisah(p: Prefs, c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val dtk = c.get(Calendar.SECOND)
        val duabelas = p.jamFormat == 1
        val jam = if (duabelas) (if (h % 12 == 0) 12 else h % 12) else h
        val sebutJam = p.jamSebutJam
        val sebutMenit = p.jamSebutMenit
        val sebutPeriode = duabelas && p.jamSebutPeriode
        // "Tepat" berlaku saat jam pas (menit 0 dan detik 0); pada saat itu detik tidak dibacakan.
        val tepatJam = sebutJam && m == 0 && (dtk == 0 || !p.jamSebutDetik)
        val tepatAwal = tepatJam && p.jamTepatAwal
        val tepatAkhir = tepatJam && p.jamTepatAkhir
        val tampilDetik = p.jamSebutDetik && !(m == 0 && dtk == 0)

        // Kata pembuka mengikuti bahasa ucapan yang dipilih; bawaannya "It is", "الوقت الحالي", dll.
        // dan dapat diganti pengguna untuk tiap bahasa.
        val pembuka = p.jamAwalan.trim()

        if (p.bahasaAktif == 1) {
            val sb = StringBuilder(pembuka)
            if (tepatAwal) sb.append(" exactly").append(sepTepat(p))
            if (sebutJam) sb.append(" ").append(JamBahasa.kata(jam, 1))
            if (sebutMenit && !(sebutJam && m == 0)) {
                if (sebutJam) {
                    sb.append(" hours")
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" ").append(JamBahasa.kata(m, 1)).append(" minutes")
                } else sb.append(" ").append(JamBahasa.kata(m, 1)).append(" minutes")
            } else if (sebutJam && m == 0) {
                if (tepatJam) { if (tepatAkhir) sb.append(sepTepat(p)).append(" o'clock") }
                else sb.append(" hours")
            } else if (sebutJam && tampilDetik) sb.append(" hours")
            if (tampilDetik) sb.append(" ").append(JamBahasa.kata(dtk, 1)).append(" seconds")
            if (sebutPeriode) sb.append(if (h < 12) " AM" else " PM")
            return sb.toString()
        }
        if (p.bahasaAktif == 2) {
            val sb = StringBuilder(pembuka)
            if (tepatAwal) sb.append(" بالضبط").append(sepTepat(p))
            if (sebutJam) sb.append("، الساعة ").append(JamBahasa.kata(jam, 2))
            if (sebutMenit && !(sebutJam && m == 0)) {
                if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" و").append(JamBahasa.kata(m, 2)).append(" دقيقة")
                } else sb.append(" ").append(JamBahasa.kata(m, 2)).append(" دقيقة")
            } else if (sebutJam && m == 0 && tepatAkhir) sb.append(sepTepat(p)).append(" تمامًا")
            if (tampilDetik) sb.append(" ").append(JamBahasa.kata(dtk, 2)).append(" ثانية")
            return sb.toString()
        }
        if (p.bahasaAktif == 4) {
            val awalanSunda = if (!tepatAwal) pembuka else {
                val mSunda = Regex("(?i)\\btabuh\\s*\\z").find(pembuka)
                if (mSunda != null) pembuka.substring(0, mSunda.range.first) + "leres" + sepTepat(p) + " " + pembuka.substring(mSunda.range.first)
                else if (pembuka.isBlank()) "Leres" + sepTepat(p) else "Leres" + sepTepat(p) + " " + pembuka
            }
            val sb = StringBuilder(awalanSunda)
            if (sebutJam) sb.append(" ").append(JamBahasa.sundaKata(jam))
            val periodeSunda = when (h) {
                in 0..3 -> "wanci wengi"
                in 4..10 -> "wanci enjing"
                in 11..14 -> "wanci siang"
                in 15..18 -> "wanci sonten"
                else -> "wanci wengi"
            }
            if (tepatJam && sebutPeriode) sb.append(" ").append(periodeSunda)
            if (sebutMenit && !(sebutJam && m == 0)) {
                if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" langkung ").append(JamBahasa.sundaKata(m)).append(" menit")
                } else sb.append(" menit ").append(JamBahasa.sundaKata(m))
            } else if (sebutJam && m == 0 && tampilDetik) sb.append(" langkung")
            if (tepatAkhir) sb.append(sepTepat(p)).append(" leres")
            if (tampilDetik) sb.append(" ").append(JamBahasa.sundaKata(dtk)).append(" detik")
            if (sebutPeriode && !tepatJam) sb.append(" ").append(periodeSunda)
            return sb.toString()
        }
        if (p.bahasaAktif == 3) {
            // Kata pembuka Jawa disimpan terpisah dari kata pembuka Indonesia, jadi aman dipakai di sini.
            val sb = StringBuilder(pembuka)
            if (tepatAwal) sb.append(" pas").append(sepTepat(p))
            if (sebutJam) sb.append(" tabuh ").append(JamBahasa.jawaKata(jam))
            val periodeJawa = when (h) {
                in 0..3 -> "tengah dalu"
                in 4..10 -> "enjing"
                in 11..14 -> "siyang"
                in 15..18 -> "sonten"
                else -> "dalu"
            }
            // Pas jam pas: keterangan wekdal langsung sesudah tabuh, lalu "pas".
            if (tepatJam && sebutPeriode) sb.append(' ').append(periodeJawa)
            if (sebutMenit && !(sebutJam && m == 0)) {
                if (sebutJam) {
                    if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                    sb.append(" langkung ").append(JamBahasa.jawaKata(m)).append(" menit")
                } else sb.append(" ").append(JamBahasa.jawaKata(m)).append(" menit")
            } else if (sebutJam && m == 0 && tampilDetik) sb.append(" langkung")
            if (tepatAkhir) sb.append(sepTepat(p)).append(" pas")
            // Menit lan detik langsung dirangkai tanpa tembung panyambung.
            if (tampilDetik) sb.append(" ").append(JamBahasa.jawaKata(dtk)).append(" detik")
            if (sebutPeriode && !tepatJam) sb.append(' ').append(periodeJawa)
            return sb.toString()
        }

        val awalan = p.jamAwalan.trim()
        val sb = StringBuilder(if (tepatAwal) awalanDenganTepat(awalan, sepTepat(p)) else awalan)
        if (sebutJam) sb.append(' ').append(kata(jam))
        // Pas jam pas: keterangan waktu langsung sesudah jam ("pukul enam pagi tepat").
        if (tepatJam && sebutPeriode) sb.append(' ').append(bagianHari(h))
        if (sebutMenit && !(sebutJam && m == 0)) {
            if (sebutJam) {
                if (p.jamJedaJamMenit > 0) sb.append(PEMISAH_INTERNAL)
                sb.append(" lewat ").append(kata(m)).append(" menit")
            } else sb.append(" menit ").append(kata(m))
        } else if (sebutJam && m == 0 && tampilDetik) sb.append(" lewat")
        if (tepatAkhir) sb.append(sepTepat(p)).append(" tepat")
        // Tanpa koma literal agar intonasi TTS tidak terputus (perbaikan 1.0.29).
        if (tampilDetik) sb.append(" ").append(kata(dtk)).append(" detik")
        if (sebutPeriode && !tepatJam) sb.append(' ').append(bagianHari(h))
        return sb.toString()
    }

    /** Teks yang ditampilkan/diucapkan tetap alami; pemisah teknis tidak pernah dibacakan. */
    fun ucapan(p: Prefs, c: Calendar): String = ucapanDenganPemisah(p, c).replace(PEMISAH_INTERNAL, "")


    /**
     * Urutan acuan main.lua: waktu terlebih dahulu; lalu satu segmen hari + pasaran Jawa
     * + tanggal Masehi; terakhir tanggal Hijriah. Segmen kalender yang tidak aktif dilewati.
     */
    fun segmenTanggal(p: Prefs, c: Calendar): List<String> {
        val hasil = ArrayList<String>(segmenKalender(p, c, bolehKosong = true))
        hasil.addAll(HariLibur.segmen(p, c))
        hasil.addAll(InfoSholat.segmen(p, c))
        return hasil.filter { it.isNotBlank() }
    }

    /**
     * Hanya tanggal kalender (Masehi, pasaran Jawa, Hijriah) sesuai pengaturan, tanpa libur dan info salat.
     * Dipakai perintah suara "tanggal" agar yang dibacakan hanya yang diminta. Bila semua bagian kalender
     * dinonaktifkan, tanggal Masehi tetap dibacakan karena pengguna memang memintanya.
     */
    fun segmenKalender(p: Prefs, c: Calendar, bolehKosong: Boolean = false): List<String> {
        val hasil = ArrayList<String>()
        if (p.kalenderPasaranOn || p.kalenderMasehiOn) {
            val bagian = ArrayList<String>()
            if (p.kalenderPasaranOn) bagian.add(KalenderTanggal.pasaran(c, p.kalenderPasaranKoreksi, p.bahasaAktif))
            if (p.kalenderMasehiOn) bagian.add(KalenderTanggal.masehi(c, p.bahasaAktif))
            hasil.add(bagian.joinToString(", "))
        }
        if (p.kalenderHijriOn) {
            hasil.add(KalenderTanggal.hijriah(
                c,
                if (p.kalenderHijriAuto) 0 else p.kalenderHijriKoreksi,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineOffset else 0,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineTanggal else null,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineHari else null,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineBulan else null,
                if (p.kalenderHijriAuto) p.kalenderHijriOnlineTahun else null,
                p.bahasaAktif,
                if (p.kalenderHijriAuto) p.appContext else null
            ))
        }
        if (hasil.isEmpty() && !bolehKosong) hasil.add(KalenderTanggal.masehi(c, p.bahasaAktif))
        return hasil.filter { it.isNotBlank() }
    }

    /**
     * Pengumuman otomatis berkala hanya boleh membacakan waktu.
     * Kalender, hari libur, dan informasi jadwal salat hanya dibacakan melalui tombol pemicu.
     */
    fun segmenTanggalBerkala(p: Prefs, c: Calendar): List<String> = emptyList()

    fun segmenUcapanLengkap(p: Prefs, c: Calendar): List<String> {
        return (listOf(ucapan(p, c)) + segmenTanggal(p, c)).filter { it.isNotBlank() }
    }

    fun ucapanLengkap(p: Prefs, c: Calendar): String = segmenUcapanLengkap(p, c).joinToString(". ")

    /** Waktu saja, mempertahankan pengaturan jeda khusus antara jam dan menit. */
    fun bagianUcapanLengkap(p: Prefs, c: Calendar): Pair<String, String?> = bagianUcapan(p, c)

    /** Pecah melalui pemisah internal agar jeda 300 ms tidak bergantung pada tanda baca. */
    fun bagianUcapan(p: Prefs, c: Calendar): Pair<String, String?> {
        val teks = ucapanDenganPemisah(p, c)
        val posisi = teks.indexOf(PEMISAH_INTERNAL)
        return if (posisi >= 0) Pair(teks.substring(0, posisi).trimEnd(), teks.substring(posisi + PEMISAH_INTERNAL.length).trimStart())
        else Pair(teks.replace(PEMISAH_INTERNAL, ""), null)
    }

    /** "06.30" */
    fun format(menit: Int): String = "%02d.%02d".format(menit / 60, menit % 60)

    private val NAMA_HARI = arrayOf("Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab")

    fun ringkasHari(mask: Int): String {
        if ((mask and 127) == 127) return "Setiap hari"
        if ((mask and 127) == 0) return "Tidak ada"
        // Urutan tampil Senin..Minggu
        return listOf(1, 2, 3, 4, 5, 6, 0).filter { (mask and (1 shl it)) != 0 }
            .joinToString(", ") { NAMA_HARI[it] }
    }

    /** Waktu (ms) jadwal pertama yang lebih besar dari [setelah], atau null bila tidak ada hari aktif. */
    fun berikut(p: Prefs, setelah: Long): Long? {
        val mulai = p.jamMulai
        val selesai = p.jamSelesai
        val panjang = when {
            selesai > mulai -> selesai - mulai
            selesai < mulai -> selesai + 1440 - mulai
            else -> 0
        }
        val langkah = if (p.jamMode == 0) 60 else p.jamInterval
        val awal = if (p.jamMode == 0) (60 - mulai % 60) % 60 else 0
        if (p.jamHari == 0) return null

        for (d in -1..8) {
            val dasar = Calendar.getInstance()
            dasar.timeInMillis = setelah
            dasar.set(Calendar.HOUR_OF_DAY, 0)
            dasar.set(Calendar.MINUTE, 0)
            dasar.set(Calendar.SECOND, 0)
            dasar.set(Calendar.MILLISECOND, 0)
            dasar.add(Calendar.DAY_OF_YEAR, d)
            val hari = dasar.get(Calendar.DAY_OF_WEEK) - 1
            if ((p.jamHari and (1 shl hari)) == 0) continue
            var off = awal
            while (off <= panjang) {
                val t = dasar.clone() as Calendar
                t.add(Calendar.MINUTE, mulai + off)
                if (t.timeInMillis > setelah) return t.timeInMillis
                off += langkah
            }
        }
        return null
    }
}
