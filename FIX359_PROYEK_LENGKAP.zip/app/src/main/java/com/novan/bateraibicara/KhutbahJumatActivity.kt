package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale

/**
 * FIX202: Himpunan Khutbah Jum'at. Daftar naskah -> halaman naskah (khutbah pertama dan kedua) dengan ukuran huruf
 * yang dapat diatur, salin, bagikan, dan dengarkan (teks-ke-ucapan, mengikuti bahasa aktif).
 */
class KhutbahJumatActivity : Halaman() {
    override val judulHalaman = R.string.judul_khutbah

    private val simpan by lazy { getSharedPreferences("khutbah_jumat", MODE_PRIVATE) }
    private var pembicara: Pembicara? = null

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun judul(k: KhutbahData.Khutbah) = if (english) k.judulEn else k.judulId
    private fun isi(b: KhutbahData.Blok) = if (english) b.en else b.id

    override fun onPause() {
        hentikanSuara()
        super.onPause()
    }

    override fun onDestroy() {
        hentikanSuara()
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("khutbah", -1)
        val k = KhutbahData.daftar.getOrNull(nomor)
        if (k == null) daftar() else { naskah(nomor, k); tombolMesinBawah() }
    }

    // ---------- Daftar ----------

    private fun daftar() {
        info(tr(
            "Himpunan lebih dari delapan puluh naskah khutbah Jum'at yang dapat dibaca dari ponsel, lengkap dengan khutbah pertama dan kedua, kutipan Arab, dan terjemahan. Naskah ini draf yang disusun untuk aplikasi ini; sebaiknya ditinjau ustadz atau takmir sebelum disampaikan di mimbar.",
            "A collection of Friday sermon texts (over eighty topics) you can read on your phone, with the first and second sermons, Arabic quotations, and translations. These texts are drafts prepared for this app; please have a scholar or mosque committee review them before delivering them from the pulpit."
        ))
        var render: (String) -> Unit = { }
        val kolom = isian(tr("Cari tema khutbah", "Search sermon topic"), "", android.text.InputType.TYPE_CLASS_TEXT) { render(it) }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        val mulai = root.childCount
        render = { teksCari ->
            while (root.childCount > mulai) root.removeViewAt(root.childCount - 1)
            val q = teksCari.trim().lowercase(Locale.ROOT)
            var ada = 0
            KhutbahData.daftar.forEachIndexed { i, k ->
                if (q.isEmpty() || k.judulId.lowercase(Locale.ROOT).contains(q) || k.judulEn.lowercase(Locale.ROOT).contains(q) || (i + 1).toString() == q) {
                    ada++
                    tombol((i + 1).toString() + ". " + judul(k)) {
                        startActivity(Intent(this, KhutbahJumatActivity::class.java).putExtra("khutbah", i))
                    }
                }
            }
            if (ada == 0) info(tr("Tidak ada tema yang cocok.", "No matching topic."))
            tombolMesinBawah()
        }
        render("")
    }

    // ---------- Naskah ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 18f)

    private fun naskah(nomor: Int, k: KhutbahData.Khutbah) {
        bagian(judul(k), 22f)
        tombol(tr("Dengarkan khutbah ini", "Listen to this sermon")) { ucapkanSemua(k) }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanSuara(); toast(tr("Suara dihentikan.", "Audio stopped.")) }
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(34f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }

        subjudul(tr("Khutbah pertama", "First sermon"))
        k.pertama.forEach { blok(it) }
        subjudul(tr("Khutbah kedua", "Second sermon"))
        k.kedua.forEach { blok(it) }

        val semua = teksLengkap(k)
        tombol(tr("Salin naskah", "Copy text")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("khutbah", semua))
                toast(tr("Naskah disalin.", "Text copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan naskah", "Share text")) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua)
                startActivity(Intent.createChooser(i, tr("Bagikan naskah khutbah", "Share sermon text")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan naskah.", "No app is available to share this text."))
            }
        }
    }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 20f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(24), 0, dp(6))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun blok(b: KhutbahData.Blok) {
        if (b.arab != null) {
            val ar = TextView(this)
            ar.text = b.arab
            ar.textSize = ukuran() + 6f
            ar.setTextColor(warnaTeks())
            ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
            ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            ar.setLineSpacing(0f, 1.3f)
            ar.setPadding(0, dp(12), 0, dp(6))
            root.addView(ar)
        }
        val tv = TextView(this)
        tv.text = isi(b)
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(4), 0, dp(8))
        root.addView(tv)
        if (b.sumber != null) {
            val s = TextView(this)
            s.text = b.sumber
            s.textSize = 14f
            s.setTextColor(warnaPetunjuk())
            root.addView(s)
        }
    }

    private fun teksLengkap(k: KhutbahData.Khutbah): String = buildString {
        append(judul(k)).append("\n\n")
        append(tr("Khutbah pertama", "First sermon")).append("\n\n")
        k.pertama.forEach { b -> if (b.arab != null) append(b.arab).append("\n"); append(isi(b)).append("\n\n") }
        append(tr("Khutbah kedua", "Second sermon")).append("\n\n")
        k.kedua.forEach { b -> if (b.arab != null) append(b.arab).append("\n"); append(isi(b)).append("\n\n") }
    }.trim()

    // ---------- Audio: membaca terjemahan/isi dalam bahasa aktif (kutipan Arab tidak dibacakan) ----------

    private fun pecah(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        var sisa = teks.trim()
        while (sisa.length > maks) {
            var potong = sisa.lastIndexOfAny(charArrayOf('.', '\n', ';', ':'), maks)
            if (potong < maks / 2) potong = sisa.lastIndexOf(' ', maks)
            if (potong <= 0) potong = maks - 1
            hasil.add(sisa.substring(0, potong + 1).trim())
            sisa = sisa.substring(potong + 1).trim()
        }
        if (sisa.isNotEmpty()) hasil.add(sisa)
        return hasil
    }

    /** FIX353: bagian Suara pembaca (mesin, kecepatan, nada, keluaran, volume mandiri, gema) di paling bawah halaman. */
    private fun tombolMesinBawah() {
        blokSuara("khutbah") { tr("Alhamdulillah. Ini contoh suara pembaca naskah khutbah Jumat.", "Alhamdulillah. This is a sample of the Friday sermon reading voice.") }
    }

    private fun hentikanSuara() {
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
    }

    private fun ucapkanSemua(k: KhutbahData.Khutbah) {
        val bacaan = (listOf(judul(k)) + (k.pertama + k.kedua).map { isi(it) }).joinToString("\n")
        ucapkan(bacaan, false)
    }

    /** [arab] true = ucapkan teks Arab dengan suara Arab; false = teks bahasa aplikasi. */
    private fun ucapkan(teks: String, arab: Boolean) {
        hentikanSuara()
        try {
            val sp = Pembicara(applicationContext, Prefs(this).suara("khutbah")) { toast(it) }
            sp.bisaDibungkam = true
            sp.paksaBahasaTampilan = true
            sp.paksaArab = arab
            pembicara = sp
            sp.ucapkanRangkaian(pecah(teks, 500), 250L)
        } catch (_: Exception) {
            toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
        }
    }
}
