package com.novan.bateraibicara

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.speech.tts.UtteranceProgressListener
import java.io.File
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.TextView
import java.util.Locale

/**
 * FIX226: Doa Sehari-hari Sesuai Sunnah. Beranda (cari + kategori) -> daftar doa per kategori -> halaman doa
 * (Arab, cara baca Latin, arti, kapan dibaca, sumber dan derajat hadits). Setiap doa dapat didengarkan:
 * bacaan Arab (jika suara Arab terpasang), cara baca Latin, dan artinya dalam bahasa aktif aplikasi.
 */
class DoaHarianActivity : Halaman() {
    override val judulHalaman = R.string.judul_doa_harian

    private val simpan by lazy { getSharedPreferences("doa_harian", MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var ttsSiap = false
    private var tertunda: (() -> Unit)? = null

    private val english: Boolean get() = BahasaAplikasi.tampilan(this) == 1
    private fun judul(d: DoaHarianData.Doa) = if (english) d.judulEn else d.judulId
    private fun nama(k: Pair<String, String>) = if (english) k.second else k.first

    override fun onPause() {
        hentikanPembicara()
        try { tts?.stop() } catch (_: Exception) { }
        hentikanAudioDoa()
        super.onPause()
    }

    override fun onDestroy() {
        hentikanPembicara()
        hentikanAudioDoa()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        tts = null
        super.onDestroy()
    }

    override fun bangun() {
        val nomor = intent.getIntExtra("doa", -1)
        val kategori = intent.getIntExtra("kategori", -1)
        val d = DoaHarianData.daftar.getOrNull(nomor)
        when {
            d != null -> halamanDoa(nomor, d)
            kategori in DoaHarianData.kategori.indices -> daftarKategori(kategori)
            else -> beranda()
        }
        if (d != null || kategori in DoaHarianData.kategori.indices) tombolMesinBawah()
    }

    // ---------- Beranda ----------

    private fun beranda() {
        info(tr(
            "Kumpulan doa sehari-hari yang diamalkan Rasulullah shallallahu 'alaihi wasallam, dikelompokkan menurut keperluannya: tidur, makan, bepergian, shalat, dzikir pagi dan petang, dan lainnya. Setiap doa disertai tulisan Arab, cara baca Latin, arti, waktu membaca, serta sumber dan derajat haditsnya (shahih atau hasan). Setiap doa juga dapat didengarkan. Arti bukan pengganti bacaan Arab; hafalkan lafaz Arabnya, dan pelajari bacaan yang benar dari guru.",
            "A collection of everyday supplications practiced by the Messenger of Allah, peace be upon him, grouped by need: sleeping, eating, travel, prayer, morning and evening remembrance, and more. Each supplication comes with the Arabic text, Latin transliteration, meaning, when to recite it, and its source and hadith grade (sahih or hasan). Each one can also be listened to. The meaning does not replace the Arabic wording; memorize the Arabic and learn correct recitation from a teacher."
        ))
        var render: (String) -> Unit = { }
        val kolom = isian(tr("Cari doa", "Search supplications"), "", android.text.InputType.TYPE_CLASS_TEXT) { render(it) }
        kolom.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        val mulai = root.childCount
        render = { teksCari ->
            while (root.childCount > mulai) root.removeViewAt(root.childCount - 1)
            val q = teksCari.trim().lowercase(Locale.ROOT)
            if (q.isEmpty()) {
                bagian(tr("Kategori doa", "Categories"))
                DoaHarianData.kategori.forEachIndexed { i, k ->
                    val jumlah = DoaHarianData.daftar.count { it.kategori == i }
                    tombol(nama(k) + ", " + jumlah + " " + tr("doa", "supplications")) {
                        startActivity(Intent(this, DoaHarianActivity::class.java).putExtra("kategori", i))
                    }
                }
            } else {
                var ada = 0
                DoaHarianData.daftar.forEachIndexed { i, d ->
                    if (cocok(d, q)) {
                        ada++
                        tombol(judul(d)) { buka(i) }
                    }
                }
                if (ada == 0) info(tr("Tidak ada doa yang cocok.", "No matching supplication."))
            }
            tombolMesinBawah()
        }
        render("")
    }

    private fun cocok(d: DoaHarianData.Doa, q: String): Boolean {
        val kat = DoaHarianData.kategori[d.kategori]
        val gudang = (d.judulId + " " + d.judulEn + " " + d.artiId + " " + d.artiEn + " " + d.latin + " " + kat.first + " " + kat.second)
            .lowercase(Locale.ROOT)
        return q.split(" ").filter { it.isNotEmpty() }.all { gudang.contains(it) }
    }

    private fun buka(nomor: Int) {
        startActivity(Intent(this, DoaHarianActivity::class.java).putExtra("doa", nomor))
    }

    // ---------- Daftar per kategori ----------

    private fun daftarKategori(kategori: Int) {
        bagian(nama(DoaHarianData.kategori[kategori]), 22f)
        var urut = 0
        DoaHarianData.daftar.forEachIndexed { i, d ->
            if (d.kategori == kategori) {
                urut++
                tombol(urut.toString() + ". " + judul(d)) { buka(i) }
            }
        }
    }

    // ---------- Halaman doa ----------

    private fun ukuran(): Float = simpan.getFloat("ukuran", 20f)

    private fun halamanDoa(nomor: Int, d: DoaHarianData.Doa) {
        bagian(judul(d), 22f)
        info(nama(DoaHarianData.kategori[d.kategori]))

        subjudul(tr("Teks Arab", "Arabic text"))
        val ar = TextView(this)
        ar.text = d.arab
        ar.textSize = ukuran() + 6f
        ar.setTextColor(warnaTeks())
        ar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ar.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        ar.setLineSpacing(0f, 1.4f)
        ar.setPadding(0, dp(8), 0, dp(8))
        root.addView(ar)

        subjudul(tr("Cara baca (Latin)", "Transliteration"))
        paragraf(d.latin)
        subjudul(tr("Artinya", "Meaning"))
        paragraf(if (english) d.artiEn else d.artiId)
        subjudul(tr("Kapan dibaca", "When to recite"))
        paragraf(if (english) d.kapanEn else d.kapanId)
        subjudul(tr("Sumber", "Source"))
        paragraf(if (english) d.sumberEn else d.sumberId)

        subjudul(tr("Audio doa", "Supplication audio"))
        info(tr("Audio doa ini berupa berkas suara. Bila Anda menaruh rekaman sendiri bernama doa_" + String.format(Locale.US, "%03d", nomor + 1) + " (mp3, m4a, ogg, atau wav) di folder audio doa aplikasi, rekaman itu yang diputar; bila tidak ada, aplikasi membuat berkas audio bacaan Arab dari suara perangkat.",
                "This supplication audio is a sound file. If you place your own recording named doa_" + String.format(Locale.US, "%03d", nomor + 1) + " (mp3, m4a, ogg or wav) in the app's supplication audio folder, that recording is played; otherwise the app creates an Arabic audio file from the device voice."))
        tombol(tr("Putar audio doa", "Play supplication audio")) { putarAudioDoa(nomor, d) }
        tombol(tr("Jeda atau lanjutkan audio doa", "Pause or resume supplication audio")) { jedaLanjutAudioDoa() }
        tombol(tr("Hentikan audio doa", "Stop supplication audio")) { hentikanAudioDoa(); toast(tr("Audio doa dihentikan.", "Supplication audio stopped.")) }
        subjudul(tr("Dengarkan", "Listen"))
        tombol(tr("Dengarkan bacaan Arab", "Listen to the Arabic")) { ucapkan(d.arab, Locale("ar"), true) }
        tombol(tr("Dengarkan cara baca Latin", "Listen to the Latin reading")) { ucapkan(d.latin, Locale("id", "ID"), false) }
        tombol(tr("Dengarkan artinya", "Listen to the meaning")) {
            ucapkan(if (english) d.artiEn else d.artiId, if (english) Locale.US else Locale("id", "ID"), false)
        }
        tombol(tr("Hentikan suara", "Stop audio")) { hentikanPembicara(); try { tts?.stop() } catch (_: Exception) { }; toast(tr("Suara dihentikan.", "Audio stopped.")) }

        subjudul(tr("Pengaturan dan bagikan", "Settings and sharing"))
        tombol(tr("Perbesar huruf", "Increase text size")) { simpan.edit().putFloat("ukuran", (ukuran() + 2f).coerceAtMost(36f)).apply(); recreate() }
        tombol(tr("Perkecil huruf", "Decrease text size")) { simpan.edit().putFloat("ukuran", (ukuran() - 2f).coerceAtLeast(14f)).apply(); recreate() }
        val semua = teksLengkap(d)
        tombol(tr("Salin doa", "Copy supplication")) {
            try {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("doa", semua))
                toast(tr("Doa disalin.", "Supplication copied."))
            } catch (_: Exception) { }
        }
        tombol(tr("Bagikan doa", "Share supplication")) {
            try {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, semua)
                startActivity(Intent.createChooser(i, tr("Bagikan doa", "Share supplication")))
            } catch (_: Exception) {
                toast(tr("Tidak ditemukan aplikasi untuk membagikan doa.", "No app is available to share this text."))
            }
        }

        // Navigasi ke doa sebelumnya dan berikutnya dalam kategori yang sama.
        val sekategori = DoaHarianData.daftar.indices.filter { DoaHarianData.daftar[it].kategori == d.kategori }
        val posisi = sekategori.indexOf(nomor)
        if (posisi > 0) tombol(tr("Doa sebelumnya", "Previous supplication")) { pindah(sekategori[posisi - 1]) }
        if (posisi >= 0 && posisi < sekategori.size - 1) tombol(tr("Doa berikutnya", "Next supplication")) { pindah(sekategori[posisi + 1]) }
    }

    private fun pindah(nomor: Int) {
        startActivity(Intent(this, DoaHarianActivity::class.java).putExtra("doa", nomor))
        finish()
    }

    private fun teksLengkap(d: DoaHarianData.Doa): String = buildString {
        append(judul(d)).append("\n\n")
        append(d.arab).append("\n\n")
        append(d.latin).append("\n\n")
        append(if (english) d.artiEn else d.artiId).append("\n\n")
        append(if (english) d.sumberEn else d.sumberId)
    }

    private fun subjudul(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 18f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(warnaAksen())
        tv.setPadding(0, dp(20), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        root.addView(tv)
    }

    private fun paragraf(teks: String) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran()
        tv.setTextColor(warnaTeks())
        tv.setLineSpacing(0f, 1.2f)
        tv.setPadding(0, dp(2), 0, dp(6))
        root.addView(tv)
    }

    // ---------- FIX249: audio berkas per doa ----------

    private var pemutarDoa: MediaPlayer? = null
    private var sedangMenyiapkan = false

    private fun namaBerkas(nomor: Int): String = "doa_" + String.format(Locale.US, "%03d", nomor + 1)

    /** Folder tempat pengguna dapat menaruh rekaman doa sendiri. */
    private fun folderRekaman(): File? = try { getExternalFilesDir("DoaAudio") } catch (_: Exception) { null }

    private fun cariRekaman(nomor: Int): File? {
        val dasar = namaBerkas(nomor)
        val folder = folderRekaman() ?: return null
        for (ext in listOf("mp3", "m4a", "ogg", "wav", "aac")) {
            val f = File(folder, dasar + "." + ext)
            if (f.exists() && f.length() > 0) return f
        }
        return null
    }

    private fun berkasHasilSuara(nomor: Int): File {
        val folder = File(filesDir, "doa_audio")
        if (!folder.exists()) folder.mkdirs()
        return File(folder, namaBerkas(nomor) + "_ar.wav")
    }

    private fun putarAudioDoa(nomor: Int, d: DoaHarianData.Doa) {
        hentikanAudioDoa()
        val idRaw = resources.getIdentifier(namaBerkas(nomor), "raw", packageName)
        if (idRaw != 0) { mainkan { m -> resources.openRawResourceFd(idRaw).use { m.setDataSource(it.fileDescriptor, it.startOffset, it.length) } }; return }
        val rekaman = cariRekaman(nomor)
        if (rekaman != null) { mainkan { m -> m.setDataSource(rekaman.absolutePath) }; return }
        val hasil = berkasHasilSuara(nomor)
        if (hasil.exists() && hasil.length() > 1024) { mainkan { m -> m.setDataSource(hasil.absolutePath) }; return }
        if (sedangMenyiapkan) { toast(tr("Audio doa sedang disiapkan, mohon tunggu.", "The audio is being prepared, please wait.")); return }
        sedangMenyiapkan = true
        toast(tr("Menyiapkan berkas audio doa, mohon tunggu sebentar.", "Preparing the audio file, please wait a moment."))
        denganTts {
            val m = tts
            if (m == null) { sedangMenyiapkan = false; return@denganTts }
            val r = m.setLanguage(Locale("ar"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                sedangMenyiapkan = false
                toast(tr("Suara bahasa Arab belum terpasang di perangkat. Pasang data suara Arab pada pengaturan teks-ke-ucapan Android, atau taruh rekaman doa sendiri di folder audio doa.",
                    "The Arabic voice is not installed on this device. Install Arabic voice data in Android text-to-speech settings, or place your own recording in the supplication audio folder."))
                return@denganTts
            }
            val sementara = File(hasil.parentFile, hasil.name + ".tmp")
            sementara.delete()
            val kode = "doaberkas_" + System.nanoTime()
            m.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    if (utteranceId != kode) return
                    runOnUiThread {
                        sedangMenyiapkan = false
                        if (sementara.exists() && sementara.length() > 1024 && sementara.renameTo(hasil)) {
                            if (!isFinishing && !isDestroyed) mainkan { mp -> mp.setDataSource(hasil.absolutePath) }
                        } else {
                            sementara.delete()
                            toast(tr("Berkas audio doa tidak berhasil dibuat.", "The audio file could not be created."))
                        }
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId != kode) return
                    runOnUiThread { sedangMenyiapkan = false; sementara.delete(); toast(tr("Berkas audio doa tidak berhasil dibuat.", "The audio file could not be created.")) }
                }
            })
            val b = Bundle()
            val ok = m.synthesizeToFile(d.arab, b, sementara, kode)
            if (ok != TextToSpeech.SUCCESS) { sedangMenyiapkan = false; toast(tr("Berkas audio doa tidak berhasil dibuat.", "The audio file could not be created.")) }
        }
    }

    private fun mainkan(sumber: (MediaPlayer) -> Unit) {
        try {
            try { tts?.stop() } catch (_: Exception) { }
            val m = MediaPlayer()
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            sumber(m)
            m.setOnCompletionListener { hentikanAudioDoa() }
            m.setOnErrorListener { _, _, _ -> hentikanAudioDoa(); toast(tr("Audio doa tidak dapat diputar.", "The audio could not be played.")); true }
            m.prepare()
            m.start()
            pemutarDoa = m
            PembungkamTelungkup.mulai(this, "baca_doa_audio", 600_000L) { hentikanAudioDoa() }
        } catch (_: Exception) {
            hentikanAudioDoa()
            toast(tr("Audio doa tidak dapat diputar.", "The audio could not be played."))
        }
    }

    private fun jedaLanjutAudioDoa() {
        val m = pemutarDoa
        if (m == null) { toast(tr("Belum ada audio doa yang diputar.", "No supplication audio is playing.")); return }
        try {
            if (m.isPlaying) { m.pause(); toast(tr("Audio doa dijeda.", "Supplication audio paused.")) }
            else { m.start(); toast(tr("Audio doa dilanjutkan.", "Supplication audio resumed.")) }
        } catch (_: Exception) { hentikanAudioDoa() }
    }

    private fun hentikanAudioDoa() {
        PembungkamTelungkup.selesai("baca_doa_audio")
        val m = pemutarDoa ?: return
        pemutarDoa = null
        try { m.stop() } catch (_: Exception) { }
        try { m.release() } catch (_: Exception) { }
    }

    // ---------- Suara (teks-ke-ucapan) ----------

    /** FIX354: bagian Suara pembaca (mesin, kecepatan, nada, keluaran, volume mandiri, gema) di paling bawah halaman. */
    private fun tombolMesinBawah() {
        blokSuara("doa") { tr("Bismillahirrahmanirrahim. Ini contoh suara pembaca doa harian.", "Bismillahirrahmanirrahim. This is a sample of the daily supplications reading voice.") }
    }

    private var pembicara: Pembicara? = null

    private fun hentikanPembicara() {
        try { pembicara?.matikan() } catch (_: Exception) { }
        pembicara = null
    }

    private fun bacaDenganPembicara(potongan: List<String>, bahasa: Locale?, jeda: Long) {
        hentikanPembicara()
        try {
            val sp = Pembicara(applicationContext, Prefs(this).suara("doa")) { toast(it) }
            sp.bisaDibungkam = true
            sp.paksaLocale = bahasa
            pembicara = sp
            sp.ucapkanRangkaian(potongan, jeda)
        } catch (_: Exception) {
            toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
        }
    }

    private fun ucapkan(teks: String, bahasa: Locale, arab: Boolean) {
        bacaDenganPembicara(pecah(teks, 500), bahasa, 250L)
    }

    private fun denganTts(aksi: () -> Unit) {
        if (ttsSiap) { aksi(); return }
        tertunda = aksi
        if (tts == null) {
            val mesin = Prefs(this).suara("doa").engine.ifBlank { null }
            tts = TextToSpeech(applicationContext, { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsSiap = true
                    val a = tertunda
                    tertunda = null
                    a?.invoke()
                } else {
                    toast(tr("Mesin teks-ke-ucapan tidak dapat dimulai.", "The text-to-speech engine could not start."))
                    try { tts?.shutdown() } catch (_: Exception) { }
                    tts = null
                    tertunda = null
                }
            }, mesin)
        }
    }

    private fun pecah(teks: String, maks: Int): List<String> {
        val hasil = ArrayList<String>()
        var sisa = teks.trim()
        while (sisa.length > maks) {
            var potong = sisa.lastIndexOfAny(charArrayOf('.', '\n', ';', ':'), maks)
            if (potong < maks / 2) potong = sisa.lastIndexOf(' ', maks)
            if (potong <= 0) potong = maks - 1
            hasil.add(sisa.substring(0, potong + 1).trim())
            sisa = sisa.substring(potong + 1).trim()
        }
        if (sisa.isNotEmpty()) hasil.add(sisa)
        return hasil
    }
}
