# FIX297 - Info sinyal/jaringan lewat asisten + ketelitian lokasi dikembalikan
- Akurasi: FIX296 terlalu longgar (berhenti 10 m/25 m, batas 25 dtk). Dikembalikan: berhenti langsung <= 3 m, cache segar 15 dtk <= 3 m, kumpulkan sampel dan rata-ratakan hingga 35 dtk; berhenti dini pada 18 dtk hanya bila <= 5 m.
- Baru: TopikPerangkat.SINYAL + laporanSinyal(): koneksi aktif (Wi-Fi/seluler/Ethernet), validasi internet, Wi-Fi (nama bila terbaca, dBm, pita, kecepatan tautan), seluler (operator, 2G-5G, level dan dBm, roaming, data menyala/mati), mode pesawat, Bluetooth.
- Dikenali bila ada kata jaringan (sinyal, wifi, internet, seluler...) + kata tanya, dan tanpa kata kendali (nyalakan/matikan...), jadi kendali Wi-Fi/Bluetooth tetap berjalan.
- Manifest: ACCESS_WIFI_STATE. Petunjuk dipindah ke string baru isi_petunjuk_penggunaan_lanjutan_3 (ID 64-66 / EN 61-63) karena batas ukuran string.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat. Nama Wi-Fi hanya terbaca bila izin dan layanan lokasi aktif; sinyal seluler butuh izin telepon.
