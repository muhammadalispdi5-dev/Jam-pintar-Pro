# FIX319 (belum dikompilasi dengan Gradle / belum diuji di perangkat)
- KOREKSI volume: penurunan STREAM_RING/NOTIFICATION via setStreamVolume (FIX314) dihapus; volume perangkat tidak pernah diubah aplikasi lagi. Pendengar fokus kosong dipertahankan agar suara asisten tidak diturunkan sistem. Catatan: bila HP sudah sempat turun volumenya akibat FIX314, naikkan manual sekali; aplikasi tidak menyimpan nilai aslinya.
- Ayat menurut tema: TemaQuran.kt (38 tema, daftar ayat disusun manual dari ingatan; BELUM diverifikasi terhadap mushaf, mohon dicek), parser PenafsirQuran (Perintah.tema/temaRentang), PemutarQuranService memutar ayat-ayat tema (cadangan: cari di teks terjemahan quran_id.json/quran_en.json, maks. 5 ayat).
- Hadis menurut tema: Jenis.HADITS_TEMA, PerintahSuaraActivity.bacakanHaditsTema memakai KitabHadits.cariNomorDariTeks + terjemahan Indonesia dari kitab yang sudah diunduh; maks. 3 hadis.
- Petunjuk ID 88 / EN 85 (dan item 84/81 dikoreksi). Tes: tools/uji_fix319_tema_dan_volume.py
- Batasan: hadis dibacakan dari terjemahan Indonesia saja; tema bebas butuh teks terjemahan Al-Qur'an terunduh.
