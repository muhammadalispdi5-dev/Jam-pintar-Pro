# FIX335
Pembaruan otomatis: cek tiap MainActivity dibuka (sebelumnya hanya per proses + 12 jam, padahal layanan latar menjaga proses hidup); ulang bila gagal; tunggu bila dialog lain tampil; jeda 30 menit. Belum dikompilasi / diuji di perangkat.
