# FIX300 - Volume mandiri dan efek gema di Pengaturan Jadwal Sholat dan Pengingat
- Menu baru "Volume mandiri dan efek gema" (kelompok "mandiri" di PrayerSettingsActivity): per suara ada volume 0-100 persen (pengali setVolume pemutar), pilihan efek gema (GemaAudio.daftarKunci, 11 pilihan) dan kekuatan 0-100, plus tombol Tes suara yang memanggil tes yang sudah ada.
- Kunci per fitur: azan_<waktu> (subuh, dzuhur, ashar, maghrib, isya, imsak, terbit, dhuha, tahajud), advance_<waktu>, tarhim_<waktu>, iqomah_<waktu>, sahur, berbuka. Tersimpan di PrayerPrefs (vm_, gm_, gk_).
- PrayerAlarmService: kunciMandiri ditetapkan dari intent; terapkanSuaraMandiri(mp) dipanggil sebelum start() pada ketiga pembuat MediaPlayer (playSound berkas dan azan bawaan, playRawSound); gema dilepas di stopPlayback.
- Batas: hanya suara berkas audio. Ucapan mesin suara (TTS) pengingat sebelum sholat tidak berubah. Volume mandiri hanya meredam (maks 100 persen); ekor gema bisa terpotong saat pemutaran selesai. Default 100 persen dan gema mati, jadi perilaku lama tidak berubah.
- Belum dikompilasi dengan Gradle / belum diuji di perangkat. Petunjuk ID 69 / EN 66.
