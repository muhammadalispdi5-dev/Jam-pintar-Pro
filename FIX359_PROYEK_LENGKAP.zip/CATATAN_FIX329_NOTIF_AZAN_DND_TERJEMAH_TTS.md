# FIX329
- Notifikasi jadwal: hitung mundur hanya bila advanceReminder(k) aktif.
- Azan: abaikan alarm azan >90 dtk sebelum waktu (jadwal ulang). Penyebab azan ganda belum terbukti; pengingat sebelum salat bawaan memakai TTS, bukan azan.
- DND salat: kategori prioritas hanya ALARMS (+MEDIA bila volume azan = media).
- Suara azan lama (azan_biasa_lama, azan_subuh_lama) dikembalikan sebagai pilihan.
- Terjemah TTS: TerjemahTts, TerjemahSuaraActivity (profil suara "trj"), hook di PemutarQuranService.lanjutKeBerikut dan KhatamActivity (penyelesai).
- Belum dikompilasi dengan Gradle / belum diuji di perangkat.
