FIX309: gema Khatam disempurnakan (dialog gabungan, kekuatan kelipatan 5, status, matikan gema, auto 60 persen).
