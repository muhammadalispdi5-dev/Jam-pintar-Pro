# FIX311 - Gema nyata di Jadwal Salat & Khatam, contoh TTS, Simpan vs Contoh dibedakan

Catatan jujur: belum dikompilasi dengan Gradle / belum diuji di perangkat.

## Isi
- GemaDsp.kt: DSP streaming (echo + reverb Freeverb, pre-delay, damping, ekor, limiter), meniru Gema TTS 2.0.
- PemutarMono (PemutarAudio.kt): memutar azan/murattal lewat MediaCodec + AudioTrack dengan DSP langsung.
- PrayerAlarmService: azan/pengingat memakai gema nyata (fallback MediaPlayer + AudioEffect).
- Khatam (KhatamActivity, SaluranAudioKhatam, PemutarQuranService): murattal dengan gema nyata.
- ContohGema.kt: contoh hanya TTS, kalimat "Ini adalah contoh suara gema yang Anda pilih.", tidak menyimpan, dialog tetap terbuka, semua dalam try/catch.
- Dialog gema (Halaman, PrayerSettingsActivity, Khatam): draf sampai Simpan; Batal membuang; Putar contoh gema hanya mendengarkan. Jadwal Salat: tombol terpisah "Simpan lalu tes suara lengkap".
- Petunjuk ID 80-81 / EN 77-78.

## Batasan
- DSP real-time pada azan/murattal belum diuji di perangkat.
- Khatam: berlaku mulai ayat berikutnya bila pemutar saat ini berbasis MediaPlayer.
- Ekor gema di antara ayat dengan jeda sunyi belum ditangani.
- Dialog Jadwal Salat tidak lagi punya tombol "Tes suara" langsung (diganti "Simpan lalu tes suara lengkap").
