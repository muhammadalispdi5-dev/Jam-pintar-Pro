# FIX341
Kitab Tafsir: tombol unduh seluruh kitab (114 surah) + progres + batal + hapus, tampilan alamat sumber, pencarian tema (TemaQuran) dan isi tafsir yang sudah diunduh. Petunjuk ID 121 / EN 118.
Belum dikompilasi dengan Gradle / belum diuji di perangkat. Slug dan bentuk JSON tafsir masih belum terverifikasi.
