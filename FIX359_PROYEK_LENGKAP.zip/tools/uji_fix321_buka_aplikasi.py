from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
p=t("PencocokAplikasi.kt")
for k in ["brimo","byond","livin","pkg:com.whatsapp.w4b","gojek","grab","maxim","indrive","object PencocokAplikasi"]:
    if k not in p: g.append("GAGAL alias "+k)
a=t("PerintahSuaraActivity.kt")
for k in ["PencocokAplikasi.cari(daftar, k)","luncurkanAplikasi","Pilih aplikasi untuk dibuka"]:
    if k not in a: g.append("GAGAL "+k)
print("\n".join(g) if g else "UJI FIX321: LULUS")
