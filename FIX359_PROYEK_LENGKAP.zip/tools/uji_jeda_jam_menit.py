#!/usr/bin/env python3
"""FIX292: jeda jam-menit pada pengumuman otomatis tidak boleh bertambah oleh ekor gema (ucapan selesai segera)."""
import sys
p=open('app/src/main/java/com/novan/bateraibicara/Pembicara.kt').read()
g=0
def cek(n,ok):
    global g
    print(("LULUS " if ok else "GAGAL ")+n); g+=(not ok)
cek("penyelesaian tidak lagi ditunda 1,8 detik","handler.postDelayed({ selesaiRender(id) }, 1800L)" not in p)
cek("ekor gema dilepas terpisah","selesaiDenganEkor" in p and "lepasEkorSekarang" in p and "postDelayed(lepasEkor, ekorSisaMs.coerceAtLeast(300L))" in p and "gemaEkor" in p)
cek("ekor dilepas saat dihentikan","lepasEkorSekarang()\n        try { gemaRender.lepas()" in p)
cek("ekor tidak memotong pemutar berikut (gema per pemutar)","gemaRender = GemaAudio(app)" in p and "tambahSenyapWav" in p)
sys.exit(0)
