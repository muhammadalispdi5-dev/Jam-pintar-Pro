import sys
s=open('app/src/main/java/com/novan/bateraibicara/BatteryTalkService.kt').read()
ok=True
def cek(n,c):
    global ok
    print(("LULUS " if c else "GAGAL ")+n); ok&=c
i=s.index('private fun pasangBungkam'); j=s.index('// ---------- Notifikasi',i)
blok=s[i:j]
cek("stop satu bunyi tidak membatalkan ulang",'penuhUlangSisa = 0' not in blok and 'batalkanUlangPenuh' not in blok)
k=s.index('private fun jalankanUlangPenuh'); m=s[k:k+700]
cek("tiap ulang dapat dihentikan sendiri",'pasangBungkam("baterai"' in m)
cek("ulang berikut tetap dijadwalkan",'jadwalkanUlangPenuh(token)' in m)
cek("dicabut membatalkan ulang",'plugTerakhir == 0' in m and 'penuhUlangSisa = 0\n            penuhUlangToken++\n            batalkanUlangPenuh(this)' in s)
sys.exit(0 if ok else 1)
