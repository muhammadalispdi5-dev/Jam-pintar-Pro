import sys
b='app/src/main/java/com/novan/bateraibicara/'
def r(n): return open(b+n).read()
g=0
def cek(n,c):
    global g
    print(("OK   " if c else "GAGAL ")+n); g+=(not c)
for n in ['PrayerAlarmReceiver.kt','AlarmJamReceiver.kt','KhatamReminderReceiver.kt','HafalanSrsReceiver.kt']:
    cek("saklar utama "+n,'Prefs(context).enabled' in r(n))
cek("goncangan",'"enabled", false' in r('GoncanganSuaraService.kt'))
cek("tombol",'"enabled", false' in r('TombolSuaraAccessibilityService.kt'))
cek("notif jadwal",'!Prefs(c).enabled' in r('JadwalNotifikasi.kt'))
k=r('KhatamActivity.kt')
cek("unduh ulang",'percobaan < 4' in k and 'bukaKoneksiUnduh' in k and 'penyebabUnduhTerakhir' in k)
w=r('JamWaktu.kt')
cek("jeda tepat",'sepTepat' in w and 'jedaBagianMs' in w and 'jamJedaTepat' in r('Prefs.kt') and 'jam_jeda_tepat' in open('app/src/main/res/values/strings.xml').read())
u=r('UpdateManager.kt')
cek("repo pro/bro",'daftarRepo' in u and 'alamatApkResmi' in u)
cek("default repo",'Jam-pintar-Pro' in open('app/build.gradle.kts').read())
sys.exit(0)
