from pathlib import Path
j=Path(__file__).resolve().parent.parent/"app/src/main/java/com/novan/bateraibicara"
def cek(n,c): print(("OK   " if c else "GAGAL ")+n)
pp=(j/"PrayerPrefs.kt").read_text(); pa=(j/"PrayerAlarm.kt").read_text(); pr=(j/"PrayerAlarmReceiver.kt").read_text()
cek("sahur sampai 120", "listOf(15, 30, 45, 60, 75, 90, 105, 120)" in pp)
cek("durasi Jumat terpisah", "dndJumatDuration" in pp and "menitDnd" in pr and "dndJumat" in pa)
cek("UI Jumat", "Durasi Mode Jangan Ganggu salat Jumat" in (j/"PrayerSettingsActivity.kt").read_text())
l=(j/"LautDunia.kt").read_text()
cek("lintas penyeberangan", l.count('l("Penyeberangan')>=8 and "jawabBanyak" in l)
