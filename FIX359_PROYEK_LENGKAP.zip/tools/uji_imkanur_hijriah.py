#!/usr/bin/env python3
"""FIX295: acuan Python HijriImkanur cocok dengan penetapan awal bulan pemerintah (2023-2026) dan identik dengan tabel/ambang Kotlin."""
import sys, re, math, datetime as dt, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import imkanur_acuan as I
g = 0
def cek(n, ok):
    global g
    print(("LULUS " if ok else "GAGAL ") + n); g += (not ok)
# (tahun, bulan 1-12) -> tanggal 1 menurut penetapan pemerintah (Kemenag RI)
RESMI = {(1444,9):dt.date(2023,3,23),(1444,10):dt.date(2023,4,22),(1444,12):dt.date(2023,6,20),
         (1445,9):dt.date(2024,3,12),(1445,10):dt.date(2024,4,10),(1445,12):dt.date(2024,6,8),
         (1446,9):dt.date(2025,3,1),(1446,10):dt.date(2025,3,31),(1446,12):dt.date(2025,5,28),
         (1447,1):dt.date(2025,6,27),(1447,9):dt.date(2026,2,19),(1447,10):dt.date(2026,3,21)}
K0, TH = 315, 1447
hasil = {}
for k in range(K0 - 30, K0 + 16):
    cj = I.conjunction_near(2451550.09766 + 29.530588861 * k)
    n, _, _ = I.month_start(cj)
    tot = TH * 12 + (k - K0)
    hasil[(tot // 12, tot % 12 + 1)] = I.cal(n)
for kunci, tgl in sorted(RESMI.items()):
    cek("awal bulan %d-%02d = %s (hitungan %s)" % (kunci[0], kunci[1], tgl, hasil.get(kunci)), hasil.get(kunci) == tgl)
kt = open('app/src/main/java/com/novan/bateraibicara/HijriImkanur.kt').read()
def tabel(nama):
    m = re.search(r'private val %s = arrayOf\((.*?)\n    \)' % nama, kt, re.S)
    return [tuple(int(x) for x in r) for r in re.findall(r'intArrayOf\((-?\d+), (-?\d+), (-?\d+), (-?\d+), (-?\d+)\)', m.group(1))]
cek("tabel LT Kotlin = Python", tabel('LT') == I.LT)
cek("tabel BT Kotlin = Python", tabel('BT') == I.BT)
cek("ambang Kotlin = Python", "3.0 - 0.05" in kt and "6.4 - 0.05" in kt)
cek("titik acuan Banda Aceh", "LAT = 5.55" in kt and "LON = 95.32" in kt and I.LAT == 5.55 and I.LON == 95.32)
cek("jangkar 1 Muharram 1447", "K_JUMADA = 315" in kt and "HIJRI_TAHUN_JANGKAR = 1447" in kt)
sys.exit(0)
