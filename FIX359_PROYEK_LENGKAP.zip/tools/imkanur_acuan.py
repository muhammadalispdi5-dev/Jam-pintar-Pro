import math, datetime as dt
R=math.pi/180
def jd(y,m,d,h=0.0):
    if m<=2: y-=1; m+=12
    A=y//100; B=2-A+A//4
    return int(365.25*(y+4716))+int(30.6001*(m+1))+d+B-1524.5+h/24
def jd_dt(t): return jd(t.year,t.month,t.day,t.hour+t.minute/60+t.second/3600)
def norm(x): return x%360.0
def sun(T):  # T julian centuries J2000 ; returns apparent lon, (ra,dec)
    L0=norm(280.46646+36000.76983*T+0.0003032*T*T)
    M=norm(357.52911+35999.05029*T-0.0001537*T*T)
    C=(1.914602-0.004817*T-0.000014*T*T)*math.sin(M*R)+(0.019993-0.000101*T)*math.sin(2*M*R)+0.000289*math.sin(3*M*R)
    lon=L0+C; om=125.04-1934.136*T
    lam=lon-0.00569-0.00478*math.sin(om*R)
    return lam
def obliq(T):
    return 23.439291-0.0130042*T
# Moon: Meeus ch.47 truncated
LT=[(0,0,1,0,6288774),(2,0,-1,0,1274027),(2,0,0,0,658314),(0,0,2,0,213618),(0,1,0,0,-185116),(0,0,0,2,-114332),(2,0,-2,0,58793),(2,-1,-1,0,57066),(2,0,1,0,53322),(2,-1,0,0,45758),(0,1,-1,0,-40923),(1,0,0,0,-34720),(0,1,1,0,-30383),(2,0,0,-2,15327),(0,0,1,2,-12528),(0,0,1,-2,10980),(4,0,-1,0,10675),(0,0,3,0,10034),(4,0,-2,0,8548),(2,1,-1,0,-7888),(2,1,0,0,-6766),(1,0,-1,0,-5163),(1,1,0,0,4987),(2,-1,1,0,4036),(2,0,2,0,3994),(4,0,0,0,3861),(2,0,-3,0,3665),(0,1,-2,0,-2689),(2,0,-1,2,-2602),(2,-1,-2,0,2390),(1,0,1,0,-2348),(2,-2,0,0,2236),(0,1,2,0,-2120),(0,2,0,0,-2069),(2,-2,-1,0,2048),(2,0,1,-2,-1773),(2,0,0,2,-1595),(4,-1,-1,0,1215),(0,0,2,2,-1110),(3,0,-1,0,-892),(2,1,1,0,-810),(4,-1,-2,0,759),(0,2,-1,0,-713),(2,2,-1,0,-700),(2,1,-2,0,691),(2,-1,0,-2,596),(4,0,1,0,549),(0,0,4,0,537),(4,-1,0,0,520),(1,0,-2,0,-487),(2,1,0,-2,-399),(0,0,2,-2,-381),(1,1,1,0,351),(3,0,-2,0,-340),(4,0,-3,0,330),(2,-1,2,0,327),(0,2,1,0,-323),(1,1,-1,0,299),(2,0,3,0,294)]
BT=[(0,0,0,1,5128122),(0,0,1,1,280602),(0,0,1,-1,277693),(2,0,0,-1,173237),(2,0,-1,1,55413),(2,0,-1,-1,46271),(2,0,0,1,32573),(0,0,2,1,17198),(2,0,1,-1,9266),(0,0,2,-1,8822),(2,-1,0,-1,8216),(2,0,-2,-1,4324),(2,0,1,1,4200),(2,1,0,-1,-3359),(2,-1,-1,1,2463),(2,-1,0,1,2211),(2,-1,-1,-1,2065),(0,1,-1,-1,-1870),(4,0,-1,-1,1828),(0,1,0,1,-1794),(0,0,0,3,-1749),(0,1,-1,1,-1565),(1,0,0,1,-1491),(0,1,1,1,-1475),(0,1,1,-1,-1410),(0,1,0,-1,-1344),(1,0,0,-1,-1335),(0,0,3,1,1107),(4,0,0,-1,1021),(4,0,-1,1,833)]
def moon(T):
    Lp=norm(218.3164477+481267.88123421*T-0.0015786*T*T)
    D=norm(297.8501921+445267.1114034*T-0.0018819*T*T)
    M=norm(357.5291092+35999.0502909*T-0.0001536*T*T)
    Mp=norm(134.9633964+477198.8675055*T+0.0087414*T*T)
    F=norm(93.2720950+483202.0175233*T-0.0036539*T*T)
    A1=norm(119.75+131.849*T); A2=norm(53.09+479264.290*T); A3=norm(313.45+481266.484*T)
    E=1-0.002516*T-0.0000074*T*T
    sl=0;sr=0
    for d,m,mp,f,c in LT:
        e=E**abs(m); a=(d*D+m*M+mp*Mp+f*F)*R
        sl+=c*e*math.sin(a)
    sb=0
    for d,m,mp,f,c in BT:
        e=E**abs(m); a=(d*D+m*M+mp*Mp+f*F)*R
        sb+=c*e*math.sin(a)
    sl+=3958*math.sin(A1*R)+1962*math.sin((Lp-F)*R)+318*math.sin(A2*R)
    sb+=-2235*math.sin(Lp*R)+382*math.sin(A3*R)+175*math.sin((A1-F)*R)+175*math.sin((A1+F)*R)+127*math.sin((Lp-Mp)*R)-115*math.sin((Lp+Mp)*R)
    lon=norm(Lp+sl/1e6); lat=sb/1e6
    return lon,lat
def nutation(T):
    om=125.04-1934.136*T
    return -0.00478*math.sin(om*R)
def radec(lon,lat,T):
    eps=(obliq(T)+0.00256*math.cos((125.04-1934.136*T)*R))*R
    l=lon*R;b=lat*R
    ra=math.atan2(math.sin(l)*math.cos(eps)-math.tan(b)*math.sin(eps),math.cos(l))
    dec=math.asin(math.sin(b)*math.cos(eps)+math.cos(b)*math.sin(eps)*math.sin(l))
    return ra%(2*math.pi),dec
def gmst(J):
    T=(J-2451545.0)/36525
    return norm(280.46061837+360.98564736629*(J-2451545.0)+0.000387933*T*T)
def alt_az(J,latd,lond,ra,dec):
    H=(gmst(J)+lond)*R-ra
    la=latd*R
    return math.asin(math.sin(la)*math.sin(dec)+math.cos(la)*math.cos(dec)*math.cos(H))/R
def elong_lon(J):
    T=(J-2451545.0)/36525
    ml,_=moon(T)+(0,) if False else (moon(T)[0],0)
    return norm(ml-sun(T)+180)-180
def conjunction_near(J0):
    a=J0-3;b=J0+3
    for _ in range(60):
        m=(a+b)/2
        if elong_lon(m)>0: b=m
        else: a=m
    return (a+b)/2
def sunset(Jday0, latd, lond):  # Jday0: JD at 0h UT of the local date's ... search sunset between
    lo=Jday0; hi=Jday0+1
    # find time when sun alt crosses -0.833 going down; local sunset around 12 UT for lon 95
    def sa(J):
        T=(J-2451545.0)/36525
        lam=sun(T)+nutation(T)*0
        ra,dec=radec(lam,0,T)
        return alt_az(J,latd,lond,ra,dec)+0.833
    a=Jday0+0.20;b=Jday0+0.60   # 04:48..14:24 UT
    for _ in range(50):
        m=(a+b)/2
        if sa(m)>0: a=m
        else: b=m
    return (a+b)/2
def eval_at(J,latd,lond):
    T=(J-2451545.0)/36525
    ml,mb=moon(T); sl=sun(T)
    ra,dec=radec(ml,mb,T)
    h=alt_az(J,latd,lond,ra,dec)
    # parallax (topocentric): distance ~ 384400 km
    h_topo=h-(6378.14/385000)/R*math.cos(h*R)
    el=math.degrees(math.acos(math.cos(mb*R)*math.cos((ml-sl)*R)))
    return h_topo,el
LAT,LON=5.55,95.32
def start_for(conj):
    # local date (UTC+7) of conjunction
    t=conj+0.5+7/24
    d0=math.floor(t)  # JD at 12h? convert later
    # local date as JD midnight local = floor(conj+0.5+7/24)-0.5 ... compute UT date of local midnight
    res=[]
    for k in (0,1):
        loc_mid=math.floor(conj+0.5+7/24)+k   # integer count of local day
        # UT JD at local 00:00 = loc_mid-0.5-7/24
        ut0=loc_mid-0.5-7/24
        # sunset search expects 0h UT date: sunset local ~ 18:00 = 11:00 UT same UT day as local date
        ssJ=sunset(loc_mid-0.5,LAT,LON)
        if ssJ<conj: ok=False; h=el=None
        else:
            h,el=eval_at(ssJ,LAT,LON) if ssJ>conj else (None,None)
        yield loc_mid,ssJ,conj,h,el
def cal(jdn):  # local day number (JD noon-based int) -> date
    j=jdn+0.5
    Z=int(j);F=j-Z
    A=Z if Z<2299161 else Z+1+int((Z-1867216.25)/36524.25)-int(int((Z-1867216.25)/36524.25)/4)
    B=A+1524;C=int((B-122.1)/365.25);Dd=int(365.25*C);E=int((B-Dd)/30.6001)
    day=B-Dd-int(30.6001*E);m=E-1 if E<14 else E-13;y=C-4716 if m>2 else C-4715
    return dt.date(y,m,day)
def month_start(conj,h_min=2.95,el_min=6.35):
    for loc_mid,ssJ,c,_,_ in start_for(conj):
        if ssJ<=conj: continue
        h,el=eval_at(ssJ,LAT,LON)
        if h>=h_min and el>=el_min: return loc_mid+1, h, el
    # istikmal: evening 2 not ok
    return list(start_for(conj))[0][0]+2, None, None
