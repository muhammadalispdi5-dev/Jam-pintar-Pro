import sys,os
B=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","app/src/main/java/com/novan/bateraibicara/")
m=open(B+"MainActivity.kt").read(); u=open(B+"UpdateManager.kt").read()
def cek(n,k): print(("LULUS " if k else "GAGAL ")+n)
cek("cek tiap layar dibuka",'cekAwalLayar' in m and 'periksaOtomatisBilaPerlu(0)' in m)
cek("gagal dicoba ulang",'cekAwalLayar = false' in m)
cek("jeda 30 menit",'30L * 60 * 1000' in u)
