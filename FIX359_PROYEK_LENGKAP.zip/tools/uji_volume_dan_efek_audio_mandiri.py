from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
base = ROOT / 'app/src/main/java/com/novan/bateraibicara'
prefs = (base / 'Prefs.kt').read_text(encoding='utf-8')
page = (base / 'Halaman.kt').read_text(encoding='utf-8')
speaker = (base / 'Pembicara.kt').read_text(encoding='utf-8')
melody = (base / 'Melodi.kt').read_text(encoding='utf-8')
clock = (base / 'JamActivity.kt').read_text(encoding='utf-8')
battery = (base / 'BateraiActivity.kt').read_text(encoding='utf-8')
alarm = (base / 'AlarmJamService.kt').read_text(encoding='utf-8')
khatam = (base / 'KhatamActivity.kt').read_text(encoding='utf-8')
player = (base / 'PemutarQuranService.kt').read_text(encoding='utf-8')
assert 'var volumePersen: Int' in prefs and 'var efekRuang: Int' in prefs
assert '⚙ Volume mandiri dan efek vokal' in page and 'Aula sedang' in page and 'Aula besar' in page
assert all(label in page for label in ['Gema lembut (echo-like)', 'Studio vokal', 'Karaoke', 'Panggung konser'])
assert 'idx(kb("efek_ruang"), 0, 11)' in prefs
assert 'KEY_PARAM_VOLUME, gainSaatIni()' in speaker and 'suara.volumePersen' in speaker
assert 'PresetReverb.PRESET_MEDIUMHALL' in speaker and 'PresetReverb.PRESET_LARGEHALL' in speaker and 'KEY_PARAM_SESSION_ID' in speaker and 'mesin.audioSessionId' not in speaker
assert 'Echo-like' in speaker and 'Vocal studio' in page and 'Concert stage' in page
assert 'volume: Float = 1.0f' in melody and 'player.setVolume(volume.coerceIn' in melody
assert 'volume = prefs.suara("jam").volumePersen / 100f' in clock
assert 'volume_persen' in battery and 'efek_pengumuman' in battery
assert 'volumeMandiri' in alarm and 'volume = Prefs(this).suara("jam").volumePersen / 100f' in alarm
assert 'pengaturanVolumeAudio()' in khatam and 'volume_audio_persen' in khatam
assert 'volume_audio_persen' in player
assert 'versi' not in ''
print('UJI VOLUME DAN EFEK AUDIO MANDIRI: LULUS (profil Jam, Baterai, Khatam; volume dan preset efek ruang/vokal)')
