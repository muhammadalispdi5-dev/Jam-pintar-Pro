B="app/src/main/java/com/novan/bateraibicara/"
a=open(B+"PerintahSuaraActivity.kt").read(); w=open(B+"WaktuDunia.kt").read(); q=open(B+"TanyaJawab.kt").read()
def cek(n,k): print(("ok " if k else "GAGAL ")+n)
cek("jenis baru","WAKTU_DUNIA" in a and "TANYA_JAWAB" in a and "bacakanWaktuDunia" in a and "mulaiTanyaJawab" in a and "menungguJawabanLanjut" in a)
cek("zona","Asia/Riyadh" in w and "Asia/Tokyo" in w and "America/New_York" in w and "isDaylightSavings" in w)
cek("tanya jawab","fun akhiriSesi" in q and "fun mulaiSesi" in q and "bantuanAplikasi" in q and "tidakAda" in q)
