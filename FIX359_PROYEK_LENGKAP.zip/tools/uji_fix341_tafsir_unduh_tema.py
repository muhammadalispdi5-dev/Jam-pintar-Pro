B="app/src/main/java/com/novan/bateraibicara/"
d=open(B+"TafsirData.kt").read(); a=open(B+"TafsirActivity.kt").read()
for k in ["fun unduhSemua","fun hapus","fun cariTeks","fun jumlahTersimpan","fun sumber"]:
    print("GAGAL "+k if k not in d else "ok "+k)
for k in ["mulaiUnduhSemua","cariTema","TemaQuran.deteksi","Hapus data kitab ini"]:
    print("GAGAL "+k if k not in a else "ok "+k)
