from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
s=(R/"PemutarQuranService.kt").read_text(encoding="utf-8")
g=[]
for k in ["seluruhPerSurah = true","seluruhPerSurah = false","kataPilihSurah","kataPilihAyat","else if (seluruhPerSurah)"]:
    if k not in s: g.append("GAGAL "+k)
print("\n".join(g) if g else "UJI FIX326: LULUS")
