import re,sys
s=open('app/src/main/java/com/novan/bateraibicara/PerintahSuaraActivity.kt').read()
ok=True
def cek(n,c):
    global ok
    print(("LULUS " if c else "GAGAL ")+n); ok&=c
cek("target akurasi 3 m",'if (akurat) 3f else 2_000f' in s)
cek("berhenti saat <= 3 m",'val cukup = location.accuracy <= batasAkurasi' in s)
cek("hasil lunak 18 detik hanya <= 5 m",'postDelayed(lunak, 18_000L)' in s)
cek("batas keras 35 detik",'if (akurat) 35_000L' in s)
cek("lunak dibatalkan saat selesai",s.count('removeCallbacks(lunak)')>=1)
cek("lunak hanya <= 5 m",'t.accuracy <= 5f' in s)
cek("sinyal ada",'laporanSinyal()' in s and 'TopikPerangkat.SINYAL' in s)
sys.exit(0 if ok else 1)
