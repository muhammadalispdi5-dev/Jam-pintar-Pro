import sys
b='app/src/main/java/com/novan/bateraibicara/'
g=0
def cek(c,m):
    global g
    if not c: print("GAGAL",m); g+=1
d=open(b+'DndAzan.kt').read()
cek('PRIORITY_CATEGORY_MEDIA' in d and 'PRIORITY_CATEGORY_ALARMS' in d,'kebijakan prioritas')
cek('pulihkanKebijakan' in d and 'pasangKembaliSetelahAzan' in d,'pemulihan')
cek('DndAzan.pasangFilterRamahAzan' in open(b+'PrayerAlarmReceiver.kt').read(),'receiver')
cek('DndAzan.pulihkanKebijakan' in open(b+'PrayerAlarm.kt').read(),'restore')
s=open(b+'PrayerAlarmService.kt').read()
cek('DndAzan.izinkanSuaraAzan' in s and 'DndAzan.pasangKembaliSetelahAzan' in s,'service')
print("selesai",g)
