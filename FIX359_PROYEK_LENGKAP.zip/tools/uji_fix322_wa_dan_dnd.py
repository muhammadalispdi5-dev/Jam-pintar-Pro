from pathlib import Path
R=Path(__file__).resolve().parents[1]/"app/src/main/java/com/novan/bateraibicara"
t=lambda n:(R/n).read_text(encoding="utf-8")
g=[]
if "semuaWa.size == 1" not in t("PencocokAplikasi.kt"): g.append("GAGAL wa tunggal")
if '"tahajud", "dhuha")' not in t("PrayerAlarm.kt"): g.append("GAGAL dnd alarm")
if 'name != "tahajud" && name != "dhuha"' not in t("PrayerPrefs.kt"): g.append("GAGAL default dnd")
if '"Tahajud" to "tahajud", "Dhuha" to "dhuha"' not in t("PrayerSettingsActivity.kt"): g.append("GAGAL saklar dnd")
if 'it in setOf("wa", "whatsapp", "watsap", "wasap", "w4b")' not in t("PerintahSuaraActivity.kt"): g.append("GAGAL klasifikasi wa")
print("\n".join(g) if g else "UJI FIX322: LULUS")
