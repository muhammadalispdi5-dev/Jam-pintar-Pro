# FIX322
- Buka WhatsApp: satu jenis terpasang langsung dibuka, lebih dari satu: pilih/sebut spesifik (PencocokAplikasi + klasifikasi).
- Saklar DND Tahajud dan Dhuha (bawaan mati), memakai prayerMinutes (waktu khusus/hitungan). Petunjuk ID 92 / EN 89.
