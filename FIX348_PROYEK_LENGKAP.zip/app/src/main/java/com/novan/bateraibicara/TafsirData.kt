package com.novan.bateraibicara

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * FIX338: kitab tafsir. Teks diunduh per surah dari proyek terbuka spa5k/tafsir_api (lewat jsDelivr atau GitHub mentah) lalu disimpan
 * di penyimpanan aplikasi sehingga surah yang pernah dibuka dapat dibaca tanpa internet. Penguraian JSON dibuat longgar
 * (beberapa bentuk kunci) karena bentuk berkas tiap edisi belum diuji di perangkat.
 */
object TafsirData {
    class Dua(val id: String, val en: String)
    private fun tr(id: String, en: String) = Dua(id, en)

    class Kitab(val slug: String, val nama: Dua, val bahasa: String, val kunci: List<String>)

    val daftar: List<Kitab> = listOf(
        Kitab("in-tafsir-jalalayn", tr("Tafsir Jalalayn (Indonesia)", "Tafsir Jalalayn (Indonesian)"), "id", listOf("jalalayn", "jalalain", "jalalen", "jalalan")),
        Kitab("id-tafsir-as-saadi", tr("Tafsir As-Sa'di (Indonesia)", "Tafsir As-Sa'di (Indonesian)"), "id", listOf("saadi", "sa'di", "sadi", "as sa di")),
        Kitab("indonesian-mokhtasar", tr("Tafsir Al-Mukhtashar (Indonesia)", "Tafsir Al-Mukhtasar (Indonesian)"), "id", listOf("mukhtashar", "mukhtasar", "mokhtasar", "muhtasar")),
        Kitab("ar-tafsir-muyassar", tr("Tafsir Al-Muyassar (Arab)", "Tafsir Al-Muyassar (Arabic)"), "ar", listOf("muyassar", "muyasar", "muaisar")),
        Kitab("ar-tafsir-ibn-kathir", tr("Tafsir Ibnu Katsir (Arab)", "Tafsir Ibn Kathir (Arabic)"), "ar", listOf("katsir", "kathir", "katir", "kasir", "ibnu katsir", "ibn kathir")),
        Kitab("ar-tafsir-al-jalalayn", tr("Tafsir Jalalayn (Arab)", "Tafsir Jalalayn (Arabic)"), "ar", listOf("jalalayn arab")),
        Kitab("en-tafisr-ibn-kathir", tr("Tafsir Ibn Kathir (Inggris)", "Tafsir Ibn Kathir (English)"), "en", listOf("kathir inggris", "ibn kathir english")),
        Kitab("en-al-jalalayn", tr("Tafsir Jalalayn (Inggris)", "Tafsir Jalalayn (English)"), "en", listOf("jalalayn inggris", "jalalayn english")),
        Kitab("kemenag-ringkas", tr("Tafsir Kemenag ringkas (Indonesia)", "Tafsir Kemenag short (Indonesian)"), "id", listOf("kemenag ringkas", "kemenag singkat", "kemenag")),
        Kitab("kemenag-lengkap", tr("Tafsir Kemenag lengkap (Indonesia)", "Tafsir Kemenag full (Indonesian)"), "id", listOf("kemenag lengkap", "kemenag panjang"))
    )

    private val kunciAyat = listOf("ayah", "verse", "aya", "ayat", "number", "id", "ayah_number", "verse_number")
    private val kunciTeks = listOf("text", "content", "tafsir", "body", "tafseer")
    private val kunciDaftar = listOf("ayahs", "verses", "tafsir", "data", "result", "results", "ayat")

    private fun berkas(c: Context, slug: String, surah: Int): File {
        val dir = File(c.applicationContext.filesDir, "tafsir/" + slug)
        dir.mkdirs()
        return File(dir, "$surah.json")
    }

    fun tersimpan(c: Context, slug: String, surah: Int): Boolean = berkas(c, slug, surah).let { it.exists() && it.length() > 2 }

    @Volatile var galatTerakhir = ""

    private fun ambil(alamat: String): String? {
        return try {
            var u = alamat
            for (loncat in 0..4) {
                val k = URL(u).openConnection() as HttpURLConnection
                k.connectTimeout = 15000; k.readTimeout = 40000
                k.instanceFollowRedirects = true
                k.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JamPintarPro")
                k.setRequestProperty("Accept", "application/json,*/*")
                try {
                    val kode = k.responseCode
                    if (kode in 300..399) { val l = k.getHeaderField("Location"); if (l.isNullOrBlank()) { galatTerakhir = "HTTP " + kode.toString(); return null }; u = URL(URL(u), l).toString(); continue }
                    if (kode != 200) { galatTerakhir = "HTTP " + kode.toString(); return null }
                    return k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } finally { k.disconnect() }
            }
            galatTerakhir = "terlalu banyak pengalihan"; null
        } catch (e: Exception) { galatTerakhir = (e.javaClass.simpleName + " " + (e.message ?: "")).take(120); null }
    }

    private val dasarMirror = listOf(
        "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/",
        "https://raw.githubusercontent.com/spa5k/tafsir_api/main/tafsir/",
        "https://rawcdn.githack.com/spa5k/tafsir_api/bf42646e16973c59a0789b7a3ad065ff6ad6b0bf/tafsir/"
    )
    private val hanyaPerAyat = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    @Volatile var daftarSlugContoh = ""

    /** Daftar edisi (slug) dari editions.json; disimpan di HP. */
    private fun edisi(c: Context): List<Pair<String, String>> {
        val f = File(File(c.applicationContext.filesDir, "tafsir").also { it.mkdirs() }, "editions.json")
        var teks: String? = if (f.exists() && f.length() > 10) try { f.readText(Charsets.UTF_8) } catch (_: Exception) { null } else null
        if (teks == null) {
            for (d in dasarMirror) { val t = ambil(d + "editions.json"); if (t != null && t.length > 10) { teks = t; try { f.writeText(t, Charsets.UTF_8) } catch (_: Exception) { }; break } }
        }
        val hasil = ArrayList<Pair<String, String>>()
        try {
            val akar: Any = try { JSONObject(teks ?: return hasil) } catch (_: Exception) { JSONArray(teks) }
            val arr = cariDaftar(akar, 0) ?: return hasil
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val sl = e.optString("slug", "")
                if (sl.isNotBlank()) hasil.add(sl to (e.optString("name", "") + " " + e.optString("author_name", "") + " " + e.optString("language_name", "")).lowercase())
            }
        } catch (_: Exception) { }
        return hasil
    }

    /** Mencocokkan slug bawaan dengan edisi yang benar-benar ada di sumber. */
    private fun resolusi(c: Context, slug: String): String {
        val e = edisi(c)
        if (e.isEmpty()) return slug
        daftarSlugContoh = e.map { it.first }.filter { it.startsWith("in") || it.startsWith("id") || it.startsWith("ar") || it.startsWith("en") }.take(60).joinToString(", ")
        if (e.any { it.first == slug }) return slug
        val kit = daftar.firstOrNull { it.slug == slug } ?: return slug
        val awalan = kit.bahasa
        val kata = kit.kunci.map { it.lowercase() }
        val cocok = e.firstOrNull { (sl, info) -> (sl.startsWith(awalan) || sl.startsWith(if (awalan == "id") "in" else awalan)) && kata.any { info.contains(it) || sl.contains(it.replace(" ", "-")) } }
        return cocok?.first ?: slug
    }

    /** Unduhan satu berkas; kode 404 dikembalikan sebagai (404, null). Aman dipakai bersamaan. */
    private fun ambilKode(alamat: String): Pair<Int, String?> {
        return try {
            val k = URL(alamat).openConnection() as HttpURLConnection
            k.connectTimeout = 15000; k.readTimeout = 30000
            k.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JamPintarPro")
            try {
                val kode = k.responseCode
                if (kode == 200) 200 to k.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() } else kode to null
            } finally { k.disconnect() }
        } catch (e: Exception) { -1 to (e.javaClass.simpleName + " " + (e.message ?: "")).take(100) }
    }

    private fun teksAyat(t: String): String {
        val o = try { JSONObject(t) } catch (_: Exception) { return "" }
        var isi = ""
        for (k in kunciTeks) { val v = o.optString(k, ""); if (v.isNotBlank()) { isi = v; break } }
        if (isi.isBlank()) {
            val it2 = o.keys()
            while (it2.hasNext()) { val kk = it2.next(); val v = o.opt(kk); if (v is String && v.length > isi.length && kk !in listOf("name", "slug", "source", "author", "language")) isi = v }
        }
        return isi.replace(Regex("<[^>]+>"), " ").replace(Regex("[ \\t]+"), " ").trim()
    }

    /** Cadangan bila berkas per surah tidak ada: ambil per ayat (paralel), ayat 404 dianggap kosong. */
    private fun muatPerAyat(slugUrl: String, surah: Int, dasar: String): Pair<Map<Int, String>?, String> {
        val n = PenafsirQuran.jumlahAyat(surah)
        val hasil = java.util.concurrent.ConcurrentHashMap<Int, String>()
        val gagal = java.util.concurrent.atomic.AtomicInteger(0)
        val contohGalat = java.util.concurrent.atomic.AtomicReference("")
        val antre = java.util.concurrent.atomic.AtomicInteger(1)
        val pekerja = (1..6).map {
            Thread {
                while (!batalUnduh) {
                    val a = antre.getAndIncrement()
                    if (a > n || gagal.get() > 3) break
                    var kode = -1; var isi: String? = null
                    for (coba in 0..1) { val r = ambilKode(dasar + slugUrl + "/" + surah + "/" + a + ".json"); kode = r.first; isi = r.second; if (kode == 200 || kode == 404) break }
                    if (kode == 200 && isi != null) { val t = teksAyat(isi); if (t.isNotBlank()) hasil[a] = t }
                    else if (kode != 404) { gagal.incrementAndGet(); contohGalat.set("ayat " + a + ": " + kode + " " + (isi ?: "")) }
                }
            }.also { it.start() }
        }
        pekerja.forEach { try { it.join() } catch (_: Exception) { } }
        if (gagal.get() > 0 || hasil.isEmpty()) return null to (if (contohGalat.get().isNotEmpty()) contohGalat.get() else "ayah: 404")
        return hasil.toSortedMap() to ""
    }

    // ---------------- Sumber cadangan: API Quran.com (nomor sumber dicari otomatis) ----------------
    private val QC = "https://api.quran.com/api/v4/"
    @Volatile var daftarQuranCom = ""

    private fun daftarSumberQc(c: Context): List<JSONObject> {
        val f = File(File(c.applicationContext.filesDir, "tafsir").also { it.mkdirs() }, "qcom_resources.json")
        var teks: String? = if (f.exists() && f.length() > 10) try { f.readText(Charsets.UTF_8) } catch (_: Exception) { null } else null
        if (teks == null) { teks = ambil(QC + "resources/tafsirs"); if (teks != null) try { f.writeText(teks, Charsets.UTF_8) } catch (_: Exception) { } }
        val hasil = ArrayList<JSONObject>()
        try {
            val arr = JSONObject(teks ?: return hasil).optJSONArray("tafsirs") ?: return hasil
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { hasil.add(it) }
        } catch (_: Exception) { }
        return hasil
    }

    private fun cocokQc(c: Context, kit: Kitab): JSONObject? {
        val semua = daftarSumberQc(c)
        val bhs = when (kit.bahasa) { "id" -> "indonesian"; "ar" -> "arabic"; else -> "english" }
        val satuBahasa = semua.filter { it.optString("language_name", "").lowercase() == bhs }
        daftarQuranCom = satuBahasa.joinToString("; ") { it.optInt("id").toString() + " " + it.optString("name", "") + " / " + it.optString("author_name", "") }
        val kata = (kit.kunci + kit.slug.split("-")).map { it.lowercase() }.filter { it.length >= 4 && it !in listOf("tafsir", "tafisr", "indonesian", "arab", "inggris") }
        var terbaik: JSONObject? = null; var skorTerbaik = 0
        for (o in satuBahasa) {
            val info = (o.optString("name", "") + " " + o.optString("author_name", "") + " " + o.optString("slug", "")).lowercase()
            val skor = kata.count { info.contains(it) }
            if (skor > skorTerbaik) { skorTerbaik = skor; terbaik = o }
        }
        return terbaik
    }

    private fun muatQuranCom(c: Context, slugAsal: String, surah: Int): Map<Int, String>? {
        val kit = daftar.firstOrNull { it.slug == slugAsal } ?: return null
        val sumber = cocokQc(c, kit)
        if (sumber == null) { galatTerakhir = "quran.com: no matching edition"; return null }
        val id = sumber.optInt("id")
        val hasil = java.util.TreeMap<Int, String>()
        var halaman = 1
        while (halaman <= 20) {
            val t = ambil(QC + "tafsirs/" + id + "/by_chapter/" + surah + "?per_page=50&page=" + halaman) ?: return null
            val o = try { JSONObject(t) } catch (_: Exception) { galatTerakhir = "quran.com: bad data"; return null }
            val arr = o.optJSONArray("tafsirs") ?: return null
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val kunci = e.optString("verse_key", "")
                val ay = kunci.substringAfter(":", "").toIntOrNull() ?: continue
                val tk = e.optString("text", "").replace(Regex("<[^>]+>"), " ").replace(Regex("[ \\t]+"), " ").trim()
                if (tk.isNotBlank()) hasil[ay] = tk
            }
            val berikut = o.optJSONObject("pagination")?.opt("next_page")
            if (berikut == null || berikut == JSONObject.NULL || (berikut is Number && berikut.toInt() <= halaman)) break
            halaman++
        }
        if (hasil.isEmpty()) { galatTerakhir = "quran.com: empty"; return null }
        return hasil
    }

    /** Tafsir Kemenag (ringkas/lengkap) dari api.quran.gading.dev; bentuk data: data.verses[].tafsir.id.short/long. */
    private fun muatKemenag(slug: String, surah: Int): Map<Int, String>? {
        val t = ambil("https://api.quran.gading.dev/surah/" + surah) ?: return null
        val hasil = java.util.TreeMap<Int, String>()
        try {
            val ayat = JSONObject(t).optJSONObject("data")?.optJSONArray("verses") ?: run { galatTerakhir = "gading: bad data"; return null }
            for (i in 0 until ayat.length()) {
                val e = ayat.optJSONObject(i) ?: continue
                val no = e.optJSONObject("number")?.optInt("inSurah", 0) ?: 0
                val td = e.optJSONObject("tafsir")?.optJSONObject("id")
                var tk = td?.optString(if (slug.endsWith("lengkap")) "long" else "short", "") ?: ""
                if (tk.isBlank()) tk = td?.optString("short", "") ?: ""
                if (no > 0 && tk.isNotBlank()) hasil[no] = tk.replace(Regex("<[^>]+>"), " ").replace(Regex("[ \\t]+"), " ").trim()
            }
        } catch (_: Exception) { galatTerakhir = "gading: bad data"; return null }
        if (hasil.isEmpty()) { galatTerakhir = "gading: empty"; return null }
        return hasil
    }

    /** Memuat tafsir satu surah: nomor ayat ke teks. Panggil di thread latar. Null bila tidak tersimpan dan tidak dapat diunduh. */
    @Synchronized
    fun muat(c: Context, slugAsal: String, surah: Int): Map<Int, String>? {
        val slug = slugAsal
        val f = berkas(c, slug, surah)
        if (f.exists() && f.length() > 2) {
            val lokal = try { urai(f.readText(Charsets.UTF_8)) } catch (_: Exception) { null }
            if (lokal != null && lokal.isNotEmpty()) return lokal
            try { f.delete() } catch (_: Exception) { }
        }
        if (slugAsal.startsWith("kemenag-")) {
            val k = muatKemenag(slugAsal, surah) ?: return null
            try {
                val arr = JSONArray()
                for ((ay, tk) in k) arr.put(JSONObject().put("ayah", ay).put("text", tk))
                f.writeText(JSONObject().put("ayahs", arr).toString(), Charsets.UTF_8)
            } catch (_: Exception) { }
            return k
        }
        val slugUrl = resolusi(c, slugAsal)
        val alamat = listOf(
            "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/$slugUrl/$surah.json",
            "https://raw.githubusercontent.com/spa5k/tafsir_api/main/tafsir/$slugUrl/$surah.json",
            "https://github.com/spa5k/tafsir_api/raw/main/tafsir/$slugUrl/$surah.json",
            "https://rawcdn.githack.com/spa5k/tafsir_api/bf42646e16973c59a0789b7a3ad065ff6ad6b0bf/tafsir/$slugUrl/$surah.json",
            "https://fastly.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/$slugUrl/$surah.json"
        )
        val semuaGalat = StringBuilder()
        for (a in (if (slugUrl in hanyaPerAyat) emptyList() else alamat)) {
            val teks = ambil(a)
            if (teks == null) { semuaGalat.append(a.substringAfter("://").substringBefore("/")).append(": ").append(galatTerakhir).append("; "); continue }
            val hasil = try { urai(teks) } catch (_: Exception) { null }
            if (hasil == null || hasil.isEmpty()) galatTerakhir = tr("format data tidak dikenali: ", "unrecognized data format: ").id + teks.take(80).replace("\n", " ")
            if (hasil != null && hasil.isNotEmpty()) {
                try { f.writeText(teks, Charsets.UTF_8) } catch (_: Exception) { }
                return hasil
            }
        }
        // Cadangan 1: API Quran.com.
        run {
            val q = muatQuranCom(c, slugAsal, surah)
            if (q != null) {
                hanyaPerAyat.add(slugUrl)
                try {
                    val arr = JSONArray()
                    for ((ay, tk) in q) arr.put(JSONObject().put("ayah", ay).put("text", tk))
                    f.writeText(JSONObject().put("ayahs", arr).toString(), Charsets.UTF_8)
                } catch (_: Exception) { }
                return q
            }
            semuaGalat.append("api.quran.com: ").append(galatTerakhir).append("; ")
        }
        // Cadangan 2: berkas per ayat.
        if (!batalUnduh || true) {
            for (dasar in dasarMirror.take(3)) {
                val (peta, galat) = muatPerAyat(slugUrl, surah, dasar)
                if (peta != null) {
                    hanyaPerAyat.add(slugUrl)
                    try {
                        val arr = JSONArray()
                        for ((ay, tk) in peta) arr.put(JSONObject().put("ayah", ay).put("text", tk))
                        f.writeText(JSONObject().put("ayahs", arr).toString(), Charsets.UTF_8)
                    } catch (_: Exception) { }
                    return peta
                }
                semuaGalat.append(dasar.substringAfter("://").substringBefore("/")).append(" (ayah): ").append(galat).append("; ")
            }
        }
        if (semuaGalat.isNotEmpty() && daftarSlugContoh.isNotEmpty() && slugUrl != slugAsal) semuaGalat.append(" [dipakai: " + slugUrl + "]")
        if (semuaGalat.isNotEmpty()) galatTerakhir = (semuaGalat.toString() + (if (galatTerakhir.startsWith("format") || galatTerakhir.startsWith("unrecog")) galatTerakhir else "")).trim()
        return null
    }

    private fun cariDaftar(o: Any?, kedalaman: Int): JSONArray? {
        if (o is JSONArray) return o
        if (o !is JSONObject || kedalaman > 2) return null
        for (k in kunciDaftar) { val v = o.opt(k); if (v is JSONArray) return v }
        for (k in kunciDaftar) { val v = o.opt(k); if (v is JSONObject) cariDaftar(v, kedalaman + 1)?.let { return it } }
        return null
    }

    private fun urai(teks: String): Map<Int, String>? {
        val akar: Any = try { JSONObject(teks) } catch (_: Exception) { try { JSONArray(teks) } catch (_: Exception) { return null } }
        val arr = cariDaftar(akar, 0) ?: return null
        val hasil = LinkedHashMap<Int, String>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            var nomor = 0
            for (k in kunciAyat) { val n = e.optInt(k, 0); if (n > 0) { nomor = n; break } }
            if (nomor == 0) nomor = i + 1
            var isi = ""
            for (k in kunciTeks) { val s = e.optString(k, ""); if (s.isNotBlank()) { isi = s; break } }
            if (isi.isBlank()) { val it2 = e.keys(); while (it2.hasNext()) { val kk = it2.next(); val v = e.opt(kk); if (v is String && v.length > isi.length && kk !in listOf("name", "slug", "source", "author", "language")) isi = v } }
            hasil[nomor] = isi.replace(Regex("<[^>]+>"), " ").replace(Regex("[ \\t]+"), " ").trim()
        }
        return hasil
    }

    // ---------------- FIX341: unduh seluruh kitab, hapus, dan pencarian tema ----------------
    @Volatile var batalUnduh = false

    fun sumber(slug: String): String = if (slug.startsWith("kemenag-")) "https://api.quran.gading.dev/surah/" else "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/" + slug + "/"

    fun jumlahTersimpan(c: Context, slug: String): Int = (1..114).count { tersimpan(c, slug, it) }

    fun hapus(c: Context, slug: String) {
        try { File(c.applicationContext.filesDir, "tafsir/" + slug).deleteRecursively() } catch (_: Exception) { }
    }

    /** Mengunduh semua surah kitab (yang belum tersimpan); panggil di thread latar. Mengembalikan jumlah surah tersimpan setelahnya. */
    fun unduhSemua(c: Context, slug: String, lapor: (selesai: Int, total: Int) -> Unit): Int {
        batalUnduh = false
        galatTerakhir = ""
        var gagalBeruntun = 0
        for (putaran in 0..1) {
            for (sr in 1..114) {
                if (batalUnduh) return jumlahTersimpan(c, slug)
                if (!tersimpan(c, slug, sr)) {
                    if (muat(c, slug, sr) == null) gagalBeruntun++ else gagalBeruntun = 0
                    if (gagalBeruntun >= 4 && jumlahTersimpan(c, slug) == 0) return 0
                }
                lapor(jumlahTersimpan(c, slug), 114)
            }
            if (jumlahTersimpan(c, slug) >= 114) break
        }
        return jumlahTersimpan(c, slug)
    }

    private val kataSambung = setOf("yang", "dan", "dengan", "untuk", "dari", "pada", "dalam", "atau", "itu", "ini", "ada", "adalah", "kepada", "tentang", "mengenai", "the", "and", "of", "for", "with", "about")

    fun kataKunci(kueri: String): List<String> =
        kueri.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").split(Regex("\\s+")).filter { it.length >= 3 && it !in kataSambung }.distinct()

    /** Mencari kata kunci di tafsir yang sudah diunduh. Hasil: surah, ayat, cuplikan; semua kata lebih dulu, lalu minimal setengah kata. Thread latar. */
    fun cariTeks(c: Context, slug: String, kueri: String, batas: Int): List<Triple<Int, Int, String>> {
        val kata = kataKunci(kueri)
        if (kata.isEmpty()) return emptyList()
        val perlu = (kata.size + 1) / 2
        val semua = ArrayList<Pair<Int, Triple<Int, Int, String>>>()
        for (sr in 1..114) {
            if (!tersimpan(c, slug, sr)) continue
            val peta = try { urai(berkas(c, slug, sr).readText(Charsets.UTF_8)) } catch (_: Exception) { null } ?: continue
            for ((ay, tk) in peta) {
                if (tk.isBlank()) continue
                val rendah = tk.lowercase()
                val skor = kata.count { rendah.contains(it) }
                if (skor >= perlu) {
                    val pos = kata.map { rendah.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: 0
                    val mulai = (pos - 40).coerceAtLeast(0)
                    semua.add(skor to Triple(sr, ay, tk.substring(mulai, (mulai + 160).coerceAtMost(tk.length)).replace("\n", " ").trim()))
                }
            }
        }
        return semua.sortedWith(compareByDescending<Pair<Int, Triple<Int, Int, String>>> { it.first }.thenBy { it.second.first * 1000 + it.second.second }).take(batas).map { it.second }
    }

    /** Teks tafsir ayat [ayat]; bila kosong (tafsir menggabung beberapa ayat) dikembalikan teks ayat sebelumnya yang tidak kosong beserta nomornya. */
    fun untukAyat(peta: Map<Int, String>, ayat: Int): Pair<Int, String>? {
        val langsung = peta[ayat]
        if (!langsung.isNullOrBlank()) return ayat to langsung
        var k = ayat - 1
        while (k >= 1) { val t = peta[k]; if (!t.isNullOrBlank()) return k to t; k-- }
        return null
    }

    /** Kitab yang disebut dalam ucapan (dicocokkan dari kata kunci); null bila tidak disebut. */
    fun cariKitab(kandidat: List<String>): Int? {
        for (u in kandidat) {
            val s = u.lowercase().replace(Regex("[^a-z' ]"), " ").replace(Regex("\\s+"), " ")
            val arab = s.contains("arab")
            val inggris = s.contains("inggris") || s.contains("english")
            var terbaik: Int? = null
            for ((i, k) in daftar.withIndex()) {
                if (k.kunci.any { s.contains(it) }) {
                    if (arab && k.bahasa == "ar") return i
                    if (inggris && k.bahasa == "en") return i
                    if (terbaik == null) terbaik = i
                }
            }
            // "jalalayn" tanpa bahasa: Indonesia; Katsir tanpa bahasa: Arab sudah dipilih urutan daftar.
            if (terbaik != null) return terbaik
        }
        return null
    }
}
